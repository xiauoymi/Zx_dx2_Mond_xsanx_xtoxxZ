/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 * Filename:    $RCSfile: MockDfUser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:35:07 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MockDfUser extends MockPersistentObject implements IDfUser {
    private String userLoginName;
    private String defaultACL;
    private String aliasSet;
    private int clientCapability;
    private String folderPath;
    private String description;
    private String homeDocbase;
    private String userAddress;
    private String userDBName;
    private String userDelegation;
    private String userGroupName;
    private String userName;
    private String accountName;
    private String domainName;
    private int userPrivileges;
    private int userState;
    private boolean globallyManaged;
    private int userSource;
    private boolean workflowDisabled;
    private int userXPrivileges;
    private int failedAuthenticationAttempts;
    private String userSourceAsString;
    private String aclDomain = "testacldomain";
    private IDfTime modifyDate = new DfTime();

    public void save() throws DfException {
       wasSaveCalled = true;
        IDfSession session = getSession();
        if (session instanceof MockSession) {
            MockSession mockSession = (MockSession) session;
            setString("r_object_id", "testuser" + accountName);
            mockSession.addObject(this, "dm_user where user_name='" + userName + "'");
            mockSession.addObject(this,
                                  "dm_user where user_name='" + userName + "' or user_os_name='" + accountName + "'");
            mockSession.addObject(this, "testuser" + accountName);

            IDfGroup userGroup = mockSession.getGroup(userGroupName);
            if (userGroup != null) {
                userGroup.addUser(userName);
            } else {
                throw new DfException("can't find user group");
            }
        }
    }

  public boolean isDeleted() throws DfException {
    return false;
  }

  public boolean isReplica() throws DfException {
    return false;
  }

  public int getVStamp() throws DfException {
    return 0;
  }

  public void destroy() throws DfException {
  }

  public IDfType getType() throws DfException {
    return null;
  }

  public boolean isNew() throws DfException {
    return false;
  }

  public void revert() throws DfException {
  }

  public boolean apiSet(String s, String s1, String s2) throws DfException {
    return false;
  }

  public boolean apiExec(String s, String s1) throws DfException {
    return false;
  }

  public boolean fetch(String s) throws DfException {
    return false;
  }

  public boolean fetchWithCaching(String s, boolean b, boolean b1) throws DfException {
    return false;
  }

  public IDfRelation addChildRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public IDfRelation addParentRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public void removeChildRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public void removeParentRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public IDfCollection getChildRelatives(String s) throws DfException {
    return null;
  }

  public IDfCollection getParentRelatives(String s) throws DfException {
    return null;
  }

  public void signoff(String s, String s1, String s2) throws DfException {
  }

  public void validateAllRules(int i) throws DfException {
  }

  public void validateObjRules(int i) throws DfException {
  }

  public void validateAttrRules(String s, int i) throws DfException {
  }

  public void validateAttrRulesWithValue(String s, String s1, int i) throws DfException {
  }

  public void validateAttrRulesWithValues(String s, IDfList iDfList, int i) throws DfException {
  }

  public void validateObjRulesWithValues(IDfList iDfList, IDfList iDfList1, int i) throws DfException {
  }

  public IDfList getAttrAsstDependencies(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistance(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistanceWithValues(String s, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public String getWidgetType(int i, String s) throws DfException {
    return null;
  }

  public IDfValidator getValidator() throws DfException {
    return null;
  }

  public boolean isDirty() throws DfException {
    return false;
  }

  public String getUserName() throws DfException {
        return userName;
    }

    public String getUserOSName() throws DfException {
        return accountName;
    }

    public String getUserAddress() throws DfException {
        return userAddress;
    }

    public String getUserGroupName() throws DfException {
        return userGroupName;
    }

    public int getUserPrivileges() throws DfException {
        return userPrivileges;
    }

    public boolean isSuperUser() throws DfException {
        return false;
    }

    public boolean isSystemAdmin() throws DfException {
        return false;
    }

    public int getOwnerDefPermit() throws DfException {
        return 0;
    }

    public int getGroupDefPermit() throws DfException {
        return 0;
    }

    public int getWorldDefPermit() throws DfException {
        return 0;
    }

    public String getDefaultFolder() throws DfException {
        return folderPath;
    }

    public boolean isGroup() throws DfException {
        return false;
    }

    public String getUserDBName() throws DfException {
        return userDBName;
    }

    public String getDescription() throws DfException {
        return description;
    }

    public String getACLDomain() throws DfException {
        return aclDomain;
    }

    public String getACLName() throws DfException {
        return defaultACL;
    }

    public String getUserOSDomain() throws DfException {
        return domainName;
    }

    public String getHomeDocbase() throws DfException {
        return homeDocbase;
    }

    public int getUserState() throws DfException {
        return userState;
    }

    public boolean isGloballyManaged() throws DfException {
        return globallyManaged;
    }

    public IDfTime getModifyDate() throws DfException {
        return modifyDate;
    }

    public IDfId getAliasSetId() throws DfException {
        return null;
    }

    public String getAliasSet() throws DfException {
        return aliasSet;
    }

    public int getClientCapability() throws DfException {
        return clientCapability;
    }

    public String getUserDelegation() throws DfException {
        return userDelegation;
    }

    public boolean isWorkflowDisabled() throws DfException {
        return workflowDisabled;
    }

    public int getUserSource() throws DfException {
        return userSource;
    }

    public boolean hasSession() throws DfException {
        return false;
    }

    public String getUserLoginName() throws DfException {
        return userLoginName;
    }

    public void setUserLoginName(String userLoginName) throws DfException {
        this.userLoginName = userLoginName;
    }

    public void setDefaultACL(String defaultACL) throws DfException {
        this.defaultACL = defaultACL;
    }

    public void setAliasSet(String aliasSet) throws DfException {
        this.aliasSet = aliasSet;
    }

    public void setClientCapability(int clientCapability) throws DfException {
        this.clientCapability = clientCapability;
    }

    public void setDefaultFolder(String folderPath, boolean isPrivate) throws DfException {
        this.folderPath = folderPath;
    }

    public void setDescription(String description) throws DfException {
        this.description = description;
    }

    public void setHomeDocbase(String homeDocbase) throws DfException {
        this.homeDocbase = homeDocbase;
    }

    public void changeHomeDocbase(String userName, boolean isImmediate) throws DfException {
        if (userName == null) throw new DfException("can't change home docbase to null");
    }

    public void setUserAddress(String userAddress) throws DfException {
        this.userAddress = userAddress;
    }

    public void setUserDBName(String userDBName) throws DfException {
        this.userDBName = userDBName;
    }

    public void setUserDelegation(String userDelegation) throws DfException {
        this.userDelegation = userDelegation;
    }

    public void setUserGroupName(String userGroupName) throws DfException {
        this.userGroupName = userGroupName;
    }

    public void setUserName(String userName) throws DfException {
        this.userName = userName;
    }

    public void renameUser(String userName, boolean isImmediate, boolean unlockObjects, boolean reportOnly) throws
                                                                                                            DfException {
    }

    public void setUserOSName(String accountName, String domainName) throws DfException {
        this.accountName = accountName;
        this.domainName = domainName;
    }

    public void setUserPrivileges(int userPrivileges) throws DfException {
        this.userPrivileges = userPrivileges;
    }

    public void setUserState(int userState, boolean unlockObjects) throws DfException {
        this.userState = userState;
    }

    public void setGloballyManaged(boolean globallyManaged) throws DfException {
        this.globallyManaged = globallyManaged;
    }

    public void setUserSource(int userSource) throws DfException {
        this.userSource = userSource;
    }

    public void setWorkflowDisabled(boolean workflowDisabled) throws DfException {
        this.workflowDisabled = workflowDisabled;
    }

    public void setWriteFederationLogOption(int writeFederationLogOption) throws DfException {

    }

    public void setUserXPrivileges(int userXPrivileges) throws DfException {
        this.userXPrivileges = userXPrivileges;
    }

    public int getUserXPrivileges() throws DfException {
        return userXPrivileges;
    }

    public void setFailedAuthenticationAttempts(int failedAuthenticationAttempts) throws DfException {
        this.failedAuthenticationAttempts = failedAuthenticationAttempts;
    }

    public int getFailedAuthenticationAttempts() throws DfException {
        return failedAuthenticationAttempts;
    }

    public String getUserDistinguishedLDAPName() throws DfException {
        return null;
    }

    public boolean hasEvents() throws DfException {
        return false;
    }

    public String getUserSourceAsString() throws DfException {
        return userSourceAsString;
    }

    public void setUserSourceAsString(String userSourceAsString) throws DfException {
        this.userSourceAsString = userSourceAsString;
    }
}