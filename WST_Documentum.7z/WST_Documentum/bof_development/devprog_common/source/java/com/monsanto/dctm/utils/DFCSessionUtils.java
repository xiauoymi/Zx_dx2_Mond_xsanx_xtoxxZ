/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * Filename:    $RCSfile: DFCSessionUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 15:52:08 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class DFCSessionUtils {

    private static IDfSession session = null;
    private static IDfSessionManager sessionManager = null;

    public static IDfSession getSession() {
        return session;
    }

    public static IDfSessionManager getSessionManager() {
        return sessionManager;
    }

    protected static void displayError(Exception e) {
        System.out.println("<<<<<<<<< An error has occurred");
        e.printStackTrace();
    }

    public static IDfSession login(String strDocbase, String uName, String pWord, String domain) throws DfException {
        IDfClientX clientX = new DfClientX();
        IDfClient client = clientX.getLocalClient();
        sessionManager = client.newSessionManager();
        IDfLoginInfo loginInfo = clientX.getLoginInfo();
        loginInfo.setUser(uName);
        loginInfo.setPassword(pWord);
        loginInfo.setDomain(domain);
        sessionManager.setIdentity(strDocbase, loginInfo);
        session = sessionManager.getSession(strDocbase);
        System.out.println(">>>>>>>>> Logged into the docbase " + strDocbase + " as " + uName);
        return session;

    }

    public static void logout() {
        if (session != null) {
            sessionManager.release(session);
            System.out.println("<<<<<<<<< Released session");
        }
    }

    public static IDfSessionManager createSessionManager(String docbase, String user, String pass) throws DfException {
        IDfClientX clientx = new DfClientX();
        IDfClient client = clientx.getLocalClient();
        IDfSessionManager sMgr = client.newSessionManager();
        IDfLoginInfo loginInfoObj = clientx.getLoginInfo();
        loginInfoObj.setUser(user);
        loginInfoObj.setPassword(pass);
        loginInfoObj.setDomain(null);
        sMgr.setIdentity(docbase, loginInfoObj);
        return sMgr;
    }
}