/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfId;

/**
 * Filename:    $RCSfile: MockDfACL.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-07-13 20:16:40 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockDfACL extends MockPersistentObject implements IDfACL {
    public String docbaseOwnerName;
    public String aclName;

    public MockDfACL(String docbaseOwnerName, String aclName) {
        this.docbaseOwnerName = docbaseOwnerName;
        this.aclName = aclName;
    }

    public void setObjectName(String string) throws DfException {
        this.aclName = string;
    }

  public boolean isReplica() throws DfException {
    return false;
  }

  public int getVStamp() throws DfException {
    return 0;
  }

  public void destroy() throws DfException {
  }

  public IDfType getType() throws DfException {
    return null;
  }

  public boolean isDirty() throws DfException {
    return false;
  }

  public boolean isNew() throws DfException {
    return false;
  }

  public void revert() throws DfException {
  }

  public void save() throws DfException {
  }

  public boolean apiSet(String s, String s1, String s2) throws DfException {
    return false;
  }

  public boolean apiExec(String s, String s1) throws DfException {
    return false;
  }

  public boolean fetch(String s) throws DfException {
    return false;
  }

  public boolean fetchWithCaching(String s, boolean b, boolean b1) throws DfException {
    return false;
  }

  public IDfRelation addChildRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public IDfRelation addParentRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public void removeChildRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public void removeParentRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public IDfCollection getChildRelatives(String s) throws DfException {
    return null;
  }

  public IDfCollection getParentRelatives(String s) throws DfException {
    return null;
  }

  public boolean isDeleted() throws DfException {
    return false;
  }

  public void signoff(String s, String s1, String s2) throws DfException {
  }

  public void validateAllRules(int i) throws DfException {
  }

  public void validateObjRules(int i) throws DfException {
  }

  public void validateAttrRules(String s, int i) throws DfException {
  }

  public void validateAttrRulesWithValue(String s, String s1, int i) throws DfException {
  }

  public void validateAttrRulesWithValues(String s, IDfList iDfList, int i) throws DfException {
  }

  public void validateObjRulesWithValues(IDfList iDfList, IDfList iDfList1, int i) throws DfException {
  }

  public IDfList getAttrAsstDependencies(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistance(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistanceWithValues(String s, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public String getWidgetType(int i, String s) throws DfException {
    return null;
  }

  public IDfValidator getValidator() throws DfException {
    return null;
  }

  public String getObjectName() throws DfException {
    return aclName;
    }

    public void setDescription(String string) throws DfException {
    }

    public String getDescription() throws DfException {
        return null;
    }

    public void setDomain(String string) throws DfException {
    }

    public String getDomain() throws DfException {
        return null;
    }

    public boolean isInternal() throws DfException {
        return false;
    }

    public int getAccessorCount() throws DfException {
        return 0;
    }

    public String getAccessorName(int i) throws DfException {
        return null;
    }

    public int getAccessorPermit(int i) throws DfException {
        return 0;
    }

    public int getAccessorPermitType(int i) throws DfException {
        return 0;
    }

    public int getAccessorXPermit(int i) throws DfException {
        return 0;
    }

    public boolean isGroup(int i) throws DfException {
        return false;
    }

    public boolean isGloballyManaged() throws DfException {
        return false;
    }

    public boolean hasPermission(String string, String string1) throws DfException {
        return false;
    }

    public String getAccessorXPermitNames(int i) throws DfException {
        return null;
    }

    public int getPermit(String string) throws DfException {
        return 0;
    }

    public int getXPermit(String string) throws DfException {
        return 0;
    }

    public String getXPermitNames(String string) throws DfException {
        return null;
    }

    public String getXPermitList() throws DfException {
        return null;
    }

    public void grant(String string, int i, String string1) throws DfException {
    }

    public void grantPermit(IDfPermit iDfPermit) throws DfException {
    }

    public void revoke(String string, String string1) throws DfException {
    }

    public void revokePermit(IDfPermit iDfPermit) throws DfException {
    }

    public IDfList getPermissions() throws DfException {
        return null;
    }

    public void destroyACL(boolean b) throws DfException {
    }

    public int getACLClass() throws DfException {
        return 0;
    }

    public void setACLClass(int i) throws DfException {
    }
}