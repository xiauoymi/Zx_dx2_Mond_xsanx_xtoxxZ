/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

/**
 * Filename:    $RCSfile: QueryUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 21:18:41 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class QueryUtils {

    public static IDfCollection execQuery(IDfSession sess, IDfQuery q, String queryString) {
        IDfCollection col = null; //For the result
        try {
            q.setDQL(queryString); //Give it the query
            col = q.execute(sess, DfQuery.DF_READ_QUERY); //Execute synchronously
        } catch (DfException dfe) {
            System.out.println("\n" + dfe.toString());
        }
        return col;
    }
}