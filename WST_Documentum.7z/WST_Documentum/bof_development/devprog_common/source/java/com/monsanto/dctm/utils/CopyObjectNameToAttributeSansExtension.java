/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

/**
 * Filename:    $RCSfile: CopyObjectNameToAttributeSansExtension.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 15:52:08 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class CopyObjectNameToAttributeSansExtension {
    private static IDfSession session;

    public static void main(String[] args) {
        if (validateArgs(args)) {
            execute(args);
        } else {
            exitWithUsageMessage();
        }
    }

    private static void exitWithUsageMessage() {
        System.err.println("Please enter the arguments.. Docbase Username Password ObjectType AttributeName");
        System.exit(1);
    }

    private static boolean validateArgs(String[] args) {
        return args.length == 5;
    }

    public static void execute(String[] args) {
        try {
            session = DFCSessionUtils.login(args[0], args[1], args[2], null);
            copyObjectNamesToAttribute(args[3], args[4]);
        } catch (Exception e) {
            DFCSessionUtils.displayError(e);
        } finally {
            DFCSessionUtils.logout();
        }
    }

    private static void copyObjectNamesToAttribute(String objectType, String attributeName) throws DfException {
        IDfCollection objects = null;
        try {
            objects = runQuery("select r_object_id from " + objectType);
            while (objects.next()) {
                IDfId objectId = objects.getId("r_object_id");
                IDfSysObject object = (IDfSysObject) session.getObject(objectId);
                copyObjectNameToAttribute(object, attributeName);
            }
        } finally {
            closeCollection(objects);
        }
    }

    private static void copyObjectNameToAttribute(IDfSysObject object, String attributeName) throws DfException {
        String objectName = object.getString("object_name");
        String contentType = object.getString("a_content_type");
        IDfFormat format = session.getFormat(contentType);
        String dosExtension = format.getDOSExtension();
        if (objectName.endsWith("." + dosExtension)) {
            objectName = objectName.substring(0, objectName.lastIndexOf("." + dosExtension));
        }
        System.out.println("objectName = " + objectName);
        object.setRepeatingString(attributeName, 0, objectName);
        object.save();
    }


    private static IDfCollection runQuery(String query) throws DfException {
        System.out.print(query);
        IDfQuery q = new DfQuery();
        q.setDQL(query);
        return q.execute(session, IDfQuery.DF_QUERY);
    }

    private static void closeCollection(IDfCollection coll) throws DfException {
        if (coll != null) {
            coll.close();
            System.out.println(" ...DONE!");
        }
    }

}