/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

/**
 * Filename:    $RCSfile: TestUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/04/18 18:10:41 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class TestUtils {

  public static boolean isObjectLinkedToFolder(IDfSysObject object, String folderName) throws DfException {
    int folderIdCount = object.getFolderIdCount();
    boolean objectIsLinked = false;
    for (int i = 0; !objectIsLinked && i < folderIdCount; i++) {
      String folderNameAtIndex = getFolderNameAtIndex(i, object.getSession(), object);
      objectIsLinked = folderName.equals(folderNameAtIndex);
    }
    return objectIsLinked;
  }

  public static String getFolderNameAtIndex(int index, IDfSession session, IDfSysObject object) throws DfException {
    return ((IDfFolder) session.getObject(object.getFolderId(index))).getRepeatingString("r_folder_path", 0);
  }

  public static boolean isVersionLabelAttached(IDfSysObject object, String versionLabel)
      throws DfException {
    IDfVersionLabels versionLabels = object.getVersionLabels();
    int versionLabelCount = versionLabels.getVersionLabelCount();
    boolean containsVersionLabel = false;
    for (int i = 0; !containsVersionLabel && i < versionLabelCount; i++) {
      String versionLabelAtIndex = versionLabels.getVersionLabel(i);
      containsVersionLabel = versionLabel.equals(versionLabelAtIndex);
    }
    return containsVersionLabel;
  }

  public static IDfSysObject checkoutCheckin(IDfSysObject object, IDfSession session) throws DfException {
    IDfSysObject newObject;
    object.checkout();
    IDfId newObjectId = object.checkin(false, "");
    newObject = (IDfSysObject) session.getObject(newObjectId);
    return newObject;
  }

  public static int getNumberOfVersions(IDfSysObject object) throws DfException {
    IDfCollection versions = null;
    int numOfVersions = 0;
    try {
      versions = object.getVersions(null);
      while (versions.next()) {
        numOfVersions++;
      }
    } finally {
      if (versions != null) {
        versions.close();
      }
    }
    return numOfVersions;
  }

  public static boolean isMarkedCurrent(IDfSysObject currentObject) throws DfException {
    return isVersionLabelAttached(currentObject, "CURRENT");
  }
}