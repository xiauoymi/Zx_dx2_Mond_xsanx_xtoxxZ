package com.monsanto.dctm.utils;
/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: ExecDQL.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 15:52:08 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class ExecDQL {
    private static IDfSession session;

    public static void main(String[] args) {
        if (validateArgs(args)) {
            execute(args);
        } else {
            exitWithUsageMessage();
        }
    }

    private static List parseQueryFile(String[] args) throws IOException {
        List queryList = new ArrayList();
        BufferedReader inputbr = new BufferedReader(new FileReader(args[3]));
        String str = null;
        while ((str = inputbr.readLine()) != null) {

            queryList.add(str);
        }
        inputbr.close();
        return queryList;
    }

    public static void exitWithUsageMessage() {
        System.err.println("Please enter the arguments.. Docbase Username Password Filename");
        System.exit(1);
    }

    public static boolean validateArgs(String[] args) {
        return args.length == 4;
    }

    public static void execute(String[] args) {
        try {
            session = DFCSessionUtils.login(args[0], args[1], args[2], null);
            List queryList = null;
            queryList = parseQueryFile(args);
            runQueries(queryList);
        } catch (Exception e) {
            DFCSessionUtils.displayError(e);
        } finally {
            DFCSessionUtils.logout();
        }
    }



    private static void runQueries(List queryList) throws DfException {
        Iterator queries = queryList.iterator();
        while (queries.hasNext()) {
            runQuery((String) queries.next());
        }

    }

    private static void runQuery(String query) throws DfException {
        System.out.print(query);
        IDfQuery q = new DfQuery();
        q.setDQL(query);
        IDfCollection coll = q.execute(session, IDfQuery.DF_QUERY);
        if (coll != null) {
            coll.close();
            System.out.println(" ...DONE!");
        }
    }

}