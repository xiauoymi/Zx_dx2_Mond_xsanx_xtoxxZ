/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;
import com.documentum.fc.common.IDfList;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockDfGroup.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:34:57 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockDfGroup extends MockPersistentObject implements IDfGroup {
    private List users = new ArrayList();
    private String groupName;
    private List results;

  public boolean isDeleted() throws DfException {
    return false;
  }

  public boolean apiExec(String s, String s1) throws DfException {
    return false;
  }

  public void destroy() throws DfException {
  }

  public void revert() throws DfException {
  }

  public boolean apiSet(String s, String s1, String s2) throws DfException {
    return false;
  }public void signoff(String s, String s1, String s2) throws DfException {
}

  public void validateAllRules(int i) throws DfException {
  }

  public void validateAttrRules(String s, int i) throws DfException {
  }

  public void validateObjRulesWithValues(IDfList iDfList, IDfList iDfList1, int i) throws DfException {
  }

  public boolean fetch(String s) throws DfException {
    return false;
  }

  public boolean isNew() throws DfException {
    return false;
  }

  public void save() throws DfException {
  }

  public IDfList getAttrAssistanceWithValues(String s, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public IDfList getAttrAssistance(String s) throws DfException {
    return null;
  }

  public IDfRelation addChildRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public IDfCollection getParentRelatives(String s) throws DfException {
    return null;
  }

  public void removeParentRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public boolean isDirty() throws DfException {
  return false;
}public IDfRelation addParentRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
  return null;
  }

  public String getWidgetType(int i, String s) throws DfException {
    return null;
  }

  public IDfCollection getChildRelatives(String s) throws DfException {
    return null;
  }

  public IDfType getType() throws DfException {
    return null;
  }

  public void removeChildRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public void validateAttrRulesWithValues(String s, IDfList iDfList, int i) throws DfException {
  }

  public void validateAttrRulesWithValue(String s, String s1, int i) throws DfException {
  }

  public int getVStamp() throws DfException {
    return 0;
  }

  public IDfValidator getValidator() throws DfException {
    return null;
  }


  public boolean isReplica() throws DfException {
    return false;
  }

  public void validateObjRules(int i) throws DfException {
  }

  public boolean fetchWithCaching(String s, boolean b, boolean b1) throws DfException {
    return false;
  }

  public IDfList getAttrAsstDependencies(String s) throws DfException {
    return null;
  }

  public String getOwnerName() throws DfException {
        return null;
    }

    public String getGroupName() throws DfException {
        return groupName;
    }

    public String getGroupAddress() throws DfException {
        return null;
    }

    public String getUsersNames(int i) throws DfException {
        return null;
    }

    public int getUsersNamesCount() throws DfException {
        return 0;
    }

    public String getGroupsNames(int i) throws DfException {
        return null;
    }

    public int getGroupsNamesCount() throws DfException {
        return 0;
    }

    public boolean isPrivate() throws DfException {
        return false;
    }

    public String getDescription() throws DfException {
        return null;
    }

    public String getAllUsersNames(int i) throws DfException {
        return null;
    }

    public int getAllUsersNamesCount() throws DfException {
        return users.size();
    }

    public boolean isGloballyManaged() throws DfException {
        return false;
    }

    public IDfTime getModifyDate() throws DfException {
        return null;
    }

    public IDfId getAliasSetId() throws DfException {
        return null;
    }

    public void setAliasSetId(IDfId iDfId) throws DfException {
    }

    public boolean isUserInGroup(String user) throws DfException {
        return users.contains(user);
    }

    public boolean isGroupInGroup(String attrName) throws DfException {
        return false;
    }

    public void renameGroup(String attrName, boolean b, boolean b1, boolean b2) throws DfException {
    }

    public void setGroupName(String groupName) throws DfException {
        this.groupName = groupName;
    }

    public void setGroupAddress(String attrName) throws DfException {
    }

    public void setDescription(String attrName) throws DfException {
    }

    public void setPrivate(boolean b) throws DfException {
    }

    public void setOwnerName(String attrName) throws DfException {
    }

    public void setGloballyManaged(boolean b) throws DfException {
    }

    public boolean addUser(String user) throws DfException {
        if (users.contains(user)) {
            return false;
        } else {
            users.add(user);
            return true;
        }
    }

    public boolean addGroup(String attrName) throws DfException {
        return false;
    }

    public boolean removeUser(String user) throws DfException {
        if (users.contains(user)) {
            users.remove(user);
            return true;
        } else {
            return false;
        }
    }

    public boolean removeGroup(String attrName) throws DfException {
        return false;
    }

    public void removeAllUsers() throws DfException {
        users.clear();
    }

    public void removeAllGroups() throws DfException {
    }

    public IDfCollection getUsersNames() throws DfException {
      IDfCollection collection = new MockDfCollection(true, results);
      return collection;
    }

    public IDfCollection getGroupsNames() throws DfException {
        return null;
    }

    public void setGroupClass(String attrName) throws DfException {
    }

    public String getGroupClass() throws DfException {
        return null;
    }

    public void setGroupAdmin(String attrName) throws DfException {
    }

    public String getGroupAdmin() throws DfException {
        return null;
    }

    public void setDynamic(boolean b) throws DfException {
    }

    public boolean getDynamic() throws DfException {
        return false;
    }

    public void setDynamicDefault(boolean b) throws DfException {
    }

    public boolean getDynamicDefault() throws DfException {
        return false;
    }

    public String getGroupDisplayName() throws DfException {
        return null;
    }

    public void setGroupDisplayName(String attrName) throws DfException {
    }

    public IDfId getGroupNativeRoomId() throws DfException {
        return null;
    }

    public void setGroupNativeRoomId(IDfId iDfId) throws DfException {
    }


   public List setResults(List results){
    this.results = results;
    return results;
  }
}