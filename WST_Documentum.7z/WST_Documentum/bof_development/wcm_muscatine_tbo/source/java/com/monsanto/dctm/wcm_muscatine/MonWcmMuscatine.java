/*
 * Created on Jul 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.wcm_muscatine;

import com.documentum.fc.client.DfDocument;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;

/**
 * @author lakench
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MonWcmMuscatine extends DfDocument implements IMonWcmMuscatine, IDfDynamicInheritance {

	/* (non-Javadoc)
	 * @see com.documentum.fc.client.IDfBusinessObject#getVersion()
	 */
    public String getVendorString()
    {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    public String getVersion()
    {
        return "1.0";
    }

    public boolean isCompatible(String str)
    {
        return str.equals("1.0");
    }

    public boolean supportsFeature(String str)
    {
        String strFeatures = "";
        return strFeatures.indexOf(str) != -1;
    }
    
	public IDfId checkinEx(boolean arg0, String arg1, String arg2, String arg3,
			String arg4, String arg5) throws DfException
	{
		IDfId newObjId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
		getObject(newObjId).save();
		return newObjId;
	}
	
	public void save() throws DfException {
		super.save();
		queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
	}
}
