/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mon_docs.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.attachlifecycle.test.MockMonAttachLifecycleService;
import com.monsanto.dctm.mon_docs.IMonMonDocs;
import com.monsanto.dctm.mon_docs.MonMonDocs;
import com.monsanto.dctm.test.MockDfDocument;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockMonMonDocs.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date:
 * 2008/01/03 21:07:11 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockMonMonDocs extends MonMonDocs implements IMonMonDocs {
  private MockDfDocument mock;

  public void attachPolicy(IDfId iDfId, String s, String s1) throws DfException {
    mock.attachPolicy(iDfId, s, s1);
  }public String getTypeName() throws DfException {
  return "mon_docs";
}

  public void setSession(IDfSession session) {
      mock.setSession(session);
    }
   public IDfSession getSession() {
        return mock.getSession();
    }

  public void save() throws DfException {
   mock.save();
  }

  public IDfId getPolicyId() throws DfException {
    return mock.getPolicyId();
  }

  public String getString(String s) throws DfException {
    return mock.getString(s);
  }

  public MockMonMonDocs() {
    this(new MockDfDocument());
  }

  public MockMonMonDocs(MockDfDocument mockDfDocument) {
    mock = mockDfDocument;
  }
  public void setString(String attrName, String value) throws DfException {
       mock.setString(attrName, value);
    }

  public IMonAttachLifecycleService getAttachLifecycleService() throws DfException {
    ArrayList typesThatUseScopes = new ArrayList();
    typesThatUseScopes.add("pmf_doc_luling");


    return new MockMonAttachLifecycleService(typesThatUseScopes);
  }


  public void applyLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws
      DfServiceException, DfException {
    IMonAttachLifecycleService attachLifecycleService = getAttachLifecycleService();
    System.out.println("mockscope = " + scope);
    attachLifecycleService.attachLifecycle(sourceObject, lifecycleName, stateName, scope);


  }

  public String getVersion() {
    return null;
  }

  public String getVendorString() {
    return null;
  }

  public boolean isCompatible(String s) {
    return false;
  }

  public boolean supportsFeature(String s) {
    return false;
  }
}