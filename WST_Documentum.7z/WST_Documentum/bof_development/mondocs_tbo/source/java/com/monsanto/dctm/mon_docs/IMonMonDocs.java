/*
 * Created on Jul 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.mon_docs;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;

/**
 * @author lakench
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IMonMonDocs extends IDfBusinessObject, IDfSysObject {

  void applyLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws
      DfServiceException, DfException;
}
