/*
 * Created on Jul 28, 2005
 *
 */
package com.monsanto.dctm.mon_docs;

import com.documentum.devprog.autonaming.DpAutoNamingServiceException;
import com.documentum.devprog.autonaming.IDpAutoNamingService;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.mapattributes.AttributeMapException;
import com.monsanto.dctm.mapattributes.IMapAttributes;
import com.monsanto.dctm.watermark.IMonWatermarkService;
//import com.monsanto.dctm.requestPDFRendition.IMonRequestPDFRenditionService;

/**
 * @author lakench
 */
public class MonMonDocs extends DfDocument implements IMonMonDocs, IDfDynamicInheritance {
    protected boolean m_newFlag = false;
    protected boolean m_hasSaveBeenCalled = false;
    protected boolean m_setUniqueName = false;

    /* (non-Javadoc)
    * @see com.documentum.fc.client.IDfBusinessObject#getVersion()
    */
    public String getVendorString() {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean isCompatible(String str) {
        return str.equals("1.0");
    }

    public boolean supportsFeature(String str) {
        String strFeatures = "";
        return strFeatures.indexOf(str) != -1;
    }

    protected void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {
      System.out.println("MonMonDocs.doSave");
        boolean isImported = !saveLock && isNew();
        super.doSave(saveLock, versionLabel, extendedArgs);
        if (isImported) mapAttributes();
        applyLifecycle(this, null, null, null);
        //createPDFRendition();
    }

    private void mapAttributes() throws DfException {
        IDfSessionManager sessMgr = getSession().getSessionManager();
        IMapAttributes mapAttributesService = (IMapAttributes) DfClient.getLocalClient()
                .newService(IMapAttributes.class.getName(), sessMgr);
        try {
            mapAttributesService.mapAttributes(getSession().getDocbaseName(), this);
        } catch (AttributeMapException e) {
            e.printStackTrace();
        }
    }

    public void saveLock() throws DfException {
        if (!m_newFlag) {
            m_hasSaveBeenCalled = true;
            m_newFlag = !(getValue("r_creator_name").asString() != null &&
                          getValue("r_creator_name").asString().length() > 0);

            for (int i = 0; i < getVersionLabelCount(); i++) {
                if (getVersionLabel(i).equals("_NEW_")) {
                    m_newFlag = true;
                }
            }
        }
        setUniqueName();


        super.saveLock();


    }

    public IDfId checkinEx(boolean arg0, String arg1, String arg2, String arg3, String arg4, String arg5) throws
                                                                                                          DfException {
        if (!m_newFlag) {
            m_hasSaveBeenCalled = true;
            m_newFlag = !(getValue("r_creator_name").asString() != null &&
                          getValue("r_creator_name").asString().length() > 0);

            for (int i = 0; i < getVersionLabelCount(); i++) {
                if (getVersionLabel(i).equals("_NEW_")) {
                    m_newFlag = true;
                }
            }
        }

        setUniqueName();


        IDfId newObjectId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);


      applyLifecycle(this, null, null, null);
      //createPDFRendition();

        return newObjectId;
    }

    public void save() throws DfException {

        setUniqueName();


        if (!m_newFlag) {
            m_hasSaveBeenCalled = true;
            m_newFlag = !(getValue("r_creator_name").asString() != null &&
                          getValue("r_creator_name").asString().length() > 0);

            for (int i = 0; i < getVersionLabelCount(); i++) {
                if (getVersionLabel(i).equals("_NEW_")) {
                    m_newFlag = true;
                }
            }
        }

        super.save();
    }

    public void applyLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws
        DfException {

        IMonAttachLifecycleService attachLifecycleService = getAttachLifecycleService();
      System.out.println("scope = " + scope);
        attachLifecycleService.attachLifecycle(sourceObject, lifecycleName, stateName, scope);
    }

    protected IMonAttachLifecycleService getAttachLifecycleService() throws DfException {
        IDfSessionManager sessMgr = getSession().getSessionManager();
        return (IMonAttachLifecycleService) DfClient.getLocalClient()
                .newService(IMonAttachLifecycleService.class.getName(), sessMgr);
    }
  /*protected void createPDFRendition() throws DfServiceException, DfException {
    IMonRequestPDFRenditionService requestPDFRenditionService = getRequestPDFRenditonService();
    requestPDFRenditionService.requestPDFRendition(this);

  }

  protected IMonRequestPDFRenditionService getRequestPDFRenditonService() throws DfException {
    IDfSessionManager sessMgr = getSession().getSessionManager();
    return(IMonRequestPDFRenditionService) DfClient.getLocalClient()
        .newService(IMonRequestPDFRenditionService.class.getName(),sessMgr);
  }*/

    protected void setUniqueName() {
        if (m_newFlag && !m_setUniqueName) {
            IDfSessionManager sessMgr = getSession().getSessionManager();

            try {
                IDpAutoNamingService autoNamingService = (IDpAutoNamingService) DfClient.getLocalClient()
                        .newService(IDpAutoNamingService.class.getName(), sessMgr);

                String uniqueName = autoNamingService
                        .getUniqueName(getSession().getDocbaseName(), "useAutonumberObjectsRule",
                                       getObjectId().getId());
                if (uniqueName != null) {
                    setObjectName(uniqueName);
                    m_setUniqueName = true;
                }
            }
            catch (DfException e) {
                e.printStackTrace();
            }
            catch (DpAutoNamingServiceException e) {
                e.printStackTrace();
            }
        }
    }

   public String getFileEx2(String fileName, String formatName, int pageNumber, String pageModifier,
                             boolean getResource) throws DfException {
     String fileLocation = super.getFileEx2(fileName, formatName, pageNumber, pageModifier, getResource);

      IMonWatermarkService watermarkService = (IMonWatermarkService) DfClient.getLocalClient()
                .newService(IMonWatermarkService.class.getName(), getSession().getSessionManager());

        try {
            if (watermarkService.isTypeWatermarked(this.getTypeName())) {
                watermarkService.addWatermark(fileLocation, formatName, this);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }

        return fileLocation;
    }
    }
//    System.out.println("viewedDirectory = " + viewedDirectory);
//    IDfList viewedObjects = registry.getViewedObjects();
//    System.out.println("viewedObjects.getCount() = " + viewedObjects.getCount());
//    for(int i =0; i< viewedObjects.getCount(); i++)
//    {
//      IDfViewedObject viewedObject = (IDfViewedObject) viewedObjects.get(i);
//            registry.removeViewedObject( viewedObject);
//      String viewedobjpath = viewedObject.getFilePath();
//      System.out.println("viewedobjpath = " + viewedobjpath);
//      System.out.println("i:viewedObject.getObjectName("+i+") = " + viewedObject.getObjectName());
//      viewedObject.updateRegistry();
//
//    }

//  }
//}
