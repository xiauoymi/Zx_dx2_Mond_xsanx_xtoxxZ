/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.nst_docs.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.nst_docs.INstDocs;
import com.monsanto.dctm.test.TestUtils;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Filename:    $RCSfile: NstDocs_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:37:15 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class NstDocs_AT extends TestCase {
    public HashMap stateToAclMap;
  private static final String testdocbase = "stltst03";
  private static final String testuserid = "lakench";
  private static final String testpw = "G1ng3r";

  protected void setUp() throws Exception {
        super.setUp();
        stateToAclMap = new HashMap();
        stateToAclMap.put("Work In Progress", "nst_workinprogress");
        stateToAclMap.put("Under Review", "nst_wf_user_write");
        stateToAclMap.put("Under Approval", "nst_wf_user_write");
        stateToAclMap.put("Approved", "nst_approved");

    }

    public void testCreate() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        INstDocs object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (INstDocs) session.newObject("nst_docs");

            assertNotNull(object);
            assertEquals("Copyright(c) Monsanto Corp., 2005", object.getVendorString());
            assertEquals("1.0", object.getVersion());
            assertTrue(object.isCompatible("1.0"));
            assertFalse(object.isCompatible("2.0"));
            assertFalse(object.supportsFeature(null));
            assertFalse(object.supportsFeature("anything"));
        } finally {
            if (object != null) {
                ((IDfSysObject) object).destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testCheckin() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase,testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("nst_docs");
            object.save();

            newObject = TestUtils.checkoutCheckin(object, session);

            assertEquals("Network Service Lifecycle", object.getPolicyName());
            assertLifecycleState(object, "Work In Progress");
            assertEquals("Network Service Lifecycle", newObject.getPolicyName());
            assertLifecycleState(newObject, "Work In Progress");
        } finally {
            if (object != null) {
                object.destroyAllVersions();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testCheckinApprovedVersion() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject = null;
        IDfSessionManager anotherSessionManager = DFCSessionUtils
                .createSessionManager(testdocbase, "devl29", "devl29");
        IDfSession anotherSession = null;
        IDfSysObject anotherNewObject = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("nst_docs");
            object.save();
            newObject = TestUtils.checkoutCheckin(object, session);
            newObject.promote(null, false, false);
            assertLifecycleState(newObject, "Under Review");
            newObject.promote(null, false, false);
            assertLifecycleState(newObject, "Under Approval");
            newObject.promote(null, false, false);

            assertLifecycleState(newObject, "Approved");
            anotherSession = anotherSessionManager.getSession(testdocbase);
            anotherNewObject = (IDfSysObject) anotherSession.getObject(newObject.getObjectId());

            anotherNewObject = TestUtils.checkoutCheckin(anotherNewObject, anotherSession);

            assertEquals("Network Service Lifecycle", anotherNewObject.getPolicyName());
            assertEquals("devl29", anotherNewObject.getOwnerName());
            assertLifecycleState(anotherNewObject, "Work In Progress");

        } finally {
            if (object != null) {
                object.destroyAllVersions();
            }
            if (session != null) {
                sessionManager.release(session);
            }
            if (anotherSession != null) {
                anotherSessionManager.release(anotherSession);
            }
        }
    }

    public void testSaveLockApprovedVersion() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase,testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject = null;
        IDfSessionManager anotherSessionManager = DFCSessionUtils
                .createSessionManager(testdocbase, "devl29", "devl29");
        IDfSession anotherSession = null;
        IDfSysObject anotherNewObject = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("nst_docs");
            object.save();
            newObject = TestUtils.checkoutCheckin(object, session);
            newObject.promote(null, false, false);
            assertLifecycleState(newObject, "Under Review");
            newObject.promote(null, false, false);
            assertLifecycleState(newObject, "Under Approval");
            newObject.promote(null, false, false);

            assertLifecycleState(newObject, "Approved");
            anotherSession = anotherSessionManager.getSession(testdocbase);
            anotherNewObject = (IDfSysObject) anotherSession.getObject(newObject.getObjectId());
            anotherNewObject.saveLock();

            assertEquals("Network Service Lifecycle", anotherNewObject.getPolicyName());
            assertEquals("devl29", anotherNewObject.getOwnerName());
            assertLifecycleState(anotherNewObject, "Work In Progress");

        } finally {
            if (object != null) {
                object.destroyAllVersions();
            }
            if (session != null) {
                sessionManager.release(session);
            }
            if (anotherSession != null) {
                anotherSessionManager.release(anotherSession);
            }
        }
    }

    public void testGetListOfVersionIds() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject = null;
        try {
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("nst_docs");
            object.save();
            newObject = TestUtils.checkoutCheckin(object, session);
            List expectedVersions = new ArrayList();
            expectedVersions.add(object.getObjectId().getId());
            expectedVersions.add(newObject.getObjectId().getId());
            List actualVersions = ((INstDocs) object).getListOfVersionIds();
            assertTrue(actualVersions.containsAll(expectedVersions));
        } finally {
            if (object != null) {
                object.destroyAllVersions();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }

    }

    private void assertLifecycleState(IDfSysObject object, String stateName) throws DfException {
        assertEquals(stateName, object.getCurrentStateName());
        assertEquals(stateName, object.getString("nst_doc_status"));
        assertEquals((String) stateToAclMap.get(stateName), object.getACLName());
    }
}