/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.nst_docs;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.mon_docs.MonMonDocs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: NstDocs.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-20 04:34:42 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class NstDocs extends MonMonDocs implements IDfDynamicInheritance, INstDocs {

    /**
     * @noinspection RefusedBequest
     */
    public String getVersion() {
        return "1.0";
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getVendorString() {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean isCompatible(String version) {
        return version.equals(getVersion());
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean supportsFeature(String feature) {
        return false;
    }

    public void updateOwnerAndDemote() throws DfException {
        setOwnerName(getSession().getLoginUserName());
        save();
        demote("Work In Progress", true);
    }

    protected IDfId doCheckin(boolean b, String attrName, String attrName1, String attrName2, String attrName3, String attrName4, Object[] objects) throws
                                                                                                                                                    DfException {
        IDfId newId = super.doCheckin(b, attrName, attrName1, attrName2, attrName3, attrName4, objects);
        if (getCurrentStateName().equals("Approved")) {
            getLatestVersion().updateOwnerAndDemote();
        }
        return newId;
    }

    protected void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {
        super.doSave(saveLock, versionLabel, extendedArgs);
        if (saveLock) {
            if (getCurrentStateName().equals("Approved")) {
                getLatestVersion().updateOwnerAndDemote();
            }
        }
    }

    protected INstDocs getLatestVersion() throws DfException {
        INstDocs latestVersion = null;
        Iterator versionIds = getListOfVersionIds().iterator();
        while (versionIds.hasNext()) {
            String versionId = (String) versionIds.next();
            IDfSysObject version = (IDfSysObject) getSession().getObject(new DfId(versionId));
            if (version.getLatestFlag()) {
                latestVersion = (INstDocs) version;
                break;
            }
        }
        return latestVersion;
    }

    public List getListOfVersionIds() throws DfException {
        IDfCollection versionsCollection = null;
        List versions = new ArrayList();
        try {
            versionsCollection = getVersions(null);
            while (versionsCollection.next()) {
                String versionId = versionsCollection.getString("r_object_id");
                versions.add(versionId);
            }
        } finally {
            if (versionsCollection != null) {
                versionsCollection.close();
            }
        }
        return versions;
    }
}