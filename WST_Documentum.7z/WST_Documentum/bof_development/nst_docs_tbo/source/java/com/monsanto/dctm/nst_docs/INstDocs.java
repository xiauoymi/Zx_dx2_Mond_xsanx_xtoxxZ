/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.nst_docs;

import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.common.DfException;

import java.util.List;

/**
 * Filename:    $RCSfile: INstDocs.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-20 04:34:42 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public interface INstDocs extends IDfBusinessObject {
    public void updateOwnerAndDemote() throws DfException;

    public List getListOfVersionIds() throws DfException;
}