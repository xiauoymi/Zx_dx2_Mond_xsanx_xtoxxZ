/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.nst_docs.test;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.attachlifecycle.test.AttachLifecycleTestUtils;
import com.monsanto.dctm.nst_docs.NstDocs;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: NstDocs_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-20 04:34:42 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class NstDocs_UT extends TestCase {
    public MockSession mockSession;

    public void testCreate() throws Exception {
        NstDocs object = new NstDocs();
        assertNotNull(object);

    }

    public void testLifecycleAttached() throws Exception {
        MockNstDocs mock = createMockNstDocsObject();
        assertEquals("Network Service Lifecycle", mock.getPolicyName());
        assertLifecycleState(mock, "Work In Progress");
    }

    public void testPromotes() throws Exception {
        MockNstDocs mock = createMockNstDocsObject();
        assertEquals("Network Service Lifecycle", mock.getPolicyName());
        assertLifecycleState(mock, "Work In Progress");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Under Review");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Under Approval");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Approved");
    }

    public void testUpdateOwnerAndDemote() throws Exception {
        MockNstDocs mock = createMockNstDocsObject();
        assertEquals("Network Service Lifecycle", mock.getPolicyName());
        assertLifecycleState(mock, "Work In Progress");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Under Review");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Under Approval");
        mock.promote(null, false, false);
        assertLifecycleState(mock, "Approved");
        mockSession.setLoginUserName("devl29");
        mock.updateOwnerAndDemote();

        assertTrue(mock.saveCalled);
        assertEquals("Network Service Lifecycle", mock.getPolicyName());
        assertEquals("devl29", mock.getOwnerName());
        AttachLifecycleTestUtils.assertLifecycleState(mock, "Work In Progress", mock.stateToAclMap);
    }

    public void testGetListOfVersionIds() throws Exception {
        MockNstDocs mock = createMockNstDocsObjectWithMultipleVersions();
        List versions = mock.getListOfVersionIds();
        assertTrue(versions.containsAll(mock.versions.keySet()));

    }

    public void testFindLatestVersion() throws Exception {
        MockNstDocs mock = createMockNstDocsObjectWithMultipleVersions();
        IDfSysObject latestVersion = (IDfSysObject) mock.getLatestVersion();
        assertEquals(mock.latestVersionId, latestVersion.getObjectId().getId());
    }

    private MockNstDocs createMockNstDocsObjectWithMultipleVersions() throws DfException {
        MockNstDocs mock = createMockNstDocsObject();
        mock.addVersion("objectid2", "2.0");
        return mock;
    }

    private void assertLifecycleState(MockNstDocs mock, String stateName) throws DfException {
        AttachLifecycleTestUtils.assertLifecycleState(mock, stateName, mock.stateToAclMap);
    }

    private MockNstDocs createMockNstDocsObject() throws DfException {
        mockSession = AttachLifecycleTestUtils.createMockSessionWithMockNstDocsLifecycle();
        MockNstDocs mock = new MockNstDocs(mockSession, "objectid1", "1.0");
        mock.setSession(mockSession);
        return mock;
    }
}