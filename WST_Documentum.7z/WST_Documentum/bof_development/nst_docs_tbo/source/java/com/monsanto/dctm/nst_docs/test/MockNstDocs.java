/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.nst_docs.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.mon_docs.test.MockMonMonDocs;
import com.monsanto.dctm.nst_docs.INstDocs;
import com.monsanto.dctm.nst_docs.NstDocs;

import java.util.*;

/**
 * Filename:    $RCSfile: MockNstDocs.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:37:15 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MockNstDocs extends NstDocs {
    private MockMonMonDocs mock;
    public String lifecycleScope;
    public HashMap stateToAclMap;
    public boolean saveCalled = false;
    public Map versions = new HashMap();
    public List versionsList = new ArrayList();
    public String latestVersionId;

    public MockNstDocs() {
        this(new MockMonMonDocs());
        stateToAclMap = new HashMap();
        stateToAclMap.put("Work In Progress", "nst_workinprogress");
        stateToAclMap.put("Under Review", "nst_wf_user_write");
        stateToAclMap.put("Under Approval", "nst_wf_user_write");
        stateToAclMap.put("Approved", "nst_approved");
    }

    public MockNstDocs(IDfSession session, String objectId, String versionNumber) throws DfException {
        this();
        setSession(session);
        setString("r_object_id", objectId);
        versions.put(objectId, versionNumber);
        latestVersionId = objectId;
        try {
            getAttachLifecycleService().attachLifecycle(this, "Network Service Lifecycle", "Work In Progress",
                "testscope");
        } catch (DfException e) {
            e.printStackTrace();
        }
    }

    public MockNstDocs(MockMonMonDocs mockMonMonDocs) {
        mock = mockMonMonDocs;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected IMonAttachLifecycleService getAttachLifecycleService() throws DfException {
        return mock.getAttachLifecycleService();
    }

    public void applyLifecycle(DfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws DfServiceException, DfException {
        super.applyLifecycle(this, null, null, null);
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getString(String attrName) throws DfException {
        return mock.getString(attrName);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void setString(String attrName, String value) throws DfException {
        mock.setString(attrName, value);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void attachPolicy(IDfId iDfId, String stateName, String scope) throws DfException {
        mock.attachPolicy(iDfId, stateName, scope);
        lifecycleScope = scope;
        setString("nst_doc_status", stateName);
        setString("acl_name", (String) stateToAclMap.get(stateName));
    }

    /**
     * @noinspection RefusedBequest
     */
    public void promote(String state, boolean override, boolean fTestOnly) throws DfException {
        mock.promote(state, override, fTestOnly);
        setString("nst_doc_status", getCurrentStateName());
        setString("acl_name", (String) stateToAclMap.get(getCurrentStateName()));
    }

    /**
     * @noinspection RefusedBequest
     */
    public void demote(String attrName, boolean b) throws DfException {
        mock.demote(attrName, b);
        setString("nst_doc_status", getCurrentStateName());
        setString("acl_name", (String) stateToAclMap.get(getCurrentStateName()));
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfId getPolicyId() throws DfException {
        return mock.getPolicyId();
    }

    protected String getCurrentDocbase() throws DfException {
        return "test_docbase";
    }

    /**
     * @noinspection RefusedBequest
     */
    public void setSession(IDfSession session) {
        mock.setSession(session);
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfSession getSession() {
        return mock.getSession();
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getNextStateName() throws DfException {
        return mock.getNextStateName();
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getCurrentStateName() throws DfException {
        return mock.getCurrentStateName();
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getPreviousStateName() throws DfException {
        return mock.getPreviousStateName();
    }

    /**
     * @noinspection RefusedBequest
     */
    public void save() throws DfException {
        saveCalled = true;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected INstDocs getLatestVersion() throws DfException {
        return (INstDocs) getSession().getObject(new DfId(latestVersionId));
    }

    /**
     * @noinspection RefusedBequest
     */
    public List getListOfVersionIds() throws DfException {
        Iterator versionIds = versions.keySet().iterator();
        List versionIdsList = new ArrayList();
        while (versionIds.hasNext()) {
            versionIdsList.add(versionIds.next());
        }
        return versionIdsList;
    }

    /**
     * @noinspection RefusedBequest
     */
    public synchronized void setSessionManager(IDfSessionManager sessionManager) throws DfException {
        mock.setSessionManager(sessionManager);
    }

    public void addVersion(String newVersionId, String newVersionNumber) throws DfException {
        versions.put(newVersionId, newVersionNumber);
        latestVersionId = newVersionId;
        MockNstDocs newObject = new MockNstDocs(getSession(), newVersionId, newVersionNumber);
        ((MockSession) getSession()).addObject(newObject, newVersionId);
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfId getObjectId() throws DfException {
        return mock.getObjectId();
    }
}