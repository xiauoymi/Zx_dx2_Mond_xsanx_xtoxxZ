/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.agtech;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.mon_docs.MonMonDocs;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Filename:    $RCSfile: AgTechBPD.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-20 04:34:42 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AgTechBPD extends MonMonDocs implements IAgTechBPD, IDfDynamicInheritance {
    /**
     * @noinspection RefusedBequest
     */
    public String getVendorString() {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getVersion() {
        return "1.0";
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean isCompatible(String str) {
        return str.equals("1.0");
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean supportsFeature(String str) {
        return false;
    }

    protected IDfId doCheckin(boolean fRetainLock, String versionLabels, String oldCompoundArchValue, String oldSpecialAppValue, String newCompoundArchValue, String newSpecialAppValue, Object[] extendedArgs) throws
                                                                                                                                                                                                                DfException {
        IDfId newObjectId = super.doCheckin(fRetainLock, versionLabels, oldCompoundArchValue, oldSpecialAppValue,
                                            newCompoundArchValue, newSpecialAppValue, extendedArgs);
        getSession().getObject(newObjectId).save();
        IDfSysObject previousApprovedVersion = getPreviousApprovedVersion();
        if (previousApprovedVersion != null) {
            previousApprovedVersion.mark("CURRENT");
            previousApprovedVersion.save();
        }

        return newObjectId;
    }

    private IDfSysObject getPreviousApprovedVersion() throws DfException {
        IDfSysObject version = null;
        IDfCollection versions = null;
        try {
            boolean approvedVersionFound = false;
            versions = getVersions(null);
            if (versions != null) {
                while (versions.next()) {
                    version = (IDfSysObject) getSession().getObject(versions.getId("r_object_id"));
                    if (version.getCurrentStateName().equals("Approved")) {
                        approvedVersionFound = true;
                        break;
                    }
                }
            }
            if (!approvedVersionFound) {
                version = null;
            }
        } finally {
            if (versions != null) {
                versions.close();
            }
        }
        return version;
    }


    protected void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {
        super.doSave(saveLock, versionLabel, extendedArgs);
        if (getCurrentStateName() != null) mark(getCurrentStateName());
        super.doSave(saveLock, versionLabel, extendedArgs);
    }

    protected void doPromote(String state, boolean override, boolean fTestOnly, Object[] extendedArgs) throws
                                                                                                       DfException {
        IDfId chronicleId = getChronicleId();
        super.doPromote(state, override, fTestOnly, extendedArgs);
        IDfSysObject currentObject = getCurrentVersionAfterAgTechBPDPromote(
                (IDfSysObject) getSession().getObject(chronicleId),
                getSession());
        if (currentObject.getCurrentStateName() != null) currentObject.mark(currentObject.getCurrentStateName());
        currentObject.save();
    }

    private IDfSysObject getCurrentVersionAfterAgTechBPDPromote(IDfSysObject object, IDfSession session) throws
                                                                                                         DfException {
        IDfCollection versions = null;
        IDfSysObject currentObject;
        try {
            versions = object.getVersions(null);
            Map versionLabelToObject = new HashMap();
            while (versions.next()) {
                IDfId objectId = new DfId(versions.getString("r_object_id"));
                IDfSysObject version = (IDfSysObject) session.getObject(objectId);
                Iterator versionLabels = Arrays
                        .asList(version.getAllRepeatingStrings("r_version_label", ",").split(",")).iterator();
                while (versionLabels.hasNext()) {
                    String versionLabel = (String) versionLabels.next();
                    versionLabelToObject.put(versionLabel, version);
                }
            }
            currentObject = (IDfSysObject) versionLabelToObject.get("CURRENT");
        } finally {
            if (versions != null) {
                versions.close();
            }
        }
        return currentObject;
    }
}