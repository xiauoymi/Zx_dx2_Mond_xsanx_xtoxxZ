/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.agtech.test;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.agtech.IAgTechBPD;
import com.monsanto.dctm.test.TestUtils;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Filename:    $RCSfile: AgTechBPD_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date:
 * 2007/04/18 18:10:41 $
 *
 * @author lakench
 * @version $Revision: 1.7 $
 */
public class AgTechBPD_AT extends TestCase {
  private static final String testdocbase = "stltst03";
  private static final String testuserid = "lakench";
  private static final String testpw = "G1ng3r";

  public void testCreate() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = (IDfSysObject) session.newObject("ag_tech_best_practice");
      object.setString("crop", "Cotton");
      object.save();

      assertNotNull(object);
      assertEquals("Copyright(c) Monsanto Corp., 2005", ((IAgTechBPD) object).getVendorString());
      assertEquals("1.0", ((IAgTechBPD) object).getVersion());
      assertTrue(((IAgTechBPD) object).isCompatible("1.0"));
      assertFalse(((IAgTechBPD) object).isCompatible("2.0"));
      assertFalse(((IAgTechBPD) object).supportsFeature(null));
      assertFalse(((IAgTechBPD) object).supportsFeature("anything"));
      assertEquals("Ag_Tech_BPD_LC", object.getPolicyName());
      assertEquals("Draft", object.getCurrentStateName());
      assertTrue(
          TestUtils.isObjectLinkedToFolder(object, "/Ag Technology Best Practices/Cotton/Draft"));
      assertFalse(TestUtils.isObjectLinkedToFolder(object,
          "/Ag Technology Best Practices/Cotton/Approved"));
      assertEquals("Draft", object.getString("a_status"));
      assertEquals("bpd_cot_draft", object.getACLName());
      assertTrue(TestUtils.isVersionLabelAttached(object, "Draft"));
    } finally {
      if (object != null) {
        object.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testCheckin() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    IDfSysObject newObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);

      newObject = TestUtils.checkoutCheckin(object, session);

      assertFalse(TestUtils.isMarkedCurrent(object));
      assertTrue(TestUtils.isObjectLinkedToFolder(object, "/Ag Technology Best Practices/Cotton/Draft"));
      assertTrue(TestUtils.isObjectLinkedToFolder(newObject, "/Ag Technology Best Practices/Cotton/Draft"));
      assertTrue(TestUtils.isMarkedCurrent(newObject));
      assertTrue(TestUtils.isVersionLabelAttached(newObject, "Draft"));
    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testApproveMajorVersionDocument() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);

      object.promote(null, false, false);
      IDfSysObject currentObject = getCurrentVersionAfterAgTechBPDPromote(object, session);

      assertEquals("Approved", currentObject.getCurrentStateName());
      assertTrue(
          TestUtils.isObjectLinkedToFolder(currentObject, "/Ag Technology Best Practices/Cotton/Approved"));
      assertEquals("bpd_cot_approved", currentObject.getACLName());
      assertTrue(TestUtils.isMarkedCurrent(currentObject));
      assertTrue(TestUtils.isVersionLabelAttached(currentObject, "1.0"));
      assertTrue(TestUtils.isVersionLabelAttached(currentObject, "Approved"));

    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testApproveMinorVersionDocument() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    IDfSysObject newObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);

      newObject = TestUtils.checkoutCheckin(object, session);

      newObject.promote(null, false, false);
      assertEquals(2, TestUtils.getNumberOfVersions(object));

      IDfSysObject currentObject = getCurrentVersionAfterAgTechBPDPromote(object, session);

      assertFalse(currentObject.getObjectId().getId().equals(object.getObjectId().getId()));
      assertFalse(TestUtils.isMarkedCurrent(object));
      assertFalse(TestUtils.isVersionLabelAttached(object, "Draft"));
      assertTrue(TestUtils.isObjectLinkedToFolder(object, "/Ag Technology Best Practices/Cotton/Draft"));

      assertEquals("Approved", currentObject.getCurrentStateName());
      assertTrue(
          TestUtils.isObjectLinkedToFolder(currentObject, "/Ag Technology Best Practices/Cotton/Approved"));
      assertEquals("bpd_cot_approved", currentObject.getACLName());
      assertTrue(TestUtils.isMarkedCurrent(currentObject));
      assertTrue(TestUtils.isVersionLabelAttached(currentObject, "2.0"));
      assertTrue(TestUtils.isVersionLabelAttached(currentObject, "Approved"));
    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testVersionApprovedDocumentGoesToDraft() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    IDfSysObject newDraftObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);
      IDfSysObject currentObject = promoteAgTechBPDDoc(object, session);

      newDraftObject = TestUtils.checkoutCheckin(currentObject, session);

      assertAgTechBPDDocState(currentObject, "Approved", "/Ag Technology Best Practices/Cotton/Approved",
          "bpd_cot_approved", true, "2.0");

      assertAgTechBPDDocState(newDraftObject, "Draft", "/Ag Technology Best Practices/Cotton/Draft", "bpd_cot_draft",
          false, "2.1");
    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testCheckinWithPreviouslyApprovedVersion() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSession session = null;
    IDfSysObject object = null;
    IDfSysObject anotherNewDraftObject = null;
    IDfSysObject newDraftObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);
      IDfSysObject currentObject = promoteAgTechBPDDoc(object, session);

      assertAgTechBPDDocState(currentObject, "Approved", "/Ag Technology Best Practices/Cotton/Approved",
          "bpd_cot_approved", true, "2.0");

      newDraftObject = TestUtils.checkoutCheckin(currentObject, session);
      assertAgTechBPDDocState(newDraftObject, "Draft", "/Ag Technology Best Practices/Cotton/Draft", "bpd_cot_draft",
          false, "2.1");

      anotherNewDraftObject = TestUtils.checkoutCheckin(newDraftObject, session);
      assertAgTechBPDDocState(anotherNewDraftObject, "Draft", "/Ag Technology Best Practices/Cotton/Draft",
          "bpd_cot_draft", false, "2.2");
      assertFalse(TestUtils.isVersionLabelAttached(newDraftObject, "Draft"));

    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testCheckinWithPreviouslyApprovedVersionUserWithReadAccess() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    IDfSessionManager sessionManager1 = DFCSessionUtils.createSessionManager(testdocbase, "devl02", "devl02");
    IDfSession session = null;
    IDfSession session1 = null;
    IDfSysObject object = null;
    IDfSysObject anotherNewDraftObject = null;
    IDfSysObject newDraftObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our object at the end rather than begin and abort a transaction
      session = sessionManager.getSession(testdocbase);
      object = createInitialAgTechBPDDoc(session);

      IDfSysObject currentObject = promoteAgTechBPDDoc(object, session);

      assertAgTechBPDDocState(currentObject, "Approved", "/Ag Technology Best Practices/Cotton/Approved",
          "bpd_cot_approved", true, "2.0");

      session1 = sessionManager1.getSession(testdocbase);
      newDraftObject = TestUtils.checkoutCheckin(currentObject, session1);

      assertAgTechBPDDocState(newDraftObject, "Draft", "/Ag Technology Best Practices/Cotton/Draft", "bpd_cot_draft",
          false, "2.1");

      anotherNewDraftObject = TestUtils.checkoutCheckin(newDraftObject, session1);

      assertAgTechBPDDocState(anotherNewDraftObject, "Draft", "/Ag Technology Best Practices/Cotton/Draft",
          "bpd_cot_draft", false, "2.2");

    } finally {
      if (object != null) {
        object.destroyAllVersions();
      }
      if (session != null) {
        sessionManager.release(session);

      }
      if (session1 != null) {
        sessionManager1.release(session1);
      }
    }
  }

  private void assertAgTechBPDDocState(IDfSysObject object, String state, String path, String aclName,
                                       boolean shouldBeCurrent, String versionNumber) throws DfException {
    assertEquals(state, object.getCurrentStateName());
    assertTrue(
        TestUtils.isObjectLinkedToFolder(object, path));
    assertEquals(aclName, object.getACLName());
    assertEquals(shouldBeCurrent, TestUtils.isMarkedCurrent(object));
    assertTrue(TestUtils.isVersionLabelAttached(object, versionNumber));
    assertTrue(TestUtils.isVersionLabelAttached(object, state));
  }

  private IDfSysObject createInitialAgTechBPDDoc(IDfSession session) throws DfException {
    IDfSysObject object;
    object = (IDfSysObject) session.newObject("ag_tech_best_practice");
    object.setString("crop", "Cotton");
    object.setObjectName("001testApproveDocument");
    object.save();
    return object;
  }

  private IDfSysObject promoteAgTechBPDDoc(IDfSysObject object, IDfSession session) throws DfException {
    IDfSysObject newObject;
    newObject = TestUtils.checkoutCheckin(object, session);
    newObject.promote(null, false, false);
    return getCurrentVersionAfterAgTechBPDPromote(object, session);
  }

  private IDfSysObject getCurrentVersionAfterAgTechBPDPromote(IDfSysObject object, IDfSession session) throws
      DfException {
    IDfCollection versions = null;
    IDfSysObject currentObject;
    try {
      versions = object.getVersions(null);
      Map versionLabelToObject = new HashMap();
      while (versions.next()) {
        IDfId objectId = new DfId(versions.getString("r_object_id"));
        IDfSysObject version = (IDfSysObject) session.getObject(objectId);
        Iterator versionLabels = Arrays
            .asList(version.getAllRepeatingStrings("r_version_label", ",").split(",")).iterator();
        while (versionLabels.hasNext()) {
          String versionLabel = (String) versionLabels.next();
          versionLabelToObject.put(versionLabel, version);
        }
      }
      currentObject = (IDfSysObject) versionLabelToObject.get("CURRENT");
    } finally {
      if (versions != null) {
        versions.close();
      }
    }
    return currentObject;
  }
}