/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.agtech;

import com.documentum.fc.client.IDfBusinessObject;

/**
 * Filename:    $RCSfile: IAgTechBPD.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-13 21:42:30 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public interface IAgTechBPD extends IDfBusinessObject {
}