/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.breedingtechnology.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.breedingtechnology.BreedingTechnology;
import com.monsanto.dctm.test.MockSysObject;

/**
 * Filename:    $RCSfile: MockBreedingTechnology.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-01-30 21:32:58 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class MockBreedingTechnology extends BreedingTechnology {
public MockSession session = null;
  private MockSysObject mock;
  public String lifecycleName = null;
  protected void setProcessId(String processName, IDfSession session) throws DfException{
    super.setProcessId(processName,session);
  }

   public MockBreedingTechnology(){

  }
public MockBreedingTechnology(MockSysObject mock){
    this.mock = mock;
  }
  protected String execQuery(String queryString)
        throws DfException {
    return super.execQuery(queryString);
  }
  public IDfSession getSession() {
        return mock.getSession();
    }
   public void setSession(IDfSession session) {
        mock.setSession(session);
    }
  public String setPrefix(IDfSysObject sysObj , String prePrefix)throws DfException{
    return super.setPrefix(sysObj, prePrefix );
  }
  protected void setPerformers(IDfSysObject sysObj, IDfSession session) throws DfException {
    super.setPerformers(sysObj,session);
  }
   protected void setAliases(IDfWorkflow workflow, IDfSession sess) throws DfException {
     super.setAliases(workflow,sess);
    //workflow.setAliasSetId("66001abe8000f108");
//    session.addObject(workflow,"66001abe8000f108");
   }
}