/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.breedingtechnology;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 * Filename:    $RCSfile: BreedingTechnology.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-06-05 18:51:23 $
 *
 * @author rrkaur
 * @version $Revision: 1.4 $
 */
public class BreedingTechnology extends DfSysObject implements IBreedingTechnology, IDfDynamicInheritance{
  private IDfId m_processId = null;
  private String m_Workflow2Run = "Breeding Technology Approval Workflow";

  private IDfSession session = null;
  public String user = null;
  public String author = null;
  public String approver = null;
  private String prefix = null;
  private String approved = "Approved";
  private String OBJECT_ALREADY_PARTICIPATES_IN_WORKFLOW = "This object already participates in workflow with ID:: ";
  private String draft = "Draft";
  private static final String CURRENT_VERSION = "CURRENT";
  private IDfId m_activityId = null;
  private String m_strPackageName = null;
  private String m_strPortName = null;
  private static final String LIFECYCLE = "Breeding Technology LC";
  private static final String STATE_NAME = "Draft" ;

  public IDfId checkinEx(
      boolean arg0,
      String arg1,
      String arg2,
      String arg3,
      String arg4,
      String arg5)
      throws DfException {
    IDfId newId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
    IDfSysObject newObj = null;
    session = getSession();
    newObj = (IDfSysObject) session.getObject(newId);
    if (isCurrentVersion(this)){
      processAliasAttachLifecycle(this);
    }
    session.setAliasSet(newObj.getAliasSet());
    if (isApprovedVersion(this) || (!isAlreadyInWorkflow(newObj) && isDraftVersion(newObj))) {
      setProcessId(m_Workflow2Run,session);
      setPerformers(newObj,session);
      startWorkflow(newId,session);
    }
    return newId;
  }

  public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
      throws DfException {
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "@@@@@@@@@ doSave @@@@@@@@@", null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "***Your name is :: " + getSession().getLoginUserName(), null, null);
    super.doSave(saveLock, versionLabel, extendedArgs);
    session = getSession();
    if (isCurrentVersion(this)) {
      processAliasAttachLifecycle(this);
    }
    if (!isAlreadyInWorkflow(this) && isDraftVersion(this)) {
      setProcessId(m_Workflow2Run,session);
      setPerformers(this,session);
      startWorkflow(this.getId("r_object_id"),session);
      //setAliases(newObj,session);
    }
  } //doSave

  public void save() throws DfException {
    //System.out.println("BreedingTechnology.save");
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "@@@@@@@@@ SAVE @@@@@@@@@", null, null);
    super.save();

  }

  protected void startWorkflow(IDfId documentId, IDfSession session) throws DfException {
    //System.out.println("BreedingTechnology.startWorkflow");
    String activityName = null;
    String packageName = null;
    String portName = null;
    try {
      IDfId processId = getProcessId();
      if (processId == null) {
        DfLogger.warn(this, "No valid processes to start", null, null);
        return;
      }
      IDfWorkflowBuilder wfBuilder = session.newWorkflowBuilder(processId);
      IDfWorkflow workflow = getWorkflowInfo(wfBuilder);

      setAliases(workflow,session); //Set the missing aliases here!
      setActivityIfNull(wfBuilder);

      IDfActivity activity = (IDfActivity) session.getObject(getActivityId());
      activityName = activity.getString("object_name");

      if (getPortName() == null) //choose first input port by default
      {
        for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
          if (activity.getPortType(cntrPort).equals("INPUT")) {
            portName = activity.getPortName(cntrPort);
            packageName = activity.getPackageName(cntrPort);
            break;
          }
        }
      } else {
        portName = getPortName();
        for (int i = 0; i < activity.getPortCount(); i++) {
          if (activity.getPortName(i).equals(portName)) {
            packageName = activity.getPackageName(i);
            break;
          }
        }
      }

      String strObjectType = getTypeName();
      DfList list = new DfList();
      list.append(documentId);
      workflow.addPackage(
          activityName,
          portName,
          packageName,
          strObjectType,
          "",
          false,
          list);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Started workflow with id: " + workflow.getObjectId().getId(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Workflow name: " + workflow.getObjectName(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "The workflow supervisor is: " + workflow.getSupervisorName(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Added package with doc id: " + documentId, null, null);
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
      throw dfe;
    }
  } //startWorkflow

  private void setActivityIfNull(IDfWorkflowBuilder wfBuilder) throws DfException {
    if (getActivityId() == null) //choose first start activity by default
    {
      IDfList activityIds = wfBuilder.getStartActivityIds();
      setActivityId((IDfId) activityIds.get(0));
    }
  }

  private IDfWorkflow getWorkflowInfo(IDfWorkflowBuilder wfBuilder) throws DfException {
    wfBuilder.initWorkflow();
    wfBuilder.runWorkflow();
    return wfBuilder.getWorkflow();
  }

  protected void setAliases(IDfWorkflow workflow, IDfSession session) throws DfException {
    try {
      IDfAliasSet AliasSet = (IDfAliasSet) session.getObject(workflow.getAliasSetId());
      int nAliases = AliasSet.getAliasCount();
      setUserAuthorApproverAlias(AliasSet);
      AliasSet.save();
//      for (int i = 0; i < nAliases; i++) {
//        System.out.println("AliasName: " + AliasSet.getAliasName(i)
//            + " , "
//            + "AliasValue = " + AliasSet.getAliasValue(i));
//      }
    } catch (DfException dfe) {
      throw dfe;
    }
  } //setAliases

  private void setUserAuthorApproverAlias(IDfAliasSet aliasSet) throws DfException {
    int indexofApp = aliasSet.findAliasIndex("bt_approvers");
    if (indexofApp > -1)
      aliasSet.setAliasValue(indexofApp, approver);
    int indexofAuth = aliasSet.findAliasIndex("bt_authors");
    if (indexofAuth > -1)
      aliasSet.setAliasValue(indexofAuth, author);
    int indexofUser = aliasSet.findAliasIndex("bt_users");
    if (indexofUser > -1)
      aliasSet.setAliasValue(indexofUser, user);
  }

  protected boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException {
    //System.out.println("BreedingTechnology.isAlreadyInWorkflow");

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    IDfCollection wcoll = null;
    boolean inWorkflow = false;

    try {
      wcoll = sysObj.getWorkflows("", "");
      if (wcoll != null && wcoll.next()) {
//       System.out.println(OBJECT_ALREADY_PARTICIPATES_IN_WORKFLOW + wcoll.getString("r_workflow_id"));
        inWorkflow = true;
      } else if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null) {
        while (coll.next()) {
          versionId = coll.getId("r_object_id");
          version = (IDfSysObject) getSession().getObject(versionId);
          if (version.getCurrentStateName().equals(approved))
            continue;
          /* issue #0241813
          Closing previuos collection object before it gets assigned to new object */
          wcoll.close();
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Breeding Technology Collection Object Closed." , null, null);
          /* issue #0241813 */
          wcoll = version.getWorkflows("", "");
          if (wcoll != null && wcoll.next()) {
//            System.out.println(OBJECT_ALREADY_PARTICIPATES_IN_WORKFLOW + wcoll.getString("r_workflow_id"));
            inWorkflow = true;
            break;
          }
        }
      }
    } catch (DfException dfe) {
      throw dfe;
    } finally {
      if (wcoll != null)
        wcoll.close();
      if (coll != null)
        coll.close();
    }


    return inWorkflow;
  } //isAlreadyInWorkflow
  protected boolean isApprovedVersion(IDfSysObject sysObj) throws DfException {
    //System.out.println("BreedingTechnology.isApprovedVersion");
    boolean isApproved = false;
//    if (sysObj.getCurrentStateName() == null)
//      return true;
    if (sysObj.getCurrentStateName().equals(approved)) {
      isApproved = true;
    }
    return isApproved;
  } //isApprovedVersion

  protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {
    //System.out.println("BreedingTechnology.isDraftVersion");

    String label = null;
    boolean isDraft = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
//      System.out.println("is Draft label " + label);
      if (label.equals(draft))
        isDraft = true;
    }
    return isDraft;
  } //isDraftVersion
  protected boolean isCurrentVersion(IDfSysObject sysObj) throws DfException {
    //System.out.println("BreedingTechnology.isCurrentVersion");

    String label = null;
    boolean isCurrent = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
//      System.out.println("is Draft label " + label);
      if (label.equals(CURRENT_VERSION))
        isCurrent = true;
    }
    return isCurrent;
  } //isDraftVersion
  protected void setPerformers(IDfSysObject sysObj, IDfSession sess) throws DfException {

    String groupPrefix = null;
    groupPrefix = setPrefix(sysObj, "bt_");
    user = groupPrefix + "_user";
    author = groupPrefix + "_author";
    approver = groupPrefix + "_approval";
    try {
      if (groupPrefix == "" || groupPrefix == null)
        throw new DfException("No valid group for this workflow");

      checkGroupExistsOrNotEmpty(sess.getGroup(user),user);
      checkGroupExistsOrNotEmpty(sess.getGroup(author),author);
      checkGroupExistsOrNotEmpty(sess.getGroup(approver),approver);
    } catch (DfException dfe) {
      DfLogger.warn(this, dfe.getMessage(), null, null);
      throw dfe;
    }
  }

  private void checkGroupExistsOrNotEmpty(IDfGroup group, String groupName) throws DfException {
    if (group == null || group.getAllUsersNamesCount() < 1) {
      String msg = "###Author Group specified by " + groupName + " does not exist!";
      throw new DfException(msg);
    }
  }

  protected String setPrefix(IDfSysObject sysObj, String prePrefix ) throws DfException {
    String level = sysObj.getString("bt_level");
    String function = sysObj.getString("bt_function");
    String site = sysObj.getString("site");
    String select = "select coded_value from dm_dbo.code_lookup where decoded_value='";
    String query = null;

    if(level.equalsIgnoreCase("Corporate")){
      query = select + level + "' and code_type ='bt_level'";
      String levelCode = execQuery(query);
      prefix = prePrefix + levelCode;
    }else if(level.equalsIgnoreCase("Function")){
      query = select + function + "' and code_type='bt_function'";
      String functionCode = execQuery(query);
      prefix = prePrefix + functionCode ;
    }else if(level.equalsIgnoreCase("Site")){
      query = select + site + "' and code_type = 'bt_site'";
      String siteCode = execQuery(query);
      prefix = prePrefix + siteCode ;
    }
    return prefix;
  }
  public void processAliasAttachLifecycle(IDfSysObject sysObj)throws DfException {
    String aliasSetName = setPrefix(sysObj, "breed_tech_");
    //System.out.println("aliasSetName = " + aliasSetName);
    session = getSession();
    try {
      StringBuffer bufQual = new StringBuffer();
      bufQual.append("dm_policy where object_name='").append(
          LIFECYCLE).append(
          "'");
      IDfId policyId = session.getIdByQualification(bufQual.toString());
      //System.out.println("policyId = " + policyId);
      if ((policyId == null) || (policyId.isNull())) {
        String msg = "Unable to locate the lifecycle to be applied";
        DfLogger.warn(this, msg, null, null);
        throw new IllegalArgumentException(msg);
      }
      else{
        applyLifeCycle(policyId, sysObj, aliasSetName);
      }
    } catch (DfException dfe) {
      DfLogger.error(this, "Error attaching the policy :: " + LIFECYCLE, null, null);
      throw dfe;
    }
  }

  private void applyLifeCycle(IDfId policyId, IDfSysObject sysObj, String aliasSetName) throws DfException {
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Got policy with id: " + policyId.getId(), null, null);
    if  (sysObj.getPolicyId().toString() == "0000000000000000")  {
      sysObj.attachPolicy(policyId,"", aliasSetName);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "!!!!!!!!Successfully attached policy...", null, null);
    }
  }
//
//  private void attachLifeCycle(String state, IDfSysObject sysObj, IDfId policyId, String scope) throws DfException {
//    if (state != null){
//      //System.out.println("sysObj object id in attachlifecycle = " + sysObj.getObjectId().toString());
//      sysObj.attachPolicy(policyId, state, scope);
//      //System.out.println("!!!!!!!!Successfully attached policy..." );
//      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "!!!!!!!!Successfully attached policy...", null, null);
//    }
//  }

  protected void setProcessId(String processName, IDfSession session) throws DfException {
    IDfCollection Workflows = null;
    try {
      Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        if (Next.getString("object_name").equals(processName)) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          break;
        }
      }
    } catch (DfException dfe) {
      throw dfe;
    }finally{
      if(Workflows != null){
        Workflows.close();
      }
    }
  }

  protected String execQuery(String queryString) throws DfException {
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    String result = null;
    try {
      IDfQuery q = clientx.getQuery(); //Create query object

      q.setDQL(queryString); //Give it the query
      coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
      if (coll.next()) {
        result = coll.getString("coded_value");
      }
    } catch (DfException dfe) {
      throw dfe;
    } finally {
      if(coll !=null){
        coll.close();
      }
    }
    return result;
  } //execQuery

  public void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }

  public void setPackageName(String packageName) {
    m_strPackageName = packageName;
  }

  public void setPortName(String strPort) {
    m_strPortName = strPort;
  }

  public IDfId getActivityId() {
    return m_activityId;
  }

  public String getPackageName() {
    return m_strPackageName;
  }

  public String getPortName() {
    return m_strPortName;
  }

  public IDfId getProcessId() {
    return m_processId;
  }

  public boolean supportsFeature(String arg0) {
    return false;
  } //supportsFeature

  public boolean isCompatible(String arg0) {
    if (arg0.equals(getVersion())) {
      return true;
    }
    return false;
  } //isCompatible

  public String getVersion() {
    return "1.0";
  } //getVersion

  public String getVendorString() {
    return "Copyright (c) 2006 Monsanto Corp.";
  } //getVendorString

}