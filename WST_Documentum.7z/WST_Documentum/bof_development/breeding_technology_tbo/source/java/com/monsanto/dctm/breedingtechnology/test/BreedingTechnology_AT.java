/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.breedingtechnology.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.breedingtechnology.IBreedingTechnology;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: BreedingTechnology_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-01-30 21:32:58 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class BreedingTechnology_AT extends TestCase {
  public void testCreateOneBreedTechDoc() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl12", "devl12");
    IDfSession session = null;
    IDfSysObject object = null;
    IDfCollection workflows = null;
    IDfId workflowId = null;
    IDfWorkflow workflowObject = null;
    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("breed_tech_doc");
      object.setString("object_name", "TEST BREED FROM AT");
      object.setRepeatingString("keywords",0,"kk");
      object.setRepeatingString("authors",0,"usha");
      object.setString("bt_level","Corporate");
      object.setString("bt_function","All");
      object.setString("site","All");
      object.setRepeatingString("crop",0,"All");

      object.save();

      assertNotNull(object);
      assertEquals("Copyright (c) 2006 Monsanto Corp.", ((IBreedingTechnology) object).getVendorString());
      assertEquals("TEST BREED FROM AT", object.getObjectName());
      assertEquals("Corporate", object.getString("bt_level"));
      assertEquals("All",  object.getString("bt_function"));
      assertEquals("All", object.getString("site"));
      assertEquals("Breeding Technology LC", object.getPolicyName());
      assertEquals("Draft", object.getCurrentStateName());
      assertEquals("1.0", ((IBreedingTechnology) object).getVersion());
      workflows = object.getWorkflows("","");
      if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
        assertEquals("Breeding Technology Approval Workflow 2008-05-30",workflowObject.getObjectName());
      }
    }finally {
      if (object != null) {
        workflows = object.getWorkflows("","");
        if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        object.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateBreedTechDocWithDifferentFunction() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl11", "devl11");
    IDfSession session = null;
    IDfSysObject object = null;
    IDfCollection workflows = null;
    IDfId workflowId = null;
    IDfWorkflow workflowObject = null;
    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("breed_tech_doc");
      object.setString("object_name", "TEST BREED FROM AT");
      object.setRepeatingString("keywords",0,"kk");
      object.setRepeatingString("authors",0,"usha");
      object.setString("bt_level","Function");
      object.setString("bt_function","Entomology");
      object.setString("site","All");
      object.setRepeatingString("crop",0,"All");
      object.save();

      assertNotNull(object);
      assertEquals("Copyright (c) 2006 Monsanto Corp.", ((IBreedingTechnology) object).getVendorString());
      assertEquals("TEST BREED FROM AT", object.getObjectName());
      assertEquals("Function", object.getString("bt_level"));
      assertEquals("Entomology",  object.getString("bt_function"));
      assertEquals("All", object.getString("site"));
      assertEquals("Breeding Technology LC", object.getPolicyName());
      assertEquals("Draft", object.getCurrentStateName());
      assertEquals("1.0", ((IBreedingTechnology) object).getVersion());
      workflows = object.getWorkflows("","");
      if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
        assertEquals("Breeding Technology Approval Workflow 2008-05-30",workflowObject.getObjectName());
      }
    }finally {
      if (object != null) {
        workflows = object.getWorkflows("","");
        if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        object.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateBreedTechDocWithDifferentSite() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl11", "devl11");
    IDfSession session = null;
    IDfSysObject object = null;
    IDfCollection workflows = null;
    IDfId workflowId = null;
    IDfWorkflow workflowObject = null;
    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("breed_tech_doc");
      object.setString("object_name", "TEST BREED FROM AT");
      object.setRepeatingString("keywords",0,"kk");
      object.setRepeatingString("authors",0,"usha");
      object.setString("bt_level","Site");
      object.setString("bt_function","Entomology");
      object.setString("site","Ankeny, IA");
      object.setRepeatingString("crop",0,"All");
      object.save();

      assertNotNull(object);
      assertEquals("Copyright (c) 2006 Monsanto Corp.", ((IBreedingTechnology) object).getVendorString());
      assertEquals("TEST BREED FROM AT", object.getObjectName());
      assertEquals("Site", object.getString("bt_level"));
      assertEquals("Entomology",  object.getString("bt_function"));
      assertEquals("Ankeny, IA", object.getString("site"));
      assertEquals("Breeding Technology LC", object.getPolicyName());
      assertEquals("Draft", object.getCurrentStateName());
      assertEquals("1.0", ((IBreedingTechnology) object).getVersion());
      workflows = object.getWorkflows("","");
      if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
        assertEquals("Breeding Technology Approval Workflow 2008-05-30",workflowObject.getObjectName());
      }
    }finally {
      if (object != null) {
        workflows = object.getWorkflows("","");
        if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        object.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

}