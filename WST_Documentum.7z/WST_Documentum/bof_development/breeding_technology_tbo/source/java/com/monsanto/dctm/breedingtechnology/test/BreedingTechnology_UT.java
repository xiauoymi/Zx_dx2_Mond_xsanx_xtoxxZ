/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.breedingtechnology.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.monsanto.dctm.breedingtechnology.BreedingTechnology;
import com.monsanto.dctm.test.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: BreedingTechnology_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-01-30 21:32:58 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class BreedingTechnology_UT extends TestCase {
   private MockDfSessionManager sessionManager;

  protected void setUp(){
  sessionManager = new MockDfSessionManager();
  }

  public void testCreate() throws Exception {
    BreedingTechnology breed = new BreedingTechnology();
    assertNotNull(breed);
    assertTrue(breed instanceof BreedingTechnology);
  }
  public void testSetProcessId() throws Exception {
    MockBreedingTechnology breed = new MockBreedingTechnology();
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    session.setResults(setupResults());
    assertNull(breed.getProcessId());
    breed.setProcessId("Breeding Technology Approval Workflow",session);
    assertNotNull(breed.getProcessId());
  }

  public void testExecQuery() throws Exception {

    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("bt_function","All");
    sysObject.setString("bt_site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","corp");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate'");

    assertEquals("corp",breed.execQuery("select coded_value from dm_dbo.code_lookup where decoded_value='Corporate'"));
  }
  public void testSetPrefixIfLevelIsCorporate() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","corp");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");
    assertEquals("bt_corp",breed.setPrefix(sysObject, "bt_"));

   }
  public void testSetPrefixIfLevelIsFunction() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Function");
    sysObject.setString("function","ITI");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","ent");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='ITI' and code_type='bt_function'");
    assertEquals("bt_ent",breed.setPrefix(sysObject, "bt_"));
   }

   public void testSetPrefixIfLevelIsSite() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Site");
    sysObject.setString("function","ITI");
    sysObject.setString("site","York, NE");
    sysObject.setSession(session);
    sysObject.setString("coded_value","yor");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='York, NE' and code_type = 'bt_site'");
    assertEquals("bt_yor",breed.setPrefix(sysObject, "bt_"));
   }

  public void testSetPerformers() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","corp");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");

    MockDfGroup userGroup = new MockDfGroup();
    userGroup.setGroupName("bt_corp_user");
    MockDfUser mockUser = new MockDfUser();
    mockUser.setUserName("testuser");
    session.addUser(mockUser);
    userGroup.addUser("testuser");
    session.addGroup(userGroup);

    MockDfGroup authorGroup = new MockDfGroup();
    authorGroup.setGroupName("bt_corp_author");
    MockDfUser mockAuthor = new MockDfUser();
    mockAuthor.setUserName("testuser");
    session.addUser(mockAuthor);
    authorGroup.addUser("testAuthor");
    session.addGroup(authorGroup);

    MockDfGroup approverGroup = new MockDfGroup();
    approverGroup.setGroupName("bt_corp_approval");
    MockDfUser mockApprover = new MockDfUser();
    mockApprover.setUserName("testApprove");
    session.addUser(mockApprover);
    approverGroup.addUser("testApprover");
    session.addGroup(approverGroup);

    breed.setPerformers(sysObject,session);
    assertEquals("bt_corp_user",breed.user);
    assertEquals("bt_corp_author",breed.author);
    assertEquals("bt_corp_approval",breed.approver);

  }
  public void testSetPerformersThrowExceptionIfGroupIsNullOrEmpty() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","corp");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");
    try {
      breed.setPerformers(sysObject,session);
    } catch (DfException e) {

      return;
    }
    fail("###Author Group specified by bt_corp_user does not exist!");
  }

  public void testSetPerformersUsersInGroup() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","corp");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");

    MockDfGroup userGroup = new MockDfGroup();
    userGroup.setGroupName("bt_corp_user");
  userGroup.addUser("User1");
    session.addGroup(userGroup);

    MockDfGroup authGroup = new MockDfGroup();
    authGroup.setGroupName("bt_corp_author");
  authGroup.addUser("Author1");
    session.addGroup(authGroup);

    MockDfGroup appGroup = new MockDfGroup();
    appGroup.setGroupName("bt_corp_approval");
  appGroup.addUser("Approver1");
    session.addGroup(appGroup);

  breed.setPerformers(sysObject,session);
    assertEquals("bt_corp_user",breed.user);
    assertEquals("bt_corp_author",breed.author);
    assertEquals("bt_corp_approval",breed.approver);

  }
  public void testSetAlias() throws Exception {
    MockWorkflow workflow = new MockWorkflow();
    MockBreedingTechnology breed = new MockBreedingTechnology();
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    workflow.setResults(setupResults());
    workflow.setAliasSetId("66001abe8000f108");

    MockAliasSet mockAliasSetObject = new MockAliasSet();
    mockAliasSetObject.setString("object_name", "breed_tech_cor");
    mockAliasSetObject.setString("r_object_id", "66001abe8000f108");
    session.addObject(mockAliasSetObject, "66001abe8000f108");

    breed.setAliases(workflow,session);

  }
  public void testSetAliasPrefixIfLevelIsCorporate() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","cor");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");
    assertEquals("breed_tech_cor",breed.setPrefix(sysObject,"breed_tech_"));
   }
  public void testProcessAliasAttachLifecycle() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","cor");
    sysObject.setString("r_object_id","9999990000000000");
    sysObject.setString("r_policy_id", "0000000000000000");
    sysObject.setString("r_alias_set_id", "0000000000000000");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");
    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);

    MockSysObject mockLifecycleObject = new MockSysObject();
    mockLifecycleObject.setString("object_name", "Breeding Technology LC");
    ArrayList stateNames = new ArrayList();
    stateNames.add("Draft");
    stateNames.add("Approve");
    stateNames.add("Archive");
    mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
    mockLifecycleObject.setString("r_object_id", "46001abe8016d334");
    session.addObject(mockLifecycleObject, "dm_policy where object_name='Breeding Technology LC'");
    session.addObject(mockLifecycleObject, "46001abe8016d334");

    MockSysObject mockAliasSetObject = new MockSysObject();
    mockAliasSetObject.setString("object_name", "breed_tech_cor");
    mockAliasSetObject.setString("r_object_id", "66001abe8000f108");
    session.addObject(mockAliasSetObject, "dm_alias_set where object_name='breed_tech_cor'");
    session.addObject(mockAliasSetObject, "66001abe8000f108");

    breed.processAliasAttachLifecycle(sysObject);

    assertEquals("46001abe8016d334", sysObject.getPolicyId().toString());
    assertEquals("66001abe8000f108", sysObject.getAliasSetId().toString());
   }

  public void testprocessAliasAttachLifecycleThrowsException() throws Exception {
    MockSysObject sysObject = new MockSysObject();
    MockSession session = (MockSession)getSessionManager("stltst03","devl12","devl12").getSession("stltst03");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("function","All");
    sysObject.setString("site","All");
    sysObject.setSession(session);
    sysObject.setString("coded_value","cor");
    sysObject.setString("r_object_id","9999990000000000");
    sysObject.setString("r_policy_id", "0000000000000000");
    session.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where decoded_value='Corporate' and code_type ='bt_level'");

    MockBreedingTechnology breed = new MockBreedingTechnology(sysObject);
    MockSysObject mockLifecycleObject = new MockSysObject();
    mockLifecycleObject.setString("object_name", "Breeding Technology LC");
    ArrayList stateNames = new ArrayList();
    stateNames.add("Draft");
    stateNames.add("Approve");
    stateNames.add("Archive");
    mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
    session.addObject(mockLifecycleObject, "dm_policy where object_name='Breeding Technology LC'");
    session.addObject(mockLifecycleObject, "46001abe8016d334");

    MockSysObject mockAliasSetObject = new MockSysObject();
    mockAliasSetObject.setString("object_name", "breed_tech_cor");
    mockAliasSetObject.setString("r_object_id", "66001abe8000f108");
    session.addObject(mockAliasSetObject, "dm_alias_set where object_name='breed_tech_cor'");
    session.addObject(mockAliasSetObject, "66001abe8000f108");

    try {
      breed.processAliasAttachLifecycle(sysObject);
    } catch (IllegalArgumentException e) {


      return;
    }
    fail("Unable to locate the lifecycle to be applied");
   }

  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {

     IDfLoginInfo loginInfoObj = new DfLoginInfo();
        loginInfoObj.setUser(userid);
        loginInfoObj.setPassword(password);
        loginInfoObj.setDomain(null);
        sessionManager.setIdentity(docbase, loginInfoObj);
        return sessionManager;
    }
  private List setupResults() {

    Map row1 = new HashMap();
    List objectName = new ArrayList();
    objectName.add(0, "Breeding Technology Approval Workflow");
    row1.put("object_name", objectName);

    Map row2 = new HashMap();
    List objectIds = new ArrayList();
    objectIds.add(0, "4b001abe80173f50");
    row1.put("r_object_id", objectIds);

    Map row3 = new HashMap();
    List aliasID = new ArrayList();
    aliasID.add(0, "66001abe8000f108");
    row1.put("r_alias_set_id", aliasID);

    Map row4 = new HashMap();
    List code = new ArrayList();
    code.add(0, "corp");
    row1.put("coded_value", code);

    List workflowProcess = new ArrayList();
    workflowProcess.add(row1);
    workflowProcess.add(row2);
    workflowProcess.add(row3);
    workflowProcess.add(row4);
    return workflowProcess;
  }
}