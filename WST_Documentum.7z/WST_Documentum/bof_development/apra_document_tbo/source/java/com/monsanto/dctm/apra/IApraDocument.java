/*
 * IApraDocument.java
 *
 * Created on May 5, 2006, 1:14 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.apra;

import com.documentum.fc.client.IDfBusinessObject;

/**
 * @author tsvedan
 */
public interface IApraDocument extends IDfBusinessObject {

}
