/*
 * ApraDocument.java
 *
 * Created on May 5, 2006, 1:14 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.apra;

import com.documentum.fc.client.DfSysObject;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;

/**
 * @author tsvedan
 */
public class ApraDocument extends DfSysObject
    implements IApraDocument, IDfDynamicInheritance {

  /**
   * Creates a new instance of ApraDocument
   */
  public ApraDocument() {
  }

/*    
   public void save() throws DfException {
       DfLogger.debug(this, "@@@@@@@@@ SAVE @@@@@@@@@", null,null);
       super.save();
   } //save

   public void saveLock() throws DfException {
       DfLogger.debug(this, "@@@@@@@@@ SAVELOCK @@@@@@@@@", null,null);
       String folder = ((IDfFolder) getSession().getObject(getFolderId(0))).getFolderPath(0);
       DfLogger.debug(this, "Folder path = " + folder, null,null);
       if (folder.indexOf("Electronic Submission") > 0){
           setACLName("Animal Product eSub ACL");
           setACLDomain("dmtst01");
       }
       super.saveLock();
   } //savelock
*/

  protected void doSave(boolean saveLock, String versionLabel, Object[] extArguments) throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ doSave @@@@@@@@@", null, null);
//        super.doSave(saveLock, versionLabel, extArguments);
    String folder = ((IDfFolder) getSession().getObject(getFolderId(0))).getFolderPath(0);
    DfLogger.debug(this, "Folder path = " + folder, null, null);
    if (folder.indexOf("Electronic Submission") > 0 && getACLName().indexOf("eSub") < 0) {
      setACLName("Animal Product eSub ACL");
      setACLDomain("dmtst01");
    }
    super.doSave(saveLock, versionLabel, extArguments);
  }

  public boolean supportsFeature(String arg0) {
    return false;
  } //supportsFeature


  public boolean isCompatible(String arg0) {
    if (arg0.equals(getVersion())) {
      return true;
    }
    return false;
  } //isCompatible


  public String getVersion() {
    return "1.0";
  } //getVersion


  public String getVendorString() {
    return "Monsanto Company, Inc.";
  } //getVendorString

}
