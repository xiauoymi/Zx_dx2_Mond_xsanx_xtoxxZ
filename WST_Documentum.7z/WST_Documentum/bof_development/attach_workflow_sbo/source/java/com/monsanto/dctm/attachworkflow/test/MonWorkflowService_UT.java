/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachworkflow.test;

import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.attachworkflow.MonWorkflowService;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonWorkflowService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-02-25 22:45:21 $
 *
 * @author ussing
 * @version $Revision: 1.3 $
 */
public class MonWorkflowService_UT extends TestCase {


  public void testCreate() throws Exception {
    MonWorkflowService service = new MonWorkflowService();
    assertNotNull(service);
  }
  public void testWithNullsThrowsException() throws Exception {
    MonWorkflowService service = new MonWorkflowService();
    try {
      service.attachWorkflow(null);
    } catch (IllegalArgumentException e) {
      // expected path
      return;
    }
    fail("Should have thrown an illegal argument exception");
  }
  public void testWithOnlySysObjectThrowsException() throws Exception {
    MonWorkflowService service = new MonWorkflowService();
    MockSysObject sourceObject = new MockSysObject();
    sourceObject.setSession(new MockSession(new MockDfSessionManager()));
    sourceObject.setString("r_object_type", "dont_attach_type");
    try {
      service.attachWorkflow(sourceObject);
    } catch (IllegalArgumentException e) {
      // expected path
      return;
    }
    fail("Should have thrown an illegal argument exception");
  }
//  public void testGetWorkflowNameFromBOConfig() {
//    MonWorkflowService service = new MonWorkflowService();
//    String workflowName = service.getWorkflowNameFromConfig("breed_tech_doc");
//    assertEquals(workflowName,"Breeding Technology Approval Workflow");
//  }
  public void testWorkflowExists() throws Exception{
    MonWorkflowService serviceWorkflow = new MonWorkflowService();
    MockSysObject sourceObject = new MockSysObject();
    sourceObject.setSession(new MockSession(new MockDfSessionManager()));
    MockSession session = WorkflowTestUtils.createMockSessionWithMockWorkflow();
    sourceObject.setSession(session);
    sourceObject.setString("r_object_type", "breed_tech_doc");
    assertTrue(serviceWorkflow.checkWorkflowExists(sourceObject,"Breeding Technology Approval Workflow"));

  }
//    public void testLifecycleExists() throws Exception {
//        MonWorkflowService serviceWorkflow = new MonWorkflowService();
//        MockSysObject sourceObject = new MockSysObject();
//        sourceObject.setSession(new MockSession(new MockDfSessionManager()));
//        MockSession session = WorkflowTestUtils.createMockSessionWithMockWorkflow();
//        sourceObject.setSession(session);
//        sourceObject.setString("r_policy_id", null);
//        sourceObject.setString("r_object_type", "breed_tech_doc");
//        serviceWorkflow.attachWorkflow(sourceObject, "Breeding Technology Approval Workflow");
//        assertEquals("Breeding Technology LC", sourceObject.getPolicyName());
//        assertEquals("Draft", sourceObject.getCurrentStateName());
//    }

}