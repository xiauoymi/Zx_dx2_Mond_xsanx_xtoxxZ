/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachworkflow.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockWorkflow;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: WorkflowTestUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-02-25 22:45:52 $
 *
 * @author USSING
 * @version $Revision: 1.1 $
 */
public class WorkflowTestUtils {
  public static MockSession createMockSessionWithMockWorkflow() throws DfException {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();

    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockWorkflow mockWorkflowObject = new MockWorkflow();
    WorkflowTestUtils workflowTestUtils = new WorkflowTestUtils();
    mockWorkflowObject.setObjectName("Breeding Technology Approval Workflow");
    //.setString("object_name", "Breeding Technology Approval Workflow");
    mockSession.setResults(workflowTestUtils.setupResults());
//        mockSession.addObject(mockLifecycleObject, "lifecycleID:Breeding Technology LC");
    mockSession.addObject(mockWorkflowObject, "dm_workflow where object_name='Breeding Technology Approval Workflow'");
    return mockSession;

  }
  private List setupResults() {

    Map row1 = new HashMap();
    List objectName = new ArrayList();
    objectName.add(0, "Breeding Technology Approval Workflow");
    row1.put("object_name", objectName);
    Map row2 = new HashMap();
    List objectIds = new ArrayList();
    objectIds.add(0, "4b001abe80173f50");
    row1.put("r_object_id", objectIds);

    List workflowProcess = new ArrayList();
    workflowProcess.add(row1);
    workflowProcess.add(row2);
    return workflowProcess;
  }
}