/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachworkflow;

import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.devprog.common.boconfig.BOConfigFactory;
import com.documentum.devprog.common.boconfig.IBOConfig;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;

/**
 * Filename:    $RCSfile: MonWorkflowService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-02-25 22:46:15 $
 *
 * @author ussing
 * @version $Revision: 1.3 $
 */
public class MonWorkflowService extends DfService implements
    IMonWorkflowService {

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2006";
  }

  public String getVersion() {
    return "1.0";
  }
  public boolean isCompatible(String str) {
    return str.equals(getVersion());
  }

  public void attachWorkflow(IDfSysObject sourceObject) throws DfException {
    if (sourceObject == null) {
      throw new IllegalArgumentException("object cannot be null");
    }else
    {
      String objectType = sourceObject.getTypeName();
      String workflowName = getWorkflowNameFromConfig(objectType);
      if (workflowName == null){
        throw new IllegalArgumentException("Workflow Name cannot be null");
      }
    }
  }

  public String getWorkflowNameFromConfig(String typeName) {
    IBOConfig boConfig;
    try {
      boConfig = BOConfigFactory.newBOConfig(this);
    } catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }
    return boConfig.getValue("/" + typeName + "/workflow");
  }

  public boolean checkWorkflowExists(IDfSysObject sourceObject, String workflowName ) throws DfException {
    boolean workflowExist = false;
//    String worflowTemplateQuery = "select r_object_id from dm_workflow where object_name = '" + workflowName + "'";
//

//    IDfCollection coll = null; //Collection for the result
//    IDfClientX clientx = new DfClientX();
//    IDfQuery q = clientx.getQuery(); //Create query object
//    String result = null;
//      System.out.println("worflowTemplateQuery = " + worflowTemplateQuery);
//    q.setDQL(worflowTemplateQuery); //Give it the query
//    coll = q.execute(sourceObject.getSession(), IDfQuery.DF_READ_QUERY);
//    if (coll.next()) {
//      result = coll.getString("r_object_id");
//      workflowExist = true;
//      DfLogger.debug(this, "Query executed... Result is " + result, null, null);
//    }
//    if (coll != null)
//      coll.close();

    IDfSession session = null;
    IDfCollection Workflows = null;
    try {
      session = sourceObject.getSession();
      Workflows = session.getRunnableProcesses("");
      System.out.println("Workflows = " + Workflows);
      IDfId processID = null;

      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        //System.out.println("workflowName = " + workflowName);
        if (Next.getString("object_name").equals(workflowName)) {
          processID = Next.getId("r_object_id");
          workflowExist = true;
          // m_processId = processID;
          DfLogger.debug(this, "Workflow name: " + Next.getString("object_name"), null, null);
          DfLogger.debug(this, "Set the process id: " + processID.toString(), null, null);
          break;
        }
      }
    } catch (DfException dfe) {
      throw dfe;
    }finally{
      Workflows.close();
    }
    return workflowExist;
  }

}