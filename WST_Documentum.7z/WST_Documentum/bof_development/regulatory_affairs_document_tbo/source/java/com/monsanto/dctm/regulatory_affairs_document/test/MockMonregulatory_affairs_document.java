/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.regulatory_affairs_document.Monregulatory_affairs_document;
import com.monsanto.dctm.test.MockDfDocument;

/**
 * Filename:    $RCSfile: MockMonregulatory_affairs_document.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 18:11:55 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class MockMonregulatory_affairs_document extends Monregulatory_affairs_document {
    private MockDfDocument mock;
    private IDfSession session;
    public boolean sessionReleased = false;

    public MockMonregulatory_affairs_document(MockDfDocument mock) {
        this.mock = mock;
    }

    public MockMonregulatory_affairs_document() {
        this(new MockDfDocument());
    }

    /**
     * @noinspection RefusedBequest
     */
    public void appendString(String string, String string1) throws DfException {
        mock.appendString(string, string1);
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getString(String string) throws DfException {
        return mock.getString(string);
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean isAttrRepeating(String string) throws DfException {
        return mock.isAttrRepeating(string);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void setRepeatingString(String string, int i, String string1) throws DfException {
        mock.setRepeatingString(string, i, string1);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void setString(String string, String string1) throws DfException {
        mock.setString(string, string1);
    }

    /**
     * @noinspection RefusedBequest
     */
    public String getRepeatingString(String string, int i) throws DfException {
        return mock.getRepeatingString(string, i);
    }

    /**
     * @noinspection RefusedBequest
     */
    public int getValueCount(String string) throws DfException {
        return mock.getValueCount(string);
    }

    /**
     * @noinspection RefusedBequest
     */
    public int findString(String string, String string1) throws DfException {
        return mock.findString(string, string1);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void remove(String string, int i) throws DfException {
        mock.remove(string, i);
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfPersistentObject getObject(IDfId iDfId) throws DfException {
        return mock.getObject(iDfId);
    }

    /**
     * @noinspection RefusedBequest
     */
    public synchronized void setSessionManager(IDfSessionManager sessionManager) throws DfException {
        mock.setSessionManager(sessionManager);
    }

    /**
     * @noinspection RefusedBequest
     */
    public synchronized IDfSessionManager getSessionManager() {
        return mock.getSessionManager();
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfSession getSession() {
        if (session == null) {
            session = new MockSession(Monregulatory_affairs_document_UT.TEST_DOCBASE_OWNER);
        }
        return session;
    }

    /**
     * @noinspection RefusedBequest
     */
    public void releaseSession(IDfSession session) {
        sessionReleased = true;
    }
}