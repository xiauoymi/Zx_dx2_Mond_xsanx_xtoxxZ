/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.utils.QueryUtils;
import com.monsanto.dctm.utils.pathgeneration.DefaultPathGenerator;

import java.util.*;

/**
 * Filename:    $RCSfile: RegAffairsDocBiotechPathGenerator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-18 02:17:30 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class RegAffairsDocBiotechPathGenerator extends DefaultPathGenerator {

    public RegAffairsDocBiotechPathGenerator() {
        listOfAttrNames = new ArrayList();
        listOfAttrNames.add(Monregulatory_affairs_document.REG_CLASSIFICATION_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.CROP_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.BIOTECH_TRAIT_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.BIOTECH_GENE_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.SUBMISSION_REGION_ATTR_NAME);
        prefix = Monregulatory_affairs_document.CABINET_NAME;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected List postProcessPathList(IDfPersistentObject typedObject, List alPaths) throws DfException {
        List modifiedAlPaths = new ArrayList();
        if (alPaths != null) {
            for (Iterator iterator = alPaths.iterator(); iterator.hasNext();) {
                String path = (String) iterator.next();
                Map pathElementsMap = mapPathElementsToAttrNames(path, typedObject);
                if (geneTraitComboExists(typedObject, (String) pathElementsMap.get("biotech_gene"),
                                         (String) pathElementsMap.get("biotech_trait"))) {
                    modifiedAlPaths.add(path);
                }
            }
        }
        return modifiedAlPaths;
    }

    private Map mapPathElementsToAttrNames(String path, IDfTypedObject typedObject) throws DfException {
        String parsedPath = stripPrefixAndFollowingSlash(path);
        String[] pathElements = parsedPath.split("/");
        Iterator attrNames = listOfAttrNames.iterator();
        HashMap pathElementsMap = new HashMap();
        int i = 0;
        while (attrNames.hasNext()) {
            String pathElement = null;
            String attrName = (String) attrNames.next();
            if (i < pathElements.length) {
                pathElement = pathElements[i];
                while (!valueInAttribute(pathElement, attrName, typedObject)) {
                    i++;
                    pathElement = pathElement + "/" + pathElements[i];
                }
            }
            pathElementsMap.put(attrName, pathElement);
            i++;

        }
        return pathElementsMap;
    }

    private boolean valueInAttribute(String pathElement, String attrName, IDfTypedObject typedObject) throws
                                                                                                      DfException {
        if (typedObject.isAttrRepeating(attrName)) {
            return typedObject.findString(attrName, pathElement) != -1;
        } else {
            return typedObject.getString(attrName).equals(pathElement);
        }
    }

    private String stripPrefixAndFollowingSlash(String path) {
        return path.substring(path.indexOf(prefix + "/") + (prefix + "/").length());
    }

    private boolean geneTraitComboExists(IDfPersistentObject typedObject, String strBiotechGene, String strBiotechTrait) throws
                                                                                                                         DfException {
        IDfCollection queryResult = null;
        String strValidComboQuery =
                "select decoded_value from dm_dbo.code_lookup where code_type='ag_reg_affairs_biotech_gene' and decoded_value='" +
                strBiotechGene + "' and (xref_value is null or xref_value='" + strBiotechTrait +
                "')";
        IDfSession session = typedObject.getSession();
        queryResult = QueryUtils.execQuery(session, createDfQuery(), strValidComboQuery);
        boolean geneTraitComboExists = queryResult.next();
        queryResult.close();
        return geneTraitComboExists;
    }

    protected IDfQuery createDfQuery() {
        return new DfQuery();
    }
}