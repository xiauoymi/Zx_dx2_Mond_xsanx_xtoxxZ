package com.monsanto.dctm.regulatory_affairs_document;

import com.documentum.fc.client.DfDocument;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.utils.pathgeneration.DefaultPathGenerator;
//import com.monsanto.dctm.utils.pathgeneration.PathCreationUtils;
import com.monsanto.dctm.utils.pathgeneration.PathGenerator;

import java.util.ArrayList;
import java.util.HashMap;
//import java.util.Iterator;
import java.util.List;

public class Monregulatory_affairs_document extends DfDocument
        implements IMonregulatory_affairs_document, IDfDynamicInheritance {

    private static final String COPYRIGHT = "Copyright(c) Monsanto Corp., 2005";
    private static final String VERSION = "1.0";
    private HashMap aclLookup;
    public static final String ACTIVE_INGREDIENT_ATTR_NAME = "active_ingredient";
    public static final String REG_DOC_DISCIPLINE_ATTR_NAME = "regulatory_doc_discipline";
    public static final String CROP_ATTR_NAME = "crop";
    public static final String BIOTECH_TRAIT_ATTR_NAME = "biotech_trait";
    public static final String REG_CLASSIFICATION_ATTR_NAME = "regulatory_classification";
    public static final String BIOTECH_GENE_ATTR_NAME = "biotech_gene";
    public static final String SUBMISSION_REGION_ATTR_NAME = "submission_region";
    public static final String CABINET_NAME = "/Regulatory Affairs Library";

    public Monregulatory_affairs_document() {
        aclLookup = new HashMap();
        aclLookup.put("ARP", "Regulatory Affairs ARP Document");
        aclLookup.put("CSWG", "Regulatory Affairs CSWG Document");
        aclLookup.put("ChemEcotox", "Reg Affairs ChemEcotox Doc");
        aclLookup.put("6a2NR", "Regulatory Affairs 6a2NR Doc");
    }

    public String getVendorString() {
        return COPYRIGHT;
    }

    public String getVersion() {
        return VERSION;
    }

    public boolean isCompatible(String str) {
        return str.equals("1.0");
    }

    public boolean supportsFeature(String str) {
        String strFeatures = "";
        return strFeatures.indexOf(str) != -1;
    }

    public String getRegulatoryClassification() throws DfException {
        return getString(REG_CLASSIFICATION_ATTR_NAME);
    }

    public void setRegulatoryClassification(String value) throws DfException {
        setString(REG_CLASSIFICATION_ATTR_NAME, value);
    }

    public String getRegulatoryDocContentType() throws DfException {
        return getString("regulatory_doc_content_type");
    }

    public void setRegulatoryDocContentType(String value) throws DfException {
        setString("regulatory_doc_content_type", value);
    }

    public String getSubmissionRegion() throws DfException {
        return getString(SUBMISSION_REGION_ATTR_NAME);
    }

    public void setSubmissionRegion(String value) throws DfException {
        setString(SUBMISSION_REGION_ATTR_NAME, value);
    }

    public String getBarCode() throws DfException {
        return getString("bar_code");
    }

    public void setBarCode(String value) throws DfException {
        setString("bar_code", value);
    }

    public String getActiveIngredient(int index) throws DfException {
        return getRepeatingString(ACTIVE_INGREDIENT_ATTR_NAME, index);
    }

    public int getActiveIngredientCount() throws DfException {
        return getValueCount(ACTIVE_INGREDIENT_ATTR_NAME);
    }

    public void setActiveIngredient(int index, String value) throws DfException {
        setRepeatingString(ACTIVE_INGREDIENT_ATTR_NAME, index, value);
    }


    public String getRegulatoryDocDiscipline(int index) throws DfException {
        return getRepeatingString(REG_DOC_DISCIPLINE_ATTR_NAME, index);
    }

    public int getRegulatoryDocDisciplineCount() throws DfException {
        return getValueCount(REG_DOC_DISCIPLINE_ATTR_NAME);
    }

    public void setRegulatoryDocDiscipline(int index, String value) throws DfException {
        setRepeatingString(REG_DOC_DISCIPLINE_ATTR_NAME, index, value);
    }

    public String getCrop(int index) throws DfException {
        return getRepeatingString(CROP_ATTR_NAME, index);
    }

    public int getCropCount() throws DfException {
        return getValueCount(CROP_ATTR_NAME);
    }

    public void setCrop(int index, String value) throws DfException {
        setRepeatingString(CROP_ATTR_NAME, index, value);
    }

    public String getBiotechTrait(int index) throws DfException {
        return getRepeatingString(BIOTECH_TRAIT_ATTR_NAME, index);
    }

    public int getBiotechTraitCount() throws DfException {
        return getValueCount(BIOTECH_TRAIT_ATTR_NAME);
    }

    public void setBiotechTrait(int index, String value) throws DfException {
        setRepeatingString(BIOTECH_TRAIT_ATTR_NAME, index, value);
    }

    public String getBiotechGene(int index) throws DfException {
        return getRepeatingString(BIOTECH_GENE_ATTR_NAME, index);
    }

    public int getBiotechGeneCount() throws DfException {
        return getValueCount(BIOTECH_GENE_ATTR_NAME);
    }

    public void setBiotechGene(int index, String value) throws DfException {
        setRepeatingString(BIOTECH_GENE_ATTR_NAME, index, value);
    }

    public String getSupportingDocBarCodes(int index) throws DfException {
        return getRepeatingString("supporting_doc_bar_codes", index);
    }

    public int getSupportingDocBarCodesCount() throws DfException {
        return getValueCount("supporting_doc_bar_codes");
    }

    public void setSupportingDocBarCodes(int index, String value) throws DfException {
        setRepeatingString("supporting_doc_bar_codes", index, value);
    }

    protected void doSave(boolean b, String string, Object[] objects) throws DfException {
        setACLFromKeywords();
      //Commented so as to uncustomize the application to not to unlink before linking and not to put the
      //document at the folder location based on attributes

        //linkObjectToPaths(getPathsFromAttributes());
        super.doSave(b, string, objects);
    }

    protected IDfId doCheckin(boolean b, String string, String string1, String string2, String string3, String string4, Object[] objects) throws
                                                                                                                                          DfException {
        IDfId newObjectId = super.doCheckin(b, string, string1, string2, string3, string4, objects);
        getObject(newObjectId).save();
        return newObjectId;
    }

    protected void setACLFromKeywords() throws DfException {
        if (!getRegulatoryDocContentType().equals("Draft")) {
            for (int i = 0; i < getKeywordsCount(); i++) {
                String strKeyword = getKeywords(i);
                String strACLName = (String) aclLookup.get(strKeyword);
                if (strACLName != null && strACLName != getACLName()) {
                    IDfSession session = getSession();
                    IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), strACLName);
                    setACL(newACL);
                    releaseSession(session);
                }
            }
        }
    }

    protected List getPathsFromAttributes() throws DfException {
        List alPaths = new ArrayList();
        if (!getRegulatoryDocContentType().equals("Draft")) {
            PathGenerator pathGenerator = createPathGenerator();
            alPaths = pathGenerator.generatePaths(this);
        }
        return alPaths;
    }

    private PathGenerator createPathGenerator() throws DfException {
        String strRegulatoryClassification = getRegulatoryClassification();
        PathGenerator pathGenerator = new DefaultPathGenerator(null, null);
        if (strRegulatoryClassification.equals("Chemical")) {
            pathGenerator = createChemicalPathGenerator();
        } else if (strRegulatoryClassification.equals("Biotech")) {
            pathGenerator = createBiotechPathGenerator();
        }
        return pathGenerator;
    }

    protected RegAffairsDocChemicalPathGenerator createChemicalPathGenerator() {
        return new RegAffairsDocChemicalPathGenerator();
    }

    protected RegAffairsDocBiotechPathGenerator createBiotechPathGenerator() {
        return new RegAffairsDocBiotechPathGenerator();
    }

    /**
     * @param pathsToLinkTo
     * @throws DfException
     */

    // NOT IN USE since this application was uncustomized. 

    /*protected void linkObjectToPaths(List pathsToLinkTo) throws DfException {

        if (!pathsToLinkTo.isEmpty()) {
          PathCreationUtils.unlinkAllExistingFolderPaths(this);

            for (Iterator itPaths = pathsToLinkTo.iterator(); itPaths.hasNext();) {
                String strPath = itPaths.next().toString();
                linkToPathCreatingFoldersAsNeccessary(strPath);
            }
        }

    }*/

   /* private void linkToPathCreatingFoldersAsNeccessary(String strPath) throws DfException {
        createPath(strPath);
        link(strPath);
    }

    *//**
     * @param strPath
     * @throws DfException
     *//*
    protected void createPath(String strPath) throws DfException {
        String strRegulatoryClassification = getRegulatoryClassification();
        PathCreationUtils.createFolder(getSession(), strPath, "/", "dm_folder",
                                       "/Regulatory Affairs Library/" + strRegulatoryClassification);
    }*/
}