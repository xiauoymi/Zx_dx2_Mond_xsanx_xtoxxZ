/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document;

import com.monsanto.dctm.utils.pathgeneration.DefaultPathGenerator;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: RegAffairsDocChemicalPathGenerator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 21:18:42 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class RegAffairsDocChemicalPathGenerator extends DefaultPathGenerator {

    public RegAffairsDocChemicalPathGenerator() {
        prefix = Monregulatory_affairs_document.CABINET_NAME;
        listOfAttrNames = new ArrayList();
        listOfAttrNames.add(Monregulatory_affairs_document.REG_CLASSIFICATION_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.ACTIVE_INGREDIENT_ATTR_NAME);
        listOfAttrNames.add(Monregulatory_affairs_document.REG_DOC_DISCIPLINE_ATTR_NAME);
    }
}