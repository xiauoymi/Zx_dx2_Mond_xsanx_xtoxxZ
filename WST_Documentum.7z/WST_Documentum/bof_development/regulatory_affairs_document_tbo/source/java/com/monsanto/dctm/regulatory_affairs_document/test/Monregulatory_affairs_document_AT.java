/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.regulatory_affairs_document.IMonregulatory_affairs_document;
import com.monsanto.dctm.regulatory_affairs_document.Monregulatory_affairs_document;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: Monregulatory_affairs_document_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-01-30 21:02:02 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class Monregulatory_affairs_document_AT extends TestCase {
    public void testCreateRegulatoryAffairsDocument() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfPersistentObject object = session.newObject("regulatory_affairs_document");
            assertNotNull(object);
            assertTrue(object instanceof IMonregulatory_affairs_document);
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkObjectToPathsViaSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            setAttributesForFolderMapping(object);
            object.link("/Temp");

            object.save();

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertFalse(folderPathList.contains("/Temp"));
            assertTrue(folderPathList.contains("/Regulatory Affairs Library/Chemical/test active ing/test doc disc"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkBiotechObjectToPathsBadGeneTraitCombo() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            setAttributesForFolderMappingForBiotechBadGeneTraitCombo(object);
            object.link("/Temp");

            object.save();

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertTrue(folderPathList.contains("/Temp"));
            assertFalse(folderPathList.contains("/Regulatory Affairs Library/Biotech/Corn/Maize/Output/Cordap"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkBiotechObjectToPathsGoodGeneTraitCombo() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "dmadmin", "NewDctm5");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            setAttributesForFolderMappingForBiotechGoodGeneTraitCombo(object);
            object.link("/Temp");

            object.save();

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertFalse(folderPathList.contains("/Temp"));
            assertTrue(folderPathList.contains(
                    "/Regulatory Affairs Library/Biotech/Alfalfa/Herbicide Tolerance/CP4 EPSPS, Glyphosate Tolerance"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkBiotechObjectToPathsCropCornGoodGeneTraitCombo() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "dmadmin", "NewDctm5");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            setAttributesForFolderMappingForBiotechCropCornGoodGeneTraitCombo(object);
            object.link("/Temp");

            object.save();

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertFalse(folderPathList.contains("/Temp"));
            assertTrue(folderPathList.contains(
                    "/Regulatory Affairs Library/Biotech/Corn/Maize/Herbicide Tolerance/CP4 EPSPS, Glyphosate Tolerance"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkObjectToPathsViaSaveLock() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            setAttributesForFolderMapping(object);
            object.link("/Temp");

            object.saveLock();

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertFalse(folderPathList.contains("/Temp"));
            assertTrue(folderPathList.contains("/Regulatory Affairs Library/Chemical/test active ing/test doc disc"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLinkObjectToPathsViaCheckin() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");
            object.link("/Temp");
            object.save();

            object.checkout();
            setAttributesForFolderMapping(object);

            IDfId newObjectId = object.checkin(false, "");

            assertEquals(1, object.getFolderIdCount());
            ArrayList folderPathList = getFolderPathList(session, object);
            assertTrue(folderPathList.contains("/Temp"));
            assertFalse(folderPathList.contains("/Regulatory Affairs Library/Chemical/test active ing/test doc disc"));

            IDfSysObject newObject = (IDfSysObject) session.getObject(newObjectId);
            assertEquals(1, newObject.getFolderIdCount());
            ArrayList newFolderPathList = getFolderPathList(session, newObject);
            assertFalse(newFolderPathList.contains("/Temp"));
            assertTrue(
                    newFolderPathList.contains("/Regulatory Affairs Library/Chemical/test active ing/test doc disc"));
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testSetAclFromKeywordsViaSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            object.setKeywords(0, "ARP");

            object.save();

            assertEquals("Regulatory Affairs ARP Document", object.getACLName());

        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testSetAclFromKeywordsViaSaveWithInitialAcl() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");
            object.setObjectName("testdocument");
            object.setACL(session.getACL("dmtst01", "Regulatory Affairs Document"));
            object.save();
            object.setKeywords(0, "ARP");
            object.save();

            assertEquals("Regulatory Affairs ARP Document", object.getACLName());

            object.destroyAllVersions();

        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testSetAclFromKeywordsViaSaveWithInitialAclAlreadyCorrect() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");
            object.setObjectName("testdocument");
            object.setACL(session.getACL("dmtst01", "Regulatory Affairs ARP Document"));
            object.save();
            object.setKeywords(0, "ARP");
            object.save();

            assertEquals("Regulatory Affairs ARP Document", object.getACLName());

            object.destroyAllVersions();

        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testSetAclFromKeywordsViaSaveLock() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession("mtctst01");
            IDfSysObject object = (IDfSysObject) session.newObject("regulatory_affairs_document");

            object.setKeywords(0, "ARP");

            object.saveLock();

            assertEquals("Regulatory Affairs ARP Document", object.getACLName());

        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    private void setAttributesForFolderMapping(IDfSysObject object) throws DfException {
        object.setString("regulatory_doc_content_type", "not draft");
        object.setString("regulatory_classification", "Chemical");
        object.setRepeatingString("active_ingredient", 0, "test active ing");
        object.setRepeatingString("regulatory_doc_discipline", 0, "test doc disc");
    }

    private void setAttributesForFolderMappingForBiotechBadGeneTraitCombo(IDfSysObject object) throws DfException {
        object.setString("regulatory_doc_content_type", "not draft");
        object.setString(Monregulatory_affairs_document.REG_CLASSIFICATION_ATTR_NAME, "Biotech");
        object.setRepeatingString(Monregulatory_affairs_document.CROP_ATTR_NAME, 0, "Corn/Maize");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_TRAIT_ATTR_NAME, 0, "Output");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_GENE_ATTR_NAME, 0, "Cordap");
    }

    private void setAttributesForFolderMappingForBiotechGoodGeneTraitCombo(IDfSysObject object) throws DfException {
        object.setString("regulatory_doc_content_type", "not draft");
        object.setString(Monregulatory_affairs_document.REG_CLASSIFICATION_ATTR_NAME, "Biotech");
        object.setRepeatingString(Monregulatory_affairs_document.CROP_ATTR_NAME, 0, "Alfalfa");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_TRAIT_ATTR_NAME, 0, "Herbicide Tolerance");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_GENE_ATTR_NAME, 0,
                                  "CP4 EPSPS, Glyphosate Tolerance");
    }

    private void setAttributesForFolderMappingForBiotechCropCornGoodGeneTraitCombo(IDfSysObject object) throws
                                                                                                        DfException {
        object.setString("regulatory_doc_content_type", "not draft");
        object.setString(Monregulatory_affairs_document.REG_CLASSIFICATION_ATTR_NAME, "Biotech");
        object.setRepeatingString(Monregulatory_affairs_document.CROP_ATTR_NAME, 0, "Corn/Maize");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_TRAIT_ATTR_NAME, 0, "Herbicide Tolerance");
        object.setRepeatingString(Monregulatory_affairs_document.BIOTECH_GENE_ATTR_NAME, 0,
                                  "CP4 EPSPS, Glyphosate Tolerance");
    }

    private ArrayList getFolderPathList(IDfSession session, IDfSysObject object) throws DfException {
        ArrayList folderPathList = new ArrayList();
        int folderIdCount = object.getFolderIdCount();
        for (int i = 0; i < folderIdCount; i++) {
            folderPathList.add(((IDfFolder) session.getObject(object.getFolderId(i))).getFolderPath(i));
        }
        return folderPathList;
    }

}