// FrontEnd Plus GUI for JAD
// DeCompiled : IMonregulatory_affairs_document.class

package com.monsanto.dctm.regulatory_affairs_document;

import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.common.DfException;

public interface IMonregulatory_affairs_document
    extends IDfBusinessObject {
  public String getRegulatoryClassification()
      throws DfException;

  public void setRegulatoryClassification(String s)
      throws DfException;

  public String getRegulatoryDocContentType()
      throws DfException;

  public void setRegulatoryDocContentType(String s)
      throws DfException;

  public String getSubmissionRegion()
      throws DfException;

  public void setSubmissionRegion(String s)
      throws DfException;

  public String getBarCode()
      throws DfException;

  public void setBarCode(String s)
      throws DfException;

  public String getActiveIngredient(int i)
      throws DfException;

  public int getActiveIngredientCount()
      throws DfException;

  public void setActiveIngredient(int i, String s)
      throws DfException;


  public String getRegulatoryDocDiscipline(int i)
      throws DfException;

  public int getRegulatoryDocDisciplineCount()
      throws DfException;

  public void setRegulatoryDocDiscipline(int i, String s)
      throws DfException;

  public String getCrop(int i)
      throws DfException;

  public int getCropCount()
      throws DfException;

  public void setCrop(int i, String s)
      throws DfException;

  public String getBiotechTrait(int i)
      throws DfException;

  public int getBiotechTraitCount()
      throws DfException;

  public void setBiotechTrait(int i, String s)
      throws DfException;

  public String getBiotechGene(int i)
      throws DfException;

  public int getBiotechGeneCount()
      throws DfException;

  public void setBiotechGene(int i, String s)
      throws DfException;

  public String getSupportingDocBarCodes(int i)
      throws DfException;

  public int getSupportingDocBarCodesCount()
      throws DfException;

  public void setSupportingDocBarCodes(int i, String s)
      throws DfException;
}