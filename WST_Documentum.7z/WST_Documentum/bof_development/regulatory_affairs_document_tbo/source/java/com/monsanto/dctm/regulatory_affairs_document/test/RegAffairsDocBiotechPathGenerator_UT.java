/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.regulatory_affairs_document.RegAffairsDocBiotechPathGenerator;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: RegAffairsDocBiotechPathGenerator_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-18 02:17:30 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class RegAffairsDocBiotechPathGenerator_UT extends TestCase {
    public void testPostProcessPathListNullArguments() throws Exception {
        MockRegAffairsDocBiotechPathGenerator mock = new MockRegAffairsDocBiotechPathGenerator();
        List list = mock.postProcessPathList(null, null);
        assertTrue(list.isEmpty());
    }


    public class MockRegAffairsDocBiotechPathGenerator extends RegAffairsDocBiotechPathGenerator {
        protected List postProcessPathList(IDfPersistentObject typedObject, List alPaths) throws DfException {
            // for visibility
            return super.postProcessPathList(typedObject, alPaths);
        }
    }
}