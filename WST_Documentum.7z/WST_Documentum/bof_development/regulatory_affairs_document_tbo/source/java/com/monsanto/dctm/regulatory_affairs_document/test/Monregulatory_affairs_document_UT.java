/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory_affairs_document.test;

import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.regulatory_affairs_document.RegAffairsDocBiotechPathGenerator;
import com.monsanto.dctm.test.MockDfACL;
import com.monsanto.dctm.test.MockDfQuery;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockFolder;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: Monregulatory_affairs_document_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-07-13 20:11:01 $
 *
 * @author lakench
 * @version $Revision: 1.13 $
 */
public class Monregulatory_affairs_document_UT extends TestCase {

    public static final String TEST_DOCBASE_OWNER = "test_docbase_owner";

    public void testKeywordSetToARPSetsCorrectACL() throws Exception {
        MockMonregulatory_affairs_documentForACLFromKeywords mockMonregulatory_affairs_document = new MockMonregulatory_affairs_documentForACLFromKeywords(
                "ARP");
        mockMonregulatory_affairs_document.setRegulatoryDocContentType("not draft");

        mockMonregulatory_affairs_document.setACLFromKeywords();

        assertEquals("Regulatory Affairs ARP Document", mockMonregulatory_affairs_document.iDfACL.aclName);
        assertEquals(TEST_DOCBASE_OWNER, mockMonregulatory_affairs_document.iDfACL.docbaseOwnerName);
        assertTrue(mockMonregulatory_affairs_document.sessionReleased);
    }

  public void testKeywordSetTo6a2NRSetsCorrectACL() throws Exception {
        MockMonregulatory_affairs_documentForACLFromKeywords mockMonregulatory_affairs_document = new MockMonregulatory_affairs_documentForACLFromKeywords(
                "6a2NR");
        mockMonregulatory_affairs_document.setRegulatoryDocContentType("not draft");

        mockMonregulatory_affairs_document.setACLFromKeywords();

        assertEquals("Regulatory Affairs 6a2NR Doc", mockMonregulatory_affairs_document.iDfACL.aclName);
        assertEquals(TEST_DOCBASE_OWNER, mockMonregulatory_affairs_document.iDfACL.docbaseOwnerName);
        assertTrue(mockMonregulatory_affairs_document.sessionReleased);
    }

    public void testKeywordSetToCSWGSetsCorrectACL() throws Exception {
        MockMonregulatory_affairs_documentForACLFromKeywords mockMonregulatory_affairs_document = new MockMonregulatory_affairs_documentForACLFromKeywords(
                "CSWG");
        mockMonregulatory_affairs_document.setRegulatoryDocContentType("not draft");

        mockMonregulatory_affairs_document.setACLFromKeywords();

        assertEquals("Regulatory Affairs CSWG Document", mockMonregulatory_affairs_document.iDfACL.aclName);
        assertEquals(TEST_DOCBASE_OWNER, mockMonregulatory_affairs_document.iDfACL.docbaseOwnerName);
        assertTrue(mockMonregulatory_affairs_document.sessionReleased);
    }

    public void testKeywordSetToChemEcotoxSetsCorrectACL() throws Exception {
        MockMonregulatory_affairs_documentForACLFromKeywords mockMonregulatory_affairs_document = new MockMonregulatory_affairs_documentForACLFromKeywords(
                "ChemEcotox");
        mockMonregulatory_affairs_document.setRegulatoryDocContentType("not draft");

        mockMonregulatory_affairs_document.setACLFromKeywords();

        assertEquals("Reg Affairs ChemEcotox Doc", mockMonregulatory_affairs_document.iDfACL.aclName);
        assertEquals(TEST_DOCBASE_OWNER, mockMonregulatory_affairs_document.iDfACL.docbaseOwnerName);
        assertTrue(mockMonregulatory_affairs_document.sessionReleased);
    }

    public void testDraftDoesntChangeACL() throws Exception {
        MockMonregulatory_affairs_documentForACLFromKeywords mock = new MockMonregulatory_affairs_documentForACLFromKeywords(
                "ARP");
        mock.setRegulatoryDocContentType("Draft");

        mock.setACLFromKeywords();

        assertEquals(MockMonregulatory_affairs_documentForACLFromKeywords.INITIAL_ACL_NAME, mock.iDfACL.aclName);
    }

    public void testGetPathsFromAttributesForChemicalWithOneIngredient() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes();
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Chemical");
        mock.setActiveIngredient(0, "test active ing");
        mock.setRegulatoryDocDiscipline(0, "test doc disc");


        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(1, pathsFromAttributes.size());
        String actualPathName = (String) pathsFromAttributes.get(0);
        assertEquals("/Regulatory Affairs Library/Chemical/test active ing/test doc disc", actualPathName);
    }

    public void testGetPathsFromAttributesForChemicalWithMoreThanOneIngredientAndDocDiscipline() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes();
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Chemical");
        mock.setActiveIngredient(0, "test active ing1");
        mock.setRegulatoryDocDiscipline(0, "test doc disc1");
        mock.setActiveIngredient(1, "test active ing2");
        mock.setRegulatoryDocDiscipline(1, "test doc disc2");

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(4, pathsFromAttributes.size());
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Chemical/test active ing1/test doc disc1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Chemical/test active ing1/test doc disc2"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Chemical/test active ing2/test doc disc1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Chemical/test active ing2/test doc disc2"));
    }

    public void testGetPathsFromAttributesForBiotech() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes(
                new MockDfQuery(true));
        MockDfSessionManager sessionManager = new MockDfSessionManager();
        mock.setSessionManager(sessionManager);
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Biotech");
        mock.setCrop(0, "test crop");
        mock.setBiotechTrait(0, "test trait");
        mock.setBiotechGene(0, "test gene");
        mock.setSubmissionRegion(null);

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(1, pathsFromAttributes.size());
        String actualPathName = (String) pathsFromAttributes.get(0);
        assertEquals("/Regulatory Affairs Library/Biotech/test crop/test trait/test gene", actualPathName);
        assertEquals(
                "select decoded_value from dm_dbo.code_lookup where code_type='ag_reg_affairs_biotech_gene' and decoded_value='test gene' and (xref_value is null or xref_value='test trait')",
                mock.mockDfQuery.getDQL());
        assertTrue(mock.mockDfQuery.executeCalled);
        assertFalse(sessionManager.wasReleaseCalled);
    }

    public void testGetPathsFromAttributesForBiotechBadGeneTraitCombo() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes(
                new MockDfQuery(false));
        MockDfSessionManager sessionManager = new MockDfSessionManager();
        mock.setSessionManager(sessionManager);
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Biotech");
        mock.setCrop(0, "test crop");
        mock.setBiotechTrait(0, "test trait");
        mock.setBiotechGene(0, "test gene");
        mock.setSubmissionRegion(null);

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(0, pathsFromAttributes.size());
        assertEquals(
                "select decoded_value from dm_dbo.code_lookup where code_type='ag_reg_affairs_biotech_gene' and decoded_value='test gene' and (xref_value is null or xref_value='test trait')",
                mock.mockDfQuery.getDQL());
        assertTrue(mock.mockDfQuery.executeCalled);
        assertFalse(sessionManager.wasReleaseCalled);
    }

    public void testGetPathsFromAttributesForBiotechWithMoreThanOneGeneTraitAndCrop() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes(
                new MockDfQuery(true));
        MockDfSessionManager sessionManager = new MockDfSessionManager();
        mock.setSessionManager(sessionManager);
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Biotech");
        mock.setCrop(0, "test crop1");
        mock.setCrop(1, "test crop2");
        mock.setBiotechTrait(0, "test trait1");
        mock.setBiotechTrait(1, "test trait2");
        mock.setBiotechGene(0, "test gene1");
        mock.setBiotechGene(1, "test gene2");
        mock.setSubmissionRegion(null);

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(8, pathsFromAttributes.size());
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop1/test trait1/test gene1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop1/test trait1/test gene2"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop1/test trait2/test gene1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop1/test trait2/test gene2"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop2/test trait1/test gene1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop2/test trait1/test gene2"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop2/test trait2/test gene1"));
        assertTrue(
                pathsFromAttributes.contains("/Regulatory Affairs Library/Biotech/test crop2/test trait2/test gene2"));

        assertTrue(mock.mockDfQuery.executeCalled);
        assertFalse(sessionManager.wasReleaseCalled);
    }

    public void testGetPathsFromAttributesForBiotechWithSubmissionRegionAndMoreThanOneGeneTraitAndCrop() throws
                                                                                                         Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes(
                new MockDfQuery(true));
        MockDfSessionManager sessionManager = new MockDfSessionManager();
        mock.setSessionManager(sessionManager);
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("Biotech");
        mock.setCrop(0, "test crop1");
        mock.setCrop(1, "test crop2");
        mock.setBiotechTrait(0, "test trait1");
        mock.setBiotechTrait(1, "test trait2");
        mock.setBiotechGene(0, "test gene1");
        mock.setBiotechGene(1, "test gene2");
        mock.setSubmissionRegion("test sub region");

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertEquals(8, pathsFromAttributes.size());
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop1/test trait1/test gene1/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop1/test trait1/test gene2/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop1/test trait2/test gene1/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop1/test trait2/test gene2/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop2/test trait1/test gene1/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop2/test trait1/test gene2/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop2/test trait2/test gene1/test sub region"));
        assertTrue(pathsFromAttributes.contains(
                "/Regulatory Affairs Library/Biotech/test crop2/test trait2/test gene2/test sub region"));

        assertTrue(mock.mockDfQuery.executeCalled);
        assertFalse(sessionManager.wasReleaseCalled);
    }

    public void testGetPathsFromAttributesForDraftContentType() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes();
        mock.setRegulatoryDocContentType("Draft");

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertTrue(pathsFromAttributes.isEmpty());
    }

    public void testGetPathsFromAttributesForNonBiotechAndNonChemical() throws Exception {
        MockMonregulatory_affairs_documentForPathsFromAttributes mock = new MockMonregulatory_affairs_documentForPathsFromAttributes();
        mock.setRegulatoryDocContentType("not draft");
        mock.setRegulatoryClassification("bad reg classification");

        List pathsFromAttributes = mock.getPathsFromAttributes();

        assertFalse(mock.setACLFromKeywordsRan);
        assertTrue(pathsFromAttributes.isEmpty());
    }

//    public void testLinkObjectsToPathsOnePath() throws Exception {
//        MockMonregulatory_affairs_documentForLinkObjectsToPaths mock = new MockMonregulatory_affairs_documentForLinkObjectsToPaths();
//        ((MockSession) mock.getSession()).addObject(new MockFolder("initial path"), "folderID:initial path");
//        mock.setRegulatoryClassification("test reg classification");
//        mock.link("initial path");
//        ArrayList pathsToLinkTo = new ArrayList();
//        pathsToLinkTo.add("test path1");
//
//        mock.linkObjectToPaths(pathsToLinkTo);
//
//        assertEquals(1, mock.getFolderIdCount());
//        assertEquals("test path1", mock.folderIdToPathNameMap.get(mock.getFolderId(0)));
//    }

//    public void testLinkObjectsToPathsManyPaths() throws Exception {
//        MockMonregulatory_affairs_documentForLinkObjectsToPaths mock = new MockMonregulatory_affairs_documentForLinkObjectsToPaths();
//        ((MockSession) mock.getSession()).addObject(new MockFolder("initial path1"), "folderID:initial path1");
//        ((MockSession) mock.getSession()).addObject(new MockFolder("initial path2"), "folderID:initial path2");
//        ((MockSession) mock.getSession()).addObject(new MockFolder("initial path3"), "folderID:initial path3");
//        mock.setRegulatoryClassification("test reg classification");
//        mock.link("initial path1");
//        mock.link("initial path2");
//        mock.link("initial path3");
//        ArrayList pathsToLinkTo = new ArrayList();
//        pathsToLinkTo.add("test path1");
//        pathsToLinkTo.add("test path2");
//
//        mock.linkObjectToPaths(pathsToLinkTo);
//
//        assertEquals(2, mock.getFolderIdCount());
//        ArrayList folderPathList = new ArrayList();
//        int folderIdCount = mock.getFolderIdCount();
//        for (int i = 0; i < folderIdCount; i++) {
//            folderPathList.add(mock.folderIdToPathNameMap.get(mock.getFolderId(i)));
//        }
//        assertFalse(folderPathList.contains("initial path1"));
//        assertFalse(folderPathList.contains("initial path2"));
//        assertFalse(folderPathList.contains("initial path3"));
//        assertTrue(folderPathList.contains("test path1"));
//        assertTrue(folderPathList.contains("test path2"));
//    }

    class MockMonregulatory_affairs_documentForACLFromKeywords extends MockMonregulatory_affairs_document {
        public MockDfACL iDfACL;
        public static final String INITIAL_ACL_NAME = "initial ACL name";

        public MockMonregulatory_affairs_documentForACLFromKeywords(String keyword) {
            try {
                setKeywords(0, keyword);
                setACLName(INITIAL_ACL_NAME);
                setACL(new MockDfACL("test docbase owner", INITIAL_ACL_NAME));
            } catch (DfException e) {
                e.printStackTrace();
            }
        }

        /**
         * @noinspection RefusedBequest
         */
        public void setACL(IDfACL iDfACL) throws DfException {
            this.iDfACL = (MockDfACL) iDfACL;
        }

        public void setACLFromKeywords() throws DfException {
            super.setACLFromKeywords();
        }
    }

    class MockMonregulatory_affairs_documentForPathsFromAttributes extends MockMonregulatory_affairs_document {
        public MockDfQuery mockDfQuery;
        public boolean setACLFromKeywordsRan = false;

        public MockMonregulatory_affairs_documentForPathsFromAttributes() {
        }

        public MockMonregulatory_affairs_documentForPathsFromAttributes(MockDfQuery mockDfQuery) {
            this.mockDfQuery = mockDfQuery;
      mockDfQuery.setResults(setupResults());
        }
    private List setupResults() {
      Map row1 = new HashMap();
      List objectIds1 = new ArrayList();
      objectIds1.add(0, "09876543");
      row1.put("r_component_id", objectIds1);

      List results = new ArrayList();
      results.add(row1);

      return results;
    }
        public List getPathsFromAttributes() throws DfException {
            return super.getPathsFromAttributes();
        }

        /**
         * @noinspection RefusedBequest
         */
        protected void setACLFromKeywords() throws DfException {
            this.setACLFromKeywordsRan = true;
        }

        /**
         * @noinspection RefusedBequest
         */
        protected IDfQuery createDfQuery() {
            return mockDfQuery;
        }

        /**
         * @noinspection RefusedBequest
         */
        protected RegAffairsDocBiotechPathGenerator createBiotechPathGenerator() {
            return new MockRegAffairsDocBiotechPathGenerator(mockDfQuery);
        }

    }

    class MockRegAffairsDocBiotechPathGenerator extends RegAffairsDocBiotechPathGenerator {
        private MockDfQuery mockDfQuery;


        public MockRegAffairsDocBiotechPathGenerator(MockDfQuery mockDfQuery) {
            super();
            this.mockDfQuery = mockDfQuery;
        }

        /**
         * @noinspection RefusedBequest
         */
        protected IDfQuery createDfQuery() {
            return mockDfQuery;
        }
    }

    class MockMonregulatory_affairs_documentForLinkObjectsToPaths extends MockMonregulatory_affairs_document {
        public Map folderIdToPathNameMap = new HashMap();

//        protected void linkObjectToPaths(List pathsToLinkTo) throws DfException {
//            super.linkObjectToPaths(pathsToLinkTo);
//        }

        /**
         * @noinspection RefusedBequest
         */
//        protected void createPath(String strPath) throws DfException {
//        }

        /**
         * @noinspection RefusedBequest
         */
        public void link(String pathName) throws DfException {
            IDfId folderId = generateFolderIdFromPathName(pathName);
            appendId("i_folder_id", folderId);
            folderIdToPathNameMap.put(folderId, pathName);
        }

        private DfId generateFolderIdFromPathName(String pathName) {
            return new DfId("folderID:" + pathName);
        }

        /**
         * @noinspection RefusedBequest
         */
        protected String getFolderPathFromFolderId(IDfId dfIdFolderId) throws DfException {
            return (String) folderIdToPathNameMap.get(dfIdFolderId);
        }

        /**
         * @noinspection RefusedBequest
         */
        public void unlink(String pathName) throws DfException {
            IDfId folderId = generateFolderIdFromPathName(pathName);
            int index = findId("i_folder_id", folderId);
            remove("i_folder_id", index);
            folderIdToPathNameMap.remove(folderId);
        }
    }
}