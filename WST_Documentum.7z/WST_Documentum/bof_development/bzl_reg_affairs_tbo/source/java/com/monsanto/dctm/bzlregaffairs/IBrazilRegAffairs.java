package com.monsanto.dctm.bzlregaffairs;

import com.documentum.fc.client.IDfBusinessObject;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Dec 1, 2009
 * Time: 1:02:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IBrazilRegAffairs extends IDfBusinessObject {
}
