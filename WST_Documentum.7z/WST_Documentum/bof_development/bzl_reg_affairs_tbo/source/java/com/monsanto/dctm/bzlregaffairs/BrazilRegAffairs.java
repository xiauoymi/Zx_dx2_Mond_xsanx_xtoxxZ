package com.monsanto.dctm.bzlregaffairs;

import com.monsanto.dctm.mon_docs.MonMonDocs;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfACL;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Dec 1, 2009
 * Time: 12:59:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrazilRegAffairs extends MonMonDocs implements IDfDynamicInheritance, IBrazilRegAffairs{

    public String getVendorString() {
       return "Copyright(c) Monsanto Corp., 2009";
     }

     public String getVersion() {
       return "1.0";
     }

     public boolean isCompatible(String str) {
       return str.equals("1.0");
     }

     public boolean supportsFeature(String str) {
       return false;
     }
  public IDfId checkinEx( boolean arg0,String arg1,String arg2,String arg3,String arg4, String arg5)
      throws DfException {
    IDfId newId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
    IDfSysObject newObj = null;
    IDfSession session = this.getSession();      
    session = getSession();
    newObj = (IDfSysObject) session.getObject(newId);
    setACLBasedOnCategory();
    return newId;
  }
    public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
        throws DfException {
      super.doSave(saveLock, versionLabel, extendedArgs);
      setACLBasedOnCategory();
      super.doSave(saveLock, versionLabel, extendedArgs);
    }
  private void setACLBasedOnCategory() throws DfException {
    String category = this.getString("category");
    IDfSession session = this.getSession();
    if(category.equalsIgnoreCase("Agroqu�micos")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "ral_bzl_chemical_acl");
      setACL(newACL);
    } else if(category.equalsIgnoreCase("Biotecnologia")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "ral_bzl_biotech_acl");
      setACL(newACL);
    } else if(category.equalsIgnoreCase("Monitoramento")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "ral_bzl_monitor_acl");
      setACL(newACL);
    } else if(category.equalsIgnoreCase("Sementes")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "ral_bzl_seeds_acl");
      setACL(newACL);
    } else if(category.equalsIgnoreCase("Stwerdaship")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "ral_bzl_stwerdaship_acl");
      setACL(newACL);
    }
    }
}
