/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.pmf.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.pmf.IPMFDocLuling;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * Filename:    $RCSfile: PMFDocLuling_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date:
 * 2007/08/03 20:04:46 $
 *
 * @author ussing
 * @version $Revision: 1.5 $
 */
public class PMFDocLuling_AT extends TestCase {
  private static final String testdocbase = "stltst03";
  //Change credentials to some super-user to execute this test
  private static final String testuserid = "dmadmin";
  private static final String testpw = "NewDctm5";
  private IDfId[] objectIds = new IDfId[26];
  private IDfId workflowId;
  private IDfCollection workflows;
  private IDfSysObject object;
  private IDfSessionManager sessionManager;
  private IDfSession session;

  protected void setUp() throws Exception {
    super.setUp();
    sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
    session = sessionManager.getSession(testdocbase);
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    System.out.println("objectIds.length = " + this.objectIds.length);
    IDfWorkflow workflowObject;
    for (int i = 0; i < this.objectIds.length; i++) {
      System.out.println("teardown loop i = " + i);
      System.out.println("objectIds[" + i + "] = " + this.objectIds[i]);
      if (this.objectIds[i] != null) {
        object = (IDfSysObject) session.getObject(this.objectIds[i]);
        if (object != null) {
          System.out.println("Object Id " + i + " " + this.objectIds[i].toString());
          workflows = object.getWorkflows("", "");
          if (workflows != null && workflows.next()) {
            workflowId = workflows.getId("r_workflow_id");
            System.out.println("Workflow id: " + workflowId.toString());
            workflowObject = (IDfWorkflow) session.getObject(workflowId);
            workflowObject.abort();
            workflowObject.destroy();
            workflows.close();
          }
        }
        if (object != null) {
          object.destroy();
        }
      }
    }


    if (session != null)

    {
      sessionManager.release(session);
    }
  }

  public void testCreateOnePMFLulingDoc() throws DfException {
    IDfWorkflow workflowObject;
    object = (IDfSysObject) session.newObject("pmf_doc_luling");
    objectIds[0] = object.getObjectId();
    object.setString("object_name", "TESTPMF 08_ipa");
    object.setString("document_number", "2001");
    object.setString("mfg_unit", "IPA");
    object.setString("doc_class", "05 Training");
    object.setString("doc_subclass", "Not Applicable");
    object.setString("equipment_number","100012354");
    object.setString("functional_location","lu-wjh-aaaa-aaaaa2");
    object.link("/Temp");

    object.save();

    assertNotNull(object);
    assertEquals("Copyright(c) Monsanto Corp., 2005", ((IPMFDocLuling) object).getVendorString());
    assertEquals("TESTPMF 08_ipa", object.getObjectName());
    assertEquals("Luling", object.getString("site_or_plant"));
    assertEquals("2001", object.getString("document_number"));
    assertEquals("IPA", object.getString("mfg_unit"));
    assertEquals("05 Training", object.getString("doc_class"));
    assertEquals("Not Applicable", object.getString("doc_subclass"));
    assertEquals("PMF Luling", object.getPolicyName());
    assertEquals("Effective", object.getCurrentStateName());
    assertEquals("0000000000100012354", object.getString("format_equip_no"));
    assertEquals("LU-WJH-AAAA-AAAAA2", object.getString("format_functional_location"));
    assertEquals("1.0", ((IPMFDocLuling) object).getVersion());
    workflows = object.getWorkflows("", "");
    if (workflows != null && workflows.next()) {
      workflowId = workflows.getId("r_workflow_id");
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
      Calendar now = Calendar.getInstance();
      Date date = now.getTime();
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
      assertEquals("PMF Luling MOC Workflow " + formatter.format(date), workflowObject.getObjectName());
      assertEquals("pmf_luling_ipa", object.getAliasSet());
      workflows.close();
    }
  }

  public void testEquipmentNumberEnteredWithSomeZeros() throws DfException {
    IDfWorkflow workflowObject;
    object = (IDfSysObject) session.newObject("pmf_doc_luling");
    objectIds[0] = object.getObjectId();
    object.setString("object_name", "TESTPMF 08_ipa");
    object.setString("document_number", "2001");
    object.setString("mfg_unit", "IPA");
    object.setString("doc_class", "05 Training");
    object.setString("doc_subclass", "Not Applicable");
    object.setString("equipment_number","000100012354");
    object.setString("functional_location","lu-wjh-aaaa-aaaaa2");
    object.link("/Temp");

    object.save();

    assertNotNull(object);
    assertEquals("Copyright(c) Monsanto Corp., 2005", ((IPMFDocLuling) object).getVendorString());
    assertEquals("TESTPMF 08_ipa", object.getObjectName());
    assertEquals("Luling", object.getString("site_or_plant"));
    assertEquals("2001", object.getString("document_number"));
    assertEquals("IPA", object.getString("mfg_unit"));
    assertEquals("05 Training", object.getString("doc_class"));
    assertEquals("Not Applicable", object.getString("doc_subclass"));
    assertEquals("PMF Luling", object.getPolicyName());
    assertEquals("Effective", object.getCurrentStateName());
    assertEquals("000100012354", object.getString("equipment_number"));
    assertEquals("0000000000100012354", object.getString("format_equip_no"));
    assertEquals("lu-wjh-aaaa-aaaaa2", object.getString("functional_location"));
    assertEquals("LU-WJH-AAAA-AAAAA2", object.getString("format_functional_location"));
    assertEquals("1.0", ((IPMFDocLuling) object).getVersion());
    workflows = object.getWorkflows("", "");
    if (workflows != null && workflows.next()) {
      workflowId = workflows.getId("r_workflow_id");
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
      Calendar now = Calendar.getInstance();
      Date date = now.getTime();
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
      assertEquals("PMF Luling MOC Workflow " + formatter.format(date), workflowObject.getObjectName());
      assertEquals("pmf_luling_ipa", object.getAliasSet());
      workflows.close();
    }
  }
public void testCreateOnePMFLulingDocAndUpdateEquipNoWhichHasBeenFormatted() throws DfException {
    IDfWorkflow workflowObject;
    object = (IDfSysObject) session.newObject("pmf_doc_luling");
    objectIds[0] = object.getObjectId();
    object.setString("object_name", "TESTPMF 08_ipa");
    object.setString("document_number", "2001");
    object.setString("mfg_unit", "IPA");
    object.setString("doc_class", "05 Training");
    object.setString("doc_subclass", "Not Applicable");
    object.setString("equipment_number","0000000000100012354");
    object.setString("functional_location","lu-wjh-aaaa-aaaaa2");
    object.link("/Temp");

    object.save();

    assertNotNull(object);
    assertEquals("Copyright(c) Monsanto Corp., 2005", ((IPMFDocLuling) object).getVendorString());
    assertEquals("TESTPMF 08_ipa", object.getObjectName());
    assertEquals("Luling", object.getString("site_or_plant"));
    assertEquals("2001", object.getString("document_number"));
    assertEquals("IPA", object.getString("mfg_unit"));
    assertEquals("05 Training", object.getString("doc_class"));
    assertEquals("Not Applicable", object.getString("doc_subclass"));
    assertEquals("PMF Luling", object.getPolicyName());
    assertEquals("Effective", object.getCurrentStateName());
    assertEquals("0000000000100012354", object.getString("format_equip_no"));
    assertEquals("LU-WJH-AAAA-AAAAA2", object.getString("format_functional_location"));
    assertEquals("1.0", ((IPMFDocLuling) object).getVersion());
    workflows = object.getWorkflows("", "");
    if (workflows != null && workflows.next()) {
      workflowId = workflows.getId("r_workflow_id");
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
      Calendar now = Calendar.getInstance();
      Date date = now.getTime();
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
      assertEquals("PMF Luling MOC Workflow " + formatter.format(date), workflowObject.getObjectName());
      assertEquals("pmf_luling_ipa", object.getAliasSet());
      workflows.close();
    }
  }
  public void testCreateMorePMFLulingDoc() throws DfException {
//    IDfSessionManager sessionManager= DFCSessionUtils.createSessionManager(testdocbase,testuserid,testpw);
//IDfSession session=null;
    IDfSysObject object;
    IDfCollection workflows;
    IDfId workflowId;
    IDfWorkflow workflowObject;

    String objectName;
    session = sessionManager.getSession(testdocbase);
    for (int i = 0; i < 26; i++) {
      objectName = "LULTESTPMF ";
      objectName = objectName + i;
      object = (IDfSysObject) session.newObject("pmf_doc_luling");
      object.setString("object_name", objectName);
      object.setString("document_number", "2001");
      object.setString("mfg_unit", "CT2");
      object.setString("doc_class", "05 Training");
      object.setString("doc_subclass", "Not Applicable");
      object.link("/Temp");
      System.out.println("i = " + i);

      System.out.println("objectIds.length = " + this.objectIds.length);
      object.save();
      this.objectIds[i] = object.getId("r_object_id");
      System.out.println("create loop i = " + i);
    }
    for (int i = 0; i < this.objectIds.length; i++) {
      System.out.println("assert loop i = " + i);
      if (this.objectIds[i] != null) {
        object = (IDfSysObject) session.getObject(this.objectIds[i]);
        objectName = "LULTESTPMF ";
        objectName = objectName + i;


        assertNotNull(object);
        assertEquals("Copyright(c) Monsanto Corp., 2005", ((IPMFDocLuling) object).getVendorString());
        assertEquals(objectName, object.getObjectName());
        assertEquals("Luling", object.getString("site_or_plant"));
        assertEquals("2001", object.getString("document_number"));
        assertEquals("CT2", object.getString("mfg_unit"));
        assertEquals("pmf_luling_ct2", object.getAliasSet());
        assertEquals("05 Training", object.getString("doc_class"));
        assertEquals("Not Applicable", object.getString("doc_subclass"));
        assertEquals("PMF Luling", object.getPolicyName());
        assertEquals("Effective", object.getCurrentStateName());
        assertEquals("1.0", ((IPMFDocLuling) object).getVersion());
        workflows = object.getWorkflows(null, null);
        System.out.println("workflows = " + workflows);
        if (workflows != null && workflows.next()) {
          System.out.println("workflows must not be null here");
          workflowId = workflows.getId("r_workflow_id");
          workflowObject = (IDfWorkflow) session.getObject(workflowId);
          Calendar now = Calendar.getInstance();
          Date date = now.getTime();
          SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
          assertEquals("PMF Luling MOC Workflow " + formatter.format(date), workflowObject.getObjectName());
          workflows.close();
        }
      }
    }
  }

}

