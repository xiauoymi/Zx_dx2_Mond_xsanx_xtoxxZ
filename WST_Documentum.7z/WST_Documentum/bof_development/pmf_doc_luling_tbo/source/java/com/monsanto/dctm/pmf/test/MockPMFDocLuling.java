/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.pmf.test;

import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.pmf.IPMFDocLuling;

/**
 * Filename:    $RCSfile: MockPMFDocLuling.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:39:08 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class MockPMFDocLuling extends MockSysObject implements IPMFDocLuling {
  public String getVersion() {
    return null;
  }

  public String getVendorString() {
    return null;
  }

  public boolean isCompatible(String s) {
    return false;
  }

  public boolean supportsFeature(String s) {
    return false;
  }
}