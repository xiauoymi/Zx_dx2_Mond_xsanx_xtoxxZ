/*
 * IPMFDocLuling.java
 *
 * Created on November 14, 2005, 10:41 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.pmf;

import com.documentum.fc.client.IDfBusinessObject;


/**
 * @author tsvedan
 */
public interface IPMFDocLuling extends IDfBusinessObject {

}
