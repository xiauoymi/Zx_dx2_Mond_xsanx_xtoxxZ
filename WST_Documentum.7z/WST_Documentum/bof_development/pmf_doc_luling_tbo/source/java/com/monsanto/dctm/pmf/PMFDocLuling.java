/*
 * PMFDocLuling.java
 *
 * Created on November 14, 2005, 10:41 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.pmf;

//import com.documentum.devprog.common.boconfig.*;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.mapattributes.IMapAttributes;
import com.monsanto.dctm.mapattributes.AttributeMapException;
import com.monsanto.dctm.watermark.IMonWatermarkService;

/**
 * @author tsvedan
 * PMFDocLuling doesn't extend MonMonDocs because of the requirements that on import workflow should not start
 * and documents should be in effective state. But when document is checked out, it should kick-off the workflow
 * and document should be in Draft state.
 * This was not possible with MonDocs because of the implementation of it, thus it was decided to remove this
 * TBO's dependency on MonMonDocs and should extend DfDocument instead and use attach lifecycle service to attach
 * Lifecycle at stages required.
 *
 */
public class PMFDocLuling extends DfDocument implements IPMFDocLuling, IDfBusinessObject

{

  public PMFDocLuling() {

  }

  protected void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {

    IMonAttachLifecycleService service = getAttachLifecycleService();

    super.doSave(saveLock, versionLabel, extendedArgs);

    String scope = getScopeForLifecycle();
    if (this.getPolicyId().isNull()) {
      mapAttributes();
      super.doSave(saveLock, versionLabel, extendedArgs);
      service.attachLifecycle(this,null,"Effective",scope.toString());
    }
  }
  public void setString(String attribute, String value) throws com.documentum.fc.common.DfException{

    super.setString(attribute,value);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Luling setString()", null,null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Luling BEFORE Attribute: "+ attribute + " Value: "+ value, null,null);
    if(attribute.equalsIgnoreCase("functional_location")){
      value = value.toUpperCase();
      attribute = "format_functional_location";

    }else if(attribute.equalsIgnoreCase("equipment_number")){
      value = reformatEquipmentNumber(value);
      attribute = "format_equip_no";
    }
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Luling BEFORE Attribute: "+ attribute + " Value: "+ value, null,null);
    super.setString(attribute,value);
  }

  private String reformatEquipmentNumber(String equipValue )throws DfException {
    String equipmentPrefix = "0000000000";
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"equipvalue: "+ equipValue,null,null);
    if(equipValue.trim().length() == 0){
      equipValue = "";
    }else if(equipValue.trim().startsWith("0")){
      equipValue = equipValue.replaceFirst("^0*","");
      equipValue = equipmentPrefix.concat(equipValue.trim());
    }
    else {
      equipValue = equipmentPrefix.concat(equipValue.trim());
    }
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Updated equipvalue: "+ equipValue,null,null);
    return equipValue;

  }
  private void mapAttributes() throws DfException {
    IDfSessionManager sessMgr = getSession().getSessionManager();
    IMapAttributes mapAttributesService = (IMapAttributes) DfClient.getLocalClient()
        .newService(IMapAttributes.class.getName(), sessMgr);
    try {
      mapAttributesService.mapAttributes(getSession().getDocbaseName(), this);
    } catch (AttributeMapException e) {
      e.printStackTrace();
    }
  }

  private IMonAttachLifecycleService getAttachLifecycleService() throws DfException {
    IDfSessionManager sessMgr = getSession().getSessionManager();

    return (IMonAttachLifecycleService) DfClient.getLocalClient()
        .newService(IMonAttachLifecycleService.class.getName(), sessMgr);
  }

  private String getScopeForLifecycle() throws DfException {
    String scope = ("pmf_luling_");
    StringBuffer query = new StringBuffer("select coded_value from dm_dbo.code_lookup");
    query.append(" where decoded_value='").append(getString("mfg_unit")).append("'");
    query.append(" and code_type='pmf_luling_unit'");
    scope = scope + execQuery(query.toString());
    return scope;
  }


  public IDfId doCheckin(
      boolean b, String s,
      String s1,
      String s2,
      String s3,
      String s4,
      Object[] objects)
      throws DfException {
    if (this.getPreviousApprovedVersion()){
      s = s.replaceAll("CURRENT", moveSymbolicVersionLabel());
    }
    else{
      s = "," + moveSymbolicVersionLabel() + s;
    }
    IDfId newId = super.doCheckin(b,s, s1, s2, s3, s4, objects);

    IDfSession sess = null;
    IDfSysObject newObj = null;
    sess = getSession();
    newObj = (IDfSysObject) sess.getObject(newId);

    if (isApprovedVersion(this) || (!isAlreadyInWorkflow(newObj) && isDraftVersion(newObj))) {
      setProcessId(m_Workflow2Run);
      setPerformers(newObj);
      startWorkflow(newId);
    }
    return newId;
  }

  protected void setProcessId(String processName) throws DfException {

    IDfSession session = null;
    IDfCollection Workflows = null;
    try {
      session = getSession();
      Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        if (Next.getString("object_name").equals(processName)) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Workflow name: " + Next.getString("object_name"), null, null);
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Set the process id: " + processID.toString(), null, null);
          break;
        }
      }
    }finally{
      Workflows.close();
    }

  }


  protected void startWorkflow(IDfId documentId) throws DfException {
    IDfSession session = null;
    String activityName = null;
    String packageName = null;
    String portName = null;
    session = getSession();

    IDfId processId = getProcessId();
    if (validateProcessToStart(processId)) return;

    IDfWorkflow workflow = initializeWorkflow(session, processId).getWorkflow();

    setAliases(workflow); //Set the missing aliases here!
    updateSupervisor(workflow);
    chooseFirstStartActivity(initializeWorkflow(session, processId));

    IDfActivity activity =
        (IDfActivity) session.getObject(getActivityId());
    activityName = activity.getString("object_name");

    /*if (getPortName() == null) //choose first input port by default
    {*/
    for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
      if (activity.getPortType(cntrPort).equals("INPUT")) {
        portName = activity.getPortName(cntrPort);
        packageName = setPackageName(activity, cntrPort,packageName);
        break;
      }
    }
    //}
    /*else {
      portName = getPortName();
      for (int i = 0; i < activity.getPortCount(); i++) {
        if (activity.getPortName(i).equals(portName)) {
          packageName = setPackageName(activity, i,packageName);
          break;
        }
      }
    }*/
    String strObjectType = getTypeName();
    DfList list = new DfList();
    list.append(documentId);
    workflow.addPackage(activityName,portName,packageName,strObjectType,"",false,list);
  } //startWorkflow

  private String setPackageName(IDfActivity activity, int cntrPort, String packageName) throws DfException {
    packageName = activity.getPackageName(cntrPort);
    return packageName;
  }

  private boolean validateProcessToStart(IDfId processId) {
    if (processId == null) {
      DfLogger.warn(this, "No valid processes to start", null, null);
      return true;
    }
    return false;
  }

  private void chooseFirstStartActivity(IDfWorkflowBuilder wfBuilder) throws DfException {
    if (getActivityId() == null) //choose first start activity by default
    {
      IDfList activityIds = wfBuilder.getStartActivityIds();
      setActivityId((IDfId) activityIds.get(0));
    }
  }

  private void updateSupervisor(IDfWorkflow workflow) throws DfException {
    if (supervisor != null) {
      workflow.updateSupervisorName(supervisor);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Changed the supervisor for workflow to: " + supervisor, null, null);
    }
  }

  private IDfWorkflowBuilder initializeWorkflow(IDfSession session, IDfId processId) throws DfException {
    IDfWorkflowBuilder wfBuilder =
        session.newWorkflowBuilder(processId);
    wfBuilder.initWorkflow();
    wfBuilder.runWorkflow();
    return wfBuilder;
  }


  protected void setAliases(IDfWorkflow workflow) throws DfException {

    IDfSession session = null;

    session = getSession();
    // Get the AliasSet ID for this workflow
    IDfId AliasSetId = workflow.getAliasSetId();
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Alias set ID: " + AliasSetId.toString(), null, null);

    //get the alias set
    IDfAliasSet AliasSet = (IDfAliasSet) session.getObject(AliasSetId);
    //Set the aliases by name - Reviewer, Approver
    int nAliases = AliasSet.getAliasCount();

    int indexofRev = AliasSet.findAliasIndex("Mfg TCT");
    if (indexofRev > -1)
      AliasSet.setAliasValue(indexofRev, mfgTCT);
    int indexofApp = AliasSet.findAliasIndex("PSM Clerk");
    if (indexofApp > -1)
      AliasSet.setAliasValue(indexofApp, psmClerk);
    int indexofAuth = AliasSet.findAliasIndex("Author");
    if (indexofAuth > -1)
      AliasSet.setAliasValue(indexofAuth, session.getLoginUserName());

    // Save the AliasSet!
    AliasSet.save();

    for (int i = 0; i < nAliases; i++) {
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "AliasName: "
          + AliasSet.getAliasName(i)
          + ", "
          + "AliasValue = "
          + AliasSet.getAliasValue(i), null, null);
    }



  } //setAliases

  protected void setPerformers(IDfSysObject sysObj) throws DfException {
    String mfgUnit = null;
    StringBuffer query = new StringBuffer("select coded_value from dm_dbo.code_lookup");
    query.append(" where decoded_value='").append(sysObj.getString("mfg_unit")).append("'");
    query.append(" and code_type='pmf_luling_unit'");

    mfgUnit = execQuery(query.toString());
    mfgTCT = "lul_" + mfgUnit + "_mfg_tct";
    psmClerk = "lul_" + mfgUnit + "_psm_clerk";

    IDfGroup reviewers = getSession().getGroup(mfgTCT);
    if (reviewers != null && reviewers.getUsersNamesCount() > 0)
      supervisor = reviewers.getAllUsersNames(0);
  } //setPerformers

  protected boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException  {
    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    IDfCollection wcoll = null;
    boolean inWorkflow = false;
    String currentState = new String();
    try{
      wcoll = sysObj.getWorkflows("", "");
      if (wcoll != null && wcoll.next()) {
        inWorkflow = true;
      } else if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null) {
        while (coll.next()) {
          versionId = coll.getId("r_object_id");
          version = (IDfSysObject) getSession().getObject(versionId);
          if (version != null){
            currentState = version.getCurrentStateName();
            if (currentState != null) {
              if (currentState.equals(approved))
                continue;
              /* issue #0241813
              Closing previuos collection object before it gets assigned to new object */
              wcoll.close();
              DfLogger.info(this, "Name:"+this.getObjectName() + " "+"PMF Luling Collection Object Closed." , null, null);
              /* issue #0241813 */
              wcoll = version.getWorkflows("", "");
              if (wcoll != null && wcoll.next()) {
                DfLogger.info(this, "Name:"+this.getObjectName() + " "+
                    "This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"), null, null);
                inWorkflow = true;
                break;
              }
            }
          }
        }
      }
    }finally{
      if (wcoll != null)
        wcoll.close();
      if (coll != null)
        coll.close();
    }
    return inWorkflow;
  } //isAlreadyInWorkflow

  protected void applyLifecycle(String lifecycleName, String state, String scope) throws DfException {


    IDfSession session = null;
    if (scope.equals("pmf_luling_ipa")) {
      scope = "pmf_luling_gidry";
    }
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ " #### APPLY PolicyId  ### ", null, null);
    session = getSession();
    StringBuffer bufQual = new StringBuffer();
    bufQual.append("dm_policy where object_name='").append(
        lifecycleName).append(
        "'");
    IDfId policyId = session.getIdByQualification(bufQual.toString());
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Got policy with id: " + policyId.getId(), null, null);
    if ((policyId == null) || (policyId.isNull())) {
      String msg = "Unable to locate the lifecycle to be applied";
      DfLogger.warn(this, msg, null, null);
      throw new IllegalArgumentException(msg);
    }
    else{
      IDfSysObject policyObj = (IDfSysObject) session.getObject(policyId);
      if (policyObj != null){
        if (state == null || state.equals("")){
          state = policyObj.getRepeatingString("state_name", 0);
          if (state != null){
            this.attachPolicy(policyId, state, scope);
            this.save();
            DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "!!!!!!!!Successfully attached policy...", null, null);
          }
        }
      }
    }
  } //applyLifecycle


  protected boolean getPreviousApprovedVersion() throws DfException {

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    boolean approvedVersionFound = false;
    if (this.getVStamp() == 0) return false;
    try {
      coll = this.getVersions("r_version_label, r_modify_date, r_object_id");
      if (coll != null) {
        while (coll.next()) {
          versionId = coll.getId("r_object_id");
          version = (IDfSysObject) getSession().getObject(versionId);
          if (isApprovedVersion(version)) {
            approvedVersionFound = true;
            break;
          }
        }
      }
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
    }finally{
      if (coll != null)
        coll.close();
    }
    return approvedVersionFound;
  } //getPreviousApprovedVersion


  protected String moveSymbolicVersionLabel() throws DfException {
    String label = null;
    for (int i = 1; i < this.getVersionLabelCount(); i++) {
      label = this.getVersionLabel(i);
      if (label.equals("Review")) {
        return label;
      }
    }
    return draft;
  } //moveSymbolicVersionLabel


  protected boolean isApprovedVersion(IDfSysObject sysObj) throws DfException {
    boolean isApproved = false;
    if (sysObj.getCurrentStateName() == null)
      return true;
    if (sysObj.getCurrentStateName().equals(approved)) {
      isApproved = true;
    }
    return isApproved;
  } //isApprovedVersion

  protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {
    String label = null;
    boolean isDraft = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
      if (label.equals(draft))
        isDraft = true;
    }
    return isDraft;
  } //isDraftVersion


  protected String execQuery(String queryString) throws DfException {
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery(); //Create query object
    String result = null;
    q.setDQL(queryString); //Give it the query
    try{
      coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
      if (coll.next()) {
        result = coll.getString("coded_value");
        DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Query executed... Result is " + result, null, null);
      }
    }finally {
      if (coll != null)
        coll.close();
    }
    return result;
  } //execQuery

  public String getFileEx2(String fileName, String formatName, int pageNumber, String pageModifier,
                           boolean getResource) throws DfException {
    String fileLocation = super.getFileEx2(fileName, formatName, pageNumber, pageModifier, getResource);

    IMonWatermarkService watermarkService = (IMonWatermarkService) DfClient.getLocalClient()
        .newService(IMonWatermarkService.class.getName(), getSession().getSessionManager());

    try {
      if (watermarkService.isTypeWatermarked(this.getTypeName())) {
        watermarkService.addWatermark(fileLocation, formatName, this);
      }
    }
    catch (Exception exception) {
      exception.printStackTrace();
    }

    return fileLocation;
  }
  public void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }


  public void setPackageName(String packageName) {
    m_strPackageName = packageName;
  }


  /*public void setPortName(String strPort) {
    m_strPortName = strPort;
  }*/


  public IDfId getActivityId() {
    return m_activityId;
  }


  public String getPackageName() {
    return m_strPackageName;
  }

  public String getPortName() {
    return null;
  }


  public IDfId getProcessId() {
    return m_processId;
  }


  public boolean supportsFeature(String arg0) {
    return false;
  } //supportsFeature


  public boolean isCompatible(String arg0) {
    if (arg0.equals(getVersion())) {
      return true;
    }
    return false;
  } //isCompatible


  public String getVersion() {
    return m_strVersion;
  } //getVersion


  public String getVendorString() {
    return m_strVendorString;
  } //getVendorString



  private String draft = "Draft";
  private String approved = "Effective";
  private String m_strVendorString = "Copyright(c) Monsanto Corp., 2005";
  private String m_strVersion = "1.0";
  private String m_Workflow2Run = "PMF Luling MOC Workflow";
  private String mfgTCT = null;
  private String psmClerk = null;
  private String supervisor = null;
  private IDfId m_activityId = null;
  private IDfId m_processId = null;
  private String m_strPackageName = null;
  //private static int bufferSize = 64;
  // private String m_strPortName = null;

}
