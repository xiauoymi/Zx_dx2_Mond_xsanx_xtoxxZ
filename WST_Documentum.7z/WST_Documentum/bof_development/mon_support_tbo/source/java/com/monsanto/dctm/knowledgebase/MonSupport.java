// FrontEnd Plus GUI for JAD
// DeCompiled : MonSupport.class

package com.monsanto.dctm.knowledgebase;

import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.devprog.common.boconfig.BOConfigFactory;
import com.documentum.devprog.common.boconfig.IBOConfig;
import com.documentum.fc.client.DfSysObject;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;

// Referenced classes of package com.monsanto.dctm.knowledgebase:
//            IMonSupport

public class MonSupport extends DfSysObject
    implements IMonSupport, IDfDynamicInheritance {

  private String monSupport_DLC;
  private String draft;
  private String approved;
  private String strVendorString;
  private String strVersion;

  public MonSupport() {
    monSupport_DLC = null;
    draft = null;
    approved = null;
    strVendorString = "Monsanto Corporation";
    strVersion = "1.0";
    initConfig();
  }

  public String getVendorString() {
    return strVendorString;
  }

  public String getVersion() {
    return strVersion;
  }

  public boolean isCompatible(String arg0) {
    return arg0.equals(getVersion());
  }

  public boolean supportsFeature(String arg0) {
    return false;
  }

  private void initConfig() {
    try {
      IBOConfig boConfig = BOConfigFactory.newBOConfig(this);
      monSupport_DLC = boConfig.getValue("/mon_support/lifecycle/name");
      draft = boConfig.getValue("/mon_support/lifecycle/draftstatename");
      approved = boConfig.getValue("/mon_support/lifecycle/approvedstatename");
    }
    catch (BOConfigException boe) {
      DfLogger.error(this, "<<<<<<<Error initializing the config file", null, null);
      boe.printStackTrace();
    }
  }

  public IDfId checkinEx(boolean arg0, String arg1, String arg2, String arg3, String arg4, String arg5)
      throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ CHECKINEX @@@@@@@@@", null, null);
    if (getPreviousApprovedVersion())
      arg1 = arg1.replaceAll("CURRENT", moveSymbolicVersionLabel());
    else
      arg1 = "," + moveSymbolicVersionLabel() + arg1;
    return super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
  }

  public void save()
      throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ SAVE @@@@@@@@@", null, null);
    if (getPreviousApprovedVersion()) {
      unmark("CURRENT");
      super.save();
    } else {
      super.save();
    }
  }

  public void saveLock()
      throws DfException {
    super.saveLock();
    DfLogger.debug(this, "@@@@@@@@@ SAVELOCK @@@@@@@@@", null, null);
    if (getPolicyId().isNull())
      applyLifecycle(monSupport_DLC, null, getAliasSetName());
  }

  private void applyLifecycle(String lifecycleName, String state, String scope)
      throws DfException {
    IDfSession session = null;
    try {
      session = getSession();
      StringBuffer bufQual = new StringBuffer(64);
      bufQual.append("dm_policy where object_name='").append(lifecycleName).append("'");
      IDfId policyId = session.getIdByQualification(bufQual.toString());
      DfLogger.debug(this, "Got policy with id: " + policyId.getId(), null, null);
      if (policyId == null || policyId.isNull()) {
        String msg = "Unable to locate the lifecycle to be applied";
        DfLogger.warn(this, msg, null, null);
        throw new IllegalArgumentException(msg);
      }
      IDfSysObject policyObj = (IDfSysObject) session.getObject(policyId);
      if (state == null || state.equals(""))
        state = policyObj.getRepeatingString("state_name", 0);
      attachPolicy(policyId, state, scope);
      DfLogger.debug(this, "!!!!!!!!Successfully attached policy...", null, null);
    }
    catch (DfException dfe) {
      DfLogger.error(this, "Error attaching the policy :: " + lifecycleName, null, null);
    }
  }

  private String getAliasSetName()
      throws DfException {
    StringBuffer aliasSet = new StringBuffer(40);
    String monSuptType = null;
    monSuptType = getString("mon_supt_type");
    aliasSet.append("mon_supt_").append(monSuptType).append(" Alias Set");
    return aliasSet.toString();
  }

  protected boolean getPreviousApprovedVersion()
      throws DfException {
    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    boolean approvedVersionFound = false;
    if ((coll = getVersions("r_version_label, r_modify_date, r_object_id")) != null) {
      do {
        if (!coll.next())
          break;
        versionId = coll.getId("r_object_id");
        version = (IDfSysObject) getSession().getObject(versionId);
        if (!isApprovedVersion(version))
          continue;
        approvedVersionFound = true;
        break;
      } while (true);
      coll.close();
    }
    return approvedVersionFound;
  }

  protected String moveSymbolicVersionLabel() {
    return draft;
  }

  protected boolean isApprovedVersion(IDfSysObject sysObj)
      throws DfException {
    boolean isApproved = false;
    if (sysObj.getCurrentStateName().equals(approved))
      isApproved = true;
    return isApproved;
  }
}
