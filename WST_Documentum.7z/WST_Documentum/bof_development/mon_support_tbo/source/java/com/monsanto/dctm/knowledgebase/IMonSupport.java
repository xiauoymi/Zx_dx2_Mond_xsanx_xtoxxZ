// FrontEnd Plus GUI for JAD
// DeCompiled : IMonSupport.class

package com.monsanto.dctm.knowledgebase;

import com.documentum.fc.client.IDfBusinessObject;

public interface IMonSupport
    extends IDfBusinessObject {
}
