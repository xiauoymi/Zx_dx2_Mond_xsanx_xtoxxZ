/*
 * Created on May 16, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.deepexport;

import com.documentum.fc.client.IDfService;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public interface IDpDeepExportService extends IDfService {

  /**
   * Exports the contents of a docbase folder to the local file system. It recursively exports the contents of any
   * folder present within the main folder selected for export.
   *
   * @param folderId            The docbase folder on which to run deep export.
   * @param localFilesystemPath The path on the filesystem where the exported data will be stored.
   *
   * @return The local filesystem absolute path of the exported directory.
   *
   * @exception DfException
   * @exception DpDeepExportServiceException
   */
  String deepExportFolder(IDfId folderId, String localFilesystemPath) throws DfException, DpDeepExportServiceException;

}
