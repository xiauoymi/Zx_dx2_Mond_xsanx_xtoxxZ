/*
 * Created on May 16, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.deepexport;

import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import org.apache.log4j.Level;


/**
 * A program to test the deep export service based BO.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class TestDeepExportService {
  private LoginManager m_loginMgr = null;

  TestDeepExportService(String username, String password, String docbase) {
    m_loginMgr = new LoginManager(username, password, docbase);
  }

  public void performExport(String docbaseFolder, String localFolder) throws Exception {
    try {
      IDfSession session = m_loginMgr.getSession();
      IDfFolder folder = null;
      if (new DfId(docbaseFolder).isObjectId()) {
        folder = (IDfFolder) session.getObject(new DfId(docbaseFolder));
      } else {
        folder = (IDfFolder) session.getObjectByPath(docbaseFolder);
      }

      IDfSessionManager sessMgr = m_loginMgr.getSessionManager();
      IDfClient localClient = m_loginMgr.getLocalClient();
      String serviceName = IDpDeepExportService.class.getName();
      IDpDeepExportService exportService = (IDpDeepExportService) localClient.newService(serviceName, sessMgr);
      exportService.deepExportFolder(folder.getObjectId(), localFolder);
      System.out.println("Successfully deep exported");

    }
    finally {
      m_loginMgr.releaseSession();
    }
  }

  /**
   * @param args <p> args[0] username <br> args[1] password <br> args[2] docbaseName <br> args[3] docbaseFolderToExport
   *             <br> args[4] localFolderToExportTo <br>
   */
  public static void main(String[] args) {
    try {
      if (args.length < 5) {
        System.out.println("Invalid number of arguments");
        System.out.println("Correct format: username password docbase docbaseFolderPath localFolderPath");
        System.exit(1);
      }

      DfLogger.getLogger("com.documentum.devprog").setLevel(Level.DEBUG);
      TestDeepExportService serv = new TestDeepExportService(args[0], args[1], args[2]);
      serv.performExport(args[3], args[4]);

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }


  }
}
