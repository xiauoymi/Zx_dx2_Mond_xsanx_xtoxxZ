/*
 * Created on May 16, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.deepexport;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class DpDeepExportServiceException extends Exception {

  /**
   *
   */
  public DpDeepExportServiceException() {
    super();
  }

  /**
   * @param s
   */
  public DpDeepExportServiceException(String s) {
    super(s);
  }

}
