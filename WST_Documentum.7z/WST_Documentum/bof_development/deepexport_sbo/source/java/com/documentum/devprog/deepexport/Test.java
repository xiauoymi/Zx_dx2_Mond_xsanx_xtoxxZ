// Test.java
//
// Copyright (C) 2003, Documentum, Inc., All rights reserved
//
// Test stub for running the DeepExport code
//
package com.documentum.devprog.deepexport;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

public class Test {
  // Login Info - will obtain from command-line args
  String docbaseName;  //args[0]  ("train5")
  String userName;     //args[1]  ("dmadmin")
  String password;     //args[2]  ("training")
  String docbaseFolder;     //args[3]  ("/dmamin/project 123")
  String filesystemDirectory;     //args[4]  ("c:\\test1\\project export")

  //variables used for most programs
  IDfClientX clientx;
  IDfClient client;
  IDfSession session;
  //@@@ for DFC 5.x only
  IDfSessionManager sMgr;

  /**
   * Program logic "begins" here.
   */
  public void begin(String[] args) {

    try {
      // Get the command line arguments and parse them
      parseCmdLine(args);

      //create a Session Manager and get a session
      sMgr = createSessionManager(docbaseName, userName, password);
      session = sMgr.getSession(docbaseName);

      System.out.println("Calling with '" + docbaseFolder + "' and  '" + filesystemDirectory + "'");

      // Start the deep export operation
      Operations operate = new Operations(session);
      operate.doDeepExport(docbaseFolder, filesystemDirectory);

      System.out.println("Finished");
    } catch (Throwable e) {
      if (e instanceof DfException) {
        System.out.println("DFC Exception:");
        String s = ((DfException) e).getStackTraceAsString();
        System.out.println(s);
      } else {
        System.out.println("Non-DFC Exception");
        e.printStackTrace();
      }
    } //end: catch()
    finally {
      sMgr.release(session);
    }
  } // end: begin()

  /**
   * Create a Session Manager
   */
  IDfSessionManager createSessionManager(String docbase, String user, String pass) throws Exception {
    //create a Client object
    clientx = new DfClientX();
    client = clientx.getLocalClient();
    //create a Session Manager object
    sMgr = client.newSessionManager();
    //create an IDfLoginInfo object named �loginInfoObj�
    IDfLoginInfo loginInfoObj = clientx.getLoginInfo();
    loginInfoObj.setUser(user);
    loginInfoObj.setPassword(pass);
    //bind the Session Manager to the login info
    sMgr.setIdentity(docbase, loginInfoObj);
    return sMgr;
  }

  /**
   * void parseCmdLine( String[] args )
   *
   * Copies args[] variables into friendlier-named variables
   */
  void parseCmdLine(String[] args) {
    if (args.length == 5) {
      for (int i = 0; i < args.length; ++i) {
        switch (i) {
          case DOCBASE:   // 0
            docbaseName = args[i];
            break;
          case USERNAME:  // 1
            userName = args[i];
            break;
          case PASSWORD:  // 2
            password = args[i];
            break;
          case DOCBASEPATH:  // 3
            docbaseFolder = args[i];
            break;
          case FILESYSTEMPATH:  // 4
            filesystemDirectory = args[i];
            break;
        }
      }
    } else {
      help();
      System.exit(1); // you never return from this method
    }
  } //end: parseCmdLine( String[] args )

  /**
   * Standard startup code for any standalone Java application.  This is done so that the class may supply member
   * variables to other methods of this class and make non-static methods that may act as getters and setters, etc for
   * the fields of this object.
   */
  public static void main(String[] args) {
    new Test().begin(args);
  }

  void help() {
    String[] helpList = {
        "You must set arguments before executing this program.",
        "Usage: java Test Docbase user pwd docbasePath filesystemPath",
        "",
        "Where: ",
        "      docbase        is your Docbase name",
        "      user           is your user name for the Docbase",
        "      pwd            is users password",
        "      docbasePath    is root folder in docbase to export",
        "      filesystemPath is target root folder on file system",
        "",
        "Example from command line:",
        "",
        "   java Test eCS0407 tuser1 tpwd1 /dmadmin/TestTransform c:\\test2\\project export",
    };

    for (int i = 0; i < helpList.length; ++i) {
      System.out.println(helpList[i]);
    }
  } //end: help()


  final int DOCBASE = 0;
  final int USERNAME = 1;
  final int PASSWORD = 2;
  final int DOCBASEPATH = 3;
  final int FILESYSTEMPATH = 4;
}

