/*
 * Created on May 28, 2003
 * Documentum Developer Program 2003
 *
 */
package com.documentum.devprog.deepexport;

import java.util.EventListener;

/**
 * An interface to listen for the completion of the deep export. Classes that intend to listen for the completion of a
 * deep export should implement this interface.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public interface IDpDeepExportCompleteListener extends EventListener {
  /**
   * Signifies the completion of deep export of a folder. The method is called when deep export completes.
   *
   * @param e
   */
  public void deepExportComplete(DpDeepExportCompleteEvent e);
}
