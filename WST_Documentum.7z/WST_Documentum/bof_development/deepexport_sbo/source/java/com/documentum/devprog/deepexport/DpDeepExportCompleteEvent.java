/*
 * Created on May 28, 2003
 * Documentum Developer Program 2003
 * 
 */
package com.documentum.devprog.deepexport;

import java.util.EventObject;

/**
 * Event that indicates the completion of deep(recursive) export of a folder.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class DpDeepExportCompleteEvent extends EventObject {

  /**
   * @param source The object that generates this event.
   */
  public DpDeepExportCompleteEvent(Object source) {
    super(source);

  }

}
