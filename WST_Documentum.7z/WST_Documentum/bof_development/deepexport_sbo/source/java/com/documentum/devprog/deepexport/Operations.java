// Operations.java
//
// Copyright (C) 2003, Documentum, Inc., All rights reserved
//
// This application exports a folder from a Docbase to the filesystem including all of the 
// sub-folders. It will create the target dircectories on the filesystem if required.
//
package com.documentum.devprog.deepexport;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.operations.*;

import java.io.File;

public class Operations {
  IDfSession m_session = null;
  IDfFolder m_workingFolder = null;
  IDfClientX m_clientX = null;

  public Operations(IDfSession session) {
    m_session = session;
    m_clientX = new DfClientX();
  }

  //Description: Exports the documents in a folder to the file system

  public void doDeepExport(String myDocbaseFolder, String myFilesystemDirectory)
      throws DfException {

    // Create the destination folder on the filesystem. This routine will create it
    // even if it is nested a few levels down.
    createFolderPath(myFilesystemDirectory);

    IDfFolder exportFolder = (IDfFolder) m_session.getObjectByPath(myDocbaseFolder);

    System.out.println("Starting export of Docbase files from folder path " + myDocbaseFolder);

    // This is a deep export, so get all of the folders in the specified location
    // and then export the contents of each folder
    String qualification =
        "select r_object_id from dm_folder where FOLDER(ID('" + exportFolder.getObjectId() + "'), DESCEND)";
    IDfCollection colDQL = execQuery(m_session, qualification);

    IDfFolder myFolder = null;

    while (colDQL.next()) {
      // Get the r_object_id of each folder
      IDfAttr attr = colDQL.getAttr(0);
      String objectID = colDQL.getString(attr.getName());

      // Get the docbase folder object
      myFolder = (IDfFolder) m_session.getObject(m_clientX.getId(objectID));

      // Build the absolute filesystem folder path be appending the docbase path to the
      // file system root.
      String absFolderPath = myFilesystemDirectory +
          myFolder.getFolderPath(0).substring(myDocbaseFolder.length(), myFolder.getFolderPath(0).length());

      // Exoprt this docbase folder ising the Export Operation
      Operations.doExport(m_session, myFolder, absFolderPath);
    }
  }

  // This method exports a single docbase folder to a filesystem directory - it will
  // create the filesystem sbdirectory if necessary
  public static void doExport(IDfSession sess, IDfFolder exportFolder, String myFilesystemDirectory)
      throws DfException {
    IDfClientX m_clientx = new DfClientX();
    IDfExportOperation operation = m_clientx.getExportOperation();

    operation.setDestinationDirectory(myFilesystemDirectory);

    // Do not need to call createFolderPath, just createFolder as we know that the rest
    // of the path will already be there already.
    createFolder(myFilesystemDirectory);

    String qualification = "select * from dm_document where FOLDER(ID('" + exportFolder.getObjectId() + "'))";

    IDfCollection col = null; //create a collection for the images to be exported
    try {

      IDfQuery q = m_clientx.getQuery(); //Create query object
      q.setDQL(qualification); //Give it the query
      col = q.execute(sess, IDfQuery.DF_READ_QUERY); //Execute synchronously

      while (col.next()) {
        String name = col.getString("object_name");
        IDfFile destFile = m_clientx.getFile(myFilesystemDirectory + name);
        //check if the file has been exported (exists) to avoid another export
        if (! destFile.exists()) {
          //Create an IDfSysObject representing the object in the collection
          String id = col.getString("r_object_id");
          IDfId idObj = m_clientx.getId(id);
          IDfSysObject myObj = (IDfSysObject) sess.getObject(idObj);
          // add the IDfSysObject to the operation
          IDfExportNode node = (IDfExportNode) operation.add(myObj);
        }
      }

      //see sample: Operations- Execute and Check Errors
      Operations.executeOperation(operation);
    }
    finally {
      if (col != null)
        col.close();
    }
  }

  public static IDfCollection execQuery(IDfSession sess, String queryString) throws DfException {
    IDfCollection col = null; //For the result
    try {
      IDfQuery q = new DfQuery(); //Create query object
      q.setDQL(queryString); //Give it the query
      col = q.execute(sess, DfQuery.DF_READ_QUERY); //Execute synchronously
    } catch (DfException dfe) {
      System.out.println("\n" + dfe.toString());
    }
    return col;
  }

  public static void executeOperation(IDfOperation operation)
      throws DfException {
    //operation.setOperationMonitor( new Progress() );

    // Execute the operation
    boolean executeFlag = operation.execute();

    // Check if any errors occured during the execution of the operation
    if (executeFlag == false) {
      // Get the list of errors
      IDfList errorList = operation.getErrors();
      String message = "";
      IDfOperationError error = null;

      // Iterate through the errors and concatenate the error messages
      for (int i = 0; i < errorList.getCount(); i++) {
        error = (IDfOperationError) errorList.get(i);
        message += error.getMessage();
      }

      System.out.println("Errors:");
      System.out.println(message);
      // Create a DfException to report the errors
      //DfException e = new DfException();
      //e.setMessage(message);
      //throw e;
    }
  }//end: executeOperation(...)

  public static void createFolderPath(String myFilesystemDirectory) {

    StringBuffer bufFolderPath = new StringBuffer(64);

    String pathSeparator = System.getProperty("file.separator");
    java.util.StringTokenizer st = new java.util.StringTokenizer(myFilesystemDirectory, pathSeparator);

    while (st.hasMoreTokens()) {

      bufFolderPath.append(st.nextToken());
      bufFolderPath.append(pathSeparator);
      createFolder(bufFolderPath.toString());
    }
  }

  public static void createFolder(String myFilesystemDirectory) {
    //if the directory doesn't exist, make it
    //be sure to "import java.io.*;"
    System.out.println("About to create folder: " + myFilesystemDirectory);
    File file = new File(myFilesystemDirectory);
    try {
      if (!file.exists()) {
        file.mkdir();
        System.out.println("Created directory " + myFilesystemDirectory);
      }
    }
    catch (SecurityException e) {
      System.out.println("Can not create directory " + myFilesystemDirectory);
    }
  }


}//end: class Operations