/*
 * Created on May 28, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.documentum.devprog.deepexport;


import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfVirtualDocument;
import com.documentum.fc.common.DfId;
import com.documentum.operations.IDfExportOperation;

/**
 * @author dmadmin
 *
 *         To change the template for this generated type comment go to Window>Preferences>Java>Code Generation>Code and
 *         Comments
 */
public class TestExport {

  public static void main(String[] args) {
    try {

      LoginManager loginMgr = new LoginManager("apatil", "ap9hcs", "wdk52on");
      IDfClientX clientX = new DfClientX();
      IDfExportOperation export = clientX.getExportOperation();
      IDfSession session = loginMgr.getSession();
      IDfDocument doc = (IDfDocument) session.getObject(new DfId("0936fd188000ab8d"));
      if (doc.isVirtualDocument()) {
        IDfVirtualDocument vDoc = doc.asVirtualDocument("CURRENT", false);
        export.add(vDoc);
      } else {
        export.add(doc);
      }

      export.setDestinationDirectory("C:\\devprog");
      if (export.execute() == false) {
        System.out.println("export failed");
      } else {
        System.out.println("export succeeded");
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}