/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;
import com.monsanto.dctm.mapattributes.AttributeMapException;
import com.monsanto.dctm.mapattributes.MapAttributes;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: MapAttributes_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2006/09/04 14:18:02 $
 *
 * @author LAKENCH
 * @version $Revision: 1.13 $
 */
public class MapAttributes_UT extends TestCase {
    private static final String DOCBASE = "stltst03";
    private static final String USERNAME = "devl30";
    private static final String PASSWORD = "devl30";

    private MapAttributes mapAttributes;


    protected void setUp() throws Exception {
        super.setUp();
        mapAttributes = new MapAttributes();
        mapAttributes.setSessionManager(DFCSessionUtils.createSessionManager(DOCBASE, USERNAME, PASSWORD));
    }

    protected void tearDown() throws Exception {
        mapAttributes = null;
        super.tearDown();
    }

    public void testMapAttributesWithNullArguments() throws Exception {
        try {
            mapAttributes.mapAttributes(null, null);
        }
        catch (AttributeMapException e) {
            return;
        }
        fail("Expected AttributeMapException");
    }

    public void testMapAttributesWithBadDocbase() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_NOT_IN_MAP);
            mapAttributes.mapAttributes("this is a docbase name that will never exist", object);
        } catch (AttributeMapException e) {
            return;
        } finally {
            cleanup(session);
        }
        fail("Expected AttributeMapException");
    }

    public void testMapAttributesWithSourceObjectNotInSpreadsheetMap() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_NOT_IN_MAP);
            IDfTime origModifyDate = object.getModifyDate();
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            assertEquals("object should not be modified", origModifyDate, object.getModifyDate());
            assertFalse("object should not be \"dirty\"", object.isDirty());
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesWithSourceObjectNotInInitialFolder() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil.createTestDocbaseObject(session,
                                                                         TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                                                         TestObjectUtil.BAD_INITIAL_FOLDER);
            IDfTime origModifyDate = object.getModifyDate();
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            assertEquals("object should not be modified", origModifyDate, object.getModifyDate());
            assertFalse("object should not be \"dirty\"", object.isDirty());
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesWithSourceObjectInInitialFolder() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil.createTestDocbaseObject(session,
                                                                         TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                                                         TestObjectUtil.GOOD_INITIAL_FOLDER);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesInSubfolder() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                             TestObjectUtil.GOOD_INITIAL_FOLDER + "/" + TestObjectUtil.SUBFOLDER_NAME);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
            verifyObjectIsStillInSubfolderUnderFinalFolder(session, object);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesTwoObjectsSameNameDifferentSubfolders() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil.createTestDocbaseObject(session,
                                                                         TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                                                         TestObjectUtil.GOOD_INITIAL_FOLDER);
            IDfSysObject object2 = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                             TestObjectUtil.GOOD_INITIAL_FOLDER + "/" + TestObjectUtil.SUBFOLDER_NAME);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            mapAttributes.mapAttributes(DOCBASE, object2);
            verifyObjectWasUpdatedFromSpreadsheet(object);
            verifyObjectWasUpdatedFromSpreadsheet(object2);
            verifyObjectIsStillInSubfolderUnderFinalFolder(session, object2);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesObjectLinkedToDynamicFolders() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil.createTestDocbaseObject(session,
                                                                         TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                                                                         TestObjectUtil.GOOD_INITIAL_FOLDER);
            TestObjectUtil
                    .createHappyTestAttributeMapObjectWithFolderMapping(session,
                                                                        TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasLinkedToDynamicFolder(session, object);
        }
        finally {
            cleanup(session);
        }
    }

    private void verifyObjectWasLinkedToDynamicFolder(IDfSession session, IDfSysObject object) throws DfException {
        String objectPath = ((IDfFolder) session.getObject(object.getFolderId(0))).getString("r_folder_path");
        assertTrue("Object must be linked to subject folder",
                   objectPath.endsWith("/" + TestObjectUtil.NEW_TITLE_VALUE));
    }

    private void verifyObjectIsStillInSubfolderUnderFinalFolder(IDfSession session, IDfSysObject object2) throws
                                                                                                          DfException {
        String objectPath = ((IDfFolder) session.getObject(object2.getFolderId(0))).getString("r_folder_path");
        assertTrue("Relative path should stay the same", objectPath.endsWith("/" + TestObjectUtil.SUBFOLDER_NAME));
    }

    public void testMapAttributesMapFromSpreadsheet() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesLaunchServiceThroughMonDocsTBO() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            verifyObjectWasUpdatedFromSpreadsheet(object);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesExistingObjectDoesntChange() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            verifyObjectWasUpdatedFromSpreadsheet(object);
            object.setObjectName(TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            object.setString(TestObjectUtil.ATTR_TITLE, TestObjectUtil.ORIGINAL_TITLE_VALUE);
            object.setKeywords(0, TestObjectUtil.ORIG_KEYWORD_ONE);
            object.setKeywords(1, TestObjectUtil.ORIG_KEYWORD_TWO);
            object.setBoolean(TestObjectUtil.ATTR_BOOLEAN, false);
            object.setInt(TestObjectUtil.ATTR_INT, TestObjectUtil.ORIGINAL_INTEGER_VALUE);
            object.setTime(TestObjectUtil.ATTR_TIME, TestObjectUtil.TEST_TIME);
            object.save();
            verifyObjectWasNotUpdated(object, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesObjectAssociatedWithBlankMapRowDoesntChange() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_BLANK_ROW);
            verifyObjectWasNotUpdated(object, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_BLANK_ROW);
        }
        finally {
            cleanup(session);
        }
    }

    public void testMapAttributesObjectAssociatedWithSomeBlanksInRowIsUpdated() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MIXED_ROW);
            verifyMixedObjectWasUpdated(object);
        } finally {
            cleanup(session);
        }
    }

    public void testMapAttributesObjectAssociatedWithUndefinedCellsRowIsUpdated() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_IN_UNDEFINED_ROW);
            verifyMixedObjectWasUpdated(object);
        } finally {
            cleanup(session);
        }
    }

    public void testMapAttributesObjectWithLongAttributeValueUpdated() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_IN_LONG_ATTR_ROW);
            verifyLongAttributeValueObjectWasUpdated(object);
        } finally {
            cleanup(session);
        }
    }

    public void testHandleBadAttributeInSpreadsheet() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            TestObjectUtil.createBadTestAttributeMapObject(session);
            mapAttributes.mapAttributes(DOCBASE, object);
        }
        catch (AttributeMapException e) {
            return;
        }
        finally {
            cleanup(session);
        }
        fail("Expected AttributeMapException");
    }

    public void testLookupAttributeNameInDataDictionary() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            assertEquals("string_single should be updated", TestObjectUtil.SINGLE_KEYWORD_VALUE,
                         object.getString("string_single"));
        }
        finally {
            cleanup(session);
        }
    }

    public void testAlternateRepeatingSeparatorInSpreadsheet() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR_ALT);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
        }
        finally {
            cleanup(session);
        }
    }

    public void testImportReportObjectIsCreatedWithAppropriateNameAndLocation() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
            String mapObjectFolder = ((IDfFolder) session.getObject(attributeMapObject.getFolderId(0)))
                    .getString("r_folder_path");
            String mapObjectName = attributeMapObject.getObjectName();
            Date mapObjectModifyDate = attributeMapObject.getModifyDate().getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String formattedMapObjectModifyDate = dateFormat.format(mapObjectModifyDate);
            IDfPersistentObject bulkImportReportObject = session.getObjectByQualification(
                    "dm_sysobject where object_name = 'BulkImportReport for " + mapObjectName +
                    formattedMapObjectModifyDate +
                    "' and FOLDER('" + mapObjectFolder + "')");
            assertNotNull("bulkImportReportObject should not be null", bulkImportReportObject);
        }
        finally {
            cleanup(session);
        }
    }

    public void testImportReportEntryCreatedForMappedObject() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyObjectWasUpdatedFromSpreadsheet(object);
            verifyEntryForTestObjectInImportReport(session, attributeMapObject, object);
            HSSFRow importReportRow = getImportReportRowForObject(session, attributeMapObject, object);
            assertEquals("Import Report should indicate attributes were mapped",
                         importReportRow.getCell((short) 5).getStringCellValue(), "Yes");
        }
        finally {
            cleanup(session);
        }
    }

    public void testImportReportEntryCreatedForNonMappedObject() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_NOT_IN_MAP);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyEntryForTestObjectInImportReport(session, attributeMapObject, object);
            HSSFRow importReportRow = getImportReportRowForObject(session, attributeMapObject, object);
            assertEquals("Import Report should indicate attributes were not mapped",
                         importReportRow.getCell((short) 5).getStringCellValue(), "No");
        }
        finally {
            cleanup(session);
        }
    }

    public void testImportReportEntryForMappedObjectIsValid() throws Exception {
        IDfSession session = null;
        try {
            mapAttributes.getSessionManager().beginTransaction();
            session = mapAttributes.getSession(DOCBASE);
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            mapAttributes.mapAttributes(DOCBASE, object);
            verifyEntryForTestObjectInImportReport(session, attributeMapObject, object);
            verifyImportReportObjectOnlyHasOneVersion(session, attributeMapObject);
            verifyImportReportHeaderRowSetProperly(session, attributeMapObject);
            verifyImportReportRowForMappedObjectSetProperly(session, attributeMapObject, object);
        } finally {
            cleanup(session);
        }
    }

    private void verifyImportReportHeaderRowSetProperly(IDfSession session, IDfSysObject attributeMapObject)
            throws DfException {
        HSSFRow headerRow = getImportReportSheet(session, attributeMapObject).getRow(0);
        verifyImportReportHeaderRowSetProperly(headerRow);
    }

    private void verifyImportReportRowForMappedObjectSetProperly(IDfSession session, IDfSysObject attributeMapObject,
                                                                 IDfSysObject object)
            throws DfException, ParseException {


        HSSFRow headerRow = getImportReportSheet(session, attributeMapObject).getRow(0);


        HSSFRow importReportRow = getImportReportRowForObject(session, attributeMapObject, object);
        assertTrue("timestamp should be formatted as a date", isDateCell(importReportRow.getCell((short) 0),
                                                                         getImportReportWorkbook(session,
                                                                                                 attributeMapObject)));
        assertEquals("object id column wasn't set properly", object.getObjectId().getId(),
                     importReportRow.getCell((short) 1).getStringCellValue());
        assertEquals("original object name with path column wasn't set properly",
                     TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                     importReportRow.getCell((short) 2).getStringCellValue());
        assertEquals("name of map file columns wasn't set properly", attributeMapObject.getObjectName(),
                     importReportRow.getCell((short) 3).getStringCellValue());
        assertEquals("initial import path wasn't set properly", attributeMapObject.getString("init_folder_name"),
                     importReportRow.getCell((short) 4).getStringCellValue());
        assertEquals("attributes are mapped should indicate yes", "Yes",
                     importReportRow.getCell((short) 5).getStringCellValue());
        assertEquals("final root path wasn't set properly", attributeMapObject.getString("final_folder_name"),
                     importReportRow.getCell((short) 6).getStringCellValue());


        assertEquals("boolean attribute column wasn't set properly", true,
                     getCellForAttrName(TestObjectUtil.ATTR_BOOLEAN, headerRow, importReportRow).getBooleanCellValue());
        assertEquals("object name attribute column wasn't set properly", TestObjectUtil.NEW_OBJECT_NAME_VALUE,
                     getCellForAttrName(TestObjectUtil.ATTR_OBJECT_NAME, headerRow,
                                        importReportRow).getStringCellValue());
        assertEquals("integer attribute column wasn't set properly", TestObjectUtil.NEW_INTEGER_VALUE,
                     getCellForAttrName(TestObjectUtil.ATTR_INT, headerRow, importReportRow).getNumericCellValue(), 0);
        assertEquals("keywords attribute column wasn't set properly",
                     TestObjectUtil.KEYWORD_ONE + TestObjectUtil.REPEATING_VALUE_SEPARATOR + TestObjectUtil.KEYWORD_TWO,
                     getCellForAttrName(TestObjectUtil.ATTR_KEYWORDS, headerRow, importReportRow).getStringCellValue());
        String dateTimeFormat = "M/d/yy h:mm a";
        SimpleDateFormat df = new SimpleDateFormat(dateTimeFormat, Locale.getDefault());
        Date dateAttributeValue = df.parse(TestObjectUtil.TEST_DATE_STRING);
        assertEquals("date attribute column wasn't set properly", dateAttributeValue,
                     getCellForAttrName(TestObjectUtil.ATTR_TIME, headerRow, importReportRow).getDateCellValue());
        assertEquals(TestObjectUtil.ATTR_TITLE + " attribute column wasn't set properly",
                     TestObjectUtil.NEW_TITLE_VALUE,
                     getCellForAttrName(TestObjectUtil.ATTR_TITLE, headerRow, importReportRow).getStringCellValue());
        assertEquals("Single Valued String column wasn't set properly", TestObjectUtil.SINGLE_KEYWORD_VALUE,
                     getCellForAttrName("Single Valued String", headerRow, importReportRow).getStringCellValue());

    }

    private void verifyImportReportObjectOnlyHasOneVersion(IDfSession session, IDfSysObject attributeMapObject) throws
                                                                                                                DfException {
        IDfSysObject importReportObject = getImportReportObject(session, attributeMapObject);
        assertTrue("import report object version should be 1.0",
                   importReportObject.getVersionLabels().getImplicitVersionLabel().equals("1.0"));
    }

    private void verifyImportReportHeaderRowSetProperly(HSSFRow headerRow) {
        assertEquals("timestamp col heading wasn't set properly", "Timestamp",
                     headerRow.getCell((short) 0).getStringCellValue());
        assertEquals("object id col heading wasn't set properly", "Object ID",
                     headerRow.getCell((short) 1).getStringCellValue());
        assertEquals("object name and path col heading wasn't set properly", "Name and Path",
                     headerRow.getCell((short) 2).getStringCellValue());
        assertEquals("map file used col heading wasn't set properly", "Map File Used",
                     headerRow.getCell((short) 3).getStringCellValue());
        assertEquals("initial import folder col heading wasn't set properly", "Initial Import Path",
                     headerRow.getCell((short) 4).getStringCellValue());
        assertEquals("were attributes mapped col heading wasn't set properly", "Attributes Mapped?",
                     headerRow.getCell((short) 5).getStringCellValue());
        assertEquals("final root path col heading wasn't set properly", "Final Root Path",
                     headerRow.getCell((short) 6).getStringCellValue());
        assertTrue("boolean attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_BOOLEAN, headerRow));
        assertTrue("object name attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_OBJECT_NAME, headerRow));
        assertTrue("integer attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_INT, headerRow));
        assertTrue("keywords attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_KEYWORDS, headerRow));
        assertTrue("date attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_TIME, headerRow));
        assertTrue(TestObjectUtil.ATTR_TITLE + " attribute col heading wasn't set properly",
                   doesColumnHeadingExist(TestObjectUtil.ATTR_TITLE, headerRow));
        assertTrue("Single Valued String attribute col heading wasn't set properly",
                   doesColumnHeadingExist("Single Valued String", headerRow));
    }

    private HSSFCell getCellForAttrName(String attrName, HSSFRow headerRow, HSSFRow dataRow) {
        Iterator cells = headerRow.cellIterator();
        while (cells.hasNext()) {
            HSSFCell cell = (HSSFCell) cells.next();
            String cellValue = cell.getStringCellValue();
            if (cellValue.equals(attrName)) return dataRow.getCell(cell.getCellNum());
        }
        return null;
    }

    private boolean doesColumnHeadingExist(String attrBoolean, HSSFRow headerRow) {
        Iterator cells = headerRow.cellIterator();
        while (cells.hasNext()) {
            String cellValue = ((HSSFCell) cells.next()).getStringCellValue();
            if (cellValue.equals(attrBoolean)) return true;
        }
        return false;
    }

    private boolean isDateCell(HSSFCell cell, HSSFWorkbook workbook) {
        String formatString = workbook.createDataFormat().getFormat(cell.getCellStyle().getDataFormat());
        return HSSFDateUtil.isCellDateFormatted(cell) ||
               Pattern.compile("[mM]+\\/[dD]+\\/[yY]+|[hH]+:[mM]+").matcher(formatString).find();
    }

    private void verifyEntryForTestObjectInImportReport(IDfSession session, IDfSysObject attributeMapObject,
                                                        IDfSysObject object) throws
                                                                             DfException {
        HSSFRow detailRow = getImportReportRowForObject(session, attributeMapObject, object);
        assertNotNull("I should have found a BulkImportReport entry for the test object", detailRow);
    }

    private HSSFRow getImportReportRowForObject(IDfSession session, IDfSysObject attributeMapObject,
                                                IDfSysObject object) throws
                                                                     DfException {
        Iterator rows = getImportReportSheet(session, attributeMapObject).rowIterator();
        HSSFRow detailRow = null;
        while (rows.hasNext()) {
            HSSFRow row = (HSSFRow) rows.next();
            if (row.getCell((short) 1).getStringCellValue().equals(object.getObjectId().getId())) {
                detailRow = row;
                break;
            }
        }
        return detailRow;
    }

    private HSSFSheet getImportReportSheet(IDfSession session, IDfSysObject attributeMapObject) throws DfException {
        HSSFWorkbook importReportWorkbook = getImportReportWorkbook(session, attributeMapObject);
        return importReportWorkbook.getSheetAt(0);
    }

    private HSSFWorkbook getImportReportWorkbook(IDfSession session, IDfSysObject attributeMapObject) throws
                                                                                                      DfException {
        IDfSysObject bulkImportReportObject = getImportReportObject(session, attributeMapObject);
        HSSFWorkbook importReportWorkbook = null;
        try {
            importReportWorkbook = new HSSFWorkbook(new POIFSFileSystem(bulkImportReportObject.getContent()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return importReportWorkbook;
    }

    private IDfSysObject getImportReportObject(IDfSession session, IDfSysObject attributeMapObject) throws DfException {
        String mapObjectFolder = ((IDfFolder) session.getObject(attributeMapObject.getFolderId(0)))
                .getString("r_folder_path");
        String mapObjectName = attributeMapObject.getObjectName();
        Date mapObjectModifyDate = attributeMapObject.getModifyDate().getDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String formattedMapObjectModifyDate = dateFormat.format(mapObjectModifyDate);
        IDfSysObject bulkImportReportObject = (IDfSysObject) session.getObjectByQualification(
                "dm_sysobject where object_name = 'BulkImportReport for " + mapObjectName +
                formattedMapObjectModifyDate +
                "' and FOLDER('" + mapObjectFolder + "')");
        assertNotNull("bulkImportReportObject should not be null", bulkImportReportObject);
        return bulkImportReportObject;
    }

    private void cleanup(IDfSession session) throws DfServiceException {
        mapAttributes.releaseSession(session);
        mapAttributes.getSessionManager().abortTransaction();
    }

    private void verifyObjectWasUpdatedFromSpreadsheet(IDfSysObject object) throws DfException {
        assertEquals(TestObjectUtil.ATTR_TIME + " should be updated",
                     new DfTime(TestObjectUtil.TEST_DATE_STRING, DfTime.DF_TIME_PATTERN44).asString(
                             DfTime.DF_TIME_PATTERN44),
                     object.getTime(TestObjectUtil.ATTR_TIME).asString(DfTime.DF_TIME_PATTERN44));
        assertEquals(TestObjectUtil.ATTR_INT + " should be updated", TestObjectUtil.NEW_INTEGER_VALUE,
                     object.getInt(TestObjectUtil.ATTR_INT));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated",
                     TestObjectUtil.KEYWORD_ONE + TestObjectUtil.REPEATING_VALUE_SEPARATOR + TestObjectUtil.KEYWORD_TWO,
                     object.getAllRepeatingStrings(TestObjectUtil.ATTR_KEYWORDS,
                                                   TestObjectUtil.REPEATING_VALUE_SEPARATOR));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_ONE,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 0));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_TWO,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 1));
        assertEquals(
                TestObjectUtil.ATTR_OBJECT_NAME + " should be updated", TestObjectUtil.NEW_OBJECT_NAME_VALUE,
                object.getString(TestObjectUtil.ATTR_OBJECT_NAME));
        assertEquals(TestObjectUtil.ATTR_TITLE + " should be updated", TestObjectUtil.NEW_TITLE_VALUE,
                     object.getString(TestObjectUtil.ATTR_TITLE));
        String objectPath = ((IDfFolder) object.getSession().getObject(object.getFolderId(0)))
                .getString("r_folder_path");
        assertTrue("Primary folder link should be updated", objectPath.startsWith(
                object.getSession().getUser(object.getSession().getLoginUserName()).getDefaultFolder() + TestObjectUtil
                        .FINAL_FOLDER));
        assertFalse("object should not be \"dirty\"", object.isDirty());
    }

    private void verifyMixedObjectWasUpdated(IDfSysObject object) throws DfException {
        assertEquals(TestObjectUtil.ATTR_TIME + " should be updated",
                     new DfTime(TestObjectUtil.TEST_DATE_STRING, DfTime.DF_TIME_PATTERN44).asString(
                             DfTime.DF_TIME_PATTERN44),
                     object.getTime(TestObjectUtil.ATTR_TIME).asString(DfTime.DF_TIME_PATTERN44));
        assertEquals(TestObjectUtil.ATTR_INT + " should be not be updated", TestObjectUtil.ORIGINAL_INTEGER_VALUE,
                     object.getInt(TestObjectUtil.ATTR_INT));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated",
                     TestObjectUtil.KEYWORD_ONE + TestObjectUtil.REPEATING_VALUE_SEPARATOR + TestObjectUtil.KEYWORD_TWO,
                     object.getAllRepeatingStrings(TestObjectUtil.ATTR_KEYWORDS,
                                                   TestObjectUtil.REPEATING_VALUE_SEPARATOR));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_ONE,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 0));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_TWO,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 1));
        assertEquals(
                TestObjectUtil.ATTR_OBJECT_NAME + " should be updated", TestObjectUtil.NEW_OBJECT_NAME_VALUE,
                object.getString(TestObjectUtil.ATTR_OBJECT_NAME));
        assertEquals(TestObjectUtil.ATTR_TITLE + " should not be updated", TestObjectUtil.ORIGINAL_TITLE_VALUE,
                     object.getString(TestObjectUtil.ATTR_TITLE));
        String objectPath = ((IDfFolder) object.getSession().getObject(object.getFolderId(0)))
                .getString("r_folder_path");
        assertTrue("Primary folder link should be updated", objectPath.startsWith(
                object.getSession().getUser(object.getSession().getLoginUserName()).getDefaultFolder() + TestObjectUtil
                        .FINAL_FOLDER));
        assertFalse("object should not be \"dirty\"", object.isDirty());

    }

    private void verifyLongAttributeValueObjectWasUpdated(IDfSysObject object) throws DfException {
        assertEquals(TestObjectUtil.ATTR_TIME + " should be updated",
                     new DfTime(TestObjectUtil.TEST_DATE_STRING, DfTime.DF_TIME_PATTERN44).asString(
                             DfTime.DF_TIME_PATTERN44),
                     object.getTime(TestObjectUtil.ATTR_TIME).asString(DfTime.DF_TIME_PATTERN44));
        assertEquals(TestObjectUtil.ATTR_INT + " should be updated", TestObjectUtil.NEW_INTEGER_VALUE,
                     object.getInt(TestObjectUtil.ATTR_INT));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated",
                     TestObjectUtil.KEYWORD_ONE + TestObjectUtil.REPEATING_VALUE_SEPARATOR + TestObjectUtil.KEYWORD_TWO,
                     object.getAllRepeatingStrings(TestObjectUtil.ATTR_KEYWORDS,
                                                   TestObjectUtil.REPEATING_VALUE_SEPARATOR));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_ONE,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 0));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should be updated", TestObjectUtil.KEYWORD_TWO,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 1));
        assertEquals(
                TestObjectUtil.ATTR_OBJECT_NAME + " should be updated", TestObjectUtil.NEW_OBJECT_NAME_VALUE,
                object.getString(TestObjectUtil.ATTR_OBJECT_NAME));
        assertEquals(TestObjectUtil.ATTR_TITLE + " should not be truncated", TestObjectUtil.LONG_TITLE_VALUE,
                     object.getString(TestObjectUtil.ATTR_TITLE));
        String objectPath = ((IDfFolder) object.getSession().getObject(object.getFolderId(0)))
                .getString("r_folder_path");
        assertTrue("Primary folder link should be updated", objectPath.startsWith(
                object.getSession().getUser(object.getSession().getLoginUserName()).getDefaultFolder() + TestObjectUtil
                        .FINAL_FOLDER));
        assertFalse("object should not be \"dirty\"", object.isDirty());

    }


    private void verifyObjectWasNotUpdated(IDfSysObject object, String origObjNameValue) throws DfException {
        assertEquals(TestObjectUtil.ATTR_TIME + " should not be updated", TestObjectUtil.TEST_TIME,
                     object.getTime(TestObjectUtil.ATTR_TIME));
        assertEquals(TestObjectUtil.ATTR_INT + " should be not be updated", TestObjectUtil.ORIGINAL_INTEGER_VALUE,
                     object.getInt(TestObjectUtil.ATTR_INT));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should not be updated",
                     TestObjectUtil.ORIG_KEYWORD_ONE + TestObjectUtil.REPEATING_VALUE_SEPARATOR + TestObjectUtil
                             .ORIG_KEYWORD_TWO,
                     object.getAllRepeatingStrings(TestObjectUtil.ATTR_KEYWORDS,
                                                   TestObjectUtil.REPEATING_VALUE_SEPARATOR));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should not be updated", TestObjectUtil.ORIG_KEYWORD_ONE,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 0));
        assertEquals(TestObjectUtil.ATTR_KEYWORDS + " should not be updated", TestObjectUtil.ORIG_KEYWORD_TWO,
                     object.getRepeatingString(TestObjectUtil.ATTR_KEYWORDS, 1));
        assertEquals(TestObjectUtil.ATTR_OBJECT_NAME + " should not be updated", origObjNameValue,
                     object.getString(TestObjectUtil.ATTR_OBJECT_NAME));
        assertEquals(TestObjectUtil.ATTR_TITLE + " should not be updated", TestObjectUtil.ORIGINAL_TITLE_VALUE,
                     object.getString(TestObjectUtil.ATTR_TITLE));
        assertFalse("object should not be \"dirty\"", object.isDirty());
    }
}