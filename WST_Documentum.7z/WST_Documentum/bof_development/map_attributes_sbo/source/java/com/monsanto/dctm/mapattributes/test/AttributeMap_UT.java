/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes.test;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.monsanto.dctm.mapattributes.AttributeMap;
import com.monsanto.dctm.mapattributes.AttributeMapException;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: AttributeMap_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 21:18:41 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AttributeMap_UT extends TestCase {
    private static final String DOCBASE = "stltst03";
    private static final String USERNAME = "devl30";
    private static final String PASSWORD = "devl30";

    private IDfSessionManager sessionManager;

    protected void setUp() throws Exception {
        super.setUp();
        sessionManager = DFCSessionUtils.createSessionManager(DOCBASE, USERNAME, PASSWORD);
    }

    protected void tearDown() throws Exception {
        sessionManager = null;
        super.tearDown();
    }

    public void testAttributeMapWithNullArguments() throws Exception {
        try {
            new AttributeMap(null, null);
        } catch (AttributeMapException e) {
            return;
        }
        fail("Expected AttributeMapException");
    }

    public void testAttributeMapWithNullObject() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            new AttributeMap(session, null);
        } catch (AttributeMapException e) {
            return;
        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }
        fail("Expected AttributeMapException");
    }

    public void testNoAttributeMap() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            AttributeMap attributeMap = new AttributeMap(session, object);
            assertFalse("there should not be an attrbibute map", attributeMap.isAssociatedWithMapObj());
        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }
    }

    public void testAttributeMapWithBadAttributeName() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            TestObjectUtil.createBadTestAttributeMapObject(session);
            new AttributeMap(session, object);
        } catch (AttributeMapException e) {
            return;
        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }
        fail("Expected AttributeMapException");
    }

    public void testObjectShouldBeAssociatedWithAttributeMapButNotInIt() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_NOT_IN_MAP);
            TestObjectUtil.createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            AttributeMap attributeMap = new AttributeMap(session, object);
            assertTrue("this should be associated with a map object", attributeMap.isAssociatedWithMapObj());
            assertFalse("this object should not be in the map", attributeMap.isInAttributeMap());
        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }
    }

    public void testObjectInAttributeMap() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            String defaultFolder = session.getUser(session.getLoginUserName()).getDefaultFolder();
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            Date mapObjectModifyDate = attributeMapObject.getModifyDate().getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String formattedMapObjModifyDate = dateFormat.format(mapObjectModifyDate);
            String mapObjFolderName = ((IDfFolder) session.getObject(attributeMapObject.getFolderId(0)))
                    .getString("r_folder_path");
            AttributeMap attributeMap = new AttributeMap(session, object);
            assertEquals("object name and orig object name from AttributeMap should be the same",
                         object.getObjectName(), attributeMap.getOrigDfSysObjectName());
            assertEquals("repeating value separator wasn't set properly", TestObjectUtil.REPEATING_VALUE_SEPARATOR,
                         attributeMap.getRepeatingValueSeparator());
            assertEquals("initial folder name wasn't set properly",
                         defaultFolder + TestObjectUtil.GOOD_INITIAL_FOLDER, attributeMap.getInitialFolderName());
            assertEquals("final folder name wasn't set properly", defaultFolder + TestObjectUtil.FINAL_FOLDER,
                         attributeMap.getFinalFolderName());
            assertEquals("target object name wasn't set properly", TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP,
                         attributeMap.getTargetObjectName());
            assertEquals("formatted map obj modified date wasn't set properly", formattedMapObjModifyDate,
                         attributeMap.getFormattedMapObjModifyDate());
            assertEquals("map obj folder name wasn't set properly", mapObjFolderName,
                         attributeMap.getMapObjFolderName());
            assertEquals("map obj name wasn't set properly", attributeMapObject.getObjectName(),
                         attributeMap.getMapObjectName());
            assertTrue("this should be associated with a map object", attributeMap.isAssociatedWithMapObj());
            assertTrue("this object should be in the map", attributeMap.isInAttributeMap());
            assertEquals("test map object and map obj from AttributeMap should be the same",
                         attributeMapObject.getObjectId().getId(), attributeMap.getAttrMapObj().getObjectId().getId());
            assertTrue("attribute names iterator contents should match spreadsheet contents",
                       verifyAttributeNamesMatchesSpreadsheet(attributeMap));
            assertTrue("translated attribute names iterator contents should match data dictionary contents",
                       verifyTranslatedAttributeNamesMatchesDataDictionary(attributeMap));

        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }

    }

    public void testLongAttributeValueDoesNotTruncateInMap() throws Exception {
        sessionManager.beginTransaction();
        IDfSession session = sessionManager.getSession(DOCBASE);
        try {
            String defaultFolder = session.getUser(session.getLoginUserName()).getDefaultFolder();
            IDfSysObject object = TestObjectUtil
                    .createTestDocbaseObject(session, TestObjectUtil.ORIG_OBJ_NAME_IN_LONG_ATTR_ROW);
            IDfSysObject attributeMapObject = TestObjectUtil
                    .createHappyTestAttributeMapObject(session, TestObjectUtil.REPEATING_VALUE_SEPARATOR);
            Date mapObjectModifyDate = attributeMapObject.getModifyDate().getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String formattedMapObjModifyDate = dateFormat.format(mapObjectModifyDate);
            String mapObjFolderName = ((IDfFolder) session.getObject(attributeMapObject.getFolderId(0)))
                    .getString("r_folder_path");
            AttributeMap attributeMap = new AttributeMap(session, object);
            assertEquals(TestObjectUtil.ATTR_TITLE + " value should not be truncated", TestObjectUtil.LONG_TITLE_VALUE,
                         attributeMap.getAttributeValue(TestObjectUtil.ATTR_TITLE));
            assertEquals("object name and orig object name from AttributeMap should be the same",
                         object.getObjectName(), attributeMap.getOrigDfSysObjectName());
            assertEquals("repeating value separator wasn't set properly", TestObjectUtil.REPEATING_VALUE_SEPARATOR,
                         attributeMap.getRepeatingValueSeparator());
            assertEquals("initial folder name wasn't set properly",
                         defaultFolder + TestObjectUtil.GOOD_INITIAL_FOLDER, attributeMap.getInitialFolderName());
            assertEquals("final folder name wasn't set properly", defaultFolder + TestObjectUtil.FINAL_FOLDER,
                         attributeMap.getFinalFolderName());
            assertEquals("target object name wasn't set properly",
                         TestObjectUtil.ORIG_OBJ_NAME_IN_LONG_ATTR_ROW,
                         attributeMap.getTargetObjectName());
            assertEquals("formatted map obj modified date wasn't set properly", formattedMapObjModifyDate,
                         attributeMap.getFormattedMapObjModifyDate());
            assertEquals("map obj folder name wasn't set properly", mapObjFolderName,
                         attributeMap.getMapObjFolderName());
            assertEquals("map obj name wasn't set properly", attributeMapObject.getObjectName(),
                         attributeMap.getMapObjectName());
            assertTrue("this should be associated with a map object", attributeMap.isAssociatedWithMapObj());
            assertTrue("this object should be in the map", attributeMap.isInAttributeMap());
            assertEquals("test map object and map obj from AttributeMap should be the same",
                         attributeMapObject.getObjectId().getId(), attributeMap.getAttrMapObj().getObjectId().getId());
            assertTrue("attribute names iterator contents should match spreadsheet contents",
                       verifyAttributeNamesMatchesSpreadsheet(attributeMap));
            assertTrue("translated attribute names iterator contents should match data dictionary contents",
                       verifyTranslatedAttributeNamesMatchesDataDictionary(attributeMap));

        } finally {
            sessionManager.release(session);
            sessionManager.abortTransaction();
        }

    }

    private boolean verifyTranslatedAttributeNamesMatchesDataDictionary(AttributeMap attributeMap) {
        Iterator translatedAttributeNames = attributeMap.getTranslatedAttributeNames();
        List attributeNamesList = new ArrayList();
        while (translatedAttributeNames.hasNext()) {
            String attributeName = (String) translatedAttributeNames.next();
            attributeNamesList.add(attributeName);
        }
        List attributeNamesFromDataDictionaryList = new ArrayList();
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_BOOLEAN);
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_INT);
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_KEYWORDS);
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_OBJECT_NAME);
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_TITLE);
        attributeNamesFromDataDictionaryList.add(TestObjectUtil.ATTR_TIME);
        attributeNamesFromDataDictionaryList.add("string_single");

        return attributeNamesFromDataDictionaryList.containsAll(attributeNamesList) &&
               attributeNamesList.containsAll(attributeNamesFromDataDictionaryList);

    }

    private boolean verifyAttributeNamesMatchesSpreadsheet(AttributeMap attributeMap) {
        Iterator attributeNames = attributeMap.getAttributeNames();
        List attributeNamesList = new ArrayList();
        while (attributeNames.hasNext()) {
            String attributeName = (String) attributeNames.next();
            attributeNamesList.add(attributeName);
        }

        List attributeNamesFromSpreadsheetList = new ArrayList();
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_BOOLEAN);
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_INT);
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_KEYWORDS);
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_OBJECT_NAME);
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_TITLE);
        attributeNamesFromSpreadsheetList.add(TestObjectUtil.ATTR_TIME);
        attributeNamesFromSpreadsheetList.add("Single Valued String");

        return attributeNamesFromSpreadsheetList.containsAll(attributeNamesList) &&
               attributeNamesList.containsAll(attributeNamesFromSpreadsheetList);
    }

}