package com.monsanto.dctm.mapattributes;/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.fc.client.IDfService;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;

import java.util.Map;

/**
 * Filename:    $RCSfile: IMapAttributes.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2006/09/04 13:07:19 $
 *
 * @author LAKENCH
 * @version $Revision: 1.4 $
 */
public interface IMapAttributes extends IDfService {

  public void mapAttributes(String docbase, IDfSysObject object) throws AttributeMapException, DfException;

}