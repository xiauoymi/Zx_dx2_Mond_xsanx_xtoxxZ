/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: MapAttributes.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date:
 * 2006/09/04 13:07:19 $
 *
 * @author LAKENCH
 * @version $Revision: 1.9 $
 */
public class MapAttributes extends DfService implements IMapAttributes {

  public void mapAttributes(String docbase, IDfSysObject object) throws AttributeMapException {
    if (object == null) throw new AttributeMapException(new IllegalArgumentException("object cannot be null"));
    IDfSession session = null;
    try {
      session = getSession(docbase);
      AttributeMap attributeMap = new AttributeMap(session, object);
      if (attributeMap.isAssociatedWithMapObj()) {
        addBulkImportReportRow(getBulkImportReportObject(docbase, attributeMap), object, attributeMap);
        if (!attributeMap.isInAttributeMap()) {
          updateBulkImportReportRowForNonMappedObject(docbase, object, attributeMap);
          return;
        }
        Iterator attributes = attributeMap.getTranslatedAttributeNames();
        while (attributes.hasNext()) {
          String attributeName = (String) attributes.next();
          String attributeValue = attributeMap.getAttributeValue(attributeName);
          List attributeValueList = prepareMapValues(object, attributeName, attributeValue,
              attributeMap.getRepeatingValueSeparator());
          setObjectAttributeValues(attributeValueList, object, attributeName);
        }
        linkObjectToFinalFolder(docbase, object, attributeMap);
        updateBulkImportReportRowForMappedObject(docbase, object, attributeMap);
        unlinkObjectFromInitialFolder(object);
        object.save();
      }

    }
    catch (DfIdentityException e) {
      throw new AttributeMapException("Bad docbase specified: " + docbase, e);
    }
    catch (DfException e) {
      throw new AttributeMapException("Bad attribute in map: " + e.getMessage(), e);
    } finally {
      if (session != null) getSessionManager().release(session);
    }
  }

  private void updateBulkImportReportRowForNonMappedObject(String docbase, IDfSysObject object,
                                                           AttributeMap attributeMap) throws
      DfException {
    IDfSysObject bulkImportReportObject = getBulkImportReportObject(docbase, attributeMap);
    updateImportReportRowAttrMappedColumn(bulkImportReportObject, object, "No");

  }

  private void updateBulkImportReportRowForMappedObject(String docbase, IDfSysObject object,
                                                        AttributeMap attributeMap) throws
      DfException,
      AttributeMapException {
    IDfSysObject bulkImportReportObject = getBulkImportReportObject(docbase, attributeMap);
    updateImportReportRowAttrMappedColumn(bulkImportReportObject, object, "Yes");
    updateImportReportRowFinalRootPathColumn(bulkImportReportObject, object, attributeMap.getFinalFolderName());
    updateImportReportMappedValueColumns(bulkImportReportObject, object, attributeMap);
  }

  private void updateImportReportMappedValueColumns(IDfSysObject bulkImportReportObject, IDfSysObject object,
                                                    AttributeMap attributeMap)
      throws DfException, AttributeMapException {
    bulkImportReportObject.checkout();
    HSSFWorkbook importReportWorkbook = null;
    try {
      importReportWorkbook = new HSSFWorkbook(new POIFSFileSystem(bulkImportReportObject.getContent()));
    } catch (IOException e) {
      e.printStackTrace();
    }
    HSSFSheet importReportSheet = importReportWorkbook.getSheetAt(0);
    HSSFRow mappedObjectRow = getMatchingBulkImportReportRow(importReportSheet, object);
    if (mappedObjectRow != null) {
      List attributeColNames = createColumnHeadingList();
      Iterator attributeNames = attributeMap.getAttributeNames();
      short cellNum = 7;
      while (attributeNames.hasNext()) {
        String attributeName = (String) attributeNames.next();
        attributeColNames.add(attributeName);
        attributeName = attributeMap.translateAttributeNameThroughDataDictionary(object, attributeName);
        setImportReportAttributeValueColumn(mappedObjectRow, cellNum, object, attributeName);
        cellNum++;
      }
      addHeaderRow(importReportWorkbook, attributeColNames);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      try {
        importReportWorkbook.write(byteArrayOutputStream);
      } catch (IOException e) {
        e.printStackTrace();
      }
      bulkImportReportObject.setContent(byteArrayOutputStream);
      bulkImportReportObject.save();
    } else {
      bulkImportReportObject.cancelCheckout();
    }
  }

  private void setImportReportAttributeValueColumn(HSSFRow mappedObjectRow, short cellNum, IDfSysObject object,
                                                   String attributeName)
      throws DfException {
    int attrDataType = object.getAttrDataType(attributeName);
    HSSFCell mappedObjectCol = mappedObjectRow.createCell(cellNum);
    String value = object.getValue(attributeName).asString();
    if (value == null || value.length() == 0 || value.startsWith("null")) {
      mappedObjectCol.setCellValue("");
      return;
    }
    if (object.isAttrRepeating(attributeName)) {
      mappedObjectCol.setCellValue(object.getAllRepeatingStrings(attributeName, ", "));
    } else {
      switch (attrDataType) {
        case IDfType.DF_BOOLEAN:
          mappedObjectCol.setCellValue(object.getBoolean(attributeName));
          break;
        case IDfType.DF_DOUBLE:
          mappedObjectCol.setCellValue(object.getDouble(attributeName));
          break;
        case IDfType.DF_INTEGER:
          mappedObjectCol.setCellValue(Double.parseDouble(Integer.toString(object.getInt(attributeName))));
          break;
        case IDfType.DF_STRING:
          mappedObjectCol.setCellValue(object.getString(attributeName));
          break;
        case IDfType.DF_TIME:
          mappedObjectCol.setCellValue(object.getTime(attributeName).getDate());
      }
    }
  }

  private void updateImportReportRowFinalRootPathColumn(IDfSysObject bulkImportReportObject, IDfSysObject object,
                                                        String columnValue)
      throws DfException {
    bulkImportReportObject.checkout();
    HSSFWorkbook importReportWorkbook = null;
    try {
      importReportWorkbook = new HSSFWorkbook(new POIFSFileSystem(bulkImportReportObject.getContent()));
    } catch (IOException e) {
      e.printStackTrace();
    }
    HSSFSheet importReportSheet = importReportWorkbook.getSheetAt(0);
    HSSFRow mappedObjectRow = getMatchingBulkImportReportRow(importReportSheet, object);
    if (mappedObjectRow != null) {
      short cellNum = 6;
      mappedObjectRow.createCell(cellNum).setCellValue(columnValue);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      try {
        importReportWorkbook.write(byteArrayOutputStream);
      } catch (IOException e) {
        e.printStackTrace();
      }
      bulkImportReportObject.setContent(byteArrayOutputStream);
      bulkImportReportObject.save();
    } else {
      bulkImportReportObject.cancelCheckout();
    }
  }

  private void updateImportReportRowAttrMappedColumn(IDfSysObject bulkImportReportObject, IDfSysObject object,
                                                     String columnValue) throws
      DfException {
    bulkImportReportObject.checkout();
    HSSFWorkbook importReportWorkbook = null;
    try {
      importReportWorkbook = new HSSFWorkbook(new POIFSFileSystem(bulkImportReportObject.getContent()));
    } catch (IOException e) {
      e.printStackTrace();
    }
    HSSFSheet importReportSheet = importReportWorkbook.getSheetAt(0);
    HSSFRow mappedObjectRow = getMatchingBulkImportReportRow(importReportSheet, object);
    if (mappedObjectRow != null) {
      short cellNum = 5;
      mappedObjectRow.createCell(cellNum).setCellValue(columnValue);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      try {
        importReportWorkbook.write(byteArrayOutputStream);
      } catch (IOException e) {
        e.printStackTrace();
      }
      bulkImportReportObject.setContent(byteArrayOutputStream);
      bulkImportReportObject.save();
    } else {
      bulkImportReportObject.cancelCheckout();
    }
  }

  private HSSFRow getMatchingBulkImportReportRow(HSSFSheet importReportSheet, IDfSysObject object) throws
      DfException {
    Iterator rows = importReportSheet.rowIterator();
    HSSFRow detailRow = null;
    while (rows.hasNext()) {
      HSSFRow row = (HSSFRow) rows.next();
      if (row.getCell((short) 1).getStringCellValue().equals(object.getObjectId().getId())) {
        detailRow = row;
        break;
      }
    }
    return detailRow;
  }

  private IDfSysObject getBulkImportReportObject(String docbase, AttributeMap attributeMap) throws DfException {
    String mapObjectFolder = attributeMap.getMapObjFolderName();
    String mapObjectName = attributeMap.getMapObjectName();
    String formattedMapObjectModifyDate = attributeMap.getFormattedMapObjModifyDate();
    IDfSysObject bulkImportReportObject = (IDfSysObject) getSession(docbase).getObjectByQualification(
        "dm_sysobject where object_name = 'BulkImportReport for " + mapObjectName +
            formattedMapObjectModifyDate +
            "' and FOLDER('" + mapObjectFolder + "')");
    if (bulkImportReportObject == null) {
      bulkImportReportObject = (IDfSysObject) getSession(docbase).newObject("bulk_import_attribute_map");
      bulkImportReportObject.link(mapObjectFolder);
      bulkImportReportObject
          .setObjectName("BulkImportReport for " + mapObjectName + formattedMapObjectModifyDate);
      ByteArrayOutputStream bulkImportReportSpreadsheet = createBulkImportReportSpreadsheet();
      bulkImportReportObject.setContentType("excel8book");
      bulkImportReportObject.setContent(bulkImportReportSpreadsheet);
      bulkImportReportObject.save();
    }
    return bulkImportReportObject;
  }

  private ByteArrayOutputStream createBulkImportReportSpreadsheet() {

    HSSFWorkbook workBook = null;
    workBook = new HSSFWorkbook();
    workBook.createSheet();
    addHeaderRow(workBook, createColumnHeadingList());
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      workBook.write(byteArrayOutputStream);
    } catch (IOException e) {
      e.printStackTrace();
    }

    return byteArrayOutputStream;
  }

  private void addHeaderRow(HSSFWorkbook workBook, List columnHeadingList) {
    HSSFSheet sheet = workBook.getSheetAt(0);
    HSSFFont font = workBook.createFont();
    font.setColor(HSSFColor.WHITE.index);
    HSSFCellStyle columnHeaderStyle = workBook.createCellStyle();
    columnHeaderStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    columnHeaderStyle.setFillBackgroundColor(HSSFColor.BLUE_GREY.index);
    columnHeaderStyle.setFillForegroundColor(HSSFColor.BLUE_GREY.index);
    columnHeaderStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
    columnHeaderStyle.setFont(font);
    HSSFCell headerCell = null;
    HSSFRow headerRow = sheet.createRow(0);
    short col = 0;
    Iterator itColumns = columnHeadingList.iterator();
    while (itColumns.hasNext()) {
      String columnLabel = (String) itColumns.next();
      headerCell = headerRow.createCell(col);
      headerCell.setCellValue(columnLabel);
      adjustColumnWidth(sheet, col, columnLabel);
      headerCell.setCellStyle(columnHeaderStyle);
      col++;
    }

  }

  private void adjustColumnWidth(HSSFSheet sheet, short col, String colValue) {
    int colWidth = colValue.length();
    short sheetColWidth = (short) ((colWidth + 1) * 256);
    if (sheetColWidth > sheet.getColumnWidth(col)) {
      sheet.setColumnWidth(col, sheetColWidth);
    }
  }


  private List createColumnHeadingList() {
    List listColumns = new ArrayList(4);
    listColumns.add("Timestamp");
    listColumns.add("Object ID");
    listColumns.add("Name and Path");
    listColumns.add("Map File Used");
    listColumns.add("Initial Import Path");
    listColumns.add("Attributes Mapped?");
    listColumns.add("Final Root Path");
    return listColumns;
  }

  private void setObjectAttributeValues(List attributeValueList, IDfSysObject object, String attributeName) throws
      DfException {
    Iterator attributeValues = attributeValueList.iterator();
    int index = 0;
    while (attributeValues.hasNext()) {
      String value = (String) attributeValues.next();
      if (value != null && value.length() > 0) {
        value = value.trim();
        switch (object.getAttrDataType(attributeName)) {
          case IDfValue.DF_BOOLEAN:
            object.setRepeatingBoolean(attributeName, index, new Boolean(value).booleanValue());
            break;
          case IDfValue.DF_TIME:
            object.setRepeatingTime(attributeName, index,
                new DfTime(value, DfTime.DF_TIME_PATTERN44));
            break;
          default:
            object.setRepeatingString(attributeName, index, value);
        }
        index++;
      }
    }
  }

  private List prepareMapValues(IDfSysObject object, String attributeName, String attributeValue,
                                String repeatingSeparator) throws
      DfException {
    List attributeValueList = new ArrayList(5);
    if (attributeValue != null && attributeValue.length() > 0) {
      if (object.isAttrRepeating(attributeName)) {
        attributeValueList = Arrays.asList(attributeValue.split(repeatingSeparator));
        object.removeAll(attributeName);
      } else {
        attributeValueList.add(attributeValue);
      }
    }
    return attributeValueList;
  }

  private void linkObjectToFinalFolder(String docbase, IDfSysObject object, AttributeMap attributeMap) throws
      DfException {
    String finalFolder = getFinalFolder(attributeMap);
    createFolder(getSession(docbase), finalFolder);
    object.link(finalFolder);

  }

  private void unlinkObjectFromInitialFolder(IDfSysObject object) throws
      DfException {
    IDfId dfIdFolderId = object.getFolderId(0);
    object.unlink(dfIdFolderId.getId());
  }

  private String getFinalFolder(AttributeMap attributeMap) {

    String targetObjectName = attributeMap.getTargetObjectName();
    int indexOfFilename = targetObjectName.lastIndexOf("/");
    String finalFolder = attributeMap.getFinalFolderName();
    if (indexOfFilename > -1) {
      finalFolder = finalFolder + "/" + targetObjectName.substring(0, indexOfFilename);
    }
    return parseFinalFolder(finalFolder, attributeMap);
  }

  private String parseFinalFolder(String folderPath, AttributeMap attrMap) {
    StringBuffer strbuff = new StringBuffer(256);
    String [] folderNames = folderPath.split(PATH_SEPARATOR);
    for (int i = 0; i < folderNames.length; i++) {
      if (folderNames[i].length() > 0) {
        if (folderNames[i].startsWith("{") && folderNames[i].endsWith("}")) {
          String name = folderNames[i].substring(1, folderNames[i].length() - 1);
          String value = attrMap.getAttributeValue(name);
          if (value != null && value.length() > 0)
            strbuff.append(PATH_SEPARATOR).append(value);
        } else strbuff.append(PATH_SEPARATOR).append(folderNames[i]);
      }
    }
    return strbuff.toString();
  }

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2006";
  }

  public String getVersion() {
    return "1.0";
  }

  public boolean isCompatible(String str) {
    return str.equals(getVersion());
  }


  private void addBulkImportReportRow(IDfSysObject bulkImportReportObject, IDfSysObject object,
                                      AttributeMap attributeMap)
      throws DfException {
    IDfSysObject attributeMapObject = attributeMap.getAttrMapObj();
    bulkImportReportObject.checkout();
    HSSFWorkbook importReportWorkbook = null;
    try {
      importReportWorkbook = new HSSFWorkbook(new POIFSFileSystem(bulkImportReportObject.getContent()));
    } catch (IOException e) {
      e.printStackTrace();
    }
    HSSFSheet attributesSheet = importReportWorkbook.getSheetAt(0);
    HSSFRow mappedObjectRow = attributesSheet.createRow(attributesSheet.getLastRowNum() + 1);
    short cellNum = 0;
    HSSFCell timestampCell = mappedObjectRow.createCell(cellNum);
    timestampCell.setCellValue(new Date());
    HSSFCellStyle cellStyle = importReportWorkbook.createCellStyle();
    cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy h:mm"));
    timestampCell.setCellStyle(cellStyle);
    cellNum++;
    mappedObjectRow.createCell(cellNum).setCellValue(object.getObjectId().getId());
    cellNum++;
    mappedObjectRow.createCell(cellNum).setCellValue(attributeMap.getTargetObjectName());
    cellNum++;
    mappedObjectRow.createCell(cellNum).setCellValue(attributeMap.getMapObjectName());
    cellNum++;
    mappedObjectRow.createCell(cellNum).setCellValue(attributeMap.getInitialFolderName());
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      importReportWorkbook.write(byteArrayOutputStream);
    } catch (IOException e) {
      e.printStackTrace();
    }
    bulkImportReportObject.setContent(byteArrayOutputStream);
//        bulkImportReportObject.checkin(false, "");
    bulkImportReportObject.save();
  }


  /**
   * Creates a folder specified by folder path. If the folders in the path don't exist, they are created too. Thus, its
   * a recursive docbase folder creation method. <p/> <p> The first component of the path is assumed to be a cabinet and
   * an object of type dm_cabinet is created for the first component if it does not exist. <p/> <p> This method is
   * expensive in terms of time and should be called with discretion. <p/> <p> The last argument of the method specifies
   * a base path. This path specifies the path beyond which the recursive folder creation proceeds. Specifying this
   * value will avoid checks for existence of folders specified in base path. This will eventually help speed up
   * processing and thus serves as a heuristic. This is an optional argument and if left empty or <code>null</code> all
   * folders specified in <code>path</code> are checked for existence and created if not present. This argument should
   * not end with the path separator ('/').
   *
   * @param sess
   * @param path The folder path to be created.
   *
   * @return
   *
   * @exception DfException
   * @exception RuntimeException This exception is thrown if basePath is not a valid basePath of <br> specified path.
   */
  private static IDfId createFolder(IDfSession sess, String path) throws DfException {
    return createFolder(sess, path, null, null, null);
  }

  private static IDfId createFolder(IDfSession sess, String path, String pathSep, String type, String basePath) throws
      DfException {
    boolean cabinetStillToBeProcessed = true;
    pathSep = validatePathSep(pathSep);
    type = validateType(type);
    IDfId currentId = null;
    StringBuffer bufFldrPath = new StringBuffer(48);
    if ((basePath != null) && (basePath.length() > 1)) {
      currentId = getIdByPath(sess, basePath);
      if (!currentId.isNull()) {
        //base path actually exists.
        bufFldrPath.append(basePath);
        cabinetStillToBeProcessed = false; //cabinet already processed due to base path.

        path = removeBasePathFromPath(basePath, path);
      }
    }
    StringTokenizer tokFldrNames = new StringTokenizer(path, pathSep);
    if (cabinetStillToBeProcessed) {
      //Execution will come here only if basePath was not specified or
      //if specified basePath was not valid.
      String cabinetName = tokFldrNames.nextToken();
      currentId = createCabinet(cabinetName, sess);
      bufFldrPath.append(pathSep).append(cabinetName);
    }
    //By this point the bufFldrPath will either have the cabinet path
    //or it will have the basePath in it.

    //now create all folders beyond the cabinet or basePath.
    while (tokFldrNames.hasMoreTokens()) {
      String parentPath = bufFldrPath.toString();

      String fldrName = tokFldrNames.nextToken();
      bufFldrPath.append(pathSep).append(fldrName);
      //by this point the buffer should contain the new expected path

      currentId = getIdByPath(sess, bufFldrPath.toString());
      if (currentId.isNull()) {
        //looks like the new folder in the path does not exist.
        IDfFolder newFldr = (IDfFolder) sess.newObject(type);
        newFldr.setObjectName(fldrName);
        newFldr.link(parentPath);
        newFldr.save();
        currentId = newFldr.getObjectId();
      }
      //by this point currentId should point to next folder in path
    }//while(all folder names)

    return currentId;
  }

  private static IDfId createCabinet(String cabinetName, IDfSession sess) throws DfException {
    IDfId currentId;
    StringBuffer cabQual = new StringBuffer(32);
    cabQual.append("dm_cabinet where object_name='").append(
        cabinetName).append(
        "'");
    currentId = sess.getIdByQualification(cabQual.toString());
    if (currentId.isNull()) {
      //need to create cabinet.
      IDfFolder cab = (IDfFolder) sess.newObject("dm_cabinet");
      cab.setObjectName(cabinetName);
      cab.save();
      currentId = cab.getObjectId();
    }
    return currentId;
  }

  private static String removeBasePathFromPath(String basePath, String path) {
    int basePathLen = basePath.length();
    if (basePathLen < path.length()) {
      path = path.substring(basePath.length());
    }
    return path;
  }

  private static String validateType(String type) {
    if ((type == null) || (type.length() == 0)) {
      type = FOLDER_TYPE;
    }
    return type;
  }

  private static String validatePathSep(String pathSep) {
    if (pathSep == null || (pathSep.length() == 0)) {
      pathSep = PATH_SEPARATOR;
    }
    return pathSep;
  }


  /**
   * Gets an object id given the path of the object. This method is a simple wrapper around the
   * IDfSession#getIdByQualification(...) method. This method can be used instead of the
   * IDfSession.getObjectByQualification() if all that is needed is the object id instead of a full fetch that
   * getObjectByQualification(...) method does. This method can be useful to check for the existence of an object if
   * path is known.
   *
   * @param sess Docbase session
   * @param path Docbase path of the object whose id needs to be obtained.
   *
   * @return instance of <code>IDfId</code>. This instance will contain a valid id if the object was found or an invalid
   *         id if the object was not found or if the path was illegal.
   *
   * @exception DfException
   */
  private static IDfId getIdByPath(IDfSession sess, String path) throws DfException {
    int pathSepIndex = path.lastIndexOf('/');
    if (pathSepIndex == -1) {
      return new DfId("000");
    }

    StringBuffer bufQual = new StringBuffer(32);
    if (pathSepIndex == 0) {
      //its a cabinet path
      bufQual.append(" dm_cabinet where object_name='");
      bufQual.append(path.substring(1));
      bufQual.append("'");
    } else {
      bufQual.append(" dm_sysobject where FOLDER('");
      bufQual.append(path.substring(0, pathSepIndex));
      bufQual.append("') ");
      bufQual.append(" and object_name='");
      bufQual.append(path.substring(pathSepIndex + 1));
      bufQual.append("'");
    }

    String strQual = bufQual.toString();
    return sess.getIdByQualification(strQual);
  }

  private static final String FOLDER_TYPE = "dm_folder";
  private static final String PATH_SEPARATOR = "/";

}