/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;
import com.monsanto.dctm.utils.pathgeneration.PathCreationUtils;

import java.io.File;

/**
 * Filename:    $RCSfile: TestObjectUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2006/11/07 20:52:50 $
 *
 * @author lakench
 * @version $Revision: 1.8 $
 */
public class TestObjectUtil {
    public static final String OBJECT_TYPE = "mon_tfd_object_type";
    public static final String ATTR_OBJECT_NAME = "object_name";
    public static final String ORIG_OBJ_NAME_VALUE_IN_MAP = "original object name";
    public static final String ORIG_OBJ_NAME_VALUE_IN_BLANK_ROW = "blank row object name";
    public static final String ORIG_OBJ_NAME_VALUE_NOT_IN_MAP = "this object name is not in the spreadsheet";
    public static final String NEW_OBJECT_NAME_VALUE = "new object name";
    public static final String ATTR_TITLE = "title";
    public static final String ORIGINAL_TITLE_VALUE = "original subject";
    public static final String NEW_TITLE_VALUE = "new subject";
    public static final String ATTR_KEYWORDS = "keywords";
    public static final String SINGLE_KEYWORD_VALUE = "single keyword";
    public static final String KEYWORD_ONE = "new keyword1";
    public static final String KEYWORD_TWO = "new keyword2";
    public static final String REPEATING_VALUE_SEPARATOR = ", ";
    public static final String ORIG_KEYWORD_ONE = "keyword1";
    public static final String ORIG_KEYWORD_TWO = "keyword2";
    public static final String ATTR_BOOLEAN = "bool_single";
    public static final String ATTR_INT = "int_single";
    public static final int ORIGINAL_INTEGER_VALUE = 5678;
    public static final int NEW_INTEGER_VALUE = 12345;
    public static final String ATTR_TIME = "time_single";
    public static final String TEST_DATE_STRING = "4/27/05 1:58 PM";
    public static final IDfTime TEST_TIME = new DfTime();
    public static final int ONE_SECOND = 1000;
    public static final int COL_WIDTH_FACTOR = 256;
    public static final String REPEATING_VALUE_SEPARATOR_ALT = ";#";
    public static final String BAD_INITIAL_FOLDER = "/Initial Folder Not In Map";
    public static final String GOOD_INITIAL_FOLDER = "/Initial Folder In Map";
    public static final String FINAL_FOLDER = "/Final Resting Place of Documents";
    public static final String FOLDER_MAPPING = "/{" + ATTR_TITLE + "}";
    public static final String SUBFOLDER_NAME = "testsubfolder";
    public static final String TEST_SPREADSHEET_FILENAME = "testBulkImport.xls";
    public static final String ORIG_OBJ_NAME_VALUE_IN_MIXED_ROW = "mixed row object name";
    public static final String ORIG_OBJ_NAME_IN_UNDEFINED_ROW = "undefined row object name";
    public static final String ORIG_OBJ_NAME_IN_LONG_ATTR_ROW = "long attribute value row object name";
    public static final String LONG_TITLE_VALUE = "This is a long string for testing if this code truncates an attribute value at 255 characters.  012345678911234567892123456789312345678941234567895123456789612345678971234567898123456789901234567891123456789212345678931234567894123456789512345678961234567897123456789812345678990123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899";

    public static IDfSysObject createTestDocbaseObject(IDfSession session, String origObjectName) throws DfException {
        return createTestDocbaseObject(session, origObjectName, GOOD_INITIAL_FOLDER);
    }

    public static IDfSysObject createTestDocbaseObject(IDfSession session, String origObjectName,
                                                       String importFolderName) throws
                                                                                DfException {
        IDfUser user = session.getUser(session.getLoginUserName());
        String userDefaultFolder = user.getDefaultFolder();

        importFolderName = userDefaultFolder + importFolderName;
        PathCreationUtils.createFolder(session, importFolderName);

        IDfSysObject object = (IDfSysObject) session.newObject(OBJECT_TYPE);
        object.link(importFolderName);
        object.setObjectName(origObjectName);
        object.setString(ATTR_TITLE, ORIGINAL_TITLE_VALUE);
        object.setKeywords(0, ORIG_KEYWORD_ONE);
        object.setKeywords(1, ORIG_KEYWORD_TWO);
        object.setBoolean(ATTR_BOOLEAN, false);
        object.setInt(ATTR_INT, ORIGINAL_INTEGER_VALUE);
        object.setTime(ATTR_TIME, TEST_TIME);
        object.save();
        return object;
    }

    public static IDfSysObject createHappyTestAttributeMapObject(IDfSession session,
                                                                 String repeatingValueSeparator) throws
                                                                                                 DfException {
        IDfSysObject object = (IDfSysObject) session.newObject("bulk_import_attribute_map");
        object.setObjectName(OBJECT_TYPE + "TestBulkImport");
        object.setString("assoc_object_type", OBJECT_TYPE);
        object.setString("repeating_separator", repeatingValueSeparator);
        object.setString("init_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + GOOD_INITIAL_FOLDER);
        object.setString("final_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + FINAL_FOLDER);
        TestSpreadsheetUtil.createHappyTestSpreadsheet(repeatingValueSeparator);
        object.setFileEx(TEST_SPREADSHEET_FILENAME, "excel8book", 0, null);
        object.save();
        deleteTestSpreadsheet();
        return object;
    }

    public static IDfSysObject createHappyTestAttributeMapObjectWithFolderMapping(IDfSession session,
                                                                                  String repeatingValueSeparator) throws
                                                                                                                  DfException {
        IDfSysObject object = (IDfSysObject) session.newObject("bulk_import_attribute_map");
        object.setObjectName(OBJECT_TYPE + "TestBulkImport");
        object.setString("assoc_object_type", OBJECT_TYPE);
        object.setString("repeating_separator", repeatingValueSeparator);
        object.setString("init_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + GOOD_INITIAL_FOLDER);
        object.setString("final_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + FINAL_FOLDER);
        object.setString("final_folder_mapping", FOLDER_MAPPING);
        TestSpreadsheetUtil.createHappyTestSpreadsheet(repeatingValueSeparator);
        object.setFileEx(TEST_SPREADSHEET_FILENAME, "excel8book", 0, null);
        object.save();
        deleteTestSpreadsheet();
        return object;
    }

    public static boolean deleteTestSpreadsheet() {
        File testSpreadsheet = new File(TEST_SPREADSHEET_FILENAME);
        return testSpreadsheet.delete();
    }

    public static IDfSysObject createBadTestAttributeMapObject(IDfSession session) throws DfException {
        IDfSysObject object = (IDfSysObject) session.newObject("bulk_import_attribute_map");
        object.setObjectName(OBJECT_TYPE + "BadTestBulkImport");
        object.setString("assoc_object_type", OBJECT_TYPE);
        object.setString("repeating_separator", REPEATING_VALUE_SEPARATOR);
        object.setString("init_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + GOOD_INITIAL_FOLDER);
        object.setString("final_folder_name",
                         session.getUser(session.getLoginUserName()).getDefaultFolder() + FINAL_FOLDER);
        TestSpreadsheetUtil.createBadTestSpreadsheet();
        object.setFileEx(TEST_SPREADSHEET_FILENAME, "excel8book", 0, null);
        object.save();
        deleteTestSpreadsheet();
        return object;
    }
}