/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes.test;

import com.monsanto.dctm.mapattributes.AttributeMapException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AttributeMapException_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-10-22 05:49:55 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AttributeMapException_UT extends TestCase {
    public void testThrowAttributeMapException() throws Exception {
        try {
            throw new AttributeMapException();
        } catch (AttributeMapException e) {
            assertNull("message should be null", e.getMessage());
        }
    }

    public void testThrowAttributeMapExceptionWithJustMessage() throws Exception {
        try {
            throw new AttributeMapException("test message");
        } catch (AttributeMapException e) {
            assertEquals("message wasn't set properly", e.getMessage(), "test message");
        }
    }

    public void testThrowAttributeMapExceptionWithJustCause() throws Exception {
        Throwable testException = null;
        try {
            testException = new Throwable("test throwable");
            throw new AttributeMapException(testException);
        } catch (AttributeMapException e) {
            assertEquals("cause wasn't set properly", e.getCause(), testException);
        }
    }

    public void testThrowAttributeMapExceptionWithMessageAndCause() throws Exception {
      Throwable testException = null;
        try {
            testException = new Throwable("test throwable");
            throw new AttributeMapException("test message", testException);
        } catch (AttributeMapException e) {
            assertEquals("message wasn't set properly", e.getMessage(), "test message");
            assertEquals("cause wasn't set properly", e.getCause(), testException);
        }
    }

}