/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes;

/**
 * Filename:    $RCSfile: AttributeMapException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2006-09-07 20:47:38 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AttributeMapException extends Exception {
  public AttributeMapException() {
    super();
  }

  public AttributeMapException(String message) {
    super(message);
  }

  public AttributeMapException(Throwable cause) {
    super(cause);
  }

  public AttributeMapException(String message, Throwable cause) {
    super(message, cause);
  }
}