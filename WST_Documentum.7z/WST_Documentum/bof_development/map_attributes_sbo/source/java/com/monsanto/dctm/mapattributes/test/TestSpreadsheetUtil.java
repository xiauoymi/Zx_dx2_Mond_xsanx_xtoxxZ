/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes.test;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Filename:    $RCSfile: TestSpreadsheetUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 21:18:42 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class TestSpreadsheetUtil {
    public static HSSFCellStyle cellDateTimeFormat;
    public static SimpleDateFormat df;

    public static void createHappyTestSpreadsheet(String repeatingValueSeparator) {
        HSSFWorkbook workBook;
        workBook = new HSSFWorkbook();

        HSSFSheet sheet = workBook.createSheet();
        initDateFormats(workBook);
        int row = 1;
        createNonMatchingSpreadsheetRow(sheet, row);
        row++;
        createMatchingSpreadsheetRow(sheet, row, repeatingValueSeparator);
        row++;
        createMatchingSpreadsheetRowForSubFolder(sheet, row, repeatingValueSeparator);
        row++;
        createRowWithSomeUndefinedCells(sheet, row, repeatingValueSeparator);
        row++;
        createMatchingSpreadsheetRowWithBlankValues(sheet, row);
        row++;
        createMixedSpreadsheetRow(sheet, row, repeatingValueSeparator);
        row++;
        createLongAttributeValueSpreadsheetRow(sheet, row, repeatingValueSeparator);
        addHeaderRow(workBook, sheet, createHappyColumnHeadingList());
        writeToFile(workBook, TestObjectUtil.TEST_SPREADSHEET_FILENAME);
    }

    public static void createMatchingSpreadsheetRowForSubFolder(HSSFSheet sheet, int row, String repeatingValueSeparator) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.SUBFOLDER_NAME + "/" + TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP, 2);
        cell++;
        writeCell(hssfRow, cell, "True", 0);
        cell++;
        writeCell(hssfRow, cell, Integer.toString(TestObjectUtil.NEW_INTEGER_VALUE), 1);
        cell++;
        writeCell(hssfRow, cell, repeatingValueSeparator + TestObjectUtil.KEYWORD_ONE + repeatingValueSeparator +
                                 TestObjectUtil.KEYWORD_TWO +
                                 repeatingValueSeparator, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_OBJECT_NAME_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_TITLE_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;
    }

    public static List createHappyColumnHeadingList() {
        List listColumns = new ArrayList(8);
        listColumns.add("Name");
        listColumns.add(TestObjectUtil.ATTR_BOOLEAN);
        listColumns.add(TestObjectUtil.ATTR_INT);
        listColumns.add(TestObjectUtil.ATTR_KEYWORDS);
        listColumns.add(TestObjectUtil.ATTR_OBJECT_NAME);
        listColumns.add(TestObjectUtil.ATTR_TITLE);
        listColumns.add(TestObjectUtil.ATTR_TIME);
        listColumns.add("Single Valued String");
        return listColumns;
    }

    public static void createMatchingSpreadsheetRow(HSSFSheet sheet, int row, String repeatingValueSeparator) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP, 2);
        cell++;
        writeCell(hssfRow, cell, "True", 0);
        cell++;
        writeCell(hssfRow, cell, Integer.toString(TestObjectUtil.NEW_INTEGER_VALUE), 1);
        cell++;
        writeCell(hssfRow, cell, repeatingValueSeparator + TestObjectUtil.KEYWORD_ONE + repeatingValueSeparator +
                                 TestObjectUtil.KEYWORD_TWO +
                                 repeatingValueSeparator, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_OBJECT_NAME_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_TITLE_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;
    }

    public static void createLongAttributeValueSpreadsheetRow(HSSFSheet sheet, int row, String repeatingValueSeparator) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_IN_LONG_ATTR_ROW, 2);
        cell++;
        writeCell(hssfRow, cell, "True", 0);
        cell++;
        writeCell(hssfRow, cell, Integer.toString(TestObjectUtil.NEW_INTEGER_VALUE), 1);
        cell++;
        writeCell(hssfRow, cell, repeatingValueSeparator + TestObjectUtil.KEYWORD_ONE + repeatingValueSeparator +
                                 TestObjectUtil.KEYWORD_TWO +
                                 repeatingValueSeparator, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_OBJECT_NAME_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.LONG_TITLE_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;
    }

    public static void createMixedSpreadsheetRow(HSSFSheet sheet, int row, String repeatingValueSeparator) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MIXED_ROW, 2);
        cell++;
        writeCell(hssfRow, cell, "True", 0);
        cell++;
        writeCell(hssfRow, cell, "", 1);
        cell++;
        writeCell(hssfRow, cell, repeatingValueSeparator + TestObjectUtil.KEYWORD_ONE + repeatingValueSeparator +
                                 TestObjectUtil.KEYWORD_TWO +
                                 repeatingValueSeparator, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_OBJECT_NAME_VALUE, 2);
        cell++;
        writeCell(hssfRow, cell, "", 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;
    }

    public static void createRowWithSomeUndefinedCells(HSSFSheet sheet, int row, String repeatingValueSeparator) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_IN_UNDEFINED_ROW, 2);
        cell++;
        writeCell(hssfRow, cell, "True", 0);
        cell++;
//        writeCell(hssfRow, cell, "", 1);
        cell++;
        writeCell(hssfRow, cell, repeatingValueSeparator + TestObjectUtil.KEYWORD_ONE + repeatingValueSeparator +
                                 TestObjectUtil.KEYWORD_TWO +
                                 repeatingValueSeparator, 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.NEW_OBJECT_NAME_VALUE, 2);
        cell++;
//        writeCell(hssfRow, cell, "", 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;

    }

    public static void createMatchingSpreadsheetRowWithBlankValues(HSSFSheet sheet, int row) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_BLANK_ROW, 2);
        cell++;
        writeCell(hssfRow, cell, "", 0);
        cell++;
        writeCell(hssfRow, cell, "", 1);
        cell++;
        writeCell(hssfRow, cell, "", 2);
        cell++;
        writeCell(hssfRow, cell, "", 2);
        cell++;
        writeCell(hssfRow, cell, "", 2);
        cell++;
        writeCell(hssfRow, cell, "", 4);
        cell++;
        writeCell(hssfRow, cell, "", 2);
        cell++;
    }

    public static void createNonMatchingSpreadsheetRow(HSSFSheet sheet, int row) {
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, "some other filename", 2);
        cell++;
        writeCell(hssfRow, cell, "False", 0);
        cell++;
        writeCell(hssfRow, cell, "5678", 1);
        cell++;
        writeCell(hssfRow, cell, "keyword that should never get set", 2);
        cell++;
        writeCell(hssfRow, cell, "non-matching row new object_name", 2);
        cell++;
        writeCell(hssfRow, cell, "non-matching row new subject", 2);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.TEST_DATE_STRING, 4);
        cell++;
        writeCell(hssfRow, cell, TestObjectUtil.SINGLE_KEYWORD_VALUE, 2);
        cell++;
    }

    public static void writeCell(HSSFRow hssfRow, short cellNum, String attributeValue, int attributeType) {
        HSSFCell hssfCol = hssfRow.createCell(cellNum);
        if (attributeValue == "") {
            hssfCol.setCellType(HSSFCell.CELL_TYPE_BLANK);
        } else {
            switch (attributeType) {
                case 0:
                    Boolean booleanAttributeValue = new Boolean(attributeValue);
                    hssfCol.setCellValue(booleanAttributeValue.booleanValue());
                    break;
                case 1:
                    hssfCol.setCellValue(Double.parseDouble(attributeValue));
                    break;
                case 4:
                    hssfCol.setCellStyle(cellDateTimeFormat);
                    try {
                        Date dateAttributeValue = df.parse(attributeValue);
                        hssfCol.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                        hssfCol.setCellValue(dateAttributeValue);
                    }
                    catch (ParseException parseException) {
                        parseException.printStackTrace();
                    }
                    break;
                default:
                    hssfCol.setCellValue(attributeValue);
            }
        }
    }

    public static void addHeaderRow(HSSFWorkbook workBook, HSSFSheet sheet, List listColumns) {
        HSSFFont font = workBook.createFont();
        font.setColor(HSSFColor.WHITE.index);
        HSSFCellStyle columnHeaderStyle = workBook.createCellStyle();
        columnHeaderStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        columnHeaderStyle.setFillBackgroundColor(HSSFColor.BLUE_GREY.index);
        columnHeaderStyle.setFillForegroundColor(HSSFColor.BLUE_GREY.index);
        columnHeaderStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        columnHeaderStyle.setFont(font);
        HSSFCell headerCell = null;
        HSSFRow headerRow = sheet.createRow(0);
        short col = 0;
        Iterator itColumns = listColumns.iterator();
        while (itColumns.hasNext()) {
            String columnLabel = (String) itColumns.next();
            headerCell = headerRow.createCell(col);
            headerCell.setCellValue(columnLabel);
            adjustColumnWidth(sheet, col, columnLabel);
            headerCell.setCellStyle(columnHeaderStyle);
            col++;
        }
    }

    public static void adjustColumnWidth(HSSFSheet sheet, short col, String colValue) {
        int colWidth = colValue.length();
        short sheetColWidth = (short) ((colWidth + 1) * TestObjectUtil.COL_WIDTH_FACTOR);
        if (sheetColWidth > sheet.getColumnWidth(col)) {
            sheet.setColumnWidth(col, sheetColWidth);
        }
    }

    public static void writeToFile(HSSFWorkbook workBook, String fileName) {
        FileOutputStream stream = null;
        File spreadsheetFile = new File(fileName);
        try {
            stream = new FileOutputStream(spreadsheetFile);
            workBook.write(stream);
        }
        catch (IOException ex) {
            System.out.println("Error creating temp CSV File:");
            ex.printStackTrace();
        }
        finally {
            if (stream != null) {
                try {
                    stream.close();
                }
                catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }
    }

    public static void initDateFormats(HSSFWorkbook workBook) {
        String dateTimeFormat = "M/d/yy h:mm a";
        DateFormat.getDateTimeInstance(3, 3, Locale.getDefault());
        df = new SimpleDateFormat(dateTimeFormat, Locale.getDefault());
        cellDateTimeFormat = workBook.createCellStyle();
        cellDateTimeFormat.setDataFormat(workBook.createDataFormat().getFormat(
                dateTimeFormat.substring(0, dateTimeFormat.lastIndexOf(" a")) + " AM/PM"));
    }

    public static void createBadTestSpreadsheet() {
        HSSFWorkbook workBook;
        workBook = new HSSFWorkbook();

        HSSFSheet sheet = workBook.createSheet();
        initDateFormats(workBook);
        int row = 1;
        HSSFRow hssfRow = sheet.createRow(row);
        short cell = 0;
        writeCell(hssfRow, cell, TestObjectUtil.ORIG_OBJ_NAME_VALUE_IN_MAP, 2);
        cell++;
        writeCell(hssfRow, cell, "test value", 2);

        List listColumns = new ArrayList(8);
        listColumns.add("Name");
        listColumns.add("an_attr_name_that_would_never_exist_in_an_object_type");
        addHeaderRow(workBook, sheet, listColumns);

        writeToFile(workBook, TestObjectUtil.TEST_SPREADSHEET_FILENAME);
    }
}