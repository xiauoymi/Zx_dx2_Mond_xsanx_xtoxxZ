/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.mapattributes;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: AttributeMap.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date:
 * 2006/11/07 20:52:50 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class AttributeMap {

  private String origDfSysObjectName = null;
  private IDfSysObject attrMapObj = null;
  private IDfSession session = null;
  private IDfSysObject dfSysObject = null;
  private String repeatingValueSeparator = ",";
  private String initialFolderName = null;
  private String finalFolderName;
  private String mapObjectName = null;
  private Set attributeNames = null;
  private Set translatedAttributeNames;
  private Map attributeMap = null;
  private String targetObjectName = null;
  private String formattedMapObjModifyDate = null;
  private String mapObjFolderName = null;

  public String getOrigDfSysObjectName() {
    return origDfSysObjectName;
  }

  public IDfSysObject getAttrMapObj() {
    return attrMapObj;
  }

  public void setAttrMapObj(IDfSysObject attrMapObj) {
    this.attrMapObj = attrMapObj;
  }

  public void setSession(IDfSession session) {
    this.session = session;
  }

  public IDfSysObject getDfSysObject() {
    return dfSysObject;
  }

  public void setDfSysObject(IDfSysObject dfSysObject) {
    this.dfSysObject = dfSysObject;
  }

  public String getRepeatingValueSeparator() {
    return repeatingValueSeparator;
  }

  public void setRepeatingValueSeparator(String repeatingValueSeparator) {
    this.repeatingValueSeparator = repeatingValueSeparator;
  }

  public String getInitialFolderName() {
    return initialFolderName;
  }

  public void setInitialFolderName(String initialFolderName) {
    this.initialFolderName = initialFolderName;
  }

  public String getFinalFolderName() {
    return finalFolderName;
  }

  public void setFinalFolderName(String finalFolderName) {
    this.finalFolderName = finalFolderName;
  }

  public String getMapObjectName() {
    return mapObjectName;
  }

  public Iterator getAttributeNames() {
    return attributeNames.iterator();
  }

  public Iterator getTranslatedAttributeNames() {
    return translatedAttributeNames.iterator();
  }

  public boolean isAssociatedWithMapObj() {
    return attrMapObj != null;
  }

  public boolean isInAttributeMap() {
    return attributeMap != null;
  }

  public String getTargetObjectName() {
    return targetObjectName;
  }

  public String getFormattedMapObjModifyDate() {
    return formattedMapObjModifyDate;
  }

  public String getMapObjFolderName() {
    return mapObjFolderName;
  }

  public AttributeMap(IDfSession session, IDfSysObject object) throws AttributeMapException {
    if (session != null) {
      setSession(session);
    } else {
      throw new AttributeMapException(new IllegalArgumentException("session cannot be null"));
    }
    if (object != null) {
      setDfSysObject(object);
    } else {
      throw new AttributeMapException(new IllegalArgumentException("object cannot be null"));
    }
    try {
      origDfSysObjectName = object.getObjectName();
      setAttrMapObj(getAttributeMapObjectFromDocbase(object));
      if (attrMapObj != null) {
        setRepeatingValueSeparator(attrMapObj.getString("repeating_separator"));
        setInitialFolderName(attrMapObj.getString("init_folder_name"));
        setFinalFolderName(getAggregateFolderPath());
        targetObjectName = getRelativePathAndName(getDfSysObject(), attrMapObj);
        mapObjectName = attrMapObj.getObjectName();
        Date mapObjectModifyDate = attrMapObj.getModifyDate().getDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        formattedMapObjModifyDate = dateFormat.format(mapObjectModifyDate);
        mapObjFolderName = ((IDfFolder) session.getObject(attrMapObj.getFolderId(0)))
            .getString("r_folder_path");
        Map attrMapFromSpreadsheet = generateAttributeMap(getDfSysObject(), attrMapObj);
        if (attrMapFromSpreadsheet != null) {
          attributeNames = attrMapFromSpreadsheet.keySet();
          attributeMap = translateAttributeNamesThroughDataDictionary(attrMapFromSpreadsheet,
              getDfSysObject());
          translatedAttributeNames = attributeMap.keySet();
        }
      }
    } catch (DfException e) {
      throw new AttributeMapException(e.getMessage(), e);
    }

  }

  private String getAggregateFolderPath() {
    StringBuffer strbuff = new StringBuffer(255);
    try {
      String finalFolder = attrMapObj.getString("final_folder_name");
      String folderMapping = null;
      if (attrMapObj.getType().findTypeAttrIndex("final_folder_mapping") > -1)
        folderMapping = attrMapObj.getString("final_folder_mapping");
      if (finalFolder != null && finalFolder.length() > 0)
        strbuff.append(finalFolder);
      if (folderMapping != null && folderMapping.length() > 0) {
        strbuff.append(folderMapping);
      }
    } catch (DfException e) {
      e.printStackTrace();
    }
    return strbuff.toString();
  }

  private IDfSysObject getAttributeMapObjectFromDocbase(IDfSysObject object) throws DfException {
    IDfId mapObjectId = null;
    String objectFolderName = ((IDfFolder) session.getObject(object.getFolderId(0))).getString("r_folder_path");
    String queryString =
        "select r_object_id, init_folder_name from bulk_import_attribute_map where assoc_object_type = '" +
            object.getType().getName() + "'";
    IDfCollection col = null;
    try {
      IDfQuery query = new DfClientX().getQuery();
      query.setDQL(queryString);
      col = query.execute(session, IDfQuery.DF_READ_QUERY);
      while (col.next()) {
        String initFolderName = col.getString("init_folder_name");
        if (objectFolderName.startsWith(initFolderName)) {
          mapObjectId = col.getId("r_object_id");
          break;
        }
      }
    } finally {
      if (col != null) col.close();
    }

    if (mapObjectId == null) return null;
    return (IDfSysObject) session.getObject(mapObjectId);
  }

  private Map generateAttributeMap(IDfSysObject object, IDfSysObject attrMapObj) throws DfException,
      AttributeMapException {

    HSSFWorkbook attributesWorkbook = null;
    try {
      attributesWorkbook = new HSSFWorkbook(new POIFSFileSystem(attrMapObj.getContent()));
    } catch (IOException e) {
      throw new AttributeMapException("Error reading map spreadsheet: " + e.getMessage(), e);
    }

    return extractAttributeMapFromSpreadsheet(attributesWorkbook, getRelativePathAndName(object, attrMapObj));
  }

  private Map translateAttributeNamesThroughDataDictionary(Map attributeMap, IDfSysObject object) throws DfException,
      AttributeMapException {
    Map newAttributeMap = null;
    newAttributeMap = new HashMap(attributeMap.size());
    Iterator attributes = attributeMap.keySet().iterator();
    while (attributes.hasNext()) {
      String attributeName = (String) attributes.next();
      String attributeValue = (String) attributeMap.get(attributeName);
      attributeName = translateAttributeNameThroughDataDictionary(object, attributeName);
      newAttributeMap.put(attributeName, attributeValue);
    }
    return newAttributeMap;
  }

  public String translateAttributeNameThroughDataDictionary(IDfSysObject object, String attributeName) throws
      DfException,
      AttributeMapException {
    IDfType type = object.getType();
    int typeAttrIndex = type.findTypeAttrIndex(attributeName);
    if (typeAttrIndex == -1) {
      int typeAttrCount = type.getTypeAttrCount();
      boolean attrFound = false;
      for (int i = 0; i < typeAttrCount; i++) {
        String attrDescription = type.getTypeAttrDescriptionAt(i);
        if (attrDescription.equals(attributeName)) {
          attributeName = type.getTypeAttrNameAt(i);
          attrFound = true;
          break;
        }
      }
      if (!attrFound) {
        throw new AttributeMapException("Bad attribute in map: " + attributeName);
      }
    }
    return attributeName;
  }

  private String getRelativePathAndName(IDfSysObject object, IDfSysObject attrMapObj) throws DfException {
    String objectName = object.getObjectName();
    String objectPath = ((IDfFolder) object.getSession().getObject(object.getFolderId(0)))
        .getString("r_folder_path");
    String initialPath = attrMapObj.getString("init_folder_name");
    String relativePathAndName = null;
    int indexOfRelativePath = objectPath.indexOf(initialPath) + initialPath.length() + 1;
    if (indexOfRelativePath > objectPath.length()) {
      relativePathAndName = objectName;
    } else {
      String objectPathRelativeToInitialPath = objectPath.substring(indexOfRelativePath);
      relativePathAndName = objectPathRelativeToInitialPath + "/" + objectName;
    }
    return relativePathAndName;
  }

  private Map extractAttributeMapFromSpreadsheet(HSSFWorkbook attributesWorkbook, String relativePathAndName)
      throws AttributeMapException {
    HSSFSheet attributesSheet = attributesWorkbook.getSheetAt(0);
    Iterator rows = attributesSheet.rowIterator();
    HSSFRow headerRow = null;
    HSSFRow detailRow = null;
    while (rows.hasNext()) {
      HSSFRow row = (HSSFRow) rows.next();
      if (row.getRowNum() == 0) {
        headerRow = row;
      }

      if (row.getCell((short) 0).getStringCellValue().equals(relativePathAndName)) {
        detailRow = row;
        break;
      }
    }

    HashMap attributes = null;
    if (detailRow != null) {
      attributes = new HashMap(headerRow.getPhysicalNumberOfCells());
      Iterator headerRowCells = headerRow.cellIterator();
      while (headerRowCells.hasNext()) {
        HSSFCell headerCell = (HSSFCell) headerRowCells.next();
        try {
          if (headerCell.getCellNum() != 0) attributes.put(getAttrNameFromCell(headerCell),
              getAttrValueFromCell(
                  detailRow.getCell(headerCell.getCellNum()),
                  attributesWorkbook));
        } catch (NullPointerException e) {
          throw new AttributeMapException("Bad spreadsheet map: " + e.getMessage(), e);
        }
      }
    }
    return attributes;
  }

  private String getAttrValueFromCell(HSSFCell cell, HSSFWorkbook workbook) {
    if (cell != null) {
      switch (cell.getCellType()) {
        case HSSFCell.CELL_TYPE_STRING:
          return cell.getStringCellValue();
        case HSSFCell.CELL_TYPE_BOOLEAN:
          return Boolean.toString(cell.getBooleanCellValue());
        case HSSFCell.CELL_TYPE_NUMERIC:
          if (isDateCell(cell, workbook)) {
            return new DfTime(cell.getDateCellValue()).asString(DfTime.DF_TIME_PATTERN44);
          } else {
            return Double.toString(cell.getNumericCellValue());
          }
      }
    }
    return null;
  }

  private boolean isDateCell(HSSFCell cell, HSSFWorkbook workbook) {
    String formatString = workbook.createDataFormat().getFormat(cell.getCellStyle().getDataFormat());
    return HSSFDateUtil.isCellDateFormatted(cell) ||
        Pattern.compile("[mM]+\\/[dD]+\\/[yY]+|[hH]+:[mM]+").matcher(formatString).find();
  }

  private String getAttrNameFromCell(HSSFCell cell) {
    return cell.getStringCellValue();
  }

  public String getAttributeValue(String attributeName) {
    String value = null;
    try {
      value = (String) attributeMap
          .get(translateAttributeNameThroughDataDictionary(this.getDfSysObject(), attributeName));
    } catch (Exception e) {
    }
    return value;
  }
}