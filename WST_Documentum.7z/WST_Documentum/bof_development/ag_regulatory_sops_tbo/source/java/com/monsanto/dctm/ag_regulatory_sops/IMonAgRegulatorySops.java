package com.monsanto.dctm.ag_regulatory_sops;

import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.common.DfException;

public interface IMonAgRegulatorySops extends IDfBusinessObject {
    public void requestPDFRendition() throws DfException;

}
