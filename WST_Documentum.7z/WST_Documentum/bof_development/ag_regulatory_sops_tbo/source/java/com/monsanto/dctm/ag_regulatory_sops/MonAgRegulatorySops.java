package com.monsanto.dctm.ag_regulatory_sops;

import com.documentum.fc.client.DfDocument;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;

/**
 * @author lakench
 */
public class MonAgRegulatorySops extends DfDocument implements IMonAgRegulatorySops, IDfDynamicInheritance {

    public String getVendorString() {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean isCompatible(String str) {
        return str.equals("1.0");
    }

    public boolean supportsFeature(String str) {
        return false;
    }

    protected IDfId doCheckin(boolean b, String attrName, String attrName1, String attrName2, String attrName3, String attrName4, Object[] objects) throws
                                                                                                                                                    DfException {
        IDfId newObjId = super.doCheckin(b, attrName, attrName1, attrName2, attrName3, attrName4, objects);
        ((IMonAgRegulatorySops) getObject(newObjId)).requestPDFRendition();
        return newObjId;
    }

    public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
            throws DfException {
        super.doSave(saveLock, versionLabel, extendedArgs);
        requestPDFRendition();
    }

    public void requestPDFRendition() throws DfException {
        queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
    }

}
