/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.ag_regulatory_sops.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.ag_regulatory_sops.IMonAgRegulatorySops;
import com.monsanto.dctm.test.TestUtils;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.HashMap;

/**
 * Filename:    $RCSfile: MonAgRegulatorySops_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-02 17:02:19 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class MonAgRegulatorySops_AT extends TestCase {

    public HashMap stateToAclMap;

    protected void setUp() throws Exception {
        super.setUp();
        stateToAclMap = new HashMap();
        stateToAclMap.put("In Progress", "Reg_sops_document");
        stateToAclMap.put("Approved", "Reg_sops_document");
        stateToAclMap.put("Effective", "Reg_sops_document");
        stateToAclMap.put("Superseded", "Reg_sops_document");
        stateToAclMap.put("Retired", "Reg_sops_document");

    }

    public void testCreate() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        IMonAgRegulatorySops object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession("mtctst01");
            object = (IMonAgRegulatorySops) session.newObject("ag_regulatory_sops");

            assertNotNull(object);
            assertEquals("Copyright(c) Monsanto Corp., 2005", object.getVendorString());
            assertEquals("1.0", object.getVersion());
            assertTrue(object.isCompatible("1.0"));
            assertFalse(object.isCompatible("2.0"));
            assertFalse(object.supportsFeature(null));
            assertFalse(object.supportsFeature("anything"));
        } finally {
            if (object != null) {
                ((IDfSysObject) object).destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testCheckin() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("mtctst01", "devl30", "devl30");
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession("mtctst01");
            object = (IDfSysObject) session.newObject("ag_regulatory_sops");
            object.setRepeatingString("sop_groups", 0, "Agricultural Research");
            object.setString("sop_type", "Best Practice");
            object.save();

            newObject = TestUtils.checkoutCheckin(object, session);

            assertEquals("Reg SOPs", object.getPolicyName());
            assertLifecycleState(object, "In Progress");
            assertEquals("Reg SOPs", newObject.getPolicyName());
            assertLifecycleState(newObject, "In Progress");
        } finally {
            if (object != null) {
                object.destroyAllVersions();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    private void assertLifecycleState(IDfSysObject object, String stateName) throws DfException {
        assertEquals(stateName, object.getCurrentStateName());
        assertEquals(stateName, object.getString("status"));
        assertEquals((String) stateToAclMap.get(stateName), object.getACLName());
    }
}