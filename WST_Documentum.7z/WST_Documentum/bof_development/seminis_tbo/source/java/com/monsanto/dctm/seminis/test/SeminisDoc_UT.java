/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.seminis.test;

//import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.test.MockDfSessionManager;
import junit.framework.TestCase;


/**
 * Filename:    $RCSfile: SeminisDoc_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 18:54:49 $
 *
 * @author ussing
 * @version $Revision: 1.3 $
 */
public class SeminisDoc_UT extends TestCase {
  private MockDfSessionManager sessionManager;
  private static final String SEMINIS_ADMINS = "seminis_admins";
  private static final String ADMINUSERID = "AdminUser";
  private static final String ADMINUSERID1 = "AdminUser1";

  public void testCreate() throws Exception {
    MockSeminisDoc object = new MockSeminisDoc();

    assertNotNull(object);
  }
  public void testApplyDefaulyACL() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","");
    mock.setString("section","");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();

    assertEquals("initial ACL name", mock.iDfACL.aclName);

  }
  public void testDepartmentIsPathology() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","Pathology");
    mock.setString("section","");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();
    assertEquals("Pathology",mock.getString("operating_unit"));
    assertEquals("Seminis Pathology Dept ACL", mock.iDfACL.aclName);

  }
  public void testDepartmentIsSeedTechnologyAndSectionPelleting() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","Seed Technology");
    mock.setString("section","seed tech section Pelleting");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();
    assertEquals("Seed Technology",mock.getString("operating_unit"));
    assertEquals("Seminis Seed Technology dept ACL", mock.iDfACL.aclName);

  }
  public void testDepartmentIsSeedTechnologyAndSectionPriming() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","Seed Technology");
    mock.setString("section","Seed tech and section is Priming");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();
    assertEquals("Seed Technology",mock.getString("operating_unit"));
    assertEquals("Seminis Seed Technology dept ACL", mock.iDfACL.aclName);

  }
  public void testDepartmentIsGeneticPurityAndSectionGPL() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","Genetic Purity");
    mock.setString("section","section contains GpL");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();
    assertEquals("Genetic Purity",mock.getString("operating_unit"));
    assertEquals("Seminis Genetic Purity dept ACL", mock.iDfACL.aclName);

  }
  public void testDepartmentIsGeneticPurityAndSectionGPG() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("r_object_id", "091234242");
    mock.setString("operating_unit","Genetic Purity");
    mock.setString("section","Section is GPG");
    assertEquals("initial ACL name",mock.getString("acl_name"));
    mock.setACLfromDepartment();
    assertEquals("Genetic Purity",mock.getString("operating_unit"));
    assertEquals("Seminis Genetic Purity & GPG", mock.iDfACL.aclName);

  }
  public void testSendEmailToAdminWhenNotificationMessageAndNotifyUserIsBlank() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisDoc mock = new MockSeminisDoc();
    mock.setSession(mockSession);
    mock.setString("notify_message", "");
    mock.setString("r_object_id", "091234242");
    mock.setString("object_name", "Test Seminis Doc");
    //mock.setRepeatingString("notify_users",0,"");
    mock.addMockGroup(SEMINIS_ADMINS, ADMINUSERID);
    mock.addDocument("091234242");

    mock.save();
    mock.notifyAdminGroup();

    assertNotNull(mock);
    assertTrue(mock.wasSaveCalled);
    assertEquals("", mock.getString("notify_message"));
    //assertEquals("", mock.getRepeatingString("notify_users",0));
    assertEquals("091234242", mock.getString("r_object_id"));
    assertTrue(mockSession.getGroup(SEMINIS_ADMINS).isUserInGroup(ADMINUSERID));
    assertEquals(ADMINUSERID, mock.queueOwner);
    assertEquals("dm_save", mock.event);
    assertEquals(0, mock.priority);
    assertTrue(mock.sendMail);
    assertNull(mock.dueDate);
    assertEquals("", mock.message);
  }
}
