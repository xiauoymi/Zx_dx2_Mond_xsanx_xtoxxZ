/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.seminis.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;
import com.monsanto.dctm.mon_docs.test.MockMonMonDocs;
import com.monsanto.dctm.seminis.SeminisDoc;
import com.monsanto.dctm.test.MockDfGroup;
import com.monsanto.dctm.test.MockDfACL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockSeminisDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 18:54:49 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class MockSeminisDoc extends SeminisDoc {
   private MockMonMonDocs mock;
    public String queueOwner;
    public String event;
    public int priority;
    public boolean sendMail;
    public IDfTime dueDate;
    public String message;
    public IDfId newObjId;
    private IDfSession session;
    public boolean wasSaveCalled = false;
    private static final String ADMINUSERID = "AdminUser";
  public MockDfACL iDfACL;
public static final String INITIAL_ACL_NAME = "initial ACL name";
   public MockSeminisDoc(){
    this(new MockMonMonDocs());
     try {
       setACLName(INITIAL_ACL_NAME);
       setACL(new MockDfACL("test docbase owner", INITIAL_ACL_NAME));
     } catch (DfException e) {
       e.printStackTrace();
     }

   }
  public void setACL(IDfACL iDfACL) throws DfException {
                 this.iDfACL = (MockDfACL) iDfACL;
          }


    public MockSeminisDoc(MockMonMonDocs mockDocs) {
       mock = mockDocs;
    }

   protected void setACLfromDepartment() throws DfException{

     super.setACLfromDepartment();
 }

  public MockSeminisDoc(String department) {

    }
 /* public IDfACL getACL(){
    System.out.println("GET ACL");
    return null;
  }*/
      public MockSeminisDoc(IDfSession session, String objectId) throws DfException {
        this();
        setSession(session);
        setString("r_object_id", objectId);
    }
     /**
     * @noinspection RefusedBequest
     */
    public void setSession(IDfSession session) {
        mock.setSession(session);
    }
  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getSession() {
        return mock.getSession();
  }

      /**
     * @noinspection RefusedBequest
     */
    public String getString(String attrName) throws DfException {
        return mock.getString(attrName);
    }

    /**
     * @noinspection RefusedBequest
     */
    public void setString(String attrName, String value) throws DfException {
        mock.setString(attrName, value);
    }
  /**
   * @noinspection RefusedBequest
   */
  /*public void setRepeatingString(String string, int i, String string1) throws DfException {
      mock.setRepeatingString(string, i, string1);
  }*/

  /**
   * @noinspection RefusedBequest
   */
  public String getRepeatingString(String string, int i) throws DfException {
      return mock.getRepeatingString(string, i);

  }
  public void save() throws DfException {
     //mock.save();
     wasSaveCalled = true;
 //    notifyAdminGroup();
  }
    /**
     * @noinspection RefusedBequest
     */
    public IDfId getObjectId() throws DfException {
        return mock.getObjectId();
    }

    public int getValueCount(String string) throws DfException {
      return mock.getValueCount(string);
    }
  public void addDocument(String newDocId) throws DfException {

      MockSeminisDoc semDoc = new MockSeminisDoc(getSession(), newDocId);
      ((MockSession) getSession()).addObject(semDoc, newDocId);
  }
    /**
     * @noinspection RefusedBequest
     */
    public synchronized void setSessionManager(IDfSessionManager sessionManager) throws DfException {
        mock.setSessionManager(sessionManager);
    }

  public void addMockGroup(String groupName,String initialUser) throws DfException {
    MockDfGroup group = new MockDfGroup();
    group.setResults(setupResults());
    group.setGroupName(groupName);
    if (initialUser != null && initialUser.length() > 0) {
      group.addUser(initialUser);
    }
    ((MockSession) getSession()).addGroup(group);
  }
      private List setupResults() {

     Map row1 = new HashMap();
     List objectIds1 = new ArrayList();
     objectIds1.add(0, ADMINUSERID);
     row1.put("users_names", objectIds1);

     List adminUsers = new ArrayList();
     adminUsers.add(row1);
     return adminUsers;
    }
  public IDfId queue(String queueOwner, String event, int priority, boolean sendMail, IDfTime dueDate, String message) throws
                                                                                                                         DfException {

        this.queueOwner = queueOwner;
        this.event = event;
        this.priority = priority;
        this.sendMail = sendMail;
        this.dueDate = dueDate;
        this.message = message;
        return new DfId(null);
    }

}