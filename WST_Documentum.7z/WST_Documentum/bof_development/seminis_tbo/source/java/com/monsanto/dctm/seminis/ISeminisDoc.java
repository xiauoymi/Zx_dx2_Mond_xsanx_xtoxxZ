/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.seminis;

import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.common.DfException;

/**
 * Filename:    $RCSfile: ISeminisDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-08-31 20:58:50 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public interface ISeminisDoc extends IDfBusinessObject {
  public void notifyAdminGroup() throws DfException;
  public String getString(String attribute) throws DfException;
  public void setString(String attribute, String value) throws DfException;
  public String getObjectName() throws DfException;
  public void setRepeatingString(String attribute,int i, String value) throws DfException;
  public String getRepeatingString(String attribute,int i) throws DfException;
}