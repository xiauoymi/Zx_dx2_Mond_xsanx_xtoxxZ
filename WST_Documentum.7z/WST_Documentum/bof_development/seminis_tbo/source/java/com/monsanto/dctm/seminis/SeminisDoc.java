/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.seminis;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.mon_docs.MonMonDocs;

/**
 * Filename:    $RCSfile: SeminisDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-06-05 18:57:45 $
 *
 * @author ussing
 * @version $Revision: 1.6 $
 */
public class SeminisDoc extends MonMonDocs implements IDfDynamicInheritance, ISeminisDoc {
  private IDfId newObjId = null;
  private static String adminGroup="seminis_admins";
  private String draft = "Draft";

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2005";
  }

  public String getVersion() {
    return "1.0";
  }

  public boolean isCompatible(String str) {
    return str.equals("1.0");
  }

  public boolean supportsFeature(String str) {
    return false;
  }

  protected IDfId doCheckin(boolean b, String attrName, String attrName1, String attrName2, String attrName3, String attrName4, Object[] objects) throws
      DfException {

    newObjId = super.doCheckin(b, attrName, attrName1, attrName2, attrName3, attrName4, objects);
    getObject(newObjId).save();
    setACLfromDepartment();
    return newObjId;
  }
  public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
      throws DfException {
    super.doSave(saveLock, versionLabel, extendedArgs);
    //Bug Fix #242465
    if(isDraftVersion(this)){
      setACLfromDepartment();
    }
    super.doSave(saveLock, versionLabel, extendedArgs);
    notifyAdminGroup();
  }
  protected void setACLfromDepartment() throws DfException{

    String department = this.getString("operating_unit");
    String section = this.getString("section");

    IDfSession session = this.getSession();
    if(department.equalsIgnoreCase("Pathology")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Pathology Dept ACL");
      setACL(newACL);
    }else if(department.equalsIgnoreCase("Seed Technology") && (doesSectionContains(section,"PELLETING") || doesSectionContains(section,"PRIMING"))){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Seed Technology dept ACL");
      setACL(newACL);
    }else if (department.equalsIgnoreCase("Genetic Purity") &&  doesSectionContains(section,"GPG")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Genetic Purity & GPG");
      setACL(newACL);
    }else if(department.equalsIgnoreCase("Genetic Purity") &&  doesSectionContains(section,"GPL")){
      IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Genetic Purity dept ACL");
      setACL(newACL);
    }
  }

  protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {
    String label = null;
    boolean isDraft = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
      if (label.equals(draft))
        isDraft = true;
    }
    return isDraft;
  }

  private boolean doesSectionContains(String section,String subString){
    boolean doesSectionExists = false;
    System.out.println("section = " + section);
    System.out.println("subString = " + subString);
    if(section.toUpperCase().indexOf(subString)>0 || section.equalsIgnoreCase(subString)){
      doesSectionExists = true;
    }
    return doesSectionExists;
  }
  public void notifyAdminGroup() throws DfException{
//    newObjId = getId("r_object_id");
//    IDfSysObject docObj =(IDfSysObject) getSession().getObject(newObjId);
    try{
      IDfGroup IdAdminGroup = getSession().getGroup(adminGroup);
      if(IdAdminGroup == null || IdAdminGroup.getUsersNamesCount() < 0 ){
        System.out.println("Group-"+adminGroup+":No users in group or the group doesnt exists");
      }
      queue(adminGroup,"dm_save",0,true,null,getString("notify_message"));
    }
    catch (DfException dfe)
    {
      System.out.println("Exception in  = " + "notifyAdminGroup" );
      dfe.printStackTrace();
    } 
  }
//Commented for new implementation of notifyAdminGroup function
//  private IDfCollection getAdminUsers() throws DfException{
//    IDfCollection adminUsers = null;
//    IDfGroup adminGroup = getSession().getGroup("seminis_admins");
//    adminUsers = adminGroup.getUsersNames();
//    return adminUsers;
//  }
}