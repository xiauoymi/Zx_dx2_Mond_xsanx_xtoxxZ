/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.seminis.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.Calendar;

/**
 * Filename:    $RCSfile: SeminisDoc_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:43:27 $
 *
 * @author ussing
 * @version $Revision: 1.4 $
 */
public class SeminisDoc_AT extends TestCase {
  private String objectName = "Test Seminis TBO From AT_";

  public void testCreateOneSeminsDoc() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;

    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");
      object.setString("object_name", "AT TEST Seminis 1");
      object.setString("country", "USA");
      object.setString("region","Test Region");
      object.setString("section", "Test Section");
      object.setString("operating_unit","");

      object.save();
      assertEquals("AT TEST Seminis 1", object.getObjectName());
      assertEquals("USA", object.getString("country"));
      assertEquals("Test Region", object.getString("region"));
      assertEquals("Test Section", object.getString("section"));

    }finally {
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testApplyDefaultACL() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("object_name","Test apply default ACL");
      object.setString("operating_unit","");

      object.save();
      assertEquals("seminis_draft", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }
    }
  }

  public void testDepartmentIsPathology() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {
      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Pathology");
      object.setString("object_name","Test dept Pathology");

      object.save();

      assertEquals("Pathology",object.getString("operating_unit"));
      assertEquals("Seminis Pathology Dept ACL", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }
    }
  }

  public void testDepartmentIsSeedTechnologyAndSectionisPriming() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {

      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Seed Technology");
      object.setString("section","section contains priming");
      object.setString("object_name","Test dept Seed Tech & Sec Priming");

      object.save();
      assertEquals("Seed Technology",object.getString("operating_unit"));
      assertEquals("Seminis Seed Technology dept ACL", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }

    }
  }
  public void testDepartmentIsSeedTechnologyAndSectionisPelleting() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {

      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Seed Technology");
      object.setString("section","section have Pelleting");
      object.setString("object_name","Test dept Seed Tech & Sec Pelleting");

      object.save();
      assertEquals("Seed Technology",object.getString("operating_unit"));
      assertEquals("Seminis Seed Technology dept ACL", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }

    }
  }
  public void testDepartmentIsGeneticPurityAndSectionIsGPL() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {

      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Genetic Purity");
      object.setString("section","genetic purity and section gPl");
      object.setString("object_name","Test dept Genetic Purity & Sec GPL");

      object.save();
      assertEquals("Genetic Purity",object.getString("operating_unit"));
      assertEquals("Seminis Genetic Purity dept ACL", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }

    }
  }
  public void testDepartmentIsGeneticPurityAndSectionIsGPG() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {

      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Genetic Purity");
      object.setString("section","section is GPG");
      object.setString("object_name","Test dept Genetic Purity & Sec GPG");

      object.save();
      assertEquals("Genetic Purity",object.getString("operating_unit"));
      assertEquals("Seminis Genetic Purity & GPG", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }

    }
  }
  public void testDepartmentIsSeedTechnology() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    try {

      session = sessionManager.getSession("stltst03");
      object = (IDfSysObject) session.newObject("seminis_doc");

      object.setString("operating_unit","Seed Technology");
      object.setString("section","seed tech have section Priming");
      object.setString("object_name","Test dept Seed Tech & Sec Pelleting/Priming");

      object.save();
      assertEquals("Seed Technology",object.getString("operating_unit"));
      assertEquals("Seminis Seed Technology dept ACL", object.getACLName());

    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }

    }
  }

  public void testNotifyAdminEmails() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl14", "devl14");
    IDfSession session = null;
    IDfSysObject object = null;
    Object dummyObj = new Object();
    try {
      session = sessionManager.getSession("stltst03");
      object = setObjectInfo(session);
      object.save();
      synchronized(dummyObj){
        try {
          dummyObj.wait(50000);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
      }
      assertEquals("Testing -- This is notification message from seminis AT", object.getString("notify_message"));

    }finally {
      if (object != null) {
        ((IDfSysObject) object).destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  private IDfSysObject setObjectInfo(IDfSession session) throws DfException {
      IDfSysObject sysObject;
      //Changes to have unique object name
      Calendar c1 = Calendar.getInstance();
      objectName = objectName + c1.getTime().toString();
      sysObject = (IDfSysObject) session.newObject("seminis_doc");
      sysObject.setString("object_name",objectName);
      sysObject.setString("subject","test subject");
      sysObject.setString("title","test title");
      sysObject.setRepeatingString("keywords",0,"kk");
      sysObject.setRepeatingString("authors",0,"usha");
      sysObject.setString("a_document_class","Manual");
      sysObject.setString("document_number","Testdoc123");
      sysObject.setString("section","section contains gpl");
      sysObject.setString("revision","test revision");
      sysObject.setString("submitted_date","7/10/2008 00:00:00");
      sysObject.setString("region","ASIA");
      sysObject.setString("country","Thailand");
      sysObject.setString("site_or_plant","Adana, Turkey");
      sysObject.setString("operating_unit","Genetic Purity");
      sysObject.setString("notify_message","Testing -- This is notification message from seminis AT");
      return sysObject;
    }

}