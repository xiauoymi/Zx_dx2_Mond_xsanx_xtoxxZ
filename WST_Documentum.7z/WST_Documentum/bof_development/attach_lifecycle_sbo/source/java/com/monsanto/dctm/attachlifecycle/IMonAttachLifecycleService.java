package com.monsanto.dctm.attachlifecycle;

import com.documentum.fc.client.IDfService;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;

public interface IMonAttachLifecycleService extends IDfService {
    public void attachLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws DfException;

    public void syncLifecycleStateWithStateName(IDfSysObject object, String stateName) throws DfException;

  //  String getqueryToFindScope(IDfSysObject sourceObject) throws DfException;
}
