/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachlifecycle.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockPersistentObject;
import junit.framework.Assert;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: AttachLifecycleTestUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:32:20 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AttachLifecycleTestUtils {
    public static MockSession createMockSessionWithMockPesticideLabelsLifecycle() throws DfException {
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();

        MockSession mockSession = new MockSession(mockDfSessionManager);
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "Ag_Pesticide_labels_LC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Blank");
        stateNames.add("In-Progress");
        stateNames.add("Submitted");
        stateNames.add("Approved/Approved Correct");
        stateNames.add("Draft EFP");
        stateNames.add("Edited for Print");
        stateNames.add("Draft Printed");
        stateNames.add("Printed");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:Ag_Pesticide_labels_LC");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "lifecycleID:Ag_Pesticide_labels_LC");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "dm_policy where object_name='Ag_Pesticide_labels_LC'");
        return mockSession;
    }

    public static MockSession createMockSessionWithMockNstDocsLifecycle() throws DfException {
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();

        MockSession mockSession = new MockSession(mockDfSessionManager);
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "Network Service Lifecycle");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Work In Progress");
        stateNames.add("Under Review");
        stateNames.add("Under Approval");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        ArrayList allowDemotes = new ArrayList();
        allowDemotes.add("true");
        allowDemotes.add("false");
        allowDemotes.add("false");
        allowDemotes.add("false");
        mockLifecycleObject.setRepeatingStrings("allow_demote", allowDemotes);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:Network Service Lifecycle");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "lifecycleID:Network Service Lifecycle");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "dm_policy where object_name='Network Service Lifecycle'");
        return mockSession;
    }

    public static IMonAttachLifecycleService getAttachLifecycleService(IDfSessionManager sessMgr) throws DfException {
        return (IMonAttachLifecycleService) DfClient.getLocalClient()
                .newService(IMonAttachLifecycleService.class.getName(), sessMgr);
    }

    public static void assertLifecycleState(IDfSysObject object, String stateName, HashMap stateToAclMap) throws
                                                                                                          DfException {
        Assert.assertEquals(stateName, object.getCurrentStateName());
        Assert.assertEquals(stateName, object.getString("nst_doc_status"));
        Assert.assertEquals((String) stateToAclMap.get(stateName), object.getACLName());
    }

  public static MockSession createMockSessionWithMockpmflulingLifecycleandaliassets() throws DfException {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();

        MockSession mockSession = new MockSession(mockDfSessionManager);
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "PMF Luling");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Effective");
        stateNames.add("Retired");
    MockPersistentObject mockAliasSet = new MockPersistentObject();
    mockAliasSet.setString("object_name","testscope");
    mockAliasSet.setString("r_object_id", "aliasSetId:testscope");
    mockSession.addObject((IDfPersistentObject)mockAliasSet,"aliasSetId:testscope");
    mockSession.addObject((IDfPersistentObject)mockAliasSet,"dm_alias_set where object_name='testscope'");

        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:PMF Luling");
        mockSession.addObject((IDfPersistentObject)mockLifecycleObject, "lifecycleID:PMF Luling");
        mockSession.addObject((IDfPersistentObject)mockLifecycleObject, "dm_policy where object_name='PMF Luling'");
        return mockSession;
  }
}