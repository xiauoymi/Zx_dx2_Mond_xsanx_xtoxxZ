package com.monsanto.dctm.attachlifecycle;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.devprog.common.boconfig.BOConfigFactory;
import com.documentum.devprog.common.boconfig.IBOConfig;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;

public class MonAttachLifecycleService extends DfService implements
    IMonAttachLifecycleService {

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2006";
  }

  public String getVersion() {
    return "1.0";
  }

  public boolean isCompatible(String str) {
    return str.equals(getVersion());
  }

  public void attachLifecycle(IDfSysObject sourceObject, String lifecycleName,
                              String stateName, String scope) throws DfException {

    System.out.println("@@@@@@@@@ IN ATTACH LC @@@@@@@@@");
    if (isAttachLifeCycleEnabled(sourceObject)) {

      String objectType = sourceObject.getTypeName();
      lifecycleName = resolveLifecycleName(lifecycleName, objectType);
      stateName = resolveStateName(stateName, objectType);

      IDfPersistentObject policyObj = getLifecycleObjectByName(sourceObject.getSession(), lifecycleName);
      sourceObject.attachPolicy(policyObj.getObjectId(),
          Integer.toString(getStateIndexFromName(policyObj, stateName)), scope);
    }
  }

  protected String execQuery(IDfSession session, String queryString)
      throws DfException {
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery(); //Create query object
    String result = null;
    q.setDQL(queryString); //Give it the query
    try {
      coll = q.execute(session, IDfQuery.DF_READ_QUERY);
      if (coll.next()) {
        result = coll.getString("coded_value");
        DfLogger.debug(this, "Query executed... Result is " + result, null, null);
      }
    } finally {
      if (coll != null)
        coll.close();
    }
    return result;
  } //execQuery

  public void syncLifecycleStateWithStateName(IDfSysObject object, String stateName) throws DfException {
    if (object != null) {
      int stateIndex = getStateIndex(object, stateName);
      if (shouldPromote(object, stateIndex)) {
        promoteToStateIndex(object, stateIndex);
      } else if (shouldDemote(object, stateIndex)) {
        demoteToStateIndex(object, stateIndex);
      }
    } else {
      throw new IllegalArgumentException("object cannot be null");
    }
  }

  private int getStateIndexFromName(IDfPersistentObject policyObj, String stateName) throws DfException {
    int stateNameIndex;
    if (stateName == null || stateName.length() == 0) {
      stateNameIndex = 0;
    } else {
      stateNameIndex = policyObj.findString("state_name", stateName);
    }
    if (stateNameIndex < 0) {
      String msg =
          "State to be applied does not exist in the lifecycle specified: " + policyObj.getObjectId() + ", " +
              stateName;
      DfLogger.warn(this, msg, null, null);
      throw new IllegalArgumentException(msg);
    }
    return stateNameIndex;
  }

  private String resolveStateName(String passedStateName, String objectType) {
    if (passedStateName == null || passedStateName.length() == 0) {
      passedStateName = getStateNameFromConfig(objectType);
    }
    if (passedStateName == null || passedStateName.length() == 0) {
      DfLogger.info(this, "State name not specified.. defaulting to first state", null, null);
    }
    return passedStateName;
  }

  private String resolveLifecycleName(String passedLifecycleName, String objectType) {
    if (passedLifecycleName == null || passedLifecycleName.length() == 0) {
      passedLifecycleName = getLifecycleNameFromConfig(objectType);
    }
    if (passedLifecycleName == null || passedLifecycleName.length() == 0) {
      throw new IllegalArgumentException("No lifecycle name specified.");
    }
    return passedLifecycleName;
  }

  private IDfPersistentObject getLifecycleObjectByName(IDfSession session, String lifecycleName) throws DfException {
    System.out.println("lifecycleName = " + lifecycleName);
    StringBuffer bufQual = new StringBuffer();
    bufQual.append("dm_policy where object_name='").append(lifecycleName).append("'");
    IDfPersistentObject policyObj = session.getObjectByQualification(bufQual.toString());
    if (policyObj == null) {
      String msg = "Unable to locate the lifecycle to be applied";
      DfLogger.warn(this, msg, null, null);
      throw new IllegalArgumentException(msg);
    }
    return policyObj;
  }

  private boolean shouldDemote(IDfSysObject object, int stateIndex) throws DfException {
    return stateIndex != -1 && stateIndex != object.getCurrentState() && stateIndex < object.getCurrentState();
  }

  private boolean shouldPromote(IDfSysObject object, int stateIndex) throws DfException {
    return stateIndex != -1 && stateIndex != object.getCurrentState() && stateIndex > object.getCurrentState();
  }

  private int getStateIndex(IDfSysObject object, String stateName) throws DfException {
    IDfPersistentObject lifecycleObject = object.getSession().getObject(object.getPolicyId());
    return lifecycleObject.findString("state_name", stateName);
  }

  private void promoteToStateIndex(IDfSysObject object, int statusIndex) throws DfException {
    while (object.getCurrentState() != statusIndex) {
      object.promote(null, false, false);
    }
  }

  private void demoteToStateIndex(IDfSysObject object, int statusIndex) throws DfException {
    while (object.getCurrentState() != statusIndex) {
      object.demote(null, false);
    }
  }

  private boolean isAttachLifeCycleEnabled(IDfSysObject sourceObject) throws DfException {
    System.out.println("sourceObject = " + sourceObject);
    boolean attachEnabled = false;
    if (sourceObject != null) {
      String sourceLifecycleName = sourceObject.getPolicyName();
      boolean policyNotAttached = (sourceLifecycleName == null || sourceLifecycleName.length() == 0);
      String lifecycleName = getLifecycleNameFromConfig(sourceObject.getTypeName());
      if (policyNotAttached && lifecycleName != null && lifecycleName.length() > 0) {
        attachEnabled = true;
      }
    } else {
      throw new IllegalArgumentException("Source object cannot be null");
    }
    return attachEnabled;
  }

  private String getLifecycleNameFromConfig(String typeName) {
    IBOConfig boConfig;

    try {
      boConfig = BOConfigFactory.newBOConfig(this);
    } catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }
    return boConfig.getValue("/" + typeName + "/lifecyclename");
  }

  private String getStateNameFromConfig(String typeName) {
    IBOConfig boConfig;
    try {
      boConfig = BOConfigFactory.newBOConfig(this);
    } catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }
    return boConfig.getValue("/" + typeName + "/initialstatename");
  }

  public boolean typeUsesScopes(IDfSysObject sourceObject) throws DfException {
    return getTypeUsesScopesFromConfig(sourceObject.getTypeName());
  }

  private boolean getTypeUsesScopesFromConfig(String typeName) {
    IBOConfig boConfig;
    try {
      boConfig = BOConfigFactory.newBOConfig(this);
    } catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }
    return Boolean.valueOf(boConfig.getValue("/" + typeName + "/usesScopes")).booleanValue();
  }

//  public String getqueryToFindScope(IDfSysObject sourceObject) throws DfException {
//    if (typeUsesScopes(sourceObject)) {
//      return getQueryToFindScopeFromConfig(sourceObject);
//    } else return null;
//  }

  private String getQueryToFindScopeFromConfig(IDfSysObject sourceObject) throws DfException {
    IBOConfig boConfig;
    try {
      boConfig = BOConfigFactory.newBOConfig(this);
    } catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }
    return boConfig.getValue("/" + sourceObject.getTypeName() + "/scopeQuery");
  }
}
