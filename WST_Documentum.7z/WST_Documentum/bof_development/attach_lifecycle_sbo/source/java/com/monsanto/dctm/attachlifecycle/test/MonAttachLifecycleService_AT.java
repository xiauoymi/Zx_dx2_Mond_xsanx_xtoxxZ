/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachlifecycle.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.attachlifecycle.MonAttachLifecycleService;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonAttachLifecycleService_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2009-03-09 20:32:20 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MonAttachLifecycleService_AT extends TestCase {
  private static final String DOCBASE = "mtctst01";
  private static final String USERID = "lakench";
  private static final String PASSWORD = "G1ng3r";

  public void testAttachLifecycleWithNulls() throws Exception {
    IMonAttachLifecycleService service = AttachLifecycleTestUtils
        .getAttachLifecycleService(DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD));
    try {
      service.attachLifecycle(null, null, null, null);
    } catch (IllegalArgumentException e) {
      // expected path
      return;
    }
    fail("Should have thrown an illegal argument exception");
  }

  public void testAttachLifecycleThatShouldAttachWithOnlySysObjectAndScope() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl30", "devl30");
    IMonAttachLifecycleService service = AttachLifecycleTestUtils.getAttachLifecycleService(sessionManager);
    IDfSession session = null;
    IDfSysObject sourceObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
      session = sessionManager.getSession("stltst03");
      sourceObject = (IDfSysObject) session.newObject("pmf_doc_luling");
      sourceObject.setString("document_number", "2001");
      sourceObject.setString("mfg_unit", "CT2");
      sourceObject.setString("doc_class", "05 Training");
      sourceObject.setString("doc_subclass", "Not Applicable");
      sourceObject.link("/Temp");

      sourceObject.save();

      assertNotNull(sourceObject);
//      sourceObject.detachPolicy();
//      assertTrue(service.typeUsesScopes(sourceObject));

//      service.attachLifecycle(sourceObject, null, null, null);

      assertEquals("PMF Luling", sourceObject.getPolicyName());
      assertEquals("Draft", sourceObject.getCurrentStateName());
      assertEquals("pmf_luling_ct2", sourceObject.getAliasSet());
    } finally {
      if (sourceObject != null) {
        sourceObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testAttachLifecycleWithOnlySysObject() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD);
    AttachLifecycleTestUtils.getAttachLifecycleService(sessionManager);
    IDfSession session = null;
    IDfSysObject sourceObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
      session = sessionManager.getSession("mtctst01");
      sourceObject = (IDfSysObject) session.newObject("dm_document");
      sourceObject.save();

//      service.attachLifecycle(sourceObject, null, null, "testscope");

      assertEquals("0000000000000000", sourceObject.getPolicyId().getId());
    } finally {
      if (sourceObject != null) {
        sourceObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testAttachLifecylceWithOnlySysobjectThatShouldAttach() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD);
    IMonAttachLifecycleService service = AttachLifecycleTestUtils.getAttachLifecycleService(sessionManager);
    IDfSession session = null;
    IDfSysObject sourceObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
      session = sessionManager.getSession("mtctst01");
      sourceObject = (IDfSysObject) session.newObject("ag_pesticide_labels");
      sourceObject.save();
      sourceObject.detachPolicy();

      service.attachLifecycle(sourceObject, null, null, null);

      assertEquals("Ag_Pesticide_labels_LC", sourceObject.getPolicyName());
      assertEquals("Blank", sourceObject.getCurrentStateName());
    } finally {
      if (sourceObject != null) {
        sourceObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }

  public void testAttachLifeCycleWithBadStateName() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD);
    IMonAttachLifecycleService service = AttachLifecycleTestUtils.getAttachLifecycleService(sessionManager);
    IDfSession session = null;
    IDfSysObject sourceObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
      session = sessionManager.getSession("mtctst01");
      sourceObject = (IDfSysObject) session.newObject("ag_pesticide_labels");
      sourceObject.save();
      sourceObject.detachPolicy();

      service.attachLifecycle(sourceObject, "Ag_Pesticide_labels_LC", "bad state name", null);
    } catch (IllegalArgumentException e) {
      //expected path
      assertEquals("0000000000000000", sourceObject.getPolicyId().getId());
      return;
    } finally {
      if (sourceObject != null) {
        sourceObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
    fail("should have thrown IllegalArgumentException");
  }

  public void testSyncLifecycleToStateNameNullSourceObject() throws Exception {
    MonAttachLifecycleService service = new MonAttachLifecycleService();
    try {
      service.syncLifecycleStateWithStateName(null, null);
    } catch (IllegalArgumentException e) {
      //expected path
      return;
    }
    fail("should have thrown an IllegalArgumentException");
  }

  public void testSyncLifecycleToStateName() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD);
    IMonAttachLifecycleService service = AttachLifecycleTestUtils.getAttachLifecycleService(sessionManager);
    IDfSession session = null;
    IDfPersistentObject sourceObject = null;
    try {
      // Note: lifecycle manipulation apparently cannot occur within a transaction
      //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
      session = sessionManager.getSession("mtctst01");
      sourceObject = session.newObject("ag_pesticide_labels");
      sourceObject.save();
      ((IDfSysObject) sourceObject).detachPolicy();
      service.attachLifecycle((IDfSysObject) sourceObject, null, null, null);
      assertEquals("Ag_Pesticide_labels_LC", ((IDfSysObject) sourceObject).getPolicyName());
      assertEquals("Blank", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "In-Progress");
      assertEquals("In-Progress", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "Printed");
      assertEquals("Printed", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "Draft Printed");
      assertEquals("Draft Printed", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "Submitted");
      assertEquals("Submitted", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "bad state name");
      assertEquals("Submitted", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, "");
      assertEquals("Submitted", ((IDfSysObject) sourceObject).getCurrentStateName());

      service.syncLifecycleStateWithStateName((IDfSysObject) sourceObject, null);
      assertEquals("Submitted", ((IDfSysObject) sourceObject).getCurrentStateName());
    } finally {
      if (sourceObject != null) {
        sourceObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
}