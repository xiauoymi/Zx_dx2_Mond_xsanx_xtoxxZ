/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.attachlifecycle.test;

import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.attachlifecycle.MonAttachLifecycleService;
import com.monsanto.dctm.pmf.IPMFDocLuling;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MonAttachLifecycleService_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:32:20 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MonAttachLifecycleService_UT extends TestCase {
    public void testCreate() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        assertNotNull(service);
    }

    public void testAttachLifecycleWithNulls() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        try {
            service.attachLifecycle(null, null, null, null);
        } catch (IllegalArgumentException e) {
            // expected path
            return;
        }
        fail("Should have thrown an illegal argument exception");
    }

    public void testAttachLifecycleWithOnlySysObject() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(new MockSession(new MockDfSessionManager()));
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "dont_attach_type");
        service.attachLifecycle(sourceObject, null, null, null);
        assertEquals("0000000000000000", sourceObject.getPolicyId().getId());
    }

    public void testAttachLifecylceWithOnlySysobjectThatShouldAttach() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "ag_pesticide_labels");
        service.attachLifecycle(sourceObject, null, null, null);
        assertEquals("Ag_Pesticide_labels_LC", sourceObject.getPolicyName());
        assertEquals("Blank", sourceObject.getCurrentStateName());
      assertFalse(service.typeUsesScopes(sourceObject));
//      assertNull(service.getqueryToFindScope(sourceObject));
    }

    public void testAttachLifecycleWithLifecycleName() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "biotech_manuscript");
        service.attachLifecycle(sourceObject, "Ag_Pesticide_labels_LC", null, null);
        assertEquals("Ag_Pesticide_labels_LC", sourceObject.getPolicyName());
        assertEquals("Blank", sourceObject.getCurrentStateName());
    }

    public void testAttachLifecycleWithNameAndState() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "biotech_manuscript");
        service.attachLifecycle(sourceObject, "Ag_Pesticide_labels_LC", "Submitted",null );
        assertEquals("Ag_Pesticide_labels_LC", sourceObject.getPolicyName());
        assertEquals("Submitted", sourceObject.getCurrentStateName());
    }

    public void testAttachLifeCycleWithBadStateName() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "biotech_manuscript");
        try {
            service.attachLifecycle(sourceObject, "Ag_Pesticide_labels_LC", "bad state name", null);
        } catch (IllegalArgumentException e) {
            //expected path
            assertEquals("0000000000000000", sourceObject.getPolicyId().getId());
            return;
        }
        fail("should have thrown IllegalArgumentException");
    }

    public void testSyncLifecycleToStateNameNullSourceObject() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        try {
            service.syncLifecycleStateWithStateName(null, null);
        } catch (IllegalArgumentException e) {
            //expected path
            return;
        }
        fail("should have thrown an IllegalArgumentException");
    }
  public void testattachLifecycleWithNameandScope() throws Exception {
    List listofObjectTypesThatUseScopes = new ArrayList();


    listofObjectTypesThatUseScopes.add("pmf_doc_luling");
    MonAttachLifecycleService service = new MockMonAttachLifecycleService(listofObjectTypesThatUseScopes);
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockpmflulingLifecycleandaliassets();
        MockSysObject sourceObject = new MockPMFDocLuling();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "pmf_doc_luling");
        service.attachLifecycle(sourceObject, "PMF Luling", null, "testscope");
        assertEquals("PMF Luling", sourceObject.getPolicyName());
        assertEquals("Draft", sourceObject.getCurrentStateName());
    assertEquals("testscope", sourceObject.getAliasSet());
    assertTrue(service.typeUsesScopes(sourceObject));
//    assertEquals("select coded_value from dm_dbo.code_lookup where decoded_value='mfg_unit' and code_type='pmf_luling_unit'", service.getqueryToFindScope(sourceObject));
  }

    public void testSyncLifecycleToStateName() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockSession session = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(session);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "ag_pesticide_labels");
        service.attachLifecycle(sourceObject, null, null, null);
        assertEquals("Ag_Pesticide_labels_LC", sourceObject.getPolicyName());
        assertEquals("Blank", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "In-Progress");
        assertEquals("In-Progress", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "Printed");
        assertEquals("Printed", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "Draft Printed");
        assertEquals("Draft Printed", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "Submitted");
        assertEquals("Submitted", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "bad state name");
        assertEquals("Submitted", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, "");
        assertEquals("Submitted", sourceObject.getCurrentStateName());

        service.syncLifecycleStateWithStateName(sourceObject, null);
        assertEquals("Submitted", sourceObject.getCurrentStateName());
    }

  private class MockPMFDocLuling extends MockSysObject implements IPMFDocLuling {
    public String getVersion() {
      return null;
    }

    public String getVendorString() {
      return null;
    }

    public boolean isCompatible(String s) {
      return false;
    }

    public boolean supportsFeature(String s) {
      return false;
    }
  }
}