/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.regulatory;

import com.documentum.fc.client.DfSysObject;
import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;

/**
 * Filename:    $RCSfile: RegAffairsRegionalDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-10-26 20:10:26 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class RegAffairsRegionalDoc extends DfSysObject
    implements IRegAffairsRegionalDoc, IDfBusinessObject, IDfDynamicInheritance {

  public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ doSave @@@@@@@@@", null, null);
    super.doSave(saveLock, versionLabel, extendedArgs);

    if (this.getPolicyId().isNull()) {
      String country = getString("country");
      if (country != null && country.length() > 0) {
        StringBuffer scope = new StringBuffer(
            "reg_affairs_").append(country);
        applyLifecycle("Country DLC", null, scope.toString());
      } else
        applyLifecycle("Country DLC", null, null);
    }

  } //doSave

  protected void applyLifecycle(String lifecycleName, String state, String scope) throws DfException {

    IDfSession session = null;

    try {
      DfLogger.debug(this, " ####  Apply Lifecycle  ### ", null, null);
      session = getSession();
      StringBuffer bufQual = new StringBuffer(64);
      bufQual.append("dm_policy where object_name='").append(
          lifecycleName).append(
          "'");
      IDfId policyId = session.getIdByQualification(bufQual.toString());
      if ((policyId == null) || (policyId.isNull())) {
        String msg = "<<<<Unable to locate the lifecycle to be applied";
        DfLogger.warn(this, msg, null, null);
        throw new IllegalArgumentException(msg);
      }
      IDfSysObject policyObj = (IDfSysObject) session.getObject(policyId);
      if (state == null || state.equals(""))
        state = policyObj.getRepeatingString("state_name", 0);
      this.attachPolicy(policyId, state, scope);
      DfLogger.debug(this, ">>>>Successfully attached policy...", null, null);
    } catch (DfException dfe) {
      DfLogger.error(this, "!!!Error attaching the policy :: " + lifecycleName, null, null);
    }
  } //applyLifecycle

  public String getVersion() {
    return "1.0";
  }

  public String getVendorString() {
    return "Copyright (c) 2006 Monsanto Corporation";
  }

  public boolean isCompatible(String string) {
    return string.equals(getVersion());
  }

  public boolean supportsFeature(String string) {
    return false;
  }
}