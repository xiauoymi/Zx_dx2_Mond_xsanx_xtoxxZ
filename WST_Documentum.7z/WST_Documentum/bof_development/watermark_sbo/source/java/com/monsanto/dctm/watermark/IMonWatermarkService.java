/*
 * Created on Aug 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.watermark;

import java.io.IOException;

import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfService;
import com.documentum.fc.common.DfException;

/**
 * @author lakench
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IMonWatermarkService extends IDfService {
	
	public boolean isTypeWatermarked(String objectType) throws BOConfigException;

	public void addWatermark(String fileLocation, String formatName, IDfSysObject sourceObject) throws DfException, IOException, BOConfigException;
}
