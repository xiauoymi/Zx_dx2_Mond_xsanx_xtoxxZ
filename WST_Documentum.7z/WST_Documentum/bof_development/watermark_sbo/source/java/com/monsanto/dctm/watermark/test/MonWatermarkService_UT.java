/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.watermark.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.watermark.MonWatermarkService;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MonWatermarkService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-03-12 15:20:09 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class MonWatermarkService_UT extends TestCase {
    public void testCreate() throws Exception {
        MonWatermarkService service = new MonWatermarkService();
        assertNotNull(service);
    }

    public void testAttachLifecycleWithNulls() throws Exception {
        MonWatermarkService service = new MonWatermarkService();
        try {
            service.addWatermark(null, null, null);
        } catch (IllegalArgumentException e) {
            // expected path
            return;
        }
        fail("Should have thrown an illegal argument exception");
    }

  public void testAddWaterMarkWithNoAttributesThrowsException() throws Exception {
      MonWatermarkService service = new MonWatermarkService();
      MockSysObject sourceObject = new MockSysObject();
      sourceObject.setSession(new MockSession(new MockDfSessionManager()));
   try{
      service.addWatermark("filelocation", "format", sourceObject);
  } catch (DfException e) {
      // expected path
      return;
  }
  fail("Should have thrown an illegal argument exception");

  }
    public void testAddWaterMarkWithNotPDFFormatThrowsException() throws Exception {
      MonWatermarkService service = new MonWatermarkService();
      MockSysObject sourceObject = new MockSysObject();
      sourceObject.setSession(new MockSession(new MockDfSessionManager()));
   try{
      service.addWatermark("filelocation", "format", sourceObject);
  } catch (DfException e) {
      // expected path
      return;
  }
  fail("Should have thrown an illegal argument exception");

  }
 public void testAddWaterMarkWithNoContentFileThrowsException() throws Exception {
      MonWatermarkService service = new MonWatermarkService();
      MockSysObject sourceObject = new MockSysObject();
      MockSession session = new MockSession(new MockDfSessionManager());
      sourceObject.setString("r_object_type", "mon_docs");
      sourceObject.setObjectName("testObject");
      session.addObject(sourceObject);
    try{
      service.addWatermark("filelocation", "pdf", sourceObject);
      System.out.println("sourceObject = " + sourceObject.getTypeName());
      assertEquals("mon_docs", sourceObject.getTypeName());
      assertEquals("testObject", sourceObject.getObjectName());
    } catch (DfException e) {
      // expected path
      return;
  }
        catch (IOException ioe) {
      // expected path
      return;
  }
  fail("File does not exist");
  }
  public void testAddWaterMarkWithAttributes() throws Exception {
      MonWatermarkService service = new MonWatermarkService();
      MockSysObject sourceObject = new MockSysObject();
      MockSession session = new MockSession(new MockDfSessionManager());
      sourceObject.setString("r_object_type", "test_object_type");
      sourceObject.setObjectName("testObject");
      session.addObject(sourceObject);
      String originalFileLocation ="C:\\Projects\\WST_Documentum\\bof_development\\watermark_sbo\\source\\java\\com\\monsanto\\dctm\\watermark\\test\\testFiles\\watermark_pagenumbers.doc";
      File originalFile = new File(originalFileLocation);

      String NewFileLocation ="C:\\Projects\\WST_Documentum\\bof_development\\watermark_sbo\\source\\java\\com\\monsanto\\dctm\\watermark\\test\\watermark.pdf";
      File newFile = new File(NewFileLocation);

      service.addWatermark("filelocation", "pdf", sourceObject);
      System.out.println("sourceObject = " + sourceObject.getTypeName());
      assertEquals("test_object_type", sourceObject.getTypeName());
      assertEquals("testObject", sourceObject.getObjectName());
  }
  public void testAddWaterMarkWithValuesFromConfig() throws Exception {
      MonWatermarkService service = new MonWatermarkService();
      MockSysObject sourceObject = new MockSysObject();
      MockSession session = new MockSession(new MockDfSessionManager());
      sourceObject.setString("r_object_type", "mon_docs");
      sourceObject.setObjectName("testObject");
      sourceObject.setString("r_version_label", "1.0");
      sourceObject.setString("r_version_label", "Draft");
      sourceObject.setString("r_version_label", "CURRENT");
      session.addObject(sourceObject);
      String originalFileLocation ="C:\\Projects\\WST_Documentum\\bof_development\\watermark_sbo\\source\\java\\com\\monsanto\\dctm\\watermark\\test\\watermark_pagenumbers.doc";
      service.addWatermark(originalFileLocation, "pdf", sourceObject);
      System.out.println("sourceObject = " + sourceObject.getTypeName());
      assertEquals("mon_docs", sourceObject.getTypeName());
      assertEquals("testObject", sourceObject.getObjectName());
//       File originalFile = new File(originalFileLocation);
//      String NewFileLocation ="C:\\Projects\\WST_Documentum\\bof_development\\watermark_sbo\\source\\java\\com\\monsanto\\dctm\\watermark\\test\\watermark.pdf";
//      File newFile = new File(NewFileLocation);
//      assertTrue(originalFile.renameTo(newFile));
//      System.out.println("originalFile = " + newFile);
//      Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + newFile);
  }



}