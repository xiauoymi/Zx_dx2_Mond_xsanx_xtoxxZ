/*
 * Created on Aug 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.watermark;

import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.devprog.common.boconfig.BOConfigFactory;
import com.documentum.devprog.common.boconfig.IBOConfig;
import com.documentum.fc.client.DfService;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;

/**
 * @author lakench
 *
 * 
 */
public class MonWatermarkService extends DfService implements
		IMonWatermarkService {

	/* (non-Javadoc)
	 * @see com.documentum.fc.client.IDfService#getVersion()
	 */
    public String getVendorString()
    {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    public String getVersion()
    {
        return "1.0";
    }

    public boolean isCompatible(String str)
    {
        return str.equals(getVersion());
    }
    
	/* (non-Javadoc)
	 * @see com.monsanto.dctm.watermark.IMonWatermarkService#isTypeWatermarked(java.lang.String)
	 */
	public boolean isTypeWatermarked(String objectType) throws BOConfigException {
		
		return (BOConfigFactory.newBOConfig(this).getValuesAsXMLNodes("/" + objectType).length > 0);
		
	}

	/* (non-Javadoc)
	 * @see com.monsanto.dctm.watermark.IMonWatermarkService#addWatermark(java.lang.String, java.lang.String)
	 */
	public void addWatermark(String fileLocation, String formatName, IDfSysObject sourceObject)
			throws DfException, IOException, BOConfigException 
	{
		
		String strFooterLeft = null;
		String strFooterCenter = null;
		String strFooterRight = null;
		String strHeaderLeft = null;
		String strHeaderCenter = null;
		String strHeaderRight = null;
		String strWatermark = null;
		String strDateFormat = null;
		String[] strArrayAttributes = null;
    String strObjectType = null;
    HashMap hAttributeValues = new HashMap();

    strObjectType = validateArguments(sourceObject, fileLocation,formatName);
    Enumeration attributes = sourceObject.enumAttrs();
    validateAttributes(attributes);

    IBOConfig boConfig = BOConfigFactory.newBOConfig(this);
				
		strFooterLeft = boConfig.getValue("/" + strObjectType + "/footer/left");
		strFooterCenter = boConfig.getValue("/" + strObjectType + "/footer/center");
		strFooterRight = boConfig.getValue("/" + strObjectType + "/footer/right");
		strHeaderLeft = boConfig.getValue("/" + strObjectType + "/header/left");
		strHeaderCenter = boConfig.getValue("/" + strObjectType + "/header/center");
		strHeaderRight = boConfig.getValue("/" + strObjectType + "/header/right");
		strWatermark = boConfig.getValue("/" + strObjectType + "/watermark");
        strDateFormat = boConfig.getValue("/" + strObjectType + "/dateformat");
        String strWatermarkGrayLevel = boConfig.getValue("/" + strObjectType + "/watermark_gray_level");
        float watermarkGrayLevel = (float) 0.5;
        if (strWatermarkGrayLevel != null && strWatermarkGrayLevel.length() > 0)
            watermarkGrayLevel = Float.parseFloat(strWatermarkGrayLevel);

        while (attributes.hasMoreElements())
        {
            String value = null;
            IDfAttr attributeObj = (IDfAttr) attributes.nextElement();
            String attribute = attributeObj.getName();
            if (attributeObj.isRepeating())
            {
                value = sourceObject.getAllRepeatingStrings(attribute, ",");
            }
            else
            {
                value = sourceObject.getValue(attribute).asString();
            }

            if (strFooterLeft != null && strFooterLeft.length() > 0)
                strFooterLeft = strFooterLeft.replaceAll("\\{" + attribute + "\\}", value);
            if (strFooterCenter != null && strFooterCenter.length() > 0)
                strFooterCenter = strFooterCenter.replaceAll("\\{" + attribute + "\\}", value);
            if (strFooterRight != null && strFooterRight.length() > 0)
                strFooterRight = strFooterRight.replaceAll("\\{" + attribute + "\\}", value);
            if (strHeaderLeft != null && strHeaderLeft.length() > 0)
                strHeaderLeft = strHeaderLeft.replaceAll("\\{" + attribute + "\\}", value);
            if (strHeaderCenter != null && strHeaderCenter.length() > 0)
                strHeaderCenter = strHeaderCenter.replaceAll("\\{" + attribute + "\\}", value);
            if (strHeaderRight != null && strHeaderRight.length() > 0)
                strHeaderRight = strHeaderRight.replaceAll("\\{" + attribute + "\\}", value);
            if (strWatermark != null && strWatermark.length() > 0)
                strWatermark = strWatermark.replaceAll("\\{" + attribute + "\\}", value);
        }
		
		if (!(strDateFormat != null && strDateFormat.length() > 0))
		{
			strDateFormat = "dd-MMM-yyyy";
		}
		String today = new SimpleDateFormat(strDateFormat).format(new Date());
		
		if (strFooterLeft != null && strFooterLeft.length() > 0)
			strFooterLeft = strFooterLeft.replaceAll("\\{\\#today\\}", today);
		if (strFooterCenter != null && strFooterCenter.length() > 0)
			strFooterCenter = strFooterCenter.replaceAll("\\{\\#today\\}", today);
    if (strFooterRight != null && strFooterRight.length() > 0)
			strFooterRight = strFooterRight.replaceAll("\\{\\#today\\}", today);
		if (strHeaderLeft != null && strHeaderLeft.length() > 0)
			strHeaderLeft = strHeaderLeft.replaceAll("\\{\\#today\\}", today);
		if (strHeaderCenter != null && strHeaderCenter.length() > 0)
			strHeaderCenter = strHeaderCenter.replaceAll("\\{\\#today\\}", today);
		if (strHeaderRight != null && strHeaderRight.length() > 0)
			strHeaderRight = strHeaderRight.replaceAll("\\{\\#today\\}", today);
		if (strWatermark != null && strWatermark.length() > 0)
			strWatermark = strWatermark.replaceAll("\\{\\#today\\}", today);

       if (formatName.equals("pdf"))
        {
			File originalFile = new File(fileLocation);
        //  String location = "C:\\Projects\\WST_Documentum\\bof_development\\watermark_sbo\\source\\java\\com\\monsanto\\dctm\\watermark\\test\\watermark_pagenumbers.pdf";
      String location =  "watermark_pagenumbers.pdf";

      File watermarkedFile = new File(location);

//       if  (!watermarkedFile.exists()){
//
//          watermarkedFile.createNewFile();
//                  //throw new DfException("File does not exist");
//       }
          try
			{
        		//replace original file with new

        		originalFile.renameTo(watermarkedFile);
        		float fXOffset = 18;
        		float fYOffest = 18;
        		float fPageHeight = 0;
        		float fPageWidth = 0;
        		
        		// we create a reader for a certain document
        		PdfReader reader = new PdfReader(location);
            int n = reader.getNumberOfPages();

          if (strFooterLeft != null && strFooterLeft.length() > 0)
    				strFooterLeft = strFooterLeft.replaceAll("\\{\\#y\\}", "" + n);
          if (strFooterCenter != null && strFooterCenter.length() > 0)
    				strFooterCenter = strFooterCenter.replaceAll("\\{\\#y\\}", "" + n);
    			if (strFooterRight != null && strFooterRight.length() > 0)
    				strFooterRight = strFooterRight.replaceAll("\\{\\#y\\}", "" + n);
    			if (strHeaderLeft != null && strHeaderLeft.length() > 0)
    				strHeaderLeft = strHeaderLeft.replaceAll("\\{\\#y\\}", "" + n);
    			if (strHeaderCenter != null && strHeaderCenter.length() > 0)
    				strHeaderCenter = strHeaderCenter.replaceAll("\\{\\#y\\}", "" + n);
    			if (strHeaderRight != null && strHeaderRight.length() > 0)
    				strHeaderRight = strHeaderRight.replaceAll("\\{\\#y\\}", "" + n);
    			if (strWatermark != null && strWatermark.length() > 0)
    				strWatermark = strWatermark.replaceAll("\\{\\#y\\}", "" + n);
    			
        		// we create a stamper that will copy the document to a new file
        		PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(fileLocation));
        		//stamp.setEncryption(com.lowagie.text.pdf.PdfWriter.STRENGTH128BITS, null, null, com.lowagie.text.pdf.PdfWriter.AllowFillIn);
        		// adding content to each page
        		int i = 0;
        		PdfContentByte under;
        		PdfContentByte over;
        		//Image img = Image.getInstance("watermark.jpg");
        		BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
        		//img.setAbsolutePosition(200, 400);
        		
        		String strHeaderLeftNoPageNum = strHeaderLeft;
        		String strHeaderCenterNoPageNum = strHeaderCenter;
        		String strHeaderRightNoPageNum = strHeaderRight;
        		String strFooterLeftNoPageNum = strFooterLeft;
        		String strFooterCenterNoPageNum = strFooterCenter;
        		String strFooterRightNoPageNum = strFooterRight;
        		String strWatermarkNoPageNum = strWatermark;
        		
        		while (i < n) {
        			i++;
        			
        			fPageHeight = stamp.getReader().getPageSizeWithRotation(i).height();
        			fPageWidth = stamp.getReader().getPageSizeWithRotation(i).width();

        			over = stamp.getOverContent(i);
        			
        			over.beginText();
        			over.setFontAndSize(bf, 10);
        			if (strHeaderLeft != null && strHeaderLeft.length() > 0)
        			{
        				strHeaderLeft = strHeaderLeftNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
                over.showTextAligned(Element.ALIGN_LEFT, strHeaderLeft, fXOffset, fPageHeight - fYOffest, 0);
        			}
        			if (strHeaderCenter != null && strHeaderCenter.length() > 0)
        			{
        				strHeaderCenter = strHeaderCenterNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				over.showTextAligned(Element.ALIGN_CENTER, strHeaderCenter, fPageWidth / 2, fPageHeight - fYOffest, 0);
        			}
        			if (strHeaderRight != null && strHeaderRight.length() > 0)
        			{
        				strHeaderRight = strHeaderRightNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				over.showTextAligned(Element.ALIGN_RIGHT, strHeaderRight, fPageWidth - fXOffset, fPageHeight - fYOffest, 0);
        			}
        			if (strFooterLeft != null && strFooterLeft.length() > 0)
        			{
        				strFooterLeft = strFooterLeftNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				over.showTextAligned(Element.ALIGN_LEFT, strFooterLeft, fXOffset, fYOffest, 0);
        			}
        			if (strFooterCenter != null && strFooterCenter.length() > 0)
        			{
        				strFooterCenter = strFooterCenterNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				over.showTextAligned(Element.ALIGN_CENTER, strFooterCenter, fPageWidth / 2, fYOffest, 0);
        			}
        			if (strFooterRight != null && strFooterRight.length() > 0)
        			{
        				strFooterRight = strFooterRightNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				over.showTextAligned(Element.ALIGN_RIGHT, strFooterRight, fPageWidth - fXOffset, fYOffest, 0);
        			}
        			if (strWatermark != null && strWatermark.length() > 0)
        			{   
        				under = stamp.getUnderContent(i);
        				under.beginText();
        				under.setFontAndSize(bf, 36);
        				under.setGrayFill(watermarkGrayLevel);

        				float rotateAngle = (float) Math.toDegrees(Math.asin(fPageHeight / Math.sqrt(fPageWidth * fPageWidth + fPageHeight * fPageHeight)));
        				
        				strWatermark = strWatermarkNoPageNum.replaceAll("\\{\\#x\\}", "" + i);
        				under.showTextAligned(Element.ALIGN_CENTER, strWatermark, fPageWidth / 2, (fPageHeight / 2) - 18, rotateAngle);
        				under.endText();
        			}
        			over.endText();
        		}
        		// closing PdfStamper will generate the new PDF file
        		stamp.close();
        		
        		
			}
        	catch (Exception de) {
        		System.out.println(de.getMessage());
        		de.printStackTrace();
        	}
        	finally
        	{
        		watermarkedFile.delete();
        	}
        }
    else {
      throw new DfException("Not a pdf format");
      }

  }

  private void validateAttributes(Enumeration attributes) {
    if (attributes == null)
     throw new IllegalArgumentException("No Attributes found");
  }

  private String validateArguments(IDfSysObject sourceObject,String fileLocation, String formatName) throws DfException {
    String strObjectType;
    if (sourceObject == null)
       throw new IllegalArgumentException("object cannot be null");
    if (fileLocation == null)
           throw new IllegalArgumentException("File location cannot be null");
    if (formatName == null)
           throw new IllegalArgumentException("Format name cannot be null");
    strObjectType = sourceObject.getTypeName();
    if (strObjectType == null)
           throw new IllegalArgumentException("object type cannot be null");
    return strObjectType;
  }

}
