/*
 * Created on Aug 12, 2005
 
 */
package com.monsanto.dctm.autonaming;

import com.documentum.devprog.autonaming.IDpAutoNamingRule;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;

/**
 * @author lakench
 */
public class UseAutonumberObjectsRule implements IDpAutoNamingRule {

  /**
   * Instance of session manager used by this rule
   */
  private IDfSessionManager m_sessMgr = null;

  /**
   * The docbase name used by this rule.
   */
  private String m_strDocbaseName = null;

  /* (non-Javadoc)
    * @see com.documentum.devprog.autonaming.IDpAutoNamingRule#getUniqueName(java.lang.String)
    */
  public String getUniqueName(String sourceObjectId) {

    IDfSession session = null;
    IDfPersistentObject sourceObject = null;
    IDfPersistentObject autonumberObject = null;

    try {
      session = m_sessMgr.getSession(m_strDocbaseName);

      sourceObject = session.getObject(new DfId(sourceObjectId));

      String strObjectType = sourceObject.getType().getName();

      if (session.getObjectByQualification("dm_type where name = 'autonumber'") != null) {
        autonumberObject = session.getObjectByQualification("autonumber where \"objtype\" = '" + strObjectType + "'");
        if (autonumberObject != null) {
          String strSubClass = sourceObject.getString("subclass");
          autonumberObject = session.getObjectByQualification(
              "autonumber where \"objtype\" = '" + strObjectType + "' and subclass = '" + strSubClass + "'");
          if (autonumberObject != null) {
            int intLastNumberUsed = Integer.parseInt(autonumberObject.getString("last_number"));
            String strPrefix = autonumberObject.getString("prefix");

            int intNewNumber = intLastNumberUsed + 1;
            String strNewNumber = String.valueOf(intNewNumber);
            String strAutoNumberUpdateQualification = "autonumber where prefix = '" + strPrefix +
                "' and \"objtype\" = '" + strObjectType + "' and last_number = '" + String.valueOf(intLastNumberUsed) +
                "'";
            IDfPersistentObject autonumberObjectToUpdate = session
                .getObjectByQualification(strAutoNumberUpdateQualification);
            while (autonumberObjectToUpdate != null) {
              autonumberObjectToUpdate.fetch(null);
              autonumberObjectToUpdate.setString("last_number", strNewNumber);
              autonumberObjectToUpdate.save();

              autonumberObjectToUpdate = session.getObjectByQualification(strAutoNumberUpdateQualification);
            }
            return strPrefix + strNewNumber;

          } else {
            return sourceObject.getString("object_name");
          }
        } else {
          return sourceObject.getString("object_name");
        }
      }
    }
    catch (DfIdentityException e) {
      e.printStackTrace();
    }
    catch (DfAuthenticationException e) {
      e.printStackTrace();
    }
    catch (DfPrincipalException e) {
      e.printStackTrace();
    }
    catch (DfServiceException e) {
      e.printStackTrace();
    }
    catch (DfException e) {
      e.printStackTrace();
    }
    finally {
      if (session != null) {
        m_sessMgr.release(session);
        session = null;
      }
    }

    return null;
  }

  /* (non-Javadoc)
    * @see com.documentum.devprog.autonaming.IDpAutoNamingRule#isValidName(java.lang.String)
    */
  public boolean isValidName(String name) {
    return false;
  }

  /* (non-Javadoc)
    * @see com.documentum.devprog.autonaming.IDpAutoNamingRule#init(com.documentum.fc.client.IDfSessionManager, java.lang.String)
    */
  public void init(IDfSessionManager session, String docbase)
      throws DfException {
    m_sessMgr = session;

    m_strDocbaseName = docbase;
  }

}
