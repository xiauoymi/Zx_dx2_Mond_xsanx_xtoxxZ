/*
 * Created on May 14, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;

/**
 * An exception that stands for a duplicate auto naming rule.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class DpDuplicateRuleException extends Exception {
}
