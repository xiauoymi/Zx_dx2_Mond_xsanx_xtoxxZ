/*
 * Created on May 15, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;

import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;


/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class TestAutoNamingService {

  private LoginManager m_loginMgr = null;

  public TestAutoNamingService(
      String username,
      String password,
      String docbase) {
    m_loginMgr = new LoginManager(username, password, docbase);
  }

  /**
   * Calls the naming service to test its working.
   *
   * @param rule
   *
   * @exception DfException
   * @exception DpAutoNamingServiceException
   */
  public void callNamingService(String rule, String oldName)
      throws DfException, DpAutoNamingServiceException {
    String docbase = m_loginMgr.getDocbase();
    IDfSessionManager sessMgr = m_loginMgr.getSessionManager();
    IDfClient localClient = DfClient.getLocalClient();
    String strNamingService = IDpAutoNamingService.class.getName();
    IDpAutoNamingService namingService =
        (IDpAutoNamingService) localClient.newService(
            strNamingService,
            sessMgr);

    String uniqueName = namingService.getUniqueName(docbase, rule, oldName);

    System.out.println("Rule used: " + rule);
    System.out.println("Old name: " + oldName);
    System.out.println("Unique name: " + uniqueName);

  }

  /**
   * Creates the storage object in the docbase. The name of the object is set to 'dp_autonaming_service'
   *
   * @param type Object type. Currently dm_sysobject
   *
   * @exception DfException
   * @exception IOException
   */
  public void createStorageObject(String type) throws DfException, IOException {
    try {
      System.out.println("About to create an object of type: " + type);
      IDfSession session = m_loginMgr.getSession();
      IDfSysObject sysObj = (IDfSysObject) session.newObject(type);
      sysObj.setObjectName("dp_autonaming_service");
      sysObj.setContentType("binary");

      HashMap hmap = new HashMap();
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      ObjectOutputStream objOut = new ObjectOutputStream(bout);
      objOut.writeObject(hmap);

      sysObj.setContent(bout);
      sysObj.save();

      System.out.println("Storage object created");

    }
    finally {
      m_loginMgr.releaseSession();
    }
  }

  public static void main(String[] args) {
    try {
      //DfLogger.getLogger("com.documentum.devprog").setLevel(Level.DEBUG);
      if (args.length < 5) {
        System.out.println("Invalid number of arguments.");
        System.out.println(
            "The arguments are- username password docbase create/getUnique typeName/ruleName oldName");
        System.exit(1);
      }

      System.out.println("getting an instance of TestAutoNamingService");
      TestAutoNamingService test =
          new TestAutoNamingService(args[0], args[1], args[2]);

      if (args[3].equals("create")) {
        test.createStorageObject(args[4]);
      } else if (args[3].equals("getUnique")) {
        test.callNamingService(args[4], args[5]);
      } else {
        System.out.println(
            "Invalid flag. Use either 'create' or 'getUnique'");
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }

  }
}
