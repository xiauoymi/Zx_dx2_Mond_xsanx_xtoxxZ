/*
 * Created on May 14, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;

import com.documentum.devprog.common.BOConfig;
import com.documentum.fc.client.DfService;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * An implementation for the auto naming service based business object.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class DpAutoNamingService
    extends DfService
    implements IDpAutoNamingService {

  /**
   * Version of the SBO
   */
  private String m_strVersion = "1.0";

  /**
   * Description of the vendor of the SBO.
   */
  private String m_strVendorDescription = "Documentum Developer Program";

  /**
   * The configuration object.
   */
  private BOConfig m_boConfig = null;

  /**
   * The configuration scope that defines the mapping of all rule names to their implementation classes
   */
  private String RULES = "rules";

  /**
   * The name of the configuration attribute that stores the docbase object type that contains the information
   * regarding the rules.
   */
  private String DOCBASE_OBJECT_KEY = "dataStorageObject";

  /**
   * Returns the name of the configurationt that contains the mapping of the rule names to their implementation
   * classes.
   *
   * @return The rules table name.
   */
  protected String getRuleTableName() {
    return RULES;
  }

  /*
  * @return
  *
  * @see com.documentum.fc.client.IDfService#getVersion()
  */
  public String getVersion() {
    return m_strVersion;
  }

  /*
  * @return
  *
  * @see com.documentum.fc.client.IDfService#getVendorString()
  */
  public String getVendorString() {
    return m_strVendorDescription;
  }

  /*
  * @param version
  * @return
  *
  * @see com.documentum.fc.client.IDfService#isCompatible(java.lang.String)
  */
  public boolean isCompatible(String version) {
    if (version.equals(getVersion())) {
      return true;
    }
    return false;
  }


  /**
   * @param docbase  docbase name
   * @param strRule  the rule name to use
   * @param oldValue Old value to be used by rule while computing new value. <br>If oldValue is null, then it is
   *                 assumed that the <br>oldValue needs to be retrieved from the docbase.
   *
   * @return The new name.
   *
   * @exception DfException
   * @see com.documentum.devprog.autonumber.IDpAutoNamingService#getUniqueName(String, String)
   */
  public String getUniqueName(String docbase, String strRule, String oldValue)
      throws DfException, DpAutoNamingServiceException {
    DfLogger.debug(this, "getUniqueName - rule -" + strRule, null, null);
    BOConfig config = getConfigObject();

    if (config.hasAttribute(getRuleTableName(), strRule)) {


      String values[] =
          config.getAttributeValue(getRuleTableName(), strRule);
      String ruleClassName = values[0];
      IDpAutoNamingRule rule = initializeRule(docbase, ruleClassName);

      if (oldValue != null) //use value supplied by user.
      {
        DfLogger.debug(this, "User supplied old value: " + oldValue, null, null);
        String newValue = rule.getUniqueName(oldValue);
        return newValue;
      }

      //retrieve oldValue from docbase if user did not supply it.
      RuleValue ruleValue = getCurrentUniqueValue(docbase, strRule);
      String newValue = rule.getUniqueName(ruleValue.getUniqueName());
      ruleValue.setUniqueName(newValue);
      setCurrentUniqueValue(docbase, strRule, ruleValue);
      return newValue;
    } else {
      throw new DpAutoNamingServiceException("Unable to locate the rule");
    }
  }

  /*
  * @param docbase
  * @param strRuleName
  * @return
  *
  * @see com.documentum.devprog.autonumber.IDpAutoNamingService#doesRuleExist(java.lang.String, java.lang.String)
  */
  public boolean doesRuleExist(String docbase, String strRuleName) {
    BOConfig config = getConfigObject();
    return config.hasAttribute(RULES, strRuleName);
  }

  /*
  * NOT IMPLEMENTED IN THIS CLASS
  *
  * @param ruleName
  * @param ruleImplementation
  * @throws DpDuplicateRuleException
  *
  * @see com.documentum.devprog.autonumber.IDpAutoNamingService#registerRule(java.lang.String, com.documentum.devprog.autonumber.IDpAutoNamingRule)
  */
  public void registerRule(
      String docbase,
      String ruleName,
      IDpAutoNamingRule ruleImplementation)
      throws DpDuplicateRuleException {
    //This method is not implemented.

  }

  /**
   * Loads the class that implements the rule and initializes it by calling the IDpAutoNamingRule#initialize(...)
   * method.
   *
   * @param docbase       docbaseName
   * @param ruleClassName The class the implements the rule.
   *
   * @return instance of IDpAutoNamingRule
   *
   * @exception DpAutoNamingServiceException
   */
  protected IDpAutoNamingRule initializeRule(
      String docbase,
      String ruleClassName)
      throws DpAutoNamingServiceException {
    try {
      Class ruleClass = Class.forName(ruleClassName);
      Class initArgs[] = {IDfSessionManager.class, String.class};
      Method initMethod = ruleClass.getMethod("init", initArgs);

      IDpAutoNamingRule rule = (IDpAutoNamingRule) ruleClass.newInstance();
      IDfSessionManager sessMgr = getSessionManager();
      Object argsObj[] = {sessMgr, docbase};
      initMethod.invoke(rule, argsObj);

      DfLogger.debug(this, "Initialized class for rule: " + rule, null, null);
      return rule;
    }
    catch (IllegalAccessException iae) {
      throw new DpAutoNamingServiceException("Unable to instantiate the rule class due to IllegalAccessException");
    }
    catch (ClassNotFoundException cnfe) {
      throw new DpAutoNamingServiceException("Unable to locate the rule implementation class. ClassNotFoundException");
    }
    catch (InstantiationException ie) {
      throw new DpAutoNamingServiceException("Unable to instantiate class");
    }
    catch (InvocationTargetException ite) {
      throw new DpAutoNamingServiceException("Unable to invoke the init method on rule class");
    }
    catch (NoSuchMethodException nsme) {
      throw new DpAutoNamingServiceException("Unable to locate the init method in rule class");
    }

  }

  /**
   * Returns a reference to the configuration object.
   *
   * @return Configuration object.
   */
  protected BOConfig getConfigObject() {
    if (m_boConfig == null) {
      m_boConfig = new BOConfig(this, true);
    }
    return m_boConfig;
  }

  /**
   * Initialises the configuration object.
   */
  protected void initConfig() {
    m_boConfig = new BOConfig(this, true);
  }

  /**
   * Reads the current unique value from the docbase objects content.
   *
   * @param docbase
   * @param objectType
   * @param objectName
   * @param strRule
   *
   * @return
   *
   * @exception DfException
   * @exception DpAutoNamingServiceException
   */
  protected RuleValue getCurrentUniqueValue(String docbase, String strRule)
      throws DfException, DpAutoNamingServiceException {
    IDfSession session = null;
    try {

      IDfSysObject autonameObj = getAutonamingObject(docbase);
      ObjectInputStream objIn =
          new ObjectInputStream(autonameObj.getContent());
      HashMap mapRuleValues = (HashMap) objIn.readObject();
      DfLogger.debug(this, "retrieved hmap from docbase", null, null);
      RuleValue ruleVal = null;
      if (mapRuleValues.containsKey(strRule)) {
        DfLogger.debug(this, "hmap contains key", null, null);
        ruleVal = (RuleValue) mapRuleValues.get(strRule);
      } else {
        DfLogger.debug(this, "hmap does not contain the rule", null, null);
        ruleVal = new RuleValue();
        ruleVal.setUniqueName(IDpAutoNamingRule.NOT_USED_AS_YET);
      }
      objIn.close();
      return ruleVal;
    }
    catch (IOException ioe) {
      throw new DpAutoNamingServiceException("Unable to read autonaming docbase object data");
    }
    catch (ClassNotFoundException cnfe) {
      throw new DpAutoNamingServiceException("Unable to read autonaming docbase object data");
    }
    finally {
      if (session != null) {
        releaseSession(session);
      }
    }

  }

  /**
   * Returns the dm_sysobject object used to store the current rule values for all the rules. The object is used
   * primarily for storage purposes.
   *
   * @param docbase The docbase that contains the storage object.
   *
   * @return the storage object
   *
   * @exception DfException
   */
  protected IDfSysObject getAutonamingObject(String docbase)
      throws DfException {
    IDfSession session = null;
    try {
      BOConfig config = getConfigObject();
      String objectType = config.getType(DOCBASE_OBJECT_KEY);
      String values[] = config.getAttributeValue(DOCBASE_OBJECT_KEY);
      String objectName = values[0];

      StringBuffer bufQuery = new StringBuffer(32);
      bufQuery.append(objectType);
      bufQuery.append(" where ");
      bufQuery.append(" object_name like '");
      bufQuery.append(objectName);
      bufQuery.append("'");

      session = getSession(docbase);
      IDfSysObject autonameObj =
          (IDfSysObject) session.getObjectByQualification(
              bufQuery.toString());
      DfLogger.debug(this, "autonaming object : " + autonameObj.getObjectName(), null, null);
      return autonameObj;

    }
    finally {
      if (session != null) {
        releaseSession(session);

      }
    }
  }

  /**
   * Stores a new unique value for a rule in the storage object.
   *
   * @param docbase   Docbase that contains the storage object.
   * @param ruleName  The rule whose new unique value is being stored
   * @param ruleValue The new value
   *
   * @exception DfException
   * @exception DpAutoNamingServiceException
   */
  protected void setCurrentUniqueValue(
      String docbase,
      String ruleName,
      RuleValue ruleValue)
      throws DfException, DpAutoNamingServiceException {
    IDfSysObject autonameObj = null;
    try {

      autonameObj = getAutonamingObject(docbase);

      //autonameObj.lock();
      autonameObj.checkout();
      ObjectInputStream objIn =
          new ObjectInputStream(autonameObj.getContent());
      HashMap mapRuleValues = (HashMap) objIn.readObject();
      DfLogger.debug(this, "retrieved hmap to set a new value", null, null);
      objIn.close();

      mapRuleValues.put(ruleName, ruleValue);

      ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
      ObjectOutputStream objOut = new ObjectOutputStream(byteOut);
      DfLogger.debug(this, "about to write hmap into ostream", null, null);
      objOut.writeObject(mapRuleValues);

      autonameObj.setContent(byteOut);


      autonameObj.save();
    }
    catch (IOException ioe) {
      DfLogger.error(this, ioe.getMessage(), null, ioe);
      throw new DpAutoNamingServiceException("Error while updating rule values in docbase");
    }
    catch (ClassNotFoundException cnfe) {
      throw new DpAutoNamingServiceException("Error while reading rule values from docbase object");
    }
    finally {
      if ((autonameObj != null) && (autonameObj.isCheckedOut())) {
        autonameObj.checkin(false, "");
      }
    }
  }

}


