/*
 * Created on Jul 11, 2003
 *
 */
package com.documentum.devprog.autonaming;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;


/**
 * The rule replaces a pound sign (#) in a nem with a new unique number. For example: oldName - MNC_#_XYZ newName -
 * MNC_4_XYZ
 *
 * It uses the SimpleNumberIncrementRule to obtain a new unique number
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class PoundReplaceRule implements IDpAutoNamingRule {

  /**
   * Instance of session manager used by this rule
   */
  private IDfSessionManager m_sessMgr = null;

  /**
   * The docbase name used by this rule.
   */
  private String m_strDocbaseName = null;


  /**
   * @return <br> If oldName contained pound (#) sign, then this pound sign is <br> replaced with a new unique number.
   *         <br> <br> If oldName did not contain a pound(#) sign, then the oldName <br> is returned as is without
   *         modifications.
   *
   *         <br><br>If failure occurs a <code>null</code> is returned.
   *
   * @see IDpAutoNamingRule#getUniqueName(String)
   */
  public String getUniqueName(String oldName) {
    try {

      DfLogger.debug(this, "pound replace rule invoked", null, null);
      int indexPound = oldName.indexOf('#');
      if (indexPound == -1) {
        DfLogger.debug(
            this,
            "# not found in string " + oldName,
            null,
            null);

        return oldName; //no autonumbering to be done
      }

      DfLogger.debug(this, "found # in " + indexPound, null, null);

      StringBuffer strBufObjName = new StringBuffer(32);
      strBufObjName.append(oldName.substring(0, indexPound));

      IDfClient localClient = DfClient.getLocalClient();
      String strServiceName = IDpAutoNamingService.class.getName();
      IDpAutoNamingService autoNumber = (IDpAutoNamingService) localClient.newService(strServiceName, m_sessMgr);
      String number = autoNumber.getUniqueName(m_strDocbaseName, "simpleNumberingRule", null);
      DfLogger.debug(this, "Got unique number: " + number, null, null);

      strBufObjName.append("_");
      strBufObjName.append(number);
      strBufObjName.append("_");

      strBufObjName.append(
          oldName.substring(indexPound + 1, oldName.length()));

      String strFinalName = strBufObjName.toString();

      DfLogger.debug(
          this,
          "Final object name: " + strFinalName,
          null,
          null);
      return strFinalName;

    }

    catch (Exception spe) {
      DfLogger.error(this, "", null, spe);

    }
    return null;

  }


  /* (non-Javadoc)
  * @see com.documentum.devprog.autonaming.IDpAutoNamingRule#init(com.documentum.fc.client.IDfSessionManager, java.lang.String)
  */
  public void init(IDfSessionManager session, String docbase)
      throws DfException {
    m_sessMgr = session;

    m_strDocbaseName = docbase;

  }

  /**
   * Not implemented since not relevant.
   *
   * @return false At all times.
   *
   * @see IDpAutoNamingRule#isValidName(String)
   */
  public boolean isValidName(String name) {
    return false;
  }


}
