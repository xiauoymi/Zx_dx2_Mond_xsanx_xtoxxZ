/*
 * Created on May 14, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */

package com.documentum.devprog.autonaming;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;

/**
 * Implements an auto naming rule. The rule simply increments numbers and returns a new number.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class SimpleNumberIncrementRule implements IDpAutoNamingRule {

  /**
   * @param oldName
   *
   * @return A new unique number
   *
   * @see com.documentum.devprog.autonumber.IDpAutoNamingRule#getUniqueName(String)
   */
  public String getUniqueName(String oldNumber) {
    try {
      if (oldNumber.equals(NOT_USED_AS_YET)) {
        return Long.toString(1);
      }

      long lOldName = Long.parseLong(oldNumber);
      lOldName++;
      return (Long.toString(lOldName));

    }
    catch (NumberFormatException nfe) {
      DfLogger.error(this, "Unable to parse the old number", null, null);
      return null;
    }
  }

  /**
   * Checks for the validity of the number. Parses a string to search for a positive number
   *
   * @param name The name to check
   *
   * @return true=> A string parses correctly to a number. <br>false=> Otherwise.
   *
   * @see com.documentum.devprog.autonumber.IDpAutoNamingRule#isValidName(String)
   */
  public boolean isValidName(String name) {
    try {
      Long.parseLong(name);
      return true;
    }
    catch (NumberFormatException nfe) {
      return false;
    }

  }

  /**
   * Does nothing since this rule does not interact with the docbase at all.
   *
   * @param session
   * @param docbase
   *
   * @exception DfException
   * @see com.documentum.devprog.autonumber.IDpAutoNamingRule#init(com.documentum.fc.client.IDfSession)
   */
  public void init(IDfSessionManager sessMgr, String docbase) throws DfException {


  }

}
