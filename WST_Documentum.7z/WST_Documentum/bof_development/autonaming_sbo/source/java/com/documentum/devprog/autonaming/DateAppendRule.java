/*
 * Created on Jul 11, 2003
 * 
 * Documentum Developer Program 2003
 *
 */
package com.documentum.devprog.autonaming;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Appends a date string of form _MMddYY to the end of the name and returns the new name.
 *
 * <br>Example: <br>oldName - MNC <br>newName - MNC_071003
 *
 * <br>Date above stands for 10th July 2003.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class DateAppendRule implements IDpAutoNamingRule {

  /**
   * Constructs a string of form <code>oldName_MMddyy</code> MMddyy stands for the date in the above format.
   *
   * @see IDpAutoNamingRule#getUniqueName(String)
   */
  public String getUniqueName(String oldName) {
    StringBuffer strBuf = new StringBuffer(32);
    strBuf.append(oldName);
    strBuf.append("_");
    strBuf.append(getDateString());
    return strBuf.toString();

  }

  /**
   * Not used. Always returns false
   *
   * @see IDpAutoNamingRule#isValidName(String)
   */
  public boolean isValidName(String name) {
    // TODO Auto-generated method stub
    return false;
  }

  /**
   * does nothing since rule is not docbase specific
   *
   * @see IDpAutoNamingRule#init(com.documentum.fc.client.IDfSessionManager,
   *      String)
   */
  public void init(IDfSessionManager session, String docbase)
      throws DfException {

  }

  /**
   * Prepares a date string of form MMddyy
   *
   * MM - two digit month number dd - two digit date 0..31 yy - two digit year number. Example '03' means 2003
   *
   * @return date string of form MMddyy
   */
  private String getDateString() {

    Date date = new Date(System.currentTimeMillis());
    SimpleDateFormat dateFormat =
        (SimpleDateFormat) DateFormat.getDateInstance();
    dateFormat.applyPattern("MMddyy");
    String strDate = dateFormat.format(date);
    return strDate;

  }

}
