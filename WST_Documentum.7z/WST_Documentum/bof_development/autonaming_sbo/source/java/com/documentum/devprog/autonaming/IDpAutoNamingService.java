/*
 * Created on May 14, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;


import com.documentum.fc.common.DfException;

/**
 * Provides an interface to obtain a unique number or name based on a rule. It uses a docbase object to store the data.
 * It is not implemented as a TBO because, - no modifications were done to a behavior of a docbase type. - no events
 * such as checkin, checkout need to be trapped.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public interface IDpAutoNamingService {
  /**
   * Get a unique name based on a specified rule.
   *
   * @param docbase  The docbase name
   * @param strRule  A rule to use to generate
   * @param oldValue The current/old value.
   *
   * @return a unique name
   *
   * @exception DfException
   */
  public String getUniqueName(String docbase, String strRule, String oldValue) throws DfException,
      DpAutoNamingServiceException;

  /**
   * Checks if a rule by the name <code>strRuleName</code> is already registered with the auto naming service.
   *
   * @param strRuleName A rule name
   *
   * @return true=>if rule is already registered. <br>false=>if rule not registered.
   */
  public boolean doesRuleExist(String docbase, String strRuleName);

  /**
   * Registers a new rule with name <code>ruleName</code> whose implementation is specified by
   * <code>ruleImplementation</code>
   *
   * @param docbase            The docbase name
   * @param ruleName           Name of the new rule to register.
   * @param ruleImplementation The implementation class of the rule.
   *
   * @exception DpDuplicateRuleException
   */
  public void registerRule(String docbase, String ruleName, IDpAutoNamingRule ruleImplementation) throws
      DpDuplicateRuleException;

}
