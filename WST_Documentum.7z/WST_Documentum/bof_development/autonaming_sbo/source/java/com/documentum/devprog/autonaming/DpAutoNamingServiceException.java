/*
 * Created on May 14, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;

/**
 * An empty class
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class DpAutoNamingServiceException extends Exception {

  /**
   *
   */
  public DpAutoNamingServiceException() {
    super();
  }

  /**
   * @param s
   */
  public DpAutoNamingServiceException(String s) {
    super(s);
  }

}
