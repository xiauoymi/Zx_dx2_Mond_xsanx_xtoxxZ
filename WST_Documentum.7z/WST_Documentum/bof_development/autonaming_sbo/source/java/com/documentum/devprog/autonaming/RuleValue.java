/*
 * Created on May 15, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.autonaming;

import java.io.Serializable;

/**
 * A class that stores values corresponding to a rule. A value consists of a unique name and number. A rule may
 * choose to use either a rule or a number or both. For example, the SimpleNumberIncrementRule behaves same for both
 * a number and a name.
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class RuleValue implements Serializable {
  /**
   * Unique name value of the rule
   */
  String m_strUniqueName = null;

  /**
   * unique number value of the rule
   */
  String m_strUniqueNumber = null;

  /**
   * Sets a unique name
   *
   * @param name
   */
  void setUniqueName(String name) {
    m_strUniqueName = name;
  }

  /**
   * Gets the current unique name
   *
   * @return
   */
  String getUniqueName() {
    return m_strUniqueName;
  }


}