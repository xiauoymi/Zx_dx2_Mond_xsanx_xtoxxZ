/*
 * Created on May 19, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.devprog.common.UtilityMethods;
import com.documentum.devprog.deepexport.DpDeepExportServiceException;
import com.documentum.devprog.deepexport.IDpDeepExportService;
import com.documentum.devprog.deepimport.IDpDeepImportService;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Implementation of the zip service SBO version 2.0
 *
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class DpZipService extends DfService implements IDpZipService {

  /**
   * The SBO version.
   */
  private String m_strVersion = "1.2";

  /**
   * The description of the vendor of the SBO
   */
  private String m_strVendorDescription = "Documentum Developer Program 2004";

  /*
  * @return
  *
  * @see com.documentum.fc.client.IDfService#getVersion()
  */
  public String getVersion() {
    return m_strVersion;
  }

  /*
  * @return
  *
  * @see com.documentum.fc.client.IDfService#getVendorString()
  */
  public String getVendorString() {
    return m_strVendorDescription;
  }

  /*
  * @param version
  * @return
  *
  * @see com.documentum.fc.client.IDfService#isCompatible(java.lang.String)
  */
  public boolean isCompatible(String version) {
    return version.equals(getVersion());
  }

  /*
  * @param localDirectory
  * @param containingFolderId
  * @param zipFilename
  * @throws DfException
  * @throws IOException
  *
  * @see com.documentum.devprog.common.zip.IDpZipService#importAsZip(java.lang.String, com.documentum.fc.common.IDfId, java.lang.String)
  */

  /**
   * PDL -create a zip of directory - create a temp file to store the zip.
   *
   * -import the zip - delete the temp zip file.
   */
  public IDfId importAsZip(
      String localDirectory,
      IDfId containingFolderId,
      String zipFilename)
      throws DfException, IOException {
    IDfSession session = null;
    try {

      File tempZipFile =
          File.createTempFile(
              "tmp_com_documentum_devprog_common_zip_DpZipService",
              ".zip");
      String toZip[] = {localDirectory};
      IZipUtility zipUtil = new ZipUtility();
      zipUtil.createZip(toZip, tempZipFile);

      IDfClient localClient = DfClient.getLocalClient();
      String docbase = localClient.getDocbaseNameFromId(containingFolderId);
      session = getSession(docbase);

      IDfClientX clientX = new DfClientX();
      IDfImportOperation importOper = clientX.getImportOperation();
      importOper.setDestinationFolderId(containingFolderId);
      importOper.setSession(session);
      IDfImportNode importNode =
          (IDfImportNode) importOper.add(tempZipFile.getPath());
      importNode.setFormat("zip");
      importNode.setNewObjectName(zipFilename);
      importNode.setKeepLocalFile(false);
      importNode.setDocbaseObjectType("dm_document");

//         //setting template to assign acl...
//         String query = "select  where object_name ='test zip template.zip' and folder ('/Templates')";
//        try{
//         IDfSysObject myObj = (IDfSysObject) session.getObjectByQualification( qualification ); 
//         if(myObj != null){
//         System.out.println("*** from zip service template name  "+myObj.getObjectName());
//         importNode.setTemplate(myObj);
//         }else{
//             System.out.println("*** from zip service ZIP Template is not available, check /Templates cabinet for basic ZIP template ");
//         }
//        }
//         catch(DfException dex){
//             System.out.println("ERROR: ZIP Service : ");
//              DfLogger.warn(
//               this,
//               "Import operation of the zip file failed",
//               null,
//               null);
//         }

      if (importOper.execute() == false) {
        DfLogger.warn(
            this,
            "Import operation of the zip file failed",
            null,
            null);
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        UtilityMethods.printOperationErrors(bout, importOper.getErrors());
        DfLogger.warn(this, bout.toString(), null, null);
        bout.close();
        throw new RuntimeException("Zip import failed. Check log for error list");
      } else {
        String qualification = null;
        IDfId newObjId = importNode.getNewObjectId();
        IDfSysObject doc = (IDfSysObject) session.getObject(newObjId);
        qualification = "dm_acl where object_name ='O:Delete W:Read'";
        IDfACL docACL = (IDfACL) session.getObjectByQualification(qualification);
        if (docACL != null) {
          doc.setACL(docACL);
          doc.save();
        } else {
          DfLogger.debug(this,
              "Could not find ACL 'O:D W:R' in this Docbase. In order to delete ZIP files, created from exporting folders, this acl should exist in this docbase",
              null, null);
        }
        return newObjId;
      }

    }

    finally {
      if (session != null) {
        releaseSession(session);
      }
    }

  }

  /*
  * @param folderId
  * @param localDirectory
  * @throws DfException
  * @throws IOException
  *
  * @see com.documentum.devprog.common.zip.IDpZipService#exportAsZip(com.documentum.fc.common.IDfId, java.lang.String)
  */
  public String exportAsZip(IDfId folderId, String localDirectory)
      throws DfException, IOException {
    if ((folderId == null) || (folderId.isNull())) {
      throw new IllegalArgumentException("Id of the folder to zip is null");
    }

    IDfSession session = null;
    try {

      File tempDir = new File(localDirectory);
      if (tempDir.mkdirs() || tempDir.exists()) {
        DfLogger.debug(
            this,
            "Created temp dir: " + tempDir.getPath(),
            null,
            null);
      } else {
        DfLogger.warn(
            this,
            "Failed to Create dir for export of docbase files ",
            null,
            null);
        throw new IOException("Failed to create directories for export of docbase files");
      }

      IDfClient localClient = DfClient.getLocalClient();
      IDfSessionManager sessMgr = getSessionManager();
      String strDeepExport = IDpDeepExportService.class.getName();
      IDpDeepExportService deepExport =
          (IDpDeepExportService) localClient.newService(
              strDeepExport,
              sessMgr);
      DfLogger.debug(
          this,
          "Obtained handle to deep export service",
          null,
          null);

      String exportedDirectoryPath =
          deepExport.deepExportFolder(folderId, tempDir.getPath());
      DfLogger.debug(
          this,
          "Exported folder to " + exportedDirectoryPath,
          null,
          null);

      File expDir = new File(exportedDirectoryPath);
      String strArrToZip[] = {exportedDirectoryPath};
      StringBuffer bufZipName = new StringBuffer(32);
      bufZipName
          .append(tempDir.getAbsolutePath())
          .append(System.getProperty("file.separator"))
          .append(expDir.getName())
          .append(".zip");
      File finalZipFile = new File(bufZipName.toString());
      IZipUtility zipUtility = new ZipUtility();
      zipUtility.createZip(strArrToZip, finalZipFile);

      //delete temporary directory created for export.
      if (tempDir.exists()) {
        cleanupDirectory(expDir);
      }

      DfLogger.debug(
          this,
          "Final zip file is " + finalZipFile.getAbsolutePath(),
          null,
          null);
      return finalZipFile.getAbsolutePath();

    }
    catch (DpDeepExportServiceException dpse) {
      throw new RuntimeException("Unable to create zip. Failed to export contents to zip");
    }
    catch (Exception ex) {
      DfLogger.debug(this, "Exception", null, ex);
    }
    finally {
      if (session != null) {
        releaseSession(session);
      }
    }
    return null;
  }

  /*
  * @param folderId
  * @param containingFolderId
  * @throws DfException
  * @throws IOException
  *
  * @see com.documentum.devprog.common.zip.IDpZipService#createZipInDocbase(com.documentum.fc.common.IDfId, com.documentum.fc.common.IDfId)
  */
  /*
  * PDL:
  * -perform deep export of the docbase folder
  *  - create a temp folder to contain the deep exported folder
  * -import as zip the deep exported folder.
  */
  public IDfId createZipInDocbase(
      IDfId folderId,
      IDfId containingFolderId,
      String zipFilename)
      throws DfException, IOException {
    if ((folderId == null) || (folderId.isNull())) {
      throw new IllegalArgumentException("Id of the folder to zip is null");
    }

    if ((containingFolderId == null) || (containingFolderId.isNull())) {
      throw new IllegalArgumentException("Id of the folder that will store the zip is null");
    }

    IDfSession session = null;
    try {
      //Create a temp directory to deep export to
      String strTempDir = System.getProperty("java.io.tmpdir");
      DfLogger.debug(this, "Temp dir: " + strTempDir, null, null);
      String strRandomDirName =
          Integer.toString((int) (Math.random() * 1000));
      StringBuffer bufTempDeepExportDir =
          new StringBuffer(
              strTempDir.length() + strRandomDirName.length() + 2);
      bufTempDeepExportDir
          .append(strTempDir)
          .append(System.getProperty("file.separator"))
          .append(strRandomDirName);
      File tempDir = new File(bufTempDeepExportDir.toString());
      if (tempDir.mkdirs()) {
        DfLogger.debug(
            this,
            "Created temp dir: " + tempDir.getPath(),
            null,
            null);
      } else {
        DfLogger.warn(
            this,
            "Failed to Create temp dir for export of docbase files ",
            null,
            null);
        throw new IOException("Failed to create directories for export of docbase files");
      }

      IDfClient localClient = DfClient.getLocalClient();
      DfLogger.debug(this, "Got local client", null, null);
      IDfSessionManager sessMgr = getSessionManager();
      DfLogger.debug(this, "Got sess mgr", null, null);
      String strDeepExport = IDpDeepExportService.class.getName();
      //DfLogger.debug(this,"deep export service name: " + strDeepExport,null,null);
      IDpDeepExportService deepExport =
          (IDpDeepExportService) localClient.newService(
              strDeepExport,
              sessMgr);
      DfLogger.debug(
          this,
          "Obtained handle to deep export service",
          null,
          null);

      String exportedDirectoryPath =
          deepExport.deepExportFolder(folderId, tempDir.getPath());
      DfLogger.debug(
          this,
          "Exported folder to " + exportedDirectoryPath,
          null,
          null);

      IDfId importedZip =
          importAsZip(exportedDirectoryPath, containingFolderId, zipFilename);
      DfLogger.debug(
          this,
          "Import folder as zip with id " + importedZip,
          null,
          null);

      //added code to cleanup the temporary directory
      if (tempDir.exists()) {
        cleanupDirectory(tempDir);
      }
      return importedZip;
    }
    catch (DpDeepExportServiceException dpse) {
      throw new RuntimeException("Unable to create zip. Failed to export contents to zip");
    }
    catch (Exception ex) {
      DfLogger.debug(this, "Exception", null, ex);
    }
    finally {
      if (session != null) {
        releaseSession(session);
      }
    }
    return null;
  }

  /* (non-Javadoc)
  * @see com.documentum.devprog.common.zip.IDpZipService#extractZipInDocbase(java.lang.String, java.lang.String, java.lang.String)
  */
  public IDfId extractZipInDocbase(
      String docbase,
      String zipFileLocation,
      String docbaseFolderSpec)
      throws DfException, IOException {

    if (DfLogger.isDebugEnabled(this)) {
      DfLogger.debug(
          this,
          "Zip file location: " + zipFileLocation,
          null,
          null);
    }
    boolean isURL = true;
    File zipFile = null;
    File tempDir = createTempDirectory();
    if (tempDir == null) {
      throw new IOException("Failed to create a temporary directory to extract the zip");
    }

    try {
      URL url = new URL(zipFileLocation);

      //if execution continues to this line means the string is a valid
      //URL. Need to first download the zip file to the DFC machines
      //filesystem
      InputStream urlIs = url.openStream();
      BufferedInputStream bufIs = new BufferedInputStream(urlIs);
      byte[] buf = new byte[1024];
      int numRead = 0;
      zipFile =
          File.createTempFile("com_documentum_devprog_zip_service_", "zip");
      FileOutputStream fout = new FileOutputStream(zipFile);
      while ((numRead = bufIs.read(buf)) != -1) {
        fout.write(buf, 0, numRead);
      }
      fout.close();
    }
    catch (MalformedURLException mue) {
      if (DfLogger.isDebugEnabled(this)) {
        DfLogger.debug(this, "Not a URL: " + mue.getMessage(), null, null);
      }
      //The specified string was not a valid URL. Maybe its a file path
      isURL = false;
    }

    if (isURL == false) {
      zipFile = new File(zipFileLocation);
      if (zipFile.exists() == false) {
        if (DfLogger.isDebugEnabled(this)) {

          DfLogger.debug(this, "The specified zip file to extract does not exist", null, null);
        }
        //return invalid ID
        return new DfId("0000000");
      }
    }

    //first extract the zip on the filesystem of the DFC machine
    IZipUtility zipUtil = new ZipUtility();
    zipUtil.extractZip(zipFile.getAbsolutePath(), tempDir.getAbsolutePath());

    //Now deep import the extracted contents of the zip
    String deepImportName = IDpDeepImportService.class.getName();
    IDpDeepImportService deepImportServ =
        (IDpDeepImportService) DfClient.getLocalClient().newService(
            deepImportName,
            getSessionManager());
    IDfId fldrId =
        deepImportServ.importFolder(
            docbase,
            tempDir.getAbsolutePath(),
            docbaseFolderSpec,
            false);

    //cleanup all temp files and directories
    if (isURL) {
      zipFile.delete();
    }
    cleanupDirectory(tempDir);

    return fldrId;
  }

  /**
   * Creates a temporary directory for usage by the SBO.
   *
   * @return
   *
   * @since 2.0
   */
  private File createTempDirectory() {
    String strTempDir = System.getProperty("java.io.tmpdir");
    DfLogger.debug(this, "Temp dir: " + strTempDir, null, null);
    String strRandomDirName = Integer.toString((int) (Math.random() * 1000));
    StringBuffer bufTempDeepExportDir =
        new StringBuffer(strTempDir.length() + strRandomDirName.length() + 2);
    bufTempDeepExportDir
        .append(strTempDir)
        .append(System.getProperty("file.separator"))
        .append(strRandomDirName);
    File tempDir = new File(bufTempDeepExportDir.toString());
    if (tempDir.mkdirs()) {
      DfLogger.debug(
          this,
          "Created temp dir: " + tempDir.getPath(),
          null,
          null);
      return tempDir;
    } else {
      DfLogger.warn(
          this,
          "Failed to Create temp dir for export of docbase files ",
          null,
          null);
      return null;
    }
  }

  /**
   * Deep deletes a filesystem folder and its contents. This method is used to cleanup the temporary folders created by
   * the zip service.
   *
   * @param dir
   *
   * @exception IOException
   * @since 2.0
   */
  private static void cleanupDirectory(File dir) throws IOException {
    if (dir.exists() == false) {
      //nothing to delete
      return;
    }

    if (dir.isFile()) {
      //delete file and return
      dir.delete();
      return;
    }

    File[] contents = dir.listFiles();
    for (int i = 0; i < contents.length; i++) {
      File child = contents[i];
      if (child.isFile()) {
        child.delete();
      } else {
        cleanupDirectory(child);
      }
    }
    dir.delete();
  }

}
