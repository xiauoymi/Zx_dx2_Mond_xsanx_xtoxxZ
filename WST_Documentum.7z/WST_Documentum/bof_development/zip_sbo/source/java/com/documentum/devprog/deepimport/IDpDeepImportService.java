/*
 * Created on Apr 26, 2004
 * 
 * Documentum Developer Program 2004
 *
 */
package com.documentum.devprog.deepimport;

import com.documentum.fc.client.IDfService;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

import java.io.IOException;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public interface IDpDeepImportService extends IDfService {
  /**
   * Deep imports a folder specified by the argument <code>localFolder</code>. The entire folder hierarchy of the
   * localFolder is recreated in the docbase. The docbase folder under which this hierarchy is recreated is specified
   * by the argument <code>docbaseFolderSpec</code>
   *
   * @param docbase
   * @param localFolder       The path of the local filesystem folder that needs to be imported
   * @param docbaseFolderSpec The docbase folder specification. This can be either a folder <br>
   *                          path or an object id.
   * @param createRoot        A boolean parameter that specifies whether the root folder specified by <br>
   *                          <code>localFolderPath</code> should be created in docbase too. If <code>true</code> <br>
   *                                      a folder by name of folder specified by <code>localFolderPath</code> is also
   *                          <br>              created. If <code>false</code> a folder is not created but its internal
   *                          hierarchy <br>              is imported into the docbase.
   *
   * @return The object id of the newly created docbase folder.
   *
   * @exception DfException
   * @exception IOException
   */
  public IDfId importFolder(String docbase, String localFolderPath, String docbaseFolderSpec, boolean createRoot) throws
      DfException, IOException;

}
