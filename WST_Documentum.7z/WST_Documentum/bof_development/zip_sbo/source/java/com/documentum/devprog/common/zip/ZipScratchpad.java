/*
 * Created on May 8, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;


/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class ZipScratchpad {


  private void createZip(String filename) throws Exception {
    File file = new File(filename);
    FileInputStream fin = new FileInputStream(file);

    FileOutputStream fout = new FileOutputStream("C:/devprog/zipTest.zip");
    ZipOutputStream zout = new ZipOutputStream(fout);
    byte inBuf[] = new byte[1024];
    int len = 0;
    zout.putNextEntry(new ZipEntry("c:/devProg/"));
    while ((len = fin.read(inBuf)) > 0) {
      System.out.println(new String(inBuf));
      zout.write(inBuf, 0, 1024);
    }
    zout.close();
    zout.finish();
    fout.close();
    fin.close();

  }


  public void explodeIntoDocbase(IDfSession sess, String folderSpec, String zipFilePath) throws DfException,
      IOException {
    IDfId fldrId = new DfId(folderSpec);
    String docbaseFldrPath = null;
    if (fldrId.isObjectId()) {
      IDfFolder fldrObj = (IDfFolder) sess.getObject(fldrId);
      docbaseFldrPath = fldrObj.getFolderPath(0);
    } else {
      docbaseFldrPath = folderSpec;
    }

    ZipFile zipFile = new ZipFile(zipFilePath);
    Enumeration zipEntries = zipFile.entries();
    while (zipEntries.hasMoreElements()) {
      ZipEntry zipEntry = (ZipEntry) zipEntries.nextElement();
    }


  }

  /**
   *
   */
  public ZipScratchpad() {
    try {


      createZip("c:/devProg/DevProg.log.1");

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String args[]) {
    try {

      File fl = new File("C:/devprog/deploy/");
      System.out.println("Name: " + fl.getName());
      System.out.println("Parent: " + fl.getParent());
      System.out.println("Path: " + fl.getPath());
      System.out.println("Canonical path: " + fl.getCanonicalPath());
      //new ZipScratchpad();

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
