/*
 * Created on Apr 23, 2004
 * 
 * Documentum Developer Program 2004
 *
 */
package com.documentum.devprog.deepimport;


import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.operations.DfImportOperation;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;

import java.io.File;
import java.io.IOException;


/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class DeepImportScratchpad {

  /*
  * PDL:
  * GetAllChildren
  * ForEachChild
  *    - If Child IsA Folder Recurse
  *    - If Child isA Document Import Document.
  *
  */

  /**
   * @param sess
   * @param localFldr
   * @param docbaseFldr
   *
   * @exception DfException
   * @exception IOException
   */
  private void importFolder(
      IDfSession sess,
      File localFldr,
      String docbaseFldrPath)
      throws DfException, IOException {

    File[] fldrContents = localFldr.listFiles();
    for (int i = 0; i < fldrContents.length; i++) {
      File child = fldrContents[i];
      if (child.isDirectory()) {
        System.out.println("Trying to link to: " + docbaseFldrPath);
        IDfFolder newFldr = (IDfFolder) sess.newObject("dm_folder");
        newFldr.setObjectName(child.getName());
        newFldr.link(docbaseFldrPath);
        newFldr.save();

        String childDocbaseFldrPath = docbaseFldrPath + "/" + child.getName();

        importFolder(sess, child, childDocbaseFldrPath);
      } else {
        importFile(sess, child, docbaseFldrPath);
      }
    }

  }

  /*
  public String getPossibleDocbaseFormat(IDfSession sess,String filePath) throws DfException
  {
     IDfClientX clientX = new DfClientX();

     IDfFormatRecognizer fmtRecog = clientX.getFormatRecognizer(sess,filePath,null);
     String sugFmt = fmtRecog.getDefaultSuggestedFileFormat();
     System.out.println(sugFmt);
     return sugFmt;

  }
  */


  private String getPossibleDocbaseFormat(IDfSession sess, String fileName) throws DfException {
    int index = fileName.lastIndexOf(".");
    String extension = fileName.substring(index + 1);

    StringBuffer bufQuery = new StringBuffer(32);
    bufQuery.append("select name,dos_extension from dm_format where dos_extension='").append(extension).append("'");
    bufQuery.append(" OR name='").append(extension).append("'");

    String strQuery = bufQuery.toString();

    IDfCollection coll = null;
    try {
      IDfQuery query = new DfQuery();
      query.setDQL(strQuery);
      coll = query.execute(sess, IDfQuery.DF_READ_QUERY);
      if (coll.next()) {
        String fmtName = coll.getString("name");
        return fmtName;
      }
    }
    finally {
      if (coll != null) {
        coll.close();
      }
    }

    return null;
  }


  private void importFile(
      IDfSession sess,
      File localFile,
      String docbaseFldrPath)
      throws DfException, IOException {
    IDfImportOperation importOper = new DfImportOperation();
    IDfImportNode node =
        (IDfImportNode) importOper.add(localFile.getAbsolutePath());
    importOper.setSession(sess);
    System.out.println("trying to import document into: " + docbaseFldrPath);
    IDfFolder destFldr = sess.getFolderByPath(docbaseFldrPath);
    if (destFldr == null) {
      throw new RuntimeException("Dest folder for doc import is null: " + docbaseFldrPath);
    }
    node.setDestinationFolderId(
        destFldr.getObjectId());

    String filename = localFile.getName();

    node.setNewObjectName(filename);
    node.setDocbaseObjectType("dm_document");
    String format = getPossibleDocbaseFormat(sess, filename);
    if (format != null) {
      node.setFormat(format);
    }

    node.setKeepLocalFile(true);

    if (importOper.execute()) {
      System.out.println("Imported document " + localFile.getAbsolutePath());
    } else {
      System.out.println("Import failed");
    }

  }

  public void deepImport(
      IDfSession sess,
      String localFldrPath,
      String docbaseFldrPath)
      throws DfException, IOException {

    File localFldr = new File(localFldrPath);
    if (localFldr.isDirectory()) {
      IDfFolder newFldr = (IDfFolder) sess.newObject("dm_folder");
      newFldr.setObjectName(localFldr.getName());
      newFldr.link(docbaseFldrPath);
      newFldr.save();
      docbaseFldrPath += "/" + localFldr.getName();
      System.out.println("Docbase foldr path: " + docbaseFldrPath);
      importFolder(sess, localFldr, docbaseFldrPath);
    } else {
      importFile(sess, localFldr, docbaseFldrPath);
    }

  }

  public static void main(String[] args) {
    LoginManager loginMgr = new LoginManager("dmadmin", "dmadmin", "devprogDocbase");
    IDfSession sess = null;
    try {
      sess = loginMgr.getSession();
      new DeepImportScratchpad().deepImport(sess, "c:\\devprog\\deploy\\autonamingService", "/dmadmin");
      //System.out.println(new DeepImportScratchpad().getPossibleDocbaseFormat(sess,"C:\\devprog\\deploy\\boConfig\\docs\\index.html"));

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }


  }
}
