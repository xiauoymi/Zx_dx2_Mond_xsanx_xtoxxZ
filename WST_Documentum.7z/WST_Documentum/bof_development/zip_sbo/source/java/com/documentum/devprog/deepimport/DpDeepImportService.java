/*
 * Created on Apr 26, 2004
 * 
 * Documentum Developer Program 2004
 *
 */
package com.documentum.devprog.deepimport;

import com.documentum.devprog.common.UtilityMethods;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.operations.DfImportOperation;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

/**
 * Implementation for the IDpDeepImportService SBO interface. Provides implementation for deep (recursive) deep import
 * of a local filesystem folder into the docbase.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class DpDeepImportService
    extends DfService
    implements IDpDeepImportService {

  /**
   * The version of the SBO.
   */
  private String m_strVersion = "1.0";

  /**
   * A string describing the vendor.
   */
  private String m_strVendor = "Documentum Developer Program 2004";

  /* (non-Javadoc)
  * @see com.documentum.fc.client.IDfService#getVersion()
  */
  public String getVersion() {
    return m_strVersion;
  }

  /* (non-Javadoc)
  * @see com.documentum.fc.client.IDfService#getVendorString()
  */
  public String getVendorString() {
    return m_strVendor;
  }

  /* (non-Javadoc)
  * @see com.documentum.fc.client.IDfService#isCompatible(java.lang.String)
  */
  public boolean isCompatible(String version) {
    return version.equals(getVersion());
  }

  /**
   * Deep imports a local folder into the docbase.
   *
   * @param docbase           The docbase name
   * @param localFolderPath   The path of the local folder that is being deep imported. <br>                   If the
   *                          path points to a file just the file is imported <br>                   into the target
   *                          docbase folder.
   * @param docbaseFolderSpec The specification for the docbase folder into which <br>                     the import
   *                          will take place. This can either be the <br>                     object id or a path like
   *                          '/myCabinet/targetFolder' <br>
   *
   * @return <code>IDfId</code> containing a valid root folder id if create succeeded <br>    or containing an invalid
   *         id if import failed.
   *
   * @see IDpDeepImportService#importFolder(String, String,
   *      String)
   */
  public IDfId importFolder(
      String docbase,
      String localFolderPath,
      String docbaseFolderSpec,
      boolean createRoot)
      throws DfException, IOException {

    IDfSession sess = null;
    try {
      sess = getSession(docbase);

      //resolve docbase folder path. Could be either an object id or a path.
      String docbaseFldrPath = null;
      IDfId objId = new DfId(docbaseFolderSpec);
      if (objId.isObjectId()) {
        IDfFolder fldr = (IDfFolder) sess.getObject(objId);
        docbaseFldrPath = fldr.getFolderPath(0);
      } else {
        docbaseFldrPath = docbaseFolderSpec;
      }

      if (docbaseFldrPath == null || (docbaseFldrPath.length() <= 1)) {
        throw new IllegalArgumentException(
            "The target docbase folder does not exist or the docbase path is invalid : " + docbaseFldrPath);
      }

      File localFldr = new File(localFolderPath);
      if (localFldr.exists() == false) {
        throw new IllegalArgumentException("The local file/folder does not exist or the path is invalid");
      }

      if (localFldr.isDirectory()) {
        if (createRoot) {

          IDfFolder newFldr = (IDfFolder) sess.newObject("dm_folder");
          newFldr.setObjectName(localFldr.getName());
          newFldr.link(docbaseFldrPath);
          newFldr.save();
          docbaseFldrPath += "/" + localFldr.getName();
          if (DfLogger.isDebugEnabled(this)) {
            DfLogger.debug(
                this,
                "Docbase folder path: " + docbaseFldrPath,
                null,
                null);
          }
        }

        importFolderRecursively(sess, localFldr, docbaseFldrPath);
        IDfId retId = UtilityMethods.getIdByPath(sess, docbaseFldrPath);
        return retId;
      } else {
        return importFile(sess, localFldr, docbaseFldrPath);
      }
    }
    finally {
      if (sess != null) {
        releaseSession(sess);
      }
    }
  }

  /*
  * PDL:
  * GetAllChildren
  * ForEachChild
  *    - If Child IsA Folder Recurse
  *    - If Child isA Document Import Document.
  *
  */

  /**
   * Imports a folder recursively. All the immediate children of a folder are obtained. If a child is a document, its
   * is imported into docbase and if a child is a folder this very same function is called (i.e. recursively).
   *
   * @param sess
   * @param localFldr   The local filesystem folder to import. The method assumes that the docbase folder <br>
   *                    corresponding to the local folder has already been created.
   * @param docbaseFldr The docbase folder that corresponds to the specified local folder. All contents of <br>
   *                    the local folder will be imported into the docbase folder
   *
   * @exception DfException
   * @exception IOException
   */
  private void importFolderRecursively(
      IDfSession sess,
      File localFldr,
      String docbaseFldrPath)
      throws DfException, IOException {
    File[] fldrContents = localFldr.listFiles();
    for (int i = 0; i < fldrContents.length; i++) {
      File child = fldrContents[i];
      if (child.isDirectory()) {
        StringBuffer bufChildPath = new StringBuffer(32);
        bufChildPath.append(docbaseFldrPath).append("/").append(child.getName());
        String strChildDocbasePath = bufChildPath.toString();
        if (DfLogger.isDebugEnabled(this)) {
          DfLogger.debug(this, "Creating docbase folder: " + strChildDocbasePath, null, null);
        }
        UtilityMethods.createFolder(sess, strChildDocbasePath, null, null, docbaseFldrPath);
        importFolderRecursively(sess, child, strChildDocbasePath);
      } else {
        importFile(sess, child, docbaseFldrPath);
      }
    }
  }

  /**
   * Imports a single file into the docbase into the docbase folder specified by <code>docbaseFldrPath</code>
   *
   * @param sess
   * @param localFile
   * @param docbaseFldrPath
   *
   * @return
   *
   * @exception DfException
   * @exception IOException
   */
  private IDfId importFile(
      IDfSession sess,
      File localFile,
      String docbaseFldrPath)
      throws DfException, IOException {
    IDfImportOperation importOper = new DfImportOperation();
    IDfImportNode node =
        (IDfImportNode) importOper.add(localFile.getAbsolutePath());
    importOper.setSession(sess);


    IDfFolder destFldr = sess.getFolderByPath(docbaseFldrPath);
    if (destFldr == null) {
      if (DfLogger.isWarnEnabled(this)) {
        DfLogger.warn(this, "Destination folder " + docbaseFldrPath + " for import of document " +
            localFile.getAbsolutePath() + " is null", null, null);
      }
    }
    if (DfLogger.isDebugEnabled(this)) {
      DfLogger.debug(
          this,
          "Destination folder for import of document "
              + localFile.getAbsolutePath()
              + " is "
              + destFldr,
          null,
          null);
    }
    node.setDestinationFolderId(destFldr.getObjectId());

    String filename = localFile.getName();
    node.setNewObjectName(filename);
    node.setDocbaseObjectType("dm_document");

    //attempt to resolve the format.
    String format = getPossibleDocbaseFormat(sess, filename);
    if (format != null) {
      node.setFormat(format);
    }

    node.setKeepLocalFile(true);

    if (importOper.execute()) {
      if (DfLogger.isDebugEnabled(this)) {
        DfLogger.debug(
            this,
            "Import of document succeeded " + localFile.getAbsolutePath(),
            null,
            null);
      }

      IDfId newDocId = node.getNewObjectId();
      return newDocId;
    } else {
      if (DfLogger.isWarnEnabled(this)) {
        ByteArrayOutputStream errOut = new ByteArrayOutputStream();
        UtilityMethods.printOperationErrors(errOut, importOper.getErrors());
        DfLogger.warn(
            this,
            "Operation to Import document "
                + localFile.getAbsolutePath()
                + " Failed: \n"
                + errOut.toString(),
            null,
            null);
      }

      return null;
    }
  }

  /**
   * Gets the name of a possible docbase format name i.e. the 'name' attribute of the 'dm_format' object for the
   * specified filename. The method tries to compare the files extension and the 'dos_extension' attribute of dm_format
   * to check for a format name.
   *
   * @param sess
   * @param fileName
   *
   * @return
   *
   * @exception DfException
   */
  private String getPossibleDocbaseFormat(IDfSession sess, String fileName)
      throws DfException {
    int index = fileName.lastIndexOf(".");
    if (index == -1) {
      if (DfLogger.isDebugEnabled(this)) {
        DfLogger.debug(
            this,
            "The given file does not have an extension.",
            null,
            null);
      }
      return null;
    }
    String extension = fileName.substring(index + 1);

    StringBuffer bufQuery = new StringBuffer(32);
    bufQuery
        .append("select name,dos_extension from dm_format where dos_extension='")
        .append(extension)
        .append("'");
    bufQuery.append(" OR name='").append(extension).append("'");
    String strQuery = bufQuery.toString();
    if (DfLogger.isDebugEnabled(this)) {
      DfLogger.debug(
          this,
          "About to execute query: " + strQuery,
          null,
          null);
    }

    IDfCollection coll = null;
    try {
      IDfQuery query = new DfQuery();
      query.setDQL(strQuery);
      coll = query.execute(sess, IDfQuery.DF_READ_QUERY);
      if (coll.next()) {
        String fmtName = coll.getString("name");
        return fmtName;
      }
    }
    finally {
      if (coll != null) {
        coll.close();
      }
    }
    return null;
  }
}
