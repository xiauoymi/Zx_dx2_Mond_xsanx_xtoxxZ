/*
 * Created on May 8, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import java.io.*;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class ZipUtility implements IZipUtility {
  /**
   * The output zip stream to which will be written to when creating a new zip file.
   */
  private ZipOutputStream m_zipOutStream = null;

  protected void setZipOutputStream(ZipOutputStream out) {
    m_zipOutStream = out;
  }

  protected ZipOutputStream getZipOutputStream() {
    return m_zipOutStream;
  }


  /**
   * Creates a zip of a directory or file. If a directory, then the last directory in the path is assumed to be the
   * directory to be zipped and is used as a virtual root. All internal files and directories are mapped relative to
   * this virtual root.
   *
   * @param objectToZip    Complete path of a file or directory to zip.
   * @param targetFilename The output zip file that is to be created. The complete path must be mentioned alongwith any
   *                       necessary extensions such as .zip
   *
   * @see IZipUtility#createZip(String, String)
   */
  public void createZip(String objectsToZip[], File targetFile) throws IOException {
    File flSource = new File(objectsToZip[0]);


    FileOutputStream fout = new FileOutputStream(targetFile);
    ZipOutputStream zout = new ZipOutputStream(fout);
    setZipOutputStream(zout);

    if (flSource.isDirectory()) {
      addDirectoryRecursively(flSource, getZipOutputStream(), "");
    } else {
      addFile(flSource, getZipOutputStream(), "");
    }

    zout.finish();
    zout.close();
    fout.close();
  }

  /**
   * Adds a directory and its contents (i.e. other directories and files) to the zip stream
   *
   * @param directory The directory to be added.
   * @param zipStream The zip stream to which the contents are added.
   * @param path      Path of the folder that contains the new one being created.
   *
   * @exception IOException
   */
  protected void addDirectoryRecursively(File directory, ZipOutputStream zipStream, String path) throws IOException {
    /*String dirPath = directory.getPath();
    ZipEntry dirEntry = new ZipEntry(dirPath);
    zipStream.putNextEntry(dirEntry);
    zipStream.closeEntry();
    */

    StringBuffer bufPath = new StringBuffer(32);
    bufPath.append(path).append(directory.getName()).append("/");
    String curRelativePath = bufPath.toString();
    zipStream.putNextEntry(new ZipEntry(curRelativePath));

    File allFiles[] = directory.listFiles();
    for (int ctrFiles = 0; ctrFiles < allFiles.length; ctrFiles++) {
      File curFile = allFiles[ctrFiles];
      if (curFile.isDirectory()) {
        addDirectoryRecursively(curFile, zipStream, curRelativePath);
      } else {
        addFile(curFile, zipStream, curRelativePath);
      }
    }

  }

  /**
   * Adds the contents of a file to the zip stream.
   *
   * @param file      The file whose contents are to be added.
   * @param zipStream The zip stream to which the contents are added.
   * @param path      The path of the folder that contains this file.
   *
   * @exception IOException
   */
  protected void addFile(File file, ZipOutputStream zipStream, String path) throws IOException {
    FileInputStream fin = new FileInputStream(file);

    int bufSize = 1024;
    byte ipBuf[] = new byte[bufSize];
    int lenRead = 0;

    String filename = path + file.getName();
    zipStream.putNextEntry(new ZipEntry(filename));

    while ((lenRead = fin.read(ipBuf)) > 0) {
      zipStream.write(ipBuf, 0, lenRead);
    }

    zipStream.closeEntry();
    fin.close();
  }

  /*
  * @param zipFile complete path to the zip file
  * @param targetDirectory Complete path of the target directory into which
  *<br>    the zip file is extracted.
  *
  * @see com.documentum.devprog.common.zip.IZipUtility#extractZip(java.lang.String, java.lang.String)
  */
  public void extractZip(String zipFile, String targetDirectory) throws IOException {
    ZipFile zipFl = new ZipFile(zipFile);
    Enumeration enumZipEntries = zipFl.entries();
    while (enumZipEntries.hasMoreElements()) {
      ZipEntry zipEntry = (ZipEntry) enumZipEntries.nextElement();
      String entryName = zipEntry.getName();
      System.out.println(entryName);

      StringBuffer bufPath = new StringBuffer(32);
      String pathSep = System.getProperty("file.separator");
      if (targetDirectory.endsWith(pathSep)) {
        targetDirectory = targetDirectory.substring(0, targetDirectory.length() - 1);
      }
      if (entryName.startsWith(pathSep)) {
        entryName = entryName.substring(1);
      }
      bufPath.append(targetDirectory);
      bufPath.append(pathSep);
      bufPath.append(entryName);
      String entryFullPath = bufPath.toString();
      File entryFile = new File(entryFullPath);
      //System.out.println("Full Entry Path: " + entryFile.getAbsolutePath());
      if (zipEntry.isDirectory()) {
        entryFile.mkdirs();
      } else {
        File entryFileParent = entryFile.getParentFile();
        entryFileParent.mkdirs();
        FileOutputStream fout = new FileOutputStream(entryFile);
        BufferedOutputStream bufOut = new BufferedOutputStream(fout);
        InputStream is = zipFl.getInputStream(zipEntry);
        byte[] buf = new byte[1024];
        int numRead = 0;
        while ((numRead = is.read(buf)) != -1) {
          bufOut.write(buf, 0, numRead);
        }
        bufOut.close();
      }
    }
  }


}
