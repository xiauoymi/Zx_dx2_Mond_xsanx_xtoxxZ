/*
 * Created on May 8, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import java.io.File;
import java.io.IOException;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public class TestZipUtility {

  public void createZip(String dirName, String opZipName) {
    try {
      IZipUtility zipUtil = new ZipUtility();
      String[] tArgs = {dirName};
      zipUtil.createZip(tArgs, new File(opZipName));

    }
    catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  public void testZipExtract(String zipFilename, String targetDir) {
    try {
      IZipUtility zipUtil = new ZipUtility();
      zipUtil.extractZip("C:\\devprog\\setCompileEnv.zip", "c:\\devprog\\test");

    }
    catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  /**
   * @param args args[0] - The directory with full path that needs to be zipped. args[1] - The output zip file with
   *             full path
   */
  public static void main(String[] args) {
    TestZipUtility testUtil = new TestZipUtility();
    //testUtil.createZip(args[0],args[1]);
    testUtil.testZipExtract(null, null);
  }
}
