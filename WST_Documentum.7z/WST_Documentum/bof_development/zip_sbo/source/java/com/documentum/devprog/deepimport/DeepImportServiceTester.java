/*
 * Created on Apr 26, 2004
 * 
 * Documentum Developer Program 2004
 *
 */
package com.documentum.devprog.deepimport;

import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.IDfId;

/**
 * Test script to call the deep import service.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class DeepImportServiceTester {

  public static void main(String[] args) {
    LoginManager loginMgr = null;
    try {
      if (args.length < 5) {
        System.err.println("Invalid number of arguments.");
        System.out
            .println("Correct order of arguments: username password docbaseName localFolderPath docbaseFolderIdOrPath");
        System.exit(1);
      }
      loginMgr = new LoginManager(args[0], args[1], args[2]);

      String localFolderPath = args[3];
      String docbaseFolderSpec = args[4];

      IDfSessionManager sessMgr = loginMgr.getSessionManager();
      IDfClient localClient = loginMgr.getLocalClient();

      String name = IDpDeepImportService.class.getName();
      IDpDeepImportService deepImp = (IDpDeepImportService) localClient.newService(name, sessMgr);
      IDfId fldrId = deepImp.importFolder(loginMgr.getDocbase(), localFolderPath, docbaseFolderSpec, true);
      System.out.println("Imported into folder: " + fldrId.getId());

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    finally {
      loginMgr.releaseSession();
    }
  }
}
