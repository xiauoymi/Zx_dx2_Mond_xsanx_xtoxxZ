/*
 * Created on May 8, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import java.io.File;
import java.io.IOException;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public interface IZipUtility {

  void createZip(String objectsToZip[], File targetFilename) throws IOException;

  void extractZip(String zipFile, String targetDirectory) throws IOException;

}
