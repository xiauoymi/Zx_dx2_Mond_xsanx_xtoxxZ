/*
 * Created on May 20, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import com.documentum.devprog.common.LoginManager;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import org.apache.log4j.Level;

import java.io.IOException;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class TestZipService {

  private LoginManager m_loginMgr = null;

  public TestZipService(String username, String password, String docbase) {
    m_loginMgr = new LoginManager(username, password, docbase);

  }

  /**
   * Calls the zip service to create a folder zip. The zip is stored in the parent folder of the folder to be zipped.
   * The parent is the first ancestor got by IDfFolder.getAncestorId(0)
   *
   * @param folderPath
   *
   * @exception DfException
   * @exception IOException
   */
  void createZip(String folderPath) throws DfException, IOException {
    IDfSession session = m_loginMgr.getSession();
    try {
      System.out.println("Folder to zip: " + folderPath);
      IDfFolder toZipFolder =
          (IDfFolder) session.getObjectByPath(folderPath);
      IDfId folderId = toZipFolder.getObjectId();
      System.out.println("Folder id: " + folderId.getId());
      String strParentId = toZipFolder.getAncestorId(1);
      for (int i = 0; i < toZipFolder.getAncestorIdCount(); i++) {
        String strId = toZipFolder.getAncestorId(i);
        IDfFolder folder = (IDfFolder) session.getObject(new DfId(strId));
        System.out.println(folder.getFolderPath(0));
      }
      System.out.println("Parent id: " + strParentId);
      IDfId parentId = new DfId(strParentId);

      IDfClient localClient = m_loginMgr.getLocalClient();
      IDfSessionManager sessMgr = m_loginMgr.getSessionManager();
      String strServiceName = IDpZipService.class.getName();
      IDpZipService zipService =
          (IDpZipService) localClient.newService(strServiceName, sessMgr);
      IDfId zipFileId =
          zipService.createZipInDocbase(
              folderId,
              parentId,
              toZipFolder.getObjectName());
      System.out.println(
          "Zip successfully created with id: " + zipFileId.getId());
    }
    finally {
      m_loginMgr.releaseSession();
    }
  }

  /**
   * Method to test the extraction of zip into a docbase
   *
   * @param zipPath
   *
   * @exception DfException
   * @exception IOException
   */
  void extractZipIntoDocbase(String zipPath, String docbasePath)
      throws DfException, IOException {
    try {
      String zipServName = IDpZipService.class.getName();
      IDfSessionManager sessMgr = m_loginMgr.getSessionManager();
      IDfClient client = m_loginMgr.getLocalClient();
      IDpZipService zipServ =
          (IDpZipService) client.newService(zipServName, sessMgr);
      IDfId fldrId =
          zipServ.extractZipInDocbase(
              m_loginMgr.getDocbase(),
              zipPath,
              docbasePath);
      System.out.println(
          "extracted zip into docbase folder: " + fldrId.getId());
    }
    finally {
      m_loginMgr.releaseSession();
    }

  }

  public static void main(String[] args) {
    DfLogger.getLogger("com.documentum.devprog").setLevel(Level.DEBUG);
    try {
      if (args.length < 4) {
        System.out.println("Invalid number of arguments");
        System.out.println("username password docbase folderToZip");
        System.exit(1);
      }

      TestZipService test = new TestZipService(args[0], args[1], args[2]);

      String flag = args[3];
      if (flag.equals("createZip")) {
        test.createZip(args[4]);
      } else if (flag.equals("extractZipInDocbase")) {
        test.extractZipIntoDocbase(args[4], args[5]);
      } else {
        System.err.println("Invalid action flag. Correct value is 'createZip' and 'extractZipIntoDocbase'");
        System.exit(1);
      }

      //test.createZip(args[3]);
      //test.extractZipIntoDocbase("c:\\devprog\\deploy\\deepImportService.zip","/dmadmin/deepImport");
      //test.extractZipIntoDocbase("http://selfaktuell.teamone.de/cgi-bin/selfdown/download.pl?url=http%3A%2F%2Fs46.deinprovider.de%2Farchiv%2Fprogramme%2Fselfhtml80.zip","/dmadmin/deepImport");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
