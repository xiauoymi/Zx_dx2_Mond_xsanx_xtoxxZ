/*
 * Created on May 19, 2003
 * Documentum Developer Program 2003
 * 
 * 
 */
package com.documentum.devprog.common.zip;

import com.documentum.fc.client.IDfService;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

import java.io.IOException;

/**
 * @author Aashish Patil(aashish.patil@documentum.com)
 */
public interface IDpZipService extends IDfService {
  /**
   * Prepare a zip of a local directory and import it into the docbase.
   *
   * @param localDirectory     The local directory to zip
   * @param containingFolderId The docbase folder that will contain the zip
   * @param zipFilename        The <code>object_name</code> and <code>title</code> of the imported zip file.
   *
   * @return The object id of the imported zip
   *
   * @exception DfException
   * @exception IOException
   * @since 1.0
   */
  public IDfId importAsZip(String localDirectory, IDfId containingFolderId, String zipFilename) throws DfException,
      IOException;

  /**
   * Export a docbase folder alongwith all its contents to the local filesystem and prepare its zip archive.
   *
   * @param folderId       The docbase folder to export
   * @param localDirectory The local directory where the zip will be stored.
   *
   * @return The path on the loal filesystem to which the docbase folder has been exported.
   *
   * @exception DfException
   * @exception IOException
   * @since 1.0
   */
  public String exportAsZip(IDfId folderId, String localDirectory) throws DfException, IOException;

  /**
   * Prepares a zip of the contents of a docbase folder and stores the zip file in the docbase.
   *
   * @param folderId           The folder whose contents need to be zipped.
   * @param containingFolderId The folder that will contain the zipped file.
   * @param zipFilename        The object_name of the new zip file
   *
   * @return The object id of the created zip file.
   *
   * @exception DfException
   * @exception IOException
   * @since 1.0
   */
  public IDfId createZipInDocbase(IDfId folderId, IDfId containingFolderId, String zipFilename) throws DfException,
      IOException;


  /**
   * Extracts a zip into the docbase.
   *
   * @param docbase           docbase name into which the file is getting extracted
   * @param zipFileLocation   The zip file could be either a complete path <br>                   on the local
   *                          filesystem (e.g. c:\\devprog\\backup.zip <br>                   or it could be a URL
   *                          (e.g. http://www.someserver.com/archives/backup12_03.zip)
   * @param docbaseFolderSpec Either object id or the complete docbase folder path <br>                     of docbase
   *                          folder into which the zip is to be extracted <br>
   *
   * @return object id of the folder that contains the extracted contents.
   *
   * @exception DfException
   * @exception IOException
   * @since 2.0
   */
  public IDfId extractZipInDocbase(String docbase, String zipFileLocation, String docbaseFolderSpec) throws DfException,
      IOException;


}
