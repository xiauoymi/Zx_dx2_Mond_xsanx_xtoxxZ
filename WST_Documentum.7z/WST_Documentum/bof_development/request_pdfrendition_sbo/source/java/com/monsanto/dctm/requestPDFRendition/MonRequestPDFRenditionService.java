/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.requestPDFRendition;

import com.documentum.devprog.common.boconfig.BOConfigException;
import com.documentum.devprog.common.boconfig.BOConfigFactory;
import com.documentum.devprog.common.boconfig.IBOConfig;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;

/**
 * Filename:    $RCSfile: MonRequestPDFRenditionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-01-03 21:25:28 $
 *
 * @author rrkaur
 * @version $Revision: 1.1 $
 */
public class MonRequestPDFRenditionService extends DfService implements IMonRequestPDFRenditionService {

  public String queueOwner;
  public static String event = "rendition";
  public static int priority = 0;
  public static boolean sendMail = false;
  public static IDfTime dueDate = null ;
  public static String message = "rendition_req_ps_pdf";

  public String getVersion() {
     return "1.0";
  }

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2006";
  }

  public boolean isCompatible(String string) {
    return string.equals(getVersion());
  }

  public void requestPDFRendition(IDfSysObject sourceObject) throws DfException {

    //if(!hasPDFRendition(sourceObject)){
      if(isPDFRenditionAttributeEnabled(sourceObject)){
        System.out.println("applyPDFRenditionCapability(sourceObject)" + applyPDFRenditionCapability(sourceObject));

        }
    //}


  }

    private IDfId applyPDFRenditionCapability(IDfSysObject sysObj) throws DfException {
   String objFormat = sysObj.getFormat().getDOSExtension();

    if (checkMediaFormat(objFormat,sysObj)) {
      this.queueOwner = "dm_mediaserver";
    }else {
      this.queueOwner = "dm_autorender_win31";
    }

    return sysObj.queue(queueOwner, "rendition", 0, false, null,
         "rendition_req_ps_pdf");
  }

  private boolean checkMediaFormat(String objFormat,IDfSysObject sysObj) throws DfException {
    boolean mediaFormat = false;
    String queryString = "select dos_extension from dm_format where richmedia_enabled = 1";
    IDfCollection queryResult = null;
    try {
      queryResult = execQuery(queryString,sysObj);
      if (queryResult != null) {
        while (queryResult.next()) {
           if (objFormat.equals(queryResult.getString("dos_extension"))){
            mediaFormat = true;
            return mediaFormat;
          }
        }
        queryResult.close();    //Note: must close the collection because it is a limited resource
      }
    } catch (DfException e) {
      throw e;
    }

    return mediaFormat;
  }

  private IDfCollection execQuery(String queryString,IDfSysObject sysObj) throws DfException {
    IDfCollection col;
   try {
      IDfQuery q = new DfQuery();   //**Create the query object then set the query string.
     q.setDQL(queryString);
      col = q.execute(sysObj.getSession(), DfQuery.DF_READ_QUERY);   //**Synchronously execute the query.
    } catch (DfException dfe) {
      throw new DfException("Exception while querying docBase: " + dfe.getMessage(), dfe);
    }
    return col;
  }

  private boolean isPDFRenditionAttributeEnabled(IDfSysObject sourceObject) throws DfException {
    boolean isPDFEnabled = false;
    if(sourceObject != null){
      String valuePDFRendition =  getPDFRenditionValueFromConfig(sourceObject.getTypeName());
      if(valuePDFRendition == null || valuePDFRendition.length() == 0 || valuePDFRendition.equalsIgnoreCase("false")){

      }else
        isPDFEnabled = true;
    }
    else {
            throw new IllegalArgumentException("Source object cannot be null");
    }
    return isPDFEnabled;
  }

  private String getPDFRenditionValueFromConfig(String typeName) {
    IBOConfig boConfig;
    try {
      boConfig = BOConfigFactory.newBOConfig(this);
      }
    catch (BOConfigException e) {
      throw new IllegalArgumentException("Unable to find configuration file.");
    }

    return boConfig.getValue("/" + typeName + "/requestPDFRendition");
  }

}