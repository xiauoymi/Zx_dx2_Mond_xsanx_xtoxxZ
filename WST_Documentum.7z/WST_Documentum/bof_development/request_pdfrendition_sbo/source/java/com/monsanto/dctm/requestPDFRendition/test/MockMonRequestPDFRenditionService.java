/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.requestPDFRendition.test;

import com.monsanto.dctm.requestPDFRendition.MonRequestPDFRenditionService;

/**
 * Filename:    $RCSfile: MockMonRequestPDFRenditionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-01-03 21:28:30 $
 *
 * @author rrkaur
 * @version $Revision: 1.1 $
 */
public class MockMonRequestPDFRenditionService extends MonRequestPDFRenditionService {

 /* public String queueOwner;
  public String event;
  public int priority;
  public boolean sendMail;
  public IDfTime dueDate;
  public String message;
  private MockSession sess = null;

    public IDfId queue(String queueOwner, String event, int priority, boolean sendMail, IDfTime dueDate, String message) throws
                                                                                                                         DfException {

        this.queueOwner = queueOwner;
        this.event = event;
        this.priority = priority;
        this.sendMail = sendMail;
        this.dueDate = dueDate;
        this.message = message;
        return new DfId(null);
    }*/
  /*private List generateMockDosExtn() {
    List mockDosExtn = new ArrayList();
    Map mockRow = new HashMap();
    List usage = new ArrayList();
    usage = new ArrayList();
    usage.add("doc");
    mockRow.put("dos_extension", usage);
    mockDosExtn.add(mockRow);
    return mockDosExtn;
  }

  protected MockDfQuery createIDfQuery(String query) {
    MockDfQuery dfQuery = new MockDfQuery(true, generateMockDosExtn());
    dfQuery.setDQL(query);
    return dfQuery;

  }

  private IDfCollection execQuery(String queryString) throws Exception {
    IDfCollection col = null;
    try {
      MockDfQuery query = createIDfQuery(queryString);   //**Create the query object then set the query string.
      query.setDQL(queryString);
      col = query.execute(sess, DfQuery.DF_READ_QUERY);   //**Synchronously execute the query.
    } catch (DfException dfe) {
      throw new Exception("Exception while querying docBase: " + dfe.getMessage(), dfe);
    }
    return col;
  }
  public void setSession(MockSession sess){
    this.sess = sess;
  }

  protected boolean checkMediaFormat(String objFormat)  {
    boolean mediaFormat = false;
    String queryString = "select dos_extension from dm_format where richmedia_enabled = 1";
    try {
      IDfCollection queryResult = execQuery(queryString);
      if (queryResult != null) {
        while (queryResult.next()) {
          if (objFormat.equals(queryResult.getString("dos_extension"))){
            mediaFormat = true;
          }
        }
        queryResult.close();    //Note: must close the collection because it is a limited resource
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    return mediaFormat;
  }*/
}