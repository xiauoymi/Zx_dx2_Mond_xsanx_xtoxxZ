/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.requestPDFRendition.test;

import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.requestPDFRendition.MonRequestPDFRenditionService;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonRequestPDFRendition_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-01-03 21:31:57 $
 *
 * @author rrkaur
 * @version $Revision: 1.1 $
 */


public class MonRequestPDFRendition_UT extends TestCase {
  public void testCreate() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    assertNotNull(monRequestPDFRenditionService);
  }
  public void testRequestPDFRenditionWhenNullValueIsSpecified() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    try {
      monRequestPDFRenditionService.requestPDFRendition(null);
    } catch (IllegalArgumentException e) {
      //expected Path
      return;
    }
    fail("Should have thrown an illegal argument exception");

  }

  public void testIncorrectNameOfApplicationIsSpecified() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    MockSysObject sourceObject = new MockSysObject();
    sourceObject.setSession(new MockSession(new MockDfSessionManager()));
    sourceObject.setString("r_object_type", "no_pdf_rendition_specified_type");
    monRequestPDFRenditionService.requestPDFRendition(sourceObject);

    sourceObject.getFormat().getDOSExtension();

    assertNull(monRequestPDFRenditionService.queueOwner);

  }

  public void testNameOfApplicationIsSpecifiedWithPDFRenditionTagSetToNull() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    MockSysObject sourceObject = new MockSysObject();
    sourceObject.setSession(new MockSession(new MockDfSessionManager()));
    sourceObject.setString("r_object_type","wcm_muscatine");
    monRequestPDFRenditionService.requestPDFRendition(sourceObject);

    assertNull(monRequestPDFRenditionService.queueOwner);

  }

  public void testNameOfApplicationIsSpecifiedWithPDFRenditionTagSetToFalse() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    MockSysObject sourceObject = new MockSysObject();
    sourceObject.setSession(new MockSession(new MockDfSessionManager()));
    sourceObject.setString("r_object_type","ag_tech_best_practice");
    monRequestPDFRenditionService.requestPDFRendition(sourceObject);

    assertNull(monRequestPDFRenditionService.queueOwner);

  }

  public void testNameOfApplicationIsSpecifiedWIthPDFRenditonTagSetToTrueAndContentTypeIsDoc() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();

    MockSysObject sourceObject = new MockSysObject();
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(sessionManager);
    sourceObject.setSession(mockSession);
    
    sourceObject.setString("r_object_type","salsa_pos_doc");
    sourceObject.setString("r_object_id","0998761754");
    sourceObject.setString("a_content_type","msw8");
    sourceObject.setString("dos_extension","doc");
    sourceObject.setString("msw8","doc");
    sourceObject.setString("select dos_extension from dm_format where richmedia_enabled = 1","doc");

    mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,select dos_extension from dm_format where richmedia_enabled = 1");
    mockSession.addObject(sourceObject,"doc");

    monRequestPDFRenditionService.requestPDFRendition(sourceObject);

    assertEquals("dm_autorender_win31", monRequestPDFRenditionService.queueOwner);

  }

  public void testNameOfApplicationIsSpecifiedWIthPDFRenditonTagSetToTrueAndContentTypeIsMedia() throws Exception {
    MonRequestPDFRenditionService monRequestPDFRenditionService = new MonRequestPDFRenditionService();
    
    MockSysObject sourceObject = new MockSysObject();
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(sessionManager);
    sourceObject.setSession(mockSession);
    sourceObject.setString("r_object_type","salsa_pos_doc");

    sourceObject.setString("dos_extension","jpg");

    mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,select dos_extension from dm_format where richmedia_enabled = 1");

    monRequestPDFRenditionService.requestPDFRendition(sourceObject);

  }


}