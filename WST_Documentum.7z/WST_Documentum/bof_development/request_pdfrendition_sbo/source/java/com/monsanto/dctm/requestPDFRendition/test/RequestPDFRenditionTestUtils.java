/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.requestPDFRendition.test;

import com.monsanto.dctm.requestPDFRendition.IMonRequestPDFRenditionService;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.common.DfException;

/**
 * Filename:    $RCSfile: RequestPDFRenditionTestUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-01-03 21:33:00 $
 *
 * @author rrkaur
 * @version $Revision: 1.1 $
 */
public class RequestPDFRenditionTestUtils {

  /* public static IMonAttachLifecycleService getAttachLifecycleService(IDfSessionManager sessMgr) throws DfException {
      return (IMonAttachLifecycleService) DfClient.getLocalClient()
              .newService(IMonAttachLifecycleService.class.getName(), sessMgr);
  }*/
  public static IMonRequestPDFRenditionService getRequestPDFRenditionService(IDfSessionManager sessionManager) throws DfException{
    return (IMonRequestPDFRenditionService) DfClient.getLocalClient()
        .newService(IMonRequestPDFRenditionService.class.getName(), sessionManager);
  }
}