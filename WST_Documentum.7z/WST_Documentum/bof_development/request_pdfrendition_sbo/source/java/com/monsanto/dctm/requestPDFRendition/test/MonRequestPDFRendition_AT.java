/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.requestPDFRendition.test;

import com.monsanto.dctm.requestPDFRendition.IMonRequestPDFRenditionService;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonRequestPDFRendition_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-01-03 21:30:27 $
 *
 * @author rrkaur
 * @version $Revision: 1.1 $
 */
public class MonRequestPDFRendition_AT extends TestCase {

  private static final String DOCBASE = "stltst03";
    private static final String USERID = "devl30";
    private static final String PASSWORD = "devl30";

  public void testRequestPDFRenditionWithNulls() throws Exception {
         IMonRequestPDFRenditionService service = RequestPDFRenditionTestUtils
        .getRequestPDFRenditionService(DFCSessionUtils.createSessionManager(DOCBASE, USERID, PASSWORD));

    try {
      service.requestPDFRendition(null);
    } catch (IllegalArgumentException e) {

      return;
    }
    fail("Should have thrown an illegal argument exception");

    //DfClient.getLocalClient().newService(IMonRequestPDFRenditionService.class.getName(), DFCSessionUtils.createSessionManager(DOCBASE,USERID,PASSWORD));
  }

}