/*
 * BreedingDoc.java
 *
 * Created on January 10, 2006, 3:53 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.breeding;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 * @author tsvedan
 */
public class BreedingDoc extends DfSysObject
    implements IBreedingDoc, IDfDynamicInheritance {

  /**
   * Creates a new instance of BreedingDoc
   */
  public BreedingDoc() {
  }

  public IDfId checkinEx(
      boolean arg0,
      String arg1,
      String arg2,
      String arg3,
      String arg4,
      String arg5)
      throws DfException {
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "@@@@@@@@@ CHECKINEX @@@@@@@@@" , null, null);
    if (this.getPreviousApprovedVersion())
      arg1 = arg1.replaceAll("CURRENT", moveSymbolicVersionLabel());
    else
      arg1 = "," + moveSymbolicVersionLabel() + "," + arg1;
    IDfId newId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
    IDfSession sess = null;
    IDfSysObject newObj = null;

    sess = getSession();
    newObj = (IDfSysObject) sess.getObject(newId);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "***Your name is :: " + sess.getLoginUserName(), null, null);
    if (isApprovedVersion(this) || (!isAlreadyInWorkflow(newObj) && isDraftVersion(newObj))) {
      setProcessId(m_Workflow2Run);
      setPerformers(newObj);
      startWorkflow(newId);
    }
    return newId;
  } //checkinEx

  public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
      throws DfException {
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"@@@@@@@@@ doSave @@@@@@@@@", null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"***Your name is :: " + getSession().getLoginUserName(), null, null);
//    DfLogger.info(this, "saveLock = " + saveLock + "| VersionLabel = " + versionLabel, null, null);

    super.doSave(saveLock, versionLabel, extendedArgs);

    if (!isAlreadyInWorkflow(this) && isDraftVersion(this)) {
      setProcessId(m_Workflow2Run);
      setPerformers(this);
      startWorkflow(this.getId("r_object_id"));
    }
  } //doSave

  public void save() throws DfException {
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"@@@@@@@@@ SAVE @@@@@@@@@", null, null);
    if (!isApprovedVersion(this) && this.getPreviousApprovedVersion())
      this.unmark("CURRENT");
    super.save();
    /*if (approved.equals(getCurrentStateName()))
      queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");*/
  } //save

  protected void setProcessId(String processName) throws DfException {

    IDfSession session = null;
    try {
      session = getSession();
      IDfCollection Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        if (Next.getString("object_name").equals(processName)) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Workflow name: " + Next.getString("object_name"), null, null);
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Set the process id: " + processID.toString(), null, null);
          break;
        }
      }
      Workflows.close();
    } catch (DfException dfe) {
      throw dfe;
    }
  } //setProcessId

  protected void startWorkflow(IDfId documentId) throws DfException {
    IDfSession session = null;
    try {
      session = getSession();

      IDfId processId = getProcessId();
      if (processId == null) {
        DfLogger.warn(this, "No valid processes to start", null, null);
        return;
      }
      IDfWorkflowBuilder wfBuilder =
          session.newWorkflowBuilder(processId);
      wfBuilder.initWorkflow();
      wfBuilder.runWorkflow();
      IDfWorkflow workflow = wfBuilder.getWorkflow();

      setAliases(workflow); //Set the missing aliases here!

      String activityName = null;
      String packageName = null;
      String portName = null;

      if (getActivityId() == null) //choose first start activity by default
      {
        IDfList activityIds = wfBuilder.getStartActivityIds();
        setActivityId((IDfId) activityIds.get(0));
      }

      IDfActivity activity =
          (IDfActivity) session.getObject(getActivityId());
      activityName = activity.getString("object_name");

      if (getPortName() == null) //choose first input port by default
      {
        for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
          if (activity.getPortType(cntrPort).equals("INPUT")) {
            portName = activity.getPortName(cntrPort);
            packageName = activity.getPackageName(cntrPort);
            break;
          }
        }
      } else {
        portName = getPortName();
        for (int i = 0; i < activity.getPortCount(); i++) {
          if (activity.getPortName(i).equals(portName)) {
            packageName = activity.getPackageName(i);
            break;
          }
        }
      }

      String strObjectType = getTypeName();
      DfList list = new DfList();
      list.append(documentId);
      workflow.addPackage(
          activityName,
          portName,
          packageName,
          strObjectType,
          "",
          false,
          list);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Started workflow with id: " + workflow.getObjectId().getId(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Workflow name: " + workflow.getObjectName(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"The workflow supervisor is: " + workflow.getSupervisorName(), null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Added package with doc id: " + documentId, null, null);
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
      throw dfe;
    }
  } //startWorkflow

  protected void setAliases(IDfWorkflow workflow) throws DfException {

    IDfSession session = null;
    try {
      session = getSession();
      // Get the AliasSet ID for this workflow
      IDfId AliasSetId = workflow.getAliasSetId();
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Alias set ID: " + AliasSetId.toString(), null, null);

      //get the alias set
      IDfAliasSet AliasSet = (IDfAliasSet) session.getObject(AliasSetId);
      //Set the aliases by name - Reviewer, Approver
      int nAliases = AliasSet.getAliasCount();

      int indexofRev1 = AliasSet.findAliasIndex("Reviewers1");
      if (indexofRev1 > -1)
        AliasSet.setAliasValue(indexofRev1, reviewers1);
      int indexofRev2 = AliasSet.findAliasIndex("Reviewers2");
      if (indexofRev2 > -1)
        AliasSet.setAliasValue(indexofRev2, reviewers2);
      int indexofApp = AliasSet.findAliasIndex("Approvers");
      if (indexofApp > -1)
        AliasSet.setAliasValue(indexofApp, approvers);
      int indexofAuth = AliasSet.findAliasIndex("Author");
      if (indexofAuth > -1)
        AliasSet.setAliasValue(indexofAuth, session.getLoginUserName());

      // fix for issue#0159022
      int indexofNotify = AliasSet.findAliasIndex("NotifyGrp");
      if (indexofNotify > -1)
        AliasSet.setAliasValue(indexofNotify, notifyGrp);
      // fix for issue#0159022

      // Save the AliasSet!
      AliasSet.save();

      for (int i = 0; i < nAliases; i++) {
        DfLogger.info(this, "Name:"+this.getObjectName() + " "+"AliasName: "
            + AliasSet.getAliasName(i)
            + ", "
            + "AliasValue = "
            + AliasSet.getAliasValue(i), null, null);
      }

    } catch (DfException dfe) {
      //do not log a DfException since it is thrown by DFC and hence already
      //logged by it. If it is logged here, it might appear twice in the
      //log file.
      throw dfe;
    }
  } //setAliases

  protected void setPerformers(IDfSysObject sysObj) throws DfException {

    //IDfSession session = getSession();

    String title = sysObj.getString("object_name");
    String business = sysObj.getString("breed_business");
    String site = sysObj.getString("site_or_plant");
    String dept = sysObj.getString("breed_department");
    String proc = sysObj.getString("breed_procedure");
    String crop = sysObj.getString("breed_crop");


    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Title: " + title, null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Business: " + business, null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Site: " + site, null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Function/Department: " + dept, null, null);
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Procedure: " + proc, null, null);


    String select = "select coded_value from dm_dbo.code_lookup";// where decoded_value='";
    String qualCrop = " WHERE code_type='breed_crop' and decoded_value='";
    String defaultWhere = " where decoded_value='";
    String end = "'";
    String cropCode = execQuery(select + qualCrop +  crop + end).trim();
    String query = null;

    // fix for issue#0159022
    if (cropCode !=null)
      notifyGrp=prefix + cropCode + notify_suffix;
    else
      notifyGrp="breeding_notify";
    // fix for issue#0159022
    // fix for 0180669
    if (business.trim().equals("Midas") || business.trim().equals("ISO"))
    {
      query = select + defaultWhere + business + "' and code_type='breed_business'";
      String busCode = execQuery(query);
      reviewers1 = prefix + cropCode + "_" + busCode + "_" + "all_sites" + reviewer_suffix;
      reviewers2 = prefix + cropCode + "_" + busCode + reviewer_suffix;
      approvers = prefix + cropCode + "_" + busCode + approver_suffix;
    }
    else if (!business.trim().equals("Breeding")) {
      // fix for 0180669
      query = select + defaultWhere + business + "' and code_type='breed_business'";
      String busCode = execQuery(query);
      reviewers1 = prefix + cropCode + "_" + busCode + reviewer_suffix;
      reviewers2 = prefix + cropCode + "_" + busCode + reviewer_suffix;
      approvers = prefix + cropCode + "_" + busCode + approver_suffix;

    }
    else {
      // fix for 0180669
      if (!site.trim().equals("Not Applicable")) {
        // fix for 0180669
        query = select + defaultWhere + site + "' and code_type='breed_site'";
        String siteCode = execQuery(query);
        reviewers1 = prefix + cropCode + "_" +siteCode + reviewer_suffix;
        reviewers2 = prefix + cropCode + "_" + "all_sites" + reviewer_suffix;
        approvers = prefix + cropCode+ "_" + siteCode + approver_suffix;

      }
      //fix for 0170149 and  0180669
      else if ((!dept.trim().equals("Not Applicable")) && (!proc.trim().equals("Not Applicable"))) {
      //fix for 0170149 and 0180669
        query = select + defaultWhere + dept + "' and code_type='breed_dept'";
        String deptCode = execQuery(query);
        query = select + defaultWhere + proc + "' and code_type='breed_procedure'";
        String procCode = execQuery(query);
        // Canola enhancement request
        // Different approvers needs to be selected if both Department and Procedure is selected
        if(crop.equalsIgnoreCase("Canola")){
          reviewers1 = prefix + cropCode + "_" + "iso" + reviewer_suffix;
          reviewers2 = prefix + cropCode + "_" + procCode + "_" + deptCode + reviewer_suffix;
          approvers = prefix + cropCode + "_" + procCode + "_" + deptCode + approver_suffix;

        }else{
          reviewers1 = prefix + cropCode + "_" + "iso" + reviewer_suffix;
        reviewers2 = prefix + cropCode + "_" + procCode + "_" + deptCode + reviewer_suffix;
        approvers = prefix + cropCode + "_" + deptCode + approver_suffix;
        }

      }
      // fix for 0180669
      else if (!proc.trim().equals("Not Applicable")) {
        // fix for 0180669
        query = select + defaultWhere + proc + "' and code_type='breed_procedure'";
        String procCode = execQuery(query);
        reviewers1 = prefix + cropCode + "_" +"council" + reviewer_suffix;
        reviewers2 = prefix + cropCode + "_" +"council" + reviewer_suffix;
        approvers = prefix + cropCode + "_" +"council_" + procCode + approver_suffix;
      }else if ((!dept.trim().equals("Not Applicable")) && (proc.trim().equals("Not Applicable"))) {
        // Canola enhancement request where Department will have a value
        // and procedure can be NA
        query = select + defaultWhere + dept + "' and code_type='breed_dept'";
        String deptCode = execQuery(query);
        reviewers1 = prefix + cropCode + "_" +deptCode + "_deptonly" + reviewer_suffix;
        reviewers2 = prefix + cropCode + "_" +deptCode+ "_deptonly" + reviewer_suffix;
        approvers = prefix + cropCode + "_" +deptCode + "_deptonly" + approver_suffix;
      } else {
        reviewers1 = prefix + cropCode + "_general" + reviewer_suffix;
        reviewers2 = prefix + cropCode + "_general" + reviewer_suffix;
        approvers = prefix + cropCode + "_general" + approver_suffix;
        return;
      }
    }
    validateGroups(cropCode);
  } //setPerformers

  protected void validateGroups(String cropCode) throws DfException {
    String error = null;
    IDfGroup rev = null;
    IDfGroup rev2 = null;
    IDfGroup app = null;
    IDfSession sess = getSession();
    try {
      if (reviewers1.equals(reviewers2)) {
        rev = sess.getGroup(reviewers1);
        app = sess.getGroup(approvers);
        if (rev == null || rev.getUsersNamesCount() < 1) {
          String msg = "Group specified by " + reviewers1 + " does not exist or is empty!";
          throw new DfException(msg);
        }
        if (app == null || app.getUsersNamesCount() < 1) {
          String msg = "Group specified by " + approvers + " does not exist or is empty!";
          throw new DfException(msg);
        }
      } else {
        rev = sess.getGroup(reviewers1);
        rev2 = sess.getGroup(reviewers2);
        app = sess.getGroup(approvers);
        if (rev == null || rev.getUsersNamesCount() < 1) {
          String msg = "Group specified by " + reviewers1 + " does not exist or is empty!";
          throw new DfException(msg);

        }
        if (rev2 == null || rev2.getUsersNamesCount() < 1) {
          String msg = "Group specified by " + reviewers2 + " does not exist or is empty!";
          throw new DfException(msg);
        }
        if (app == null || app.getUsersNamesCount() < 1) {
          String msg = "Group specified by " + approvers + " does not exist or is empty!";
          throw new DfException(msg);
        }
      }
    } catch (DfException e) {
      reviewers1 = prefix + cropCode + "_general" + reviewer_suffix;
      reviewers2 = prefix + cropCode + "_general" + reviewer_suffix;
      approvers = prefix + cropCode + "_general" + approver_suffix;
      error = e.getMessage();
      DfLogger.warn(this, error, null, null);
    } finally {
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Reviewers 1 group = " + reviewers1, null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Reviewers 2 group = " + reviewers2, null, null);
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+ "Approvers group = " + approvers, null, null);
    }
  } //validatePerformers

  protected boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException {

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    IDfCollection wcoll = null;
    boolean inWorkflow = false;

    wcoll = sysObj.getWorkflows("", "");
    if (wcoll != null && wcoll.next()) {
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"),
          null, null);
      inWorkflow = true;
    } else if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null) {
      while (coll.next()) {
        versionId = coll.getId("r_object_id");
        version = (IDfSysObject) getSession().getObject(versionId);
        if (version.getCurrentStateName().equals(approved))
          continue;
        /* issue #0241813
        Closing previuos collection object before it gets assigned to new object */
        wcoll.close();
        DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Breeding Doc Control Collection Object Closed." , null, null);
        /* issue #0241813 */
        wcoll = version.getWorkflows("", "");
        if (wcoll != null && wcoll.next()) {
          DfLogger.info(this, "Name:"+this.getObjectName() + " "+
              OBJECT_ALREADY_PARTICIPATES_IN_WORKFLOW + wcoll.getString("r_workflow_id"), null, null);
          inWorkflow = true;
          break;
        }
      }
    }
    if (wcoll != null)
      wcoll.close();
    if (coll != null)
      coll.close();

    return inWorkflow;
  } //isAlreadyInWorkflow

  protected boolean getPreviousApprovedVersion() throws DfException {

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    boolean approvedVersionFound = false;
    DfLogger.info(this,"Name:"+this.getObjectName() + " "+ "!!!! In getPreviousApprovedVersion....", null, null);
    if (this.getVStamp() == 0) return false;
    try {
      coll = this.getVersions("r_version_label, r_modify_date, r_object_id");
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
    }
    if (coll != null) {
      while (coll.next()) {
        versionId = coll.getId("r_object_id");
        version = (IDfSysObject) getSession().getObject(versionId);
        if (isApprovedVersion(version)) {
          approvedVersionFound = true;
          break;
        }
      }
      coll.close();
    }
    DfLogger.info(this, "Name:"+this.getObjectName() + " "+">>>> CHECKED FOR APPROVED VERSIONS .." + approvedVersionFound, null, null);
    return approvedVersionFound;
  } //getPreviousApprovedVersion


  protected String moveSymbolicVersionLabel() throws DfException {
    String label = null;
    for (int i = 1; i < this.getVersionLabelCount(); i++) {
      label = this.getVersionLabel(i);
      if (label.equals("Review")) {
        return label;
      }
    }
    return draft;
  } //moveSymbolicVersionLabel


  protected boolean isApprovedVersion(IDfSysObject sysObj) throws DfException {
    boolean isApproved = false;
    if (sysObj.getCurrentStateName() == null)
      return true;
    if (sysObj.getCurrentStateName().equals(approved)) {
      isApproved = true;
    }
    return isApproved;
  } //isApprovedVersion

  protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {

    String label = null;
    boolean isDraft = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
      //System.out.println("is Draft label " + label);
      if (label.equals(draft))
        isDraft = true;
    }
    return isDraft;
  } //isDraftVersion

  protected String execQuery(String queryString)
      throws DfException {
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery(); //Create query object
    String result = null;
    q.setDQL(queryString); //Give it the query
    coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
    if (coll.next()) {
      result = coll.getString("coded_value");
      DfLogger.info(this, "Name:"+this.getObjectName() + " "+"Query executed... Result is " + result, null, null);
    }
    if (coll != null)
      coll.close();
    return result;
  } //execQuery

  public void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }

  public void setPackageName(String packageName) {
    m_strPackageName = packageName;
  }

  public void setPortName(String strPort) {
    m_strPortName = strPort;
  }

  public IDfId getActivityId() {
    return m_activityId;
  }

  public String getPackageName() {
    return m_strPackageName;
  }

  public String getPortName() {
    return m_strPortName;
  }

  public IDfId getProcessId() {
    return m_processId;
  }

  public boolean supportsFeature(String arg0) {
    return false;
  } //supportsFeature

  public boolean isCompatible(String arg0) {
    if (arg0.equals(getVersion())) {
      return true;
    }
    return false;
  } //isCompatible

  public String getVersion() {
    return "1.0";
  } //getVersion

  public String getVendorString() {
    return "Copyright (c) 2006 Monsanto Corp.";
  } //getVendorString



  // fix for issue#0159022
  private String notifyGrp = null;
  private String notify_suffix = "_notify";
  // fix for issue#0159022
  private String reviewers1 = null;
  private String reviewers2 = null;
  private String approvers = null;
  private IDfId m_activityId = null;
  private IDfId m_processId = null;
  private String m_strPackageName = null;
  private String m_strPortName = null;

  private String m_Workflow2Run = "Breeding Approval Workflow";

  //private String strLifecycle = "Breeding DLC";
  private String draft = "Draft";
  private String approved = "Effective";

  private String prefix = "breed_";
  private String reviewer_suffix = "_reviewer";
  private String approver_suffix = "_approver";
  private String OBJECT_ALREADY_PARTICIPATES_IN_WORKFLOW = "This object already participates in workflow with ID:: ";
}
