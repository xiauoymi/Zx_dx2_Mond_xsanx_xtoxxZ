package com.monsanto.dctm.manudocctrl.test;

import junit.framework.TestCase;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.attachlifecycle.test.AttachLifecycleTestUtils;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Jul 14, 2009
 * Time: 3:55:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class ManuDoc_AT extends TestCase {
    public void testAttachLifecylceForManuThatShouldAttach() throws Exception {
       IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl29", "devl29");
       IDfSession session = null;
       IDfSysObject sourceObject = null;
       try {
         // Note: lifecycle manipulation apparently cannot occur within a transaction
         //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
         session = sessionManager.getSession("stltst03");
         sourceObject = (IDfSysObject) session.newObject("manu_doc");
         sourceObject.setObjectName("Test Lifecycle Manu doc");
         sourceObject.setString("manu_authors","devl09");
         sourceObject.setString("manu_business","Seed");
         sourceObject.setString("manu_department","Engineering");
         sourceObject.setString("manuregion","North America");
         sourceObject.setString("manuproduct_type","Not Applicable");
         sourceObject.setString("site_or_plant","Not Applicable");

         sourceObject.save();

         assertEquals("MFG DOC DLC", sourceObject.getPolicyName());
         assertEquals("Draft", sourceObject.getCurrentStateName());
       } finally {
         if (sourceObject != null) {
          sourceObject.destroy();
         }
         if (session != null) {
           sessionManager.release(session);
         }
       }
     }
     public void testAttachLifecylceForManuAfterCheckinThatShouldAttach() throws Exception {
       IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl29", "devl29");
       IDfSession session = null;
       IDfSysObject sourceObject = null;
       IDfSysObject newObject = null;
       try {
         // Note: lifecycle manipulation apparently cannot occur within a transaction
         //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
         session = sessionManager.getSession("stltst03");
         sourceObject = (IDfSysObject) session.newObject("manu_doc");
         sourceObject.setObjectName("Test Lifecycle Manu doc");
         sourceObject.setString("manu_authors","devl09");
         sourceObject.setString("manu_business","Seed");
         sourceObject.setString("manu_department","Engineering");
         sourceObject.setString("manuregion","North America");
         sourceObject.setString("manuproduct_type","Not Applicable");
         sourceObject.setString("site_or_plant","Not Applicable");
         sourceObject.save();

         sourceObject.checkout();
         IDfId newId = sourceObject.checkin(false,"");
         newObject = (IDfSysObject)session.getObject(newId);

         assertEquals("MFG DOC DLC", newObject.getPolicyName());
         assertEquals("Draft", newObject.getCurrentStateName());
       } finally {
         if (sourceObject != null) {
          sourceObject.destroy();
         }
         if (newObject != null) {
          newObject.destroy();
         }
         if (session != null) {
           sessionManager.release(session);
         }
       }
     }
     public void testAttachLifecylceForManuAfterCheckinApprovedDocThatShouldAttach() throws Exception {
       IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl29", "devl29");
       IDfSession session = null;
       IDfSysObject sourceObject = null;
       IDfSysObject newObject = null;
       try {
         // Note: lifecycle manipulation apparently cannot occur within a transaction
         //  so we have to destroy our sourceObject at the end rather than begin and abort a transaction
         session = sessionManager.getSession("stltst03");
         sourceObject = (IDfSysObject) session.newObject("manu_doc");
         sourceObject.setObjectName("Test Lifecycle Manu doc");
         sourceObject.setString("manu_authors","devl09");
         sourceObject.setString("manu_business","Seed");
         sourceObject.setString("manu_department","Engineering");
         sourceObject.setString("manuregion","North America");
         sourceObject.setString("manuproduct_type","Not Applicable");
         sourceObject.setString("site_or_plant","Not Applicable");

         sourceObject.save();
         sourceObject.promote("",true,true);

         sourceObject.checkout();
         IDfId newId = sourceObject.checkin(false,"");
         newObject = (IDfSysObject)session.getObject(newId);

         assertEquals("MFG DOC DLC", newObject.getPolicyName());
         assertEquals("Draft", newObject.getCurrentStateName());
       } finally {
         if (sourceObject != null) {
          sourceObject.destroy();
         }
         if (newObject != null) {
          newObject.destroy();
         }
         if (session != null) {
           sessionManager.release(session);
         }
       }
     }
}
