/*
 * IManuDoc.java
 *
 * Created on July 14, 2005, 9:06 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.manudocctrl;

import com.documentum.fc.client.IDfBusinessObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

/**
 * @author tsvedan
 */
public interface IManuDoc extends IDfBusinessObject {

  /**
   * Sets the Object id of the dm_process object that defines the workflow template
   *
   * @param processName Object Name of the dm_process object that defines the workflow template
   */
  public void setProcessId(String processName) throws DfException;

  /**
   * Sets the object id of the dm_activity object to which the checked in document will be attached
   *
   * @param activityId object id of the dm_activity object to which the checked in document will be attached
   */
  public void setActivityId(IDfId activityId);


  /**
   * Name of the port to on which the document will be sent.
   *
   * @param portName Port name on which the document will be sent.
   */
  public void setPortName(String portName);

  /**
   * Set the name of the package that will contain the object being checked in.
   *
   * @param packageName The name of the package
   */
  public void setPackageName(String packageName);

}
