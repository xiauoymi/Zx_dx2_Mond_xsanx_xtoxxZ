/*
 * ManuDoc.java
 *
 * Created on July 14, 2005, 9:05 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.manudocctrl;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.monsanto.dctm.mon_docs.MonMonDocs;

/**
 * @author tsvedan
 */
public class ManuDoc extends DfSysObject
        implements IManuDoc, IDfDynamicInheritance {
    private String manu_authors;

    /**
     * Creates a new instance of ManuDoc
     */
    public ManuDoc() {
        super();
        //initConfig();
    }


    private IDfId m_activityId = null;
    private IDfId m_processId = null;
    private String m_strPackageName = null;
    private String m_strPortName = null;
    private String m_Workflow2Run = "Manufacturing Approval Workflow";

    private String org = "mfg";
    private String _ = "_";
    private static final String DRAFT_LIFECYCLE_STATE = "Draft";
    private String approved = "Approved";
    private String manuReviewers = null;
    private String manuApprovers = null;
    private String supervisor = null;
    private String business = null;
    private String region = null;

    /*
    * @param arg0
    * @param arg1
    * @param arg2
    * @param arg3
    * @param arg4
    * @param arg5
    * @return com.documentum.fc.common.IDfId
    * @throws com.documentum.fc.common.DfException
    *
    * @see com.documentum.fc.client.IDfSysObject#checkinEx(boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    */
    public IDfId doCheckin(
            boolean arg0,
            String arg1,
            String arg2,
            String arg3,
            String arg4,
            String arg5,
            java.lang.Object[] objects)
            throws DfException {
        DfLogger.info(this, "@@@@@@@@@ doCheckin @@@@@@@@@", null, null);
        if (this.getPreviousApprovedVersion())
            arg1 = arg1.replaceAll("CURRENT", moveSymbolicVersionLabel());
        else
            arg1 = "," + moveSymbolicVersionLabel() + "," + arg1;
        IDfId newId = super.doCheckin(arg0, arg1, arg2, arg3, arg4, arg5,objects);

        IDfSession sess = getSession();
        IDfSysObject newObj = (IDfSysObject) sess.getObject(newId);
        DfLogger.info(this, "***Your name is :: " + sess.getLoginUserName(), null, null);
        DfLogger.info(this, "ManuDoc.checkinEx", null, null);
        DfLogger.info(this, "newObj.getString(\"manu_authors\") = " + newObj.getString("manu_authors"), null, null);
        manu_authors = newObj.getString("manu_authors");
        if (isApprovedVersion(this) || (!isAlreadyInWorkflow(newObj) && isDraftVersion(newObj))) {
            setProcessId(getWorkflowName());
            setGroupNames(newObj);
            startWorkflow(newId);
        }
        return newId;
    } //checkinEx


    /*
    * @param saveLock
    * @param versionLabel
    * @param extendedArgs
    *
    * @throws com.documentum.fc.common.DfException
    *
    */
    public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs) throws DfException {
        DfLogger.info(this, "@@@@@@@@@ doSave @@@@@@@@@", null, null);
        DfLogger.info(this, "***Your name is :: " + getSession().getLoginUserName(), null, null);
        super.doSave(saveLock, versionLabel, extendedArgs);

        if (!isAlreadyInWorkflow(this) && isDraftVersion(this)) {
            DfLogger.info(this,"ManuDoc.doSave",null,null);
            DfLogger.info(this,"this.getString(\"manu_authors\") = " + this.getString("manu_authors"),null,null);
            manu_authors = this.getString("manu_authors");
            setProcessId(getWorkflowName());
            setGroupNames(this);
            startWorkflow(this.getId("r_object_id"));
        }

    } //doSave
    /**
     * Gets and sets the ID of the process to start from the Docbase.
     *
     * @param processName Name of the process that represents the workflow to initialize
     */
    public void setProcessId(String processName) throws DfException {
        IDfSession session;
        IDfCollection Workflows = null;
        try {
            session = getSession();
            Workflows = session.getRunnableProcesses("");
            IDfId processID;
            while (Workflows.next()) {
                IDfTypedObject Next = Workflows.getTypedObject();
                if (Next.getString("object_name").equals(processName)) {
                    processID = Next.getId("r_object_id");
                    m_processId = processID;
                    DfLogger.info(this, "Workflow name: " + Next.getString("object_name"), null, null);
                    DfLogger.info(this, "Set the process id: " + processID.toString(), null, null);
                    break;
                }
            }
        } finally{
            if (Workflows != null)
            Workflows.close();
        }
    }


    /**
     * Sets the object id of the dm_activity object to which the checked in document will be attached
     *
     * @param activityId object id of the dm_activity object to which the checked in document will be attached
     */
    public void setActivityId(IDfId activityId) {
        m_activityId = activityId;
    }


    /**
     * sets the package name to which to add the object being checked in.
     *
     * @param packageName package name
     */
    public void setPackageName(String packageName) {
        m_strPackageName = packageName;
    }

    /**
     * Name of the port to on which the document will be sent.
     *
     * @param strPort Port name on which the document will be sent.
     */
    public void setPortName(String strPort) {
        m_strPortName = strPort;
    }


    /**
     * Returns the object id of the dm_activity object to which the checked in document will be attached
     *
     * @return IDfId    object id of the dm_activity object to which the checked in document will be attached
     */
    public IDfId getActivityId() {
        return m_activityId;
    }

    /**
     * gets the name of the package to which the object being checked in is added.
     *
     * @return String name of the package to which the object being checked in is added
     */
    public String getPackageName() {
        return m_strPackageName;
    }

    /**
     * Gets the name of the port on which the document will be sent.
     *
     * @return String   Port name on which the document will be sent
     */
    public String getPortName() {
        return m_strPortName;
    }

    /**
     * getter method for the process id.
     *
     * @return IDfId    object id of the dm_process object that defines the workflow template
     */
    public IDfId getProcessId() {
        return m_processId;
    }


//    private void initConfig() {
//        try {
////            DfLogger.info(this,"****Initializing the XML config file", null, null);
//            IBOConfig boConfig = BOConfigFactory.newBOConfig(this);
//            approved = boConfig.getValue("/manu_doc/lifecycle/approvedstatename");
//            m_Workflow2Run = boConfig.getValue("/manu_doc/workflow/name");
//            defaultGroupPre = boConfig.getValue("/manu_doc/workflow/defaultgroupprefix");
//        } catch (BOConfigException boe) {
//            DfLogger.error(this, "Error initializing the config file", null, null);
//            boe.printStackTrace();
//        }
//    }


    /**
     * Starts the workflow and attaches the document specified by <code>documentId</code> to the workflow. The first start
     * activity is chosen and first input port of that activity is chosen to attach the document.
     *
     * @param documentId Object id of the document that will be attached to the workflow after it is started.
     * @throws com.documentum.fc.common.DfException
     */
    protected void startWorkflow(IDfId documentId) throws DfException {
        IDfSession session;
        try {
            session = getSession();

            IDfId processId = getProcessId();
            if (processId == null) {
                DfLogger.warn(this, "No valid processes to start", null, null);
                return;
            }
            IDfWorkflowBuilder wfBuilder =
                    session.newWorkflowBuilder(processId);
            wfBuilder.initWorkflow();
            wfBuilder.runWorkflow();
            IDfWorkflow workflow = wfBuilder.getWorkflow();

            setAliases(workflow); //Set the missing aliases here!
            workflow.updateSupervisorName(supervisor);

            String packageName = null;
            String portName = null;

            if (getActivityId() == null) //choose first start activity by default
            {
                IDfList activityIds = wfBuilder.getStartActivityIds();
                setActivityId((IDfId) activityIds.get(0));
            }

            IDfActivity activity =
                    (IDfActivity) session.getObject(getActivityId());
            String activityName = activity.getString("object_name");

            if (getPortName() == null) //choose first input port by default
            {
                for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
                    if (activity.getPortType(cntrPort).equals("INPUT")) {
                        portName = activity.getPortName(cntrPort);
                        packageName = activity.getPackageName(cntrPort);
                        break;
                    }
                }
            } else {
                portName = getPortName();
                for (int i = 0; i < activity.getPortCount(); i++) {
                    if (activity.getPortName(i).equals(portName)) {
                        packageName = activity.getPackageName(i);
                        break;
                    }
                }
            }

            String strObjectType = getTypeName();
            DfList list = new DfList();
            list.append(documentId);
            workflow.addPackage(
                    activityName,
                    portName,
                    packageName,
                    strObjectType,
                    "",
                    false,
                    list);
            DfLogger.info(this, "Started workflow with id: " + workflow.getObjectId().getId(), null, null);
            DfLogger.info(this, "Workflow name: " + workflow.getObjectName(), null, null);
            DfLogger.info(this, "The workflow supervisor is: " + workflow.getSupervisorName(), null, null);
            DfLogger.info(this, "Added package with doc id: " + documentId, null, null);
        } catch (DfException dfe) {
            DfLogger.error(this, dfe.getMessage(), null, null);
            dfe.printStackTrace();
            throw dfe;
        }
    } //startWorkflow


    /**
     * Obtains the default alias set for the workflow and sets the alias values for all the aliases.
     *
     * @param workflow Workflow object for which the aliases need to be assigned.
     * @throws com.documentum.fc.common.DfException
     */
    protected void setAliases(IDfWorkflow workflow) throws DfException {
            IDfSession session = getSession();
            // Get the AliasSet ID for this workflow
            IDfId AliasSetId = workflow.getAliasSetId();
            DfLogger.info(this, "Alias set ID: " + AliasSetId.toString(), null, null);
            //get the alias set
            IDfAliasSet AliasSet = (IDfAliasSet) session.getObject(AliasSetId);
            //Set the aliases by name - Reviewer, Approver
            int nAliases = AliasSet.getAliasCount();

            int indexofRev = AliasSet.findAliasIndex("Reviewers");
            if (indexofRev > -1)
                AliasSet.setAliasValue(indexofRev, manuReviewers);
            int indexofApp = AliasSet.findAliasIndex("Approvers");
            if (indexofApp > -1)
                AliasSet.setAliasValue(indexofApp, manuApprovers);
            int indexofAuth = AliasSet.findAliasIndex("Author");
            DfLogger.info(this,"manu_authors = " + manu_authors,null,null);
            if (indexofAuth > -1)
                AliasSet.setAliasValue(indexofAuth, manu_authors);

            // Save the AliasSet!
            AliasSet.save();

            for (int i = 0; i < nAliases; i++) {
                DfLogger.info(this, "AliasName: "
                        + AliasSet.getAliasName(i)
                        + ", "
                        + "AliasValue = "
                        + AliasSet.getAliasValue(i), null, null);
            }

    } //setAliases


    /**
     * Creates the appropriate group name prefix for the activity performers based on the attributes of the document.
     *
     * @param manuDocument The document object in consideration as an IDfSysObject interface
     */
    protected String makeGroupNamesPrefixBasedOnAttrs(IDfSysObject manuDocument) throws DfException {
        String manuTitle = manuDocument.getString("object_name").trim();
        String manuBusiness = manuDocument.getString("manu_business").trim();
        String manuDept = manuDocument.getString("manu_department").trim();
        String manuRegion = manuDocument.getString("manuregion").trim();
        String manuSite = manuDocument.getString("site_or_plant").trim();
        String manuProduct = manuDocument.getString("manuproduct_type").trim();

        DfLogger.info(this, "Title: " + manuTitle, null, null);
        DfLogger.info(this, "Business: " + manuBusiness, null, null);
        DfLogger.info(this, "Region: " + manuRegion, null, null);
        DfLogger.info(this, "Department: " + manuDept, null, null);
        DfLogger.info(this, "Site: " + manuSite, null, null);
        DfLogger.info(this, "Crop: " + manuProduct, null, null);

        String select = "SELECT coded_value FROM dm_dbo.code_lookup ";
        String end = "'";
        setBusiness(manuBusiness, select, end);
        setRegion(manuRegion, select, end);

        return processGroupCreationPrefix(manuDept, manuSite, manuProduct, select, end);
    } //makeGroupNamesPrefixBasedOnAttrs

    private void setRegion(String manuRegion, String select, String end) throws DfException {
        String qualReg = "WHERE code_type='manu_region' AND decoded_value='";
        region = execQuery(select + qualReg + manuRegion + end);
    }

    private void setBusiness(String manuBusiness, String select, String end) throws DfException {
        String qualBus = "WHERE code_type='manu_business' AND decoded_value='";
        business = execQuery(select + qualBus + manuBusiness + end);
    }

    private String processGroupCreationPrefix(String manuDept, String manuSite,
                                              String manuProduct, String select, String end) throws DfException {
        String groupPrefix;
            if (manuSite.equals("Not Applicable")) {
                if (manuProduct.equals("Not Applicable"))
                {
                    groupPrefix = createGroupPrefixDepartmentSelectionIsNotNA(manuDept, select, end);
                }
                else
                {
                    groupPrefix = createGroupPrefixProductSelectionIsNotNA(manuProduct, select, end);
                }
            }
            else
            {
                groupPrefix = createGroupPrefixSiteSelectionIsNotNA(manuSite, select, end);
            }
        supervisor = org + _ + business + _ + region + "_wf_supervisor";
        return groupPrefix;
    }

    private String createGroupPrefixProductSelectionIsNotNA(String manuProduct, String select, String end) throws DfException {
        String product;
        String groupPrefix;
        String qualProduct = "WHERE code_type='manu_producttype' AND decoded_value='";
        product = execQuery(select + qualProduct + manuProduct + end);
        groupPrefix = org + _ + business + _ + region + _ + product + _;
        DfLogger.info(this, "CROP Workflow group prefix :: " + groupPrefix, null, null);
        return groupPrefix;
    }

    private String createGroupPrefixDepartmentSelectionIsNotNA(String manuDept, String select, String end) throws DfException {
        String dept;
        String groupPrefix;
        String qualDept = "WHERE code_type='manu_dept' AND decoded_value='";
        dept = execQuery(select + qualDept + manuDept + end);
        groupPrefix = org + _ + business + _ + region + _ + dept + _;
        DfLogger.info(this, "DEPT Workflow group prefix :: " + groupPrefix, null, null);
        return groupPrefix;
    }

    private String createGroupPrefixSiteSelectionIsNotNA(String manuSite, String select, String end) throws DfException {
        String site;
        String groupPrefix;
        String qualSite = "WHERE code_type='manu_site' AND decoded_value='";
        site = execQuery(select + qualSite + manuSite + end);
        groupPrefix = org + _ + business + _ + site + _;
        DfLogger.info(this, "SITE Workflow group prefix :: " + groupPrefix, null, null);
        return groupPrefix;
    }


    /**
     * Sets the appropriate group names for the reviewers and approvers groups based on the group prefix output from the
     * makeGroupNamesPrefixBasedOnAttrs method
     *
     * @param sysObj The current document in consideration as an IDfSysObject interface
     * @throws com.documentum.fc.common.DfException
     */
    protected void setGroupNames(IDfSysObject sysObj) throws DfException {

        IDfGroup superGroup = null;
        IDfSession sess = getSession();
        String groupPrefix = makeGroupNamesPrefixBasedOnAttrs(sysObj);
        if (groupPrefix == "" || groupPrefix == null)
            throw new DfException("No valid group for this workflow");

        manuReviewers = groupPrefix + "reviewers";
        manuApprovers = groupPrefix + "approvers";
        IDfGroup revGroup = sess.getGroup(manuReviewers);
        IDfGroup appGroup = sess.getGroup(manuApprovers);
        if (supervisor != null)
        {
            superGroup = sess.getGroup(supervisor);
        }
        try {
            if (revGroup == null || revGroup.getAllUsersNamesCount() < 1) {
                String msg = "###Group specified by " + manuReviewers + " does not exist or is empty!";
                throw new DfException(msg);
            }
            if (appGroup == null || appGroup.getAllUsersNamesCount() < 1) {
                String msg = "###Group specified by " + manuApprovers + " does not exist or is empty!";
                throw new DfException(msg);
            }
        } catch (DfException dfe) {
            manuReviewers = org  +"_"+ business +"_"+ region +"_general_reviewers";
            manuApprovers = org  +"_"+ business +"_"+ region +"_general_approvers";
            DfLogger.warn(this, dfe.getMessage(), null, null);
            DfLogger.info(this, "Reviewers group = " + manuReviewers, null, null);
            DfLogger.info(this, "Approvers group = " + manuApprovers, null, null);
        } finally {
            if (superGroup != null && superGroup.getAllUsersNamesCount() > 0)
                supervisor = superGroup.getAllUsersNames(0);
            else {
                IDfGroup revGroupToGo = sess.getGroup(manuReviewers);
                supervisor = revGroupToGo.getAllUsersNames(0);
            }
        }
    }//setGroupNames


    /**
     * Executes a query against the docbase and returns the String representation of the result - used here to run queries
     * against the code_lookup registered table and get the coded_value given the decoded_value and code_type
     *
     * @param queryString The query to execute
     *
     * @return String representing the result of the query
     * @throws com.documentum.fc.common.DfException
     */
    protected String execQuery(String queryString) throws DfException {
        IDfCollection coll = null; //Collection for the result
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery(); //Create query object
        String result = null;
        q.setDQL(queryString); //Give it the query
        try{
            coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
            if (coll.next()) {
                result = coll.getString("coded_value");
                DfLogger.info(this, "Query executed... Result is " + result, null, null);
            }
        }finally {
            if (coll != null)
                coll.close();
        }
        return result;
    } //execQuery

    /**
     * Checks to see if there is a previous (latest) Approved version anywhere in the version tree
     *
     * @return Returns true if one exists, false otherwise
     * @throws com.documentum.fc.common.DfException
     */
    protected boolean getPreviousApprovedVersion() throws DfException {
        IDfSysObject version = null;
        IDfId versionId;
        IDfCollection coll = null;
        boolean approvedVersionFound = false;
        DfLogger.info(this, "!!!! In getPreviousApprovedVersion....", null, null);
        if (this.getVStamp() == 0) return false;
        try {
            coll = this.getVersions("r_version_label, r_modify_date, r_object_id");
            if (coll != null) {
                while (coll.next()) {
                    versionId = coll.getId("r_object_id");
                    version = (IDfSysObject) getSession().getObject(versionId);
                    if (isApprovedVersion(version)) {
                        approvedVersionFound = true;
                        break;
                    }
                }
            }
        }finally{
            if (coll != null)
                coll.close();
        }
        DfLogger.info(this, "!!!!!CHECKED FOR APPROVED VERSIONS .." + approvedVersionFound, null, null);
        return approvedVersionFound;
    } //getPreviousApprovedVersion

    /**
     * Checks to see if this document is a Draft version by checking its version label for the value Draft.
     *
     * @param sysObj
     * @return Returns true if this is a Draft version, false otherwise
     */
    protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {
        String label;
        boolean isDraft = false;
        for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
            label = sysObj.getVersionLabel(i);
            if (label.equals(DRAFT_LIFECYCLE_STATE))
                isDraft = true;
        }
        return isDraft;
    } //isDraftVersion

    /**
     * Checks to see if this document is already participating in a workflow
     *
     * @return Returns true if it is, false otherwise
     */
    protected boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException {
        IDfSysObject version;
        IDfId versionId = null;
        IDfCollection coll = null;
        IDfCollection wcoll = null;
        boolean inWorkflow = false;
        try{
            wcoll = sysObj.getWorkflows("", "");
            if (wcoll != null && wcoll.next()) {
                DfLogger.info(this, "This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"),
                        null, null);
                inWorkflow = true;
            } else if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null) {
                while (coll.next()) {
                    versionId = coll.getId("r_object_id");
                    version = (IDfSysObject) getSession().getObject(versionId);
                    if (version.getCurrentStateName().equals(approved))
                        continue;
//         Closing previuos collection object before it gets assigned to new object */
                    if (wcoll != null)
                    {
                    wcoll.close();
                    DfLogger.info(this, "Manu Doc Control Collection Object Closed." , null, null);
                    }
                    wcoll = version.getWorkflows("", "");
                    if (wcoll != null && wcoll.next()) {
                        DfLogger.info(this,
                                "This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"), null, null);
                        inWorkflow = true;
                        break;
                    }
                }
            }
        }finally {
            if (wcoll != null)
                wcoll.close();
            if (coll != null)
                coll.close();
        }
        return inWorkflow;
    } //isAlreadyInWorkflow


    /**
     * Finds the symbolic version labels draft and "Review" in the current document's r_version_label and automatically
     * moves it to next version during checkin.
     *
     * @return String The symbolic version label applied to this document. Returns Draft if it finds Approved!
     */
    protected String moveSymbolicVersionLabel() throws DfException {
        String label;
        for (int i = 1; i < this.getVersionLabelCount(); i++) {
            label = this.getVersionLabel(i);
            if (label.equals("Review")) {
                return label;
            }
        }
        return DRAFT_LIFECYCLE_STATE;
    } //moveSymbolicVersionLabel

    /**
     * Tests whether an object is the latest approved version.
     *
     * @param sysObj The object that has to be tested for "Approved" label.
     *
     * @return boolean True if it is, False otherwise.
     * @throws com.documentum.fc.common.DfException
     */
    protected boolean isApprovedVersion(IDfSysObject sysObj) throws DfException {
        boolean isApproved = false;
        if (sysObj.getCurrentStateName() == null)
            return true;
        if (sysObj.getCurrentStateName().equals(approved)) {
            isApproved = true;
        }
        return isApproved;
    } //isApprovedVersion


    /* Returns a string describing the vendor.
    * @return java.lang.String
    *
    * @see com.documentum.fc.client.IDfBusinessObject#getVendorString()
    */
    public String getVendorString() {
        return "Copyright (c) 2006 Monsanto Corp.";
    }

    /*
    * Returns the version of the business object.
    *
    * @return java.lang.String    A string of form 'majorVersionNumber.minorVersionNumber'
    *
    * @see com.documentum.fc.client.IDfBusinessObject#getVersion()
    */
    public String getVersion() {
        return "1.0";
    }


    /*
    * @param arg0
    * @return boolean
    *
    * @see com.documentum.fc.client.IDfBusinessObject#isCompatible(java.lang.String)
    */
    public boolean isCompatible(String arg0) {
        return arg0.equals(getVersion()) ? true : false;
    }


    /**
     * @param arg0
     *
     * @return boolean
     *
     * @see com.documentum.fc.client.IDfBusinessObject#supportsFeature(String)
     */
    public boolean supportsFeature(String arg0) {
        return false;
    }

    public String getWorkflowName() {
        return m_Workflow2Run;
    }

    protected String getManuReviewerGroup() {
        return manuReviewers;
    }

    protected String getManuApproverGroup() {
         return manuApprovers;
    }
}
