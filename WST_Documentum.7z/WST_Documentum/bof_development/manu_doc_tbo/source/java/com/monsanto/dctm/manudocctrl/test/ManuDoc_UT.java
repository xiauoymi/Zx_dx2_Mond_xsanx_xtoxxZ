package com.monsanto.dctm.manudocctrl.test;

import junit.framework.TestCase;
import com.monsanto.dctm.test.*;
import com.monsanto.dctm.attachlifecycle.MonAttachLifecycleService;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.DfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Jul 14, 2009
 * Time: 1:36:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class ManuDoc_UT extends TestCase {

    public void testCreate() throws Exception {
        MockManuDoc mockManuDoc = new MockManuDoc();

        assertNotNull(mockManuDoc);
    }
    public void testAttachLifecycleWithLifecycleNameForManu() throws Exception {
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);

        assertEquals("MFG DOC DLC", sourceObject.getPolicyName());
        assertEquals("Draft", sourceObject.getCurrentStateName());
    }
    public void testGetWorkflowNameWithNoWorkflowNameGiven() throws Exception {
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //manu sysobject setup
        MockSysObject sourceObject = new MockSysObject();
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);

        String workflowName = mockManuDoc.getWorkflowName();

        assertEquals("Manufacturing Approval Workflow", workflowName);
    }
    public void testMakeGroupNamesPrefixBasedOnAttrsSiteDoesNotHaveNAShouldHaveSiteGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","WACO Production");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Canola Process");

        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueSiteObject = new MockSysObject();
        codedValueSiteObject.setString("coded_value","wacoprd");
        mockSession.addObject(codedValueSiteObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_site' AND decoded_value='WACO Production'");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        String groupPreFix = mockManuDoc.makeGroupNamesPrefix(sourceObject);

        assertEquals("mfg_seed_wacoprd_", groupPreFix);
    }
    public void testMakeGroupNamesPrefixBasedOnAttrsSiteDoesNotHaveNAProductIsNAShouldHaveSiteGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","WACO Production");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Not Applicable");

        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueSiteObject = new MockSysObject();
        codedValueSiteObject.setString("coded_value","wacoprd");
        mockSession.addObject(codedValueSiteObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_site' AND decoded_value='WACO Production'");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        String groupPreFix = mockManuDoc.makeGroupNamesPrefix(sourceObject);

        assertEquals("mfg_seed_wacoprd_", groupPreFix);
    }
    public void testMakeGroupNamesPrefixBasedOnAttrsSiteHasNAProductTypeIsNotNAShouldHaveRegionProductTypeGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        sourceObject.setSession(mockSession);
        //sysobject setup
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","Not Applicable");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Canola Process");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueProductTypeObject = new MockSysObject();
        codedValueProductTypeObject.setString("coded_value","canpro");
        mockSession.addObject(codedValueProductTypeObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_producttype' AND decoded_value='Canola Process'");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        String groupPreFix = mockManuDoc.makeGroupNamesPrefix(sourceObject);

        assertEquals("mfg_seed_na_canpro_", groupPreFix);
    }
    public void testMakeGroupNamesPrefixBasedOnAttrsSiteHasNAProductTypeIsNADeptIsNotGlobalOpsShouldHaveRegionDeptGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","Not Applicable");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Not Applicable");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueDeptObject = new MockSysObject();
        codedValueDeptObject.setString("coded_value","eng");
        mockSession.addObject(codedValueDeptObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_dept' AND decoded_value='Engineering'");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        String groupPreFix = mockManuDoc.makeGroupNamesPrefix(sourceObject);

        assertEquals("mfg_seed_na_eng_", groupPreFix);
    }
    public void testMakeGroupNamesPrefixBasedOnAttrsSiteHasNARegionIsAllProductTypeIsNADeptIsGlobalOpsShouldHaveRegionDeptGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","Not Applicable");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Global Operations");
        sourceObject.setString("manuproduct_type","Not Applicable");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueDeptObject = new MockSysObject();
        codedValueDeptObject.setString("coded_value","glops");
        mockSession.addObject(codedValueDeptObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_dept' AND decoded_value='Global Operations'");

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        String groupPreFix = mockManuDoc.makeGroupNamesPrefix(sourceObject);

        assertEquals("mfg_seed_na_glops_", groupPreFix);
    }
    public void testSetGroupNamesSiteDoesNotHaveNAAndSiteGroupIsNotExistingShouldHaveRegionGeneralGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","WACO Production");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Canola Process");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueSiteObject = new MockSysObject();
        codedValueSiteObject.setString("coded_value","wacoprd");
        mockSession.addObject(codedValueSiteObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_site' AND decoded_value='WACO Production'");
        //supervisor group setup
        MockDfGroup workflowSupervisorGroup = new MockDfGroup();
        workflowSupervisorGroup.setGroupName("mfg_seed_na_wf_supervisor");
        workflowSupervisorGroup.addUser("user1");
        mockSession.addGroup(workflowSupervisorGroup);

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        mockManuDoc.setGroupNames(sourceObject);

        assertEquals("mfg_seed_na_general_reviewers", mockManuDoc.getManuReviewerGroup());
        assertEquals("mfg_seed_na_general_approvers", mockManuDoc.getManuApproverGroup());
    }
    public void testSetGroupNamesSiteDoesNotHaveNAProductIsNAAndSiteGroupIsNotExistingShouldHaveRegionGeneralGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","WACO Production");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Not Applicable");

        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueSiteObject = new MockSysObject();
        codedValueSiteObject.setString("coded_value","wacoprd");
        mockSession.addObject(codedValueSiteObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_site' AND decoded_value='WACO Production'");
        //supervisor group setup
        MockDfGroup workflowSupervisorGroup = new MockDfGroup();
        workflowSupervisorGroup.setGroupName("mfg_seed_na_wf_supervisor");
        workflowSupervisorGroup.addUser("user1");
        mockSession.addGroup(workflowSupervisorGroup);

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        mockManuDoc.setGroupNames(sourceObject);

        assertEquals("mfg_seed_na_general_reviewers", mockManuDoc.getManuReviewerGroup());
        assertEquals("mfg_seed_na_general_approvers", mockManuDoc.getManuApproverGroup());
    }
    public void testSetGroupNamesSiteHasNAProductTypeIsNotNAAndRegionProductTypeGroupIsNotExistingShouldHaveRegionGeneralGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        sourceObject.setSession(mockSession);
        //sysobject setup
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","Not Applicable");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Canola Process");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueProductTypeObject = new MockSysObject();
        codedValueProductTypeObject.setString("coded_value","canpro");
        mockSession.addObject(codedValueProductTypeObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_producttype' AND decoded_value='Canola Process'");
        //supervisor group setup
        MockDfGroup workflowSupervisorGroup = new MockDfGroup();
        workflowSupervisorGroup.setGroupName("mfg_seed_na_wf_supervisor");
        workflowSupervisorGroup.addUser("user1");
        mockSession.addGroup(workflowSupervisorGroup);

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        mockManuDoc.setGroupNames(sourceObject);

        assertEquals("mfg_seed_na_general_reviewers", mockManuDoc.getManuReviewerGroup());
        assertEquals("mfg_seed_na_general_approvers", mockManuDoc.getManuApproverGroup());
    }
    public void testSetGroupNamesSiteHasNAProductTypeIsNADeptHasValueAndRegionDeptGroupIsNotExistingShouldHaveRegionGeneralGroupPrefix() throws Exception {
        MockSysObject sourceObject = new MockSysObject();
        MockManuDoc mockManuDoc = new MockManuDoc(sourceObject);
        MonAttachLifecycleService service = new MonAttachLifecycleService();
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        //lifecycle setup
        MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "MFG DOC DLC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Draft");
        stateNames.add("Review");
        stateNames.add("Approved");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "lifecycleID:MFG DOC DLC");
        mockSession.addObject(mockLifecycleObject, "dm_policy where object_name='MFG DOC DLC'");
        //manu sysobject setup
        sourceObject.setSession(mockSession);
        sourceObject.setString("r_policy_id", null);
        sourceObject.setString("r_object_type", "manu_doc");
        sourceObject.setString("object_name", "test object name");
        sourceObject.setString("manu_authors","devl09");
        sourceObject.setString("manu_business","Seed");
        sourceObject.setString("site_or_plant","Not Applicable");
        sourceObject.setString("manuregion","North America");
        sourceObject.setString("manu_department","Engineering");
        sourceObject.setString("manuproduct_type","Not Applicable");
        //code lookup setup
        sourceObject.setString("coded_value","seed");
        mockSession.addObject(sourceObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_business' AND decoded_value='Seed'");
        MockSysObject codedValueRegionObject = new MockSysObject();
        codedValueRegionObject.setString("coded_value","na");
        mockSession.addObject(codedValueRegionObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_region' AND decoded_value='North America'");
        MockSysObject codedValueDeptObject = new MockSysObject();
        codedValueDeptObject.setString("coded_value","eng");
        mockSession.addObject(codedValueDeptObject,"query_cmd,s0,T,F,,,,,SELECT coded_value FROM dm_dbo.code_lookup WHERE code_type='manu_dept' AND decoded_value='Engineering'");
        //supervisor group setup
        MockDfGroup workflowSupervisorGroup = new MockDfGroup();
        workflowSupervisorGroup.setGroupName("mfg_seed_na_wf_supervisor");
        workflowSupervisorGroup.addUser("user1");
        mockSession.addGroup(workflowSupervisorGroup);

        service.attachLifecycle(sourceObject, "MFG DOC DLC", null, null);
        mockManuDoc.setGroupNames(sourceObject);

        assertEquals("mfg_seed_na_general_reviewers", mockManuDoc.getManuReviewerGroup());
        assertEquals("mfg_seed_na_general_approvers", mockManuDoc.getManuApproverGroup());
    }

}
