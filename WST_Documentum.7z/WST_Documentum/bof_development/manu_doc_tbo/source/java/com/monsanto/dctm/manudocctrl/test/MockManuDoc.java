package com.monsanto.dctm.manudocctrl.test;

import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockPersistentObject;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.test.MockAliasSet;
import com.monsanto.dctm.manudocctrl.ManuDoc;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.IDfSession;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Jul 14, 2009
 * Time: 1:38:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockManuDoc extends ManuDoc {
    private MockSysObject mock;
    public MockManuDoc(MockSysObject mock){
        this.mock = mock;
    }
    public MockManuDoc() {
    }

    public String makeGroupNamesPrefix(MockSysObject sourceObject) throws DfException {
        return super.makeGroupNamesPrefixBasedOnAttrs(sourceObject);
    }
    public void setGroupNames(MockSysObject sourceObject)throws DfException {
        super.setGroupNames(sourceObject);
    }

    public String execQuery(String queryString) throws DfException {
        return super.execQuery(queryString);
    }
  public IDfSession getSession() {
    return mock.getSession();
  }
  public void setSession(IDfSession session) {
    mock.setSession(session);
  }

    public String getManuReviewerGroup() {
        return super.getManuReviewerGroup() ;
    }

    public String getManuApproverGroup() {
        return super.getManuApproverGroup();
    }
}
