package com.monsanto.dctm.hrindia.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.hrindia.HrIndiaDoc;
import com.monsanto.dctm.mon_docs.test.MockMonMonDocs;
import com.monsanto.dctm.test.MockDfACL;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Jul 6, 2009
 * Time: 2:49:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockHrIndiaDoc extends HrIndiaDoc {
       private MockMonMonDocs mock;
    public MockDfACL iDfACL;
   public MockHrIndiaDoc(){
    this(new MockMonMonDocs());
   }
    public MockHrIndiaDoc(MockMonMonDocs mockDocs) {
       mock = mockDocs;
    }
    public String getString(String attrName) throws DfException {
        return mock.getString(attrName);
    }
   
    public void setString(String attrName, String value) throws DfException {
        mock.setString(attrName, value);
    }
    public void setSession(IDfSession session) {
        mock.setSession(session);
    }
    public IDfSession getSession() {
          return mock.getSession();
    }
  public void setACL(IDfACL iDfACL) throws DfException {
                 this.iDfACL = (MockDfACL) iDfACL;
          }
  public IDfACL getACL(){
        return this.iDfACL;
  }
}
