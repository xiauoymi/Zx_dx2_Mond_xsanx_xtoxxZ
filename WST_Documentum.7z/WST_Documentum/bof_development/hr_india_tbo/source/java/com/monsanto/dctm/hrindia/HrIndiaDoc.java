/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.hrindia;

import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;
import com.monsanto.dctm.mon_docs.MonMonDocs;

/**
 * Filename:    $RCSfile: HrIndiaDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-07-13 20:14:11 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class HrIndiaDoc extends MonMonDocs implements IDfDynamicInheritance, IHrIndiaDoc{
    private static final String CONFIDENTIAL_CODED_VALUE = "conf";
    private static final String CONFIDENTIAL_DOC_ACL = "hr_in_conf_acl";
    private static final String GENERAL_DOC_ACL = "hr_in_gen_acl";
    private static final String GENERAL_CODED_VALUE = "gen";

    public String getVendorString() {
        return "Copyright(c) Monsanto Corp., 2005";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean isCompatible(String str) {
        return str.equals("1.0");
    }

    public boolean supportsFeature(String str) {
        return false;
    }
    protected IDfId doCheckin(boolean b, String attrName, String attrName1, String attrName2, String attrName3, String attrName4, Object[] objects) throws
            DfException {
        IDfId newObjId = super.doCheckin(b, attrName, attrName1, attrName2, attrName3, attrName4, objects);
        getObject(newObjId).save();
        DfLogger.debug(this,"HrIndiaDoc.doCheckin  newObjId: "+ newObjId, null, null);
        setAclForDocTypes();
        return newObjId;
    }
    public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
            throws DfException {
        super.doSave(saveLock, versionLabel, extendedArgs);
        DfLogger.debug(this,"HrIndiaDoc.doSave", null, null);
        setAclForDocTypes();
        super.doSave(saveLock, versionLabel, extendedArgs);
    }
    public void setAclForDocTypes() throws DfException {
        String hrDocType = this.getString("hr_doc_type");
        //get coded_value from code lookup
        String codedValue = getCodedValue(hrDocType);
        if (codedValue.equalsIgnoreCase(CONFIDENTIAL_CODED_VALUE)) {
            applyACL(CONFIDENTIAL_DOC_ACL);
        }
        if (codedValue.equalsIgnoreCase(GENERAL_CODED_VALUE)) {
            applyACL(GENERAL_DOC_ACL);
        }
    }

    private void applyACL(String acl) throws DfException {
        IDfSession session = this.getSession();
        DfLogger.debug(this,"HrIndiaDoc.applyACL: Before Changed permissions to: " + acl , null, null);
        IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), acl);
        setACL(newACL);
        DfLogger.debug(this,"HrIndiaDoc.applyACL:Changed permissions to: " + getACL().getObjectName() , null, null);
    }

    private String getCodedValue(String hrDocType) throws DfException {
        String codedValueFromCodeLookup;
        String query = "select coded_value from dm_dbo.code_lookup where code_type =  'hr_doc_type'  and decoded_value = '" + hrDocType + "'";
        DfLogger.debug(this, "HrIndiaDoc.getCodedValue: Query: " + query, null, null);
        codedValueFromCodeLookup = execQuery(query);
        return codedValueFromCodeLookup;
    }
    protected String execQuery(String queryString)
            throws DfException {
        IDfCollection coll = null; //Collection for the result
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery(); //Create query object
        String result = null;
        q.setDQL(queryString); //Give it the query
        try{
            coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
            if (coll.next()) {
                result = coll.getString("coded_value");
                DfLogger.debug(this,"HrIndiaDoc.execQuery: Name:"+this.getObjectName() + " "+"Query executed... Result is " + result, null, null);
            }
        }
        finally {
            if (coll != null)
                coll.close();
        }
        return result;
    } //execQuery
}
