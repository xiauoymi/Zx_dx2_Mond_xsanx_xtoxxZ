/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.hrindia;

import com.documentum.fc.common.DfException;
import com.documentum.fc.client.IDfBusinessObject;

/**
 * Filename:    $RCSfile: IHrIndiaDoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-07-13 20:14:11 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public interface IHrIndiaDoc extends IDfBusinessObject {
  public String getString(String attribute) throws DfException;
  public void setString(String attribute, String value) throws DfException;
  public String getObjectName() throws DfException;
  public void setRepeatingString(String attribute,int i, String value) throws DfException;
  public String getRepeatingString(String attribute,int i) throws DfException;
  public void setAclForDocTypes() throws DfException;
}