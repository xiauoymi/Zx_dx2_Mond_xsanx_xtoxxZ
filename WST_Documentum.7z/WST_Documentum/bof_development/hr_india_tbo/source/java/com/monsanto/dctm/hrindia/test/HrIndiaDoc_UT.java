package com.monsanto.dctm.hrindia.test;

import junit.framework.TestCase;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.seminis.test.MockSeminisDoc;
import com.documentum.fc.client.MockSession;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Jul 6, 2009
 * Time: 2:46:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class HrIndiaDoc_UT extends TestCase {


    public void testCreate() throws Exception {
        MockHrIndiaDoc object = new MockHrIndiaDoc();

        assertNotNull(object);
    }
    public void testApplyConfidentialAcl() throws Exception {
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        MockHrIndiaDoc mock = new MockHrIndiaDoc();
        mock.setString("r_object_id", "091234242");
        mock.setString("object_name", "Test Doc");
        mock.setString("hr_doc_type","Letter of offer");
        mock.setSession(mockSession);
        MockSysObject sysObject = new MockSysObject();
        sysObject.setString("coded_value","conf");
        mockSession.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where code_type =  'hr_doc_type'  and decoded_value = 'Letter of offer'");

        mock.setAclForDocTypes();

        assertEquals("hr_in_conf_acl", mock.getACL().getObjectName());
    }
    public void testApplyGeneralAcl() throws Exception {
        MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
        MockSession mockSession = new MockSession(mockDfSessionManager);
        MockHrIndiaDoc mock = new MockHrIndiaDoc();
        mock.setString("r_object_id", "091234242");
        mock.setString("object_name", "Test Doc");
        mock.setString("hr_doc_type","Personal details");
        mock.setSession(mockSession);
        MockSysObject sysObject = new MockSysObject();
        sysObject.setString("coded_value","gen");
        mockSession.addObject(sysObject,"query_cmd,s0,T,F,,,,,select coded_value from dm_dbo.code_lookup where code_type =  'hr_doc_type'  and decoded_value = 'Personal details'");

        mock.setAclForDocTypes();

        assertEquals("hr_in_gen_acl", mock.getACL().getObjectName());
    }

}
