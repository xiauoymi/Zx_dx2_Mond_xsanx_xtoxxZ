/*
 * BiotechManuscript.java
 *
 * Created on June 23, 2006, 5:20 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.biotech;

import com.documentum.fc.client.DfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;

/**
 *
 * @author tsvedan
 */
public class BiotechManuscript extends DfSysObject
        implements IBiotechManuscript, IDfDynamicInheritance{
    
    /** Creates a new instance of BiotechManuscript */
    public BiotechManuscript() {
    }
    
    protected void doSave(boolean saveLock, String versionLabel, Object[] extArguments) throws DfException {
        DfLogger.debug(this, "@@@@@@@@@ doSave @@@@@@@@@", null,null);
        super.doSave(saveLock, versionLabel, extArguments);
        // fix for 0169912
        //queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
        // fix for 0169912
    } //doSave
    
    public IDfId checkinEx(
            boolean arg0,
            String arg1,
            String arg2,
            String arg3,
            String arg4,
            String arg5)
            throws DfException {
        DfLogger.debug(this, "@@@@@@@@@ checkinEx @@@@@@@@@", null,null);
        IDfId newId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
        // fix for 0169912
        //((IDfSysObject) getSession().getObject(newId)).queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
        // fix for 0169912
        return newId;
    } //checkinEx

  
    public boolean supportsFeature(String arg0) {
        return false;
    } //supportsFeature
    
    
    public boolean isCompatible(String arg0) {
        if (arg0.equals(getVersion())) {
            return true;
        }
        return false;
    } //isCompatible
    
    
    public String getVersion() {
        return "1.0";
    } //getVersion
    
    
    public String getVendorString() {
        return "Monsanto Company";
    } //getVendorString
    
}
