/*
 * IBiotechManuscript.java
 *
 * Created on June 23, 2006, 5:20 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.biotech;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 *
 * @author tsvedan
 */
public interface IBiotechManuscript extends IDfBusinessObject {
    
}
