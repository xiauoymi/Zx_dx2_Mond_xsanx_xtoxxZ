package com.monsanto.wam.ws.service.impl;

import com.monsanto.wam.ws.client.ProvisioningService;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.ApplicationPropertiesHelper;
import com.monsanto.wam.ws.service.WamServiceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.namespace.QName;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by ivert on 22/10/2014.
 */
@Component
public class WamServiceFactoryImpl implements WamServiceFactory {

    public static final String URL = "provisioning.url";
    public static final String QNAME_NAMESPACEURI = "provisioning.qname.namespace.uri";
    public static final String QNAME_LOCALPART = "provisioning.qname.namespace.localpart";

    private ApplicationPropertiesHelper applicationPropertiesHelper;

    @Autowired
    public WamServiceFactoryImpl(ApplicationPropertiesHelper applicationPropertiesHelper) {
        this.applicationPropertiesHelper = applicationPropertiesHelper;
    }

    @Override
    public ProvisioningService getWamService() throws WamHandlerException {
        try {
            return new ProvisioningService(getUrl(), getQName());
        } catch (MalformedURLException e) {
            throw new WamHandlerException("An error occurred generating the Service", e);
        }
    }

    private QName getQName() throws WamHandlerException {
        return new QName(applicationPropertiesHelper.getApplicationProperty(QNAME_NAMESPACEURI),
                applicationPropertiesHelper.getApplicationProperty(QNAME_LOCALPART));
    }

    private URL getUrl() throws MalformedURLException, WamHandlerException {
        return new URL(applicationPropertiesHelper.getApplicationProperty(URL));
    }
}
