package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.ProvisioningService;
import com.monsanto.wam.ws.exception.WamHandlerException;

import java.net.MalformedURLException;

/**
 * Created by ivert on 22/10/2014.
 */
public interface WamServiceFactory {

    ProvisioningService getWamService() throws WamHandlerException;
}
