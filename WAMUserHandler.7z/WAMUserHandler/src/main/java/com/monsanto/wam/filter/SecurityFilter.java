package com.monsanto.wam.filter;

import com.monsanto.wam.util.LocalServiceAuthenticationUtil;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author JPBENI
 */
public class SecurityFilter implements Filter {
    private LocalServiceAuthenticationUtil serviceAuthenticationUtil;

    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String user = ((HttpServletRequest)req).getHeader("user");
        String pass = ((HttpServletRequest)req).getHeader("password");
        if (serviceAuthenticationUtil.isValid(user, pass))
            chain.doFilter(req, resp);
        else
            ((HttpServletResponse)resp).sendError(HttpServletResponse.SC_FORBIDDEN);
    }

    public void init(FilterConfig config) throws ServletException {
        this.serviceAuthenticationUtil = new LocalServiceAuthenticationUtil();
    }

}
