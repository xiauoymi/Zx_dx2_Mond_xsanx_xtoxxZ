package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.AdminException;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;

/**
 * Created by IVERT on 07/10/2014.
 */
public interface WamUserService {

    String createUser(WamUser wamUser) throws WamHandlerException;

    String grantRole(String userId, String role) throws WamHandlerException;

    String revokeRole(String userId, String role) throws WamHandlerException;

    String modifyUser(ExistingWamUser existingWamUser) throws WamHandlerException;

    String queryUser(String userId) throws WamHandlerException;

    String sendTemplate(String userId, String template) throws WamHandlerException;
}
