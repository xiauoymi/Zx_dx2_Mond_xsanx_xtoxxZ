package com.monsanto.wam.ws.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.monsanto.wam.ws.callback.WamCallback;
import com.monsanto.wam.ws.service.beans.QueryResult;
import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Created by ivert on 16/10/2014.
 */
@Controller
public class WamRestController {

    protected static final Logger LOG = Logger.getLogger(WamRestController.class);

    public static final String OK = "OK";
    private ObjectMapper objectMapper;

    private WamCallback wamCallback;

    public WamRestController(WamCallback wamCallback) {
        objectMapper = new ObjectMapper();
        this.wamCallback = wamCallback;
    }

    @RequestMapping(value="/API/userCreated", method = RequestMethod.POST)
    @ResponseBody
    public String newUser(@RequestParam final String transactionNumber, @RequestParam final String userId)
            throws JsonProcessingException {
        LOG.debug("new User has been invoke with transactionNumber: " + transactionNumber);
        wamCallback.newUserId(transactionNumber, userId);
        return objectMapper.writeValueAsString(OK);
    }

    @RequestMapping(value="/API/role", method = RequestMethod.POST)
    @ResponseBody
    public String grantedRevoked(@RequestParam final String userId, @RequestParam final boolean result)
            throws JsonProcessingException {
        wamCallback.grantedRevoked(userId, result);
        return objectMapper.writeValueAsString(OK);
    }

    @RequestMapping(value="/API/user", method = RequestMethod.POST)
    @ResponseBody
    public String userModified(@RequestParam final String userId, @RequestParam final boolean result)
            throws JsonProcessingException {
        wamCallback.userModified(userId, result);
        return objectMapper.writeValueAsString(OK);
    }

    @RequestMapping(value="/API/template", method = RequestMethod.POST)
    @ResponseBody
    public String templateSent(@RequestParam final String userId, @RequestParam final boolean result)
            throws JsonProcessingException {
        wamCallback.templateSent(userId, result);
        return objectMapper.writeValueAsString(OK);
    }

    @RequestMapping(value="/API/query", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String queryUser(@RequestParam final String userId, @RequestBody final QueryResult result)
            throws JsonProcessingException {
        wamCallback.queryUser(userId, result);
        return objectMapper.writeValueAsString(OK);
    }

}
