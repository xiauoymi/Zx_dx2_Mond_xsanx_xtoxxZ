package com.monsanto.wam.ws.service.impl;

import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.ApplicationPropertiesHelper;
import com.monsanto.wam.util.BundleUtil;
import org.springframework.stereotype.Component;

/**
 * Created by ivert on 22/10/2014.
 */
@Component
public class ApplicationPropertyHelperImpl implements ApplicationPropertiesHelper {

    public ApplicationPropertyHelperImpl() {
    }

    @Override
    public String getApplicationProperty(String key) throws WamHandlerException {
        return BundleUtil.getApplicationProperty(key);
    }
}
