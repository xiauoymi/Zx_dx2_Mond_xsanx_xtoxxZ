package com.monsanto.wam.ws.service.beans;

/**
 * Created by IVERT on 12/11/2014.
 */
public class ExistingWamUser {

    private String userId;

    private String firstName;

    private String lastName;

    private String email;

    private String lockedByIntruder;

    private String loginDisabled;

    private String monPartyID;

    private String monUserType;

    private String title;


    public ExistingWamUser(String userId) {
        this.userId = userId;
        firstName = "";
        lastName = "";
        email = "";
        lockedByIntruder = "";
        loginDisabled = "";
        monPartyID = "";
        monUserType = "";
        title = "";
    }

    public String getUserId() {
        return userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLockedByIntruder() {
        return lockedByIntruder;
    }

    public void setLockedByIntruder(String lockedByIntruder) {
        this.lockedByIntruder = lockedByIntruder;
    }

    public String getLoginDisabled() {
        return loginDisabled;
    }

    public void setLoginDisabled(String loginDisabled) {
        this.loginDisabled = loginDisabled;
    }

    public String getMonPartyID() {
        return monPartyID;
    }

    public void setMonPartyID(String monPartyID) {
        this.monPartyID = monPartyID;
    }

    public String getMonUserType() {
        return monUserType;
    }

    public void setMonUserType(String monUserType) {
        this.monUserType = monUserType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
