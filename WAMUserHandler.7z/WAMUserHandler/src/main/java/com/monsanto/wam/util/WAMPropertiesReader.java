package com.monsanto.wam.util;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @author JPBENI
 */
public class WAMPropertiesReader {

    private static final String PROPERTY_FILE = "wamApplication" ;
    private ResourceBundle resourceBundle;

    public String getEnvironmentSpecificProperty(String property) {
        String envSpecificProperty = null;
        try {
            envSpecificProperty = EnvironmentHelper.getPropertyPrefix() + property;
            resourceBundle = ResourceBundle.getBundle(PROPERTY_FILE);
            return resourceBundle.getString(envSpecificProperty);
        } catch (EnvironmentHelperException e) {
            throw new RuntimeException(getErrorMessage(PROPERTY_FILE, property), e);
        } catch (MissingResourceException e) {
            throw new RuntimeException(getErrorMessage(PROPERTY_FILE, envSpecificProperty), e);
        }
    }

    private static String getErrorMessage(String propertyFile, String envSpecificProperty) {
        return "Error reading property: '"+ envSpecificProperty +"', from property file: '"+ propertyFile +"'";
    }
}