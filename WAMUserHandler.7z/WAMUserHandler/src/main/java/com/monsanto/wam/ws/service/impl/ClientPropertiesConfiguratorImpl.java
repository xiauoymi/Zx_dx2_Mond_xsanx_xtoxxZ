package com.monsanto.wam.ws.service.impl;

import com.monsanto.wam.ws.client.Provisioning;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.ApplicationPropertiesHelper;
import com.monsanto.wam.ws.service.ClientPropertiesConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.ws.BindingProvider;

/**
 * Created by IVERT on 11/10/2014.
 */
@Component
public class ClientPropertiesConfiguratorImpl implements ClientPropertiesConfigurator {

    private static final String USER = "provisioning.user";
    private static final String PASSWORD = "provisioning.password";
    private static final String ENDPOINT = "provisioning.endpoint";

    private ApplicationPropertiesHelper applicationPropertiesHelper;

    @Autowired
    public ClientPropertiesConfiguratorImpl(ApplicationPropertiesHelper applicationPropertiesHelper) {
        this.applicationPropertiesHelper = applicationPropertiesHelper;
    }

    @Override
    public void setProperties(Provisioning provisioning) throws WamHandlerException {
        BindingProvider bindingProvider = (BindingProvider) provisioning;
        setUsername(bindingProvider, applicationPropertiesHelper.getApplicationProperty(USER));
        setPassword(bindingProvider, applicationPropertiesHelper.getApplicationProperty(PASSWORD));
        setEndpoint(bindingProvider, applicationPropertiesHelper.getApplicationProperty(ENDPOINT));
    }

    private void setEndpoint(BindingProvider bindingProvider, String endpoint) {
        bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
    }

    private void setPassword(BindingProvider bindingProvider, String password) {
        bindingProvider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);
    }

    private void setUsername(BindingProvider bindingProvider, String user) {
        bindingProvider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, user);
    }

}
