
package com.monsanto.wam.ws.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for t_entitlementState.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="t_entitlementState">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unknown"/>
 *     &lt;enumeration value="Granted"/>
 *     &lt;enumeration value="Revoked"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "t_entitlementState")
@XmlEnum
public enum TEntitlementState {

    @XmlEnumValue("Unknown")
    UNKNOWN("Unknown"),
    @XmlEnumValue("Granted")
    GRANTED("Granted"),
    @XmlEnumValue("Revoked")
    REVOKED("Revoked");
    private final String value;

    TEntitlementState(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TEntitlementState fromValue(String v) {
        for (TEntitlementState c: TEntitlementState.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
