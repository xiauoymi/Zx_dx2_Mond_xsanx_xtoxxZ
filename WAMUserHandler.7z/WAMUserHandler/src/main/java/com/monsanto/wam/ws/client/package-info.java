@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.novell.com/provisioning/service", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.wam.ws.client;
