package com.monsanto.wam.ws.service.beans;

/**
 * Created by IVERT on 11/10/2014.
 */
public class WamUser {

    private String firstName;

    private String initialSecondName;

    private String lastName;

    private String email;

    public WamUser(String firstName, String initialSecondName, String lastName, String email) {
        this.firstName = firstName;
        this.initialSecondName = initialSecondName;
        this.lastName = lastName;
        this.email = email;
    }

    public WamUser(String firstName, String lastName, String email) {
        this(firstName, "", lastName, email);
    }

    public String getFirstName() {
        return firstName;
    }

    public String getInitialSecondName() {
        return initialSecondName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }
}
