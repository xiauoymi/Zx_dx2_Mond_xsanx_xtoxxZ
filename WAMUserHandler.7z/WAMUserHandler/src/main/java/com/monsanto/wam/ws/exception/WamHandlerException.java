package com.monsanto.wam.ws.exception;

/**
 * Created by IVERT on 12/10/2014.
 */
public class WamHandlerException extends Exception {

    public WamHandlerException(String message, Throwable e){
        super(message, e);
    }
}
