
package com.monsanto.wam.ws.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for forwardAsProxyWithDigitalSignatureRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="forwardAsProxyWithDigitalSignatureRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arg0" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.novell.com/provisioning/service}Action"/>
 *         &lt;element name="arg2" type="{http://www.novell.com/provisioning/service}DataItemArray" minOccurs="0"/>
 *         &lt;element name="arg3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="arg4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="arg5" type="{http://www.novell.com/provisioning/service}SignaturePropertyArray" minOccurs="0"/>
 *         &lt;element name="arg6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "forwardAsProxyWithDigitalSignatureRequest", propOrder = {
    "arg0",
    "action",
    "arg2",
    "arg3",
    "arg4",
    "arg5",
    "arg6"
})
public class ForwardAsProxyWithDigitalSignatureRequest {

    @XmlElementRef(name = "arg0", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<String> arg0;
    @XmlElement(name = "Action", required = true)
    protected TAction action;
    @XmlElementRef(name = "arg2", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<DataItemArray> arg2;
    @XmlElementRef(name = "arg3", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<String> arg3;
    @XmlElementRef(name = "arg4", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<String> arg4;
    @XmlElementRef(name = "arg5", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<SignaturePropertyArray> arg5;
    @XmlElementRef(name = "arg6", namespace = "http://www.novell.com/provisioning/service", type = JAXBElement.class)
    protected JAXBElement<String> arg6;

    /**
     * Gets the value of the arg0 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getArg0() {
        return arg0;
    }

    /**
     * Sets the value of the arg0 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setArg0(JAXBElement<String> value) {
        this.arg0 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link TAction }
     *     
     */
    public TAction getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link TAction }
     *     
     */
    public void setAction(TAction value) {
        this.action = value;
    }

    /**
     * Gets the value of the arg2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DataItemArray }{@code >}
     *     
     */
    public JAXBElement<DataItemArray> getArg2() {
        return arg2;
    }

    /**
     * Sets the value of the arg2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DataItemArray }{@code >}
     *     
     */
    public void setArg2(JAXBElement<DataItemArray> value) {
        this.arg2 = ((JAXBElement<DataItemArray> ) value);
    }

    /**
     * Gets the value of the arg3 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getArg3() {
        return arg3;
    }

    /**
     * Sets the value of the arg3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setArg3(JAXBElement<String> value) {
        this.arg3 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the arg4 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getArg4() {
        return arg4;
    }

    /**
     * Sets the value of the arg4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setArg4(JAXBElement<String> value) {
        this.arg4 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the arg5 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SignaturePropertyArray }{@code >}
     *     
     */
    public JAXBElement<SignaturePropertyArray> getArg5() {
        return arg5;
    }

    /**
     * Sets the value of the arg5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SignaturePropertyArray }{@code >}
     *     
     */
    public void setArg5(JAXBElement<SignaturePropertyArray> value) {
        this.arg5 = ((JAXBElement<SignaturePropertyArray> ) value);
    }

    /**
     * Gets the value of the arg6 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getArg6() {
        return arg6;
    }

    /**
     * Sets the value of the arg6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setArg6(JAXBElement<String> value) {
        this.arg6 = ((JAXBElement<String> ) value);
    }

}
