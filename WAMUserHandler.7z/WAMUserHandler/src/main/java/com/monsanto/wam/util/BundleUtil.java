package com.monsanto.wam.util;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.wam.ws.exception.WamHandlerException;

import java.text.MessageFormat;
import java.util.ResourceBundle;

/**
 * Created by IVERT on 12/10/2014.
 */
public class BundleUtil {


    public static final String WAM_APPLICATION = "wamApplication";

    /**
     * Returns the text with the corresponding key in the {@link java.util.ResourceBundle}
     *
     * @param resource {@link java.util.ResourceBundle}
     * @param key key to the text
     * @param arguments arguments that replace the wildcards in the text.
     * @return Text
     */
    public static String getMessage(ResourceBundle resource, String key, Object... arguments) {

        String message = null;
        String keyValue = resource.getString(key);

        if (keyValue != null) {
            message = MessageFormat.format(keyValue, arguments);
        }
        return message;
    }

    /**
     * Returns the text with the corresponding key in the {@link ResourceBundle}
     *
     * @param key key to the text
     * @return Text
     */
    public static String getApplicationProperty(String key) throws WamHandlerException {

        String envSpecificProperty = null;

        try {
            envSpecificProperty = EnvironmentHelper.getPropertyPrefix() + key;

            return getMessage(getResource(WAM_APPLICATION), envSpecificProperty);
        } catch (EnvironmentHelperException e) {
            throw new WamHandlerException(getErrorMessage(WAM_APPLICATION, envSpecificProperty), e);
        }
    }

    public static ResourceBundle getResource(String resourceName) {
        return ResourceBundle.getBundle(resourceName);
    }

    /**
     * Gets the message error
     *
     * @param propertyFile property file
     * @param envSpecificProperty env specific property
     * @return property value
     */
    private static String getErrorMessage(String propertyFile, String envSpecificProperty) {

        return "Error reading property: '" + envSpecificProperty + "', from property file: '" + propertyFile + "'";
    }

}
