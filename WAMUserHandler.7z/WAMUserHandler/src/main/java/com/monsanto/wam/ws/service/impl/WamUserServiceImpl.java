package com.monsanto.wam.ws.service.impl;


import com.monsanto.wam.ws.client.AdminException_Exception;
import com.monsanto.wam.ws.client.StartRequest;
import com.monsanto.wam.ws.client.StartResponse;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.StartRequestFactory;
import com.monsanto.wam.ws.service.WamUserService;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by IVERT on 07/10/2014.
 */
@Component
public class WamUserServiceImpl implements WamUserService {

    private static final Logger LOG = LoggerFactory.getLogger(WamUserServiceImpl.class);

    private WamClientFactoryImpl wamClientFactory;

    private StartRequestFactory startRequestFactory;

    @Autowired
    public WamUserServiceImpl(WamClientFactoryImpl wamClientFactory, StartRequestFactory startRequestFactory) {
        this.wamClientFactory = wamClientFactory;
        this.startRequestFactory = startRequestFactory;
    }

    @Override
    public String createUser(WamUser wamUser) throws WamHandlerException {
        LOG.debug("Requesting new User to WAM: " + wamUser.getLastName());
        return invokeStartMethod(startRequestFactory.createUserStartRequest(wamUser));
    }

    @Override
    public String grantRole(String userId, String role) throws WamHandlerException {
        LOG.debug("Requesting grant of role: <" + role + "> for user: " + userId);
        return invokeStartMethod(startRequestFactory.grantRoleStartRequest(userId, role));
    }

    @Override
    public String revokeRole(String userId, String role) throws WamHandlerException {
        LOG.debug("Requesting revoke of role: <" + role + "> for user: " + userId);
        return invokeStartMethod(startRequestFactory.revokeRoleStartRequest(userId, role));
    }

    @Override
    public String modifyUser(ExistingWamUser existingWamUser) throws WamHandlerException {
        LOG.debug("Requesting modification for: " + existingWamUser.getUserId());
        return invokeStartMethod(startRequestFactory.modifyUserStartRequest(existingWamUser));
    }

    @Override
    public String queryUser(String userId) throws WamHandlerException {
        LOG.debug("Requesting information of: " + userId);
        return invokeStartMethod(startRequestFactory.queryUserStartRequest(userId));
    }

    @Override
    public String sendTemplate(String userId, String template) throws WamHandlerException {
        LOG.debug("Requesting template: <" + template + "> be sent to user: " + userId);
        return invokeStartMethod(startRequestFactory.sendTemplateStartRequest(userId, template));
    }

    private String invokeStartMethod(StartRequest startRequest) throws WamHandlerException {
        try {
            StartResponse startResponse = wamClientFactory.getWamServiceClient().start(startRequest);
            return startResponse.getResult().getValue();
        } catch (AdminException_Exception e) {
            throw new WamHandlerException("An error occurred invoking the method start", e);
        }
    }

}
