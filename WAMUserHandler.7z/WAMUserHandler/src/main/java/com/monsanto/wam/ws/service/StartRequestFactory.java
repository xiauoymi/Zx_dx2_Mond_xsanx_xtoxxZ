package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.StartRequest;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;

/**
 * Created by IVERT on 11/10/2014.
 */
public interface StartRequestFactory {

    StartRequest createUserStartRequest(WamUser wamUser);

    StartRequest grantRoleStartRequest(String userId, String role);

    StartRequest revokeRoleStartRequest(String userId, String role);

    StartRequest modifyUserStartRequest(ExistingWamUser existingWamUser);

    StartRequest queryUserStartRequest(String userId);

    StartRequest sendTemplateStartRequest(String userId, String template);
}
