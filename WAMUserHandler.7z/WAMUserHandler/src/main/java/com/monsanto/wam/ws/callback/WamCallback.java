package com.monsanto.wam.ws.callback;

import com.monsanto.wam.ws.service.beans.QueryResult;

/**
 * Created by ivert on 21/10/2014.
 */
public interface WamCallback {

    void newUserId(String transactionNumber, String userId);

    void grantedRevoked(String userId, boolean result);

    void userModified(String userId, boolean result);

    void templateSent(String userId, boolean result);

    void queryUser(String userId, QueryResult result);
}
