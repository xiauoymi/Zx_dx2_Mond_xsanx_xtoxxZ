package com.monsanto.wam.ws.callback.impl;

import com.monsanto.wam.ws.callback.WamCallback;
import com.monsanto.wam.ws.service.beans.QueryResult;
import org.springframework.stereotype.Component;

/**
 * Created by IVERT on 30/10/2014.
 */
@Component
public class DummyWamCallback implements WamCallback {

    @Override
    public void newUserId(String transactionNumber, String userId) {
        System.out.println("newUserId");
    }

    @Override
    public void grantedRevoked(String transactionNumber, boolean userId) {
        System.out.println("grantedRevoked");
    }

    @Override
    public void userModified(String userId, boolean result) {
        System.out.println("userModified");
    }

    @Override
    public void templateSent(String userId, boolean result) {
        System.out.println("templateSent");
    }

    @Override
    public void queryUser(String userId, QueryResult result) {
        System.out.println("queryUser");
    }
}
