package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.exception.WamHandlerException;

/**
 * Created by ivert on 22/10/2014.
 */
public interface ApplicationPropertiesHelper {

    String getApplicationProperty(String key) throws WamHandlerException;

}
