package com.monsanto.wam.ws.service.impl;

import com.monsanto.wam.ws.client.*;
import com.monsanto.wam.ws.service.StartRequestFactory;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBElement;

/**
 * Created by IVERT on 12/10/2014.
 */
@Component
public class StartRequestFactoryImpl implements StartRequestFactory {

    public static final String ZERO_ARG_USER_ACCOUNT_CREATE = "cn=User Account Create,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO";
    public static final String FIRST_NAME = "firstName";
    public static final String MIDDLE_INITIAL = "middleInitial";
    public static final String LAST_NAME = "lastName";
    public static final String E_MAIL = "emailAddress";

    public static final String ZERO_ARG_GRANT_REVOKE_ROLE = "cn=Grant or Revoke Role,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO";
    public static final String USER_ID = "userID";
    public static final String ROLE = "role";
    public static final String ACTION = "action";
    public static final String ACTION_GRANT = "GRANT";
    public static final String ACTION_REVOKE = "REVOKE";

    public static final String ZERO_ARG_MODIFY_USER = "cn=Modify User Account,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO";
    public static final String LOCKED_BY_INTRUDER = "lockedByIntruder";
    public static final String LOGIN_DISABLED = "loginDisabled";
    public static final String MON_PARTY_ID = "monPartyID";
    public static final String MON_USER_TYPE = "monUserType";
    public static final String TITLE = "title";

    public static final String ZERO_ARG_QUERY_USER = "cn=Query User Account,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO";

    public static final String ZERO_ARG_SEND_TEMPLATE = "cn=Send E-mail Templates,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO";
    public static final String TEMPLATE = "templateName";

    private ObjectFactory objectFactory;

    public StartRequestFactoryImpl() {
        objectFactory = new ObjectFactory();
    }

    @Override
    public StartRequest createUserStartRequest(WamUser wamUser) {
        return getStartRequest(createArg2ForNewUser(wamUser), ZERO_ARG_USER_ACCOUNT_CREATE);
    }

    @Override
    public StartRequest grantRoleStartRequest(String userId, String role) {
        return getStartRequest(createArg2ForGrant(userId, role), ZERO_ARG_GRANT_REVOKE_ROLE);
    }

    @Override
    public StartRequest revokeRoleStartRequest(String userId, String role) {
        return getStartRequest(createArg2ForRevoke(userId, role), ZERO_ARG_GRANT_REVOKE_ROLE);
    }

    @Override
    public StartRequest modifyUserStartRequest(ExistingWamUser existingWamUser) {
        return getStartRequest(createArg2ForModify(existingWamUser), ZERO_ARG_MODIFY_USER);
    }

    @Override
    public StartRequest queryUserStartRequest(String userId) {
        return getStartRequest(createArg2ForQuery(userId), ZERO_ARG_QUERY_USER);
    }

    @Override
    public StartRequest sendTemplateStartRequest(String userId, String template) {
        return getStartRequest(createArg2ForTemplate(userId, template), ZERO_ARG_SEND_TEMPLATE);
    }

    private StartRequest getStartRequest(JAXBElement<DataItemArray> arg2, String zeroArg) {
        StartRequest startRequest = objectFactory.createStartRequest();
        startRequest.setArg0(createArg0(zeroArg));
        startRequest.setArg1(createArg1());
        startRequest.setArg2(arg2);
        return startRequest;
    }

    private JAXBElement<String> createArg0(String zeroArg) {
        return objectFactory.createStartRequestArg0(zeroArg);
    }

    private JAXBElement<String> createArg1() {
        return objectFactory.createStartRequestArg1("");
    }

    private JAXBElement<DataItemArray> createArg2ForNewUser(WamUser wamUser) {
        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        addItemToArray(dataItemArray, FIRST_NAME, wamUser.getFirstName());
        addItemToArray(dataItemArray, MIDDLE_INITIAL, wamUser.getInitialSecondName());
        addItemToArray(dataItemArray, LAST_NAME, wamUser.getLastName());
        addItemToArray(dataItemArray, E_MAIL, wamUser.getEmail());
        return objectFactory.createStartRequestArg2(dataItemArray);
    }

    private JAXBElement<DataItemArray> createArg2ForGrant(String userId, String role) {
        return createArg2ForGrantRevoke(userId, role, ACTION_GRANT);
    }

    private JAXBElement<DataItemArray> createArg2ForRevoke(String userId, String role) {
        return createArg2ForGrantRevoke(userId, role, ACTION_REVOKE);
    }

    private JAXBElement<DataItemArray> createArg2ForGrantRevoke(String userId, String role, String action) {
        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        addItemToArray(dataItemArray, ACTION, action);
        addItemToArray(dataItemArray, USER_ID, userId);
        addItemToArray(dataItemArray, ROLE, role);
        return objectFactory.createStartRequestArg2(dataItemArray);
    }

    private JAXBElement<DataItemArray> createArg2ForTemplate(String userId, String template) {
        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        addItemToArray(dataItemArray, USER_ID, userId);
        addItemToArray(dataItemArray, TEMPLATE, template);
        return objectFactory.createStartRequestArg2(dataItemArray);
    }

    private JAXBElement<DataItemArray> createArg2ForQuery(String userId) {
        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        addItemToArray(dataItemArray, USER_ID, userId);
        return objectFactory.createStartRequestArg2(dataItemArray);
    }

    private JAXBElement<DataItemArray> createArg2ForModify(ExistingWamUser existingWamUser) {
        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        addItemToArray(dataItemArray, USER_ID, existingWamUser.getUserId());
        addItemToArray(dataItemArray, FIRST_NAME, existingWamUser.getFirstName());
        addItemToArray(dataItemArray, LAST_NAME, existingWamUser.getLastName());
        addItemToArray(dataItemArray, E_MAIL, existingWamUser.getEmail());
        addItemToArray(dataItemArray, LOCKED_BY_INTRUDER, existingWamUser.getLockedByIntruder());
        addItemToArray(dataItemArray, LOGIN_DISABLED, existingWamUser.getLoginDisabled());
        addItemToArray(dataItemArray, MON_PARTY_ID, existingWamUser.getMonPartyID());
        addItemToArray(dataItemArray, MON_USER_TYPE, existingWamUser.getMonUserType());
        addItemToArray(dataItemArray, TITLE, existingWamUser.getTitle());
        return objectFactory.createStartRequestArg2(dataItemArray);
    }

    private void addItemToArray(DataItemArray dataItemArray, String key, String value) {
        dataItemArray.getDataitem().add(createDataItem(key, value));
    }

    private DataItem createDataItem(String name, String value){
        DataItem dataItem = objectFactory.createDataItem();
        dataItem.setName(name);
        StringArray stringArray = objectFactory.createStringArray();
        stringArray.getString().add(value);
        dataItem.setValue(stringArray);
        return dataItem;
    }
}
