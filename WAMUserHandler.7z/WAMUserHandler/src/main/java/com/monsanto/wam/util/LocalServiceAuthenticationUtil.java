package com.monsanto.wam.util;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author JPBENI
 */
public class LocalServiceAuthenticationUtil {
    private static final Logger LOG = LoggerFactory.getLogger(LocalServiceAuthenticationUtil.class);

    public static final String USERNAME_KEY = "wamUser";
    public static final String ENV_VARIABLE = "MONCRYPTJV";
    public static final String APP_FOLDER_NAME = "appFolderName";
    public static final String ENCRYPTED_PASSWORD_FILE = "encryptedPasswordFile";
    public static final String KEY_FILE = "keyFile";
    private String userName;
    private String password;
    private WAMPropertiesReader reader;

    public LocalServiceAuthenticationUtil() {
        try {
            LOG.info("Loading WAM credentials...");
            this.reader = new WAMPropertiesReader();
            String appName = getEnvironmentSpecificProperty(APP_FOLDER_NAME);
            String inEncryptedValueFileName = getEnvironmentSpecificProperty(ENCRYPTED_PASSWORD_FILE);
            String inKeyFileName = getEnvironmentSpecificProperty(KEY_FILE);
            this.password = EncryptionUtils.GetDecryptedStringFromExternalStorage(ENV_VARIABLE, appName,
                    inEncryptedValueFileName, inKeyFileName);
            this.userName = getEnvironmentSpecificProperty(USERNAME_KEY);
        } catch (Exception ex) {
            LOG.error("There was an error loading WAM credentials: ", ex);
            throw new RuntimeException("There was an unexpected error loading credentials: ", ex);
        }
        LOG.info("WAM credentials loaded successfully.");
    }

    public boolean isValid(final String userName, final String password) {
        if (this.userName.equals(userName) && this.password.equals(password)) {
            return true;
        }
        LOG.debug("Invalid WAM credentials: usr={}, pass={}", userName, password);
        return false;
    }

    private String getEnvironmentSpecificProperty(String property) {
        return this.reader.getEnvironmentSpecificProperty(property);
    }
}
