package com.monsanto.wam.ws.service.impl;


import com.monsanto.wam.ws.client.Provisioning;
import com.monsanto.wam.ws.client.ProvisioningService;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.ClientPropertiesConfigurator;
import com.monsanto.wam.ws.service.WamClientFactory;
import com.monsanto.wam.ws.service.WamServiceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WamClientFactoryImpl implements WamClientFactory {

    private ProvisioningService provisioningService;

    private ClientPropertiesConfigurator clientPropertiesConfigurator;

    @Autowired
    public WamClientFactoryImpl(WamServiceFactory wamServiceFactory, ClientPropertiesConfigurator clientPropertiesConfigurator) throws WamHandlerException {
        this.provisioningService = wamServiceFactory.getWamService();
        this.clientPropertiesConfigurator = clientPropertiesConfigurator;
    }

    /**
     * Gets the WAM Service Client
     * @return {@link com.monsanto.wam.ws.client.Provisioning}
     * @throws Exception
     */
    @Override
    public Provisioning getWamServiceClient() throws WamHandlerException {
        Provisioning provisioning = provisioningService.getProvisioningPort();
        clientPropertiesConfigurator.setProperties(provisioning);

        return provisioning;
    }

}