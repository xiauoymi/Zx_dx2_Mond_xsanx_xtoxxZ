package com.monsanto.wam.ws.service.beans;

/**
 * Created by IVERT on 11/10/2014.
 */
public class ClientProperties {

    private String user;

    private String password;

    private String endpoint;

    public ClientProperties(String user, String password, String endpoint) {
        this.user = user;
        this.password = password;
        this.endpoint = endpoint;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getEndpoint() {
        return endpoint;
    }

}
