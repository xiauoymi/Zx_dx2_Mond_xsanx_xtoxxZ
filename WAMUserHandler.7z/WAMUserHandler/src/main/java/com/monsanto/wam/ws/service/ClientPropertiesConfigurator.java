package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.Provisioning;
import com.monsanto.wam.ws.exception.WamHandlerException;

/**
 * Created by IVERT on 11/10/2014.
 */
public interface ClientPropertiesConfigurator {

    void setProperties(Provisioning provisioning) throws WamHandlerException;

}
