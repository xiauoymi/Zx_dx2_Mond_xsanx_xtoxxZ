package com.monsanto.wam.ws.service.beans;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by IVERT on 30/12/2014.
 */
public class QueryResult {

    @JsonProperty
    private String firstName;

    @JsonProperty
    private String lastName;

    @JsonProperty
    private String emailAddress;

    @JsonProperty
    private String department;

    @JsonProperty
    private String description;

    @JsonProperty
    private String lockedByIntruder;

    @JsonProperty
    private String loginDisabled;

    @JsonProperty
    private String monAccountType;

    @JsonProperty
    private String monExternalApplication;

    @JsonProperty
    private String monPartyId;

    @JsonProperty
    private String monSapId;

    @JsonProperty
    private String monUserType;

    @JsonProperty
    private String title;

    public QueryResult() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLockedByIntruder() {
        return lockedByIntruder;
    }

    public void setLockedByIntruder(String lockedByIntruder) {
        this.lockedByIntruder = lockedByIntruder;
    }

    public String getLoginDisabled() {
        return loginDisabled;
    }

    public void setLoginDisabled(String loginDisabled) {
        this.loginDisabled = loginDisabled;
    }

    public String getMonAccountType() {
        return monAccountType;
    }

    public void setMonAccountType(String monAccountType) {
        this.monAccountType = monAccountType;
    }

    public String getMonExternalApplication() {
        return monExternalApplication;
    }

    public void setMonExternalApplication(String monExternalApplication) {
        this.monExternalApplication = monExternalApplication;
    }

    public String getMonPartyId() {
        return monPartyId;
    }

    public void setMonPartyId(String monPartyId) {
        this.monPartyId = monPartyId;
    }

    public String getMonSapId() {
        return monSapId;
    }

    public void setMonSapId(String monSapId) {
        this.monSapId = monSapId;
    }

    public String getMonUserType() {
        return monUserType;
    }

    public void setMonUserType(String monUserType) {
        this.monUserType = monUserType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
