package com.monsanto.wam.service;

import com.monsanto.wam.ws.client.*;
import org.junit.Before;
import org.junit.Test;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import java.net.URL;

/**
 * Created by IVERT on 09/10/2014.
 */
public class WsTest {

    ObjectFactory objectFactory = new ObjectFactory();
    private Provisioning provisioningPort;

    @Before
    public void setUp() throws Exception {
        System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
        System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
        System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
        System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");

        URL baseUrl = new URL("http://test.idmprovx.monsanto.com/IDMProv/provisioning/service");
        URL url = new URL(baseUrl, "http://test.idmprovx.monsanto.com/IDMProv/provisioning/service?wsdl");
        QName serviceName = new QName("http://www.novell.com/provisioning/service", "ProvisioningService");
        ProvisioningService provisioningService = new ProvisioningService(url, serviceName);
        provisioningPort = provisioningService.getProvisioningPort();

        BindingProvider bindingProvider = (BindingProvider) provisioningPort;
        bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://test.idmprovx.monsanto.com/IDMProv/provisioning/service");
        bindingProvider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, "cn=WebServices-GlobalBarter,ou=SA,ou=SERVICES,o=MONSANTO");
        bindingProvider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, "IDMWebServicesGB1");
    }

    @Test
    public void createUser() throws Exception {

        StartRequest startRequest = getStartRequestCreateUser();

        StartResponse startResponse = provisioningPort.start(startRequest);
    }

    @Test
    public void queryUser() throws Exception {

        StartRequest startRequest = getStartRequestQueryUser();

        StartResponse startResponse = provisioningPort.start(startRequest);

    }

    private StartRequest getStartRequestQueryUser() {

        StartRequest startRequest = objectFactory.createStartRequest();

        JAXBElement<String> startRequestArg0 =
                objectFactory.createStartRequestArg0("cn=Query User Account,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO");
        startRequest.setArg0(startRequestArg0);

        startRequest.setArg1(objectFactory.createStartRequestArg1(""));

        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        dataItemArray.getDataitem().add(createDataItem("userID", "ILVERT_T"));
        JAXBElement<DataItemArray> dataItemArrayJAXBElement = objectFactory.createStartRequestArg2(dataItemArray);
        startRequest.setArg2(dataItemArrayJAXBElement);
        return startRequest;
    }

    private StartRequest getStartRequestCreateUser() {

        StartRequest startRequest = objectFactory.createStartRequest();

        JAXBElement<String> startRequestArg0 =
                objectFactory.createStartRequestArg0("cn=User Account Create,cn=RequestDefs,cn=AppConfig,cn=USERAPP-01,cn=DRVSET1,ou=IDM,ou=SERVICES,o=MONSANTO");
        startRequest.setArg0(startRequestArg0);

        startRequest.setArg1(objectFactory.createStartRequestArg1(""));

        DataItemArray dataItemArray = objectFactory.createDataItemArray();
        dataItemArray.getDataitem().add(createDataItem("firstName", "John"));
        dataItemArray.getDataitem().add(createDataItem("middleInitial", "P"));
        dataItemArray.getDataitem().add(createDataItem("lastName", "Benitez"));
        dataItemArray.getDataitem().add(createDataItem("emailAddress", "ignacio.vertiz@monsanto.com"));
        JAXBElement<DataItemArray> dataItemArrayJAXBElement = objectFactory.createStartRequestArg2(dataItemArray);
        startRequest.setArg2(dataItemArrayJAXBElement);
        return startRequest;
    }

    private DataItem createDataItem(String name, String value){
        DataItem dataItem = objectFactory.createDataItem();
        dataItem.setName(name);
        StringArray stringArray = objectFactory.createStringArray();
        stringArray.getString().add(value);
        dataItem.setValue(stringArray);
        return dataItem;
    }

}
