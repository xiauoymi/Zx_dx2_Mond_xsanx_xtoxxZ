package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.*;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;
import com.monsanto.wam.ws.service.impl.WamClientFactoryImpl;
import com.monsanto.wam.ws.service.impl.WamUserServiceImpl;
import org.junit.Before;
import org.junit.Test;

import javax.xml.bind.JAXBElement;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * Created by IVERT on 07/10/2014.
 */
public class WamUserService_UT {

    private static final String DUMMY_FIRST_NAME = null;
    private static final String DUMMY_SECOND_NAME = null;
    private static final String DUMMY_LAST_NAME = null;
    private static final String DUMMY_MAIL = null;
    private static final String TRANSACTION_NUMBER = "1";
    private static final String DUMMY_ROLE = "role";
    private static final String BILL = "Bill";
    private static final String TED = "Ted";
    private static final String SINGER = "Singer";
    private static final String DRUMMER = "Drummer";
    private static final String DUMMY_USER_ID = null;
    private static final String DUMMY_TEMPLATE = null;
    private static final String TEMPLATE_1 = "template1";
    private static final String TEMPLATE_2 = "template2";

    private WamUserService wamUserService;

    private Provisioning provisioning = mock(Provisioning.class);

    private WamClientFactoryImpl wamClientFactory = mock(WamClientFactoryImpl.class);

    private StartRequestFactory startRequestFactory = mock(StartRequestFactory.class);

    @Before
    public void setUp() throws WamHandlerException, AdminException_Exception {
        ObjectFactory objectFactory = new ObjectFactory();
        JAXBElement<String> value = objectFactory.createString(TRANSACTION_NUMBER);
        StartResponse startResponse = new StartResponse();
        startResponse.setResult(value);
        when(provisioning.start(any(StartRequest.class))).thenReturn(startResponse);
        when(wamClientFactory.getWamServiceClient()).thenReturn(provisioning);
        wamUserService = new WamUserServiceImpl(wamClientFactory, startRequestFactory);
    }

    @Test
    public void testStartRequestFactoryCallsCreateUserStartRequest_whenWamUserServiceCallsCreateUser() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls createUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);
        wamUserService.createUser(wamUser);

        // @Then create user should be called
        verify(startRequestFactory, times(1)).createUserStartRequest(wamUser);
    }

    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsCreateUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls createUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);
        wamUserService.createUser(wamUser);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsCreateUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.createUserStartRequest(any(WamUser.class))).thenReturn(startRequest);

        // @When calls createUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);
        wamUserService.createUser(wamUser);

        // @Then start should be called
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testCreateUserReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls createUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);
        String result = wamUserService.createUser(wamUser);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testCreateUserThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls createUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);
        try {
            wamUserService.createUser(wamUser);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

    @Test
    public void testStartRequestFactoryCallsCreateGrantStartRequest_whenWamUserServiceCallsGrantRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then grantRoleStartRequest should be called
        verify(startRequestFactory, times(1)).grantRoleStartRequest(anyString(), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateGrantStartRequestWithUserIdBill_whenWamUserServiceCallsGrantRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(BILL, DUMMY_ROLE);

        // @Then grantRoleStartRequest should be called with userId Bill
        verify(startRequestFactory, times(1)).grantRoleStartRequest(eq(BILL), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateGrantStartRequestWithUserIdTed_whenWamUserServiceCallsGrantRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(TED, DUMMY_ROLE);

        // @Then grantRoleStartRequest should be called with userId Ted
        verify(startRequestFactory, times(1)).grantRoleStartRequest(eq(TED), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateGrantStartRequestWithRoleSinger_whenWamUserServiceCallsGrantRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(DUMMY_USER_ID, SINGER);

        // @Then grantRoleStartRequest should be called with role Singer
        verify(startRequestFactory, times(1)).grantRoleStartRequest(anyString(), eq(SINGER));
    }

    @Test
    public void testStartRequestFactoryCallsCreateGrantStartRequestWithRoleDrummer_whenWamUserServiceCallsGrantRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(DUMMY_USER_ID, DRUMMER);

        // @Then grantRoleStartRequest should be called with role Drummer
        verify(startRequestFactory, times(1)).grantRoleStartRequest(anyString(), eq(DRUMMER));
    }

    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsGrantRole() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls grantRole
        wamUserService.grantRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsGrantRole() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.grantRoleStartRequest(anyString(), anyString())).thenReturn(startRequest);

        // @When calls grantRole
        wamUserService.grantRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then start should be called
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testGrantRoleReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls grantRole
        String result = wamUserService.grantRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testGrantRoleThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls grantRole
        try {
            wamUserService.grantRole(DUMMY_USER_ID, DUMMY_ROLE);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

    @Test
    public void testStartRequestFactoryCallsCreateRevokeStartRequest_whenWamUserServiceCallsRevokeRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then revokeRoleStartRequest should be called
        verify(startRequestFactory, times(1)).revokeRoleStartRequest(anyString(), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateRevokeStartRequestWithUserIdBill_whenWamUserServiceCallsRevokeRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(BILL, DUMMY_ROLE);

        // @Then revokeRoleStartRequest should be called with userId Bill
        verify(startRequestFactory, times(1)).revokeRoleStartRequest(eq(BILL), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateRevokeStartRequestWithUserIdTed_whenWamUserServiceCallsRevokeRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(TED, DUMMY_ROLE);

        // @Then revokeRoleStartRequest should be called with userId Ted
        verify(startRequestFactory, times(1)).revokeRoleStartRequest(eq(TED), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsCreateRevokeStartRequestWithRoleSinger_whenWamUserServiceCallsRevokeRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(DUMMY_USER_ID, SINGER);

        // @Then revokeRoleStartRequest should be called with role singer
        verify(startRequestFactory, times(1)).revokeRoleStartRequest(anyString(), eq(SINGER));
    }

    @Test
    public void testStartRequestFactoryCallsCreateRevokeStartRequestWithRoleDrummer_whenWamUserServiceCallsRevokeRole() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(DUMMY_USER_ID, DRUMMER);

        // @Then revokeRoleStartRequest should be called with role drummer
        verify(startRequestFactory, times(1)).revokeRoleStartRequest(anyString(), eq(DRUMMER));
    }

    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsRevokeRole() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.revokeRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsRevokeRole() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.revokeRoleStartRequest(anyString(), anyString())).thenReturn(startRequest);

        // @When calls revokeRole
        wamUserService.revokeRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then start should be called with startRequest as parameter
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testRevokeRoleReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls revokeRole
        String result = wamUserService.revokeRole(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testRevokeRoleThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls revokeRole
        try {
            wamUserService.revokeRole(DUMMY_USER_ID, DUMMY_ROLE);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

    @Test
    public void testStartRequestFactoryCallsCreateModifyStartRequest_whenWamUserServiceCallsModifyUser() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls modifyUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        wamUserService.modifyUser(existingWamUser);

        // @Then modifyUserStartRequest should be called
        verify(startRequestFactory, times(1)).modifyUserStartRequest(any(ExistingWamUser.class));
    }

    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsModifyUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls modifyUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        wamUserService.modifyUser(existingWamUser);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsModifyUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.modifyUserStartRequest(any(ExistingWamUser.class))).thenReturn(startRequest);

        // @When calls createUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        wamUserService.modifyUser(existingWamUser);

        // @Then start should be called
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testModifyUserReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls createUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        String result = wamUserService.modifyUser(existingWamUser);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testModifyUserThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls createUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        try {
            wamUserService.modifyUser(existingWamUser);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

    @Test
    public void testStartRequestFactoryCallsQueryStartRequest_whenWamUserServiceCallsQueryUser() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls revokeRole
        wamUserService.queryUser(DUMMY_USER_ID);

        // @Then revokeRoleStartRequest should be called
        verify(startRequestFactory, times(1)).queryUserStartRequest(anyString());
    }

    @Test
    public void testStartRequestFactoryCallsQueryStartRequestWithUserIdBill_whenWamUserServiceCallsQueryUser() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls queryUser
        wamUserService.queryUser(BILL);

        // @Then revokeRoleStartRequest should be called with userId Bill
        verify(startRequestFactory, times(1)).queryUserStartRequest(eq(BILL));
    }

    @Test
    public void testStartRequestFactoryCallsQueryUserStartRequestWithUserIdTed_whenWamUserServiceCallsQueryUser() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls queryUser
        wamUserService.queryUser(TED);

        // @Then revokeRoleStartRequest should be called with userId Ted
        verify(startRequestFactory, times(1)).queryUserStartRequest(eq(TED));
    }

    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsQueryUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls queryUser
        wamUserService.queryUser(DUMMY_USER_ID);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsQueryUser() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.queryUserStartRequest(anyString())).thenReturn(startRequest);

        // @When calls queryUser
        wamUserService.queryUser(DUMMY_USER_ID);

        // @Then start should be called with startRequest as parameter
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testQueryUserReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls queryUser
        String result = wamUserService.queryUser(DUMMY_USER_ID);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testQueryUserThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls revokeRole
        try {
            wamUserService.queryUser(DUMMY_USER_ID);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

    @Test
    public void testStartRequestFactoryCallsSendTemplateStartRequest_whenWamUserServiceCallsSendTemplate() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then sendTemplateStartRequest should be called
        verify(startRequestFactory, times(1)).sendTemplateStartRequest(anyString(), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsSendTemplateRequestWithUserIdBill_whenWamUserServiceCallsSendTemplate() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(BILL, DUMMY_TEMPLATE);

        // @Then sendTemplateStartRequest should be called with userId Bill
        verify(startRequestFactory, times(1)).sendTemplateStartRequest(eq(BILL), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsSendTemplateRequestWithUserIdTed_whenWamUserServiceCallsSendTemplate() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(TED, DUMMY_TEMPLATE);

        // @Then sendTemplateStartRequest should be called with userId Bill
        verify(startRequestFactory, times(1)).sendTemplateStartRequest(eq(TED), anyString());
    }

    @Test
    public void testStartRequestFactoryCallsSendTemplateRequestWithTemplate1_whenWamUserServiceCallsSendTemplate() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(DUMMY_USER_ID, TEMPLATE_1);

        // @Then sendTemplateStartRequest should be called with template template1
        verify(startRequestFactory, times(1)).sendTemplateStartRequest(anyString(), eq(TEMPLATE_1));
    }

    @Test
    public void testStartRequestFactoryCallsSendTemplateRequestWithTemplate2_whenWamUserServiceCallsSendTemplate() throws  WamHandlerException {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(DUMMY_USER_ID, TEMPLATE_2);

        // @Then sendTemplateStartRequest should be called with template template1
        verify(startRequestFactory, times(1)).sendTemplateStartRequest(anyString(), eq(TEMPLATE_2));
    }


    @Test
    public void testProvisioningCallsStart_whenWamUserServiceCallsSendTemplate() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory

        // @When calls sendTemplate
        wamUserService.sendTemplate(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then start should be called
        verify(provisioning, times(1)).start(any(StartRequest.class));
    }

    @Test
    public void testProvisioningCallsStartWithRequestCreatedByStartRequest_whenWamUserServiceCallsSendTemplate() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory
        StartRequest startRequest = new StartRequest();
        when(startRequestFactory.sendTemplateStartRequest(anyString(), anyString())).thenReturn(startRequest);

        // @When calls sendTemplate
        wamUserService.sendTemplate(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then start should be called with startRequest as parameter
        verify(provisioning, times(1)).start(startRequest);
    }

    @Test
    public void testSendTemplateReturnsTransactionNumberReturnedByProvisioning_whenWamUserServiceCallsIt() throws WamHandlerException {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService

        // @When calls sendTemplate
        String result = wamUserService.sendTemplate(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then the result should be equal to the transaction number
        assertThat(result).isEqualTo(TRANSACTION_NUMBER);
    }

    @Test
    public void testSendTemplateThrowsWamHandlerExceptionWrappingAdminException_whenWamUserServiceCallsIt() throws WamHandlerException, AdminException_Exception {
        // @Given a WamUserService with a startRequestFactory and a ProvisioningService.
        // And Provisioning that throws an AdminException_Exception when the start method is called
        AdminException adminException = new AdminException();
        when(provisioning.start(any(StartRequest.class))).thenThrow(new AdminException_Exception("", adminException));

        // @When calls revokeRole
        try {
            wamUserService.sendTemplate(DUMMY_USER_ID, DUMMY_TEMPLATE);
            fail("A WamHandlerException should have been thrown");
        } catch (WamHandlerException e) {
            // @Then a WamHandlerException wrapping a AdminException_Exception should have been thrown
            assertThat(e.getCause()).isInstanceOf(AdminException_Exception.class);
        }

    }

}
