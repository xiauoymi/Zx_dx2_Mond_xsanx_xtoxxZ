package com.monsanto.wam.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.monsanto.wam.ws.callback.WamCallback;
import com.monsanto.wam.ws.controller.WamRestController;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Created by ivert on 21/10/2014.
 */
public class WamRestController_UT {

    public static final String DUMMY_TRANSACTION_NUMBER = null;
    public static final String TRANSACTION_NUMBER_123 = "123";
    public static final String TRANSACTION_NUMBER_456 = "456";
    public static final String DUMMY_USER_ID = null;
    public static final String MICHAEL = "mcorleo";
    public static final String SANTINO = "scorleo";
    private WamRestController controller;

    private WamCallback wamCallback = mock(WamCallback.class);

    @Before
    public void setUp(){
        controller = new WamRestController(wamCallback);
    }

    @Test
    public void testNewUserIdIsCalled_whenNewUserIsInvoked() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.newUser(anyString(), anyString());

        //@Then
        verify(wamCallback).newUserId(anyString(), anyString());
    }

    @Test
    public void testNewUserIdIsCalledWithTransactionNumber123_whenNewUserIsInvokedWithTransactionNumber123() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.newUser(TRANSACTION_NUMBER_123, DUMMY_USER_ID);

        //@Then
        verify(wamCallback).newUserId(eq(TRANSACTION_NUMBER_123), anyString());
    }

    @Test
    public void testNewUserIdIsCalledWithTransactionNumber456_whenNewUserIsInvokedWithTransactionNumber456() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.newUser(TRANSACTION_NUMBER_456, DUMMY_USER_ID);

        //@Then
        verify(wamCallback).newUserId(eq(TRANSACTION_NUMBER_456), anyString());
    }

    @Test
    public void testNewUserIdIsCalledWithUserIdMichael_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.newUser(DUMMY_TRANSACTION_NUMBER, MICHAEL);

        //@Then
        verify(wamCallback).newUserId(anyString(), eq(MICHAEL));
    }


    @Test
    public void testNewUserIdIsCalledWithUserIdSantino_whenNewUserIsInvokedWithSantino() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.newUser(DUMMY_TRANSACTION_NUMBER, SANTINO);

        //@Then
        verify(wamCallback).newUserId(anyString(), eq(SANTINO));
    }

    @Test
    public void testGrantedRevokedIsCalled_whenNewUserIsInvoked() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When grantedRevoked is called
        controller.grantedRevoked(anyString(), anyBoolean());

        //@Then
        verify(wamCallback).grantedRevoked(anyString(), anyBoolean());
    }

    @Test
    public void testGrantedRevokedIsCalledWithMichael_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When grantedRevoked is called
        controller.grantedRevoked(MICHAEL, false);

        //@Then
        verify(wamCallback).grantedRevoked(eq(MICHAEL), anyBoolean());
    }

    @Test
    public void testGrantedRevokedIsCalledWithSantino_whenNewUserIsInvokedWithTransactionSantino() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When grantedRevoked is called
        controller.grantedRevoked(SANTINO, false);

        //@Then
        verify(wamCallback).grantedRevoked(eq(SANTINO), anyBoolean());
    }

    @Test
    public void testGrantedRevokedIsCalledWithResultTrue_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.grantedRevoked(DUMMY_USER_ID, true);

        //@Then
        verify(wamCallback).grantedRevoked(anyString(), eq(true));
    }

    @Test
    public void testGrantedRevokedIsCalledWithResultFalse_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.grantedRevoked(DUMMY_USER_ID, false);

        //@Then
        verify(wamCallback).grantedRevoked(anyString(), eq(false));
    }

    @Test
    public void testUserModifiedIsCalled_whenNewUserIsInvoked() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.grantedRevoked(anyString(), anyBoolean());

        //@Then
        verify(wamCallback).grantedRevoked(anyString(), anyBoolean());
    }

    @Test
    public void testUserModifiedIdIsCalled_whenUserModifiedIsInvoked() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When userModified is called
        controller.userModified(anyString(), anyBoolean());

        //@Then
        verify(wamCallback).userModified(anyString(), anyBoolean());
    }

    @Test
    public void testUserModifiedIsCalledWithMichael_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When userModified is called
        controller.userModified(MICHAEL, false);

        //@Then
        verify(wamCallback).userModified(eq(MICHAEL), anyBoolean());
    }

    @Test
    public void testUserModifiedIsCalledWithSantino_whenNewUserIsInvokedWithTransactionSantino() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When userModified is called
        controller.userModified(SANTINO, false);

        //@Then
        verify(wamCallback).userModified(eq(SANTINO), anyBoolean());
    }

    @Test
    public void testUserModifiedIsCalledWithResultTrue_whenNewUserIsInvokedWithTrue() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When userModified is called
        controller.userModified(DUMMY_USER_ID, true);

        //@Then
        verify(wamCallback).userModified(anyString(), eq(true));
    }

    @Test
    public void testUserModifiedIsCalledWithResultFalse_whenNewUserIsInvokedWithFalse() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When newUser is called
        controller.userModified(DUMMY_USER_ID, false);

        //@Then
        verify(wamCallback).userModified(anyString(), eq(false));
    }

    @Test
       public void testTemplateSentIdIsCalled_whenUserModifiedIsInvoked() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When templateSent is called
        controller.templateSent(anyString(), anyBoolean());

        //@Then
        verify(wamCallback).templateSent(anyString(), anyBoolean());
    }

    @Test
    public void testTemplateSentIsCalledWithMichael_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When templateSent is called
        controller.templateSent(MICHAEL, false);

        //@Then
        verify(wamCallback).templateSent(eq(MICHAEL), anyBoolean());
    }

    @Test
    public void testTemplateSentIsCalledWithSantino_whenNewUserIsInvokedWithTransactionSantino() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When templateSent is called
        controller.templateSent(SANTINO, false);

        //@Then
        verify(wamCallback).templateSent(eq(SANTINO), anyBoolean());
    }

    @Test
    public void testTemplateSentIsCalledWithResultTrue_whenNewUserIsInvokedWithTrue() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When templateSent is called
        controller.templateSent(DUMMY_USER_ID, true);

        //@Then
        verify(wamCallback).templateSent(anyString(), eq(true));
    }

    @Test
    public void testTemplateSentIsCalledWithResultFalse_whenNewUserIsInvokedWithFalse() throws JsonProcessingException {
        //@Given a WamRestController with a WamCallback

        //@When templateSent is called
        controller.templateSent(DUMMY_USER_ID, false);

        //@Then
        verify(wamCallback).templateSent(anyString(), eq(false));
    }

//    @Test
//    public void testQueryUserIdIsCalled_whenUserModifiedIsInvoked() throws JsonProcessingException {
//        //@Given a WamRestController with a WamCallback
//
//        //@When queryUser is called
//        QueryResult queryResult = new QueryResult();
//        controller.queryUser(DUMMY_USER_ID, queryResult);
//
//        //@Then
//        verify(wamCallback).queryUser(anyString(), eq(queryResult));
//    }
//
//    @Test
//    public void testQueryUserIsCalledWithMichael_whenNewUserIsInvokedWithMichael() throws JsonProcessingException {
//        //@Given a WamRestController with a WamCallback
//
//        //@When queryUser is called
//        QueryResult queryResult = new QueryResult();
//        controller.queryUser(MICHAEL, queryResult);
//
//        //@Then
//        verify(wamCallback).queryUser(eq(MICHAEL), eq(queryResult));
//    }
//
//    @Test
//    public void testQueryUserIsCalledWithSantino_whenNewUserIsInvokedWithTransactionSantino() throws IOException {
//        //@Given a WamRestController with a WamCallback
//
//        //@When queryUser is called
//        QueryResult queryResult = new QueryResult();
//        controller.queryUser(SANTINO, queryResult);
//
//        //@Then
//        verify(wamCallback).queryUser(eq(SANTINO), eq(queryResult));
//    }

}
