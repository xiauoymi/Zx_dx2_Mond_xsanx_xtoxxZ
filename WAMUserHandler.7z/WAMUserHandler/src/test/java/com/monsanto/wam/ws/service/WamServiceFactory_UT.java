package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.ProvisioningService;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.impl.ApplicationPropertyHelperImpl;
import com.monsanto.wam.ws.service.impl.WamServiceFactoryImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.xml.namespace.QName;
import java.net.MalformedURLException;
import java.net.URL;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.verifyNew;
import static org.powermock.api.mockito.PowerMockito.whenNew;

/**
 * Created by ivert on 22/10/2014.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({WamServiceFactoryImpl.class, ProvisioningService.class})
public class WamServiceFactory_UT {

    private ApplicationPropertiesHelper applicationPropertiesHelper = mock(ApplicationPropertiesHelper.class);

    private WamServiceFactory wamServiceFactory;

    @Before
    public void setUp() throws Exception {
        when(applicationPropertiesHelper.getApplicationProperty(WamServiceFactoryImpl.URL)).thenReturn("http://test?wsdl");
        when(applicationPropertiesHelper.getApplicationProperty(WamServiceFactoryImpl.QNAME_NAMESPACEURI)).thenReturn("http://test");
        when(applicationPropertiesHelper.getApplicationProperty(WamServiceFactoryImpl.QNAME_LOCALPART)).thenReturn("p");
        whenNew(ProvisioningService.class).withArguments(any(URL.class), any(QName.class)).thenReturn(null);
        wamServiceFactory = new WamServiceFactoryImpl(applicationPropertiesHelper);
    }

    @Test
    public void testReturnedServiceIsCreatedByTheCorrectConstructor_whenGetWamServiceIsCall() throws Exception {
        //@Given a WamServiceFactory with an ApplicationPropertiesHelper
        ProvisioningService mockProvisioningService = mock(ProvisioningService.class);
        whenNew(ProvisioningService.class).withArguments(any(URL.class), any(QName.class)).thenReturn(mockProvisioningService);

        //@When getWamService is called
        ProvisioningService provisioningService = wamServiceFactory.getWamService();

        //@Then the returned object by getWamService must be equal to the one created by the mocked constructor
        assertThat(provisioningService).isEqualTo(mockProvisioningService);
    }

    @Test
    public void testGetApplicationPropertiesIsCalledWithValueUrl_whenGetWamServiceIsCall() throws WamHandlerException {
        //@Given a WamServiceFactory with an ApplicationPropertiesHelper

        //@When getWamService is called
        wamServiceFactory.getWamService();

        //@Then getApplicationProperty should be called with value WamServiceFactoryImpl.URL
        verify(applicationPropertiesHelper).getApplicationProperty(WamServiceFactoryImpl.URL);
    }

    @Test
    public void testGetApplicationPropertiesIsCalledWithValueNamespace_whenGetWamServiceIsCall() throws WamHandlerException {
        //@Given a WamServiceFactory with an ApplicationPropertiesHelper

        //@When getWamService is called
        wamServiceFactory.getWamService();

        //@Then getApplicationProperty should be called with value WamServiceFactoryImpl.QNAME_NAMESPACEURI
        verify(applicationPropertiesHelper).getApplicationProperty(WamServiceFactoryImpl.QNAME_NAMESPACEURI);
    }

    @Test
    public void testGetApplicationPropertiesIsCalledWithValueLocalPart_whenGetWamServiceIsCall() throws WamHandlerException {
        //@Given a WamServiceFactory with an ApplicationPropertiesHelper

        //@When getWamService is called
        wamServiceFactory.getWamService();

        //@Then getApplicationProperty should be called with value WamServiceFactoryImpl.QNAME_LOCALPART
        verify(applicationPropertiesHelper).getApplicationProperty(WamServiceFactoryImpl.QNAME_LOCALPART);
    }

}
