package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.Provisioning;
import com.monsanto.wam.ws.client.ProvisioningService;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.impl.WamClientFactoryImpl;
import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Created by IVERT on 11/10/2014.
 */
public class WamClientFactory_UT {

    private WamServiceFactory wamServiceFactory = mock(WamServiceFactory.class);

    private ProvisioningService provisioningService = mock(ProvisioningService.class);

    private ClientPropertiesConfigurator clientPropertiesConfigurator = mock(ClientPropertiesConfigurator.class);

    private WamClientFactory wamClientFactory;

    @Before
    public void setUp() throws WamHandlerException {
        when(wamServiceFactory.getWamService()).thenReturn(provisioningService);
        wamClientFactory = new WamClientFactoryImpl(wamServiceFactory, clientPropertiesConfigurator);
    }

    @Test
    public void testProvisioningServiceCallsGetProvisioningPort_whenWamClientFactoryCallsGetWamServiceClient() throws WamHandlerException {
        // @Given a WamClientFactory with a ProvisioningService and a ClientPropertiesConfigurator

        // @When calls getWamServiceClient
        wamClientFactory.getWamServiceClient();

        // @Then getProvisioningPort should be called
        verify(provisioningService, times(1)).getProvisioningPort();
    }

    @Test
    public void testClientPropertiesConfiguratorCallsSetProperties_whenWamClientFactoryCallsGetWamServiceClient() throws WamHandlerException {
        // @Given a WamClientFactory with a ProvisioningService and a ClientPropertiesConfigurator
        Provisioning provisioning = mock(Provisioning.class);
        when(provisioningService.getProvisioningPort()).thenReturn(provisioning);

        // @When calls getWamServiceClient
        wamClientFactory.getWamServiceClient();

        // @Then setProperties should be called
        verify(clientPropertiesConfigurator, times(1)).setProperties(provisioning);
    }

}
