package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.DataItem;
import com.monsanto.wam.ws.client.StartRequest;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;
import com.monsanto.wam.ws.service.impl.StartRequestFactoryImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

public class StartRequestFactory_UT {

    private static final String DUMMY_FIRST_NAME = null;
    private static final String DUMMY_SECOND_NAME = null;
    private static final String DUMMY_LAST_NAME = null;
    private static final String DUMMY_MAIL = null;
    private static final String FIRST_NAME_JOHN = "John";
    private static final String FIRST_NAME_PAUL = "Paul";
    private static final String INITIAL_SECOND_NAME_J = "J";
    private static final String INITIAL_SECOND_NAME_K = "K";
    private static final String LAST_NAME_SMITH = "Smith";
    private static final String LAST_NAME_JONES = "Jones";
    private static final String MAIL_1 = "1@1";
    private static final String MAIL_2 = "2@2";
    private static final String BILL = "Bill";
    private static final String DUMMY_ROLE = null;
    private static final String DUMMY_USER_ID = null;
    private static final String TED = "Ted";
    private static final String SINGER = "Singer";
    private static final String DRUMMER = "Drummer";
    private static final String USER_ID_007 = "007";
    private static final String USER_ID_009 = "009";
    private static final String FALSE = "FALSE";
    private static final String TRUE = "TRUE";
    private static final String MON_PARTY_ID_TWENTY = "20";
    private static final String MON_PARTY_ID_TWENTY_FIVE = "25";
    private static final String INTERNAL = "Internal";
    private static final String EXTERNAL = "External";
    private static final String DEVELOPER = "Developer";
    private static final String TECH_LEAD = "Tech Lead";
    private static final String DUMMY_TEMPLATE = null;
    private static final String TEMPLATE_1 = "Template1";
    private static final String TEMPLATE_2 = "Template2";

    StartRequestFactory startRequestFactory = new StartRequestFactoryImpl();

    @Test
    public void testArg0IsAddedWithDefaultValue_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the arg0 value should be the default value
        assertThat(result.getArg0().getValue()).isEqualTo(StartRequestFactoryImpl.ZERO_ARG_USER_ACCOUNT_CREATE);
    }

    @Test
    public void testArg1IsAddedWithDefaultValue_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the arg1 value should be empty
        assertThat(result.getArg1().getValue()).isEmpty();
    }

    @Test
    public void testFirstNameIsAddedToRequestWithValueJohn_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName
        WamUser wamUser = new WamUser(FIRST_NAME_JOHN, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.FIRST_NAME);
        assertThat(value).isEqualTo(FIRST_NAME_JOHN);
    }

    @Test
    public void testFirstNameIsAddedToRequestWithValuePaul_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Paul as firstName
        WamUser wamUser = new WamUser(FIRST_NAME_PAUL, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be Paul
        String value = getNodeValue(result, StartRequestFactoryImpl.FIRST_NAME);
        assertThat(value).isEqualTo(FIRST_NAME_PAUL);
    }

    @Test
    public void testInitialSecondNameIsAddedToRequestWithValueJ_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with J as initialSecondName
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, INITIAL_SECOND_NAME_J, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be J
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.MIDDLE_INITIAL);
        assertThat(valueAtNode).isEqualTo(INITIAL_SECOND_NAME_J);
    }

    @Test
    public void testInitialSecondNameIsAddedToRequestWithValueK_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with K as initialSecondName
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, INITIAL_SECOND_NAME_K, DUMMY_LAST_NAME, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be K
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.MIDDLE_INITIAL);
        assertThat(valueAtNode).isEqualTo(INITIAL_SECOND_NAME_K);
    }


    @Test
    public void testLastNameIsAddedToRequestWithValueSmith_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Smith as lastName
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, LAST_NAME_SMITH, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be J
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.LAST_NAME);
        assertThat(valueAtNode).isEqualTo(LAST_NAME_SMITH);
    }

    @Test
    public void testLastNameIsAddedToRequestWithValueJones_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Jones as lastName
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, LAST_NAME_JONES, DUMMY_MAIL);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be K
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.LAST_NAME);
        assertThat(valueAtNode).isEqualTo(LAST_NAME_JONES);
    }

    @Test
    public void testEmailIsAddedToRequestWithValueEmail1_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 1@1 as email
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, MAIL_1);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be 1@1
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.E_MAIL, MAIL_1);
    }

    @Test
    public void testEmailIsAddedToRequestWithValueEmail2_whenCreateUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 2@2 as email
        WamUser wamUser = new WamUser(DUMMY_FIRST_NAME, DUMMY_SECOND_NAME, DUMMY_LAST_NAME, MAIL_2);

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.createUserStartRequest(wamUser);

        // @Then the value at the corresponding node should be 2@2
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.E_MAIL, MAIL_2);
    }

    private void assertThatRequestIsValidAndContainsValue(StartRequest result, String name, String value) {
        String valueAtNode = getNodeValue(result, name);
        assertThat(valueAtNode).isEqualTo(value);
    }

    private String getNodeValue(StartRequest result, String name) {
        List<DataItem> dataItems = result.getArg2().getValue().getDataitem();

        DataItem dataItem = CollectionUtils.find(dataItems, new DataItemPredicate(name));
        if (dataItem == null){
            fail("Invalid Request: The node " + name.toUpperCase() + " does not exist");
        }
        List<String> strings = dataItem.getValue().getString();
        return strings.get(0);
    }

    private class DataItemPredicate implements Predicate<DataItem>{

        private String name;

        private DataItemPredicate(String name) {
            this.name = name;
        }

        @Override
        public boolean evaluate(DataItem dataItem) {
            return dataItem.getName().equals(name);
        }
    }

    @Test
    public void testArg0IsAddedWithDefaultValue_whenGrantRoleStartRequestIsCalled(){
        // @Given a StartRequestFactory

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then the arg0 value should be the default value
        assertThat(result.getArg0().getValue()).isEqualTo(StartRequestFactoryImpl.ZERO_ARG_GRANT_REVOKE_ROLE);
    }

    @Test
    public void testArg1IsAddedWithDefaultValue_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(DUMMY_USER_ID, DUMMY_ROLE);

        // @Then the arg1 value should be empty
        assertThat(result.getArg1().getValue()).isEmpty();
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueBill_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(BILL, DUMMY_ROLE);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(BILL);
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueTed_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(TED, DUMMY_ROLE);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(TED);
    }

    @Test
    public void testRoleIsAddedToRequestWithValueSinger_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(DUMMY_USER_ID, SINGER);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.ROLE);
        assertThat(value).isEqualTo(SINGER);
    }

    @Test
    public void testRoleIsAddedToRequestWithValueDrummer_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(DUMMY_USER_ID, DRUMMER);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.ROLE);
        assertThat(value).isEqualTo(DRUMMER);
    }

    @Test
    public void testActionIsAddedToRequestWithValueGrant_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.grantRoleStartRequest(DUMMY_USER_ID, DRUMMER);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.ACTION);
        assertThat(value).isEqualTo(StartRequestFactoryImpl.ACTION_GRANT);
    }

    @Test
    public void testArg0IsAddedWithDefaultValue_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the arg0 value should be the default value
        assertThat(result.getArg0().getValue()).isEqualTo(StartRequestFactoryImpl.ZERO_ARG_MODIFY_USER);
    }

    @Test
    public void testArg1IsAddedWithDefaultValue_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the arg1 value should be empty
        assertThat(result.getArg1().getValue()).isEmpty();
    }

    @Test
    public void testFirstNameIsAddedToRequestWithValueJohn_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setFirstName(FIRST_NAME_JOHN);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.FIRST_NAME);
        assertThat(value).isEqualTo(FIRST_NAME_JOHN);
    }

    @Test
    public void testFirstNameIsAddedToRequestWithValuePaul_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Paul as firstName
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setFirstName(FIRST_NAME_PAUL);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be Paul
        String value = getNodeValue(result, StartRequestFactoryImpl.FIRST_NAME);
        assertThat(value).isEqualTo(FIRST_NAME_PAUL);
    }

    @Test
    public void testLastNameIsAddedToRequestWithValueSmith_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Smith as lastName
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLastName(LAST_NAME_SMITH);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be J
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.LAST_NAME);
        assertThat(valueAtNode).isEqualTo(LAST_NAME_SMITH);
    }

    @Test
    public void testLastNameIsAddedToRequestWithValueJones_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with Jones as lastName
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLastName(LAST_NAME_JONES);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be K
        String valueAtNode = getNodeValue(result, StartRequestFactoryImpl.LAST_NAME);
        assertThat(valueAtNode).isEqualTo(LAST_NAME_JONES);
    }

    @Test
    public void testEmailIsAddedToRequestWithValueEmail1_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 1@1 as email
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setEmail(MAIL_1);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 1@1
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.E_MAIL, MAIL_1);
    }

    @Test
    public void testEmailIsAddedToRequestWithValueEmail2_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 2@2 as email
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setEmail(MAIL_2);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 2@2
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.E_MAIL, MAIL_2);
    }

    @Test
    public void testUserIdIsAddedToRequestWithValue007_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 007 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(USER_ID_007);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 007
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.USER_ID, USER_ID_007);
    }

    @Test
    public void testUserIdIsAddedToRequestWithValue009_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 009 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(USER_ID_009);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 009
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.USER_ID, USER_ID_009);
    }

    @Test
    public void testLockedByIntruderIsAddedToRequestWithValueFalse_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 007 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLockedByIntruder(FALSE);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be FALSE
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.LOCKED_BY_INTRUDER, FALSE);
    }

    @Test
    public void testLockedByIntruderIsAddedToRequestWithValueTrue_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 007 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLockedByIntruder(TRUE);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be TRUE
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.LOCKED_BY_INTRUDER, TRUE);
    }

    @Test
    public void testLoginDisabledIsAddedToRequestWithValueFalse_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 007 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLoginDisabled(FALSE);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be FALSE
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.LOGIN_DISABLED, FALSE);
    }

    @Test
    public void testLoginDisabledIsAddedToRequestWithValueTrue_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 007 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setLoginDisabled(TRUE);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be TRUE
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.LOGIN_DISABLED, TRUE);
    }

    @Test
    public void testMonPartyIdIsAddedToRequestWithValueFalse_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 25 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setMonPartyID(MON_PARTY_ID_TWENTY_FIVE);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 25
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.MON_PARTY_ID, MON_PARTY_ID_TWENTY_FIVE);
    }

    @Test
    public void testMonPartyIdIsAddedToRequestWithValueTrue_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 20 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setMonPartyID(MON_PARTY_ID_TWENTY);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be 20
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.MON_PARTY_ID, MON_PARTY_ID_TWENTY);
    }

    @Test
    public void testMonUserTypeIsAddedToRequestWithValueInternal_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 20 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setMonUserType(INTERNAL);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be Internal
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.MON_USER_TYPE, INTERNAL);
    }

    @Test
    public void testMonUserTypeIsAddedToRequestWithValueExternal_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 20 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setMonUserType(EXTERNAL);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be External
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.MON_USER_TYPE, EXTERNAL);
    }

    @Test
    public void testTitleIsAddedToRequestWithValueDeveloper_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 20 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setTitle(DEVELOPER);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be External
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.TITLE, DEVELOPER);
    }

    @Test
    public void testTitleIsAddedToRequestWithValueTechLead_whenModifyUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with 20 as userId
        ExistingWamUser existingWamUser = new ExistingWamUser(DUMMY_USER_ID);
        existingWamUser.setTitle(TECH_LEAD);

        // @When modifyUserStartRequest is called
        StartRequest result = startRequestFactory.modifyUserStartRequest(existingWamUser);

        // @Then the value at the corresponding node should be External
        assertThatRequestIsValidAndContainsValue(result, StartRequestFactoryImpl.TITLE, TECH_LEAD);
    }

    @Test
    public void testArg0IsAddedWithDefaultValue_whenQueryUserStartRequestIsCalled(){
        // @Given a StartRequestFactory

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.queryUserStartRequest(DUMMY_USER_ID);

        // @Then the arg0 value should be the default value
        assertThat(result.getArg0().getValue()).isEqualTo(StartRequestFactoryImpl.ZERO_ARG_QUERY_USER);
    }

    @Test
    public void testArg1IsAddedWithDefaultValue_whenQueryUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.queryUserStartRequest(DUMMY_USER_ID);

        // @Then the arg1 value should be empty
        assertThat(result.getArg1().getValue()).isEmpty();
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueBill_whenQueryUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.queryUserStartRequest(BILL);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(BILL);
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueTed_whenQueryUserStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.queryUserStartRequest(TED);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(TED);
    }

    @Test
    public void testArg0IsAddedWithDefaultValue_whenSendTemplateStartRequestIsCalled(){
        // @Given a StartRequestFactory

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then the arg0 value should be the default value
        assertThat(result.getArg0().getValue()).isEqualTo(StartRequestFactoryImpl.ZERO_ARG_SEND_TEMPLATE);
    }

    @Test
    public void testArg1IsAddedWithDefaultValue_whenSendTemplateStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(DUMMY_USER_ID, DUMMY_TEMPLATE);

        // @Then the arg1 value should be empty
        assertThat(result.getArg1().getValue()).isEmpty();
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueBill_whenSendTemplateStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(BILL, DUMMY_TEMPLATE);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(BILL);
    }

    @Test
    public void testUserIdIsAddedToRequestWithValueTed_whenSendTemplateStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(TED, DUMMY_TEMPLATE);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.USER_ID);
        assertThat(value).isEqualTo(TED);
    }

    @Test
    public void testRoleIsAddedToRequestWithValueTemplate1_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(DUMMY_USER_ID, TEMPLATE_1);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.TEMPLATE);
        assertThat(value).isEqualTo(TEMPLATE_1);
    }

    @Test
    public void testRoleIsAddedToRequestWithValueTemplate2_whenCreateGrantStartRequestIsCalled(){
        // @Given a StartRequestFactory and a WamUser with John as firstName

        // @When createUserStartRequest is called
        StartRequest result = startRequestFactory.sendTemplateStartRequest(DUMMY_USER_ID, TEMPLATE_2);

        // @Then the value at the corresponding node should be John
        String value = getNodeValue(result, StartRequestFactoryImpl.TEMPLATE);
        assertThat(value).isEqualTo(TEMPLATE_2);
    }

}