package com.monsanto.wam.ws.service;

import com.monsanto.wam.ws.client.*;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.impl.ClientPropertiesConfiguratorImpl;
import org.junit.Before;
import org.junit.Test;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.EndpointReference;
import java.util.Map;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ClientPropertiesConfigurator_UT {

    private static final String JAMES = "James";
    private static final String MARK = "Mark";
    private static final String DOUBLE_O_7 = "007";
    private static final String DOUBLE_O_9 = "009";
    private static final String ENDPOINT_ONE = "http://monsanto.service.one";
    private static final String ENDPOINT_TWO = "http://monsanto.service.two";

    Map<String, Object> requestContext = mock(Map.class);
    private Provisioning provisioning = new FakeProvisioning();
    private ClientPropertiesConfigurator clientPropertiesConfigurator;
    private ApplicationPropertiesHelper applicationPropertiesHelper = mock(ApplicationPropertiesHelper.class);


    @Before
    public void setUp(){
        clientPropertiesConfigurator = new ClientPropertiesConfiguratorImpl(applicationPropertiesHelper);
    }

    @Test
    public void testUserNamePropertyIsSet_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator 
        
        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.USERNAME_PROPERTY), anyString());
    }

    @Test
    public void testUserNamePropertyIsSetWithJames_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(JAMES);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.USERNAME_PROPERTY), eq(JAMES));
    }

    @Test
    public void testUserNamePropertyIsSetWithMark_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(MARK);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.USERNAME_PROPERTY), eq(MARK));
    }

    @Test
    public void testPasswordPropertyIsSet_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.PASSWORD_PROPERTY), anyString());
    }

    @Test
    public void testPasswordPropertyIsSetWith007_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(DOUBLE_O_7);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.PASSWORD_PROPERTY), eq(DOUBLE_O_7));
    }

    @Test
    public void testPasswordPropertyIsSetWith009_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(DOUBLE_O_9);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.PASSWORD_PROPERTY), eq(DOUBLE_O_9));
    }

    @Test
    public void testEndpointPropertyIsSet_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.ENDPOINT_ADDRESS_PROPERTY), anyString());
    }

    @Test
    public void testEndpointPropertyIsSetWithEndpointOne_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(ENDPOINT_ONE);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.ENDPOINT_ADDRESS_PROPERTY), eq(ENDPOINT_ONE));
    }

    @Test
    public void testEndpointPropertyIsSetWithEndpointTwo_whenSetPropertiesIsCalled() throws WamHandlerException {
        // @Given a ClientPropertiesConfigurator
        when(applicationPropertiesHelper.getApplicationProperty(anyString())).thenReturn(ENDPOINT_TWO);

        clientPropertiesConfigurator.setProperties(provisioning);

        verify(requestContext).put(eq(BindingProvider.ENDPOINT_ADDRESS_PROPERTY), eq(ENDPOINT_TWO));
    }

    private class FakeProvisioning implements Provisioning, BindingProvider{

        @Override
        public Map<String, Object> getRequestContext() {
            return requestContext;
        }

        @Override
        public Map<String, Object> getResponseContext() {
            return null;
        }

        @Override
        public Binding getBinding() {
            return null;
        }

        @Override
        public EndpointReference getEndpointReference() {
            return null;
        }

        @Override
        public <T extends EndpointReference> T getEndpointReference(Class<T> clazz) {
            return null;
        }

        @Override
        public ReceiveResponse receive(ReceiveRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByApprovalStatusResponse getProcessesByApprovalStatus(GetProcessesByApprovalStatusRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public TerminateResponse terminate(TerminateRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesResponse getProcesses(GetProcessesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetClusterStateResponse getClusterState(GetClusterStateRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ForwardAsProxyResponse forwardAsProxy(ForwardAsProxyRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetEngineConfigurationResponse getEngineConfiguration(GetEngineConfigurationRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetAllProcessesResponse getAllProcesses(GetAllProcessesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ReassignAllProcessesResponse reassignAllProcesses(ReassignAllProcessesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetWebServiceActivityTimeoutResponse setWebServiceActivityTimeout(SetWebServiceActivityTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetVersionResponse getVersion(GetVersionRequest bodyIn) {
            return null;
        }

        @Override
        public ForwardWithDigitalSignatureResponse forwardWithDigitalSignature(ForwardWithDigitalSignatureRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByCreationTimeResponse getProcessesByCreationTime(GetProcessesByCreationTimeRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetWorkResponse getWork(GetWorkRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByCreationIntervalResponse getProcessesByCreationInterval(GetProcessesByCreationIntervalRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ResetPriorityForWorkTaskResponse resetPriorityForWorkTask(ResetPriorityForWorkTaskRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetDefinitionByIDResponse getDefinitionByID(GetDefinitionByIDRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCommentsResponse getComments(GetCommentsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartWorkFlowResponse startWorkFlow(StartWorkFlowRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCompletedProcessTimeoutResponse getCompletedProcessTimeout(GetCompletedProcessTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetQuorumForWorkTaskResponse getQuorumForWorkTask(GetQuorumForWorkTaskRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ReassignProcessesResponse reassignProcesses(ReassignProcessesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCommentsByActivityResponse getCommentsByActivity(GetCommentsByActivityRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProvisioningRequestsResponse getProvisioningRequests(GetProvisioningRequestsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ReassignPercentageProcessesResponse reassignPercentageProcesses(ReassignPercentageProcessesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetFlowDefinitionResponse getFlowDefinition(GetFlowDefinitionRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ForwardAsProxyWithDigitalSignatureResponse forwardAsProxyWithDigitalSignature(ForwardAsProxyWithDigitalSignatureRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetCompletedProcessTimeoutResponse setCompletedProcessTimeout(SetCompletedProcessTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetRoleRequestStatusResponse setRoleRequestStatus(SetRoleRequestStatusRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProvisioningStatusesResponse getProvisioningStatuses(GetProvisioningStatusesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetUserActivityTimeoutResponse getUserActivityTimeout(GetUserActivityTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ReassignResponse reassign(ReassignRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetGraphResponse getGraph(GetGraphRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetEngineConfigurationResponse setEngineConfiguration(SetEngineConfigurationRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessFlowXmlResponse getProcessFlowXml(GetProcessFlowXmlRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ForwardResponse forward(ForwardRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetAllProvisioningRequestsResponse getAllProvisioningRequests(GetAllProvisioningRequestsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ReassignWorkTaskResponse reassignWorkTask(ReassignWorkTaskRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartWithDigitalSignatureResponse startWithDigitalSignature(StartWithDigitalSignatureRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartAsProxyResponse startAsProxy(StartAsProxyRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCommentsByTypeResponse getCommentsByType(GetCommentsByTypeRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetUserActivityTimeoutResponse setUserActivityTimeout(SetUserActivityTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByRecipientResponse getProcessesByRecipient(GetProcessesByRecipientRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByStatusResponse getProcessesByStatus(GetProcessesByStatusRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesArrayResponse getProcessesArray(GetProcessesArrayRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetEmailNotificationsResponse setEmailNotifications(SetEmailNotificationsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCommentsByUserResponse getCommentsByUser(GetCommentsByUserRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartWithCorrelationIdResponse startWithCorrelationId(StartWithCorrelationIdRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetEmailNotificationsResponse getEmailNotifications(GetEmailNotificationsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByQueryResponse getProcessesByQuery(GetProcessesByQueryRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetWorkEntriesResponse getWorkEntries(GetWorkEntriesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessResponse getProcess(GetProcessRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByIdResponse getProcessesById(GetProcessesByIdRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetFormDefinitionResponse getFormDefinition(GetFormDefinitionRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartResponse start(StartRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public RemoveEngineResponse removeEngine(RemoveEngineRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public ClearNIMCachesResponse clearNIMCaches(ClearNIMCachesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProcessesByInitiatorResponse getProcessesByInitiator(GetProcessesByInitiatorRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public SetResultResponse setResult(SetResultRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public UnclaimResponse unclaim(UnclaimRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetCommentsByCreationTimeResponse getCommentsByCreationTime(GetCommentsByCreationTimeRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetProvisioningCategoriesResponse getProvisioningCategories(GetProvisioningCategoriesRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public StartAsProxyWithDigitalSignatureResponse startAsProxyWithDigitalSignature(StartAsProxyWithDigitalSignatureRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetEngineStateResponse getEngineState(GetEngineStateRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public MultiStartResponse multiStart(MultiStartRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetDataItemsResponse getDataItems(GetDataItemsRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public GetWebServiceActivityTimeoutResponse getWebServiceActivityTimeout(GetWebServiceActivityTimeoutRequest bodyIn) throws AdminException_Exception {
            return null;
        }

        @Override
        public AddCommentResponse addComment(AddCommentRequest bodyIn) throws AdminException_Exception {
            return null;
        }
    }

}