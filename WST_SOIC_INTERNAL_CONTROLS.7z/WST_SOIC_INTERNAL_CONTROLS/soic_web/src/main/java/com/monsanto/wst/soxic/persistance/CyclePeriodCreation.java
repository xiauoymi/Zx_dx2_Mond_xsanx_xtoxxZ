package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.exception.NewPeriodCreationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 24, 2005
 * Time: 2:02:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class CyclePeriodCreation {

    public static void main(String args[])throws Exception{
        CyclePeriodCreation cyclePeriodCreation = new CyclePeriodCreation();
        Connection connection=null;
        long startTime,endTime,dif;
        startTime = System.currentTimeMillis();
        List cyclelist = cyclePeriodCreation.createCycles("FY05.","RAM01", connection);
        cyclePeriodCreation.insertCycle(cyclelist, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;
        startTime = System.currentTimeMillis();
        List questionCycleList = cyclePeriodCreation.createQuestionCycle("FY05.","RAM01", connection);
        cyclePeriodCreation.insertQuestionCycle(questionCycleList, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;

        startTime = System.currentTimeMillis();
        List ownerCycleList = cyclePeriodCreation.createOwnerCycle("FY05.","RAM01", connection);
        cyclePeriodCreation.insertOwnerCycle(ownerCycleList, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;
    }

    public List createCycles(String sourcePeriod, String targetPeriod, Connection connection)throws Exception{
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;
        List cycleList = new ArrayList();

        try {
            preparedStatement = connection.prepareStatement("SELECT C.CYCLE_ID, C.CYCLE_CODE, C.WORLD_AREA_ID, C.COUNTRY_ID, C.PERIOD_ID, C.DESCRIPTION, C.OVERFLOW_ID FROM CYCLE C WHERE C.CYCLE_ID LIKE '%"+sourcePeriod+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateCurrentModel(rs);
                processCycle(cycle,"",targetPeriod);
                cycleList.add(cycle);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    public List createQuestionCycle(String sourcePeriod, String targetPeriod, Connection connection)throws Exception{


        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;
        List questionCycle = new ArrayList();

        try {

            preparedStatement = connection.prepareStatement("SELECT QC.CYCLE_ID,QC.QUESTION_ID FROM QUESTION_CYCLE QC WHERE QC.CYCLE_ID LIKE'%"+sourcePeriod+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateQuestionModel(rs);
                processQuestionCycle(cycle,"",targetPeriod);
                questionCycle.add(cycle);
            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return questionCycle;

    }

    public void insertQuestionCycle(List cycleList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO QUESTION_CYCLE (QUESTION_ID, CYCLE_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = cycleList.iterator();
            while(iterator.hasNext()){
                Cycle cycle = (Cycle)iterator.next();
                preparedStatement.setString(1,cycle.getQuestionId());
                preparedStatement.setString(2,cycle.getCycleId());
                preparedStatement.setDate(3,new Date(System.currentTimeMillis()));
                preparedStatement.setString(4,"ADMIN");
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public Cycle populateQuestionModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try {

            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));

            cycle.setQuestionId(rs.getString(Cycle.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cycle;
    }


    public Cycle populateCurrentModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setCycleCode(rs.getString(Cycle.CYCLE_CODE));
            cycle.setWorldAreaId(rs.getString(Cycle.WORLD_AREA_ID));
            cycle.setCountryId(rs.getString(Cycle.COUNTRY_ID));
            cycle.setDescription(rs.getString(Cycle.DESCRIPTION));
            cycle.setOverFlowId(rs.getInt(Cycle.OVERFLOW_ID));
            cycle.setPeriodId(rs.getString(Cycle.PERIOD_ID));
        } catch (Exception e) {
            //throw new DatabaseException("error while populating Cycle from resultset:" +  e.toString());

        }
        return cycle;
    }

    public void insertCycle(List cycleList, Connection connection)throws Exception{
        PreparedStatement preparedStatement=null;
        String query = "INSERT INTO CYCLE (CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION,OVERFLOW_ID, STATUS, MOD_DATE, MOD_USER)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);

            Iterator iterator = cycleList.iterator();
            while(iterator.hasNext()){
                Cycle cycle = (Cycle)iterator.next();

                preparedStatement.setString(1,cycle.getCycleId());
                preparedStatement.setString(2,cycle.getCycleCode());
                preparedStatement.setString(3,cycle.getWorldAreaId());
                preparedStatement.setString(4,cycle.getCountryId());
                preparedStatement.setString(5,cycle.getPeriodId());
                preparedStatement.setString(6,cycle.getDescription());
                preparedStatement.setInt(7,cycle.getOverFlowId());
                preparedStatement.setString(8,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(9,new Date(System.currentTimeMillis()));
                preparedStatement.setString(10,"ADMIN");
                preparedStatement.addBatch();
            }

            int result[]=preparedStatement.executeBatch();
            processUpdateCounts(result);
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void processCycle(Cycle cycle,String newCycleId,String period){
        StringTokenizer st = new StringTokenizer(cycle.getCycleId(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String targetCycleId = period+"."+countryId+"."+cycleId;
        cycle.setCycleId(targetCycleId);
        cycle.setPeriodId(period);
    }

    public void processQuestionCycle(Cycle cycle,String newCycleId,String period){
        StringTokenizer st = new StringTokenizer(cycle.getCycleId(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String targetCycleId = period+"."+countryId+"."+cycleId;
        cycle.setCycleId(targetCycleId);
    }



    public void processUpdateCounts(int[] updateCounts) {
        for (int i=0; i<updateCounts.length; i++) {
            if (updateCounts[i] >= 0) {
                // Successfully executed; the number represents number of affected rows
            } else if (updateCounts[i] == Statement.SUCCESS_NO_INFO) {
                // Successfully executed; number of affected rows not available
            } else if (updateCounts[i] == Statement.EXECUTE_FAILED) {
                // Failed to execute
            }
        }
    }

    public List createOwnerCycle(String sourcePeriod, String targetPeriod, Connection connection)throws Exception{

        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;
        List ownerCycleList = new ArrayList();
        try {

            preparedStatement = connection.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC WHERE OC.CYCLE_ID LIKE '%"+sourcePeriod+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateOwnerModel(rs);
                processCycle(cycle,"",targetPeriod);
                ownerCycleList.add(cycle);
            }
            //insertOwnerCycle(cycle,targetCycleId,period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
                throw new NewPeriodCreationException(e);
            }
        }
        return ownerCycleList;
    }

    public Cycle populateOwnerModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setOwnerId(rs.getString(Cycle.OWNERID));
        } catch (Exception e) {
            //throw new DatabaseException("error while populating Cycle from resultset:" +  e.toString());

        }
        return cycle;
    }

    public void insertOwnerCycle(List cycleList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_CYCLE (OWNER_ID, CYCLE_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = cycleList.iterator();
            while(iterator.hasNext()){
                Cycle cycle = (Cycle)iterator.next();
                preparedStatement.setString(1,cycle.getOwnerId());
                preparedStatement.setString(2,cycle.getCycleId());
                preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
                preparedStatement.setString(5,"ADMIN");
                preparedStatement.addBatch();
            }



            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {

            }
        }
    }


}
