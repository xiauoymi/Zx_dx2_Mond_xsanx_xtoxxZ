package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.facade.PeriodFacade;
import com.monsanto.wst.soxic.form.NewPeriodForm;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 14, 2005
 * Time: 3:39:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateNewPeriodDisplayAction extends Action{
    public ActionForward execute(ActionMapping mapping,
			 ActionForm form,
			 HttpServletRequest request,
			 HttpServletResponse response)throws Exception {
        PeriodFacade periodFacade = new PeriodFacade();
        NewPeriodForm newPeriodForm = (NewPeriodForm)form;
        periodFacade.getPeriod(newPeriodForm);

        return mapping.findForward("success");
    }
    
}


