package com.monsanto.wst.soxic.ownerStatusReports;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerStatus;
import com.monsanto.wst.soxic.model.OwnerStatusCountryDAO;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;
import com.monsanto.wst.soxic.reportingFramework.SoxAbstractReport;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 21, 2005
 * Time: 9:59:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusCountryReport extends SoxAbstractReport{

    OwnerStatusCountryDAO ownerStatusCountryDAO = new OwnerStatusCountryDAO();
    OwnerStatusXMLBuilder ownerStatusXMLBuilder = new OwnerStatusXMLBuilder();

    public void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException {
        String period = (String) reportParameters.getReportParameter("periodId");
        String country = (String) reportParameters.getReportParameter("country");
        String reportType="Country";
        List cycles = getCyclesForThisSelection(period,country);
        List reportInfo = new ArrayList();
        Iterator it = cycles.iterator();
        populateReportOwners(it, period, country, reportInfo);
        ownerStatusXMLBuilder.createXMLReport(reportDataElement,reportInfo,reportType);
    }

    private void populateReportOwners(Iterator it, String period, String country, List reportInfo) throws DatabaseException {
        OwnerStatus ownerStatus;
        while(it.hasNext()){
            ownerStatus = new OwnerStatus();
            String cycleid = (String) it.next();
            ownerStatus.setId(cycleid);
            ownerStatus.setOwners(getReportInformation(period,country,cycleid));
            reportInfo.add(ownerStatus);
        }
    }

    protected List getCyclesForThisSelection(String period, String country) throws DatabaseException {
        return ownerStatusCountryDAO.getCyclesForSelection(period,country);
    }

    protected List getReportInformation(String period, String country, String cycleid) throws DatabaseException {
        return ownerStatusCountryDAO.setByCountryReportInformation(period,country,cycleid);
    }

    //TODO new methods to implement

    public String returnExportFileNameKey() {
        return "Country";
    }

    public void buildFilterXML(Element rootOutputElement) throws DatabaseException {
        //To change body of implemented methods use File | Settings | File Templates.
    }


}
