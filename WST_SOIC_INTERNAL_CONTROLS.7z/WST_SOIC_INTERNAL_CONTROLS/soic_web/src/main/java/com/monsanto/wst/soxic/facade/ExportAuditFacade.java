package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.audit.util.AuditExporter;
import com.monsanto.wst.soxic.audit.util.HibernateUtil;
import com.monsanto.wst.soxic.audit.dao.ExportSubCycleDAO;
import com.monsanto.wst.soxic.audit.dao.StringSubCycleExportDAOImpl;
import org.hibernate.Session;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 14, 2009
 * Time: 10:23:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportAuditFacade {
  private Map<String, String> cycleStateMap;

  public ExportAuditFacade() {
    populateCycleStateMap();
  }

  public String prepareSubCycleString(String subCycle) throws Exception {

    Session session = HibernateUtil.getHibernateSession();
    ExportSubCycleDAO subCycleDao = new StringSubCycleExportDAOImpl(session);

    // get the cycles
    List subCycleList = subCycleDao.getSubCycleObjs(subCycle);
    if(subCycleList.size() == 0){
          return "NoSubCycles";
    }
    List<String> invalidCycleList = AuditExporter.checkForInvalidCycleState(subCycleList,cycleStateMap);
    if(invalidCycleList != null && invalidCycleList.size() == 0){
        AuditExporter.beginExportXMLConstruction(subCycleList,session, "filepath");
        return "ImportSuccess";
    }else{
        for(String message : invalidCycleList){
            System.err.println(message);
        }
        return "**********************Import Failure ! One or more cycle(s) is in invalid state ! ****************************";
    }
   
//    return subCycleDao.exportAuditXML(subCycle, cycleStateMap);
  }

   private void populateCycleStateMap() {
    if (cycleStateMap == null) {
      cycleStateMap = new HashMap<String, String>();
    }
    cycleStateMap.put("CERT_COMP", "TRUE");
    cycleStateMap.put("PRE_CERTIFICATION", "TRUE");
    cycleStateMap.put("CERTIFICATION", "TRUE");
    cycleStateMap.put("RELEASED", "TRUE");
  }
}
