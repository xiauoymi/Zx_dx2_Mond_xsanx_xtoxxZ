package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SigChangeReportModel;
import com.monsanto.wst.soxic.model.SignificantChangeProcessor;
import com.monsanto.wst.soxic.model.SigChangeReportProcessor;
import com.monsanto.wst.soxic.shared.overflow.OverFlowMap;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 9:34:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class SigReportDAO {

    SigChangeReportProcessor sigChangeReportProcessor = new SigChangeReportProcessor();

    private static String getPeriodsForSigChanges =
                    "SELECT C.PERIOD_ID AS PERIOD " +
                    "FROM CYCLE C, SIGNIFICANT_CHANGE SC " +
                    "WHERE SC.STATUS = ? " +
                    "AND C.CYCLE_ID = SC.CYCLE_ID";

    private static String getCountriesBasedOnPeriodSelected =
                    "SELECT COUNTRY_ID AS COUNTRY " +
                    "FROM CYCLE C, SIGNIFICANT_CHANGE SC " +
                    "WHERE C.CYCLE_ID = SC.CYCLE_ID  " +
                    "AND SC.STATUS = ? " +
                    "AND PERIOD_ID = ?";

    public Set getPeriods() {
        Set periodSet = new HashSet();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getPeriodsForSigChanges);
                preparedStatement.setString(1, SoxicConstants.COMPLETE);

                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    periodSet.add(rs.getString("PERIOD"));
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return periodSet;
    }

    public Set getCountriesBasedOnPeriod(String period) {
        Set countrySet = new HashSet();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getCountriesBasedOnPeriodSelected);
                preparedStatement.setString(1,SoxicConstants.COMPLETE);
                preparedStatement.setString(2,period);
                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    countrySet.add(rs.getString("COUNTRY"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return countrySet;
    }

    public List buildSignificantChangesFromQuery(String sigChangeQuery) {
        List sigChanges = new ArrayList();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        SigChangeReportModel sigChangeReportModel;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(sigChangeQuery);
                rs= preparedStatement.executeQuery();
                OverFlowMap overFlowMap = new OverFlowMap();
                while (rs.next()){
                    sigChangeReportModel = new SigChangeReportModel();
                    sigChangeReportModel.setSeqindex(rs.getString("SEQUENCE"));
                    sigChangeReportModel.setCountry(rs.getString("COUNTRY_ID"));
                    sigChangeReportModel.setCycleId(rs.getString("CYCLE_ID"));
                    sigChangeReportModel.setSelectedType(rs.getString("BUSINESS_TYPE"));
                    sigChangeReportModel.setSelectedPeriod(rs.getString("PERIOD_IMPACTED"));
                    sigChangeReportModel.setAmount(rs.getString("COST"));
                    sigChangeReportModel.setKeyContact(rs.getString("KEY_CONTACT"));
                    sigChangeReportModel.setSubcycles(rs.getString("SUB_CYCLE_IMPACTED"));
                    String desc =rs.getString("DESCRIPTION");
                    String oId = rs.getString("OVERFLOW_ID");
                    String oSeqId = rs.getString("SEQID");
                    String oSeqText = rs.getString("TEXT_CHUNK");
                    sigChangeReportModel.setOverFlowId(oId);
                    sigChangeReportModel.setOverSid(oSeqId);
                    sigChangeReportModel.setOverText(oSeqText);
                    sigChangeReportModel.setDescription(desc);
                    overFlowMap.add(oId,oSeqId,oSeqText,desc);
                    sigChangeReportModel.setOverFlowMap(overFlowMap);
                    sigChanges.add(sigChangeReportModel);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        Map significantMap = sigChangeReportProcessor.processList(sigChanges);
        return (List)new ArrayList(significantMap.values());
    }
}
