/*
 * Created on May 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.exception;

/**
 * @author vrbethi
 */
public class SubCycleAlreadyPresent extends Exception {
	public SubCycleAlreadyPresent(){
		super();
	}
	
	public SubCycleAlreadyPresent(Exception e){
		super(e);
	}	
}
