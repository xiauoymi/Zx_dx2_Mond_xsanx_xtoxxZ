package com.monsanto.wst.soxic.plugin;
import com.monsanto.spreadsheet.ContentSet;
import com.monsanto.spreadsheet.EmptyFileException;
import com.monsanto.spreadsheet.MultisheetWorkbook;
import com.monsanto.spreadsheet.poispreadsheet.POISpreadsheet;
import com.monsanto.spreadsheet.poispreadsheet.POIContentSet;
import com.monsanto.spreadsheet.exception.SpreadsheetException;
import com.monsanto.wst.soxic.model.ActivityDAO;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: May 14, 2009
 * Time: 11:17:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class SoxActivityUpdateRunner {
  private static String filepath = "Activities.xls";
  private static String sheetName = "Priority";


  public static void main(String[] s) {
    ContentSet content = null;
    for (int i = 1; i <= 2; i++) {
      try {
        content = getExcelContent(filepath, sheetName + i);
        updateActivitiesWithPriorities(content,i);
      } catch (EmptyFileException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } catch (SpreadsheetException e) {
        e.printStackTrace();
      } catch(Exception e){
        
      }

    }
  }

  private static void updateActivitiesWithPriorities(ContentSet content, int priorityCode) throws Exception{
    if (content != null) {
      String activityId = "";
      Set<String> activitySet = new HashSet<String>();
      content.next();
      while (content.next()) {
        activityId = content.getString(0);
        activitySet.add(activityId.toUpperCase());
      }
      ActivityDAO.updateActivitiies(activitySet,priorityCode);
    }
  }

  private static ContentSet getExcelContent(String filePath, String sheetName) throws EmptyFileException, IOException, SpreadsheetException {
    MultisheetWorkbook spreadsheet = new POISpreadsheet(new POIContentSet());
    ContentSet content = spreadsheet.getContent(filePath, false, sheetName);
    return content;
  }
}
