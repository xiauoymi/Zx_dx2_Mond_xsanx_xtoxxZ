package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 6, 2005
 * Time: 8:22:51 AM
 */
public class NewPeriodCreationException extends Exception{

  	public NewPeriodCreationException(){
		super();
	}

	public NewPeriodCreationException(Exception e){
		super(e);
	}
}
