package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.NewPeriodForm;
import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;
import com.monsanto.wst.soxic.facade.NewPeriodFacade;
import com.monsanto.wst.soxic.facade.PeriodFacade;
import com.monsanto.wst.soxic.facade.DocumentChangeReviewFacade;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.model.Owner;

import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 28, 2005
 * Time: 11:55:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeReviewDisplay extends Action {

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception{
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;
        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);
        setFormParameters(documentChangeReviewForm,request);

        DocumentChangeReviewFacade documentChangeReviewFacade = new DocumentChangeReviewFacade();
        documentChangeReviewFacade.setFormDetails(documentChangeReviewForm);
        documentChangeReviewFacade.setViewDetails(documentChangeReviewForm,owner);
        documentChangeReviewFacade.initializeParameters(documentChangeReviewForm,owner);
        return mapping.findForward("success");
    }

    private void setFormParameters(DocumentChangeReviewForm documentChangeReviewForm,HttpServletRequest request){
        String url = request.getParameter("documentChangeURL");
        documentChangeReviewForm.setUrl(url);
//        StringTokenizer st = new StringTokenizer(url,SoxicUtil.getSeperator());
//        String activityIdentifier = st.nextToken();
//        String sourceType = st.nextToken();
//        String requestType = st.nextToken();
//        String mode = st.nextToken();
//        String responseId="";
//        if(mode.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW)){
//            String update = st.nextToken();
//            if(update.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE)){
//               documentChangeReviewForm.setViewUpdateButton(true);
//            }else{
//               documentChangeReviewForm.setViewUpdateButton(false);
//            }
//
//            responseId = st.nextToken();
//        }
//
//        documentChangeReviewForm.setIdentifier(activityIdentifier);
//        documentChangeReviewForm.setSource_type(sourceType);
//        documentChangeReviewForm.setRequest_type(requestType);
//        documentChangeReviewForm.setMode(mode);
//        documentChangeReviewForm.setOcreqResponse(responseId);
    }
}
