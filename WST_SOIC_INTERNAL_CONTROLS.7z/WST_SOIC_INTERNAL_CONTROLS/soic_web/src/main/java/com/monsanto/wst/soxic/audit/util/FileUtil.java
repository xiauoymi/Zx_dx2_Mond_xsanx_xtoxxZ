package com.monsanto.wst.soxic.audit.util;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 9, 2008
 * Time: 11:38:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class FileUtil {
  private static String fileLocation;
  private static String errorFileLocation;

//  static {
//    if (System.getProperty("catalina.base") != null) {
//      fileLocation = System.getProperty("catalina.base") + "\\temp\\AuditExport.xml";
//      errorFileLocation = System.getProperty("catalina.base") + "\\temp\\AuditExportError.csv";
//    }
//  }
  static {
    if (System.getProperty("server.logs") != null) {
        if(System.getProperty("auditfolder") != null) {
            fileLocation = System.getProperty("auditfolder") + "\\output\\AuditExport.xml";
            errorFileLocation = System.getProperty("auditfolder")+ "\\output\\AuditExportError.csv";
        } else {
            String tmpDir = System.getProperty("java.io.tmpdir");
            fileLocation = tmpDir + "\\AuditExport.xml";
            errorFileLocation = tmpDir+ "\\AuditExportError.csv";
            System.out.println("tmpDir " + tmpDir);
        }
    }
  }

  public static void writeToFile(StringBuffer auditXml) throws IOException {
    File outputFile = new File(fileLocation);
    write(auditXml, outputFile);

  }

  public static void writeToFile(StringBuffer auditXml,String filePath) throws IOException {
    File outputFile = new File(filePath);
    write(auditXml, outputFile);

  }

  private static void write(StringBuffer auditXml, File outputFile) {
    Writer stringWriter = null;
    if (!outputFile.exists()) {
      try {
        outputFile.createNewFile();
      } catch (IOException e) {
        System.err.println("*******Error Creating a new File*********** ");
        e.printStackTrace();
      }
    }
    try {
      stringWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile, true)));
      stringWriter.write(auditXml.toString());
      stringWriter.flush();
      stringWriter.close();
    } catch (IOException e) {
      System.err.println("******Exception in writing to a file************* ");
      e.printStackTrace();
    }
  }


  public static boolean deleteFileIfPresent(String filePath) {
    boolean fileDeleted = true;

    File file = new File(filePath);
    if (file.exists()) {
      fileDeleted = file.delete();
      if(!fileDeleted){

        try {
          FileWriter writer = new FileWriter(file);
          writer.close();
          System.out.println("***********Going to Delete the file**********"+file.delete());
        } catch (IOException e) {
          e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
      }
    }

    return fileDeleted;
  }

  public static String readSubCyclesFromFile() throws Exception {
    String subCycles = "";
    String fileLoc = System.getProperty("MONCRYPTJV");
    File file = new File(fileLoc + "\\SubCycleQuarter.txt");
    BufferedReader propsFileReader = null;
    if (!file.exists()) {
      throw new Exception("Please place SubCycleQuarter.txt in : " + fileLoc);
    } else {
      propsFileReader = new BufferedReader(new FileReader(file));
      subCycles = propsFileReader.readLine();
    }
    return subCycles;
  }

  public static String getFileLocation() {
    return fileLocation;
  }

  public static String getErrorFileLocation() {
    return errorFileLocation;
  }

  public static void writeErrorMessageToFile(StringBuffer errorBuffer) {
      File outputFile = new File(errorFileLocation);
      write(errorBuffer,outputFile);
  }
}
