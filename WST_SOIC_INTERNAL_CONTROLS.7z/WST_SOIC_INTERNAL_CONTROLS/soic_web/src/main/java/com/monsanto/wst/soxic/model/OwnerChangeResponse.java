package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 2, 2005
 * Time: 5:05:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerChangeResponse {
}
