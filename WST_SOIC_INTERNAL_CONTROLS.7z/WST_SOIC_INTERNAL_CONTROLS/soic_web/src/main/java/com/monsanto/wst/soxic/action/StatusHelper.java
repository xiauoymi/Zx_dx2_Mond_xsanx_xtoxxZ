/*
 * Created on Mar 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.sql.Date;

import javax.servlet.http.HttpServletRequest;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.form.CycleViewForm;
import com.monsanto.wst.soxic.form.SubCycleViewForm;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class StatusHelper {

    public void setStatus(HttpServletRequest request, String identifier,
                          List activityList, String level, String ownerid) throws Exception {
        if (level.equalsIgnoreCase("C")) {
            String ownerCycleStatus = getCycleOwnerStatus(identifier, ownerid);
            ownerCycleStatus = getSignificantChangeStatusAndSetOwnerCycleStatus(identifier, ownerid, ownerCycleStatus);
            setOwnerCycleStatus(ownerid, identifier, ownerCycleStatus);
            setGapPresentToTrueForCycle(request, identifier, ownerCycleStatus);
            String cycleStatus = getCycleStatus(identifier);
            setCycleStatus(identifier, ownerid, cycleStatus);
        }
        if (level.equalsIgnoreCase("S")) {
            String ownerSubCycleStatus = getSubCycleOwnerStatus(identifier,
                    ownerid);
            setOwnerSubCycleStatus(ownerid, identifier, ownerSubCycleStatus);
            setGapPresentToTrueForSubcycle(request, identifier,
                    ownerSubCycleStatus);
            String subCycleStatus = getSubCycleStatus(identifier);
            setSubCycleStatus(identifier, ownerid, subCycleStatus);
        }
        if (level.equalsIgnoreCase("A")) {
            //insert(gapList,ownerid);
            setActivityStatus(activityList, ownerid);
            setGapPresentToTrue(request, identifier, ownerid, activityList);
        }
        if(level.equalsIgnoreCase("AS")){
            setGapPresentToTrueForActivitySubCycle(request,identifier,activityList);
        }
    }

    private void setActivityStatus(List activityList, String ownerid)
            throws Exception {

        Iterator activityIterator = activityList.iterator();

        while (activityIterator.hasNext()) {

            Activity activity = (Activity) activityIterator.next();

            String activityOwnerStatus = getActivityOwnerStatus(activity
                    .getActivityId(), ownerid);

            setOwnerActivityStatus(ownerid, activity.getActivityId(),
                    activityOwnerStatus);

            String activityStatus = getActivityStatus(activity.getActivityId());

            setIndividualActivityStatus(activity.getActivityId(), ownerid,
                    activityStatus);

        }
    }

    public void setOtherActivityStatus(List activityList, String ownerid,
                                       String status) throws Exception {

        GapHelper gapHelper = new GapHelper();
        Iterator activityIterator = activityList.iterator();

        while (activityIterator.hasNext()) {

            Activity activity = (Activity) activityIterator.next();

            gapHelper
                    .updateOwnerResponseStatusOtherActivity(activity
                            .getActivityId(), activity.getQuestionId(),
                            ownerid, status);

            String activityOwnerStatus = getActivityOwnerStatus(activity
                    .getActivityId(), ownerid);

            setOwnerActivityStatus(ownerid, activity.getActivityId(),
                    activityOwnerStatus);

            String activityStatus = getActivityStatus(activity.getActivityId());

            setIndividualActivityStatus(activity.getActivityId(), ownerid,
                    activityStatus);

        }
    }

    public void setActivityStatus(Activity activity, String ownerid)
            throws Exception {

        String activityOwnerStatus = getActivityOwnerStatus(activity
                .getActivityId(), ownerid);

        setOwnerActivityStatus(ownerid, activity.getActivityId(),
                activityOwnerStatus);

        String activityStatus = getActivityStatus(activity.getActivityId());

        setIndividualActivityStatus(activity.getActivityId(), ownerid,
                activityStatus);
    }

    public String setCycleStatus(String identifier, String ownerid)
            throws Exception {
        String ownerCycleStatus = getCycleOwnerStatus(identifier, ownerid);
        ownerCycleStatus = getSignificantChangeStatusAndSetOwnerCycleStatus(identifier, ownerid, ownerCycleStatus);
        setOwnerCycleStatus(ownerid, identifier, ownerCycleStatus);
        String cycleStatus = getCycleStatus(identifier);
        setCycleStatus(identifier, ownerid, cycleStatus);
        return ownerCycleStatus;
    }

    private String getSignificantChangeStatusAndSetOwnerCycleStatus(String identifier, String ownerid, String ownerCycleStatus) {
        String sigChangeStatus = CycleStatusDAO.getSigChangeStatus(identifier,ownerid);
        if (ownerCycleStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) && (sigChangeStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE))){
            ownerCycleStatus = SoxicConstants.GREEN_COMPLETE;
        }
        else
        {
            ownerCycleStatus = setStatusBasedOnDate(identifier, ownerid, ownerCycleStatus);
        }
        return ownerCycleStatus;
    }

    private String setStatusBasedOnDate(String identifier, String ownerid, String ownerCycleStatus) {
        Date dueDate = CycleStatusDAO.getDueDateForCycleAndOwner(identifier,ownerid);
        if(dueDate!=null)
        {
            ownerCycleStatus = (SoxicUtil.returnStatusPreceedingStr(dueDate)+ "INPROC");
        }
        return ownerCycleStatus;
    }

    public void setSubCycleStatus(String identifier, String ownerid,
                                  List subCycleList) throws Exception {
        String ownerSubCycleStatus = getSubCycleOwnerStatus(identifier, ownerid);
        setOwnerSubCycleStatus(ownerid, identifier, ownerSubCycleStatus);
        String subCycleStatus = getSubCycleStatus(identifier);
        setSubCycleStatus(identifier, ownerid, subCycleStatus);

        Iterator subcycleIterator = subCycleList.iterator();

        while (subcycleIterator.hasNext()) {
            SubCycle subCycle = (SubCycle) subcycleIterator.next();
            if (subCycle.getSubCycleId().equalsIgnoreCase(identifier)) {
                subCycle.setStatus(ownerSubCycleStatus);
            }
        }
    }

    /**
     * @param request
     * @param subCycleId
     */
    private void setGapPresentToTrueForSubcycle(HttpServletRequest request,
                                                String subCycleId, String status) {

        SubCycleViewForm subCycleViewForm = (SubCycleViewForm) request
                .getSession().getAttribute("subCycleViewForm");

        Collection subCycleList = subCycleViewForm.getSubCycles();

        Iterator subCycleListIterator = subCycleList.iterator();

        while (subCycleListIterator.hasNext()) {

            SubCycle subcycle = (SubCycle) subCycleListIterator.next();

            if (subcycle.getSubCycleId().equalsIgnoreCase(subCycleId)) {
                subcycle.setGap("Y");
                subcycle.setStatus(status);
            }
        }
    }

    /**
     * @param request
     * @param subCycleId
     */
    private void setGapPresentToTrueForActivitySubCycle(HttpServletRequest request,String subCycleId,
                                                        List activityList) {

        SubCycleViewForm subCycleViewForm = (SubCycleViewForm) request
                .getSession().getAttribute("subCycleViewForm");

        Activity activity = (Activity)activityList.get(0);

        Collection subCycleList = subCycleViewForm.getSubCycles();

        Iterator subCycleListIterator = subCycleList.iterator();

        while (subCycleListIterator.hasNext()) {

            SubCycle subcycle = (SubCycle) subCycleListIterator.next();

            //if (subcycle.getSubCycleId().equalsIgnoreCase(subCycleId)) {

                List controlObjectiveList = (List)subcycle.getControlObjectives();

                Iterator controlObjectiveIterator = controlObjectiveList.iterator();

                while(controlObjectiveIterator.hasNext()){
                    ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew)controlObjectiveIterator.next();

                    Iterator activityIterator = controlObjectiveNew.getActivities().iterator();

                    while(activityIterator.hasNext()){

                        ActivityNew activityNew = (ActivityNew)activityIterator.next();

                        if((activityNew.getActivityId().equalsIgnoreCase(activity.getActivityId()))){
                            activityNew.setGap("Y");
                        }
                    }
                }

            //}
        }
    }

    /**
     * @param request
     *
     */
    private void setGapPresentToTrueForCycle(HttpServletRequest request,
                                             String cycleId, String status) {

        CycleViewForm cycleViewForm = (CycleViewForm) request.getSession()
                .getAttribute("cycleViewForm");

        Collection cycleList = cycleViewForm.getCycles();

        Iterator cycleListIterator = cycleList.iterator();

        while (cycleListIterator.hasNext()) {

            Cycle cycle = (Cycle) cycleListIterator.next();

            if (cycle.getCycleId().equalsIgnoreCase(cycleId)) {
                cycle.setGap("Y");
                cycle.setStatus(status);
            }
        }
    }

    public void setCycleStatus(HttpServletRequest request, String cycleId,
                               String status) {
        CycleViewForm cycleViewForm = (CycleViewForm) request.getSession()
                .getAttribute("cycleViewForm");

        Collection cycleList = cycleViewForm.getCycles();

        Iterator cycleListIterator = cycleList.iterator();

        while (cycleListIterator.hasNext()) {

            Cycle cycle = (Cycle) cycleListIterator.next();

            if (cycle.getCycleId().equalsIgnoreCase(cycleId)) {

                cycle.setStatus(status);
            }
        }
    }

    /**
     * Sets the control Objective gap present to true
     *
     * @param request
     * @param controlObjectiveId
     * @throws Exception
     */
    public void setGapPresentToTrue(HttpServletRequest request,
                                    String controlObjectiveId, String ownerid, List activityList)
            throws Exception {

        ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) request
                .getSession().getAttribute("controlObjectiveForm");

        Collection controlObjectiveList = controlObjectiveForm
                .getControlObjectiveList();

        Iterator controlListIterator = controlObjectiveList.iterator();

        while (controlListIterator.hasNext()) {

            ControlObjective controlObjective = (ControlObjective) controlListIterator
                    .next();

            if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
                    controlObjectiveId)) {

                Iterator activityIterator = activityList.iterator();

                while (activityIterator.hasNext()) {
                    Activity activity = (Activity) activityIterator.next();

                    if (activity.getResponseGapList() != null
                            && activity.getResponseGapList().size() > 0) {
                        controlObjective.addToGapList("new gap");
                        controlObjectiveForm.setStatusForControlObjective(
                                controlObjectiveId, ((Owner) request
                                        .getSession().getAttribute("owner"))
                                        .getOwnerId());
                        StatusDAO statusDAO = new StatusDAO();
                        String status = statusDAO.getStatus(
                                SoxicConstants.CONTROLOBJECTIVE,
                                controlObjectiveId);
                        statusDAO.updateStatus(SoxicConstants.CONTROLOBJECTIVE,
                                ownerid, controlObjectiveId, status);
                    }
                }
            }
        }
    }

    private String getCycleOwnerStatus(String identifier, String ownerid)
            throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getOwnerStatus(SoxicConstants.CYCLE, ownerid,
                identifier);

    }

    public String getCycleStatus(String identifier) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getStatus(SoxicConstants.CYCLE, identifier);

    }

    private String getActivityStatus(String identifier) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getStatus(SoxicConstants.ACTIVITY, identifier);

    }

    private String getSubCycleStatus(String identifier) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getStatus(SoxicConstants.SUBCYCLE, identifier);
    }

    private String getSubCycleOwnerStatus(String identifier, String ownerid)
            throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getOwnerStatus(SoxicConstants.SUBCYCLE, ownerid,
                identifier);

    }

    private String getActivityOwnerStatus(String identifier, String ownerid)
            throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        return statusDAO.getOwnerStatus(SoxicConstants.ACTIVITY, ownerid,
                identifier);

    }

    public void setCycleStatus(String identifier, String ownerid, String status)
            throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateStatus(SoxicConstants.CYCLE, ownerid, identifier,
                status);
    }

    private void setSubCycleStatus(String identifier, String ownerid,
                                   String status) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateStatus(SoxicConstants.SUBCYCLE, ownerid, identifier,
                status);
    }

    private void setIndividualActivityStatus(String identifier, String ownerid,
                                             String status) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateStatus(SoxicConstants.ACTIVITY, ownerid, identifier,
                status);
    }

    public void setOwnerCycleStatus(String ownerid, String identifier,
                                     String status) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateOwnerStatus(SoxicConstants.CYCLE, ownerid, identifier,
                status, true);
    }

    private void setOwnerSubCycleStatus(String ownerid, String identifier,
                                        String status) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateOwnerStatus(SoxicConstants.SUBCYCLE, ownerid,
                identifier, status, true);
    }

    private void setOwnerActivityStatus(String ownerid, String identifier,
                                        String status) throws Exception {
        StatusDAO statusDAO = new StatusDAO();
        statusDAO.updateOwnerStatus(SoxicConstants.ACTIVITY, ownerid,
                identifier, status, true);
    }
}