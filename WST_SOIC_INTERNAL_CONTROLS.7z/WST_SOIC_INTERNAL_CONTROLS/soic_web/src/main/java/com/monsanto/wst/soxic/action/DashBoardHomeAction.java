package com.monsanto.wst.soxic.action;

import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.facade.DashBoardHomeFacade;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.form.DashBoardHomeForm;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 1, 2006
 * Time: 3:41:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class DashBoardHomeAction extends Action {

    List typeList = new ArrayList();

    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response) throws Exception{

        DashBoardHomeForm dashBoardHomeForm = (DashBoardHomeForm)form;
        ActionMessages messages = new ActionMessages();
        Owner owner = (Owner) request.getSession().getAttribute("owner");

        DashBoardHomeFacade dashBoardHomeFacade = new DashBoardHomeFacade();
        buildDashBoard(dashBoardHomeFacade, owner.getOwnerId(), messages, request, dashBoardHomeForm);
        return mapping.findForward("dashBoardDisplay");
    }

    public void buildDashBoard(DashBoardHomeFacade dashBoardHomeFacade, String ownerid, ActionMessages messages, HttpServletRequest request, DashBoardHomeForm dashBoardHomeForm) {
        processForOwnerInSystem(dashBoardHomeFacade, ownerid, messages, request, dashBoardHomeForm);
    }

    private void processForOwnerInSystem(DashBoardHomeFacade dashBoardHomeFacade, String ownerid, ActionMessages messages, HttpServletRequest request, DashBoardHomeForm dashBoardHomeForm) {
        List ownercycles = dashBoardHomeFacade.getCycleDetailsForOwner(ownerid);
        List ownersubcycles = dashBoardHomeFacade.getSubCycleDetailsForOwner(ownerid);
        List owneractivities = dashBoardHomeFacade.getActivityDetailsForOwner(ownerid);
        checkForOwnerCertifications(ownercycles, ownersubcycles, owneractivities, messages, request, dashBoardHomeForm);
    }

    private void checkForOwnerCertifications(List ownercycles, List ownersubcycles, List owneractivities, ActionMessages messages, HttpServletRequest request, DashBoardHomeForm dashBoardHomeForm) {
        if (ownercycles.size()==0 && ownersubcycles.size()==0 && owneractivities.size()==0){
            displayMessageForNoCertificationsAvaliable(messages, request);
        }
        else{
            setCertificationTypesIntoForm(ownercycles, dashBoardHomeForm, ownersubcycles, owneractivities);
        }
    }

    public void setCertificationTypesIntoForm(List ownercycles, DashBoardHomeForm dashBoardHomeForm, List ownersubcycles, List owneractivities) {
        if (ownercycles!=null && ownercycles.size()>0){
            dashBoardHomeForm.setCycles(ownercycles);
        }
        if (ownersubcycles!=null && ownersubcycles.size()>0){
            dashBoardHomeForm.setSubcycles(ownersubcycles);
        }
        if (owneractivities!=null && owneractivities.size()>0){
            dashBoardHomeForm.setActivities(owneractivities);
        }
    }

    private void displayMessageForNoCertificationsAvaliable(ActionMessages messages, HttpServletRequest request) {
        messages.add(ActionMessages.GLOBAL_MESSAGE,new ActionMessage(SoxicConstants.NO_CERTIFICATIONS_FOR_USER));
        saveMessages(request,messages);
    }
}
