/*
 * Created on Jan 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Status implements Serializable {
    
    public static final String INPROCESS   = "Inprocess";
        
    public static final String NOT_STARTED = "Not Started";
    
    public static final String COMPLETE    = "Complete";
        
    private String currentStatus;
    
    public Status(String string){
    	currentStatus = string;
    }
    
	/**
	 * @return Returns the currentStatus.
	 */
	public String getCurrentStatus() {
		return currentStatus;
	}
	/**
	 * @param currentStatus The currentStatus to set.
	 */
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

    public static void main(String[] args) {
    }
}
