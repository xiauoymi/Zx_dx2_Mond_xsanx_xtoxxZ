package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.exception.SigChangeListException;
import com.monsanto.wst.soxic.facade.SignificantChangeFacade;
import com.monsanto.wst.soxic.form.SignificantChangeForm;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 14, 2006
 * Time: 11:53:34 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SignificantChangeReportingInterface {

    public void createSignificantChangeReporting(SignificantChangeForm significantChangeForm, SignificantChangeFacade significantChangeFacade, String type) throws SigChangeListException;

}
