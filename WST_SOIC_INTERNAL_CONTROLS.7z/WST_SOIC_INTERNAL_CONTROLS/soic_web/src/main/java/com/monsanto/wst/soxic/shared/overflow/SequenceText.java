package com.monsanto.wst.soxic.shared.overflow;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 24, 2005
 * Time: 3:00:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class SequenceText implements Comparable{

    private String sequence;
    private String text;

    public SequenceText(String sequence, String text) {
        this.sequence = sequence;
        this.text = text;
    }

    public SequenceText(String text) {
        this.text = text;
    }

    public String getSequence() {
        return sequence;
    }

    public String getText() {
        return text;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int compareTo(Object o) {
        if(o instanceof SequenceText)  {
            return sequence.compareTo(((SequenceText)o).getSequence());
        }
        return sequence.compareTo(((SequenceText)o).getSequence());
    }    
}
