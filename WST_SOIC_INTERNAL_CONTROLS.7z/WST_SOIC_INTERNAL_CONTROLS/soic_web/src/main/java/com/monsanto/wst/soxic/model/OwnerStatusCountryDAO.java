package com.monsanto.wst.soxic.model;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 21, 2005
 * Time: 10:32:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusCountryDAO {

    private PersistentStoreConnection createPersistentStore() throws WrappingException {
        PersistentStore persistentStore = WST_SOX_PersistentStoreFactory.getStore();
        PersistentStore.registerInstance(persistentStore);
        PersistentStoreConnection psConnection = persistentStore.connect();
        return psConnection;
    }

    private void closePersistentConnection(PersistentStoreStatement persistentStoreStatement, PersistentStoreConnection psConnection) throws DatabaseException {
        if(persistentStoreStatement != null){
            try {
                persistentStoreStatement.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
        if(psConnection != null){
            try {
                psConnection.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
    }


    public List setByCountryReportInformation(String period, String country, String cycleid) throws DatabaseException {
        List ownerInfo = new ArrayList();
        ReportOwners reportOwners = null;
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement
                    ("SELECT C.CYCLE_ID,OC.OWNER_ID,O.NAME,O.LOCATION,OC.STATUS " +
                    "FROM CYCLE C, OWNER_CYCLE OC, OWNER O " +
                    "WHERE OC.CYCLE_ID = C.CYCLE_ID " +
                    "AND OC.OWNER_ID = O.OWNER_ID " +
                    "AND C.PERIOD_ID = ? " +
                    "AND C.COUNTRY_ID = ? " +
                    "and c.CYCLE_ID = ? ");
            persistentStoreStatement.setParam(1,period);
            persistentStoreStatement.setParam(2,country);
            persistentStoreStatement.setParam(3,cycleid);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                String owner = persistentStoreResultSetFwdIterator.getString("NAME");
                String location = persistentStoreResultSetFwdIterator.getString("LOCATION");
                String status = persistentStoreResultSetFwdIterator.getString("STATUS");
                if (status.equalsIgnoreCase(SoxicConstants.COMPLETE)){
                    status = "COMPLETE";
                }
                else status = "-";
                reportOwners = new ReportOwners(owner,location,status);
                ownerInfo.add(reportOwners);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(ownerInfo);
        return ownerInfo;
    }

    public List getCyclesForSelection(String period, String country) throws DatabaseException {
        List cycles = new ArrayList();
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement
                    ("SELECT CYCLE_ID FROM CYCLE WHERE PERIOD_ID = ? AND COUNTRY_ID = ?");
            persistentStoreStatement.setParam(1,period);
            persistentStoreStatement.setParam(2,country);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                setCycleIntoList(persistentStoreResultSetFwdIterator, cycles);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(cycles);
        return cycles;
    }

    private void setCycleIntoList(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator, List cycles) throws WrappingException {
        String cycleid = persistentStoreResultSetFwdIterator.getString("CYCLE_ID");
        cycles.add(cycleid);
    }
}
