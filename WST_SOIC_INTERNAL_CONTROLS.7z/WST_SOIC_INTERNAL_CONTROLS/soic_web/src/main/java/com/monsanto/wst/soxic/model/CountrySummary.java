/*
 * Created on Jun 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CountrySummary {
	
	private int numberOfControlObjectives;
	
	private int numberOfActivities;
	
	private int numberOfOwners;
	
	List cycleList;
	
	List progressPercentage= new ArrayList();
	
	private String countryName;
	
	private String color;
	
	private String period;
	
	
	
	
	
	
	
	
	/**
	 * @return Returns the period.
	 */
	public String getPeriod() {
		return period;
	}
	/**
	 * @param period The period to set.
	 */
	public void setPeriod(String period) {
		this.period = period;
	}
	/**
	 * @return Returns the color.
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color The color to set.
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return Returns the countryName.
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName The countryName to set.
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * @return Returns the cycleList.
	 */
	public List getCycleList() {
		return cycleList;
	}
	/**
	 * @param cycleList The cycleList to set.
	 */
	public void setCycleList(List cycleList) {
		this.cycleList = cycleList;
	}
	/**
	 * @return Returns the numberOfActivities.
	 */
	public int getNumberOfActivities() {
		return numberOfActivities;
	}
	/**
	 * @param numberOfActivities The numberOfActivities to set.
	 */
	public void setNumberOfActivities(int numberOfActivities) {
		this.numberOfActivities = numberOfActivities;
	}
	/**
	 * @return Returns the numberOfControlObjectives.
	 */
	public int getNumberOfControlObjectives() {
		return numberOfControlObjectives;
	}
	/**
	 * @param numberOfControlObjectives The numberOfControlObjectives to set.
	 */
	public void setNumberOfControlObjectives(int numberOfControlObjectives) {
		this.numberOfControlObjectives = numberOfControlObjectives;
	}
	/**
	 * @return Returns the numberOfOwners.
	 */
	public int getNumberOfOwners() {
		return numberOfOwners;
	}
	/**
	 * @param numberOfOwners The numberOfOwners to set.
	 */
	public void setNumberOfOwners(int numberOfOwners) {
		this.numberOfOwners = numberOfOwners;
	}
	/**
	 * @return Returns the progressPercentage.
	 */
	public List getProgressPercentage() {
		return progressPercentage;
	}
	/**
	 * @param progressPercentage The progressPercentage to set.
	 */
	public void setProgressPercentage(List progressPercentage) {
		this.progressPercentage = progressPercentage;
	}
	
	public void addProgressPercentage(String percentage){
		
		progressPercentage.add(""+percentage);
		
	}
}
