/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.OwnerResponse;
import com.monsanto.wst.soxic.model.OwnerResponseHistory;
import com.monsanto.wst.soxic.model.QuestionNew;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.model.SubCycle;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleQuestionDAO extends OracleAbstractDAO{
    
    
    private String ownerId;
    private String queryType;
       
    protected String buildSelectQuery(Map criteria) {
        
        ownerId = (String)criteria.remove(Owner.OWNER_ID);
        
        String query = "";
        queryType = criteria.get("QUERY_TYPE").toString();
        
        if(queryType.equals("SUB_CYCLE")){
            
            query = buildSubCycleQuestionsQuery(criteria.get(SubCycle.SUB_CYCLE_ID).toString());
        }
        else if(queryType.equals("CYCLE")){
            query = buildCycleQuestionsQuery(criteria.get(Cycle.CYCLE_ID).toString());
        }
        
		return query;

	}
    
    private String buildSubCycleQuestionsQuery(String subCycleId){
        
        StringBuffer query = new StringBuffer();
        
        query.append("SELECT Q.QUESTION_ID, Q.QUESTION, S.SUB_CYCLE_ID FROM QUESTION Q, QUESTION_SUB_CYCLE S " +
                     "WHERE Q.QUESTION_ID = S.QUESTION_ID AND ");
        
        query.append("S.SUB_CYCLE_ID ='"+ subCycleId +"' ORDER BY Q.QUESTION_ID");
               
        return query.toString();
    }
    
    private String buildCycleQuestionsQuery(String cycleId){
        
        StringBuffer query = new StringBuffer();
        
        query.append("SELECT Q.QUESTION_ID, Q.QUESTION, C.CYCLE_ID FROM QUESTION Q, QUESTION_CYCLE C " +
                     "WHERE Q.QUESTION_ID = C.QUESTION_ID AND ");
        
        query.append("C.CYCLE_ID ='"+ cycleId +"' ORDER BY Q.QUESTION_ID");
               
        return query.toString();
    }
 
    protected SoxicBaseModel populateModel(ResultSet rs){
 	   
 	    QuestionNew question  = new QuestionNew();
 	    try {
 	        question.setOwnerId(ownerId);
 			question.setQuestionId(rs.getString(QuestionNew.QUESTION_ID));
 			question.setQuestion(rs.getString(QuestionNew.QUESTION));
 			if(queryType.equals("SUB_CYCLE")){
 			   question.setAssociatedId(rs.getString(SubCycle.SUB_CYCLE_ID));
 			   question.setAssociatedType("S");
 			}
 			else if(queryType.equals("CYCLE")){
 			   question.setAssociatedId(rs.getString(Cycle.CYCLE_ID)); 
 			   question.setAssociatedType("C");
 			}
 			
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
 	    
 	    
 		return question;
 	}
    
    public void update(Collection soxicBaseModels) throws DatabaseException {
		Connection connection = null;
		Statement statement = null;
		OwnerResponseDAO ownerResponseDAO=null;
		OwnerResponseHistoryDAO ownerResponseHistoryDAO = null;
		Iterator itr = soxicBaseModels.iterator();
		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			statement = connection.createStatement();

			while (itr.hasNext()) {
				QuestionNew question = (QuestionNew) itr.next();
				//if(question.isAnswerModified()){
				   statement.executeQuery(buildQuery(question));
				   //after successfull execution of Insert/Update change the responseType in the question object as "UPDATE";
				   question.setResponseType("UPDATE");
				   ownerResponseDAO = new OwnerResponseDAO();
				   OwnerResponse ownerResponse = new OwnerResponse();
				   ownerResponse.setAssociatedId(question.getAssociatedId());
				   ownerResponse.setOwnerid(question.getOwnerId());
				   ownerResponse.setQuestionid(Integer.parseInt(question.getQuestionId()));
				   ownerResponse.setResponse(question.getAnswer());
				   ownerResponseDAO.retrieve(ownerResponse,OwnerResponseDAO.RESPONSE_ID);
				   OwnerResponseHistory ownerResponseHistory = new OwnerResponseHistory();
				   ownerResponseHistory.setResponseId(ownerResponse.getResponseid());
				   ownerResponseHistory.setResponse(ownerResponse.getResponse());
				   ownerResponseHistory.setOwnerid(ownerResponse.getOwnerid());
				   ownerResponseHistoryDAO = new OwnerResponseHistoryDAO();
				   ownerResponseHistoryDAO.insert(ownerResponseHistory);
				   
				//}
			}
		} 
		catch (Exception e) {
			throw new DatabaseException(e);
		} 
		finally {
			try {
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} 
			catch (SQLException e) {
				throw new DatabaseException("OracleDAO - Unable to close database connection : " + e.toString());
			}
		}
	}
	
	/**
     * @param question
     * @return
     */
    private String buildQuery(QuestionNew question) {
        
        String query = "";
        if(question.getResponseType().equals("INSERT")){
            query = buildInsertQuery(question);
        }
        else if(question.getResponseType().equals("UPDATE")){
            query = buildUpdateQuery(question);
        }
        return query;
    }
    
    private String buildInsertQuery(QuestionNew question){
        
        StringBuffer query = new StringBuffer();
        
        query.append("INSERT into OWNER_RESPONSE ( ");
        
        query.append(QuestionNew.OWNER_ID        +", ");
        query.append(QuestionNew.QUESTION_ID     +", ");
        query.append(QuestionNew.ASSOCIATED_ID   +", ");
        query.append(QuestionNew.ASSOCIATED_TYPE +", ");
        query.append(QuestionNew.RESPONSE        +", ");
        query.append(QuestionNew.STATUS          +", ");
        query.append(QuestionNew.MOD_DATE        +", ");
        query.append(QuestionNew.MOD_USER        + ")");
        
        query.append(" VALUES (");
        
        query.append("'" + question.getOwnerId()       + "', ");
        query.append("'" + question.getQuestionId()    + "', ");
        query.append("'" + question.getAssociatedId()  + "', ");
        query.append("'" + question.getAssociatedType()+ "', ");
        query.append("'" + question.getAnswer()        + "', ");
        query.append("'" + question.getStatus()        + "', ");
        query.append("to_date ('"
					+ new SimpleDateFormat("MM/dd/yyyy").format(new java.util.Date())
					+ "', 'MM/dd/yyyy'), ");
       
        query.append("'" + question.getModifiedUser()  + "' )");
        
        return query.toString();
    
    }


    private String buildUpdateQuery(QuestionNew question){
	    
	    StringBuffer updateQuery = new StringBuffer();
	    
	    updateQuery.append("UPDATE OWNER_RESPONSE SET ");
	    
	    updateQuery.append(QuestionNew.RESPONSE + "=");
	    updateQuery.append("'" + question.getAnswer()+ "' , ");
	    
	    updateQuery.append(QuestionNew.STATUS + "=");
	    updateQuery.append("'" + question.getStatus()+ "' , ");
	    
	    updateQuery.append(QuestionNew.MOD_DATE + "=");
	    updateQuery.append("to_date('"
				+ new SimpleDateFormat("MM/dd/yyyy").format(new java.util.Date())
				+ "', 'MM/dd/yyyy')");
	    
	    updateQuery.append(" where ");
	    
	    updateQuery.append(QuestionNew.OWNER_ID + "=");
	    updateQuery.append("'" + question.getOwnerId()+ "'");
	    
	    updateQuery.append(" and ");
	    
	    updateQuery.append(QuestionNew.QUESTION_ID + "=");
	    updateQuery.append("'" + question.getQuestionId()+ "'");
	    
	    updateQuery.append(" and ");
	    
	    updateQuery.append(QuestionNew.ASSOCIATED_ID + "=");
	    updateQuery.append("'" + question.getAssociatedId()+ "'");
	    
	    updateQuery.append(" and ");
	    
	    updateQuery.append(QuestionNew.ASSOCIATED_TYPE + "=");
	    updateQuery.append("'" + question.getAssociatedType()+ "'");
	    
	    return updateQuery.toString();
		
	}

    public int create(SoxicBaseModel soxicBaseModel){
        return -1;
    }

}
