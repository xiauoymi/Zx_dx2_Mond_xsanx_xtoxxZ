/*
 * Created on Mar 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.javamail;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Category;

import com.monsanto.wst.soxic.action.ExportAction;

import com.monsanto.wst.soxic.util.SoxicUtil;



/**
 * JavaMailComponent Class: To send simple email messages,
 * Html messages and Html messages with Images. 
 * 
 * Just call the static method "sendMail()" with appropriate arguments.
 * 
 * @author Rasesh
 *
 */
public class JavaMailComponent {
	
	//**Log4j logger
    private static Category logger = Category.getInstance(ExportAction.class.getName());
	
    //**Read smtp server name from a property file...
    private static String host = SoxicUtil.getSmtpServerName();
    
    
    
    /**
     * Method to just builds the message body
     * for simple message.
     *
     */
    public static void setMessageBody(Message message, String msg){
    	try{
    		message.setText(msg);

			transportMail(message);	
    	}
    	catch(Exception ex){
			logger.error("Java Mail Error with setting Message Body: " + ex.getMessage());
		}
    }
    
    /**
     * Method to just builds the message body
     * for Html message.
     *
     */
    public static void setHtmlMessageBody(Message message, String msg){
    	try{
    		message.setContent(msg, "text/html; charset=ISO-8859-1");
    		//message.setContent(msg , "iso-8859-1");
			transportMail(message);	
    	}
    	catch(Exception ex){
			logger.error("Java Mail Error with setting Message Body: " + ex.getMessage());
		}
    }
    
    /**
     * Method to just builds the message body
     * for Html message.
     *
     */
    public static void setHtmlImageMessageBody(Message message, String msg, String imageFilePath){
    	try{
    		//**Create your new message part
			BodyPart messageBodyPart = new MimeBodyPart();
			
			messageBodyPart.setContent(msg, "text/html");

			//**Create a related multi-part to combine the parts
			MimeMultipart multipart = new MimeMultipart("related");
			multipart.addBodyPart(messageBodyPart);

			//**Create part for the image
			messageBodyPart = new MimeBodyPart();

			//**Fetch the image and associate to part
			DataSource fds = new FileDataSource(imageFilePath);
			messageBodyPart.setDataHandler(new DataHandler(fds));
			messageBodyPart.setHeader("Content-ID","<companylogo>");

			//**Add part to multi-part
			multipart.addBodyPart(messageBodyPart);

			//**Associate multi-part with message
			message.setContent(multipart);
    		
    		transportMail(message);	
    	}
    	catch(Exception ex){
			logger.error("Java Mail Error with setting Message Body: " + ex.getMessage());
		}
    }
    
    /**
     * Method to just send the message that is already built.
     *
     */    
    public static void transportMail(Message message){
    	try{
    		//**Send message
			Transport.send(message);
					
			logger.info("Message sent successfully.");
    	}
    	catch(Exception ex){
			logger.error("Java Mail Transport Error: " + ex.getMessage());
		}
    }
    
    
    /**
	 * Html-Image message to one recipients.
	 * 
	 * This is the method that sends "HTML Msg with Image" to the email address specified in "to".
	 * The senders email address should be specified as "from".
	 * 
	 * The String msg is a string that can contain html-tags.
	 * 
	 * Please note that when you send html as a string, preceed the double quotes and back slashes
	 * with a back slash.
	 * Eg: (\") or (\\) and not simply (") or (\)
	 * 
	 * @param  String - to
	 * @param String - from
	 * @param String - subject
	 * @param String - HTML Msg
	 * @param String - Path to the Image
	 */
    public static void sendMail(String to, String from, String subject, String msg, String imageFilePath){
    	
    	logger.info("Sending HTML Message with Image to " + to + "...");
		
		try{
			//Get system properties
			Properties props = System.getProperties();

			//**Setup mail server
			props.put("mail.smtp.host", host);

			//**Get session
			Session session = Session.getDefaultInstance(props, null);

			//**Create the message
			Message message = new MimeMessage(session);

			//**Fill its headers
			message.setSubject(subject);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, 
			  new InternetAddress(to));

			setHtmlImageMessageBody(message, msg, imageFilePath);
		}
		catch(Exception ex){
			logger.error("Java Mail Error building Message Header: " + ex.getMessage());
		}
		
    }
    
    /**
	 * Html-Image message to many recipients.
	 * 
	 * This is the method that sends "HTML Msg with Image" to the email address specified in "to".
	 * The senders email address should be specified as "from".
	 * 
	 * The String msg is a string that can contain html-tags.
	 * 
	 * Please note that when you send html as a string, preceed the double quotes and back slashes
	 * with a back slash.
	 * Eg: (\") or (\\) and not simply (") or (\)
	 * 
	 * @param  String[] - to
	 * @param String - from
	 * @param String[] - cc
	 * @param String - subject
	 * @param String - HTML Msg
	 * @param String - Path to the Image
	 */
    public static void sendMail(String[] to, String from, String[] cc, String subject, String msg, String imageFilePath){
    	
    	logger.info("Sending HTML Message with Image...");
		
    	try{
			//Get system properties
			Properties props = System.getProperties();

			//**Setup mail server
			props.put("mail.smtp.host", host);

			//**Get session
			Session session = Session.getDefaultInstance(props, null);

			//**Define message
			MimeMessage message = new MimeMessage(session);
			
			//**toAddress
			Address[] toAddress = new Address[to.length];
			
			for(int toCnt = 0; toCnt < to.length; toCnt++){	
				toAddress[toCnt] = new InternetAddress(to[toCnt]);
				message.addRecipient(Message.RecipientType.TO, toAddress[toCnt]);
			}
			
			//**ccAddress
			Address[] ccAddress = new Address[cc.length];
			
			for(int ccCnt = 0; ccCnt < cc.length; ccCnt++){	
				ccAddress[ccCnt] = new InternetAddress(cc[ccCnt]);
				message.addRecipient(Message.RecipientType.CC, ccAddress[ccCnt]);
			}
			
			//**fromAddress
			message.setFrom(new InternetAddress(from));
			
			//**Msg Content and Subject
			message.setSubject(subject);
			
			message.setText(msg);
			
			setHtmlImageMessageBody(message, msg, imageFilePath);
		}
		catch(Exception ex){
			logger.error("Java Mail Error building Message Header: " + ex.getMessage());
		}
		
    }
    
    
    /**
	 * If boolean value htmlMessage is false, 
	 * 	it sends a simple msg/link
	 * else
	 * 	it sends "HTML Msg without any Images" to the email address specified in "to".
	 * The senders email address should be specified as "from".
	 * 
	 * The String msg is a string that can contain html-tags.
	 * 
	 * Please note that when you send html as a string, preceed the double quotes and back slashes
	 * with a back slash.
	 * Eg: (\") or (\\) and not simply (") or (\).
	 * 
	 * This works for all general HTML-Tags except the Image.
	 * 
	 * @param  String - to
	 * @param String - from
	 * @param String - subject
	 * @param String - HTML Msg
	 * @param boolean - HTML-Msg/not
	 */
    public static void sendMail(String to, String from, String subject, String msg, boolean htmlMessage){
    	
    	logger.info("Sending HTML Message to " + to + "...");
		
		try{
			//Get system properties
			Properties props = System.getProperties();

			//**Setup mail server
			props.put("mail.smtp.host", host);

			//**Get session
			Session session = Session.getDefaultInstance(props, null);

			//**Define message
			MimeMessage message = new MimeMessage(session);
			
			//**toAddress	
			Address toAddress = new InternetAddress(to);
			message.addRecipient(Message.RecipientType.TO, toAddress);
			
			//**fromAddress
			message.setFrom(new InternetAddress(from));
			
			//**Msg Content and Subject
			message.setSubject(subject);
			
			if(htmlMessage){
				setHtmlMessageBody(message, msg);
			}
			else{
				setMessageBody(message, msg);
			}
						
		}
		catch(Exception ex){
			logger.error("Java Mail Error building Message Header: " + ex.getMessage());
		}
		
    } 
    
    
   /**
	 * Method to send msg to more than one recipient
	 * This is the method that sends "Msg" to the all email addresses specified in "to" and "y".
	 * The senders email address should be specified as "from".
	 * 
	 * If boolean htmlMessage is true, it sends an Html Message.
	 * 
	 * Please note that when you send html as a string, preceed the double quotes and back slashes
	 * with a back slash.
	 * Eg: (\") or (\\) and not simply (") or (\).
	 * 
	 * This works for all general HTML-Tags except the Image.
	 * 
	 * @param  String[] - to
	 * @param String - from
	 * @param String[] - cc
	 * @param String - Msg
	 */
	public static void sendMail(String[] to, String from, String[] cc, String subject, String msg, boolean htmlMessage){
		
		logger.info("Sending Message...");
		
		try{
			//Get system properties
			Properties props = System.getProperties();

			//**Setup mail server
			props.put("mail.smtp.host", host);

			//**Get session
			Session session = Session.getDefaultInstance(props, null);

			//**Define message
			MimeMessage message = new MimeMessage(session);
			
			//**toAddress
			Address[] toAddress = new Address[to.length];
			
			
			
			for(int toCnt = 0; toCnt < to.length; toCnt++){	
				toAddress[toCnt] = new InternetAddress(to[toCnt]);
				message.addRecipient(Message.RecipientType.TO, toAddress[toCnt]);
			}
			
			//**ccAddress
			Address[] ccAddress = new Address[cc.length];
			
			for(int ccCnt = 0; ccCnt < cc.length; ccCnt++){	
				ccAddress[ccCnt] = new InternetAddress(cc[ccCnt]);
				message.addRecipient(Message.RecipientType.CC, ccAddress[ccCnt]);
			}
			
			//**fromAddress
			message.setFrom(new InternetAddress(from));
			
			//**Msg Content and Subject
			message.setSubject(subject);
			
			
			
			if(htmlMessage){
				setHtmlMessageBody(message, msg);
			}
			else{
				setMessageBody(message, msg);
			}
			
		}
		catch(Exception ex){
			logger.error("Java Mail Error building Message Header: " + ex.getMessage());
		}
		
		
	}
	
	  /**
	 * Method to send msg to more than one recipient
	 * This is the method that sends "Msg" to the all email addresses specified in "to" and "y".
	 * The senders email address should be specified as "from".
	 * 
	 * If boolean htmlMessage is true, it sends an Html Message.
	 * 
	 * Please note that when you send html as a string, preceed the double quotes and back slashes
	 * with a back slash.
	 * Eg: (\") or (\\) and not simply (") or (\).
	 * 
	 * This works for all general HTML-Tags except the Image.
	 * 
	 * @param  String[] - to
	 * @param String - from
	 * @param String[] - cc
	 * @param String - Msg
	 */
	public static void sendMail(String[] to, String from, String subject, String msg, boolean htmlMessage){
		
		logger.info("Sending Message...");
		
		try{
			//Get system properties
			Properties props = System.getProperties();

			//**Setup mail server
			props.put("mail.smtp.host", host);

			//**Get session
			Session session = Session.getDefaultInstance(props, null);

			//**Define message
			MimeMessage message = new MimeMessage(session);
			
			//**toAddress
			Address[] toAddress = new Address[to.length];
			
			for(int toCnt = 0; toCnt < to.length; toCnt++){	
				toAddress[toCnt] = new InternetAddress(to[toCnt]);
				message.addRecipient(Message.RecipientType.TO, toAddress[toCnt]);
			}
			
			//**fromAddress
			message.setFrom(new InternetAddress(from));
			
			//**Msg Content and Subject
			message.setSubject(subject);
			
			if(htmlMessage){
				setHtmlMessageBody(message, msg);
			}
			else{
				setMessageBody(message, msg);
			}
			
		}
		catch(Exception ex){
			logger.error("Java Mail Error building Message Header: " + ex.getMessage());
		}
		
		
	}	
	
	public static void main(String[] args) { //todo can this be removed?
	}
}
