/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class WorldAreaObject {
	
	
	private String worldAreaName;
	
	private int totalActivities = 0;
	
	Vector countryVector = new Vector();

	private Vector worldPeriodVector = new Vector();
	
	
	
	
	/**
	 * @return Returns the worldPeriodVector.
	 */
	public Vector getWorldPeriodVector() {
		return worldPeriodVector;
	}
	/**
	 * @param worldPeriodVector The worldPeriodVector to set.
	 */
	public void setWorldPeriodVector(Vector worldPeriodVector) {
		this.worldPeriodVector = worldPeriodVector;
	}
	/**
	 * @return Returns the totalActivities.
	 */
	public int getTotalActivities() {
		return totalActivities;
	}
	/**
	 * @param totalActivities The totalActivities to set.
	 */
	public void setTotalActivities(int totalActivities) {
		this.totalActivities = totalActivities;
	}
	
	public void addToTotalActivities(int val){
		totalActivities += val;
	}
	
	/**
	 * @return Returns the countryVector.
	 */
	public Vector getCountryVector() {
		return countryVector;
	}
	/**
	 * @param countryVector The countryVector to set.
	 */
	public void setCountryVector(Vector countryVector) {
		this.countryVector = countryVector;
	}
	/**
	 * @return Returns the worldAreaName.
	 */
	public String getWorldAreaName() {
		return worldAreaName;
	}
	/**
	 * @param worldAreaName The worldAreaName to set.
	 */
	public void setWorldAreaName(String worldAreaName) {
		this.worldAreaName = worldAreaName;
	}
}
