/*
 * Created on Mar 17, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Iterator;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.InvalidActivityException;
import com.monsanto.wst.soxic.exception.InvalidCertificationStateException;
import com.monsanto.wst.soxic.model.ItemDetails;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.form.AdminDetailsForm;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionMessage;

import javax.servlet.http.HttpServletRequest;

/**
 * @author SPOLAVA
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleAdminDetailsDAO {

    public static List getCycles() throws DatabaseException, Exception {

        List cycles = new ArrayList();

        String query = "SELECT CYCLE_ID FROM CYCLE ";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);

            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                cycles.add(resultSet.getString("CYCLE_ID"));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return cycles;

    }

    public static List getSubCycles(String cycleId) throws DatabaseException, Exception {

        List cycles = new ArrayList();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT SUB_CYCLE_ID FROM SUB_CYCLE WHERE CYCLE_ID='" + cycleId + "'";
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                cycles.add(resultSet.getString("SUB_CYCLE_ID"));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return cycles;

    }

    public static List getControlObjectives(String subCycleId) throws DatabaseException, Exception {

        List cycles = new ArrayList();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT CTRL_OBJ_ID FROM CTRL_OBJ WHERE SUB_CYCLE_ID='" + subCycleId + "'";
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                cycles.add(resultSet.getString("CTRL_OBJ_ID"));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return cycles;

    }

    public static List getActivities(String controlObjectiveId) throws DatabaseException, Exception {

        List cycles = new ArrayList();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT ACTIVITY_ID FROM ACTIVITY WHERE CTRL_OBJ_ID='" + controlObjectiveId + "' ORDER BY ACTIVITY_ID";
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                cycles.add(resultSet.getString("ACTIVITY_ID"));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return cycles;

    }

    public static ItemDetails getCycleDetails(String cycleId) throws DatabaseException {

        ItemDetails details = new ItemDetails();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT CYCLE_ID, DESCRIPTION FROM CYCLE WHERE CYCLE_ID='" + cycleId + "'";
        String dateQuery = "SELECT MIN(START_DATE), MAX(DUE_DATE) FROM OWNER_CYCLE WHERE CYCLE_ID='" + cycleId + "'";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                details.setId(resultSet.getString("CYCLE_ID"));
                details.setDescription(resultSet.getString("DESCRIPTION"));
            }

            resultSet = statement.executeQuery(dateQuery);

            while (resultSet.next()) {
                if (resultSet.getDate("MIN(START_DATE)") != null) {
                    details.setStartDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MIN(START_DATE)")));
                }
                if (resultSet.getDate("MAX(DUE_DATE)") != null) {
                    details.setDueDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MAX(DUE_DATE)")));
                }
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return details;
    }

    public static ItemDetails getSubCycleDetails(String subCycleId) throws DatabaseException {
        ItemDetails details = new ItemDetails();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT SUB_CYCLE_ID, DESCRIPTION FROM SUB_CYCLE WHERE SUB_CYCLE_ID='" + subCycleId + "'";
        String dateQuery = "SELECT MIN(START_DATE), MAX(DUE_DATE) FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID='" + subCycleId + "'";
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                details.setId(resultSet.getString("SUB_CYCLE_ID"));
                details.setDescription(resultSet.getString("DESCRIPTION"));
            }

            resultSet = statement.executeQuery(dateQuery);

            while (resultSet.next()) {
                if (resultSet.getDate("MIN(START_DATE)") != null) {
                    details.setStartDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MIN(START_DATE)")));
                }
                if (resultSet.getDate("MAX(DUE_DATE)") != null) {
                    details.setDueDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MAX(DUE_DATE)")));
                }

            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return details;
    }

    public static ItemDetails getControlObjectiveDetails(String controlObjectiveId) throws DatabaseException {
        ItemDetails details = new ItemDetails();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT CTRL_OBJ_ID, DESCRIPTION FROM CTRL_OBJ WHERE CTRL_OBJ_ID ='" + controlObjectiveId + "'";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                details.setId(resultSet.getString("CTRL_OBJ_ID"));
                details.setDescription(resultSet.getString("DESCRIPTION"));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return details;
    }

    public static ItemDetails getActivityDetails(String activityId) throws DatabaseException {

        ItemDetails details = new ItemDetails();
        List activitycodes = new ArrayList();
        String cstring = "";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String query = "SELECT ACTIVITY_ID, DESCRIPTION FROM ACTIVITY WHERE ACTIVITY_ID ='" + activityId + "'";
        String dateQuery = "SELECT MIN(START_DATE), MAX(DUE_DATE) FROM OWNER_ACTIVITY WHERE ACTIVITY_ID='" + activityId + "'";
        String querycodes = "SELECT C.CODE FROM CTRL_OBJ_CODES C, ACTIVITY A WHERE A.ACTIVITY_ID = C.ACTIVITY_ID AND C.TYPE = 'CODE' AND C.ACTIVITY_ID='" + activityId + "'";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                details.setId(resultSet.getString("ACTIVITY_ID"));
                details.setDescription(resultSet.getString("DESCRIPTION"));
            }

            resultSet = statement.executeQuery(dateQuery);

            while (resultSet.next()) {
                if (resultSet.getDate("MIN(START_DATE)") != null) {
                    details.setStartDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MIN(START_DATE)")));
                }
                if (resultSet.getDate("MAX(DUE_DATE)") != null) {
                    details.setDueDate(new SimpleDateFormat("MM/dd/yyyy").format(resultSet.getDate("MAX(DUE_DATE)")));
                }
            }

            resultSet = statement.executeQuery(querycodes);

            while (resultSet.next()) {
                if (cstring.length() == 0) {
                    cstring = cstring + resultSet.getString("CODE");
                } else {
                    cstring = cstring + "," + resultSet.getString("CODE");
                }

            }

            details.setCodestring(cstring);

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }


        return details;
    }

    public static void updateDetails(ItemDetails details) throws Exception,DatabaseException, InvalidCertificationStateException {

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();
			 
            // updates the description of the corresponding table based on the type of the details...
            statement.executeQuery(buildUpdateQuery(details));

            if (!details.getType().equals("ctrl_obj")) {
                statement.executeQuery(buildUpdateOwnerQuery(details));

                if (details.isApplyToAllChildren()) {
                    updateAllChaildDetails(details);
                }
            }
        } catch (Exception e) {
            if (e instanceof DatabaseException)
            throw new DatabaseException(e.getMessage());
            if (e instanceof InvalidCertificationStateException)
                throw new InvalidCertificationStateException();
        }  finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }

    }

    public static void updateAllChaildDetails(ItemDetails details) throws DatabaseException {

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();

            if (details.getType().equals("cycle")) {

                // updates all owner_sub_cycle table
                statement.executeQuery(buildUpdateSubCycleChaildQueryForCycle(details));
                //updates owner_activity table
                statement.executeQuery(buildUpdateActivityChaildQueryForCycle(details));
            } else if (details.getType().equals("sub_cycle")) {
                //updates owner_activity table;
                statement.executeQuery(buildUpdateActivityChaildQueryForSubCycle(details));
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (resultSet != null)
                    SoxicConnectionFactory.closeResultSet(resultSet);
                if (statement != null)
                    statement.close();
                if (connection != null)
                    SoxicConnectionFactory.closeSoxicConnection(connection);

            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }

    }

    private static String buildUpdateOwnerQuery(ItemDetails details) {

        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");

        query.append(getOwnerTableName(details.getType()));

        query.append(" SET ");

        query.append(ItemDetails.START_DATE + "=");
        query.append("to_date('"
                + details.getStartDate()
                + "', 'MM/dd/yyyy')");
        query.append(", ");

        query.append(ItemDetails.DUE_DATE + "=");
        query.append("to_date('"
                + details.getDueDate()
                + "', 'MM/dd/yyyy')");

        query.append(" WHERE ");
        query.append(getColumnName(details.getType()));
        query.append("='" + details.getId() + "'");

        return query.toString();
    }

    private static String buildUpdateQuery(ItemDetails details) throws Exception {
        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");

        query.append(getTableName(details.getType()));

        query.append(" SET ");

        query.append(ItemDetails.DESCRIPTION + "='");
        query.append(details.getDescription() + "'");

        query.append(" WHERE ");

        query.append(getColumnName(details.getType()));

        query.append("='" + details.getId() + "'");

        insertactivityCodes(details.getCodestring(), details.getId());
        deleteactivityCodes(details.getCodestring(), details.getId());

        if ((details.getType().equalsIgnoreCase("cycle")) && ((details.getStartDate() != null) && (details.getStartDate().length() > 0)) && ((details.getDueDate() != null) && (details.getDueDate().length() > 0))) {
            if (isValidStateforChange(details.getId())) {
                setCycleToCertificationState(details.getId());
            } else {
                throw new InvalidCertificationStateException(new Exception("Cycle Cannot be set into CERTIFICATION"));
            }
       }
        return query.toString();
    }


    /**
     * @param type
     */
    private static String getTableName(String type) {

        if (type.equals("cycle")) {
            return ItemDetails.CYCLE;
        } else if (type.equals("sub_cycle")) {
            return ItemDetails.SUB_CYCLE;
        } else if (type.equals("ctrl_obj")) {
            return ItemDetails.CTRL_OBJ;
        } else if (type.equals("activity")) {
            return ItemDetails.ACTIVITY;
        }
        return "";
    }

    private static String getOwnerTableName(String type) {

        if (type.equals("cycle")) {
            return ItemDetails.OWNER_CYCLE;
        } else if (type.equals("sub_cycle")) {
            return ItemDetails.OWNER_SUB_CYCLE;
        } else if (type.equals("activity")) {
            return ItemDetails.OWNER_ACTIVITY;
        }
        return "";
    }

    private static String getColumnName(String type) {

        if (type.equals("cycle")) {
            return ItemDetails.CYCLE_ID;
        } else if (type.equals("sub_cycle")) {
            return ItemDetails.SUB_CYCLE_ID;
        } else if (type.equals("ctrl_obj")) {
            return ItemDetails.CTRL_OBJ_ID;
        } else if (type.equals("activity")) {
            return ItemDetails.ACTIVITY_ID;
        }
        return "";
    }

    private static String buildUpdateSubCycleChaildQueryForCycle(ItemDetails details) {
        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");

        query.append("OWNER_SUB_CYCLE");

        query.append(" SET ");

        query.append(ItemDetails.START_DATE + "=");
        query.append("to_date('"
                + details.getStartDate()
                + "', 'MM/dd/yyyy')");
        query.append(", ");

        query.append(ItemDetails.DUE_DATE + "=");
        query.append("to_date('"
                + details.getDueDate()
                + "', 'MM/dd/yyyy')");

        query.append(" WHERE ");
        query.append("SUB_CYCLE_ID IN (");

        query.append("SELECT SUB_CYCLE_ID FROM SUB_CYCLE WHERE CYCLE_ID");
        query.append("='" + details.getId() + "'");
        query.append(")");

        return query.toString();
    }

    private static String buildUpdateActivityChaildQueryForCycle(ItemDetails details) {
        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");

        query.append("OWNER_ACTIVITY");

        query.append(" SET ");

        query.append(ItemDetails.START_DATE + "=");
        query.append("to_date('"
                + details.getStartDate()
                + "', 'MM/dd/yyyy')");
        query.append(", ");

        query.append(ItemDetails.DUE_DATE + "=");
        query.append("to_date('"
                + details.getDueDate()
                + "', 'MM/dd/yyyy')");

        query.append(" WHERE ");
        query.append("ACTIVITY_ID IN (");

        query.append("SELECT ACTIVITY_ID FROM ACTIVITY WHERE CTRL_OBJ_ID IN (");
        query.append("SELECT CTRL_OBJ_ID FROM CTRL_OBJ WHERE SUB_CYCLE_ID IN (");
        query.append("SELECT SUB_CYCLE_ID FROM SUB_CYCLE WHERE CYCLE_ID ");
        query.append("='" + details.getId() + "'");
        query.append(")))");

        return query.toString();
    }

    private static String buildUpdateActivityChaildQueryForSubCycle(ItemDetails details) {

        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");

        query.append("OWNER_ACTIVITY");

        query.append(" SET ");

        query.append(ItemDetails.START_DATE + "=");
        query.append("to_date('"
                + details.getStartDate()
                + "', 'MM/dd/yyyy')");
        query.append(", ");

        query.append(ItemDetails.DUE_DATE + "=");
        query.append("to_date('"
                + details.getDueDate()
                + "', 'MM/dd/yyyy')");

        query.append(" WHERE ");
        query.append("ACTIVITY_ID IN (");

        query.append("SELECT ACTIVITY_ID FROM ACTIVITY WHERE CTRL_OBJ_ID IN (");
        query.append("SELECT CTRL_OBJ_ID FROM CTRL_OBJ WHERE SUB_CYCLE_ID ");
        query.append("='" + details.getId() + "'");
        query.append("))");

        return query.toString();
    }

    //inserts new activity codes
    private static void insertactivityCodes(String codestring, String activityId) throws Exception {

        List activitycodeList = new ArrayList();
        String actcode = "";
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT C.CODE FROM CTRL_OBJ_CODES C, ACTIVITY A WHERE A.ACTIVITY_ID = C.ACTIVITY_ID AND C.ACTIVITY_ID=? AND C.TYPE=?");
            preparedStatement.setString(1, activityId);
            preparedStatement.setString(2, SoxicConstants.CODE);

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                activitycodeList.add(rs.getString("CODE"));
            }

            StringTokenizer st = new StringTokenizer(codestring, ",");
            while (st.hasMoreElements()) {
                actcode = String.valueOf(st.nextElement());
                boolean it = activitycodeList.contains(actcode);
                if (!it) {
                    try {
                        preparedStatement = con.prepareStatement("INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID,TYPE,CODE) VALUES (?,?,?)");
                        preparedStatement.setString(1, activityId);
                        preparedStatement.setString(2, SoxicConstants.CODE);
                        preparedStatement.setString(3, actcode);
                        int norows = preparedStatement.executeUpdate();
                    } catch (SQLException e) {
                        e.printStackTrace();
                        SoxicConnectionFactory.rollback(con);
                        SoxicConnectionFactory.closeResultSet(rs);
                        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                        SoxicConnectionFactory.closeSoxicConnection(con);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //deletes activity codes
    private static void deleteactivityCodes(String codestring, String activityId) throws Exception {

        List activitycodeList = new ArrayList();
        String actcode = "";
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT C.CODE FROM CTRL_OBJ_CODES C, ACTIVITY A WHERE A.ACTIVITY_ID = C.ACTIVITY_ID AND C.ACTIVITY_ID=? AND C.TYPE=?");
            preparedStatement.setString(1, activityId);
            preparedStatement.setString(2, SoxicConstants.CODE);

            StringTokenizer st = new StringTokenizer(codestring, ",");
            while (st.hasMoreElements()) {
                actcode = String.valueOf(st.nextElement());
                activitycodeList.add(actcode);
            }

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String delcode = rs.getString("CODE");
                boolean it = activitycodeList.contains(delcode);

                if (!it) {
                    try {
                        preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID = ? AND CODE = ?");
                        preparedStatement.setString(1, activityId);
                        preparedStatement.setString(2, delcode);
                        int norows = preparedStatement.executeUpdate();
                    } catch (SQLException e) {
                        e.printStackTrace();
                        SoxicConnectionFactory.rollback(con);
                        SoxicConnectionFactory.closeResultSet(rs);
                        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                        SoxicConnectionFactory.closeSoxicConnection(con);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //deleting activities based on administrator selection
    public static void deleteactivity(String cycleid, String subcycleid, String controlobjid, String activityid) throws Exception {

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String responseid;
        int controlobjcount = 0;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            preparedStatement = con.prepareStatement("SELECT COUNT(*) AS COUNT FROM ACTIVITY WHERE CTRL_OBJ_ID = ?");
            preparedStatement.setString(1, controlobjid);
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                controlobjcount = (rs.getInt("COUNT"));
            }

            if (controlobjcount > 1) {
                preparedStatement = con.prepareStatement("SELECT G.RESPONSE_ID FROM GAP_DC_LOE G, OWNER_RESPONSE OWR WHERE G.RESPONSE_ID = OWR.RESPONSE_ID AND OWR.ASSOCIATED_ID = ?");
                preparedStatement.setString(1, activityid);
                rs = preparedStatement.executeQuery();

                while (rs.next()) {
                    responseid = rs.getString("RESPONSE_ID");

                    preparedStatement = con.prepareStatement("DELETE FROM GAP_DC_LOE WHERE RESPONSE_ID LIKE '%" + responseid + "%'");
                    int gap_dc = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_RESPONSE_HISTORY WHERE RESPONSE_ID LIKE '%" + responseid + "%'");
                    int owner_resp_hist = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_RESPONSE WHERE RESPONSE_ID LIKE '%" + responseid + "%'");
                    int owner_resp = preparedStatement.executeUpdate();
                }

                preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID LIKE '%" + activityid + "%'");
                int ctrlobj = preparedStatement.executeUpdate();

                preparedStatement = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID LIKE '%" + activityid + "%'");
                int owner_act = preparedStatement.executeUpdate();

                preparedStatement = con.prepareStatement("DELETE FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID LIKE '%" + activityid + "%'");
                int quest_act = preparedStatement.executeUpdate();

                preparedStatement = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID LIKE '%" + activityid + "%'");
                int activity = preparedStatement.executeUpdate();
            } else
                throw new InvalidActivityException(new Exception("Invalid Activity Owners"));

        } catch (SQLException e) {
            e.printStackTrace();
            SoxicConnectionFactory.rollback(con);
            SoxicConnectionFactory.closeResultSet(rs);
            SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            SoxicConnectionFactory.closeSoxicConnection(con);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void setCycleToCertificationState(String cycleid) throws Exception {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET STATE=? WHERE CYCLE_ID=?");
            preparedStatement.setString(1, SoxicConstants.CERTIFICATION_STATE);
            preparedStatement.setString(2, cycleid);

            int n = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            SoxicConnectionFactory.rollback(con);
            SoxicConnectionFactory.closeResultSet(rs);
            SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            SoxicConnectionFactory.closeSoxicConnection(con);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
                SoxicConnectionFactory.closeSoxicConnection(con);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static boolean isValidStateforChange(String cycleid) throws Exception {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String cycle_state = null;
        boolean state = false;


        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT STATE FROM CYCLE_STATE WHERE CYCLE_ID = ?");
            preparedStatement.setString(1, cycleid);

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cycle_state = rs.getString("STATE");
            }

            if (cycle_state.equalsIgnoreCase(SoxicConstants.CYCLE_STATE_PRECERTIFY)) {
                state = true;
            } else
                state = false;
        } catch (SQLException e) {
            e.printStackTrace();
            e.printStackTrace();
            SoxicConnectionFactory.rollback(con);
            SoxicConnectionFactory.closeResultSet(rs);
            SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            SoxicConnectionFactory.closeSoxicConnection(con);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
                SoxicConnectionFactory.closeSoxicConnection(con);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return state;
    }
}

