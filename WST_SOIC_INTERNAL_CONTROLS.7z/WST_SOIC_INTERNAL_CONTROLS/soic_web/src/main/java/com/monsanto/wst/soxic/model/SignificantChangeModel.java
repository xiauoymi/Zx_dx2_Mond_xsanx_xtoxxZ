package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.shared.overflow.OverFlowMap;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 8, 2006
 * Time: 4:03:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class SignificantChangeModel implements Comparable{

    private String seqindex;
    private String selectedType;
    private String selectedPeriod;
    private String amount;
    private String keyContact;
    private String subcycles;
    private String description;
    private boolean addButton;
    private String overFlowId;
    private OverFlowMap overFlowMap;
    private String overSid;
    private String overText;

    private List sigTypes;
    private List sigPeriods;

    public SignificantChangeModel(String seqindex, String selectedType, String selectedPeriod, String amount, String keyContact, String subcycles, String description) {
        this.seqindex = seqindex;
        this.selectedType = selectedType;
        this.selectedPeriod = selectedPeriod;
        this.amount = amount;
        this.keyContact = keyContact;
        this.subcycles = subcycles;
        this.description = description;
    }   

    public SignificantChangeModel() {
    }

    public List getSigPeriods() {
        return sigPeriods;
    }

    public void setSigPeriods(List sigPeriods) {
        this.sigPeriods = sigPeriods;
    }

    public boolean isAddButton() {
        return addButton;
    }

    public void setAddButton(boolean addButton) {
        this.addButton = addButton;
    }

    public List getSigTypes() {
        return sigTypes;
    }

    public void setSigTypes(List sigTypes) {
        this.sigTypes = sigTypes;
    }

    public String getSeqindex() {
        return seqindex;
    }

    public String getSelectedType() {
        return selectedType;
    }

    public String getSelectedPeriod() {
        return selectedPeriod;
    }

    public String getAmount() {
        return amount;
    }

    public String getKeyContact() {
        return keyContact;
    }

    public String getSubcycles() {
        return subcycles;
    }

    public String getDescription() {
        if (overFlowId!=null && !overFlowId.equalsIgnoreCase("0")){
            description = overFlowMap.getCompleteString(overFlowId);
        }
        return description;
    }

    public void setSeqindex(String seqindex) {
        this.seqindex = seqindex;
    }

    public void setSelectedType(String selectedType) {
        this.selectedType = selectedType;
    }

    public void setSelectedPeriod(String selectedPeriod) {
        this.selectedPeriod = selectedPeriod;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setKeyContact(String keyContact) {
        this.keyContact = keyContact;
    }

    public void setSubcycles(String subcycles) {
        this.subcycles = subcycles;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(String overFlowId) {
        this.overFlowId = overFlowId;
    }

    public OverFlowMap getOverFlowMap() {
        return overFlowMap;
    }

    public void setOverFlowMap(OverFlowMap overFlowMap) {
        this.overFlowMap = overFlowMap;
    }

    public String getOverSid() {
        return overSid;
    }

    public void setOverSid(String overSid) {
        this.overSid = overSid;
    }

    public String getOverText() {
        return overText;
    }

    public void setOverText(String overText) {
        this.overText = overText;
    }


    public int compareTo(Object o) {
        if (o instanceof SignificantChangeModel){
            return seqindex.compareTo(((SignificantChangeModel)o).getSeqindex());
        }
        return seqindex.compareTo(((SignificantChangeModel)o).getSeqindex());
    }
}
