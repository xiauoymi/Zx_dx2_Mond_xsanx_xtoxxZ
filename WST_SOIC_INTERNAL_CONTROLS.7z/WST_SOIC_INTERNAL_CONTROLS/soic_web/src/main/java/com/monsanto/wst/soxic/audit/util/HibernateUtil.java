package com.monsanto.wst.soxic.audit.util;

import org.hibernate.Session;
import com.monsanto.wst.hibernate.HibernateFactoryImpl;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 14, 2009
 * Time: 10:08:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class HibernateUtil {
  
  private static Session hibernateSession;

  public static Session getHibernateSession() {
    HibernateFactory factory = HibernateFactoryImpl.getInstance("soic");
    hibernateSession = factory.getSession();
    hibernateSession.beginTransaction();
    hibernateSession.clear();
    return hibernateSession;
  }
}
