//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.action.ActivityTemplate;
import com.monsanto.wst.soxic.action.SubCycleHeaderTemplate;
import com.monsanto.wst.soxic.action.SubCycleOwnerTemplate;
import com.monsanto.wst.soxic.action.SubCycleTemplate;

/** 
 * MyEclipse Struts
 * Creation date: 02-25-2005
 * 
 * XDoclet definition:
 * @struts:form name="subcycleReportForm"
 */
public class SubcycleReportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	private String cyclesSelected[];
	
	private Vector finalCycleList = new Vector();
	
	//**Nested:root#1
	private Vector listOfCycles = new Vector();
	
	private SubCycleTemplate scTempl = new SubCycleTemplate(); 
	
	private SubCycleHeaderTemplate scHeaderTempl = new SubCycleHeaderTemplate();
	
	private SubCycleOwnerTemplate scOwnerTempl = new SubCycleOwnerTemplate();
	
	private ActivityTemplate actTempl = new ActivityTemplate();
	
	private Vector listOfSubCycles = new Vector();
	
	private String cyclesString = ""; 
	
	
	
	
	// --------------------------------------------------------- Methods

	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {
		
		ActionErrors errors = new ActionErrors();
		
		if(cyclesSelected == null || cyclesSelected.length == 0){
			errors.add("cyclesSelected", new ActionError("errors.cyclesSelected.null"));
		}
		
		return errors;
		
	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

	
	
//	/**
//	 * @return Returns the cyclesSelected.
//	 */
//	public Vector getCyclesSelected() {
//		return cyclesSelected;
//	}
//	/**
//	 * @param cyclesSelected The cyclesSelected to set.
//	 */
//	public void setCyclesSelected(Vector cyclesSelected) {
//		this.cyclesSelected = cyclesSelected;
//	}
	
	
	
	/**
	 * @return Returns the scTempl.
	 */
	public SubCycleTemplate getScTempl() {
		return scTempl;
	}
	/**
	 * @param scTempl The scTempl to set.
	 */
	public void setScTempl(SubCycleTemplate scTempl) {
		this.scTempl = scTempl;
	}
	
	/**
	 * @return Returns the cyclesSelected.
	 */
	public String[] getCyclesSelected() {
		return cyclesSelected;
	}
	/**
	 * @param cyclesSelected The cyclesSelected to set.
	 */
	public void setCyclesSelected(String[] cyclesSelected) {
		this.cyclesSelected = cyclesSelected;
	}
	/**
	 * @return Returns the listOfCycles.
	 */
	public Vector getListOfCycles() {
		return listOfCycles;
	}
	/**
	 * @param listOfCycles The listOfCycles to set.
	 */
	public void setListOfCycles(Vector listOfCycles) {
		this.listOfCycles = listOfCycles;
	}
	/**
	 * @return Returns the finalCycleList.
	 */
	public Vector getFinalCycleList() {
		return finalCycleList;
	}
	/**
	 * @param finalCycleList The finalCycleList to set.
	 */
	public void setFinalCycleList(Vector finalCycleList) {
		this.finalCycleList = finalCycleList;
		
		for(int i = 0; i < finalCycleList.size(); i++){
			if(i < finalCycleList.size() -1){
				cyclesString = cyclesString + finalCycleList.get(i) + ", ";
			}
			else{
				cyclesString += finalCycleList.get(i);
			}
		}
	}
	/**
	 * @return Returns the actTempl.
	 */
	public ActivityTemplate getActTempl() {
		return actTempl;
	}
	/**
	 * @param actTempl The actTempl to set.
	 */
	public void setActTempl(ActivityTemplate actTempl) {
		this.actTempl = actTempl;
	}
	/**
	 * @return Returns the scHeaderTempl.
	 */
	public SubCycleHeaderTemplate getScHeaderTempl() {
		return scHeaderTempl;
	}
	/**
	 * @param scHeaderTempl The scHeaderTempl to set.
	 */
	public void setScHeaderTempl(SubCycleHeaderTemplate scHeaderTempl) {
		this.scHeaderTempl = scHeaderTempl;
	}
	/**
	 * @return Returns the scOwnerTempl.
	 */
	public SubCycleOwnerTemplate getScOwnerTempl() {
		return scOwnerTempl;
	}
	/**
	 * @param scOwnerTempl The scOwnerTempl to set.
	 */
	public void setScOwnerTempl(SubCycleOwnerTemplate scOwnerTempl) {
		this.scOwnerTempl = scOwnerTempl;
	}
	/**
	 * @return Returns the listOfSubCycles.
	 */
	public Vector getListOfSubCycles() {
		return listOfSubCycles;
	}
	/**
	 * @param listOfSubCycles The listOfSubCycles to set.
	 */
	public void setListOfSubCycles(Vector listOfSubCycles) {
		this.listOfSubCycles = listOfSubCycles;
	}
	/**
	 * @return Returns the cyclesString.
	 */
	public String getCyclesString() {
		return cyclesString;
	}
	
	/**
	 * @param cyclesString The cyclesString to set.
	 */
	public void setCyclesString(String cyclesString) {
		this.cyclesString = cyclesString;
	}
}