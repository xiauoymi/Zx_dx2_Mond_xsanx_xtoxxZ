/*
 * Created on Jan 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;

import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycle extends SoxicBaseModel implements Comparable{
    
    //   following feilds represents the Column Names of  Sub_Cycle, Owner_Sub_cycle table in the DB.
       
    public static final String SUB_CYCLE_ID = "SUB_CYCLE_ID";
    public static final String SUB_CYCLE_CODE ="SUB_CYCLE_CODE";
    public static final String NEW_SUB_CYCLE_ID ="NEW_SUB_CYCLE_ID";
    public static final String DESCRIPTION 	= "DESCRIPTION";
    public static final String OVERFLOW_ID 	= "OVERFLOW_ID";
    public static final String STATUS 		= "STATUS";
    public static final String OWNERID		= "OWNER_ID";
    public static final String QUESTION_ID  = "QUESTION_ID";

    public static final String START_DATE 	= "START_DATE";
    public static final String DUE_DATE 	= "DUE_DATE";
   
    public static final String POTENTIAL_GAP = "POTENTIAL_GAP";
    public static final String PREV_DEF      = "PREV_DEF";
    
    
    // We need this feild to fileter the data based on the CYCLE_ID on the SubCycleView.
    public static final String CYCLE_ID      = "CYCLE_ID";
    
    private String 	subCycleId;
    private String  subCycleCode;
    private String 	description;
    private String 	status;
    private String  deficiency ;
    private String  gap;
    private Date 	dueDate;
    private String  ownerId;
    private String  ownerSubCycle;
    private String  displayStatus;
    private String  subcycleEmailId;
    private String  dueDateString;
    private boolean docChange;

    private String cycleId;
    private String questionId;

    // Cumulative risk of all the ControlObjectives of this SubCycle.
    private String risk;
       
    private Collection controlObjectives;
    private Collection sub_cycles;
    private Collection questions; 
      
    private boolean show = false;
    private boolean submitLock = false;

    private int overFlowId;

    private Date startDate;

    private String questionHeader;
    private String questionFooter;


    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        
        if(status != null && (status.equals("INPROGRESS")|| status.equals("NOT_STARTED") || status.equals("COMPLETE")))
            this.status = status;
        else
            this.status="";
        
        this.status = status;
    }
    /**
     * @return Returns the subCycleId.
     */
    public String getSubCycleId() {
        return subCycleId;
    }
    /**
     * @param subCycleId The subCycleId to set.
     */
    public void setSubCycleId(String subCycleId) {
        this.subCycleId = subCycleId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getSubCycleCode() {
        return subCycleCode;
    }

    public void setSubCycleCode(String subCycleCode) {
        this.subCycleCode = subCycleCode;
    }

    /**
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return Returns the dueDate.
     */
    public String getDueDate() {
        if(dueDate != null){
            return DateFormat.getDateInstance(DateFormat.MEDIUM).format(dueDate);
        }
        else 
           return "";
        
    }
    /**
     * @param dueDate The dueDate to set.
     */
    public void setDueDate(Date dueDate) {
        
        this.dueDate = dueDate;
    }
    
    /**
     * @return Returns the show.
     */
    public boolean isShow() {
        return show;
    }
    /**
     * @param show The show to set.
     */
    public void setShow(boolean expand) {
        this.show = expand;
    }
    /**
     * @return Returns the deficiency.
     */
    public String getDeficiency() {
        return deficiency;
    }
    /**
     * @param deficiency The deficiency to set.
     */
    public void setDeficiency(String defeciency) {
        
        if(defeciency != null && (defeciency.equals("Y")|| defeciency.equals("N")))
            this.deficiency = defeciency;
        else
            this.deficiency="";
    }
    /**
     * @return Returns the controlObjectives.
     */
    public Collection getControlObjectives() {
        return controlObjectives;
    }
    /**
     * @param controlObjectives The controlObjectives to set.
     */
    public void setControlObjectives(Collection controlObjectives) {
    	Collections.sort((List)controlObjectives);
        this.controlObjectives = controlObjectives;
    }
    /**
     * @return Returns the questions.
     */
    public Collection getQuestions() {
        return questions;
    }
    /**
     * @param questions The questions to set.
     */
    public void setQuestions(Collection questions) {
        this.questions = questions;
        setQuestionNumbers();
    }
    /**
     * @return Returns the gap.
     */
    public String getGap() {
        
        return gap;
    }
    /**
     * @param gap The gap to set.
     */
    public void setGap(String gap) {
        
        if(gap != null && (gap.equals("Y")|| gap.equals("N")))
           this.gap = gap;
        else
            this.gap="";
    }
    
    public void setSubGap(String gap){
 
        if(gap != null && (gap.equals("Y")|| gap.equals("N")))
            this.gap = gap;
         else
             this.gap="";

        if(gap==null){
        	if(status!=null && status.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
        		this.gap="N";
        	}
        }
    }
    /**
     * @return Returns the risk.
     */
    public String getRisk() {
            
        if(risk == null || risk ==""){
            generateRisk();
        }
        
        return risk;
    }
    /**
     * 
     */
    private void generateRisk() {
        
        StringBuffer cumulativeRisk  = new StringBuffer();
        Iterator     itr             = controlObjectives.iterator();
        
        int i = 0;
        while(itr.hasNext()){
            i++;
            String risk = new String(i+"."+((ControlObjectiveNew)itr.next()).getRisk());
            //cumulativeRisk.append(i+"."+((ControlObjectiveNew)itr.next()).getRisk()+"<br\\>");
            cumulativeRisk.append(risk);
                                    
        }
        
        if(cumulativeRisk.toString() != ""){
            risk = cumulativeRisk.toString();
        }
        
    }
    /**
     * @param risk The risk to set.
     */
    public void setRisk(String risk) {
        
       this.risk = risk;
            
    }
    
    public int compareTo(Object o){
    	int value = ((SubCycle)o).subCycleId.compareTo(subCycleId);
    	return -value;
    }



    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "SubCycle Info :"      + '\n');
        buffer.append("SubCycleId  :"+ subCycleId  + '\n');
        buffer.append("Description :"+ description + '\n');
        buffer.append("DueDate     :"+ dueDate     + '\n');
        buffer.append("Status      :"+ getStatus() + '\n');
        buffer.append("Gap         :"+ gap         + '\n');
        buffer.append("Deficiency  :"+ deficiency  + '\n');
        buffer.append("Risk        :"+ risk        + '\n');
        buffer.append("Lock        :"+ submitLock  + '\n');
        
//        if(controlObjectives != null){
//            
//            buffer.append("Number of Control Objectives : "+ controlObjectives.size());
//            Iterator itr = controlObjectives.iterator();
//            
//            while(itr.hasNext()){
// 	             buffer.append(((ControlObjectiveNew)itr.next()).toString());
// 	        }
//        } 
//        else{
//            buffer.append("There are no ControlObjectives Assigned for this SubCycle :"+ subCycleId +'\n');
//        }
        
        if(questions != null){
            
            buffer.append("Number of Questions : "+ questions.size());
            Iterator itr = questions.iterator();
            
            while(itr.hasNext()){
 	             buffer.append(((QuestionNew)itr.next()).toString());
 	        }
        } 
        else{
            buffer.append("There are no Questions Assigned for this SubCycle :"+ subCycleId +'\n');
        }
        
        return buffer.toString();
    }
    /**
     * @return Returns the cycleId.
     */
    public String getCycleId() {
        return cycleId;
    }
    /**
     * @param cycleId The cycleId to set.
     */
    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }
    
	/**
	 * @return Returns the ownerId.
	 */
	public String getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId The ownerId to set.
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	
	/**
	 * @return Returns the submitLock.
	 */
	public boolean isSubmitLock() {
		return submitLock;
	}
	/**
	 * @param submitLock The submitLock to set.
	 */
	public void setSubmitLock(boolean submitLock) {
		if(!this.submitLock){
			this.submitLock = submitLock;
		}
	}
	
	/**
	 * UnLock the submit button only if all the control objectives in the
	 * subcycle have a status of complete
	 * @param submitLock The submitLock to set.
	 */
	public void setSubmitLock() {

        enableDisableButtonOnStartDate();

        Date currentDate = new Date(System.currentTimeMillis());
        Date startdate = new Date(startDate.getTime());

        if ((currentDate.before(startdate))){
            submitLock=true;
        }

        Iterator controlObjectiveIterator = controlObjectives.iterator();
		
		while(controlObjectiveIterator.hasNext()){
			
			ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew)controlObjectiveIterator.next();
			
			//The status should never be null
			if(controlObjectiveNew.getStatus()==null){
				submitLock=true;
			}
			
			if(controlObjectiveNew.getStatus()!=null && !controlObjectiveNew.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) && !submitLock){
				submitLock=true;
			}

			
		}
		
	}

    private void enableDisableButtonOnStartDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date currentDate = new Date(System.currentTimeMillis());
        Date startdate = new Date(startDate.getTime());
        String cuDate = sdf.format(currentDate);
        String coDate = sdf.format(startdate);
        try {
            currentDate = sdf.parse(cuDate);
            startdate = sdf.parse(coDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (currentDate.before(startdate)){
            submitLock=true;
        }
    }

    private void setQuestionNumbers(){
        int counter = 1;
        Iterator iterator = questions.iterator();

        while(iterator.hasNext()){
            QuestionNew questionNew = (QuestionNew)iterator.next();
            questionNew.setQuestionNumber(counter);
            counter++;
        }
    }
	
	
	/**
	 * @return Returns the sub_cycles.
	 */
	public Collection getSub_cycles() {
		return sub_cycles;
	}
	/**
	 * @param sub_cycles The sub_cycles to set.
	 */
	public void setSub_cycles(Collection sub_cycles) {
		this.sub_cycles = sub_cycles;
	}
	
	
	/**
	 * @return Returns the ownerSubCycle.
	 */
	public String getOwnerSubCycle() {
		return ownerSubCycle;
	}
	/**
	 * @param ownerSubCycle The ownerSubCycle to set.
	 */
	public void setOwnerSubCycle(String ownerSubCycle) {
		this.ownerSubCycle = ownerSubCycle;
	}
	
	/**
	 * @return Returns the displayStatus.
	 */
	public String getDisplayStatus() {
		displayStatus = SoxicUtil.getDisplayStatus(status);
		return displayStatus;
	}
	
	/**
	 * @param displayStatus The displayStatus to set.
	 */
	public void setDisplayStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}

    public String getId(){
        StringTokenizer stringTokenizer = new StringTokenizer(subCycleId,".");
        String period = stringTokenizer.nextToken();
        String country = stringTokenizer.nextToken();
        String cycle = stringTokenizer.nextToken();
        String subCycle = stringTokenizer.nextToken();
        return period+"."+country+"."+cycle+"."+subCycle;
    }

    public String getCycleIdPart(){
         StringTokenizer stringTokenizer = new StringTokenizer(subCycleId,".");
        String period = stringTokenizer.nextToken();
        String cycle = stringTokenizer.nextToken();
        return period+"."+cycle;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }

    public String getSubcycleEmailId() {
        return subcycleEmailId;
    }

    public void setSubcycleEmailId(String subcycleEmailId) {
        this.subcycleEmailId = subcycleEmailId;
    }

    public String getDueDateString() {
        return dueDateString;
    }

    public void setDueDateString(String dueDateString) {
        this.dueDateString = dueDateString;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getQuestionHeader() {
        return questionHeader;
    }

    public void setQuestionHeader(String questionHeader) {
        this.questionHeader = questionHeader;
    }

    public String getQuestionFooter() {
        return questionFooter;
    }

    public void setQuestionFooter(String questionFooter) {
        this.questionFooter = questionFooter;
    }

    public SubCycle(String subCycleId, String description) {
        this.subCycleId = subCycleId;
        this.description = description;
    }

    public SubCycle(){
        
    }
}
