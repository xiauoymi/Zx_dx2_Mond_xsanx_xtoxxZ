package com.monsanto.wst.soxic.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.facade.reports.OwnerStatusReportFacade;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 3, 2006
 * Time: 10:46:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class SelectSubCycleController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        OwnerStatusReportFacade ownerStatusReportFacade = new OwnerStatusReportFacade();
        getSubCyclesBasedOnSelections(helper,ownerStatusReportFacade);
    }

    private void getSubCyclesBasedOnSelections(UCCHelper helper, OwnerStatusReportFacade ownerStatusReportFacade) throws IOException {
        try {
            ownerStatusReportFacade.buildSubCycleListOnSelection(helper);
        } catch (DatabaseException e) {
            e.printStackTrace();
        }
    }
    
}
