package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.SecurityVisibleForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 16, 2005
 * Time: 9:22:17 AM
 *
 * This class contains the security for the Doc Change Menu screen. Based on the
 * user logging in, the respective links are availble for view. The user status
 * is retrieved from the owner object, which contains whether they are IA/Admin/IA_USER.
 * 
 */

public class DocChangeMenuAction extends Action{

     public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
			                     HttpServletRequest request,
			                     HttpServletResponse response) {

        SecurityVisibleForm securityvisibleform = (SecurityVisibleForm)form;

        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);

        boolean IAUser = owner.isIAUser();
        boolean IA = owner.isIA();
        boolean Admin = owner.isAdmin();
        boolean docChange = owner.isDocChange();

        if ((IAUser) || (IA) || (Admin) || (docChange)){
            securityvisibleform.setActivityreview(true);
            securityvisibleform.setDochangereq(true);
        }else {
            securityvisibleform.setActivityreview(false);
            securityvisibleform.setDochangereq(false);
        }

        if ((IA) || (Admin)){
            securityvisibleform.setCyclemaintain(true);
            securityvisibleform.setSubcyclemaintain(true);
            securityvisibleform.setViewcreatenewperiod(true);
         }
            else{
                securityvisibleform.setCyclemaintain(false);
                securityvisibleform.setSubcyclemaintain(false);
                securityvisibleform.setViewcreatenewperiod(false);
        }

        return mapping.findForward("success");
    }
}
