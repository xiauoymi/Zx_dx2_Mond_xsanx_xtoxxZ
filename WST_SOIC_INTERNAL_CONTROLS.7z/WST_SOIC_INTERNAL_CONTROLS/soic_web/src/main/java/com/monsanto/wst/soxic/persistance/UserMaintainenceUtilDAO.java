package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 5, 2005
 * Time: 9:07:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserMaintainenceUtilDAO {

    public List selectUserMaintainenceStates(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        List userMaintainenceStates = new ArrayList();

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT VALUE FROM LOOKUP WHERE TYPE='USER_MT_ST'");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                 userMaintainenceStates.add(rs.getString("VALUE"));
            }

        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }

        return userMaintainenceStates;

    }
}
