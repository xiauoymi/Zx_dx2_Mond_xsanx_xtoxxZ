package com.monsanto.wst.soxic.workflow.DocumentChangeOperations.mocks;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 3:46:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IAAdminEmailDAOInt {
    List select();
}
