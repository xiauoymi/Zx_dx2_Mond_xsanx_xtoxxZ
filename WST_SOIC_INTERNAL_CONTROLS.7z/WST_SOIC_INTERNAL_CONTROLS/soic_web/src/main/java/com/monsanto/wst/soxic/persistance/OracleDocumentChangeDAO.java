package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.DocumentChangeDetails;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;

import java.util.*;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 4, 2005
 * Time: 5:16:01 PM
 */
public class OracleDocumentChangeDAO extends OracleAbstractDAO{

    public static final String SELECT_DOCUMENT_REQUESTS="SELECT_DOCUMENT_REQUESTS";

    public static final String SELECT_INIT_REQ_ACT_OWNER="INITIALIZE_FOR_OWNERS_IN_TABLE";
    public static final String SELECT_INIT_REQ_OTH_ACT_OWNER="INITIALIZE_FOR_OTHER_ACTIVITY_OWNERS_IN_TABLE";
    public static final String SELECT_INIT_REQ_IA_USER="INITIALIZE_FOR_IA_USERS_IN_TABLE";
    public static final String SELECT_INIT_REQ_SUB_CYCLE_OWNER="INITIALIZE_FOR_SUB_CYCLE_OWNERS_IN_TABLE";
    public static final String SELECT_INIT_REQ_IA_OWNER="INITIALIZE_FOR_IA_OWNERS_IN_TABLE";

    /**
     * format SEL_OWNER_TYPE_LEVEL
     */
    public static final String SEL_ACTOWN_PER_SUBCYCLE="SELECT_ACTIVITY_FOR_REQUESTED_ACTIVITY_OWNERS_PER_SUB_CYCLE";
    public static final String SEL_OTHACTOWN_PER_SUBCYCLE="SELECT_ACTIVITY_FOR_NON_REQUESTED_ACTIVITY_OWNERS_PER_SUB_CYCLE";
    public static final String SEL_SUBOWN_PER_SUBCYCLE="SELECT_ACTIVITY_FOR_SUB_CYLCE_OWNER_PER_SUB_CYCLE";
    public static final String SEL_IAADMINOWN_PER_SUBCYCLE="SELECT_ACTIVITY_FOR_IA_ADMIN_PER_SUB_CYCLE";
    public static final String SEL_IAOWN_PER_SUB_CYCLE="SELECT_ACTIVITY_FOR_IA_PER_SUB_CYCLE";

    public void update(Collection soxicBaseModels) throws DatabaseException, Exception{};


    protected  String buildSelectQuery(Map fields){
        return "";
    }

       protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception{
        DocumentChangeDetails documentChangeDetails= new DocumentChangeDetails();
       try{
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumns = rsmd.getColumnCount();

            // Get the column names; column indices start from 1
            for (int i=1; i<numColumns+1; i++) {
                String columnName = rsmd.getColumnName(i);
                if(columnName.equalsIgnoreCase("OWNER_ID")){
                    documentChangeDetails.setRequestor(rs.getString("OWNER_ID"));
                }
               if(columnName.equalsIgnoreCase("TARGET_ID")){
                    documentChangeDetails.setActivityId(rs.getString("TARGET_ID"));
                   documentChangeDetails.initializeDetails();
                }
               if(columnName.equalsIgnoreCase("REQ_TYPE")){
                    documentChangeDetails.setRequestType(rs.getString("REQ_TYPE"));

                }
               if(columnName.equalsIgnoreCase("OWNER_ID")){
                    documentChangeDetails.setRequestor(rs.getString("OWNER_ID"));

                }
            }

        }catch(SQLException e){
            e.printStackTrace();
        }
        return documentChangeDetails;
    }

    protected void populateModel(ResultSet rs,DocumentChangeDetails documentChangeDetails) throws DatabaseException, Exception{
        //DocumentChangeDetails documentChangeDetails= new DocumentChangeDetails();
       try{
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumns = rsmd.getColumnCount();

            // Get the column names; column indices start from 1
            for (int i=1; i<numColumns+1; i++) {
                String columnName = rsmd.getColumnName(i);
                if(columnName.equalsIgnoreCase("OWNER_ID")){
                    documentChangeDetails.setRequestor(rs.getString("OWNER_ID"));
                }
                if(columnName.equalsIgnoreCase("OCREQ_ID")){
                    documentChangeDetails.setOcreqResponseId(rs.getString("OCREQ_ID"));
                }
               if(columnName.equalsIgnoreCase("TARGET_ID")){
                    documentChangeDetails.setActivityId(rs.getString("TARGET_ID"));
                   documentChangeDetails.initializeDetails();
                }
               if(columnName.equalsIgnoreCase("REQ_TYPE")){
                    documentChangeDetails.setRequestType(rs.getString("REQ_TYPE"));

                }
               if(columnName.equalsIgnoreCase("RESP_TYPE")){
                   if(rs.getString("RESP_TYPE").equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
                       documentChangeDetails.setSubCycleStatus(rs.getString("APPROVED"));
                   }
                  if(rs.getString("RESP_TYPE").equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){

                       documentChangeDetails.setiAStatus(rs.getString("APPROVED"));
                   }
                    documentChangeDetails.setRequestType(rs.getString("REQ_TYPE"));

                }
               if(columnName.equalsIgnoreCase("OWNER_ID")){
                    documentChangeDetails.setRequestor(rs.getString("OWNER_ID"));

                }
            }

        }catch(SQLException e){
            e.printStackTrace();
        }
        //return documentChangeDetails;
    }

    public int create(SoxicBaseModel soxicBaseModel)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            OwnerChangeRequest ownerChangeRequest = (OwnerChangeRequest)soxicBaseModel;
            preparedStatement = connection
                    .prepareStatement(ownerChangeRequest.getQuery("INSERT"));
            ownerChangeRequest.setParameters(preparedStatement,"INSERT");
            result = preparedStatement.executeUpdate();


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return result;
    }

    public void selectAll(String selectType,Owner owner,Map map)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
            preparedStatement = connection
                    .prepareStatement(getQuery(selectType));
            if(selectType.equalsIgnoreCase(SELECT_INIT_REQ_ACT_OWNER) || selectType.equalsIgnoreCase(SELECT_INIT_REQ_SUB_CYCLE_OWNER) || selectType.equalsIgnoreCase(SELECT_INIT_REQ_OTH_ACT_OWNER)){
                preparedStatement.setString(1,owner.getOwnerId());
            }


            rs = preparedStatement.executeQuery();
            while(rs.next()){
                documentChangeDetails = new DocumentChangeDetails();
                documentChangeDetails = (DocumentChangeDetails)populateModel(rs);
                if(documentChangeDetails.getActivityId()!=null || documentChangeDetails.getActivityId().length()>0){
                   map.put(documentChangeDetails.getActivityId(),documentChangeDetails); 
                }

            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        //documentReviewList.add(map.values());
        // return documentReviewList;
       //return map;

    }

    public void selectForSubCycle(String selectType,Owner owner,String subCycleId,Map reviewMap)throws Exception{

        if(selectType.equalsIgnoreCase(SEL_ACTOWN_PER_SUBCYCLE)){
            selectRequestActOwnerPerSub(subCycleId,owner,reviewMap);
        }

        if(selectType.equalsIgnoreCase(SEL_OTHACTOWN_PER_SUBCYCLE)){
            selectNonActOwnerPerSub(subCycleId,owner,reviewMap);
        } 

        if(selectType.equalsIgnoreCase(SEL_SUBOWN_PER_SUBCYCLE)){
            selectRequestSubOwnerPerSub(subCycleId,owner,reviewMap);
        }
        if(selectType.equalsIgnoreCase(SEL_IAOWN_PER_SUB_CYCLE)){
            selectRequestActOwnerPerSub(subCycleId,owner,reviewMap);
        }
        if(selectType.equalsIgnoreCase(SEL_IAADMINOWN_PER_SUBCYCLE)){
            selectRequestIaOwnerPerSub(subCycleId,owner,reviewMap);
        }

    }

    /**
     *
     * @param subCycleId
     * @param owner
     * @param reviewMap
     * @throws Exception
     */
    private void selectRequestActOwnerPerSub(String subCycleId,Owner owner,Map reviewMap)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
//            preparedStatement = connection
//                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A WHERE CO.SUB_CYCLE_ID=? AND OCR.OWNER_ID =? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID=OCR.TARGET_ID AND OCR.OCREQ_ID=OCRR.OCREQ_ID");
           preparedStatement = connection
                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A WHERE CO.SUB_CYCLE_ID=? AND OCR.OWNER_ID =? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID=OCR.TARGET_ID AND OCR.OCREQ_ID=OCRR.OCREQ_ID");

            preparedStatement.setString(1,subCycleId);
            preparedStatement.setString(2,owner.getOwnerId());
            rs = preparedStatement.executeQuery();
            while(rs.next()){


                if(reviewMap.get(rs.getString("OCREQ_ID"))==null){
                    documentChangeDetails = new DocumentChangeDetails();
                    documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY);
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }else{
                    documentChangeDetails = (DocumentChangeDetails)reviewMap.get(rs.getString("OCREQ_ID"));
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

    }

    /**
     *populate the review map with Document Change Details of other activity owners
     * @param subCycleId
     * @param owner
     * @param reviewMap
     * @throws Exception
     */
    private void selectNonActOwnerPerSub(String subCycleId,Owner owner,Map reviewMap)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
            preparedStatement = connection
                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA WHERE CO.SUB_CYCLE_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID = OA.ACTIVITY_ID AND A.ACTIVITY_ID=OCR.TARGET_ID AND OCR.OCREQ_ID=OCRR.OCREQ_ID");

            preparedStatement.setString(1,subCycleId);
//            preparedStatement.setString(2,owner.getOwnerId());
            rs = preparedStatement.executeQuery();
            while(rs.next()){
               if(reviewMap.get(rs.getString("OCREQ_ID"))==null){
                    documentChangeDetails = new DocumentChangeDetails();
                    documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_OTHER_ACTIVITY);
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }else{
                    documentChangeDetails = (DocumentChangeDetails)reviewMap.get(rs.getString("OCREQ_ID"));
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        
    }

    private void selectRequestSubOwnerPerSub(String subCycleId,Owner owner,Map reviewMap)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        //List documentReviewList = new ArrayList();
        //Map map = new HashMap();
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
            preparedStatement = connection
                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A,OWNER_SUB_CYCLE OSC WHERE OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=? AND OSC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND A.ACTIVITY_ID = OCR.TARGET_ID AND OCR.OCREQ_ID = OCRR.OCREQ_ID");

            preparedStatement.setString(1,owner.getOwnerId());
            preparedStatement.setString(2,subCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
//                documentChangeDetails = new DocumentChangeDetails();
//                //map.put(documentChangeDetails.getActivityId(),documentChangeDetails);
//                documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE);
//                populateModel(rs,documentChangeDetails);
//                revList.add(documentChangeDetails);
               if(reviewMap.get(rs.getString("OCREQ_ID"))==null){
                    documentChangeDetails = new DocumentChangeDetails();
                    documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE);
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }else{
                    documentChangeDetails = (DocumentChangeDetails)reviewMap.get(rs.getString("OCREQ_ID"));
                    populateModel(rs,documentChangeDetails);
                    reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                }



            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }

    private void selectRequestIaOwnerPerSub(String subCycleId,Owner owner,Map reviewMap)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
            preparedStatement = connection
                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A WHERE CO.SUB_CYCLE_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID=OCR.TARGET_ID AND OCR.OCREQ_ID=OCRR.OCREQ_ID");
//            preparedStatement = connection
//                    .prepareStatement("SELECT OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.REQ_TYPE,OCRR.OCREQ_ID,OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,CTRL_OBJ CO,ACTIVITY A WHERE CO.SUB_CYCLE_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND (A.ACTIVITY_ID=OCR.TARGET_ID OR A.ACTIVITY_ID=OCR.SOURCE_ID) AND OCR.OCREQ_ID=OCRR.OCREQ_ID");

            preparedStatement.setString(1,subCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                if(reviewMap.get(rs.getString("OCREQ_ID"))==null){
                     documentChangeDetails = new DocumentChangeDetails();
                     documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_IA);
                     populateModel(rs,documentChangeDetails);
                     reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                 }else{
                        documentChangeDetails = (DocumentChangeDetails)reviewMap.get(rs.getString("OCREQ_ID"));
                        populateModel(rs,documentChangeDetails);
                        reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                 }

            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

    }

    public void initializeDocumentChangeReviewFormDetails(DocumentChangeReviewForm documentChangeReviewForm)throws Exception{

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

//            preparedStatement = connection
//                    .prepareStatement("SELECT OCRR.OCREQ_ID,OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OVERFLOW_ID,OCR.OWNER_ID,OCR.REQ_TYPE,OCR.REQ_TEXT,OCR.TARGET_ID,OCR.PRIORITY FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,ACTIVITY A WHERE OCR.TARGET_ID=? AND A.ACTIVITY_ID = OCR.TARGET_ID AND OCR.OCREQ_ID = OCRR.OCREQ_ID");
            preparedStatement = connection
                    .prepareStatement("SELECT OCRR.OCREQ_ID,OCRR.RESP_TYPE,OCRR.APPROVED,OCRR.NOTES,OCRR.RESP_DATE,OCR.OVERFLOW_ID,OCR.OWNER_ID,OCR.REQ_TYPE,OCR.REQ_TEXT,OCR.TARGET_ID,OCR.PRIORITY FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR,ACTIVITY A WHERE OCR.OCREQ_ID=? AND A.ACTIVITY_ID = OCR.TARGET_ID AND OCR.OCREQ_ID = OCRR.OCREQ_ID");

            //preparedStatement.setString(1,documentChangeReviewForm.getIdentifier());
            preparedStatement.setString(1,documentChangeReviewForm.getOcreqResponse());

            rs = preparedStatement.executeQuery();
            while(rs.next()){
                initDetails(rs,documentChangeReviewForm);
            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

    }

    private void initDetails(ResultSet rs,DocumentChangeReviewForm documentChangeReviewForm)throws Exception{

        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW)){

            if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){

                documentChangeReviewForm.setNewActivityDescription(rs.getString("REQ_TEXT"));
                documentChangeReviewForm.setOverFlowId(rs.getInt("OVERFLOW_ID"));
                documentChangeReviewForm.setPriority(rs.getString("PRIORITY"));
            }
           if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
                documentChangeReviewForm.setPriority(rs.getString("PRIORITY"));
                documentChangeReviewForm.setReasonForRemoval(rs.getString("REQ_TEXT"));
            }
           if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){

                documentChangeReviewForm.setNewActivityDescription(rs.getString("REQ_TEXT"));
                documentChangeReviewForm.setOverFlowId(rs.getInt("OVERFLOW_ID"));
                documentChangeReviewForm.setPriority(rs.getString("PRIORITY"));
            }
            //documentChangeReviewForm.setReasonToDisapprove("");
            if(rs.getString("RESP_TYPE").equalsIgnoreCase(documentChangeReviewForm.getSource_type())){
                if(rs.getString("APPROVED").equalsIgnoreCase("N")){
                    setReasonToDisapprove(rs, documentChangeReviewForm);

                    documentChangeReviewForm.setStatus("reject");
                }
                if(rs.getString("APPROVED").equalsIgnoreCase("Y")){
                    //documentChangeReviewForm.setReasonToDisapprove(rs.getString("NOTES"));
                    documentChangeReviewForm.setStatus("approve");
                    documentChangeReviewForm.setReasonToDisapprove("");
                }
                if(rs.getString("APPROVED").equalsIgnoreCase("P")){
                    documentChangeReviewForm.setStatus("");
                    documentChangeReviewForm.setReasonToDisapprove("");
                }
            }
            if(rs.getString("RESP_TYPE").equalsIgnoreCase(documentChangeReviewForm.getSource_type())){
                if(rs.getString("APPROVED").equalsIgnoreCase("N")){
                    //documentChangeReviewForm.setReasonToDisapprove(rs.getString("NOTES"));
                    setReasonToDisapprove(rs, documentChangeReviewForm);
                    documentChangeReviewForm.setStatus("reject");
                }
                if(rs.getString("APPROVED").equalsIgnoreCase("Y")){
                    //documentChangeReviewForm.setReasonToDisapprove(rs.getString("NOTES"));
                    documentChangeReviewForm.setStatus("approve");
                    documentChangeReviewForm.setReasonToDisapprove("");
                }
                if(rs.getString("APPROVED").equalsIgnoreCase("P")){
                    documentChangeReviewForm.setStatus("");
                    documentChangeReviewForm.setReasonToDisapprove("");
                }
            }

        }

        if((documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW) && !documentChangeReviewForm.isViewUpdateButton())){
            if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){

                documentChangeReviewForm.setNewActivityDescription(rs.getString("REQ_TEXT"));
            }
           if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){

                documentChangeReviewForm.setReasonForRemoval(rs.getString("REQ_TEXT"));
            }
           if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){

                documentChangeReviewForm.setNewActivityDescription(rs.getString("REQ_TEXT"));
            }           
        }



    }

    private void setReasonToDisapprove(ResultSet rs, DocumentChangeReviewForm documentChangeReviewForm) throws SQLException {
        String reason = rs.getString("NOTES");
        if(reason!=null && reason.length()>0){
            documentChangeReviewForm.setReasonToDisapprove(reason);
        }else{
            documentChangeReviewForm.setReasonToDisapprove("");
        }
    }

    public void setOldActivityDescription(DocumentChangeReviewForm documentChangeReviewForm)throws Exception{

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT DESCRIPTION,PRIORITY FROM ACTIVITY A WHERE A.ACTIVITY_ID=?");

            preparedStatement.setString(1,documentChangeReviewForm.getIdentifier());

            rs = preparedStatement.executeQuery();
            while(rs.next()){
                documentChangeReviewForm.setOldActivityDescription(rs.getString("DESCRIPTION"));
                documentChangeReviewForm.setPriority(rs.getString("PRIORITY"));
            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }

    public String getQuery(String type){
        if(type.equalsIgnoreCase(SELECT_DOCUMENT_REQUESTS)){
            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,OCREQ_RESPONSE OCRE,OWNER_ACTIVITY OA,ACTIVITY A,CTRL_OBJ CO,OWNER_SUB_CYCLE OSC WHERE OCRE.OCREQ_ID= ORCR.OCREQ_ID AND((ORCR.OWNER_ID =?) OR (OA.ACTIVITY_ID=ORCR.TARGET_ID AND ORCR.OWNER_ID<>OA.OWNER_ID) OR (ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND CO.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID AND OSC.OWNER_ID=?))";
        }
        if(type.equalsIgnoreCase(SELECT_INIT_REQ_ACT_OWNER)){
            //return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR WHERE ORCR.OWNER_ID=?";
           return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE ORCR.OWNER_ID=?  AND ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CS.CYCLE_ID=SC.CYCLE_ID AND CS.STATE='RELEASED'";
        }
        if(type.equalsIgnoreCase(SELECT_INIT_REQ_OTH_ACT_OWNER)){
            //return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,OWNER_ACTIVITY OA WHERE ORCR.TARGET_ID=OA.ACTIVITY_ID AND OA.OWNER_ID=?";
            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,OWNER_ACTIVITY OA,ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE ORCR.TARGET_ID=OA.ACTIVITY_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID = A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CS.CYCLE_ID=SC.CYCLE_ID AND CS.STATE='RELEASED'";
        }
//        if(type.equalsIgnoreCase(SELECT_INIT_REQ_IA_OWNER)){
//            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR WHERE ORCR.OWNER_ID=?";
//        }
        if(type.equalsIgnoreCase(SELECT_INIT_REQ_SUB_CYCLE_OWNER)){
            //return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,ACTIVITY A,CTRL_OBJ CO,OWNER_SUB_CYCLE OSC WHERE ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND CO.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND OSC.OWNER_ID=?";
            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,ACTIVITY A,CTRL_OBJ CO,OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS WHERE ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND CO.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND OSC.OWNER_ID=? AND SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID AND SC.CYCLE_ID = CS.CYCLE_ID AND CS.STATE = 'RELEASED'";
        }
        if(type.equalsIgnoreCase(SELECT_INIT_REQ_IA_OWNER)){
            //return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR";
            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CS.CYCLE_ID=SC.CYCLE_ID AND (CS.STATE='RELEASED' OR CS.STATE='LOCKED')";
        }
        if(type.equalsIgnoreCase(SELECT_INIT_REQ_IA_USER)){
            //return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR";
            return "SELECT ORCR.OWNER_ID,ORCR.TARGET_ID FROM OWNER_CHANGE_REQUEST ORCR,ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE ORCR.TARGET_ID=A.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CS.CYCLE_ID=SC.CYCLE_ID AND (CS.STATE='RELEASED')";
        }


        return "";

    }

    public void correctNewActivityDescription(DocumentChangeReviewForm documentChangeReviewForm)throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        String description = documentChangeReviewForm.getNewActivityDescription();
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT TEXT_CHUNK FROM TEXT_OVERFLOW WHERE OVERFLOW_ID=? ORDER BY SEQUENCE");

            preparedStatement.setInt(1,documentChangeReviewForm.getOverFlowId());

            rs = preparedStatement.executeQuery();
            while(rs.next()){
               description = description+rs.getString("TEXT_CHUNK");
            }
            documentChangeReviewForm.setNewActivityDescription(description);

        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }

  
    public Map selectAllActivitiesForApproval()throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Map reviewMap = new HashMap();
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            DocumentChangeDetails documentChangeDetails=null;
            preparedStatement = connection
                    .prepareStatement("SELECT OCRR.RESP_TYPE, OCRR.APPROVED, OCRR.NOTES, OCRR.RESP_DATE,\n" +
                    "       OCR.OWNER_ID, OCR.REQ_TYPE, OCRR.OCREQ_ID, OCR.TARGET_ID\n" +
                    "  FROM OWNER_CHANGE_REQUEST OCR,\n" +
                    "       OCREQ_RESPONSE OCRR,\n" +
                    "       CTRL_OBJ CO,\n" +
                    "       ACTIVITY A,\n" +
                    "       SUB_CYCLE SC,\n" +
                    "       CYCLE C,\n" +
                    "       CYCLE_STATE CS\n" +
                    " WHERE CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID\n" +
                    "   AND SC.CYCLE_ID = C.CYCLE_ID\n" +
                    "   AND C.CYCLE_ID = CS.CYCLE_ID\n" +
                    "   AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID\n" +
                    "   AND A.ACTIVITY_ID = OCR.TARGET_ID\n" +
                    "   AND OCR.OCREQ_ID = OCRR.OCREQ_ID\n" +
                    "   AND (CS.STATE = 'LOCKED' OR CS.STATE = 'RELEASED')");

            rs = preparedStatement.executeQuery();
            while(rs.next()){
                if(reviewMap.get(rs.getString("OCREQ_ID"))==null){
                     documentChangeDetails = new DocumentChangeDetails();
                     documentChangeDetails.setSourceType(SoxicConstants.DOC_CHANGE_ROLE_IA);
                     populateModel(rs,documentChangeDetails);
                     reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                 }else{
                        documentChangeDetails = (DocumentChangeDetails)reviewMap.get(rs.getString("OCREQ_ID"));
                        populateModel(rs,documentChangeDetails);
                        reviewMap.put(documentChangeDetails.getOcreqResponseId(),documentChangeDetails);
                 }
            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return reviewMap;
    }

  public String getCompleteDescription(int overFlowId, String description) throws Exception {
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    StringBuffer buf = new StringBuffer(description);
    try {

      connection = SoxicConnectionFactory.getSoxicConnection();
      preparedStatement = connection
          .prepareStatement("SELECT TEXT_CHUNK FROM TEXT_OVERFLOW WHERE OVERFLOW_ID=? ORDER BY SEQUENCE");

      preparedStatement.setInt(1, overFlowId);

      rs = preparedStatement.executeQuery();
      while (rs.next()) {
        buf.append(rs.getString("TEXT_CHUNK"));
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      //enclose this in a finally block to make
      //sure the connection is closed
      try {
        SoxicConnectionFactory.closeResultSet(rs);
        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
        SoxicConnectionFactory.closeSoxicConnection(connection);
        //connection.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return buf.toString();
  }

  /**
   * Method to fetc hthe Owners based on the table | column names
   * @param id
   * @param tableName
   * @param columnName
   * @return
   * @throws Exception
   */

  public List<String> getOwnerList(String id,String tableName,String columnName) throws Exception{
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    List<String> subCycleOwnerList = new ArrayList<String>();
    String query = "SELECT OWNER_ID FROM "+tableName+" WHERE "+columnName+" = ?";

    try {

      connection = SoxicConnectionFactory.getSoxicConnection();
      preparedStatement = connection
          .prepareStatement(query);

      preparedStatement.setString(1, id);

      rs = preparedStatement.executeQuery();
      while (rs.next()) {
        subCycleOwnerList.add(rs.getString("OWNER_ID"));
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        SoxicConnectionFactory.closeResultSet(rs);
        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
        SoxicConnectionFactory.closeSoxicConnection(connection);
        //connection.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return subCycleOwnerList;
  }
}
