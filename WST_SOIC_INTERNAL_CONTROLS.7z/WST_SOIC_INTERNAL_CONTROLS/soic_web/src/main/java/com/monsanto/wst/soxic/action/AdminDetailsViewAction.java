/*
 * Created on Mar 17, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.AdminDetailsForm;
import com.monsanto.wst.soxic.model.AdminDetails;
import com.monsanto.wst.soxic.model.ItemDetails;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminDetailsViewAction extends Action{
    
    public ActionForward execute(ActionMapping mapping, 
            					 ActionForm form,
            					 HttpServletRequest request, 
            					 HttpServletResponse response) {
        
        AdminDetailsForm adminDetailsForm = (AdminDetailsForm)form;
        
        try {
            
           if(adminDetailsForm.getChange() == null || adminDetailsForm.getChange().equals("")){
               setCycles(adminDetailsForm);
           }
           else if(adminDetailsForm.getChange().equals("cycle")){
               setSubCycles(adminDetailsForm);
               setCycleDetails(adminDetailsForm);
           }
           else if(adminDetailsForm.getChange().equals("sub_cycle")){
               setControlObjectives(adminDetailsForm);
               setSubCycleDetails(adminDetailsForm);
           }
           else if(adminDetailsForm.getChange().equals("ctrl_obj")){
               setActivities(adminDetailsForm);
               setControlObjectiveDetails(adminDetailsForm);
           }
           else if(adminDetailsForm.getChange().equals(("activity"))){
               setActivityDetails(adminDetailsForm);
           }
                 
        } catch (DatabaseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return mapping.findForward("success");
    }
    
    private void setCycles(AdminDetailsForm form) throws DatabaseException, Exception{
        
        //form.setOperations(getOperations());
        form.setCycles(AdminDetails.getCycles());
        
        form.setSubCycles(AdminDetails.getSubCycles(""));
        form.setControlObjectives(AdminDetails.getControlObjectives(""));
        form.setActivities(AdminDetails.getActivities(""));
    }
    
    private void setSubCycles(AdminDetailsForm form) throws DatabaseException, Exception{
        
        form.setSubCycles(AdminDetails.getSubCycles(form.getSelectedCycle()));
        form.setControlObjectives(AdminDetails.getControlObjectives(""));
        form.setActivities(AdminDetails.getActivities(""));
    }
    
    private void setControlObjectives(AdminDetailsForm form) throws DatabaseException, Exception{
        
        form.setControlObjectives(AdminDetails.getControlObjectives(form.getSelectedSubCycle()));
        form.setActivities(AdminDetails.getActivities(""));
    }
    
    private void setActivities(AdminDetailsForm form) throws DatabaseException, Exception{
       
        form.setActivities(AdminDetails.getActivities(form.getSelectedControlObjective()));
    }
    
    private void setCycleDetails(AdminDetailsForm form) throws DatabaseException {
                
        if( form.getSelectedCycle().equals("Choose Cycle")){
           setDefaultData(form);
        }
        else
           setData(form, AdminDetails.getItemDetails("CYCLE", form.getSelectedCycle()));
    }
    
    private void setSubCycleDetails(AdminDetailsForm form) throws DatabaseException {
        
        if( form.getSelectedSubCycle().equals("Choose SC")){
            setCycleDetails(form);
        }
        else 
            setData(form, AdminDetails.getItemDetails("SUB_CYCLE", form.getSelectedSubCycle()));
    }
    
    private void setControlObjectiveDetails(AdminDetailsForm form) throws DatabaseException {
        
        if( form.getSelectedControlObjective().equals("Choose CO")){
            setSubCycleDetails(form);
        }
        else
            setData(form, AdminDetails.getItemDetails("CTRL_OBJ", form.getSelectedControlObjective()));
    }
    
    private void setActivityDetails(AdminDetailsForm form) throws DatabaseException {
        
        if( form.getSelectedActivity().equals("Choose Activity")){
            setControlObjectiveDetails(form);
        }
        else               
            setData(form, AdminDetails.getItemDetails("ACTIVITY", form.getSelectedActivity()));
    }
    
//    private List getOperations() {
//        List operations = new ArrayList();
//        operations.add("Select Status");
//        operations.add("Change");
//        operations.add("Delete");
//        return operations;
//    }
    
    private void setData(AdminDetailsForm form, ItemDetails details){
        if(details != null){
            form.setName(details.getId());
            form.setDescription(details.getDescription());
            
            form.setStartDate( details.getStartDate());
            form.setDueDate( details.getDueDate());
            form.setActivitycodes(details.getActivitycodes());
            form.setCodestring(details.getCodestring());

        }
    }
    
    private void setDefaultData(AdminDetailsForm form){
        form.setName("");
        form.setDescription("");
        form.setStartDate("");
        form.setDueDate("");
    }
}
