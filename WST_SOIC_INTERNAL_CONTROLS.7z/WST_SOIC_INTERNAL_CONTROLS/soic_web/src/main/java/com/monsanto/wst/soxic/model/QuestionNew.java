/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;



/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class QuestionNew extends SoxicBaseModel{
    
    public static final String OWNER_ID        = "OWNER_ID";
    public static final String QUESTION_ID     = "QUESTION_ID";
    public static final String ASSOCIATED_ID   = "ASSOCIATED_ID";
    public static final String ASSOCIATED_TYPE = "ASSOCIATED_TYPE";
    public static final String QUESTION        = "QUESTION";
    public static final String RESPONSE        = "RESPONSE";
    public static final String STATUS          = "STATUS";
    
    public static final String MOD_DATE        = "MOD_DATE";
    public static final String MOD_USER        = "MOD_USER";
    
    private String ownerId;
    private String questionId;
    private String question;
    private String associatedId;
    private String associatedType;
    private String response=""; 
    private String answer = "";
    private String status;
    private java.sql.Date modifiedDate;
    private String modifiedUser;
    private int   questionNumber;
        
    private String responseType="INSERT";
    private boolean displayLink=false;
    private String link;
 
    
      
	/**
	 * @return Returns the displayLink.
	 */
	public boolean isDisplayLink() {
		return displayLink;
	}
	/**
	 * @param displayLink The displayLink to set.
	 */
	public void setDisplayLink(boolean displayLink) {
		this.displayLink = displayLink;
	}
	/**
	 * @return Returns the link.
	 */
	public String getLink() {
		return link;
	}
	/**
	 * @param link The link to set.
	 */
	public void setLink(String link) {
		this.link = link;
	}
    /**
     * @return Returns the question.
     */
    public String getQuestion() {
        return question;
    }
    /**
     * @param question The question to set.
     */
    public void setQuestion(String question) {
        this.question = question;
    }
    /**
     * @return Returns the questionId.
     */
    public String getQuestionId() {
        return questionId;
    }
    /**
     * @param questionId The questionId to set.
     */
    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }
    
    
    /**
     * @return Returns the answer.
     */
    public String getAnswer() {
        return answer;
    }
    /**
     * @param answer The answer to set.
     */
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    /**
     * @return Returns the response.
     */
    public String getResponse() {
        return response;
    }
    /**
     * @param response The response to set.
     */
    public void setResponse(String response) {
        if(response != null && !response.equals("")){
            this.response=response;
            answer=response;
            responseType="UPDATE";
        }
       
    }
    
    public boolean isAnswerModified(){
        boolean modified= false;
        
        if (!answer.equals(response))
            modified = true;
             
         return modified;    
      
    }
    /**
     * @return Returns the associatedId.
     */
    public String getAssociatedId() {
        return associatedId;
    }
    /**
     * @param associatedId The associatedId to set.
     */
    public void setAssociatedId(String associatedId) {
        this.associatedId = associatedId;
    }
    /**
     * @return Returns the associatedType.
     */
    public String getAssociatedType() {
       // return associatedType;
        return "S";
    }
    /**
     * @param associatedType The associatedType to set.
     */
    public void setAssociatedType(String associatedType) {
        this.associatedType = associatedType;
    }
    /**
     * @return Returns the ownerId.
     */
    public String getOwnerId() {
        return ownerId;
    }
    /**
     * @param ownerId The ownerId to set.
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
    
    /**
     * @return Returns the status.
     */
    public String getStatus() {
//    	if(answer!=null && answer.equalsIgnoreCase(SoxicConstants.NORESPONSE)){
//    		status = SoxicConstants.GREEN_INPROCESS;
//    	}
        return status;
    }
    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return Returns the responseType.
     */
    public String getResponseType() {
        return responseType;
    }
    /**
     * @param responseType The responseType to set.
     */
    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }
    /**
     * @return Returns the modifiedDate.
     */
    public java.sql.Date getModifiedDate() {
        
      return new java.sql.Date(new java.util.Date().getTime());
    }
    /**
     * @param modifiedDate The modifiedDate to set.
     */
    public void setModifiedDate(java.sql.Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
    /**
     * @return Returns the modifiedUser.
     */
    public String getModifiedUser() {
        return ownerId;
    }
    /**
     * @param modifiedUser The modifiedUser to set.
     */
    public void setModifiedUser(String modifiedUser) {
        this.modifiedUser = modifiedUser;
    }
    
	/**
	 * @return Returns the questionNumber.
	 */
	public int getQuestionNumber() {
		return questionNumber;
	}
	/**
	 * @param questionNumber The questionNumber to set.
	 */
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "Question Info :"      + '\n');
        buffer.append("Owner is   :"  + ownerId    + '\n');
        buffer.append("AssociatedId:" + associatedId + '\n');
        buffer.append("QuestionId :"  + questionId + '\n');
        buffer.append("Question   :"  + question   + '\n');
        buffer.append("Response   :"  + response   + '\n'); 
        buffer.append("Answer     :"  + answer     + '\n');
        buffer.append("ResponseType   :"  + responseType   + '\n');
        buffer.append("AnswerModified :"+ isAnswerModified() + '\n');
        return buffer.toString();
    }
    
    public String getId(){
        return questionId;
    }

}
