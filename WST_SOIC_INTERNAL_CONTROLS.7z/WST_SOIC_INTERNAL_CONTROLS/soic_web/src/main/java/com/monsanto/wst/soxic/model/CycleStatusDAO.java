package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 22, 2006
 * Time: 9:35:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class CycleStatusDAO {

    public static String getStatusForQuestionWithOwnerAndId(String questionId, String ownerId, String associatedId) {

        String query = SoxicUtil.getQuery("cycle.owner.response.status");
        String status = "";

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, associatedId);
                preparedStatement.setString(2, questionId);
                preparedStatement.setString(3, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                status = rs.getString("STATUS");
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return status;
    }

    public static String getSigChangeStatus(String cycleId, String ownerId) {
        String query = SoxicUtil.getQuery("significant.change.status.cycle.owner");
        List statusList = new ArrayList();

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, cycleId);
                preparedStatement.setString(2, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                    statusList.add(rs.getString("STATUS"));
//                statusList.add(rs.getString("STATUS"));
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        if (statusList.size()>0){
            return (String) statusList.get(0);
        }
        else return null;
    }

    public static Date getDueDateForCycleAndOwner(String identifier, String ownerid) {
        String query = SoxicUtil.getQuery("dueDate.cycle.owner");
        Date dueDate = null;

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, identifier);
                preparedStatement.setString(2, ownerid);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                dueDate = rs.getDate("DUEDATE");
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return dueDate;
    }

    public static Date getCompletedDateForCycleAndOwner(String identifier, String ownerid) {
        String query = SoxicUtil.getQuery("completeDate.cycle.owner");
        Date dueDate = null;

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, identifier);
                preparedStatement.setString(2, ownerid);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                dueDate = rs.getDate("COMPLETEDATE");
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return dueDate;
    }

    public static String getCycleOwnerStatus(String cycleId, String ownerId) {
        String query = SoxicUtil.getQuery("get.cycle.owner.status");
        String status = "";

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, cycleId);
                preparedStatement.setString(2, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                status = rs.getString("STATUS");    
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return status;
    }

    public static List getResponsesForCycleAndOwner(String cycleId, String ownerId) {
        String query = SoxicUtil.getQuery("cycle.owner.response");
        List responseList = new ArrayList();

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, cycleId);
                preparedStatement.setString(2, ownerId);
                preparedStatement.setString(3, SoxicConstants.GREEN_COMPLETE);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                    responseList.add(rs.getString("RESPONSE"));
            }

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return responseList;
    }

    public static void updateOwnerResponseStatusWithIncompleteGapResponse(int responseId) {
        String query = SoxicUtil.getQuery("owner.response.gap.update.status");
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, SoxicConstants.GREEN_INPROCESS);
                preparedStatement.setInt(2,responseId);
                int i = preparedStatement.executeUpdate();
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }
}
