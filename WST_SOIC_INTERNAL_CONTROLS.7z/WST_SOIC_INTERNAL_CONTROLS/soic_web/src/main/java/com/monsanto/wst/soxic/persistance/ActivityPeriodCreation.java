package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.NewPeriodCreationException;
import com.monsanto.wst.soxic.model.ActivityNew;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;
import java.sql.Date;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 24, 2005
 * Time: 4:37:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityPeriodCreation {

   public static void main(String args[])throws Exception{
       ActivityPeriodCreation activityPeriodCreation = new ActivityPeriodCreation();
        long startTime,endTime,dif;
       Connection connection=null;

        startTime = System.currentTimeMillis();
        List ctlCodeActivityList = activityPeriodCreation.createControlCodeActivity("FY05.","RAM01", connection);
        activityPeriodCreation.insertControlCodeActivity(ctlCodeActivityList, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;
   }

    public List createActivity(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List activityList = new ArrayList();

        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ActivityNew activityNew=null;
        try {

            preparedStatement = connection.prepareStatement("SELECT A.ACTIVITY_ID,A.ACTIVITY_CODE,A.DESCRIPTION,A.OVERFLOW_ID, A.PRIORITY FROM ACTIVITY A WHERE A.ACTIVITY_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                activityNew = populateCurrentModel(rs);
                processActivity(activityNew,targetPeriodId);
                activityList.add(activityNew);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public List createOwnerActivity(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List activityList = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ActivityNew activityNew=null;

        try {
            preparedStatement = connection.prepareStatement("SELECT OA.ACTIVITY_ID,OA.OWNER_ID FROM OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                activityNew = populateOwnerModel(rs);
                processActivity(activityNew,targetPeriodId);
                activityList.add(activityNew);            
            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public List createQuestionActivity(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List activityList = new ArrayList();

        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ActivityNew activityNew=null;

        try {

            preparedStatement = connection.prepareStatement("SELECT QA.ACTIVITY_ID,QA.QUESTION_ID FROM QUESTION_ACTIVITY QA WHERE QA.ACTIVITY_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                activityNew = populateQuestionModel(rs);
                processActivity(activityNew,targetPeriodId);
                activityList.add(activityNew);
            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public List createControlCodeActivity(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List activityList = new ArrayList();

        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ActivityNew activityNew=null;

        try {

            preparedStatement = connection.prepareStatement("SELECT COC.ACTIVITY_ID,COC.TYPE,COC.CODE FROM CTRL_OBJ_CODES COC WHERE COC.ACTIVITY_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                activityNew = populateControlCodeModel(rs);
                processActivity(activityNew,targetPeriodId);
                activityList.add(activityNew);
            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }



    private ActivityNew populateCurrentModel(ResultSet rs) throws DatabaseException, Exception{

        ActivityNew activity = new ActivityNew();
        try {
            activity.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activity.setActivityCode(rs.getString(ActivityNew.ACTIVITY_CODE));
            activity.setDescription(rs.getString(ActivityNew.DESCRIPTION));
            activity.setOverFlowId(rs.getInt(ActivityNew.OVERFLOW_ID));
            activity.setPriority(rs.getString(ActivityNew.PRIORITY));
        } catch (SQLException e) {
            throw new DatabaseException("OracleActivityDao - Unable to populate the ActivityNew from the ResultSet :"
                    + e.toString());
        }


        return activity;
    }

    public ActivityNew populateOwnerModel(ResultSet rs){
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setOwnerId(rs.getString(ActivityNew.OWNER_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    public ActivityNew populateQuestionModel(ResultSet rs){
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setQuestionId(rs.getString(ActivityNew.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    private ActivityNew populateControlCodeModel(ResultSet rs){
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setCodeType(rs.getString(ActivityNew.CTRL_CODE_TYPE));
            activityNew.setCode(rs.getString(ActivityNew.CTRL_CODE));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    public void insertNewActivity(List activityList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;

        String query = "INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION,OVERFLOW_ID, STATUS, MOD_DATE, MOD_USER, PRIORITY) VALUES (?, ?, ?,?, ?, ?, ?, ?, ?)";

        try {
            preparedStatement = connection.prepareStatement(query);

            Iterator iterator = activityList.iterator();
            while(iterator.hasNext()){
                ActivityNew activityNew = (ActivityNew)iterator.next();
                preparedStatement.setString(1,activityNew.getActivityId());
                preparedStatement.setString(2,activityNew.getActivityCode());
                preparedStatement.setString(3,activityNew.getControlObjectiveId());
                preparedStatement.setString(4,activityNew.getDescription());
                preparedStatement.setInt(5,activityNew.getOverFlowId());
                preparedStatement.setString(6,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(7,new Date(System.currentTimeMillis()));
                preparedStatement.setString(8,"ADMIN");
                preparedStatement.setString(9,activityNew.getPriority());
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
                e.printStackTrace();
            }
        }
    }

//    protected void insertNewActivity(List activityList){
//        Connection connection = null;
//        PreparedStatement preparedStatement=null;
//
//        String query = "INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)";
//
//        try {
//            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement(query);
//
//            Iterator iterator = activityList.iterator();
//            while(iterator.hasNext()){
//            ActivityNew activityNew = (ActivityNew)iterator.next();
//            preparedStatement.setString(1,activityNew.getActivityId());
//            preparedStatement.setString(2,activityNew.getActivityCode());
//            preparedStatement.setString(3,activityNew.getCtrlObjCode());
//            preparedStatement.setString(4,activityNew.getDescription());
//            preparedStatement.setString(5,"");
//            preparedStatement.setDate(6,new Date(System.currentTimeMillis()));
//            preparedStatement.setString(7,"ADMIN");
//
//
//            int result = preparedStatement.executeUpdate();
//        }
//        catch (SQLException e) {
//            //throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        catch (Exception e) {
//            // throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            try {
//                if (preparedStatement != null)
//                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
////                throw new DatabaseException("OracleDAO - Unable to close database connection : "
////                        + e.toString());
//            }
//        }
//    }

    public void insertOwnerActivity(List activityList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_ACTIVITY (OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = activityList.iterator();
            while(iterator.hasNext()){
                ActivityNew activityNew = (ActivityNew)iterator.next();
                preparedStatement.setString(1,activityNew.getOwnerId());
                preparedStatement.setString(2,activityNew.getActivityId());
                preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
                preparedStatement.setString(5,"ADMIN");
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

//    public void insertOwnerActivity(List activityList){
//        Connection connection = null;
//        PreparedStatement preparedStatement=null;
//
//
//        String query = "INSERT INTO OWNER_ACTIVITY (OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";
//
//        try {
//            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement(query);
//            Iterator iterator = activityList.iterator();
//            while(iterator.hasNext()){
//            ActivityNew activityNew = (ActivityNew)iterator.next();
//            preparedStatement.setString(1,activityNew.getOwnerId());
//            preparedStatement.setString(2,newActivityId);
//            preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
//            preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
//            preparedStatement.setString(5,"ADMIN");
//
//
//            int result = preparedStatement.executeUpdate();
//        }
//        catch (SQLException e) {
//            //throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        catch (Exception e) {
//            // throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            try {
//                if (preparedStatement != null)
//                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
////                throw new DatabaseException("OracleDAO - Unable to close database connection : "
////                        + e.toString());
//            }
//        }
//    }

    public void insertQuestionActivity(List activityList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO QUESTION_ACTIVITY (QUESTION_ID, ACTIVITY_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = activityList.iterator();
            while(iterator.hasNext()){
                ActivityNew activityNew = (ActivityNew)iterator.next();
                preparedStatement.setString(1,activityNew.getQuestionId());
                preparedStatement.setString(2,activityNew.getActivityId());
                //preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(3,new Date(System.currentTimeMillis()));
                preparedStatement.setString(4,"ADMIN");
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void insertControlCodeActivity(List activityList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID, TYPE, CODE) VALUES (?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = activityList.iterator();
            while(iterator.hasNext()){
                ActivityNew activityNew = (ActivityNew)iterator.next();
                preparedStatement.setString(1,activityNew.getActivityId());
                preparedStatement.setString(2,activityNew.getCodeType());
                preparedStatement.setString(3,activityNew.getCode());
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void processActivity(ActivityNew activityNew,String targetPeriodId){
        StringTokenizer st = new StringTokenizer(activityNew.getActivityId(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String subCycleId = st.nextToken();
        String controlObjectiveId = st.nextToken();
        String activityId = st.nextToken();

        String targetControlObjectiveId = targetPeriodId+"."+countryId+"."+cycleId+"."+subCycleId+"."+controlObjectiveId;
        String targetActivityId = targetPeriodId+"."+countryId+"."+cycleId+"."+subCycleId+"."+controlObjectiveId+"."+activityId;
        activityNew.setActivityId(targetActivityId);
        activityNew.setControlObjectiveId(targetControlObjectiveId);
    }

    public List getCycleList(String sourcePeriodId,String targetId)throws Exception{
        List cycleList = new ArrayList();
        Set hashSet = new HashSet();

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ActivityNew activityNew=null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT DISTINCT CYCLE_ID FROM CYCLE WHERE CYCLE_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                String cycle= rs.getString("CYCLE_ID");
                StringTokenizer stringTokenizer = new StringTokenizer(cycle,".");
                String period = stringTokenizer.nextToken();
                String countryId = stringTokenizer.nextToken();
                String cycleId = stringTokenizer.nextToken();

                String newCycleId = period+"."+countryId;
                if(hashSet.add(newCycleId)){
                   cycleList.add(newCycleId); 
                }

                //cycleList.add(cycle);
            }
            //insertNewActivity(activityNew,targetControlObjectiveId);

            //createOwnerActivity(sourceActivityId,targetControlObjectiveId+"."+activityNew.getActivityCode(),period);

            //createQuestionActivity(sourceActivityId,targetControlObjectiveId+"."+activityNew.getActivityCode(),period);

            //createControlCodeActivity(sourceActivityId,targetControlObjectiveId+"."+activityNew.getActivityCode(),period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }
}
