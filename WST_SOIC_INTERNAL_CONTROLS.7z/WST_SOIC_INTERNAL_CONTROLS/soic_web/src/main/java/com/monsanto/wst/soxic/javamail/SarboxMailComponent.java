/*
 * Created on Apr 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.javamail;

import com.monsanto.wst.soxic.model.EmailWrapper;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.model.StatusDAO;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.util.Iterator;
import java.util.List;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class SarboxMailComponent {

    public static String WORKFLOW_PAST_DUE_CURRENT_LEVEL = "workflow_past_due_current_level";

    public static String WORKFLOW_PAST_DUE_UPPER_LEVEL = "workflow_past_due_upper_level";

    public static String WORKFLOW_START_NOTIFIATION = "workflow_start_notification";

    public static String WORKFLOW_CHANGE_STATUS = "workflow_change_status";

    public static String WF_DOC_CHANGE_SUB_APPROVAL_REQUEST = "WORKFLOW_DOCUMENT_CHANGE_SUB_APPROVAL_REQUEST";
    public static String WF_DOC_CHANGE_IA_APPROVAL_REQUEST = "WORKFLOW_DOCUMENT_CHANGE_IA_APPROVAL_REQUEST";
    public static String WF_DOC_CHANGE_IA_APPROVAL_RESPONSE = "WORKFLOW_DOCUMENT_CHANGE_IA_APPROVAL";

    public static boolean workFlowEmail(String emailType, String level,
            EmailWrapper emailWrapper)throws Exception {

        if (emailType.equalsIgnoreCase(WORKFLOW_PAST_DUE_UPPER_LEVEL)) {
            sendOverDueUpperLevelNotification(level,emailWrapper);
        }
        if (emailType.equalsIgnoreCase(WORKFLOW_PAST_DUE_CURRENT_LEVEL)) {
            sendOverDueEmailNotification(emailWrapper.getEmailAddress());
        }
        if (emailType.equalsIgnoreCase(WF_DOC_CHANGE_SUB_APPROVAL_REQUEST)) {
            sendOverDueEmailNotification(emailWrapper.getEmailAddress());
        }
        return false;
    }

    public static boolean workFlowEmail(String emailType, String toType,
            OwnerWrapper ownerWrapper)throws Exception {
        if (emailType.equalsIgnoreCase(WF_DOC_CHANGE_SUB_APPROVAL_REQUEST)) {
            sendSubCycleOwnerApprovalRequest(ownerWrapper,toType);
        }
        if (emailType.equalsIgnoreCase(WF_DOC_CHANGE_IA_APPROVAL_RESPONSE)) {
            sendIAApprovalResponse(ownerWrapper);
        }
        if (emailType.equalsIgnoreCase(WF_DOC_CHANGE_IA_APPROVAL_REQUEST)) {
            sendIAOwnerApprovalRequest(ownerWrapper);
        }
        return false;
    }

    /**
     * Upper level email disabled for time being
     * @param level
     * @param identifier
     * @return
     * @throws Exception
     */
    public static boolean sendEmail(String level, String identifier)
            throws Exception {
        if (SoxicUtil.toSendEmail()) {
            StatusDAO statusDAO = new StatusDAO();
            if (statusDAO.isCurrentLevelComplete(level, identifier)) {
                UtilDAO utilDAO = new UtilDAO();
                List ownerWrapperList = utilDAO.getUpperLevelOwnerWrapperList(
                        level, identifier);
                Iterator ownerIterator = ownerWrapperList.iterator();

                while (ownerIterator.hasNext()) {
                    OwnerWrapper ownerWrapper = (OwnerWrapper) ownerIterator
                            .next();
                    if (ownerWrapper.getEmailid() != null) {
                        String upperLevel = getUpperLevel(level);
//						JavaMailComponent.sendMail(ownerWrapper.getEmailid(),
//								SoxicUtil.getFromEmailAddress(),
//								"Sarbanes-Oxley Internal Controls",
//								getCompletionBodyMessage(upperLevel,
//										ownerWrapper.getSubCycleString(),
//										ownerWrapper.getDateString()), true);
                    }
                }

                return true;
            }
        }
        return false;
    }

    public static boolean sendWorkFlowEmail(String level, String emailaddress)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            //			JavaMailComponent.sendMail(emailaddress, SoxicUtil
            //					.getFromEmailAddress(),
            //					"Sarbanes-Oxley Internal Controls --- UAT",
            //					getStartBodyMessage(level), false);
            return true;
        }

        return false;
    }

    /**
     * This method is called on the start date.
     *
     * @param level
     * @param emailaddress
     * @param customString
     * @return
     * @throws Exception
     */
    public static boolean sendStartWorkFlowEmail(String level,
                                                 String emailaddress, String subCycleList, String dueDate, String customString)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailaddress, SoxicUtil
                    .getFromEmailAddress(),SoxicUtil.getCertificationStartSubject() ,
                    getStartBodyMessage(level, subCycleList, dueDate, customString), true);
            return true;
        }

        return false;
    }

    /**
     * This method is called on the start date of the docChange.
     *
     * @param emailaddress
     * @param dueDateString
     * @return
     * @throws Exception
     */
    public static boolean sendStartDocChangeEmail(String emailaddress, String startDate, String dueDateString)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailaddress, SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getDocChangeStartSubject() ,
                    getStartDochangeBodyMessage(startDate,dueDateString), true);
            return true;
        }

        return false;
    }

    /**
     * This method is called on the start date.
     *
     * @param level
     * @param emailaddress
     * @return
     * @throws Exception
     */
    public static boolean sendStartUpperWorkFlowEmail(String level,
            String emailaddress, String subCycleList) throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailaddress, SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getCertificationStartSubject(),
                    getStartUpperBodyMessage(level, subCycleList), true);
            return true;
        }

        return false;
    }

    /**
     * This method is called when due date is over
     * @param emailaddress
     * @return
     * @throws Exception
     */
    public static boolean sendOverDueEmailNotification(String emailaddress)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailaddress, SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getPastDueSubject(),
                    overDueNotificationMessage(SoxicUtil.getHomeLink()), true);
            return true;
        }

        return false;
    }

    private static boolean sendSubCycleOwnerApprovalRequest(OwnerWrapper ownerWrapper,String toType)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(ownerWrapper.getEmailid(), SoxicUtil
                    .getFromEmailAddress(), "Sarbanes-Oxley Internal Controls: Doc Change Approval Required",
                    subCycleOwnerApprovalRequestMessage(SoxicUtil.getHomeLink(),toType), true);
            return true;
        }

        return false;
    }

    private static boolean sendIAApprovalResponse(OwnerWrapper ownerWrapper)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(ownerWrapper.getEmailid(), SoxicUtil
                    .getFromEmailAddress(), "Sarbanes-Oxley Internal Controls:Doc Change Approved",
                    iAApprovalResponse(SoxicUtil.getHomeLink()), true);
            return true;
        }

        return false;
    }

    private static boolean sendIAOwnerApprovalRequest(OwnerWrapper ownerWrapper)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(ownerWrapper.getEmailid(), SoxicUtil
                    .getFromEmailAddress(), "Sarbanes-Oxley Internal Controls: Doc Change Approval Required",
                    iAOwnerApprovalRequestMessage(SoxicUtil.getHomeLink()), true);
            return true;
        }

        return false;
    }

    private static boolean sendOverDueUpperLevelNotification(String level,
            EmailWrapper wrapper) throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(wrapper.getEmailAddress(), SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getPastDueSubject(),
                    overDueNotificationUpperLevelMessage(level, SoxicUtil
                            .getHomeLink(), wrapper), true);
            return true;
        }

        return false;
    }

    /**
     * This method returns body for overdue notification for the upper level
     *
     * @param link
     * @return
     */
    private static String overDueNotificationUpperLevelMessage(String level,
            String link, EmailWrapper wrapper) {

        String to="";
        String body="";
        String currentLevel="";
        if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
            to = "Sub-cycle Owners";
            body = "activity owners";
            currentLevel ="sub-cycle(s)";
        }
        if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
            to = "Cycle Owners";
            body = "Sub-cycle Owners";
            currentLevel ="cycle(s)";
        }
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>To:  "+to+"</b>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                //+ "<b>Please see the list below for "+body+" whose certifications are now past due.</b>"
                + "<B>Below is a list of all delinquent "+body+" in the "+currentLevel+" for which you have responsibility.  Please follow up and encourage them to complete their certification.  You will not be able to complete your certification until they have completed theirs</B>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                //+ "<table border=\"1\"><tr><td>Owner</td><td>Due Date</td></tr>";
                + "<table border=\"1\"><tr><td>OWNER</td></tr>";
//		for(int i =0;i<wrapper.getOwnerList().size();i++){
//			toSend = toSend +
//			      "<tr><td>"+wrapper.getOwnerList().get(i)+"</td><td>"+wrapper.getDueDateList().get(i)+"</td></tr>";
//		}
//		toSend = toSend+
        for(int i =0;i<wrapper.getOwnerList().size();i++){
            toSend = toSend +
                  "<tr><td>"+wrapper.getOwnerList().get(i)+"</td></tr>";
        }
        toSend = toSend+
                  "</table>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>If you have questions, please contact the Internal, Controls mailbox or call Jessica Spurgin at (314) 694-2309</b>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    /**
     * @param level
     * @param emailaddress
     * @param subCycleList
     * @param dueDateString
     * @return
     * @throws Exception
     */
    public static boolean sendStatusChangeWorkFlowEmail(String level,
            String emailaddress, String subCycleList, String dueDateString)
            throws Exception {

        //String[] to = { "vrbethi@monsanto.com" };
        //String[] cc = {};

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailaddress, SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getCertificationChangeStatusSubject(),
                    getStatusChangeBodyMessage(level, subCycleList,
                            dueDateString), true);
            return true;
        }

        return false;
    }

    /**
     * @param level
     * @return
     */
    public static String getUpperLevel(String level) {
        String upperLevel = "";

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            upperLevel = SoxicConstants.SUBCYCLE;
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            upperLevel = SoxicConstants.CYCLE;
        }
        return upperLevel;

    }

        /**
     * @param level
     * @param subCycleList
     * @param duedate
     * @param customString
         * @return
     */
    public static String getStartBodyMessage(String level, String subCycleList,
                                             String duedate, String customString) {
        String messagePart = getLevelStartMessage(level, SoxicUtil
                .getHomeLink(), subCycleList, duedate, customString)
                + "\n";
        return messagePart;
    }


    /**
     * This email is the start of the message for start date email
     * @param startdate
     * @return
     */
    public static String getStartDochangeBodyMessage(String startdate, String dueDate) {
        String emailmessage = getdocChangeCommonMessage(SoxicUtil.getHomeLink(),startdate, dueDate)
                + "\n";
        return emailmessage;
    }


    /**
     *
     * @param link
     * @param startdate
     * @param dueDate
     * @return
     */
    private static String getdocChangeCommonMessage(String link, String startdate, String dueDate) {
        String toSend = "";

        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                +"<tr>"
                +"<td text=\"#5F7D99\" width=\"96%\">"
                +"<td align=\"left\" text=\"#5F7D99\">"
                +"<td align=\"left\" colspan=\"3\" valign=\"middle\">"
                +"<span class=\"redtext\">"
                +"</span>"
                +"</td>"
                +"</tr>"
                +"</table>"
                +"<p>"
                +"Activity and Subcycle Owners,"
                +"</p>"
                +"<p>"
                +"The SOX 404 System is currently open for Documentation Change requests."
                +"</p>"
                +"<p>"
                +"Documentation Change period end date: <font color=\"red\">"
                +dueDate
                +"</font>"
                +"</p>"
                +"<p>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Please use this period to request any necessary modifications to the SOX 404"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"internal control activity descriptions."
                +"<tr>"+"<td>"
                +"</table>"
                +"</p>"
                +"<p>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Circumstances that may require a documentation change:"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"<ul>"
                +"<li> Change to a business process or IT system </li>"
                +"<li> Remediation of a deficiency </li>"
                +"<li> New accounting or reporting requirement </li>"
                +"<li> Internal Audit Recommendation </li>"
                +"</td>"+"</tr>"
                +"</table>"
                +"</p>"
                +"<p>"
                +"All change requests will be routed to Internal Audit for approval."
                +"</p>"
                +"<p>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Access the SOX 404 system using the following link: "
                + "<a href=\""
                + link
                + ">"
                +"SOX 404 System."
                +"</a>"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"Submit request for Documentation Change using the Doc Change tab."
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"Access Documentation Change training at: "
                + "<a href=\""
                + "http://stork.monsanto.com/aspen/lang-en/management/LMS_ActDetails.asp?UserMode=0&ActivityId=1981\""
                + ">"
                +"Doc Change CBT."
                +"</a>"
                +"</td>"+"</tr>"
                +"</table>"
                +"</p>"
                +"<p>"
                //+"For questions, please contact James Dallman at (314) 694-6571"
                +"For questions, please contact Jessica Spurgin at (314) 694-2309"
                +"</p>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Thank you for your commitment to maintaining the accuracy and integrity of"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"Monsanto's Sarbanes Oxley Compliance process."
                +"</td>"+"</tr>"
                +"</table>";
        return toSend;
    }

    /**
     * @param level
     * @param subCycleList
     * @return
     */
    public static String getStartUpperBodyMessage(String level,
            String subCycleList) {

        String messagePart = getUpperLevelStartMessage(level, SoxicUtil
                .getHomeLink(), subCycleList)
                + "\n";
        return messagePart;
    }

    /**
     * @param level
     * @param homeLink
     * @param subcycleList
     * @param dueDate
     * @param customString
     * @return
     */
    public static String getLevelStartMessage(String level, String homeLink,
                                              String subcycleList, String dueDate, String customString) {
        String message = mailCommonHeader(level, homeLink, subcycleList,
                dueDate, customString);
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            return message + getActivityMessage();
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            return message + getSubCycleMessage();
        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            return message + getCycleMessage();
        }
        return "";
    }

    /**
     * @param level
     * @param homeLink
     * @param subcycleList
     * @return
     */
    public static String getUpperLevelStartMessage(String level,
            String homeLink, String subcycleList) {
        //String message =
        // mailCommonHeader(level,homeLink,subcycleList,dueDate);
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            return getUpperLevelMessage(level, homeLink, subcycleList);
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            return getUpperLevelMessage(level, homeLink, subcycleList);
        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            return getCycleMessage();
        }
        return "";
    }

    /**
     * @param level
     * @param subCycleList
     * @param dueDateString
     * @return
     */
    public static String getCompletionBodyMessage(String level,
            String subCycleList, String dueDateString) {

        String messagePart = getCompletionMessage(level, SoxicUtil
                .getHomeLink(), subCycleList, dueDateString)
                + "\n";
        return messagePart;
    }

    /**
     * @param level
     * @param subCycleList
     * @param dueDateString
     * @return
     */
    public static String getStatusChangeBodyMessage(String level,
            String subCycleList, String dueDateString) {

        String messagePart = getStatusChangeMessage(level, SoxicUtil
                .getHomeLink(), subCycleList, dueDateString)
                + "\n";
        return messagePart;
    }

    /**
     * @param level
     * @param homeLink
     * @param subCycleList
     * @param dueDateString
     * @return
     */
    public static String getCompletionMessage(String level, String homeLink,
            String subCycleList, String dueDateString) {
        String message = mailCommonHeader(level, homeLink, subCycleList,
                dueDateString, "");
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            return message + getSubCycleMessage();
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            return message + getSubCycleCompletionMessage();

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            return message + getCycleCompletionMessage();

        }
        return "";
    }

    /**
     * @param level
     * @param homeLink
     * @param subCycleList
     * @param dueDateString
     * @return
     */
    public static String getStatusChangeMessage(String level, String homeLink,
            String subCycleList, String dueDateString) {
        //String message = mailCommonHeader(level,homeLink,"","");
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            //return
            // statusChangeMessage(level,homeLink,subCycleList,dueDateString);
            //return newMessage();
            //return getActivityMessage();
            return statusChangeMessage(level, homeLink, subCycleList,
                    dueDateString);
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            return statusChangeMessage(level, homeLink, subCycleList,
                    dueDateString);

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            return statusChangeMessage(level, homeLink, subCycleList,
                    dueDateString);

        }
        return "";
    }

    /**
     * @param level
     * @param link
     * @param subcycleList
     * @param duedate
     * @param customString
     * @return
     */
    public static String mailCommonHeader(String level, String link,
                                          String subcycleList, String duedate, String customString) {
        String levelStr = "";

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            levelStr = "Activity";
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            levelStr = "Sub-Cycle";

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            levelStr = "Cycle";
        }
        String toSend = "";

        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4 align=\"center\">Self-Assessment Certification</h4>"

                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>To:<span class=\"redtext\"> "
                + levelStr
                + " Owners</span></b>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>Sub-Cycle: </b>"
                + subcycleList
                + ""
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>Due: </b>"
                //+ "</td>"
                //+ "<td text=\"#5F7D99\" width=\"96%\">"
//				//+ "<td align=\"left\" text=\"#5F7D99\">"
                //+ "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<span class=\"redtext\">"
                + "<b>"
                + duedate
                + "</b>"
                + "</span>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<a href=\""
                + link
                + ">"
                + "<b>Complete Certification</b></a><br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\">"
                +customString
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>Click on the link above to complete your self-assessment certification.</b>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + " In order to fulfill the <u>quarterly</u> requirements of Section 404 of the Sarbanes-Oxley Act,<br>"
                + " Monsanto must provide a formal assertion stating management's responsibility for establishing<br>"
                + " and maintaining an adequate internal control structure that provides reasonable assurance<br> "
                + " regarding the reliability of financial reporting."
                + "<br>" + "</td>" + "</tr>";
        return toSend;
    }

    public static String getActivityMessage() {
        String toSend = "";
        toSend = toSend
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "As an activity owner, you are a crucial part of this process.  "
                + "Please complete your self-assessment certification by the due date."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "You are certifying that:"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1) The key control activities are in place and operating as documented,"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2) The control activities in place to meet the objectives are adequately designed, effective, and consistently performed, and"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3) Evidence is available to support control activities."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please remember that you are responsible for the timely remediation of any deficiencies or potential gaps identified. "
                + "</td>"
                + "</tr>"
                + "</p>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have any questions please contact your sub-cycle or cycle owner or the internal controls mailbox."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "To view a short video explaining how to use the certification system, click this link:"
//				+ "<a href=\""
//				+ SoxicUtil.getActivityHelpVideoLink()
//				+ "\">"
//				+ "<b> Training Video.</b></a><br>"
                + getTrainingVideoText(SoxicConstants.ACTIVITY)
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b> document.</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>" + "<br>" + "</table>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    public static String getSubCycleMessage() {
        String toSend = "";
        toSend = toSend
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "As a sub-cycle owner, you are a crucial part of this process. "
                + "Please complete your self-assessment certification by the due date."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "You are reviewing and approving the activity owner self-assessment results, including:"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1) The key control activities: that they are in place and operating as documented,"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2) The control objective and evidence evaluation results: the summary of status of deficiencies and the summary of potential gaps, and"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3) That evidence is available to support control activities."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please remember that you are responsible for the timely remediation of any deficiencies or potential gaps identified."
                + "</td>"
                + "</tr>"
                + "</p>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have any questions please contact your cycle owner or the internal controls mailbox."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "To view a short video explaining how to use the certification system, click this link: "
//				+ "<a href=\""
//				+ SoxicUtil.getSubCycleHelpVideoLink()
//				+ "\">"
//				+ "<b>Training Video.</b></a><br>"
                + getTrainingVideoText(SoxicConstants.SUBCYCLE)
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b> document.</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>" + "<br>" + "</table>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    public static String getSubCycleCompletionMessage() {
        String toSend = "";
        toSend = toSend
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "As a sub-cycle owner, you are a crucial part of this process. "
                + "Please complete your self-assessment certification by the due date."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "All activity owners for your sub-cycle have completed their self-assessment certifications. You are reviewing and approving the activity owner self-assessment results, including:"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1)The key control activities: that they are in place and operating as documented,"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2)The control objective and evidence evaluation results: the summary of status of deficiencies and the summary of potential gaps, and"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3)That evidence is available to support control activities."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please remember that you are responsible for the timely remediation of any deficiencies or potential gaps identified."
                + "</td>"
                + "</tr>"
                + "</p>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have any questions please contact your cycle owner or the internal controls mailbox."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "To view a short video explaining how to use the certification system, click this link:"
//				+ "<a href=\""
//				+ SoxicUtil.getSubCycleHelpVideoLink()
//				+ "\">"
//				+ "<b>Training Video</b></a><br>"
                + getTrainingVideoText(SoxicConstants.SUBCYCLE)
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>" + "<br>" + "</table>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    private static String getSecurityDocumentText(){
        String securityDocument="";
        securityDocument = securityDocument
            + "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue: "
            + "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
            + "documents/SetWinIntAuth.doc\">" + "<b>document.</b></a><br>";
        return securityDocument;
    }

    private static String getTrainingVideoText(String level){
        String helpVideo="";
        String trainingVideo="";
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            helpVideo = SoxicUtil.getActivityHelpVideoLink();
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            helpVideo = SoxicUtil.getSubCycleHelpVideoLink();

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            helpVideo = SoxicUtil.getCycleHelpVideoLink();
        }

        trainingVideo = trainingVideo
        + "To view a short video explaining how to use the certification system, click this link: "
        + "<a href=\""
        + helpVideo
        + "\">"
        + "<b>Training Video.</b></a><br>";
        return trainingVideo;
    }

    public static String getCycleMessage() {
        String toSend = "";
        toSend = toSend
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please complete a Self Assessment Certification.  "
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "You are reviewing and approving the quarterly self-assessment results, including:"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1) Key control activities are in place and are adequately designed, effectively and consistently,"
                + "performed."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2) Evidence is available to support control activities."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3) The summary of potential gaps is accurate and complete."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please remember that you are responsible for the timely remediation of any deficiencies "
                + "or potential gaps identified."
                + "</td>"
                + "</tr>"
                + "</p>"
                + "<br>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have any questions please contact the internal controls mailbox."
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "To view a short video explaining how to use the certification system, click this link:"
//				+ "<a href=\""
//				+ SoxicUtil.getCycleHelpVideoLink()
//				+ "\">"
//				+ "<b>Training Video</b></a><br>"
                + getTrainingVideoText(SoxicConstants.CYCLE)
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>" + "<br>" + "</table>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    public static String getCycleCompletionMessage() {
        String toSend = "";
        toSend = toSend
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "As a cycle owner, you are a crucial part of this process. "
                + "Please complete your self-assessment certification by the due date."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "You are reviewing and approving the self-assessment results, including:"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1)The key control activities: that they are in place and operating as documented,"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2)The control objective and evidence evaluation results: the summary of status of deficiencies and the summary of potential gaps, and"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3)That evidence is available to support control activities."
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please remember that you are responsible for the timely remediation of any deficiencies or potential gaps identified."
                + "</td>"
                + "</tr>"
                + "</p>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have any questions please contact your cycle owner or the internal controls mailbox."
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "To view a short video explaining how to use the certification system, click this link:"
//				+ "<a href=\""
//				+ SoxicUtil.getCycleHelpVideoLink()
//				+ "\">"
//				+ "<b>Training Video</b></a><br>"
                + getTrainingVideoText(SoxicConstants.CYCLE)
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>" + "<br>" + "</table>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    public static String getUpperLevelMessage(String level, String link,
            String subcycleList) {
        String levelStr = "";

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            levelStr = "Sub-Cycle";
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            levelStr = "Cycle";

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            levelStr = "Cycle";
        }
        String toSend = "";
        toSend = ""
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4 align=\"center\">Self-Assessment Certification Start Notification</h4>"
    //			+ "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>To: "
                + levelStr
                + " Owners</b>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>SubCycle: </b>"
                + subcycleList
                + ""
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" valign=\"middle\">"
                + "<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>"
                + "</td>"
                + "<td text=\"#5F7D99\" width=\"96%\">"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Self-assessment certification of the cycle listed above has begun. Activity owners will receive an email notification"
                + " with instructions to begin their certification."
                + " Click on the link below to view certification progress."
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<a href=\""
                + link
                + ">"
                + "<b>Complete Certification</b></a><br>"
                + "</td>"
                + "</tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>"
                + getSecurityDocumentText()
                + "</td>" + "</tr>";
        return toSend;
    }

    public static String statusChangeMessage(String level, String link,
            String subcycleList, String duedate) {
        String levelStr = "";
        String helpVideo = "";
        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            levelStr = "Activity";
            helpVideo = SoxicUtil.getActivityHelpVideoLink();
        }
        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            levelStr = "Sub-Cycle";
            helpVideo = SoxicUtil.getSubCycleHelpVideoLink();

        }
        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            levelStr = "Cycle";
            helpVideo = SoxicUtil.getCycleHelpVideoLink();
        }
        String toSend = "";

        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4 align=\"center\">Self-Assessment Certification</h4>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>To : "
                + levelStr
                + " Owners</b>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>SubCycle: </b>"
                + subcycleList
                + ""
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" valign=\"middle\">"
                + "<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Due: </b>"
                + "</td>"
                + "<td text=\"#5F7D99\" width=\"96%\">"
                + "<span class=\"redtext\">"
                + "<b>"
                + duedate
                + "</b>"
                + "</span>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<a href=\""
                + link
                + ">"
                + "<b>Complete Certification</b></a><br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<b>This is a reminder that the due date of your certification is rapidly approaching."
                + " Please click on the link above to complete your self-assessment certification as soon as possible</b>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "To view a short video explaining how to use the certification system, click this link:"
                + "<a href=\""
                + helpVideo
                + "\">"
                + "<b>Training Video</b></a><br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>";
                + getSecurityDocumentText();
        return toSend;
    }

    public static String newMessage() {
        String toSend = "";

        toSend = toSend
                + "<html>"
                + "<body bgcolor=\"white\">"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#003300\">"
                + "<td align=\"left\" valign=\"middle\">"
                + "<img src=\"http://w3.foundation.monsanto.com/tll/images/TLLLogoRings.gif\" width=\"60\" height=\"69\" /><font face=\"Arial\" size=\"5\" color=\"#FF8040\">"
                + "<nobr>&nbsp;&nbsp;Temporary Labor Link</nobr></font></td>"
                + "</tr>"
                + "<tr bgcolor=\"#FF8040\">"
                + "<td colspan=\"3\">"
                + "<img src=\"http://w3.foundation.monsanto.com/tll/images/spacer.gif\" height=\"8\" />"
                + "</td></tr><tr><td><HR noShade><P><FONT face=Arial>Your timecard for week ending Sunday, April 10,2005, has been approved. </FONT></P><HR noShade>"
                + "<TABLE width=\"100%\" border=0>"
                + "<TBODY>"
                + "<TR>"
                + "<TD align=right width=\"50%\" bgColor=\"#ffca95\"><FONT face=Arial>Associate Name:</FONT></TD>"
                + "<TD width=\"50%\"><FONT face=Arial>Rambabu Vijayaram Bethina</FONT></TD>"
                + "</TR>" + "<TR>"
                //				+"<TD align=right width=\"50%\" bgColor=\"#ffca95\"><FONT
                // face=Arial>Company Name:</FONT></TD>"
                //				+"<TD width=\"50%\"><FONT face=Arial>NextGen </FONT></TD>"
                //				+"</TR>"
                //				+"<TR>"
                //				+"<TD align=right width=\"50%\" bgColor=\"#ffca95\"><FONT
                // face=Arial>Requisition Number:</FONT></TD>"
                //				+"<TD width=\"50%\"><FONT face=Arial>200401603</FONT></TD>"
                //				+"</TR>"
                //				+"<TR>"
                //				+"<TD align=right width=\"50%\" bgColor=\"#ffca95\"><FONT
                // face=Arial>Java Developer II</FONT></TD>"
                //				+"<TD width=\"50%\"><FONT face=Arial>Java Developer
                // II</FONT></TD>"
                //				+"</TR>"
                + "</TABLE>" + "</td>" + "</tr>" + "</TABLE>" + "</BODY>"
                + "</HTML>";
        //			+ "<h4 align=\"left\"><img
        // src=\"http://w3d.finance.monsanto.com:8080/Soxic/images/404_internal_control_logo.gif\"></h4>";

        return toSend;
    }

    public static String selfAssemenentStart(String link) {
        String toSend = "";
        toSend = toSend
                + "<h4 align=\"left\"><img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\"></h4>"
                //+ "<h4 align=\"left\"><img
                // src=\"http://w3d.finance.monsanto.com:8080/Soxic/images/404_internal_control_logo.gif\"></h4>"
                + "<h4 align=\"center\">Self-Assessment Certification Start Notification</h4>"
                + "Self-assessment certification of the cycle has begun.  Activity owners will receive an email notification with instructions to begin their certification."
                + "<br>"
                + "Click on the link below to view certification progress"
                + "<br>"
                + "<a href=\""
                + link
                + ">"
                + "<b>Complete Certification</b></a><br>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
//				+ "If you have problems accessing the certification website it may be because your computer's settings do not match Monsanto's security requirements.  This document will explain how to correct this issue:"
//				+ "<a href=\"" + SoxicUtil.getSecurityHelpDocumentLink()
//				+ "documents/SetWinIntAuth.doc\">" + "<b>document</b></a><br>";
                + getSecurityDocumentText();
        return toSend;
    }

    /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String overDueNotificationMessage(String link) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<span class=\"redtext\">"
                + "<b>Your SOX 404 self assessment certification is now past due.  Please use the link below to certify immediately.</b>"
                + "</span>"
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<a href=\""
                + link
                + ">"
                + "<b>Complete Certification</b></a><br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<span class=\"redtext\">"
                + "<b>If you have questions, please contact the Internal, Controls mailbox or call Jessica Spurgin at (314) 694-2309</b>"
                + "</span>" + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    /**
     * 7 days prior to closing date email
     * @param emailid
     * @param end_date
     * @return
     * @throws Exception
     */
    public static boolean sendCloseDocChangeEmail(String emailid,String end_date) throws Exception{
        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailid, SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getDocChangeClosureSubject() ,
                    getCloseDochangeBodyMessage(end_date), true);
            return true;
        }

        return false;
    }

    /**
     * start of the message body for the 7 days prior to end_date email
     * @param end_date
     * @return
     */
    public static String getCloseDochangeBodyMessage(String end_date) {
        String emailmessage = getdocChangeClosureMessage(SoxicUtil.getHomeLink(),end_date)
                + "\n";
        return emailmessage;
    }


    private static String getdocChangeClosureMessage(String link, String end_date) {
        String toSend = "";

        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                +"<tr>"
                +"<td text=\"#5F7D99\" width=\"96%\">"
                +"<td align=\"left\" text=\"#5F7D99\">"
                +"<td align=\"left\" colspan=\"3\" valign=\"middle\">"
                +"<span class=\"redtext\">"
                +"</span>"
                +"</td>"
                +"</tr>"
                +"</table>"
                +"<br>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Be advised that the opportunity to request and approve Documentation Changes will close in 7 days.  Once closed, Documentation"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"Changes will no longer be available in this quarter."
                +"</td>"+"</tr>"
                +"</table>"
                +"<br>"
                +"<table>"
                +"<tr>"+"<td>"
                +"A Cycle where you are an owner is currently available for Documentation Changes.  This is a temporary period that allows you"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"to review the Certification Activities and request modifications.  Your assistance with this effort is greatly appreciated."
                +"</td>"+"</tr>"
                +"</table>"
                +"<br>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Please review your Activities by visiting the Sarbanes-Oxley Internal Controls application located at"
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                + "<a href=\""
                + link
                + ">"
                +"Sarbanes-Oxley Internal Controls"+"&nbsp;"
                +"</a>"
                +"and clicking the Doc Change menu button."
                +"</td>"+"</tr>"
                +getDocumentChangeTrainingLink()
                +"<tr>"+"<td>"
                +"If you have any questions or difficulties, please contact Jessica Spurgin at (314) 694-2309."
                +"</td>"+"</tr>"
                +"</table>"
                +"<br>"
                +"<table>"
                +"<tr>"+"<td>"
                +"Thank you for your help."
                +"</td>"+"</tr>"
                +"<tr>"+"<td>"
                +"Sarbanes-Oxley Internal Controls"
                +"</td>"+"</tr>"
                +"</table>";
        return toSend;
    }
    
   /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String subCycleOwnerApprovalRequestMessage(String link,String toType) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "To: "+toType
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Subject :"
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "A Documentation Change has been requested for an Activity that you are responsible for.  You must review and approve this modification before the change is sent to IA for final approval and inclusion in the upcoming Certification period."
                + "Changes not approved by you will not be included as part of the upcoming Certification period."
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please visit the "
                + "<a href=\""
                + link
                + ">"
                + "<b>Sarbanes-Oxley Internal Controls </b></a> application and go to the Proposed Doc Changes link located under the Doc Change menu button.  Once there, you will see a list of all requests for your Activities.<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + getDocumentChangeTrainingLink()
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have questions or difficulties, please contact Jessica Spurgin at (314) 694-2309<br>"
                + " Thank you for your help.<br>"
                + " Sarbanes-Oxley Internal Controls<br>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

   /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String iAApprovalResponse(String link) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "To: Activity Owner and Subcycle Owner"
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Subject : Sarbanes-Oxley Internal Controls:Doc Change Approved"
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "A Documentation Change you requested has been approved.  No further action is required by you."
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please visit the "
                + "<a href=\""
                + link
                + ">"
                + "<b>Sarbanes-Oxley Internal Controls </b></a> application and go to the Proposed Doc Changes link located under the Doc Change menu button.  Once there, you will see a list of all requests for your Activities.<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                +getDocumentChangeTrainingLink()
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + ""
                + "If you have questions or difficulties, please contact Jessica Spurgin at (314) 694-2309<br>"
                + " Thank you for your help.<br>"
                + " Sarbanes-Oxley Internal Controls<br>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

   /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String iAOwnerApprovalRequestMessage(String link) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "To: IA Admin"
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Subject :Sarbanes-Oxley Internal Controls: Doc Change Approval Required"
                + ""
                + "<br>"
                + "</td>"
                + "</tr>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "A Documentation Change has been approved by a Sub-cycle Owner.  You must review and approve this modification before the change will be included in the upcoming Certification period.  Changes not approved by you will not be included as part of the upcoming Certification period."
                + "<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "Please visit the "
                + "<a href=\""
                + link
                + ">"
                + "Sarbanes-Oxley Internal Controls </b></a> application and go to the Proposed Doc Changes link located under the Doc Change menu button.  Once there, you will see a list of all requests.<br>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + getDocumentChangeTrainingLink()
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "If you have questions or difficulties, please contact Jessica Spurgin at (314) 694-2309<br>"
                + " Thank you for your help.<br>"
                + " Sarbanes-Oxley Internal Controls<br>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

	public static boolean sendBadDataEmail()
			throws Exception {

		if (SoxicUtil.toSendEmail()) {
			JavaMailComponent.sendMail("VRBETHI@MONSANTO.COM", SoxicUtil
					.getFromEmailAddress(),"SOX Application Nightly Batch: Bad Data Found" ,
					"", true);
//			JavaMailComponent.sendMail("chris.carter@monsanto.com", SoxicUtil
//					.getFromEmailAddress(),"SOX Application Nightly Batch: Bad Data Found" ,
//					"", true);
//			JavaMailComponent.sendMail("vlarter@monsanto.com", SoxicUtil
//					.getFromEmailAddress(),"SOX Application Nightly Batch: Bad Data Found" ,
//					"", true);
			return true;
		}

		return false;
	}    

    public static String getDocumentChangeTrainingLink(){
        String toreturn="";
           toreturn=toreturn+"<tr>"+"<td>"
                + "For training on this process, please go to the following "
                + "<a href=\""
                + "http://stork.monsanto.com/aspen/lang-en/management/LMS_ActDetails.asp?UserMode=0&ActivityId=1981\""
                + ">"
                +"link."+"&nbsp;"
                +"</a>"
                +"</td>"+"</tr>";
        return toreturn;
    }

}