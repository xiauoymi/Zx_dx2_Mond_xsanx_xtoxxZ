/*
* Created on Feb 21, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SoxicQueryUtil {

    InputStream in;

    public Properties getPropertyFile(){
        boolean useClasspath=true;

        Properties props = new Properties();

        try {
            if (useClasspath) {
                //in = getClass().getClassLoader().getResourceAsStream("src/com/monsanto/soxic/properties/OracleQueries.properties");
                in = getClass().getClassLoader().getResourceAsStream("DatabaseResources.properties");
                ResourceBundle myResources =
                        ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.OracleQueries");

                Enumeration resourceKeys = myResources.getKeys();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }

    public String getQuery(String name){
        Properties props = getPropertyFile();
        String query = props.getProperty(name);
        closeFile();
        return query;
    }

    public void closeFile(){
        try{
            in.close();
        }catch(IOException ex){
            ex.printStackTrace();
        }

    }

    public String getQueryByName(String name,String state){
        if(state.equalsIgnoreCase(SoxicConstants.CERTIFICATION_STATE)){
            ResourceBundle myResources =
                    ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.OracleQueries");
            return myResources.getString(name);
        }
        if(state.equalsIgnoreCase(SoxicConstants.DOCCHANGE_STATE)){
//            ResourceBundle myResources =
//                    ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.OracleQueries");
//            return myResources.getString(name);
            return "SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS,SC.CYCLE_ID,CS.STATE FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA,CYCLE_STATE CS WHERE CS.CYCLE_ID = SC.CYCLE_ID AND CS.STATE=? AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID ORDER BY SC.SUB_CYCLE_ID";
        }
        return "";
    }

}
