package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 1, 2005
 * Time: 11:48:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class DateFormatException extends Exception{

    public DateFormatException(){
		super();
	}

	public DateFormatException(Exception e){
		super(e);
	}
}
