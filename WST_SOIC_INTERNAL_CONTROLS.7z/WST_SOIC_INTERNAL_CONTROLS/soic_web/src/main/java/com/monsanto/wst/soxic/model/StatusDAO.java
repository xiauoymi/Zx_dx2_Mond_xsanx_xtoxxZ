/*
 * Created on Mar 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.DBUtils;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class StatusDAO {

    /**
     * Sets the status in the owner-level table
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param owner_id
     *            owner of the level
     * @param identifier
     *            identifier for the level
     * @param status
     *            status to be set
     * @param changeStatus
     *            (true / false) --> (Submit / Save)
     * @throws Exception
     */
    public void updateOwnerStatus(String level, String owner_id,
                                  String identifier, String status, boolean changeStatus)
            throws Exception {

        Connection con = null;
        PreparedStatement updateOwnerStatus = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            if (changeStatus) {
                updateOwnerStatus = con
                        .prepareStatement(getOwnerLevelUpdateQuery(level));
                updateOwnerStatus.setString(1, status);
                updateOwnerStatus.setDate(2, new Date(System
                        .currentTimeMillis()));
                updateOwnerStatus.setDate(3, new Date(System
                        .currentTimeMillis()));
                updateOwnerStatus.setString(4, owner_id);
                updateOwnerStatus.setString(5, owner_id);
                updateOwnerStatus.setString(6, identifier);

            } else {
                //Save mode the status is always in Process
                updateOwnerStatus = con
                        .prepareStatement(getOwnerLevelSaveQuery(level));
                updateOwnerStatus.setString(1, SoxicConstants.GREEN_INPROCESS);
                updateOwnerStatus.setDate(2, new Date(System
                        .currentTimeMillis()));
                updateOwnerStatus.setString(3, owner_id);
                updateOwnerStatus.setString(4, owner_id);
                updateOwnerStatus.setString(5, identifier);
            }

            int result = updateOwnerStatus.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(updateOwnerStatus);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Sets the status in the owner-level table
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param owner_id
     *            owner of the level
     * @param identifier
     *            identifier for the level
     * @param status
     *            status to be set
     * @param changeStatus
     *            (true / false) --> (Submit / Save)
     * @throws Exception
     */
    public void updateOwnerResponseStatus(String owner_id, String identifier,
                                          String status, boolean changeStatus, String questionid)
            throws Exception {
        Connection con = null;
        PreparedStatement updateOwnerResponseStatus = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            if (changeStatus) {
                updateOwnerResponseStatus = con
                        .prepareStatement(getOwnerResponseUpdateQuery("ownerquestionidentifier"));
                updateOwnerResponseStatus.setString(1, status);
                updateOwnerResponseStatus.setDate(2, new Date(System
                        .currentTimeMillis()));
                updateOwnerResponseStatus.setString(3, owner_id);
                updateOwnerResponseStatus.setString(4, identifier);
                updateOwnerResponseStatus.setString(5, owner_id);

            }
            int result = updateOwnerResponseStatus.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(updateOwnerResponseStatus);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Sets the status in the owner-level table
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param owner_id
     *            owner of the level
     * @param identifier
     *            identifier for the level
     * @param status
     *            status to be set
     * @param changeStatus
     *            (true / false) --> (Submit / Save)
     * @throws Exception
     */
    public void updateOwnerResponseStatusOtherActivity(String owner_id,
                                                       String identifier, String status, String questionid)
            throws Exception {
        Connection con = null;
        PreparedStatement updateOwnerResponseStatus = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            updateOwnerResponseStatus = con
                    .prepareStatement("UPDATE OWNER_RESPONSE ORS SET ORS.STATUS=?,ORS.MOD_DATE=?,ORS.MOD_USER=? WHERE ORS.ASSOCIATED_ID=? AND ORS.OWNER_ID=? AND ORS.QUESTION_ID=?");
            updateOwnerResponseStatus.setString(1, status);
            updateOwnerResponseStatus.setDate(2, new Date(System
                    .currentTimeMillis()));
            updateOwnerResponseStatus.setString(3, owner_id);
            updateOwnerResponseStatus.setString(4, identifier);
            updateOwnerResponseStatus.setString(5, owner_id);
            updateOwnerResponseStatus.setString(6, questionid);

            int result = updateOwnerResponseStatus.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(updateOwnerResponseStatus);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Sets the status in the owner-level table
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param owner_id
     *            owner of the level
     * @param identifier
     *            identifier for the level
     * @param status
     *            status to be set
     * @param changeStatus
     *            (true / false) --> (Submit / Save)
     * @throws Exception
     */
    public void updateOwnerResponseStatus(int responseId, String ownerid,
                                          String status) throws Exception {
        Connection con = null;
        PreparedStatement updateOwnerResponseStatus = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            updateOwnerResponseStatus = con
                    .prepareStatement(getOwnerResponseUpdateQuery("response"));
            updateOwnerResponseStatus.setString(1, status);
            updateOwnerResponseStatus.setDate(2, new Date(System
                    .currentTimeMillis()));
            updateOwnerResponseStatus.setString(3, ownerid);
            updateOwnerResponseStatus.setInt(4, responseId);

            int result = updateOwnerResponseStatus.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(updateOwnerResponseStatus);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Sets the status in the level table
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param owner_id
     *            owner of the level
     * @param identifier
     *            identifier for the level
     * @param status
     *            status to be set
     * @param changeStatus
     *            (true / false) --> (Submit / Save)
     * @throws Exception
     */
    public void updateStatus(String level, String owner_id, String identifier,
                             String status) throws Exception {
        Connection connection = null;
        PreparedStatement updateStatus=null;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

            updateStatus = connection
                    .prepareStatement(getLevelUpdateQuery(level));

            updateStatus.setString(1, status);

            updateStatus.setDate(2, new Date(System.currentTimeMillis()));

            updateStatus.setString(3, owner_id);

            updateStatus.setString(4, identifier);

            updateStatus.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(updateStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Get status for a particular level
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param identifier
     *            identifier for level
     * @return
     * @throws Exception
     */
    public String getStatus(String level, String identifier) throws Exception {
        String status = "";

        Connection connection = null;
        PreparedStatement selectStatus=null;
        ResultSet rs=null;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

            selectStatus = connection
                    .prepareStatement(getLevelRetrieveQuery(level));

            selectStatus.setString(1, identifier);

            rs = selectStatus.executeQuery();

            while (rs.next()) {

                return rs.getString("STATUS");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(selectStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return status;
    }

    /**
     * Get status for a particular owner level
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param identifier
     *            identifier for level
     * @return
     * @throws Exception
     */
    public String getOwnerStatus(String level, String ownerid, String identifier)
            throws Exception {
        String status = "";

        Connection connection = null;
        PreparedStatement selectStatus=null;
        ResultSet rs=null;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

            selectStatus = connection
                    .prepareStatement(getOwnerLevelRetrieveQuery(level));

            selectStatus.setString(1, ownerid);

            selectStatus.setString(2, identifier);

            rs = selectStatus.executeQuery();

            while (rs.next()) {

                return rs.getString("STATUS");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //connection.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(selectStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return status;
    }

    /**
     * Get status for a particular owner for a particular Level
     *
     * @param level
     *            (Cycle / Subcyle /Activity )
     * @param identifier
     *            identifier for level
     * @return
     * @throws Exception
     */
    public String getOwnerOverAllStatus(String level, String ownerid)
            throws Exception {
        String status = "";

        Connection connection = null;
        PreparedStatement selectStatus=null;
        ResultSet rs=null;


        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

            selectStatus = connection
                    .prepareStatement(getOwnerLevelOverAllStatusQuery(level));

            selectStatus.setString(1, ownerid);

            rs = selectStatus.executeQuery();

            while (rs.next()) {

                return rs.getString("STATUS");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //connection.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(selectStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return status;
    }

    /**
     * returns true if the identifier at current level is complete
     * @param level
     * @param identifier
     * @return true is current level is complete
     * @throws Exception
     */
    public boolean isCurrentLevelComplete(String level, String identifier)
            throws Exception {

        boolean isStatusComplete = false;

        Connection connection = null;
        PreparedStatement selectStatus=null;
        ResultSet rs=null;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();

            selectStatus = connection
                    .prepareStatement(getCurrentLevelStatusQuery(level));

            selectStatus.setString(1, identifier);

            rs = selectStatus.executeQuery();

            while (rs.next()) {

                if (rs.getString("STATUS").equalsIgnoreCase(
                        SoxicConstants.GREEN_COMPLETE)) {
                    return true;
                } else {
                    return false;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(selectStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return isStatusComplete;
    }

    /**
     * Returns the update query for the level
     *
     * @param level
     * @return Query
     */
    private String getLevelUpdateQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.status.update");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.status.update");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

            query = SoxicUtil.getQuery("controlobjective.status.update");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.status.update");
        }
        return query;
    }

    /**
     * Returns the update query for the owner-level
     *
     * @param level
     * @return Query
     */
    private String getOwnerLevelUpdateQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.owner.status.update");
        }

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.owner.status.update");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.owner.status.update");
        }
        return query;
    }

    /**
     * Returns the update query for the owner-level
     *
     * @param level
     * @return Query
     */
    private String getOwnerResponseUpdateQuery(String id) {

        String query = "";

        if (id.equalsIgnoreCase("response")) {
            query = SoxicUtil.getQuery("owner.status.update");
        }

        if (id.equalsIgnoreCase("ownerquestionidentifier")) {
            query = SoxicUtil.getQuery("owner.question.status.update");
        }

        return query;
    }

    /**
     * Returns the update query for the owner-level for save operation
     *
     * @param level
     * @return Query
     */
    private String getOwnerLevelSaveQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.owner.status.update.save");
        }

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.owner.status.update.save");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.owner.status.update.save");
        }
        return query;
    }

    /**
     * Returns the retrieve query for the level
     *
     * @param level
     * @return Query
     */
    private String getLevelRetrieveQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.status.retrieve");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.status.retrieve");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

            query = SoxicUtil.getQuery("controlobjective.status.retrieve");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.status.retrieve");
        }
        return query;
    }

    /**
     * Returns the retrieve query for the owner level
     *
     * @param level
     * @return Query
     */
    private String getOwnerLevelRetrieveQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.owner.status.retrieve");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.owner.status.retrieve");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.owner.status.retrieve");
        }
        return query;
    }

    /**
     * Returns the retrieve query for the owner level
     *
     * @param level
     * @return Query
     */
    private String getOwnerLevelOverAllStatusQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.status.current.level.overall");
        }

        if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

            query = SoxicUtil.getQuery("cycle.status.current.level.overall");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.status.current.level.overall");
        }
        return query;
    }

    /**
     * Returns the retrieve query for the owner level
     *
     * @param level
     * @return Query
     */
    private String getCurrentLevelStatusQuery(String level) {

        String query = "";

        if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

            query = SoxicUtil.getQuery("subcycle.status.current.level");
        }

        if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

            query = SoxicUtil.getQuery("activity.status.current.level");
        }
        return query;
    }


    public String getStatusAfterEnteringSubCycleGap(String questionId, String associatedId, String ownerId) throws Exception {
        String status = "";
        Connection connection = null;
        PreparedStatement selectStatus=null;
        ResultSet rs=null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            selectStatus = connection.prepareStatement
                            ("SELECT STATUS " +
                            "FROM OWNER_RESPONSE " +
                            "WHERE QUESTION_ID = ? " +
                            "AND ASSOCIATED_ID = ? " +
                            "AND OWNER_ID = ?");
            selectStatus.setString(1, questionId);
            selectStatus.setString(2, associatedId);
            selectStatus.setString(3, ownerId);
            rs = selectStatus.executeQuery();
            while (rs.next()) {
                return rs.getString("STATUS");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                //connection.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(selectStatus);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return status;
    }
}