package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 1:43:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class HeaderFooterFactory {

    public static HeaderFooterFacade getFacade(String level){
        HeaderFooterFacade headerFooterFacade = null;

        if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
            headerFooterFacade = new CycleHeadFootFacade();
        }

        if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
            headerFooterFacade = new SubCycleHeadFootFacade();
        }

        if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
            headerFooterFacade = new ActivityHeadFootFacade();
        }

        return headerFooterFacade;
    }

}
