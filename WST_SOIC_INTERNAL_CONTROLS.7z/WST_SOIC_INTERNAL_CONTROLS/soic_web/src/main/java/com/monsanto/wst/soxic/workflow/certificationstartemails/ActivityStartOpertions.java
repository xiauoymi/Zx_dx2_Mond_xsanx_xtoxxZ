package com.monsanto.wst.soxic.workflow.certificationstartemails;

import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.workflow.Activity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 27, 2006
 * Time: 4:18:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityStartOpertions extends StartOperations{

    public static void main(String[] args) {
        StartOperations activityStartOpertions = new ActivityStartOpertions(SoxicConstants.ACTIVITY);
        try {
            activityStartOpertions.sendStartEmail();
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public ActivityStartOpertions(String level) {
        super(level);
    }

    protected void emailUpperLevel() throws Exception {
        UtilDAO utilDAO = new UtilDAO();
        Map ownerSubCycleMap = utilDAO.getStartDateUpperLevelOwnerWrapper(SoxicConstants.ACTIVITY);

        Iterator ownerSubCycleIterator = ownerSubCycleMap.values().iterator();

        while(ownerSubCycleIterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)ownerSubCycleIterator.next();
            SarboxMailComponent.sendStartUpperWorkFlowEmail(SoxicConstants.ACTIVITY,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString());
        }
    }

    protected void emailCurrentLevel(List activityList, String customString) throws Exception {
        Map ownerMap = processStartActivityList(activityList);
        Iterator iterator = ownerMap.values().iterator();
        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            SarboxMailComponent.sendStartWorkFlowEmail(SoxicConstants.ACTIVITY,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString(), customString);
        }
    }

    protected String getHeaderLevel() {
        return SoxicConstants.ACTIVITY_EMAIL_HEADER;
    }

    protected Map processStartActivityList(List activityList)throws Exception{
        Iterator iterator = activityList.iterator();
        Map activityOwnerMap = new HashMap();
        while(iterator.hasNext()){
            Activity activity = (Activity)iterator.next();
            if(!activityOwnerMap.containsKey(activity.getOwner_id())){
                OwnerWrapper ownerWrapper = getActivityDetailsForOwnerStartDateToday(activity);
                activityOwnerMap.put(activity.getOwner_id(),ownerWrapper);
            }
        }
        return activityOwnerMap;
    }

    protected OwnerWrapper getActivityDetailsForOwnerStartDateToday(Activity activity) throws Exception {
        UtilDAO utilDAO = new UtilDAO();
        OwnerWrapper ownerWrapper = utilDAO.getActivityDetailsForOwnerWhoseStartDateIsToday(activity.getOwner_id());
        return ownerWrapper;
    }

}
