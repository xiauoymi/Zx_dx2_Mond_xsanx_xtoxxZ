//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ActivityReportForm;
import com.monsanto.wst.soxic.form.ReportOptionsForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

/** 
 * MyEclipse Struts
 * Creation date: 03-11-2005
 * 
 * XDoclet definition:
 * @struts:action path="/activityReport" name="activityReportForm" scope="request" validate="true"
 */
public class ActivityReportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	// --------------------------------------------------------- Methods
	
	
	
	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		ActivityReportForm activityReportForm = (ActivityReportForm) form;
		
		String[] cyclesSel = activityReportForm.getCyclesSelected();
		String[] countriesSel = activityReportForm.getCountriesSelected();
		
		Vector cycles = new Vector();
		Vector countries = new Vector();
		
		//**Countries List
		if(countriesSel[0].equals("All Countries")){		
			for(int i = 1; i < ((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getAllCountryList().size(); i++){
				countries.add(((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getAllCountryList().get(i));
			}
		}
		else{
			for(int i = 0; i < countriesSel.length; i++){
					countries.add(countriesSel[i]);
			}
		}
		
		//**Cycles List
		if(cyclesSel[0].equals("All Cycles")){		
			//cycles = ((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleList();
			for(int i = 1; i < ((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleCodeList().size(); i++){
				cycles.add(((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleCodeList().get(i));
			}
		}
		else{
			for(int i = 0; i < cyclesSel.length; i++){
				cycles.add(cyclesSel[i]);
			}
		}
		
		activityReportForm.setCountriesList(countries);
		activityReportForm.setCyclesList(cycles);
		
		
		//**FinalCycleList: the list of all compatible country-cycles present.
		String periodID = activityReportForm.getPeriodID();
		Vector finalCycleList1 = new Vector();
		Vector finalCycleList2 = new Vector();
		Vector allCycles = new Vector();
		
		Vector cycleIDs = new Vector();
		
		Vector cycleVector = new Vector();
		
		//**Connecting to the Oracle DB...
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			Connection con = SoxicConnectionFactory.getSoxicConnection();
			ResultSet rs1;
			ResultSet rs2;
			ResultSet rs3;
		 	
		 	logger.info("Connected to DB from /activity-report.");
			
			//**Prepared Statements...
			PreparedStatement getfinalCycleList1;
			PreparedStatement getfinalCycleList2;
			PreparedStatement getallCycles;
			
			//****************CHUNKING********************************************************************
			PreparedStatement getActivityDescChunk;
			PreparedStatement getCODescChunk;
			
			getActivityDescChunk = con.prepareStatement
				("SELECT " +
						"T.TEXT_CHUNK " +
					"FROM " +
						"ACTIVITY A, TEXT_OVERFLOW T " +
					"WHERE " +
						"A.ACTIVITY_ID = ? AND " +
						"T.OVERFLOW_ID = A.OVERFLOW_ID " +
					"ORDER BY T.SEQUENCE");
			
			getCODescChunk = con.prepareStatement
				("SELECT " +
						"T.TEXT_CHUNK " +
					"FROM " +
						"CTRL_OBJ C, TEXT_OVERFLOW T " +
					"WHERE " +
						"C.CTRL_OBJ_ID = ? AND " +
						"T.OVERFLOW_ID = C.OVERFLOW_ID    ORDER BY T.SEQUENCE");
			
			//********************************************************************************************
			
			getfinalCycleList1 = con.prepareStatement
					("SELECT CYCLE_ID " +
						"FROM CYCLE " +
						"WHERE " +
							"PERIOD_ID = ? AND " +
							"COUNTRY_ID = ?");
			
			for(int idx = 0; idx < countries.size(); idx++){
				getfinalCycleList1.setString(1, periodID);
				getfinalCycleList1.setString(2, countries.get(idx).toString());
				rs1 = getfinalCycleList1.executeQuery();
			
				while(rs1.next()){
					finalCycleList1.add(rs1.getString("CYCLE_ID"));
				}
			}
			
			getfinalCycleList2 = con.prepareStatement
			("SELECT CYCLE_ID " +
				"FROM CYCLE " +
				"WHERE " +
					"PERIOD_ID = ? AND " +
					"CYCLE_CODE = ?");
	
			for(int idx = 0; idx < cycles.size(); idx++){
				getfinalCycleList2.setString(1, periodID);
				getfinalCycleList2.setString(2, cycles.get(idx).toString());			
				rs2 = getfinalCycleList2.executeQuery();
	
				while(rs2.next()){
					finalCycleList2.add(rs2.getString("CYCLE_ID"));
				}
			}
			
			getallCycles = con.prepareStatement
			("SELECT CYCLE_ID " +
				"FROM CYCLE " +
				"WHERE " +
					"PERIOD_ID = ?");
	
			getallCycles.setString(1, periodID);
			rs3 = getallCycles.executeQuery();
	
			while(rs3.next()){
				allCycles.add(rs3.getString("CYCLE_ID"));
			}
			
			if(countriesSel[0].equals("All Countries") && cyclesSel[0].equals("All Cycles")){
				cycleIDs = allCycles;
			}
			else{ 
				if(cyclesSel[0].equals("All Cycles")){
					cycleIDs = finalCycleList1;
				}
				else{
					if(countriesSel[0].equals("All Countries")){
						cycleIDs = finalCycleList2;
					}
					else{
						for(int idx = 0; idx < finalCycleList1.size(); idx++){
							if(finalCycleList2.contains(finalCycleList1.get(idx))){
								cycleIDs.add(finalCycleList1.get(idx));
							}
						}
					}
					
				}
			}
			
			
			//**Generate the Report using cycleIDs...
			//**********************************************************************************************
			for(int cCnt = 0; cCnt < cycleIDs.size(); cCnt++){
				
				//**Generate report for each cycle...
				ActivityReportObject reportObject = new ActivityReportObject();
				
				reportObject.setCycleID(cycleIDs.get(cCnt).toString());
				
				Vector rowList = new Vector();
				
				ResultSet rs4;
				
				PreparedStatement getGapReport;
				
				getGapReport = con.prepareStatement
					("SELECT " +
						"C.CYCLE_CODE CYCLE_CODE, " +
						"C.COUNTRY_ID COUNTRY, " +
						"OA.START_DATE START_DATE, " +
						"A.ACTIVITY_ID ACTIVITY_ID, " +
						"CO.CTRL_OBJ_ID CO_ID, " +
						"CO.DESCRIPTION CO_DESCRIPTION, " +
						"A.DESCRIPTION ACTIVITY_DESCRIPTION, " +
						"O.LOCATION LOCATION, " +
						"O.EMAIL NAME, " +
						"G.DESCRIPTION GAP_DESCRIPTION, " +
						"G.TYPE GAP_TYPE " +
					"FROM " +
						"GAP_DC_LOE G, OWNER_RESPONSE ORES, " +
						"OWNER O, OWNER_ACTIVITY OA, ACTIVITY A, " +
						"CTRL_OBJ CO, SUB_CYCLE SC, CYCLE C " +
					"WHERE " +
						"G.RESPONSE_ID = ORES.RESPONSE_ID AND " +
						"ORES.OWNER_ID = O.OWNER_ID AND " +
						"OA.OWNER_ID = O.OWNER_ID AND " +
						"OA.ACTIVITY_ID = A.ACTIVITY_ID AND " +
						"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
						"SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"ORES.ASSOCIATED_TYPE = 'A' AND " +
						"ORES.ASSOCIATED_ID = A.ACTIVITY_ID AND " +
						"C.CYCLE_ID = ?");
				
				
				getGapReport.setString(1, cycleIDs.get(cCnt).toString());
				rs4 = getGapReport.executeQuery();
			
				while(rs4.next()){
					
					ActivityReportRowObject rowObject = new ActivityReportRowObject();
					
					rowObject.setCycleCode(rs4.getString("CYCLE_CODE"));
					rowObject.setCountry(rs4.getString("COUNTRY"));
					rowObject.setStartDate(rs4.getDate("START_DATE"));
					rowObject.setActivityID(rs4.getString("ACTIVITY_ID"));
					//rowObject.setCtrlObjDesc(rs4.getString("CO_DESCRIPTION"));
					//rowObject.setActivityDesc(rs4.getString("ACTIVITY_DESCRIPTION"));
					rowObject.setLocation(rs4.getString("LOCATION"));
					rowObject.setName(rs4.getString("NAME"));
					rowObject.setGapDesc(rs4.getString("GAP_DESCRIPTION"));
					rowObject.setGapType(rs4.getString("GAP_TYPE"));
					
					//****Code for chunking to be added******************************************************
					String completeActivityChunk = "";
					String completeCOChunk = "";
					
					completeActivityChunk = rs4.getString("ACTIVITY_DESCRIPTION");
					completeCOChunk = rs4.getString("CO_DESCRIPTION");
					
					//**Activity-Chunk.....................
					try{
						getActivityDescChunk.setString(1, rs4.getString("ACTIVITY_ID").toString());
						ResultSet rsActivityChunk = getActivityDescChunk.executeQuery();
						
						while(rsActivityChunk.next()){
							completeActivityChunk += rsActivityChunk.getString("TEXT_CHUNK");
						}
					}
					catch(Exception sqle){
						logger.error(sqle.getMessage());
					}
					
					
					//**CO-Chunk.....................
					try{
						getCODescChunk.setString(1, rs4.getString("CO_ID").toString());
						ResultSet rsCOChunk = getCODescChunk.executeQuery();
						
						while(rsCOChunk.next()){
							completeCOChunk += rsCOChunk.getString("TEXT_CHUNK");
						}
					}
					catch(Exception sqle){
						logger.error(sqle.getMessage());
					}
					
					
					rowObject.setActivityDesc(completeActivityChunk);
					rowObject.setCtrlObjDesc(completeCOChunk);
					
					//*****************************************************************************************
					
					reportObject.setCycleName(rs4.getString("CYCLE_CODE"));
					
					rowList.add(rowObject);
				}
				
				reportObject.setRowList(rowList);
				
				cycleVector.add(reportObject);
			
			}
			
			
			//**********************************************************************************************
			
			con.close();
			
		
		}
		catch(Exception ex){
			logger.error("DB problem" + ex.getMessage());
		}
		
		ActionErrors errors = new ActionErrors();
		
		if(cycleIDs == null || cycleIDs.size() == 0){
			errors.add("cycleIDs2", new ActionError("errors.activityReport.finalCycleIDList.null"));
		}
		
		if(errors.isEmpty()){
			
			activityReportForm.setCycleIDs(cycleIDs);
			activityReportForm.setCycleVector(cycleVector);
			
			return mapping.findForward("success");
		}
		else{
			saveErrors(request, errors);
			return mapping.findForward("faliure");
		}
		
		
	}

}