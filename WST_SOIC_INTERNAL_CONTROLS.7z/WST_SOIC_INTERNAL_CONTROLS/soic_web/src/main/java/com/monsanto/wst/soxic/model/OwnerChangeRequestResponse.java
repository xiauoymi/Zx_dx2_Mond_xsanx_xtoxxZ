package com.monsanto.wst.soxic.model;

import java.sql.PreparedStatement;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 3, 2005
 * Time: 4:27:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerChangeRequestResponse extends SoxicBaseModel{

    public static final String RESPONSE_TYPE="RESP_TYPE";
    public static final String OWNER_ID = "OWNER_ID";
    public static final String RESPONSE_DATE="RESP_DATE";
    public static final String APPROVED="APPROVED";
    public static final String NOTES="NOTES";
    public static final String OCREQ_ID="OCREQ_ID";

    public static final String SUB_CYCLE_RESPONSE_TYPE="SUB_CYCLE";
    public static final String IA_RESPONSE_TYPE="IA";

    public static final String APPROVE_RESPONSE ="Y";
    public static final String REJECT_RESPONSE ="N";
    public static final String PENDING_RESPONSE ="P";

    private String responseType;
    private String ownerId;
    private Date responseDate;
    private String approved;
    private String notes;
    private String responseId;

    public String getResponseType() {
        return responseType;
    }

    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }


    public String getApproved() {
        return approved;
    }

    public void setApproved(String approved) {
        this.approved = approved;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getId(){
        return "";
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    public String getQuery(String type){
        return "INSERT INTO OCREQ_RESPONSE ("+OCREQ_ID+","+RESPONSE_TYPE+ ","+OWNER_ID+ ","+RESPONSE_DATE+ ","+APPROVED+ ","+NOTES+","+"MOD_DATE,MOD_USER) VALUES(?,?,?,?,?,?,?,?)";
    }

    //TODO REMOVE FROM HERE
    public void setParameters(PreparedStatement pstmt,String queryType){
        try{
            if(queryType.equalsIgnoreCase("INSERT")){
                pstmt.setString(1,getResponseId());
                pstmt.setString(2,getResponseType());
                pstmt.setString(3,getOwnerId());
                //pstmt.setDate(4,new Date(System.currentTimeMillis()));
                pstmt.setTimestamp(4,new Timestamp(System.currentTimeMillis()));
                pstmt.setString(5,getApproved());
                pstmt.setString(6,getNotes());
                pstmt.setDate(7,new Date(System.currentTimeMillis()));
                pstmt.setString(8,OWNER_ID);

            }
        }catch(SQLException sqle){

        }

    }

    public static OwnerChangeRequestResponse createNewActivitySubCycleOwnerResponse(String respId,Owner owner){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(PENDING_RESPONSE);
        ownerChangeRequestResponse.setResponseType(SUB_CYCLE_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes("");
        return ownerChangeRequestResponse;
    }

    public static OwnerChangeRequestResponse createNewActivityIAOwnerResponse(String respId,Owner owner){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(PENDING_RESPONSE);
        ownerChangeRequestResponse.setResponseType(IA_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes("");
        return ownerChangeRequestResponse;
    }

    public static OwnerChangeRequestResponse createNewActivitySubCycleApproved(String respId,Owner owner){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(APPROVE_RESPONSE);
        ownerChangeRequestResponse.setResponseType(SUB_CYCLE_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes("");
        return ownerChangeRequestResponse;
    }

    public static OwnerChangeRequestResponse createNewActivitySubCycleReject(String respId,Owner owner,String resonToReject){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(REJECT_RESPONSE);
        ownerChangeRequestResponse.setResponseType(SUB_CYCLE_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes(resonToReject);
        return ownerChangeRequestResponse;
    }

    public static OwnerChangeRequestResponse createNewActivityIAApproved(String respId,Owner owner){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(APPROVE_RESPONSE);
        ownerChangeRequestResponse.setResponseType(IA_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes("");
        return ownerChangeRequestResponse;
    }

    public static OwnerChangeRequestResponse createNewActivityIAReject(String respId,Owner owner,String resonToReject){
        OwnerChangeRequestResponse ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        ownerChangeRequestResponse.setResponseId(respId);
        ownerChangeRequestResponse.setApproved(REJECT_RESPONSE);
        ownerChangeRequestResponse.setResponseType(IA_RESPONSE_TYPE);
        ownerChangeRequestResponse.setOwnerId(owner.getOwnerId());
        ownerChangeRequestResponse.setNotes(resonToReject);
        return ownerChangeRequestResponse;
    }

}
