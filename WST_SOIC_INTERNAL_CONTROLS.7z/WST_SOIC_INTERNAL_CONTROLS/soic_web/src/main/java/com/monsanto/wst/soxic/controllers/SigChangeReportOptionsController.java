package com.monsanto.wst.soxic.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.facade.reports.SigChangeReportFacade;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 9:54:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class SigChangeReportOptionsController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        SigChangeReportFacade sigChangeReportFacade = new SigChangeReportFacade();
        String method = helper.getRequestParameterValue("method");
        if (method==null){
            sigChangeReportFacade.buildReportOptions(helper);
        }
        else
        if (method.equalsIgnoreCase(SoxicConstants.COUNTRY)){
            sigChangeReportFacade.buildReportOptionsWithPeriod(helper);
        }
    }
}
