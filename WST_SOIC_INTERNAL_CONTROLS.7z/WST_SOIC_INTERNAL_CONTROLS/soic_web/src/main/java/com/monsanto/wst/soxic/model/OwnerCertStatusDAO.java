package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 10:02:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerCertStatusDAO {

    private static final String cycleOwnerQuery = "SELECT C.CYCLE_ID, OC.STATUS " +
            "  FROM CYCLE C, OWNER_CYCLE OC " +
            " WHERE C.CYCLE_ID = OC.CYCLE_ID " +
            "   AND OC.OWNER_ID = ? " +
            "   AND C.PERIOD_ID = ?";

    private static final String subcycleOwnerQuery = "SELECT SC.SUB_CYCLE_ID, OSC.STATUS " +
            "  FROM SUB_CYCLE SC, OWNER_SUB_CYCLE OSC, CYCLE C " +
            " WHERE OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
            "   AND SC.CYCLE_ID = C.CYCLE_ID " +
            "   AND OSC.OWNER_ID = ? " +
            "   AND C.PERIOD_ID = ?";

    private static final String activityOwnerQuery = "SELECT A.ACTIVITY_ID, OA.STATUS " +
            "  FROM OWNER_ACTIVITY OA, ACTIVITY A, CTRL_OBJ CO, SUB_CYCLE SC, CYCLE C " +
            " WHERE OA.ACTIVITY_ID = A.ACTIVITY_ID " +
            "   AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
            "   AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
            "   AND SC.CYCLE_ID = C.CYCLE_ID " +
            "   AND OA.OWNER_ID = ? " +
            "   AND C.PERIOD_ID = ?";

    public List getCycleList(String ownerid, String periodId) throws Exception {
        List cycleOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(cycleOwnerQuery);
                preparedStatement.setString(1, ownerid);
                preparedStatement.setString(2, periodId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String cycleid = rs.getString("CYCLE_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(cycleid, status, cycleOwners);
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(cycleOwners);
        return cycleOwners;
    }

    private void closeDBConnection(ResultSet rs, PreparedStatement preparedStatement, Connection con) {
        SoxicConnectionFactory.closeResultSet(rs);
        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
        SoxicConnectionFactory.closeSoxicConnection(con);
    }

    private String setStatusToDisplay(String tablestatus) {
        String status;
        if (tablestatus.equalsIgnoreCase(SoxicConstants.COMPLETE)){
            status = "COMPLETE";
        }
        else{
            status = "-";
        }
        return status;
    }

    private void setIdAndStatusIntoList(String id, String status, List ownerList) {
        ReportStatus reportStatus;
        reportStatus = new ReportStatus(id,status);
        ownerList.add(reportStatus);
    }

    public List getSubcycleList(String ownerid, String periodId) throws Exception {
        List subcycleOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(subcycleOwnerQuery);
                preparedStatement.setString(1, ownerid);
                preparedStatement.setString(2, periodId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String subcycleid = rs.getString("SUB_CYCLE_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(subcycleid, status, subcycleOwners);
                }
            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(subcycleOwners);
        return subcycleOwners;
    }

    public List getActivityList(String ownerid, String periodId) throws Exception {
        List activityOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(activityOwnerQuery);
                preparedStatement.setString(1, ownerid);
                preparedStatement.setString(2, periodId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String activityid = rs.getString("ACTIVITY_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(activityid, status, activityOwners);
                }
            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(activityOwners);
        return activityOwners;
    }
}
