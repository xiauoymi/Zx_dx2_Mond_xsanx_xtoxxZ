/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.exception;

import java.sql.SQLException;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DatabaseException extends Exception {
    
    private int errorCode;	
	/**
	 * A Constant that holds the Exception Message to be displayed when the DB Pooling Initiliazation fails.
	 */
	public static final String DB_POOLING_INIT_FAILURE="Fail to initialize the database pooling";

	/**
	 * A Constant that holds the Exception Message to be displayed when the Number of Connections in the connection pool just exceeds its maximum value .
	 */
	public static final String MAX_CONNECTION_SIZE_EXCEEDED="The maximum connection pool size has been exceeded";

	/**
	 * A Constant that holds the Exception Message to be displayed when the creation of new connection fails.
	 */
	public static final String NEW_CONNECTION_CREATION_FAILURE = "Fail to create new connection";

	/**
	 * A Constant that holds the Exception Message to be displayed when an unexpected database pooling error occurs.
	 */
	public static final String UNEXPECTED_POOLING_ERROR="Encountered a unexpected database pooling error";

	/**
	 * A Constant that holds the Exception Message to be displayed when the closure of a connection fails.
	 */
	public static final String CLOSE_CONNECTION_FAILURE="Fail to close the connection";
	
	/**
	 * Constructs a new DatabaseException object using the dbException string. 
	 * @param dbException A string that says what kind of DB Exception occured.
	 */
	public DatabaseException(String dbException)
	{
		super(dbException);
	}

	/**
	 * Constructs a new DatabaseException object using the SQLException. 
	 * @param exception SQLException.
	 */

	public DatabaseException(SQLException exception)
	{
		super(exception.getMessage());
		this.errorCode = exception.getErrorCode();
	}

	/**
	 * @return
	 */
	public int getErrorCode() {
		return errorCode;
	}

    public DatabaseException(Exception exception)
	{
		super(exception.getMessage());		
	}

}
