package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 20, 2005
 * Time: 11:39:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class SubCycleDeleteForm extends ActionForm{

    private List country;
    private String selectedCountry;

    private List cycles;
    private String selectedCycles;

    private List subcycle;

    private String scindex;

    private FormFile requestedFile;

    public FormFile getRequestedFile() {
        return requestedFile;
    }

    public void setRequestedFile(FormFile requestedFile) {
        this.requestedFile = requestedFile;
    }

    public String getScindex() {
        return scindex;
    }

    public void setScindex(String scindex) {
        this.scindex = scindex;
    }

    public List getSubcycle() {
        return subcycle;
    }

    public void setSubcycle(List subcycle) {
        this.subcycle = subcycle;
    }

    public List getCountry() {
        return country;
    }

    public void setCountry(List country) {
        this.country = country;
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public String getSelectedCycles() {
        return selectedCycles;
    }

    public void setSelectedCycles(String selectedCycles) {
        this.selectedCycles = selectedCycles;
    }

//    public void reset(ActionMapping mapping, HttpServletRequest request){
//
//        selectedCountry = null;
//        selectedCycles= null;
//
//    }


}
