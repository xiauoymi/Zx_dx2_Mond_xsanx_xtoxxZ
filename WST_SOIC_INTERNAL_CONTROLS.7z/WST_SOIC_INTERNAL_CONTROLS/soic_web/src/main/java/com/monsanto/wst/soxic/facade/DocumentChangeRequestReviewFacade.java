package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.exception.NoDocumentChangeListOfActivitiesToReview;
import com.monsanto.wst.soxic.form.DocumentChangeRequestReviewForm;
import com.monsanto.wst.soxic.model.DocumentChangeDetails;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.persistance.AbstractDAOFactory;
import com.monsanto.wst.soxic.persistance.OracleDocumentChangeDAO;
import com.monsanto.wst.soxic.persistance.OracleSubCycleDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.struts.action.ActionForm;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 5, 2005
 * Time: 11:49:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeRequestReviewFacade {

    /**
     *Prepopulate the Country , Cycle and Sub cycle based avaliable activity requests
     * @param form
     * @param owner
     * @throws NoDocumentChangeListOfActivitiesToReview
     */
    public void prePopulateForm(ActionForm form,Owner owner)throws NoDocumentChangeListOfActivitiesToReview{
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        Map reviewList = getReveiwRequestList(documentChangeRequestReviewForm,owner);
        if(reviewList.size()>0){
            //documentChangeRequestReviewForm.setSelectedCountry("");
            documentChangeRequestReviewForm.setAllOwnerReviews(reviewList);
            populateCountryList(documentChangeRequestReviewForm,reviewList);
            String countryId = (String)documentChangeRequestReviewForm.getCountries().get(0);
            documentChangeRequestReviewForm.setSelectedCountry((String)documentChangeRequestReviewForm.getCountries().get(0));
            populateCycleList(documentChangeRequestReviewForm,reviewList,countryId);
            String cycleId =   (String)documentChangeRequestReviewForm.getCycles().get(0);
            documentChangeRequestReviewForm.setSelectedCycle(cycleId);
            populateSubCycleList(documentChangeRequestReviewForm,reviewList,countryId,cycleId);
            documentChangeRequestReviewForm.setSelectedSubCycle((String)documentChangeRequestReviewForm.getSubCycles().get(0));
        }else{
            throw new NoDocumentChangeListOfActivitiesToReview();
        }
    }

    /**
     *Based on who the owner is Get all the Document change requests
     * The type of owners can be IA , IAUser , Sub Cycle ,Activity owners or other activity owners
     * @param documentChangeRequestReviewForm
     * @param owner
     * @return
     */
    private Map getReveiwRequestList(DocumentChangeRequestReviewForm documentChangeRequestReviewForm,Owner owner){
        Map initDocumentRequests = new HashMap();
        OracleDocumentChangeDAO oracleDocumentChangeDAO= (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        try{
            if(!owner.isIA()){
                oracleDocumentChangeDAO.selectAll(OracleDocumentChangeDAO.SELECT_INIT_REQ_ACT_OWNER,owner,initDocumentRequests);
                oracleDocumentChangeDAO.selectAll(OracleDocumentChangeDAO.SELECT_INIT_REQ_OTH_ACT_OWNER,owner,initDocumentRequests);
                oracleDocumentChangeDAO.selectAll(OracleDocumentChangeDAO.SELECT_INIT_REQ_SUB_CYCLE_OWNER,owner,initDocumentRequests);
            }
            if(owner.isIA()){
                oracleDocumentChangeDAO.selectAll(OracleDocumentChangeDAO.SELECT_INIT_REQ_IA_OWNER,owner,initDocumentRequests);
            }
            if(owner.isIAUser()){
                oracleDocumentChangeDAO.selectAll(OracleDocumentChangeDAO.SELECT_INIT_REQ_IA_USER,owner,initDocumentRequests);
            }

        }catch(Exception e){

        }
        return initDocumentRequests;
    }

    private Map getReveiwRequestDisplayList(DocumentChangeRequestReviewForm documentChangeRequestReviewForm,Owner owner){
        Map mapToDisplay = new HashMap();
        OracleDocumentChangeDAO oracleDocumentChangeDAO= (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        try{

            if(owner.isIA()){
                oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_IAADMINOWN_PER_SUBCYCLE,owner,documentChangeRequestReviewForm.getSelectedSubCycle(),mapToDisplay);
            }
                OracleSubCycleDAO oracleSubCycleDAO= (OracleSubCycleDAO) AbstractDAOFactory.getFactory().getSubCycleDAO();
                if(oracleSubCycleDAO.isSubCycleOwner(owner,documentChangeRequestReviewForm.getSelectedSubCycle())){
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_SUBOWN_PER_SUBCYCLE,owner,documentChangeRequestReviewForm.getSelectedSubCycle(),mapToDisplay);
                }else{
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_ACTOWN_PER_SUBCYCLE,owner,documentChangeRequestReviewForm.getSelectedSubCycle(),mapToDisplay);
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_OTHACTOWN_PER_SUBCYCLE,owner,documentChangeRequestReviewForm.getSelectedSubCycle(),mapToDisplay);
                }
            if(owner.isIAUser()){
                oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_IAOWN_PER_SUB_CYCLE,owner,documentChangeRequestReviewForm.getSelectedSubCycle(),mapToDisplay);
            }


        }catch(Exception e){

        }
        return mapToDisplay;
    }

    private void populateCountryList(DocumentChangeRequestReviewForm documentChangeRequestReviewForm,Map documentRequestList){
        Set hashSet = new HashSet();
        Iterator iterator = documentRequestList.values().iterator();

        while(iterator.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)iterator.next();
            hashSet.add(documentChangeDetails.getCountry());
        }
        documentChangeRequestReviewForm.setCountries(hashSet);
    }

    private void populateCycleList(DocumentChangeRequestReviewForm documentChangeRequestReviewForm,Map documentRequestList,String countryId){
        Set hashSet = new HashSet();
        Iterator iterator = documentRequestList.values().iterator();

        while(iterator.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)iterator.next();
            if(documentChangeDetails.getCountry().equalsIgnoreCase(countryId)){
                hashSet.add(documentChangeDetails.getCycle());
            }
        }
        documentChangeRequestReviewForm.setCycles(hashSet);
    }

    private void populateSubCycleList(DocumentChangeRequestReviewForm documentChangeRequestReviewForm,Map documentRequestList,String countryId,String cycleId){
        Set hashSet = new HashSet();
        Iterator iterator = documentRequestList.values().iterator();

        while(iterator.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)iterator.next();
            if(documentChangeDetails.getCountry().equalsIgnoreCase(countryId) && documentChangeDetails.getCycle().equalsIgnoreCase(cycleId)){
                hashSet.add(documentChangeDetails.getSubCycle());
            }
        }
        documentChangeRequestReviewForm.setSubCycles(hashSet);
        documentChangeRequestReviewForm.setRequestReviewList(null);
        documentChangeRequestReviewForm.setViewAll(false);
    }

    public void changeCountry(ActionForm form){
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        String selectedCountry = documentChangeRequestReviewForm.getSelectedCountry();
        Map map = documentChangeRequestReviewForm.getAllOwnerReviews();
        populateCycleList(documentChangeRequestReviewForm,map, selectedCountry);
        String cycleId =   (String)documentChangeRequestReviewForm.getCycles().get(0);
        documentChangeRequestReviewForm.setSelectedCycle(cycleId);
        populateSubCycleList(documentChangeRequestReviewForm,map,selectedCountry,cycleId);
        documentChangeRequestReviewForm.setSelectedSubCycle((String)documentChangeRequestReviewForm.getSubCycles().get(0));
    }

    public void changeCycle(ActionForm form){
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        String selectedCountry = documentChangeRequestReviewForm.getSelectedCountry();
        String selectedCycle =   documentChangeRequestReviewForm.getSelectedCycle();
        Map map = documentChangeRequestReviewForm.getAllOwnerReviews();
        populateSubCycleList(documentChangeRequestReviewForm,map,selectedCountry,selectedCycle);
        documentChangeRequestReviewForm.setSelectedSubCycle((String)documentChangeRequestReviewForm.getSubCycles().get(0));
    }

    public void rePopulateForm(ActionForm form,Owner owner,String idenfier) throws Exception {
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        if (documentChangeRequestReviewForm.isViewAll()==true){
            setNullSelectionCriteria(form);
            if (owner.isIA()==true){
                populateFormForViewAllIA(form,owner);
            }else setViewAllDocChangesNonIA(form,owner);            
        }
        else{
            StringTokenizer stringTokenizer = new StringTokenizer(idenfier,".");

            String selectedPeriod = stringTokenizer.nextToken();
            String selectedCountry = stringTokenizer.nextToken();
            String selectedCycle = stringTokenizer.nextToken();
            String selectedSubCycle = stringTokenizer.nextToken();
            documentChangeRequestReviewForm.setSelectedCountry(selectedCountry);
            documentChangeRequestReviewForm.setSelectedCycle(selectedPeriod+"."+selectedCountry+"."+selectedCycle);
            documentChangeRequestReviewForm.setSelectedSubCycle(selectedPeriod+"."+selectedCountry+"."+selectedCycle+"."+selectedSubCycle);
            //documentChangeRequestReviewForm.setSelectedSubCycle((String)documentChangeRequestReviewForm.getSubCycles().get(0));
            populateForm(documentChangeRequestReviewForm,owner);
        }
    }

    public void populateForm(ActionForm form,Owner owner){
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        Map mapToDispaly = getReveiwRequestDisplayList(documentChangeRequestReviewForm,owner);
        Iterator values = mapToDispaly.values().iterator();
        List myList = new ArrayList();
        while(values.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)values.next();
            myList.add(documentChangeDetails);
        }
        documentChangeRequestReviewForm.setRequestReviewList(myList);
        setIdentifierString(form,owner);
    }

    private void setIdentifierString(ActionForm form,Owner owner){

        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        List tempList = documentChangeRequestReviewForm.getRequestReviewList();

        Iterator iterator = tempList.iterator();
        String docChangeIdentifier ="";

        while(iterator.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)iterator.next();
//            if(documentChangeDetails.getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_OTHER_ACTIVITY)){
//                docChangeIdentifier = documentChangeDetails.getActivityId()+SoxicUtil.getSeperator()+documentChangeDetails.getSourceType()+SoxicUtil.getSeperator()+documentChangeDetails.getRequestType()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_REVIEW+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE+SoxicUtil.getSeperator()+documentChangeDetails.getOcreqResponseId();
//            }else{
//                docChangeIdentifier = documentChangeDetails.getActivityId()+SoxicUtil.getSeperator()+documentChangeDetails.getSourceType()+SoxicUtil.getSeperator()+documentChangeDetails.getRequestType()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_REVIEW+SoxicUtil.getSeperator()+documentChangeDetails.getUpdateModifier()+SoxicUtil.getSeperator()+documentChangeDetails.getOcreqResponseId();
//            }
            docChangeIdentifier = documentChangeDetails.getActivityId()+SoxicUtil.getSeperator()+documentChangeDetails.getSourceType()+SoxicUtil.getSeperator()+documentChangeDetails.getRequestType()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_REVIEW+SoxicUtil.getSeperator()+documentChangeDetails.getUpdateModifier()+SoxicUtil.getSeperator()+documentChangeDetails.getOcreqResponseId();
            documentChangeDetails.setDocChangeIdentifier(docChangeIdentifier);
        }

    }

    public void setViewAllDocChangesIA(ActionForm form, Owner owner) throws NoDocumentChangeListOfActivitiesToReview {
        prePopulateFormforViewAllIA(form,owner);
    }

     public void prePopulateFormforViewAllIA(ActionForm form,Owner owner)throws NoDocumentChangeListOfActivitiesToReview{
            DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
            documentChangeRequestReviewForm.setViewAll(true);
            setNullSelectionCriteria(form);
            Map reviewList = getReveiwRequestList(documentChangeRequestReviewForm,owner);
            if(reviewList.size()>0){
                documentChangeRequestReviewForm.setAllOwnerReviews(reviewList);
                try {
                    populateFormForViewAllIA(form,owner);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else{
                throw new NoDocumentChangeListOfActivitiesToReview();
            }
    }

    private void populateFormForViewAllIA(ActionForm form, Owner owner) throws Exception {
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        OracleDocumentChangeDAO oracleDocumentChangeDAO= (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        Map mapToDispaly = oracleDocumentChangeDAO.selectAllActivitiesForApproval();
        Iterator values = mapToDispaly.values().iterator();
        List myList = new ArrayList();
        while(values.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)values.next();
            myList.add(documentChangeDetails);
        }
        documentChangeRequestReviewForm.setRequestReviewList(myList);
        setIdentifierString(form,owner);
    }

    private void setNullSelectionCriteria(ActionForm form){
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        documentChangeRequestReviewForm.setSelectedCountry("Select");
        documentChangeRequestReviewForm.setSelectedCycle("Select");
        documentChangeRequestReviewForm.setSelectedSubCycle("Select");
    }

    public void setViewAllDocChangesNonIA(ActionForm form, Owner owner) throws Exception {
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        documentChangeRequestReviewForm.setViewAll(true);
        setNullSelectionCriteria(form);
        List subcycleList = new ArrayList();
        Map reviewList = documentChangeRequestReviewForm.getAllOwnerReviews();
        Set activityList = getAllActivitiesForNonIA(reviewList);
        Map nonIAMap = new HashMap();
        Iterator it = activityList.iterator();
        while(it.hasNext()){
            String activityid = (String) it.next();
            subcycleList.add(splitIntoSubCycles(activityid));
        }
        nonIAMap = getnonIAMapWithSubcycles(subcycleList,documentChangeRequestReviewForm,owner);
        populateNonIAList(nonIAMap,form,owner);
    }

    private Map getnonIAMapWithSubcycles(List subcycleList, DocumentChangeRequestReviewForm documentChangeRequestReviewForm, Owner owner) throws Exception {
        Map mapToDisplay = new HashMap();
        OracleDocumentChangeDAO oracleDocumentChangeDAO= (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        OracleSubCycleDAO oracleSubCycleDAO= (OracleSubCycleDAO) AbstractDAOFactory.getFactory().getSubCycleDAO();
        Iterator it = subcycleList.iterator();
        while (it.hasNext()){
        String subcycleID = String.valueOf(it.next());
        if(oracleSubCycleDAO.isSubCycleOwner(owner,subcycleID)){
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_SUBOWN_PER_SUBCYCLE,owner,subcycleID,mapToDisplay);
                }else{
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_ACTOWN_PER_SUBCYCLE,owner,subcycleID,mapToDisplay);
                    oracleDocumentChangeDAO.selectForSubCycle(OracleDocumentChangeDAO.SEL_OTHACTOWN_PER_SUBCYCLE,owner,subcycleID,mapToDisplay);
                }
        }
        return mapToDisplay;
    }


    private Set getAllActivitiesForNonIA(Map reviewList) {
        Set hashSet = new HashSet();
        Iterator iterator = reviewList.values().iterator();

        while(iterator.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)iterator.next();
            hashSet.add(documentChangeDetails.getActivityId());
        }
        return hashSet;
    }

    private String splitIntoSubCycles(String activityid) {
        StringTokenizer stringTokenizer = new StringTokenizer(activityid,".");
        String period = stringTokenizer.nextToken();
        String country = stringTokenizer.nextToken();
        String cycleID = period+"."+country+"."+stringTokenizer.nextToken();
        String subCycleID = cycleID+"."+stringTokenizer.nextToken();
        return subCycleID;
    }

    private void populateNonIAList(Map nonIAMap,ActionForm form, Owner owner){
        DocumentChangeRequestReviewForm documentChangeRequestReviewForm =(DocumentChangeRequestReviewForm)form;
        Iterator values = nonIAMap.values().iterator();
        List myList = new ArrayList();
        while(values.hasNext()){
            DocumentChangeDetails documentChangeDetails = (DocumentChangeDetails)values.next();
            myList.add(documentChangeDetails);
        }
        documentChangeRequestReviewForm.setRequestReviewList(myList);
        setIdentifierString(form,owner);
    }
}
