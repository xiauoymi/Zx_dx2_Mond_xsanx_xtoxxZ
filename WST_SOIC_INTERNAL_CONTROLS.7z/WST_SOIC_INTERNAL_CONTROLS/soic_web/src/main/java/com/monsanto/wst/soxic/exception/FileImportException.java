package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2005
 * Time: 6:26:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileImportException extends Exception{

    public FileImportException(){
		super();
	}

	public FileImportException(Exception e){
		super(e);
	}
}
