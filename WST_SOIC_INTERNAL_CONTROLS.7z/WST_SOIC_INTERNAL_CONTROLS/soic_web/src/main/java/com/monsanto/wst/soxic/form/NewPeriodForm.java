package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionError;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import com.monsanto.wst.soxic.facade.PeriodFacade;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 14, 2005
 * Time: 3:37:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class NewPeriodForm extends ActionForm{


    private String sourcePeriod;
    private String targetPeriod;
    private String description;
    private List newPeriodList;
    private boolean cycleOnlyPeriod;

    public List getNewPeriodList() {
        return newPeriodList;
    }

    public void setNewPeriodList(List newPeriodList) {
        this.newPeriodList = newPeriodList;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSourcePeriod() {
        return sourcePeriod;
    }

    public void setSourcePeriod(String sourcePeriod) {
        this.sourcePeriod = sourcePeriod;
    }

    public String getTargetPeriod() {
        return targetPeriod;
    }

    public void setTargetPeriod(String targetPeriod) {
        this.targetPeriod = targetPeriod;
    }

    public boolean isCycleOnlyPeriod() {
        return cycleOnlyPeriod;
    }

    public void setCycleOnlyPeriod(boolean cycleOnlyPeriod) {
        this.cycleOnlyPeriod = cycleOnlyPeriod;
    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();

        if(targetPeriod==null || targetPeriod.length()==0){
            PeriodFacade periodFacade = new PeriodFacade();
            try{
                periodFacade.getPeriod(this);
            }catch(Exception e){

            }
            errors.add("targetPeriod", new ActionError(
                    "errors.period.blank"));
        }
        if(targetPeriod.indexOf(".")!=-1){
            PeriodFacade periodFacade = new PeriodFacade();
            try{
                periodFacade.getPeriod(this);
            }catch(Exception e){

            }
            
            errors.add("targetPeriod", new ActionError(
                    "errors.period.invalidid"));
        }
        return errors;
    }

}
