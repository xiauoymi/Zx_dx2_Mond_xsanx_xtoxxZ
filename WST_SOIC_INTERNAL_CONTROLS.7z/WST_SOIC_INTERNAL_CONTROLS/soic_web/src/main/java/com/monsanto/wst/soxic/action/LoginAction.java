/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.facade.DashBoardHomeFacade;
import com.monsanto.wst.soxic.form.LoginForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LoginAction extends Action {

    /**
     * Method execute
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response) throws Exception{

        Owner owner=null;

       LoginForm  loginForm = (LoginForm) form;

        try {
        	KerberosSecurity kerberosSecurity = new KerberosSecurity();
        	kerberosSecurity.init(request);
        	String myowner = kerberosSecurity.getUserID();
            owner = generateOwner(myowner);
            request.getSession().setAttribute("owner", owner);
            setTabDisplay(owner,request);
            setSaveIndicator(request);
        } catch (DatabaseException e) {
            e.printStackTrace();
            throw e;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        boolean systemStatus = new DashBoardHomeFacade().checkIfUserIsOwnerInSystem(owner.getOwnerId());
        if (systemStatus){
            return mapping.findForward("home");
        }
        else{
            return mapping.findForward(returnForward(owner));
        }
    }

    private Owner generateOwner(LoginForm form) throws DatabaseException, Exception{

        Owner owner = new Owner(form.getOwnerId().toUpperCase());
        owner.init();
        return owner;

    }

    private Owner generateOwner(String ownerId) throws DatabaseException, Exception{

        Owner owner = new Owner(ownerId.toUpperCase());
        owner.init();
        return owner;

    }

    private String returnForward(Owner owner)throws Exception{
        String forward = "home";

//        if(owner.isActivityCertification()) {
//            if(owner.getActivitySubCycleAssociation()!=null && owner.getActivitySubCycleAssociation().size()>0){
//                return "activity";
//            }
//        }
//
//        if(owner.getSubCycles()!=null && owner.getSubCycles().size()>0){
//            //owner.subCycleTab();
//            return "subcycle";
//        }
//        if(owner.getCycles()!=null && owner.getCycles().size()>0){
//            //owner.cycleTab();
//            return "cycle";
//        }
        if(owner.isViewReports()){
            return "report";
        }
        if(owner.isAdmin()){
            return "admin";
        }
        if(owner.isIA()){
            return "admin";
        }
        if(owner.isIAUser()){
            return "admin";
        }
        if(owner.isDocChangeCertification()){
            return "docchange";
        }
        return forward;
    }

    private void setTabDisplay(Owner owner,HttpServletRequest request){
        if(owner.isActivityCertification())  {
            if(owner.getActivitySubCycleAssociation()!=null && owner.getActivitySubCycleAssociation().size()>0){
                request.getSession().setAttribute(SoxicConstants.ACTIVITYPRESENT,"true");
            }
        }

        if(owner.getSubCycles()!=null && owner.getSubCycles().size()>0){
            request.getSession().setAttribute(SoxicConstants.SUBCYCLEPRESENT,"true");
        }
        if(owner.getCycles()!=null && owner.getCycles().size()>0){
            request.getSession().setAttribute(SoxicConstants.CYCLEPRESENT,"true");
        }
        if(owner.isAdmin()){
            request.getSession().setAttribute(SoxicConstants.ADMIN,"true");
        }
           if(owner.isIA()){
            request.getSession().setAttribute(SoxicConstants.ADMIN,"true");
        }
           if(owner.isIAUser()){
            request.getSession().setAttribute(SoxicConstants.ADMIN,"true");
        }
        if(owner.isViewReports()){
            request.getSession().setAttribute(SoxicConstants.REPORT,"true");
        }
           if(owner.isDocChange()){
        //if(owner.isDocChangeCertification()){
            request.getSession().setAttribute(SoxicConstants.DOCCHANGE_STATE,"true");
        }

    }

    private void setSaveIndicator(HttpServletRequest request){
        request.getSession().setAttribute(SoxicConstants.SAVEINDICATOR,SoxicUtil.getSaveIndicator());
    }

}

