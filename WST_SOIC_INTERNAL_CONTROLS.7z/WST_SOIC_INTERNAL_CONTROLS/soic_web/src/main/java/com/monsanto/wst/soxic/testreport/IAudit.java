package com.monsanto.wst.soxic.testreport;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 11:30:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class IAudit {
    private String auditid;
    private String auditname;
    private String period;
    private String siteid;
    private String sitename;
    private String auditype;
    private String startdate;
    private String enddate;
    private String opinionType;
    private String itWorkPaperStatus;
    private String financeWorkPaperStatus;
    private String financeAvailableUserid;
    private String financeReviewedUserid;
    private String itAvailableUserid;
    private String itReviewedUserid;
    private String financeAvailableDate;
    private String financeReviewedDate;
    private String itAvailableDate;
    private String itReviewedDate;
    private String finalreportDate;
    private List allOpinions;
    private List allFinanceStatus;
    private List allITStatus;
    private List auditTeamObject;
    private String countryid;
    private String countryname;
    private boolean audit_complete;
    private boolean external_view;
    private String followUpDate;
    private String compliedDate;


    public String getAuditid() {
        return auditid;
    }

    public void setAuditid(String auditid) {
        this.auditid = auditid;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSitename() {
        return sitename;
    }

    public void setSitename(String sitename) {
        this.sitename = sitename;
    }

    public String getAuditype() {
        return auditype;
    }

    public void setAuditype(String auditype) {
        this.auditype = auditype;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getOpinionType() {
        return opinionType;
    }

    public void setOpinionType(String opinionType) {
        this.opinionType = opinionType;
    }

    public String getItWorkPaperStatus() {
        return itWorkPaperStatus;
    }

    public void setItWorkPaperStatus(String itWorkPaperStatus) {
        this.itWorkPaperStatus = itWorkPaperStatus;
    }

    public String getFinanceWorkPaperStatus() {
        return financeWorkPaperStatus;
    }

    public void setFinanceWorkPaperStatus(String financeWorkPaperStatus) {
        this.financeWorkPaperStatus = financeWorkPaperStatus;
    }

    public String getFinanceAvailableUserid() {
        return financeAvailableUserid;
    }

    public void setFinanceAvailableUserid(String financeAvailableUserid) {
        this.financeAvailableUserid = financeAvailableUserid;
    }

    public String getFinanceReviewedUserid() {
        return financeReviewedUserid;
    }

    public void setFinanceReviewedUserid(String financeReviewedUserid) {
        this.financeReviewedUserid = financeReviewedUserid;
    }

    public String getItAvailableUserid() {
        return itAvailableUserid;
    }

    public void setItAvailableUserid(String itAvailableUserid) {
        this.itAvailableUserid = itAvailableUserid;
    }

    public String getItReviewedUserid() {
        return itReviewedUserid;
    }

    public void setItReviewedUserid(String itReviewedUserid) {
        this.itReviewedUserid = itReviewedUserid;
    }

    public String getFinanceAvailableDate() {
        return financeAvailableDate;
    }

    public void setFinanceAvailableDate(String financeAvailableDate) {
        this.financeAvailableDate = financeAvailableDate;
    }

    public String getFinanceReviewedDate() {
        return financeReviewedDate;
    }

    public void setFinanceReviewedDate(String financeReviewedDate) {
        this.financeReviewedDate = financeReviewedDate;
    }

    public String getItAvailableDate() {
        return itAvailableDate;
    }

    public void setItAvailableDate(String itAvailableDate) {
        this.itAvailableDate = itAvailableDate;
    }

    public String getItReviewedDate() {
        return itReviewedDate;
    }

    public void setItReviewedDate(String itReviewedDate) {
        this.itReviewedDate = itReviewedDate;
    }

    public String getFinalreportDate() {
        return finalreportDate;
    }

    public void setFinalreportDate(String finalreportDate) {
        this.finalreportDate = finalreportDate;
    }

    public List getAllOpinions() {
        return allOpinions;
    }

    public void setAllOpinions(List allOpinions) {
        this.allOpinions = allOpinions;
    }

    public List getAllFinanceStatus() {
        return allFinanceStatus;
    }

    public void setAllFinanceStatus(List allFinanceStatus) {
        this.allFinanceStatus = allFinanceStatus;
    }

    public List getAllITStatus() {
        return allITStatus;
    }

    public void setAllITStatus(List allITStatus) {
        this.allITStatus = allITStatus;
    }

    public List getAuditTeamObject() {
        return auditTeamObject;
    }

    public void setAuditTeamObject(List auditTeamObject) {
        this.auditTeamObject = auditTeamObject;
    }

    public String getAuditname() {
        return auditname;
    }

    public void setAuditname(String auditname) {
        this.auditname = auditname;
    }

    public String getCountryid() {
        return countryid;
    }

    public void setCountryid(String countryid) {
        this.countryid = countryid;
    }

    public String getCountryname() {
        return countryname;
    }

    public void setCountryname(String countryname) {
        this.countryname = countryname;
    }

    public boolean isAudit_complete() {
        return audit_complete;
    }

    public void setAudit_complete(boolean audit_complete) {
        this.audit_complete = audit_complete;
    }

    public boolean isExternal_view() {
        return external_view;
    }

    public void setExternal_view(boolean external_view) {
        this.external_view = external_view;
    }

    public String getFollowUpDate() {
        return followUpDate;
    }

    public void setFollowUpDate(String followUpDate) {
        this.followUpDate = followUpDate;
    }

    public String getCompliedDate() {
        return compliedDate;
    }

    public void setCompliedDate(String compliedDate) {
        this.compliedDate = compliedDate;
    }

    public IAudit(String auditname, String period, String sitename, String auditype, String countryname) {
        this.auditname = auditname;
        this.period = period;
        this.sitename = sitename;
        this.auditype = auditype;
        this.countryname = countryname;
    }

    public IAudit() {
    }    
}
