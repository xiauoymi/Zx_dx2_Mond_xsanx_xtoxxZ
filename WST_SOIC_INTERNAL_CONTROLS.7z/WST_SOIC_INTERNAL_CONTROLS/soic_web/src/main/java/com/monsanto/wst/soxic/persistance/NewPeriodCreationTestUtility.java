package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 6, 2005
 * Time: 12:15:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class NewPeriodCreationTestUtility {

    public static final String CYCLE_COUNT="CYCLE_COUNT";
    public static final String QUESTION_CYCLE_COUNT="QUESTION_CYCLE_COUNT";
    public static final String CYCLE_OWNER_COUNT="CYCLE_OWNER_COUNT";
    public static final String SUB_CYCLE_COUNT="SUB_CYCLE_COUNT";
    public static final String QUESTION_SUB_CYCLE_COUNT="QUESTION_SUB_CYCLE_COUNT";
    public static final String OWNER_SUB_CYCLE_COUNT="OWNER_SUB_CYCLE_COUNT";
    public static final String CTRL_OBJ_COUNT="CTRL_OBJ_COUNT";
    public static final String ACTIVIYT_COUNT="ACTIVIYT_COUNT";
    public static final String QUESTION_ACTIVITY_COUNT="QUESTION_ACTIVITY_COUNT";
    public static final String OWNER_ACTIVIY_COUNT="OWNER_ACTIVIY_COUNT";
    public static final String CTRL_CODES_COUNT="CTRL_CODES_COUNT";
    public static final String CYCLE_STATE="CYCLE_STATE";

    public int select(String queryType,String identifier){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        int count=0;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(getQuery(queryType,identifier));

            rs = preparedStatement.executeQuery();
            while(rs.next()){
                return rs.getInt("ID_COUNT");
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return count;
    }

    private String getQuery(String type,String identifier){
        if(type.equalsIgnoreCase(CYCLE_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM CYCLE WHERE CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(CYCLE_STATE)){
            return "SELECT COUNT(*) AS ID_COUNT FROM CYCLE_STATE WHERE CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(QUESTION_CYCLE_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM QUESTION_CYCLE WHERE CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(CYCLE_OWNER_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM OWNER_CYCLE WHERE CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(SUB_CYCLE_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(OWNER_SUB_CYCLE_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT  FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(QUESTION_SUB_CYCLE_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM QUESTION_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(CTRL_OBJ_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(ACTIVIYT_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM ACTIVITY WHERE ACTIVITY_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(OWNER_ACTIVIY_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM OWNER_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(QUESTION_ACTIVITY_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+identifier+"%'";
        }
        if(type.equalsIgnoreCase(QUESTION_ACTIVITY_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+identifier+"%'";
        }
       if(type.equalsIgnoreCase(CTRL_CODES_COUNT)){
            return "SELECT COUNT(*) AS ID_COUNT FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID LIKE '%"+identifier+"%'";
        }

        return "";
    }
}
