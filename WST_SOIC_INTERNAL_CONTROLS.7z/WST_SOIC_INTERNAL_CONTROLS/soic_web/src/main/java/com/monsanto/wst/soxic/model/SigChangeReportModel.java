package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 2:13:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class SigChangeReportModel extends SignificantChangeModel implements Comparable{

    private String country;
    private String cycleId;

    public String getCountry() {
        return country;
    }

    public String getCycleId() {
        return cycleId;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }

    public SigChangeReportModel(String seqindex, String selectedType, String selectedPeriod, String amount, String keyContact, String subcycles, String description, String country, String cycleId) {
        super(seqindex, selectedType, selectedPeriod, amount, keyContact, subcycles, description);
        this.country = country;
        this.cycleId = cycleId;
    }

    public SigChangeReportModel() {
    }

    public int compareTo(Object o) {
        if (o instanceof SigChangeReportModel){
            return cycleId.compareTo(((SigChangeReportModel)o).getCycleId());
        }
        return cycleId.compareTo(((SigChangeReportModel)o).getCycleId());
    }
}
