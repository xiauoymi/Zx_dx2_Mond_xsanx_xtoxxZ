package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 18, 2005
 * Time: 5:08:36 PM
 */
public class OwnerAlreadyExistsException extends Exception{
    public OwnerAlreadyExistsException(){
        super();
    }

    public OwnerAlreadyExistsException(Exception e){
        super(e);
    }
}
