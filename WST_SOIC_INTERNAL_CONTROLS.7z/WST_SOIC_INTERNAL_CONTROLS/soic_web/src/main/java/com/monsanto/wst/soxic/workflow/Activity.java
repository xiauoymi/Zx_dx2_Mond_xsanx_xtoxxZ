/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Date;
import java.util.StringTokenizer;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Activity {
	
	private String owner_id;
    private String subCycleId;
	private String activity_id;
	private String status;
	private Date start_date;
	private Date due_date;
	private Date complete_date;
	private Date mod_date;
	private String mod_user;
	private String ownerEmailId;
	private boolean toupdate=false;

	/**
	 * @return Returns the toupdate.
	 */
	public boolean isToupdate() {
		return toupdate;
	}
	/**
	 * @param toupdate The toupdate to set.
	 */
	public void setToupdate(boolean toupdate) {
		this.toupdate = toupdate;
	}
	/**
	 * @return Returns the activity_id.
	 */
	public String getActivity_id() {
		return activity_id;
	}
	/**
	 * @param activity_id The activity_id to set.
	 */
	public void setActivity_id(String activity_id) {
		this.activity_id = activity_id;
	}
	/**
	 * @return Returns the complete_date.
	 */
	public Date getComplete_date() {
		return complete_date;
	}
	/**
	 * @param complete_date The complete_date to set.
	 */
	public void setComplete_date(Date complete_date) {
		this.complete_date = complete_date;
	}
	/**
	 * @return Returns the due_date.
	 */
	public Date getDue_date() {
		return due_date;
	}
	/**
	 * @param due_date The due_date to set.
	 */
	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}

	/**
	 * @return Returns the mod_user.
	 */
	public String getMod_user() {
		return mod_user;
	}
	/**
	 * @param mod_user The mod_user to set.
	 */
	public void setMod_user(String mod_user) {
		this.mod_user = mod_user;
	}
	/**
	 * @return Returns the owner_id.
	 */
	public String getOwner_id() {
		return owner_id;
	}
	/**
	 * @param owner_id The owner_id to set.
	 */
	public void setOwner_id(String owner_id) {
		this.owner_id = owner_id;
	}
	/**
	 * @return Returns the start_date.
	 */
	public Date getStart_date() {
		return start_date;
	}
	/**
	 * @param start_date The start_date to set.
	 */
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the mod_date.
	 */
	public Date getMod_date() {
		return mod_date;
	}
	/**
	 * @param mod_date The mod_date to set.
	 */
	public void setMod_date(Date mod_date) {
		this.mod_date = mod_date;
	}

    public String getOwnerEmailId() {
        return ownerEmailId;
    }

    public void setOwnerEmailId(String ownerEmailId) {
        this.ownerEmailId = ownerEmailId;
    }

    public String getSubCycleId() {
        return subCycleId;
    }

    public void setSubCycleId(String activityIdIn) {
        StringTokenizer stringTokenizer = new StringTokenizer(activityIdIn,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        String currentActivityId= stringTokenizer.nextToken();
        this.subCycleId = period+"."+countryId+"."+cycleId+"."+subCycleId;
    }
}
