package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.model.ControlObjectiveNew;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 19, 2005
 * Time: 8:51:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ControlObjectiveDAO {
//        public void createControlObjective(String sourceControlObjectiveId,String targetSubCycleId,String period)throws Exception{
//
//        Connection con = null;
//		PreparedStatement preparedStatement = null;
//		ResultSet rs=null;
//        ControlObjectiveNew controlObjectiveNew=null;
//       // String query = "SELECT CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK FROM CTRL_OBJ WHERE CTRL_OBJ_ID='"+criteria.get(ControlObjectiveNew.CTRL_OBJ_ID)+"'";
//		try {
//			con = SoxicConnectionFactory.getSoxicConnection();
//			preparedStatement = con.prepareStatement("SELECT CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK FROM CTRL_OBJ WHERE CTRL_OBJ_ID='"+sourceControlObjectiveId+"'");
//			rs = preparedStatement.executeQuery();
//			while(rs.next()){
//               controlObjectiveNew = populateModel(rs);
//			}
//            insertNewControlObjective(controlObjectiveNew,targetSubCycleId);
//            createActivities(sourceControlObjectiveId,targetSubCycleId+"."+controlObjectiveNew.getControlObjectiveCode(),period);
//            //insertSubCycle(subCycle,targetCycleId,period);
//            //createOwnerSubCycle(sourceSubCycleId,targetCycleId+"."+subCycle.getSubCycleCode(),period);
//            //createControlObjectives(sourceSubCycleId,targetCycleId+"."+subCycle.getSubCycleCode(),period);
//
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			//enclose this in a finally block to make
//			//sure the connection is closed
//			try {
//				//con.close();
//				SoxicConnectionFactory.closeResultSet(rs);
//				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
//				SoxicConnectionFactory.closeSoxicConnection(con);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//
//    }
//
//
//       protected ControlObjectiveNew populateModel(ResultSet rs) throws DatabaseException, Exception {
//
//        ControlObjectiveNew controlObjective = new ControlObjectiveNew();
//
//        try {
//
//            controlObjective.setControlObjectiveId(rs.getString(ControlObjectiveNew.CTRL_OBJ_ID));
//            controlObjective.setControlObjectiveCode(rs.getString(ControlObjectiveNew.CTRL_OBJ_CODE));
//            controlObjective.setDescription(rs.getString(ControlObjectiveNew.DESCRIPTION));
//            //controlObjective.setStatus(rs.getString(ControlObjectiveNew.STATUS));
//            controlObjective.setRisk(rs.getString(ControlObjectiveNew.RISK));
//           //controlObjective.setGap(rs.getString(ControlObjectiveNew.POTENTIAL_GAP));
//            //controlObjective.setDeficiency(rs.getString(ControlObjectiveNew.PREV_DEF));
//
//            //controlObjective.setActivities(getActivities(controlObjective.getControlObjectiveId()));
//
//        } catch (SQLException e) {
//            throw new DatabaseException("error while populating ControlObjectiveNew from ResultSet:" + e.toString());
//
//        }
//
//        return controlObjective;
//    }
//
//    private void insertNewControlObjective(ControlObjectiveNew controlObjectiveNew,String targetSubCycleId){
//        Connection connection = null;
//        PreparedStatement preparedStatement=null;
//
//        String query = "INSERT INTO CTRL_OBJ (CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
//
//        try {
//            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement(query);
//
//
//            preparedStatement.setString(1,targetSubCycleId+"."+controlObjectiveNew.getControlObjectiveCode());
//            preparedStatement.setString(2,controlObjectiveNew.getControlObjectiveCode());
//            preparedStatement.setString(3,targetSubCycleId);
//            preparedStatement.setString(4,controlObjectiveNew.getDescription());
//            preparedStatement.setString(5,controlObjectiveNew.getRisk());
//            preparedStatement.setString(6,SoxicConstants.GREEN_COMPLETE);
//            preparedStatement.setDate(7,new Date(System.currentTimeMillis()));
//            preparedStatement.setString(8,"ADMIN");
//
//
//            int result = preparedStatement.executeUpdate();
//        }
//        catch (SQLException e) {
//            //throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        catch (Exception e) {
//            // throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            try {
//                if (preparedStatement != null)
//                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
////                throw new DatabaseException("OracleDAO - Unable to close database connection : "
////                        + e.toString());
//            }
//        }
//    }
//
//           public void createActivities(String sourceControlObjectiveId,String targetControlObjectiveId,String period){
//       Connection connection = null;
//        PreparedStatement preparedStatement=null;
//        ResultSet rs=null;
//        ActivityDAO activityDAO = new ActivityDAO();
//
//
//        String query = "SELECT ACTIVITY_ID FROM ACTIVITY A WHERE CTRL_OBJ_ID=?";
//
//        try {
//            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setString(1,sourceControlObjectiveId);
//            rs = preparedStatement.executeQuery();
//            while(rs.next()){
//                activityDAO.createActivity(rs.getString("ACTIVITY_ID"),targetControlObjectiveId,period);
//                //controlObjectiveDAO.createControlObjective(rs.getString("CTRL_OBJ_ID"),targetSubCycleId,period);
//            }
//        }
//        catch (SQLException e) {
//            //throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        catch (Exception e) {
//            // throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            try {
//                if (preparedStatement != null)
//                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
////                throw new DatabaseException("OracleDAO - Unable to close database connection : "
////                        + e.toString());
//            }
//        }
//    }



}
