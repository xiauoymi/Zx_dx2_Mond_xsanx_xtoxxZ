/*
 * Created on Mar 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.exception.*;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.sql.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author vrbethi
 * @author rgeorge
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UtilDAO {

    private static final String DATE_FORMAT = "MM/dd/yyyy";

    public List getIAOwnerWrapper(){
		List ownerWrapperList= new ArrayList();
		OwnerWrapper ownerWrapper=null;
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        String emailAddress="";
        Set hashSet = new HashSet();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT O.EMAIL,O.NAME FROM OWNER O,OWNER_ROLE ORL WHERE O.OWNER_ID=ORL.OWNER_ID AND ORL.ROLE_ID=?");
            preparedStatement.setString(1,SoxicConstants.DOC_CHANGE_ROLE_IA);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                emailAddress = rs.getString("EMAIL");
                if(hashSet.add(emailAddress)){
                    ownerWrapper = new OwnerWrapper();
                    ownerWrapper.setEmailid(emailAddress);
                    ownerWrapper.setOwnerName(rs.getString("NAME"));
                    ownerWrapperList.add(ownerWrapper);
                }
            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
        return ownerWrapperList;
    }

    /**
	 * Method get upper level id for the identifier
	 * @return
	 */
	public String getUpperLevel(String level,String identifier)throws Exception{
		
		String upperLevel="";

		Connection connection = null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement selectStatus = connection
					.prepareStatement(getUpperLevel(level));

			selectStatus.setString(1, identifier);

			ResultSet rs = selectStatus.executeQuery();

			while (rs.next()) {
				upperLevel=rs.getString("IDENTIFIER");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return upperLevel;
	}
	
	public List getUpperLevelOwnerWrapperList(String level,String identifier)throws Exception{
		
		List ownerWrapperList= new ArrayList();
		OwnerWrapper ownerWrapper=null;
		Connection connection = null;
        Set hashSet = new HashSet();


		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement selectStatus = connection
					.prepareStatement(getUpperLevelOwnerWrapper(level));

			selectStatus.setString(1, identifier);

			ResultSet rs = selectStatus.executeQuery();

			while (rs.next()) {
                if(hashSet.add(rs.getString("EMAIL"))){
				    ownerWrapper = new OwnerWrapper();
				    ownerWrapper.populate(rs);
				    ownerWrapperList.add(ownerWrapper);
                }
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapperList;
		
	}
	
	public List getLevelOwnerWrapperList(String level,String identifier)throws Exception{
		
		List ownerWrapperList= new ArrayList();
		OwnerWrapper ownerWrapper=null;
		Connection connection = null;
		

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement selectStatus = connection
					.prepareStatement(getLevelOwnerWrapper(level));

			selectStatus.setString(1, identifier);

			ResultSet rs = selectStatus.executeQuery();

			while (rs.next()) {
				ownerWrapper = new OwnerWrapper();
				//ownerWrapper.populate(rs);
				ownerWrapper.setOwnerid(rs.getString("OWNER_ID"));
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setLevel(level);
				ownerWrapperList.add(ownerWrapper);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapperList;
		
	}	
	
	/**
	 * Returns the update query for the level
	 * 
	 * @param level
	 * @return Query
	 */
	private String getUpperLevel(String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = SoxicUtil.getQuery("subcycle.upper.level");
		}


		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = SoxicUtil.getQuery("activity.upper.level");
		}
		return query;
	}
	
	/**
	 * Returns the update query for the level
	 * 
	 * @param level
	 * @return Query
	 */
	private String getUpperLevelOwnerWrapper(String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = SoxicUtil.getQuery("subcycle.upper.level.ownerwrapper");
		}


		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = SoxicUtil.getQuery("activity.upper.level.ownerwrapper");
		}
		return query;
	}
	
	/**
	 * Returns the update query for the level
	 * 
	 * @param level
	 * @return Query
	 */
	private String getLevelOwnerWrapper(String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = SoxicUtil.getQuery("subcycle.current.level.ownerwrapper");
		}


		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = SoxicUtil.getQuery("cycle.current.level.ownerwrapper");
		}
		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "SELECT O.EMAIL,O.NAME,O.OWNER_ID FROM OWNER O,OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID = ? AND OA.OWNER_ID=O.OWNER_ID";
		}
		return query;
	}	
	
	public String getPeriod()throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("SELECT PERIOD_ID FROM CYCLE ORDER BY PERIOD_ID");
			resultset = preparedStatement.executeQuery();
			while(resultset.next()){
				return resultset.getString("PERIOD_ID");
			}

		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}
		
		return "";
	}
	
	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public String getEmailAddress(String ownerid)throws Exception{
		
		String emailid="";
		
		Connection con = null;
		PreparedStatement getEmailAddress = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getEmailAddress = con.prepareStatement("SELECT O.EMAIL FROM OWNER O WHERE O.OWNER_ID=?");
			
			getEmailAddress.setString(1,ownerid);
						
			rs = getEmailAddress.executeQuery();
			
			while(rs.next()){
				emailid = rs.getString("EMAIL");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getEmailAddress);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return emailid;
	}
	
	
	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getActivityStartOwnerWrapper(String ownerid)throws Exception{
		
		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT DISTINCT O.EMAIL,O.NAME,CO.SUB_CYCLE_ID,OA.DUE_DATE FROM ACTIVITY A,OWNER_ACTIVITY OA,CTRL_OBJ CO,OWNER O WHERE OA.OWNER_ID =? AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND O.OWNER_ID=OA.OWNER_ID");
			
			getOwnerWrapper.setString(1,ownerid);
						
			ResultSet rs = getOwnerWrapper.executeQuery();
			
			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){
					
					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}
					
				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
					}				
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getStatusChangeOwnerWrapper(String ownerid)throws Exception{

		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT DISTINCT O.EMAIL,O.NAME,CO.SUB_CYCLE_ID,OA.DUE_DATE FROM ACTIVITY A,OWNER_ACTIVITY OA,CTRL_OBJ CO,OWNER O WHERE OA.OWNER_ID =? AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND O.OWNER_ID=OA.OWNER_ID AND OA.STATUS<>'G_COMPLETE'");

			getOwnerWrapper.setString(1,ownerid);

			ResultSet rs = getOwnerWrapper.executeQuery();

			while(rs.next()){
                if(rs.getDate("DUE_DATE")!=null){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){

					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}

				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
					}
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
                }

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getActivityDetailsForOwnerWhoseStartDateIsToday(String ownerid)throws Exception{

		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT DISTINCT O.EMAIL,O.NAME,CO.SUB_CYCLE_ID,OA.DUE_DATE FROM ACTIVITY A,OWNER_ACTIVITY OA,CTRL_OBJ CO,OWNER O WHERE OA.OWNER_ID =? AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND O.OWNER_ID=OA.OWNER_ID AND OA.START_DATE=?");

			getOwnerWrapper.setString(1,ownerid);
			getOwnerWrapper.setDate(2,new Date(System.currentTimeMillis()));

			ResultSet rs = getOwnerWrapper.executeQuery();

			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){

					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}

				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
					}
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getSubCycleStartOwnerWrapper(String ownerid)throws Exception{
		
		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.DUE_DATE,O.EMAIL,O.NAME FROM OWNER_SUB_CYCLE OSC,OWNER O WHERE OSC.OWNER_ID=? AND O.OWNER_ID=OSC.OWNER_ID");
			
			getOwnerWrapper.setString(1,ownerid);
						
			rs = getOwnerWrapper.executeQuery();
			
			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){
					
					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}
					
				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
					}				
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getSubCycleStartOwnerWrapperOnlyIncompleteOnes(String ownerid)throws Exception{

		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.DUE_DATE,O.EMAIL,O.NAME FROM OWNER_SUB_CYCLE OSC,OWNER O WHERE OSC.OWNER_ID=? AND O.OWNER_ID=OSC.OWNER_ID AND OSC.START_DATE=?");

			getOwnerWrapper.setString(1,ownerid);
			getOwnerWrapper.setDate(2,new Date(System.currentTimeMillis()));

			rs = getOwnerWrapper.executeQuery();

			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){

					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}

				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
					}
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getCycleStartOwnerWrapper(String ownerid)throws Exception{
		
		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,OC.DUE_DATE,O.EMAIL,O.NAME FROM OWNER_CYCLE OC,SUB_CYCLE SC,OWNER O WHERE OC.OWNER_ID =? AND O.OWNER_ID=OC.OWNER_ID AND OC.CYCLE_ID=SC.CYCLE_ID");
			
			getOwnerWrapper.setString(1,ownerid);

			rs = getOwnerWrapper.executeQuery();
			
			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){
					
					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}
					
				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						if(ownerWrapper.getDateString().indexOf(tempDate)<0){
							ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
						}
					}				
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapper;
	}

	/**
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public OwnerWrapper getCycleStartOwnerWrapperStartDateToday(String ownerid)throws Exception{

		//String emailid="";
		Connection con = null;
		OwnerWrapper ownerWrapper = new OwnerWrapper();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getOwnerWrapper = con.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,OC.DUE_DATE,O.EMAIL,O.NAME FROM OWNER_CYCLE OC,SUB_CYCLE SC,OWNER O WHERE OC.OWNER_ID =? AND O.OWNER_ID=OC.OWNER_ID AND OC.CYCLE_ID=SC.CYCLE_ID AND OC.START_DATE=?");

			getOwnerWrapper.setString(1,ownerid);
			getOwnerWrapper.setDate(2,new Date(System.currentTimeMillis()));

			rs = getOwnerWrapper.executeQuery();

			while(rs.next()){
				if(ownerWrapper.getSubCycleString()==null || ownerWrapper.getSubCycleString().length()==0){

					ownerWrapper.setSubCycleString(rs.getString("SUB_CYCLE_ID"));
				}else{
					if(ownerWrapper.getSubCycleString().indexOf(rs.getString("SUB_CYCLE_ID"))<0){
						ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+rs.getString("SUB_CYCLE_ID"));
					}

				}
				if(rs.getString("DUE_DATE")!=null){
					String tempDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("DUE_DATE"));
					if(ownerWrapper.getDateString()==null || ownerWrapper.getDateString().length()==0){
						ownerWrapper.setDateString(tempDate);
					}else{
						if(ownerWrapper.getDateString().indexOf(tempDate)<0){
							ownerWrapper.setDateString(ownerWrapper.getDateString()+", "+tempDate);
						}
					}
				}
				ownerWrapper.setEmailid(rs.getString("EMAIL"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return ownerWrapper;
	}

	/**
	 * Returns a map of owner warpper objects with the owner id as the key for the upper level
	 * who's start date is the current date
	 * @param level
	 * @return
	 * @throws Exception
	 */
	public Map getStartDateUpperLevelOwnerWrapper(String level) throws Exception{
		Connection con = null;
		Map ownerWrapperMap = new HashMap();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
				getOwnerWrapper = con.prepareStatement("SELECT DISTINCT OSC.SUB_CYCLE_ID,O.EMAIL,O.OWNER_ID FROM OWNER_ACTIVITY OA,ACTIVITY A,CTRL_OBJ CO,OWNER_SUB_CYCLE OSC,OWNER O WHERE OA.START_DATE=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND CO.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND O.OWNER_ID=OSC.OWNER_ID");
			}else{
				getOwnerWrapper = con.prepareStatement("SELECT DISTINCT OC.CYCLE_ID,O.EMAIL,O.OWNER_ID FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,OWNER_CYCLE OC,OWNER O WHERE OSC.START_DATE=? AND SC.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND SC.CYCLE_ID=OC.CYCLE_ID AND O.OWNER_ID=OC.OWNER_ID");
			}
			
			
			getOwnerWrapper.setDate(1,new Date(System.currentTimeMillis()));
						
			rs = getOwnerWrapper.executeQuery();
			
			while(rs.next()){
				
				populateSubCycleOwnerWrapperMap(rs,ownerWrapperMap,level);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
				//con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapperMap;		
	}
	
	/**
	 * Returns a map of owner warpper objects with the owner id as the key for the upper level
	 * who's due date is past due and certification has not been completed yet.
	 * @param level
	 * @return
	 * @throws Exception
	 */
	public Map getOverDueUpperLevelOwnerWrapper(String level) throws Exception{
		Connection con = null;
		Map ownerWrapperMap = new HashMap();
		PreparedStatement getOwnerWrapper = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
				getOwnerWrapper = con.prepareStatement("SELECT DISTINCT OSC.SUB_CYCLE_ID,O.EMAIL,O.OWNER_ID FROM OWNER_ACTIVITY OA,ACTIVITY A,CTRL_OBJ CO,OWNER_SUB_CYCLE OSC,OWNER O WHERE OA.DUE_DATE<? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND CO.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND O.OWNER_ID=OSC.OWNER_ID AND OA.STATUS <> 'G_COMPLETE'");
			}else{
				getOwnerWrapper = con.prepareStatement("SELECT DISTINCT OC.CYCLE_ID,O.EMAIL,O.OWNER_ID FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,OWNER_CYCLE OC,OWNER O WHERE OSC.DUE_DATE<? AND SC.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND SC.CYCLE_ID=OC.CYCLE_ID AND O.OWNER_ID=OC.OWNER_ID AND OSC.STATUS <> 'G_COMPLETE'");
			}
			
			
			getOwnerWrapper.setDate(1,new Date(System.currentTimeMillis()));
						
			rs = getOwnerWrapper.executeQuery();
			
			while(rs.next()){
				
				populateSubCycleOwnerWrapperMap(rs,ownerWrapperMap,level);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getOwnerWrapper);
				SoxicConnectionFactory.closeSoxicConnection(con);
				//con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return ownerWrapperMap;		
	}
	
	public void populateSubCycleOwnerWrapperMap(ResultSet resultSet,Map ownerWrapperMap,String level) throws Exception{
		OwnerWrapper ownerWrapper=null;
		
		if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
			if(ownerWrapperMap.get(resultSet.getString("OWNER_ID"))==null){
				
				ownerWrapper = new OwnerWrapper();
				ownerWrapper.setEmailid(resultSet.getString("EMAIL"));
				ownerWrapper.setOwnerid(resultSet.getString("OWNER_ID"));
				ownerWrapper.setSubCycleString(resultSet.getString("SUB_CYCLE_ID"));
				
				ownerWrapperMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
			}else{
				
				ownerWrapper = (OwnerWrapper)ownerWrapperMap.get(resultSet.getString("OWNER_ID"));
				ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+resultSet.getString("SUB_CYCLE_ID"));
			}
		}else{
			if(ownerWrapperMap.get(resultSet.getString("OWNER_ID"))==null){
				
				ownerWrapper = new OwnerWrapper();
				ownerWrapper.setEmailid(resultSet.getString("EMAIL"));
				ownerWrapper.setOwnerid(resultSet.getString("OWNER_ID"));
				ownerWrapper.setSubCycleString(resultSet.getString("CYCLE_ID"));
				
				ownerWrapperMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
			}else{
				
				ownerWrapper = (OwnerWrapper)ownerWrapperMap.get(resultSet.getString("OWNER_ID"));
				ownerWrapper.setSubCycleString(ownerWrapper.getSubCycleString()+", "+resultSet.getString("CYCLE_ID"));
			}			
		}

		
	}
	
	/**
	 * Returns a list of FAQ's
	 * @return
	 * @throws Exception
	 */
	public List getFAQ()throws Exception{
		
		int counter=1;
		
		List faqList = new ArrayList();
		
		Connection con = null;
		PreparedStatement getFaq = null;
		ResultSet rs=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getFaq = con.prepareStatement("SELECT * from FAQ");
						
			rs = getFaq.executeQuery();
			
			while(rs.next()){
				FAQ faq = new FAQ();
				faq.setQuestion(rs.getString("QUESTION"));
				faq.setAnswer(rs.getString("DESCRIPTION"));
				faq.setCounter(counter);
				faqList.add(faq);
				counter++;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getFaq);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return faqList;
	}
	
	/**
	 * Returns a list of Countries avaliable
	 * @return
	 * @throws Exception
	 */
	public List getCountries(String periodIn)throws Exception{
		List countryList = new ArrayList();		
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null,rs1=null;
		HashMap hashMap = new HashMap();
		LinkedList linkedList = new LinkedList();
		List orderedList = new ArrayList();

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			preparedStatement = con.prepareStatement("SELECT COUNTRY_ID,CYCLE_ID from CYCLE WHERE PERIOD_ID=?");
			preparedStatement.setString(1,periodIn);
						
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				if(hashMap.put(rs.getString("COUNTRY_ID"),rs.getString("CYCLE_ID"))==null){
					StringTokenizer st = new StringTokenizer(rs.getString("CYCLE_ID"),".");
					String period = st.nextToken();
					String countryId = st.nextToken();
					String cycleid = st.nextToken();
					countryList.add(countryId);
				}
				
			}
			
			preparedStatement = con.prepareStatement("SELECT NAME FROM LOOKUP WHERE TYPE='COUNTRYID' ORDER BY SEQUENCE");
			rs1 = preparedStatement.executeQuery();
			while(rs1.next()){
				//linkedList.add(rs1.getString("NAME"));
				if(countryList.contains(rs1.getString("NAME"))){
					orderedList.add(rs1.getString("NAME"));
				}
				
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return orderedList;
		//return countryList;
	}
	
	/**
	 * Returns a list for percentage completion for the country list passed
	 * @param level
	 * @param countryList
	 * @return
	 * @throws Exception
	 */
	public List getPercentageCompletion(String level,List countryList,String period)throws Exception{
		List percentageCompletion = new ArrayList();		
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			
			
			for(int i=0;i<countryList.size();i++)
			{
				int size=0,complete=0;
				preparedStatement = con.prepareStatement(getPercentageCompletionQuery(level,(String)countryList.get(i),period));
				//preparedStatement.setString(1,(String)countryList.get(i));
				rs = preparedStatement.executeQuery();

                while (rs.next()) {
                    size++;
                    if (SoxicConstants.GREEN_COMPLETE.equalsIgnoreCase(rs.getString("STATUS"))) {
                        complete++;
                    }
                }
				double percentage = ((double)complete/(double)size)*100;
				int intval=0;
				if(percentage < 1 && percentage!=0){
					intval = 1;
				}else{
					intval = (int)percentage;
				}
				
				percentageCompletion.add(""+intval);
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return percentageCompletion;		
	}
	
	/**
	 * Returns a list for due date for the country list passed
	 * @param level
	 * @param countryList
	 * @return
	 * @throws Exception
	 */
	public List getDueDate(String level,List countryList,String period)throws Exception{
		List dueDate = new ArrayList();		
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		Date date = null;
	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			
			for(int i=0;i<countryList.size();i++)
			{
				preparedStatement = con.prepareStatement(getDueDateQuery(level,(String)countryList.get(i),period));
				rs = preparedStatement.executeQuery();
				while(rs.next()){
					date = rs.getDate("DUE_DATE");
				}
				if(date!=null){
					dueDate.add(""+date.getMonth()+"/"+date.getDay());
				}else{
					dueDate.add("");
				}
				
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return dueDate;		
	}
	
	/**
	 *This method returns cycle list for the period. 
	 *
	 * @return
	 */
	public List getCycleList(String period)throws Exception{
		
		List cycleList = new ArrayList();
		HashSet hashSet = new HashSet();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		Date date = null;
	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			//preparedStatement = con.prepareStatement("SELECT DISTINCT CYCLE_CODE FROM CYCLE C,LOOKUP L WHERE L.TYPE='CURRENT_ACTIVE_PERIOD' AND L.VALUE=C.PERIOD_ID");
			preparedStatement = con.prepareStatement("SELECT CYCLE_CODE FROM CYCLE C WHERE C.PERIOD_ID=?");
			preparedStatement.setString(1,period);
			
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				//cycleList.add(rs.getString("CYCLE_CODE"));
				hashSet.add(rs.getString("CYCLE_CODE"));
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		cycleList.addAll(hashSet);
		return cycleList;				
	}
	
	/**
	 * This method sets the number of control objectives for the current period , Country
	 * @param countrySummary
	 * @throws Exception
	 */
	public void setNumberOfControlObjectives(CountrySummary countrySummary)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		Date date = null;
	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT COUNT(*) AS NUM_CTRL FROM CTRL_OBJ CO WHERE CO.CTRL_OBJ_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"%'");
			//preparedStatement.setString(1,countrySummary.getCountryName());
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				countrySummary.setNumberOfControlObjectives(rs.getInt("NUM_CTRL"));
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}				
	}
	
	/**
	 * This method sets the number of activities for the current period and Country
	 * @param countrySummary
	 * @throws Exception
	 */
	public void setNumberOfActivities(CountrySummary countrySummary)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		Date date = null;
	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT COUNT(*) AS NUM_ACT FROM ACTIVITY A WHERE A.ACTIVITY_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"%'");
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				countrySummary.setNumberOfActivities(rs.getInt("NUM_ACT"));
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}				
	}
	
	/**
	 * This method returns activity owners for the current period and Country
	 * @param countrySummary
	 * @return
	 * @throws Exception
	 */
	public HashSet setNumberOfActivityOwners(CountrySummary countrySummary)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		HashSet hashSet = new HashSet();	
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT OA.OWNER_ID FROM OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"%'");
			//preparedStatement.setString(1,countrySummary.getCountryName());
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				hashSet.add(rs.getString("OWNER_ID"));
			}

			countrySummary.setNumberOfOwners(hashSet.size());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
		return hashSet;
	}
	
	/**
	 * This method returns subcycle owners for the current period and Country
	 * @param countrySummary
	 * @param hashSet
	 * @return
	 * @throws Exception
	 */
	public HashSet setNumberOfSubCycleOwners(CountrySummary countrySummary,HashSet hashSet)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC WHERE OSC.SUB_CYCLE_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"%'");
			//preparedStatement.setString(1,countrySummary.getCountryName());
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				hashSet.add(rs.getString("OWNER_ID"));
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return hashSet;
	}
	
	/**
	 * This method sets the precentage completion for Country and for each cycle
	 * @param countrySummary
	 * @param cycleList
	 * @throws Exception
	 */
	public void setOverAllPercentageCompletion(CountrySummary countrySummary,List cycleList)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		List statusList=null;
		
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			Iterator iterator = cycleList.iterator();
			
			while(iterator.hasNext()){
				statusList = new ArrayList();
				int count=0;
				String cycleId = (String)iterator.next();
				preparedStatement = con.prepareStatement("SELECT A.STATUS FROM ACTIVITY A WHERE A.ACTIVITY_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"."+cycleId+"%'");
				
				//preparedStatement.setString(1,countrySummary.getCountryName());
				rs = preparedStatement.executeQuery();
				
				while(rs.next()){
					statusList.add(rs.getString("STATUS"));
				}
				
				preparedStatement = con.prepareStatement("SELECT SC.STATUS FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"."+cycleId+"%'");
				
				//preparedStatement.setString(1,countrySummary.getCountryName());
				rs = preparedStatement.executeQuery();
				
				while(rs.next()){
					statusList.add(rs.getString("STATUS"));
				}
				
				preparedStatement = con.prepareStatement("SELECT C.STATUS FROM CYCLE C WHERE C.CYCLE_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"."+cycleId+"%'");
				
				//preparedStatement.setString(1,countrySummary.getCountryName());
				rs = preparedStatement.executeQuery();
				
				while(rs.next()){
					statusList.add(rs.getString("STATUS"));
				}
				
				if(statusList.size()==0){
					countrySummary.addProgressPercentage("-");
				}else{
					Iterator statusIterator = statusList.iterator();
					
					while(statusIterator.hasNext()){
						
						if(((String)statusIterator.next()).equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
							count++;
						}
					}
					
					double percentage = ((double)count/(double)statusList.size())*100;
					countrySummary.addProgressPercentage(""+(int)percentage);
				}

				
				
			}
			

		
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	}
	
	public String getCurrentActivePeriod()throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		String currentActivePeriond="";
		
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT L.VALUE FROM LOOKUP L WHERE L.TYPE='CURRENT_ACTIVE_PERIOD'");
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				currentActivePeriond = rs.getString("VALUE");
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return currentActivePeriond;		
	}
	
	/**
	 * This method returns cycle owners for the current period and Country
	 * @param countrySummary
	 * @param hashSet
	 * @return
	 * @throws Exception
	 */
	public HashSet setNumberOfCycleOwners(CountrySummary countrySummary,HashSet hashSet)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT OC.OWNER_ID FROM OWNER_CYCLE OC WHERE OC.CYCLE_ID LIKE '%"+countrySummary.getPeriod()+"."+countrySummary.getCountryName()+"%'");
			//preparedStatement.setString(1,countrySummary.getCountryName());
			rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				hashSet.add(rs.getString("OWNER_ID"));
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return hashSet;
	}
	
	/**
	 * Returns percentage completion query
	 * 
	 * @param level
	 * @return Query
	 */
	private String getPercentageCompletionQuery(String level,String country,String period) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT STATUS FROM SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+period+"."+country+"%'";
		}
		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "SELECT STATUS FROM ACTIVITY WHERE ACTIVITY_ID LIKE '%"+period+"."+country+"%'";
		}	
		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT STATUS FROM CYCLE WHERE CYCLE_ID LIKE '%"+period+"."+country+"%'";
		}
		return query;
	}
	
	/**
	 * Returns due date query
	 * 
	 * @param level
	 * @return Query
	 */
	private String getDueDateQuery(String level,String country,String period) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT MAX(DUE_DATE) AS DUE_DATE FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+period+"."+country+"%'";
		}
		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "SELECT MAX(DUE_DATE) AS DUE_DATE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+period+"."+country+"%'";
		}	
		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT MAX(DUE_DATE) AS DUE_DATE FROM OWNER_CYCLE WHERE CYCLE_ID LIKE '%"+period+"."+country+"%'";
		}
		return query;
	}

	public List getOverDueOwnersPerSubCycleOwner(String subCycleOwnerId)throws Exception{
		List ownerDuePerSubCycleOwner = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		OwnerWrapper ownerWrapper=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT DISTINCT O.NAME FROM OWNER_SUB_CYCLE OSC,CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA,OWNER O WHERE OSC.OWNER_ID=? AND CO.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND OA.STATUS <>'G_COMPLETE' AND OA.DUE_DATE < ? AND O.OWNER_ID=OA.OWNER_ID");
			preparedStatement.setString(1,subCycleOwnerId);
			preparedStatement.setDate(2,new Date(System.currentTimeMillis()));
			rs = preparedStatement.executeQuery();

			while(rs.next()){
				ownerWrapper = new OwnerWrapper();
				//ownerWrapper.setDateString(rs.getString("DUE_DATE"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
				ownerDuePerSubCycleOwner.add(ownerWrapper);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}


		return ownerDuePerSubCycleOwner;
	}

	public List getOverDueOwnersPerCycleOwner(String cycleOwnerId)throws Exception{
		List ownerDuePerSubCycleOwner = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		OwnerWrapper ownerWrapper=null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = con.prepareStatement("SELECT DISTINCT O.NAME FROM OWNER_CYCLE OC,SUB_CYCLE SC,OWNER_SUB_CYCLE OSC,OWNER O WHERE OC.OWNER_ID=? AND SC.CYCLE_ID=OC.CYCLE_ID AND OSC.SUB_CYCLE_ID=SC.SUB_CYCLE_ID AND OSC.DUE_DATE<? AND OSC.STATUS <> 'G_COMPLETE' AND O.OWNER_ID = OSC.OWNER_ID");
			preparedStatement.setString(1,cycleOwnerId);
			preparedStatement.setDate(2,new Date(System.currentTimeMillis()));
			rs = preparedStatement.executeQuery();

			while(rs.next()){
				ownerWrapper = new OwnerWrapper();
				//ownerWrapper.setDateString(rs.getString("DUE_DATE"));
				ownerWrapper.setOwnerName(rs.getString("NAME"));
				ownerDuePerSubCycleOwner.add(ownerWrapper);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}


		return ownerDuePerSubCycleOwner;
	}
    
       /**
	 * Returns a list of Countries based on 4 states - INITIATED, RELEASED, LOCKED, PRE-CERTIFY
	 * @return List
	 * @throws Exception
	 */
	public List getCountriesforCycleManage()throws Exception{
		List countryList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT DISTINCT C.COUNTRY_ID from CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC WHERE C.CYCLE_ID = CS.CYCLE_ID AND C.CYCLE_ID = SC.CYCLE_ID AND (CS.STATE=? OR CS.STATE=? OR CS.STATE=? OR CS.STATE=?)");
                preparedStatement.setString(1, SoxicConstants.CYCLE_STATE);
                preparedStatement.setString(2,SoxicConstants.CYCLE_STATE_RELEASE);
                preparedStatement.setString(3,SoxicConstants.CYCLE_STATE_LOCK);
                preparedStatement.setString(4,SoxicConstants.CYCLE_STATE_PRECERTIFY);

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    countryList.add(rs.getString("COUNTRY_ID"));
				}
            if (countryList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return countryList;
		//return countryList;
	}


    /**
     * This method retrieves countries which are in INITAITED state
     * @return List
     * @throws Exception
     */
    public List getCountriestodelete()throws Exception{
		List countryList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT DISTINCT C.COUNTRY_ID from CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC WHERE C.CYCLE_ID = CS.CYCLE_ID AND C.CYCLE_ID = SC.CYCLE_ID AND CS.STATE = ?");
                preparedStatement.setString(1, SoxicConstants.CYCLE_STATE);

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    countryList.add(rs.getString("COUNTRY_ID"));
				}
            if (countryList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return countryList;
		//return countryList;
	}


    /**
     * Returns a list of cycles based on the country
     * @param countryid
     * @return List
     * @throws Exception
     */
    public List getCyclesfromCountry(String countryid)throws Exception{
		List cycleList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT DISTINCT C.CYCLE_ID FROM CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC WHERE C.CYCLE_ID = CS.CYCLE_ID AND C.CYCLE_ID = SC.CYCLE_ID AND C.COUNTRY_ID = ? AND CS.STATE = ?");
                preparedStatement.setString(1,countryid);
                preparedStatement.setString(2,SoxicConstants.CYCLE_STATE);

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    cycleList.add(rs.getString("CYCLE_ID"));
				}
//            if (cycleList.size()==0){
//                throw new NullAndArrayIndexException(new Exception());
//            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cycleList;
		//return cycleList;
	}

    /**
     * Returns a list of sub-cycles based on INITIATED state and the
     * cycle selected
     * @param cycleid
     * @return List
     * @throws Exception
     */
    public List getSubCyclesfromCycles(String cycleid)throws Exception{
		List subcycleList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT sc.sub_cycle_id FROM sub_cycle sc,cycle_state cs WHERE sc.CYCLE_ID = cs.CYCLE_ID AND sc.cycle_id=? and CS.STATE=? order by sc.sub_cycle_id ASC");
			    preparedStatement.setString(1,cycleid);
                preparedStatement.setString(2,SoxicConstants.CYCLE_STATE);

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    subcycleList.add(rs.getString("SUB_CYCLE_ID"));
				}
//            if (subcycleList.size()==0){
//                throw new NullAndArrayIndexException(new Exception());
//            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subcycleList;
		//return subcycleList;
	}


        /**
         * Deletes the sub-cycles based on the user selection
         * @param subcycleid
         * @throws Exception
         */
        public int deleteSubcycles(String subcycleid)throws Exception{

            Connection con = null;
            PreparedStatement preparedStatement = null;
            ResultSet rs = null;
            int count = 0;

            try {
                    con = SoxicConnectionFactory.getSoxicConnection();

                    preparedStatement = con.prepareStatement("DELETE FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subcycleid+"%'");
                    int question_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID LIKE '%"+subcycleid+"%'");
                    int ctrl_obj_codes = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM QUESTION_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subcycleid+"%'");
                    int question_sub_cycle = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subcycleid+"%'");
                    int owner_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subcycleid+"%'");
                    int owner_sub_cycle = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subcycleid+"%'");
                    int activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%"+subcycleid+"%'");
                    int ctrl_obj = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subcycleid+"%'");
                    int sub_cycle = preparedStatement.executeUpdate();

                 count = question_activity+ctrl_obj_codes+question_sub_cycle+owner_activity+owner_sub_cycle+activity+ctrl_obj+sub_cycle;

                } catch (SQLException e) {
                    e.printStackTrace();
                    SoxicConnectionFactory.rollback(con);
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);
                } finally {
                //enclose this in a finally block to make
                //sure the connection is closed
                try {
                    //con.close();
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        return count;
        }

    /**
     * Returns a list of cycles & other data from cycle_state table based on the country
     * and state is INITIATED, RELEASED, LOCKED and PRE_CERTIFICATION
     * @param countryid
     * @return List
     * @throws Exception
     */
    public List getCycleStatefromCountry(String countryid)throws Exception{
        CycleMaintainObject cmo;
		List cyclemaintainList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT DISTINCT CS.CYCLE_ID,CS.STATE,CS.BEGIN_DATE,CS.END_DATE FROM CYCLE C,CYCLE_STATE CS WHERE C.CYCLE_ID = CS.CYCLE_ID AND C.COUNTRY_ID=? AND (CS.STATE=? OR CS.STATE=? OR CS.STATE=? OR CS.STATE=?) ORDER BY CS.STATE");
                preparedStatement.setString(1,countryid);
                preparedStatement.setString(2, SoxicConstants.CYCLE_STATE);
                preparedStatement.setString(3,SoxicConstants.CYCLE_STATE_RELEASE);
                preparedStatement.setString(4,SoxicConstants.CYCLE_STATE_LOCK);
                preparedStatement.setString(5,SoxicConstants.CYCLE_STATE_PRECERTIFY);                

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    cmo = new CycleMaintainObject();
                    cmo.setCycle(rs.getString("CYCLE_ID"));
                    cmo.setState(rs.getString("STATE"));
                    if ((cmo.getState().equalsIgnoreCase(SoxicConstants.CYCLE_STATE_LOCK)) || (cmo.getState().equalsIgnoreCase(SoxicConstants.CYCLE_STATE_PRECERTIFY))){
                        cmo.setStatus("DISABLE");
                    }
                    if ((rs.getDate("BEGIN_DATE")!=null) && (rs.getDate("END_DATE")!=null))
                    {
                        cmo.setBegin_date(df.format(rs.getDate("BEGIN_DATE")));
                        cmo.setEnd_date(df.format(rs.getDate("END_DATE")));
                    }

                    cyclemaintainList.add(cmo);
				}
            if (cyclemaintainList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }

		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cyclemaintainList;
	}

    /**
     * Sets the state to RELEASED for cycleids and dates selected
     * @throws Exception
     */
    public void setReleaseState(String cycleid, String state, String begin_date, String end_date, boolean docrelease)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String sdate = begin_date;
        String edate = end_date;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET STATE=?, BEGIN_DATE=?, END_DATE=? WHERE CYCLE_ID=?");
                if (docrelease){
			        preparedStatement.setString(1, SoxicConstants.CYCLE_STATE_RELEASE);
                }
//                if ((!docrelease) && (state.equals(SoxicConstants.CYCLE_STATE))){
//                    preparedStatement.setString(1, SoxicConstants.CYCLE_STATE);
//                }else
//                if ((!docrelease) && (!state.equals(SoxicConstants.CYCLE_STATE))){
//                    preparedStatement.setString(1, state);
//                }

            try {
                    Date b_date = new Date(df.parse(sdate).getTime());
                    Date e_date = new Date(df.parse(edate).getTime());

                    String st_date = (df.format((b_date)));
                    String ed_date = (df.format((e_date)));

                    if ((!st_date.equals(sdate)) || (!ed_date.equals(edate))){
                        throw new DateFormatException(new Exception("Date Format is Incorrect"));
                    }

                    if ((e_date.after(b_date)) || (e_date.equals(b_date))){
                        preparedStatement.setDate(2, b_date);
                        preparedStatement.setDate(3, e_date);
                    }
                    else throw new DateSequenceException(new Exception("Date Sequence is Incorrect"));
                }catch (ParseException e){
                throw new IncorrectDateException(new Exception("Incorrect Date Entered"));
            }

                preparedStatement.setString(4, cycleid);

                int n = preparedStatement.executeUpdate();
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

    /**
     * Sets the state to LOCKED for cycleids that are selected to be locked
     * @throws Exception
     */
    public void setLockedState(String cycleid, String state, String begin_date, String end_date, boolean locked)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String sdate = begin_date;
        String edate = end_date;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET STATE=?, BEGIN_DATE=?, END_DATE=? WHERE CYCLE_ID=?");
                if (locked){
			        preparedStatement.setString(1,SoxicConstants.CYCLE_STATE_LOCK);
                }

            try {
                    Date b_date = new Date(df.parse(sdate).getTime());
                    Date e_date = new Date(df.parse(edate).getTime());

                    String st_date = (df.format((b_date)));
                    String ed_date = (df.format((e_date)));

                    if ((!st_date.equals(sdate)) || (!ed_date.equals(edate))){
                        throw new DateFormatException(new Exception("Date Format is Incorrect"));
                    }

                    if ((e_date.after(b_date)) || (e_date.equals(b_date))){
                        preparedStatement.setDate(2, b_date);
                        preparedStatement.setDate(3, e_date);
                    }
                    else throw new DateSequenceException(new Exception("Date Sequence is Incorrect"));
                }catch (ParseException e){
                    throw new IncorrectDateException(new Exception("Incorrect Date Entered"));
                }
                preparedStatement.setString(4, cycleid);

                int n = preparedStatement.executeUpdate();
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

    /**
     * Sets the state to PRE_CERTIFICATION for cycleids that are already locked
     * @throws Exception
     */
    public void setPreCertifyState(String cycleid)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			        con = SoxicConnectionFactory.getSoxicConnection();
                    preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET STATE=? WHERE CYCLE_ID=?");
			        preparedStatement.setString(1,SoxicConstants.CYCLE_STATE_PRECERTIFY);
                    preparedStatement.setString(2, cycleid);

                System.out.print("UPDATE REACHED");
                int n = preparedStatement.executeUpdate();
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

    /**
     * contains method to forward to PRE_CERTIFICATION directly
     * if there no requests, or based on the type of request (ADD/MODIFY/REMOVE)
     * forward to the respective method
     * @param activityid
     * @throws Exception
     */
    public boolean checkIApproved(String activityid) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        boolean status = false;

		try {
			        con = SoxicConnectionFactory.getSoxicConnection();
                    preparedStatement = con.prepareStatement
                            ("SELECT DISTINCT A.ACTIVITY_ID,OCR.APPROVED,OWR.REQ_TYPE " +
                            "FROM OWNER_CHANGE_REQUEST OWR, " +
                            "OCREQ_RESPONSE OCR, " +
                            "ACTIVITY A " +
                            "WHERE OCR.OCREQ_ID = OWR.OCREQ_ID " +
                            "AND A.ACTIVITY_ID = OWR.TARGET_ID " +
                            "AND OCR.RESP_TYPE = 'IA' " +
                            "AND OCR.APPROVED = 'Y' " +
                            "AND A.ACTIVITY_ID = ?");
			        preparedStatement.setString(1, activityid);

            rs= preparedStatement.executeQuery();
              while (rs.next()){
                        status = true;
                    }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
//                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return status;
    }

    public boolean add_question_Precertify(String activityid, String priority) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        Owner owner = new Owner();
        String ownerid = owner.getOwnerId();
        Date tdate = new Date(System.currentTimeMillis());

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("INSERT INTO QUESTION_ACTIVITY VALUES (?,?,?,?)");
                preparedStatement.setInt(1, 1);
                preparedStatement.setString(2, activityid);
                preparedStatement.setDate(3,tdate);
                preparedStatement.setString(4,"rg");
                preparedStatement.executeUpdate();

                preparedStatement = con.prepareStatement("INSERT INTO QUESTION_ACTIVITY VALUES (?,?,?,?)");
                preparedStatement.setInt(1, 2);
                preparedStatement.setString(2, activityid);
                preparedStatement.setDate(3,tdate);
                preparedStatement.setString(4,"rg");
                preparedStatement.executeUpdate();

                preparedStatement = con.prepareStatement("UPDATE ACTIVITY SET PRIORITY = ? WHERE ACTIVITY_ID = ?");
                preparedStatement.setString(1, priority);
                preparedStatement.setString(2, activityid);
                preparedStatement.executeUpdate();

		    } catch (SQLException e) {
			    e.printStackTrace();
                return false;
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
                return false;
			}
		}

        return true;
    }

    /**
     * updates the activity requested and then calls the method to perform
     * PRE_CERTIFICATION
     * @param activityid
     * @param request_text
     * @return
     * @throws Exception
     */
    public boolean add_modify_PreCertify(String activityid, String request_text, String priority)throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("UPDATE ACTIVITY SET DESCRIPTION=?, PRIORITY=? WHERE ACTIVITY_ID=?");
                preparedStatement.setString(1, request_text);
                preparedStatement.setString(2, priority);
                preparedStatement.setString(3, activityid);

                int n = preparedStatement.executeUpdate();
		    } catch (SQLException e) {
			    e.printStackTrace();
                return false;
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
                return false;
			}
		}

        return true;
    }

        public boolean addModifyPreCertify(String activityid, String request_text, String priority, int overflow)throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
               // int overflow = getOverflowFromOwnerChangeRequest(activityid, con);
                preparedStatement = con.prepareStatement("UPDATE ACTIVITY SET DESCRIPTION=?, PRIORITY=?, OVERFLOW_ID=? WHERE ACTIVITY_ID=?");
                preparedStatement.setString(1, request_text);
                preparedStatement.setString(2, priority);
                preparedStatement.setInt(3, overflow);
                preparedStatement.setString(4, activityid);
                rs = preparedStatement.executeQuery();
            } catch (SQLException e) {
			    e.printStackTrace();
                return false;
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
                SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
                return false;
			}
		}

        return true;
    }

    /**
     * Removes the requested activity and then forwards to the method
     * to perform PRE_CERTIFICATION
     * @param activityid
     * @param ctrl_obj_id
     * @return
     * @throws Exception
     */
    public boolean remove_PreCertify(String activityid, String ctrl_obj_id) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        int controlobjcount = 0;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();

                preparedStatement = con.prepareStatement("SELECT COUNT(*) AS COUNT FROM ACTIVITY WHERE CTRL_OBJ_ID = ?");
                preparedStatement.setString(1, ctrl_obj_id);
                rs = preparedStatement.executeQuery();
                while(rs.next()){
				     controlobjcount = (rs.getInt("COUNT"));
			    }

                if (controlobjcount > 1) {
                    preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int ctrl_codes = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int owner_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int question_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int activity = preparedStatement.executeUpdate();
                }
                else
                {
                    preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ_CODES WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int ctrl_codes = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int owner_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int question_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM CTRL_OBJ WHERE CTRL_OBJ_ID = ?");
                    preparedStatement.setString(1, ctrl_obj_id);
                    int ctrl_obj = preparedStatement.executeUpdate();
                }
                } catch (SQLException e) {
                    e.printStackTrace();
                    SoxicConnectionFactory.rollback(con);
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);
                    return false;
                } finally {
                //enclose this in a finally block to make
                //sure the connection is closed
                try {
                    //con.close();
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
        return true;
    }


    /**
     * selects the cycles that are in INITIATED and RELEASED states only
     * based on the country
     * @param countryid
     * @throws Exception
     */
    public List getCountriesInitiated(String countryid) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        List cyclemaintainList = new ArrayList();

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT DISTINCT CS.CYCLE_ID,CS.STATE,CS.BEGIN_DATE,CS.END_DATE FROM CYCLE C,CYCLE_STATE CS WHERE C.CYCLE_ID = CS.CYCLE_ID AND C.COUNTRY_ID=? AND (CS.STATE=? OR CS.STATE=?) ORDER BY CS.STATE");
                preparedStatement.setString(1,countryid);
                preparedStatement.setString(2, SoxicConstants.CYCLE_STATE);
                preparedStatement.setString(3, SoxicConstants.CYCLE_STATE_RELEASE);

                rs = preparedStatement.executeQuery();

                while(rs.next()){
                        cyclemaintainList.add(rs.getString("CYCLE_ID"));
                }
            if (cyclemaintainList.size()==0){
                throw new NoInitiatedCycleException();
            }
        }
        catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
        }

        return cyclemaintainList;
    }

    /**
     * sets the Start & End dates for the cycles selected
     * @param cycleid
     * @param b_date
     * @param e_date
     * @throws Exception
     */
    public void putDatesInCycles(String cycleid,Date b_date,Date e_date) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET BEGIN_DATE=?, END_DATE=? WHERE CYCLE_ID=?");

                        preparedStatement.setDate(1, b_date);
                        preparedStatement.setDate(2, e_date);
                        preparedStatement.setString(3, cycleid);

                preparedStatement.executeUpdate();

		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }

    public void setInitiateState(String cycleid, String state, String begin_date, String end_date)throws Exception{
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String sdate = begin_date;
        String edate = end_date;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("UPDATE CYCLE_STATE SET STATE=?, BEGIN_DATE=?, END_DATE=? WHERE CYCLE_ID=?");
			        preparedStatement.setString(1,state);

            try {
                    Date b_date = new Date(df.parse(sdate).getTime());
                    Date e_date = new Date(df.parse(edate).getTime());

                    String st_date = (df.format((b_date)));
                    String ed_date = (df.format((e_date)));

                    if ((!st_date.equals(sdate)) || (!ed_date.equals(edate))){
                        throw new DateFormatException(new Exception("Date Format is Incorrect"));
                    }

                    if ((e_date.after(b_date)) || (e_date.equals(b_date))){
                        preparedStatement.setDate(2, b_date);
                        preparedStatement.setDate(3, e_date);
                    }
                    else throw new DateSequenceException(new Exception("Date Sequence is Incorrect"));
                }catch (ParseException e){
                    throw new IncorrectDateException(new Exception("Incorrect Date Entered"));
                }
                preparedStatement.setString(4, cycleid);

                int n = preparedStatement.executeUpdate();
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
//                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


//    public boolean checkIANotApproved(String cycleid) throws Exception{
//        Connection con = null;
//		PreparedStatement preparedStatement = null;
//		ResultSet rs = null;
//        String activityid = null;
//        boolean status = false;
//
//		try {
//			        con = SoxicConnectionFactory.getSoxicConnection();
//                    preparedStatement = con.prepareStatement
//                            ("SELECT A.ACTIVITY_ID, OWR.REQ_TYPE, OWR.REQ_TEXT, A.CTRL_OBJ_ID " +
//                            "  FROM OWNER_CHANGE_REQUEST OWR, " +
//                            "       OCREQ_RESPONSE OCR, " +
//                            "       ACTIVITY A, " +
//                            "       CTRL_OBJ CO, " +
//                            "       SUB_CYCLE SC, " +
//                            "       CYCLE C, " +
//                            "       CYCLE_STATE CS " +
//                            " WHERE OCR.OCREQ_ID = OWR.OCREQ_ID " +
//                            "   AND A.ACTIVITY_ID = OWR.TARGET_ID " +
//                            "   AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
//                            "   AND SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID " +
//                            "   AND C.CYCLE_ID = SC.CYCLE_ID " +
//                            "   AND CS.CYCLE_ID = C.CYCLE_ID " +
//                            "   AND OCR.RESP_TYPE = 'IA' " +
//                            "   AND OCR.APPROVED = 'N' " +
//                            "   AND CS.CYCLE_ID = ? AND CS.STATE = ?");
//			        preparedStatement.setString(1, cycleid);
//                    preparedStatement.setString(2, SoxicConstants.CYCLE_STATE_LOCK);
//
//            rs= preparedStatement.executeQuery();
//
//            while (rs.next()){
//                        activityid = rs.getString("ACTIVITY_ID");
//                        status = true;
//                    }
//
//            if (status){
//                remove_IANotApproved(activityid);
//            }
//
//            } catch (SQLException e) {
//			    e.printStackTrace();
//		    } finally {
//			//enclose this in a finally block to make
//			//sure the connection is closed
//			try {
//				//con.close();
//				SoxicConnectionFactory.closeResultSet(rs);
//				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
////                con.commit();
//				SoxicConnectionFactory.closeSoxicConnection(con);
//
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//
//        return status;
//    }


    public void remove_IANotApproved(String activityid) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();

                    preparedStatement = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int question_activity = preparedStatement.executeUpdate();

                    preparedStatement = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID = ?");
                    preparedStatement.setString(1, activityid);
                    int activity = preparedStatement.executeUpdate();

                } catch (SQLException e) {
                    e.printStackTrace();
                    SoxicConnectionFactory.rollback(con);
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);

                } finally {
                //enclose this in a finally block to make
                //sure the connection is closed
                try {
                    //con.close();
                    SoxicConnectionFactory.closeResultSet(rs);
                    SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                    SoxicConnectionFactory.closeSoxicConnection(con);
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }
    }

    public List getIApprovedCycles(String cycleid) throws Exception{
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        DocPublishObject dpo;
		List docpublishlist = new ArrayList();
        String type = null;
        HashSet set = new HashSet();

		try {
			        con = SoxicConnectionFactory.getSoxicConnection();
                    preparedStatement = con.prepareStatement
                            ("SELECT A.ACTIVITY_ID, OWR.REQ_TYPE, OCR.APPROVED, OWR.REQ_TEXT, OWR.OVERFLOW_ID, A.CTRL_OBJ_ID, OWR.PRIORITY " +
                            "FROM OWNER_CHANGE_REQUEST OWR, " +
                            "OCREQ_RESPONSE OCR, " +
                            "ACTIVITY A, " +
                            "CTRL_OBJ CO, " +
                            "SUB_CYCLE SC, " +
                            "CYCLE C, " +
                            "CYCLE_STATE CS " +
                            "WHERE OCR.OCREQ_ID = OWR.OCREQ_ID " +
                            "AND A.ACTIVITY_ID = OWR.TARGET_ID " +
                            "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                            "AND SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID " +
                            "AND C.CYCLE_ID = SC.CYCLE_ID " +
                            "AND CS.CYCLE_ID = C.CYCLE_ID " +
                            "AND OCR.RESP_TYPE = 'IA' " +
                            "AND (OCR.APPROVED = 'N' OR OCR.APPROVED = 'Y') " +
                            "AND CS.CYCLE_ID = ? AND CS.STATE = ? ORDER BY OCR.RESP_DATE DESC ");
			        preparedStatement.setString(1, cycleid);
                    preparedStatement.setString(2, SoxicConstants.CYCLE_STATE_LOCK);

                rs= preparedStatement.executeQuery();

                while (rs.next()){
                    dpo = new DocPublishObject();
                    type = rs.getString("REQ_TYPE");
                    if ((type.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)) || (type.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE))){
                        //if (rs.getString("APPROVED").equalsIgnoreCase("Y")){
                            //if (set.add(rs.getString("ACTIVITY_ID"))){
                                dpo.setActivity_id(rs.getString("ACTIVITY_ID"));
                                dpo.setReq_type(rs.getString("REQ_TYPE"));
                                dpo.setDoc_text(rs.getString("REQ_TEXT"));
                                dpo.setCobj_id(rs.getString("CTRL_OBJ_ID"));
                                dpo.setPriority(rs.getString("PRIORITY"));
                                dpo.setOverflow_Id(rs.getInt("OVERFLOW_ID"));
                                String approved = rs.getString("APPROVED");
                                if(approved.equalsIgnoreCase("Y")){
                                    dpo.setApproved(true);
                                }else{
                                    dpo.setApproved(false);
                                }
                                docpublishlist.add(dpo);
                            //}
                        //}
                    }else if (type.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                                dpo.setActivity_id(rs.getString("ACTIVITY_ID"));
                                dpo.setReq_type(rs.getString("REQ_TYPE"));
                                dpo.setDoc_text(rs.getString("REQ_TEXT"));
                                dpo.setCobj_id(rs.getString("CTRL_OBJ_ID"));
                                dpo.setPriority(rs.getString("PRIORITY"));
                                String approved = rs.getString("APPROVED");
                                if(approved.equalsIgnoreCase("Y")){
                                    dpo.setApproved(true);
                                }else{
                                    dpo.setApproved(false);
                                }
                        docpublishlist.add(dpo);
                    }
                }
            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
//                con.commit();
				SoxicConnectionFactory.closeSoxicConnection(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return docpublishlist;
    }

  public List<String> getOwnerSubCycleStatus(String subCycleId) {
    Connection conn = null;
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    List<String> ownerSubCycleStatusList = new ArrayList<String>();
    try {
      conn = SoxicConnectionFactory.getSoxicConnection();
      preparedStatement = conn.prepareStatement("SELECT OSC.STATUS FROM OWNER_SUB_CYCLE OSC WHERE SUB_CYCLE_ID = ?");
      preparedStatement.setString(1, subCycleId);
      rs = preparedStatement.executeQuery();
      while (rs.next()) {
        ownerSubCycleStatusList.add(rs.getString("STATUS"));
      }

    } catch (Exception e) {

    } finally {
      try {
        SoxicConnectionFactory.closeResultSet(rs);
        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
        SoxicConnectionFactory.closeSoxicConnection(conn);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return ownerSubCycleStatusList;
  }
}
