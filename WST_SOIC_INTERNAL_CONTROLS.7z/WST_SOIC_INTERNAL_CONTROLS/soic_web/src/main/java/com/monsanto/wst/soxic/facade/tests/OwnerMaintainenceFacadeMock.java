package com.monsanto.wst.soxic.facade.tests;

import com.monsanto.wst.soxic.facade.OwnerMaintainenceFacade;


/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 16, 2005
 * Time: 10:08:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerMaintainenceFacadeMock extends OwnerMaintainenceFacade{


}
