package com.monsanto.wst.soxic.audit;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 10:00:05 AM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@NoDeleteAllowed
@Table(schema = "SARBOX_ET",name = "SUB_CYCLE")
public class SubCycleObj implements Serializable{

  @Id
  @Column(name = "SUB_CYCLE_ID")
  private String subCycleId;

  @Column(name = "SUB_CYCLE_CODE")
  private String subCycleCode;
  
  @Column(name = "CYCLE_ID",insertable = false,updatable = false)
  private String cycleId;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "STATUS")
  private String status;

  @Column(name = "OVERFLOW_ID",nullable = true)
  private Integer overFlowId;

  @Column(name = "POTENTIAL_GAP")
  private String gap;


  @Column(name = "PREV_DEF")
  private String  deficiency ;

  @OneToMany(mappedBy = "subCycle",fetch = FetchType.LAZY,targetEntity = ControlObjectiveObj.class)
   private List<ControlObjectiveObj> controlObjectives = new ArrayList<ControlObjectiveObj>();

  @OneToMany(mappedBy = "subCycleId",targetEntity = OwnerSubCycleObj.class,fetch = FetchType.LAZY)
  private List<OwnerSubCycleObj> owner = new ArrayList<OwnerSubCycleObj>();

  @ManyToOne
  @JoinColumn(name = "CYCLE_ID")
  private CycleObj cycle;

   public String getSubCycleCode() {
    return subCycleCode;
  }

  public void setSubCycleCode(String subCycleCode) {
    this.subCycleCode = subCycleCode;
  }


  public String getCycleId() {
    return cycleId;
  }

  public void setCycleId(String cycleId) {
    this.cycleId = cycleId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public Integer getOverFlowId() {
    return overFlowId;
  }

  public void setOverFlowId(Integer overFlowId) {
    this.overFlowId = overFlowId;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }
  public String getDeficiency() {
    return deficiency;
  }

  public void setDeficiency(String deficiency) {
    this.deficiency = deficiency;
  }

  public List<OwnerSubCycleObj> getOwner() {
    return owner;
  }

  public void setOwner(List<OwnerSubCycleObj> owner) {
    this.owner = owner;
  }

  public String getSubCycleId() {
    return subCycleId;
  }

  public void setSubCycleId(String subCycleId) {
    this.subCycleId = subCycleId;
  }

  public List<ControlObjectiveObj> getControlObjectives() {
    return controlObjectives;
  }

  public void setControlObjectives(List<ControlObjectiveObj> controlObjectives) {
    this.controlObjectives = controlObjectives;
  }

  public CycleObj getCycle() {
    return cycle;
  }

  public void setCycle(CycleObj cycle) {
    this.cycle = cycle;
  }
}

