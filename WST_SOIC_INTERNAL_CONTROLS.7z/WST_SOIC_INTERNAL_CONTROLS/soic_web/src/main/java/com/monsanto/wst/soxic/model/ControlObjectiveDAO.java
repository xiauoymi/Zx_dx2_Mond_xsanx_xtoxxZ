/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class ControlObjectiveDAO {

	public static void main(String[] args) {
	}

	/**
	 * Method returns a list of control objectives for the sub-cycle id and owner
	 * @param subcycleId
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public static List getAllControlObjectives(String subcycleId, String ownerid)
			throws Exception {
		
		List controlObjectives = new ArrayList();
		Connection con = null;
		PreparedStatement retrieveControlObjectiveList=null;
		ResultSet rs=null;
		int maxStatus = 0;
		java.util.Date minDate = null;
        java.util.Date minStartDate = null;
		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			retrieveControlObjectiveList = con
					.prepareStatement("SELECT CO.CTRL_OBJ_ID,CO.DESCRIPTION,CO.SUB_CYCLE_ID,CO.RISK,CO.PREV_DEF,CO.OVERFLOW_ID,OA.OWNER_ID,OA.STATUS,OA.START_DATE,OA.DUE_DATE,Q.QUESTION,Q.QUESTION_ID,A.ACTIVITY_ID,A.DESCRIPTION DESC1,A.OVERFLOW_ID OVF1,Q.ACT_ANS_TYPE,L.VALUE,D.DESCRIPTION DESC2 FROM CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA,QUESTION_ACTIVITY QA,QUESTION Q,LOOKUP L,DEF_REF D WHERE  CO.SUB_CYCLE_ID=? AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND Q.QUESTION_ID=QA.QUESTION_ID AND QA.ACTIVITY_ID = A.ACTIVITY_ID AND L.TYPE='STATUS' AND L.NAME=OA.STATUS AND CO.CTRL_OBJ_ID=D.OBJ_COMPOSITE_ID(+) ORDER BY CO.CTRL_OBJ_ID,A.ACTIVITY_ID,L.VALUE,Q.QUESTION_ID");

			retrieveControlObjectiveList.setString(1, subcycleId);

			rs = retrieveControlObjectiveList.executeQuery();

			String currentObjId = null;
			Question q = null;
			ControlObjective controlObjective = null;
			//String activityOldId = null;
			int questionCounter = 0;
			int activityCounter = 0;
			Activity activity = null;
			String rsownerid = null;
			String status = null;

			while (rs.next()) {
				questionCounter++;

				String controlObjectiveId = rs.getString("CTRL_OBJ_ID");

				if (currentObjId == null) {
					currentObjId = controlObjectiveId;
					controlObjective = new ControlObjective();
				} else {
					if (!currentObjId.equalsIgnoreCase(controlObjectiveId)) {
						if (controlObjective.getStatus() == null) {
							controlObjective.setStatus(new Status(
									Status.COMPLETE));
						}
						controlObjectives.add(controlObjective);
						controlObjective = new ControlObjective();
						currentObjId = controlObjectiveId;
						maxStatus = 0;
						minDate = null;
					}
				}

				//set the control objective properties
				controlObjective.setControlObjectiveId(controlObjectiveId);
				controlObjective.setControlObjectiveDescription(rs
						.getString("DESCRIPTION"));
				controlObjective.setPreviousDef(rs.getString("PREV_DEF"));

				if (rs.getDate("DUE_DATE") != null) {
					java.util.Date tempdate = rs.getDate("DUE_DATE");
					if (minDate == null) {
						minDate = tempdate;

					}
					if (minDate != null && minDate.after(tempdate)) {
						minDate = tempdate;
					}
					//String temp = DateFormat.getDateInstance(DateFormat.MEDIUM)
					//		.format(minDate);
					controlObjective
							.setControlObjectiveDate(DateFormat
									.getDateInstance(DateFormat.MEDIUM).format(
											minDate));
				}

                if (rs.getDate("START_DATE") != null) {
					java.util.Date tempstartDate = rs.getDate("START_DATE");
					if (minStartDate == null) {
						minStartDate = tempstartDate;
					}
					if (minStartDate != null && minStartDate.after(tempstartDate)) {
						minStartDate = tempstartDate;
					}
					controlObjective.setStartDate((Date) minStartDate);
				}
				controlObjective.setRisk(rs.getString("RISK"));
				controlObjective.setOverFlowId(rs.getString("OVERFLOW_ID"));
				controlObjective.addDeficiencyToList(rs.getString("DESC2"));
				//String id = rs.getString("SUB_CYCLE_ID");

				//owner id for activity
				rsownerid = rs.getString("OWNER_ID");
				if (rs.getInt("VALUE") > maxStatus
						&& rsownerid.equalsIgnoreCase(ownerid)) {
					maxStatus = rs.getInt("VALUE");
					status = rs.getString("STATUS");
					controlObjective.setStatus(new Status(status));
				}

				//String question = rs.getString("QUESTION");

                q = new Question();
				q.setQuestionId(rs.getString("QUESTION_ID"));
				q.setDescription(rs.getString("QUESTION"));
				q.setCounter(questionCounter);
				q.setActualAnsType(rs.getString("ACT_ANS_TYPE"));

				if (q.getActualAnsType().equalsIgnoreCase(
						SoxicConstants.ASSIGNEDACTIVITY)) {
					controlObjective.addQuestionToHash(q);
				} else {
					controlObjective.addQuestionToHash(q);
				}

				//String activityId = rs.getString("ACTIVITY_ID");

				activityCounter++;
				activity = new Activity();
				activity.setCounter(activityCounter);
				activity.setDescription(rs.getString("DESC1"));
				activity.setActivityId(rs.getString("ACTIVITY_ID"));
				activity.setDueDate(rs.getDate("DUE_DATE"));
				activity.setStatus(rs.getString("STATUS"));
				activity.setOverFlowId(rs.getString("OVF1"));

				if (rsownerid.equalsIgnoreCase(ownerid)) {
					controlObjective.addAssignedActivityToMap(activity);
				} else {
					controlObjective.addRemainingActivityToMap(activity);
				}
			}

			controlObjectives.add(controlObjective);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(retrieveControlObjectiveList);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return controlObjectives;
	}

    	/**
	 * Method returns a list of control objectives for the sub-cycle id and owner
	 * @param subcycleId
	 * @return
	 * @throws Exception
	 */
	public static List getAllControlObjectives(String subcycleId)
			throws Exception {

		List controlObjectives = new ArrayList();
		Connection con = null;
		PreparedStatement retrieveControlObjectiveList=null;
		ResultSet rs=null;
		int maxStatus = 0;
		java.util.Date minDate = null;
		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			retrieveControlObjectiveList = con
					.prepareStatement("SELECT CO.CTRL_OBJ_ID,CO.DESCRIPTION,CO.SUB_CYCLE_ID,CO.RISK,CO.PREV_DEF,CO.OVERFLOW_ID,OA.OWNER_ID,OA.STATUS,OA.DUE_DATE,Q.QUESTION,Q.QUESTION_ID,A.ACTIVITY_ID,A.DESCRIPTION DESC1,A.OVERFLOW_ID OVF1,Q.ACT_ANS_TYPE,L.VALUE,D.DESCRIPTION DESC2 FROM CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA,QUESTION_ACTIVITY QA,QUESTION Q,LOOKUP L,DEF_REF D WHERE  CO.SUB_CYCLE_ID=? AND A.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND Q.QUESTION_ID=QA.QUESTION_ID AND QA.ACTIVITY_ID = A.ACTIVITY_ID AND L.TYPE='STATUS' AND L.NAME=OA.STATUS AND CO.CTRL_OBJ_ID=D.OBJ_COMPOSITE_ID(+) ORDER BY CO.CTRL_OBJ_ID,A.ACTIVITY_ID,L.VALUE");

			retrieveControlObjectiveList.setString(1, subcycleId);

			rs = retrieveControlObjectiveList.executeQuery();

			String currentObjId = null;
			Question q = null;
			ControlObjective controlObjective = null;
			//String activityOldId = null;
			int questionCounter = 0;
			int activityCounter = 0;
			Activity activity = null;
			String rsownerid = null;
			String status = null;

			while (rs.next()) {
				questionCounter++;

				String controlObjectiveId = rs.getString("CTRL_OBJ_ID");

				if (currentObjId == null) {
					currentObjId = controlObjectiveId;
					controlObjective = new ControlObjective();
				} else {
					if (!currentObjId.equalsIgnoreCase(controlObjectiveId)) {
						if (controlObjective.getStatus() == null) {
							controlObjective.setStatus(new Status(
									Status.COMPLETE));
						}
						controlObjectives.add(controlObjective);
						controlObjective = new ControlObjective();
						currentObjId = controlObjectiveId;
						maxStatus = 0;
						minDate = null;
					}
				}

				//set the control objective properties
				controlObjective.setControlObjectiveId(controlObjectiveId);
				controlObjective.setControlObjectiveDescription(rs
						.getString("DESCRIPTION"));
				controlObjective.setPreviousDef(rs.getString("PREV_DEF"));

				if (rs.getDate("DUE_DATE") != null) {
					java.util.Date tempdate = rs.getDate("DUE_DATE");
					if (minDate == null) {
						minDate = tempdate;

					}
					if (minDate != null && minDate.after(tempdate)) {
						minDate = tempdate;
					}
					//String temp = DateFormat.getDateInstance(DateFormat.MEDIUM)
					//		.format(minDate);
					controlObjective
							.setControlObjectiveDate(DateFormat
									.getDateInstance(DateFormat.MEDIUM).format(
											minDate));
				}
				controlObjective.setRisk(rs.getString("RISK"));
				controlObjective.setOverFlowId(rs.getString("OVERFLOW_ID"));
				controlObjective.addDeficiencyToList(rs.getString("DESC2"));
				//String id = rs.getString("SUB_CYCLE_ID");

				//owner id for activity
				rsownerid = rs.getString("OWNER_ID");
//				if (rs.getInt("VALUE") > maxStatus
//						&& rsownerid.equalsIgnoreCase(ownerid)) {
//					maxStatus = rs.getInt("VALUE");
//					status = rs.getString("STATUS");
//					controlObjective.setStatus(new Status(status));
//				}

				//String question = rs.getString("QUESTION");

				q = new Question();
				q.setQuestionId(rs.getString("QUESTION_ID"));
				q.setDescription(rs.getString("QUESTION"));
				q.setCounter(questionCounter);
				q.setActualAnsType(rs.getString("ACT_ANS_TYPE"));

				if (q.getActualAnsType().equalsIgnoreCase(
						SoxicConstants.ASSIGNEDACTIVITY)) {
					controlObjective.addQuestionToHash(q);
				} else {
					controlObjective.addQuestionToHash(q);
				}

				//String activityId = rs.getString("ACTIVITY_ID");

				activityCounter++;
				activity = new Activity();
				activity.setCounter(activityCounter);
				activity.setDescription(rs.getString("DESC1"));
				activity.setActivityId(rs.getString("ACTIVITY_ID"));
				activity.setDueDate(rs.getDate("DUE_DATE"));
				activity.setStatus(rs.getString("STATUS"));
				activity.setOverFlowId(rs.getString("OVF1"));

				//if (rsownerid.equalsIgnoreCase(ownerid)) {
					controlObjective.addAssignedActivityToMap(activity);
				//} else {
					//controlObjective.addRemainingActivityToMap(activity);
				//}
			}

			controlObjectives.add(controlObjective);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(retrieveControlObjectiveList);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return controlObjectives;
	}

	public static Map getOverFlowControlObjectiveDescList(String inCondition)
			throws Exception {
		Map controlObjectiveDescriptionOverFlow = new HashMap();
		Connection con = null;
		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement getOverflowCtrlDesc = con
					.prepareStatement("SELECT TOV.SEQUENCE,TOV.TEXT_CHUNK,CO.CTRL_OBJ_ID FROM CTRL_OBJ CO,TEXT_OVERFLOW TOV WHERE CO.CTRL_OBJ_ID IN ("
							+ inCondition
							+ ") AND TOV.OVERFLOW_ID=CO.OVERFLOW_ID");

			ResultSet rs = getOverflowCtrlDesc.executeQuery();
			while (rs.next()) {
				String controlObjectiveId = rs.getString("CTRL_OBJ_ID");
				if (controlObjectiveDescriptionOverFlow.get(controlObjectiveId) == null) {
					controlObjectiveDescriptionOverFlow.put(controlObjectiveId,
							rs.getString("TEXT_CHUNK"));
				} else {
					String firstPart = (String) controlObjectiveDescriptionOverFlow
							.get(controlObjectiveId);
					controlObjectiveDescriptionOverFlow.put(controlObjectiveId,
							firstPart + rs.getString("TEXT_CHUNK"));
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return controlObjectiveDescriptionOverFlow;

	}


	public static boolean isActivityComplete(String ownerid, String activityid)
			throws Exception {

		boolean activityCompleted = false;

		Connection connection = null;

		try {

			//connection = getConnection();
			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement selectStatus = connection
					.prepareStatement("SELECT ORS.STATUS FROM OWNER_RESPONSE ORS,LOOKUP L WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND L.TYPE='STATUS' AND L.NAME=ORS.STATUS ORDER BY L.VALUE DESC");

			selectStatus.setString(1, ownerid);

			selectStatus.setString(2, activityid);

			ResultSet rs = selectStatus.executeQuery();

			while (rs.next()) {

				if (rs.getString("STATUS").equalsIgnoreCase(
						SoxicConstants.GREEN_COMPLETE)) {
					return true;
				} else {
					return false;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return activityCompleted;
	}

	public static List returnDeficiency(String controlObjectiveId)
			throws Exception {
		Connection con = null;
		String description = null;

		List defList = new ArrayList();
		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement getDeficiency = con
					.prepareStatement("SELECT * FROM DEF_REF DR WHERE DR.OBJ_COMPOSITE_ID=?");
			getDeficiency.setString(1, controlObjectiveId);

			ResultSet rs = getDeficiency.executeQuery();
			while (rs.next()) {
				description = rs.getString("DESCRIPTION");
				defList.add(description);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return defList;
	}

	/**
	 * Sets the gap for the Control objective list
	 * @param controlObjectives
	 * @throws Exception
	 */
	public static void getGapMap(List controlObjectives) throws Exception {
		Connection con = null;
		PreparedStatement getGap=null;
		ResultSet rs=null;
		
		String description;
		String type;
		String ctlpart = getQueryString(controlObjectives);

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getGap = con
					.prepareStatement("SELECT A.CTRL_OBJ_ID,ORS.RESPONSE_ID,GDL.DESCRIPTION,GDL.TYPE FROM ACTIVITY A,OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE A.CTRL_OBJ_ID IN ("
							+ ctlpart
							+ ") AND A.ACTIVITY_ID=ORS.ASSOCIATED_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID ORDER BY A.CTRL_OBJ_ID");

			rs = getGap.executeQuery();
			while (rs.next()) {
				description = rs.getString("DESCRIPTION");
				type = rs.getString("TYPE");
				addGap(controlObjectives, type + " --  " + description, rs
						.getString("CTRL_OBJ_ID"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(getGap);
				SoxicConnectionFactory.closeSoxicConnection(con);
				//con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static List getGapForControlObjective(String controlObjectiveId)
			throws Exception {

		ArrayList gapList = new ArrayList();

		Connection con = null;

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement getGap = con
					.prepareStatement("SELECT A.CTRL_OBJ_ID,ORS.RESPONSE_ID,GDL.DESCRIPTION,GDL.TYPE FROM ACTIVITY A,OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE A.CTRL_OBJ_ID=? AND A.ACTIVITY_ID=ORS.ASSOCIATED_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID ORDER BY A.CTRL_OBJ_ID");

			getGap.setString(1, controlObjectiveId);

			ResultSet rs = getGap.executeQuery();
			while (rs.next()) {

				String gap = rs.getString("DESCRIPTION");

				gapList.add(gap);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return gapList;
	}

	public static List getDeficiency(String Id, String level) throws Exception {

		List deficiencyList = new ArrayList();

		Connection con = null;

		PreparedStatement getDeficiency = null;

		String deficiency = "";

		String id = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getDeficiency = con.prepareStatement(getControlObjectiveString(Id,
					level));

			getDeficiency.setString(1, Id);

			ResultSet rs = getDeficiency.executeQuery();
			while (rs.next()) {

				deficiency = rs.getString("DESCRIPTION");

				id = rs.getString("OBJ_COMPOSITE_ID");

				addDeficiency(deficiencyList, id, deficiency);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return deficiencyList;
	}

	public static List getGap(String Id, String level) throws Exception {

		List gapList = new ArrayList();

		Connection con = null;

		PreparedStatement getGap = null;

		String gap = "";

		String id = "";

		String type = "";

		String owner = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getGap = con.prepareStatement(getGapQuery(level));

			getGap.setString(1, Id);

			ResultSet rs = getGap.executeQuery();
			while (rs.next()) {

				gap = rs.getString("DESCRIPTION");

				id = rs.getString("ASSOCIATED_ID");

				type = rs.getString("ASSOCIATED_TYPE");

				owner = rs.getString("OWNER_ID");

				addGapNew(gapList, id, gap, type, owner);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return gapList;
	}

	public static List getOwnerGap(String Id, String level, String ownerid)
			throws Exception {

		List gapList = new ArrayList();

		Connection con = null;

		PreparedStatement getGap = null;

		String gap = "";

		String id = "";

		String type = "";

		String owner = "";

		try {
			//con = getConnection();
			
			con = SoxicConnectionFactory.getSoxicConnection();

			getGap = con.prepareStatement(getGapQuery(level));

			getGap.setString(1, Id);

			getGap.setString(2, ownerid);

			ResultSet rs = getGap.executeQuery();
			while (rs.next()) {

				gap = rs.getString("DESCRIPTION");

				id = rs.getString("ASSOCIATED_ID");

				type = rs.getString("ASSOCIATED_TYPE");

				owner = rs.getString("OWNER_ID");

				addGapNew(gapList, id, gap, type, owner);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return gapList;
	}

	public static String getQueryString(List controlObjectives) {
		String query = "";

		Iterator iterator = controlObjectives.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (query.length() != 0) {

				query = query + ",";
			}

			query = query + "'" + controlObjective.getControlObjectiveId()
					+ "'";

		}
		return query;

	}

	public static void addGap(List controlObjectives, String gap, String ctlId) {

		Iterator iterator = controlObjectives.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (ctlId
					.equalsIgnoreCase(controlObjective.getControlObjectiveId())) {

				controlObjective.addToGapList(gap);
			}
		}

	}

	public static String getControlObjectiveString(String id, String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT DISTINCT DR.DESCRIPTION,DR.OBJ_COMPOSITE_ID FROM SUB_CYCLE SC,CTRL_OBJ CO,DEF_REF DR WHERE SC.SUB_CYCLE_ID=? AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND DR.OBJ_COMPOSITE_ID=CO.CTRL_OBJ_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT DISTINCT DR.DESCRIPTION,DR.OBJ_COMPOSITE_ID FROM CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO,DEF_REF DR WHERE C.CYCLE_ID=? AND C.CYCLE_ID=SC.CYCLE_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND DR.OBJ_COMPOSITE_ID=CO.CTRL_OBJ_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			query = "SELECT * FROM DEF_REF WHERE OBJ_COMPOSITE_ID=?";
		}

		return query;
	}

	public static String getGapQuery(String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT DISTINCT GDL.DESCRIPTION,SC.SUB_CYCLE_ID,ORS.ASSOCIATED_ID,ORS.ASSOCIATED_TYPE,ORS.OWNER_ID FROM SUB_CYCLE SC,CTRL_OBJ CO,ACTIVITY A,GAP_DC_LOE GDL,OWNER_RESPONSE ORS WHERE SC.SUB_CYCLE_ID=? AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND (ORS.ASSOCIATED_ID=A.ACTIVITY_ID OR ORS.ASSOCIATED_ID=SC.SUB_CYCLE_ID) AND ORS.RESPONSE_ID=GDL.RESPONSE_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT DISTINCT GDL.DESCRIPTION,SC.SUB_CYCLE_ID,ORS.ASSOCIATED_ID,ORS.ASSOCIATED_TYPE,ORS.OWNER_ID FROM CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO,ACTIVITY A,GAP_DC_LOE GDL,OWNER_RESPONSE ORS WHERE C.CYCLE_ID=? AND SC.CYCLE_ID=C.CYCLE_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND (ORS.ASSOCIATED_ID=A.ACTIVITY_ID OR ORS.ASSOCIATED_ID=SC.SUB_CYCLE_ID OR ORS.ASSOCIATED_ID=C.CYCLE_ID) AND ORS.RESPONSE_ID=GDL.RESPONSE_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			query = "SELECT DISTINCT GDL.DESCRIPTION,CO.CTRL_OBJ_ID,ORS.ASSOCIATED_ID,ORS.ASSOCIATED_TYPE,ORS.OWNER_ID FROM CTRL_OBJ CO,ACTIVITY A,OWNER_RESPONSE ORS,GAP_DC_LOE GDL  WHERE CO.CTRL_OBJ_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND ORS.ASSOCIATED_ID=A.ACTIVITY_ID AND GDL.RESPONSE_ID=ORS.RESPONSE_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "SELECT DISTINCT GDL.DESCRIPTION,ORS.ASSOCIATED_ID,ORS.ASSOCIATED_TYPE,ORS.OWNER_ID FROM ACTIVITY A,OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE A.ACTIVITY_ID=? AND A.ACTIVITY_ID=ORS.ASSOCIATED_ID AND GDL.RESPONSE_ID=ORS.RESPONSE_ID AND ORS.OWNER_ID=?";
		}

		return query;
	}

	public static String getGapUpdateQuery(String id, String level) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "UPDATE SUB_CYCLE SC SET SC.POTENTIAL_GAP=? WHERE SC.SUB_CYCLE_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "UPDATE CYCLE C SET C.POTENTIAL_GAP=? WHERE C.CYCLE_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			query = "UPDATE CTRL_OBJ CO SET CO.POTENTIAL_GAP=? WHERE CO.CTRL_OBJ_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "UPDATE ACTIVITY A SET A.POTENTIAL_GAP=? WHERE A.ACTIVITY_ID=?";
		}
		return query;
	}

	public static void addDeficiency(List deficiencyList,
			String controlObjectiveId, String deficiencyString) {

		Iterator deficiencyListIterator = deficiencyList.iterator();

		while (deficiencyListIterator.hasNext()) {

			Deficiency deficiency = (Deficiency) deficiencyListIterator.next();

			if (deficiency.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {
				deficiency.addDeficiency(deficiencyString);
				return;
			}
		}
		Deficiency def = new Deficiency();
		def.setControlObjectiveId(controlObjectiveId);
		def.addDeficiency(deficiencyString);
		deficiencyList.add(def);

	}

	public static void addGapNew(List deficiencyList,
			String controlObjectiveId, String gapString, String type,
			String owner) {

		Iterator gapListIterator = deficiencyList.iterator();

		while (gapListIterator.hasNext()) {

			Gap gap = (Gap) gapListIterator.next();

			if (gap.getControlObjectiveId()
					.equalsIgnoreCase(controlObjectiveId)) {
				gap.addGap(gapString, owner);
				return;
			}
		}
		Gap gap = new Gap();
		gap.setControlObjectiveId(controlObjectiveId);
		gap.addGap(gapString, owner);
		gap.setAssociatedId(type);
		deficiencyList.add(gap);
	}

	public static void addCycleGap(List subCyleList, String id,
			String gapString, String level, String owner, String subcycleid) {
		addSubCycleGap(subCyleList, id, level, gapString, owner, subcycleid);
		if (level.equalsIgnoreCase("C")) {
			//cycleGap.addGap(gapString);
		} else {
			//cycleGap.addSubCycleGap(id,level,gapString,owner,subcycleid);
		}

	}

	public static List getCycleGap(String idIn) throws Exception {

		List subCycleList = new ArrayList();

		Connection con = null;

		PreparedStatement getGap = null;

		String gap = "";

		String id = "";

		String type = "";

		String owner = "";

		String subcycleid = "";

		try {
			//con = getConnection();
			
			con = SoxicConnectionFactory.getSoxicConnection();

			getGap = con.prepareStatement(getGapQuery(SoxicConstants.CYCLE));

			getGap.setString(1, idIn);

			ResultSet rs = getGap.executeQuery();

			while (rs.next()) {

				gap = rs.getString("DESCRIPTION");

				id = rs.getString("ASSOCIATED_ID");

				type = rs.getString("ASSOCIATED_TYPE");

				owner = rs.getString("OWNER_ID");

				subcycleid = rs.getString("SUB_CYCLE_ID");

				addCycleGap(subCycleList, id, gap, type, owner, subcycleid);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subCycleList;
	}

	public static void addGap(String id, String level) throws Exception {

		Connection con = null;

		PreparedStatement addGap = null;

		try {
			//con = getConnection();
			
			con = SoxicConnectionFactory.getSoxicConnection();

			addGap = con.prepareStatement(getGapUpdateQuery(id, level));

			addGap.setString(1, "Y");

			addGap.setString(2, id);

			addGap.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static String getCycleForControlObjective(String id)
			throws Exception {

		Connection con = null;

		PreparedStatement getCycleId = null;

		String cycleId = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getCycleId = con
					.prepareStatement("SELECT C.CYCLE_ID FROM CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO WHERE C.CYCLE_ID=SC.CYCLE_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID=?");

			getCycleId.setString(1, id);

			ResultSet rs = getCycleId.executeQuery();
			while (rs.next()) {
				cycleId = rs.getString("CYCLE_ID");
			}
			getCycleId.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cycleId;
	}

	public static String getCycleForSubcycle(String id) throws Exception {

		Connection con = null;

		PreparedStatement getCycleId = null;

		String cycleId = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getCycleId = con
					.prepareStatement("SELECT C.CYCLE_ID FROM CYCLE C,SUB_CYCLE SC WHERE C.CYCLE_ID=SC.CYCLE_ID AND SC.SUB_CYCLE_ID=?");

			getCycleId.setString(1, id);

			ResultSet rs = getCycleId.executeQuery();
			while (rs.next()) {
				cycleId = rs.getString("CYCLE_ID");
			}
			getCycleId.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cycleId;
	}

	public static String getSubCycleForControlObjective(String id)
			throws Exception {

		Connection con = null;

		PreparedStatement getSubCycleId = null;

		String subCycleId = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getSubCycleId = con
					.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC,CTRL_OBJ CO WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND CO.CTRL_OBJ_ID=?");

			getSubCycleId.setString(1, id);

			ResultSet rs = getSubCycleId.executeQuery();
			while (rs.next()) {
				subCycleId = rs.getString("SUB_CYCLE_ID");
			}
			getSubCycleId.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subCycleId;
	}

	public static String getStatusForControlObjective(
			String controlObjectiveId, String ownerId) throws Exception {

		Connection con = null;

		PreparedStatement getControlObjectiveStatus = null;

		String status = "";

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getControlObjectiveStatus = con
					.prepareStatement("SELECT OA.STATUS FROM CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA,LOOKUP L WHERE CO.CTRL_OBJ_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND OA.OWNER_ID=? AND L.TYPE='STATUS' AND L.NAME=OA.STATUS ORDER BY L.VALUE");

			getControlObjectiveStatus.setString(1, controlObjectiveId);

			getControlObjectiveStatus.setString(2, ownerId);

			ResultSet rs = getControlObjectiveStatus.executeQuery();
			while (rs.next()) {
				status = rs.getString("STATUS");
				return status;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return status;
	}

	public static void setGapForLevels(String id, String level)
			throws Exception {

		String cycleId = "";
		String subCycleId = "";
		String controlObjectiveId = "";

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			subCycleId = getSubCycleForControlObjective(id);
			addGap(subCycleId, SoxicConstants.SUBCYCLE);

			cycleId = getCycleForControlObjective(id);
			addGap(cycleId, SoxicConstants.CYCLE);

			addGap(id, SoxicConstants.CONTROLOBJECTIVE);

		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			addGap(id, SoxicConstants.ACTIVITY);

			controlObjectiveId = getControlObjectiveIdForActivity(id);
			addGap(controlObjectiveId, SoxicConstants.CONTROLOBJECTIVE);

			subCycleId = getSubCycleForControlObjective(controlObjectiveId);
			addGap(subCycleId, SoxicConstants.SUBCYCLE);

			cycleId = getCycleForControlObjective(controlObjectiveId);
			addGap(cycleId, SoxicConstants.CYCLE);

		}

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			cycleId = getCycleForSubcycle(id);
			addGap(cycleId, SoxicConstants.CYCLE);

		}
	}

	public static String getControlObjectiveIdForActivity(String activityId)
			throws Exception {
		Connection con = null;

		PreparedStatement getControlObjectiveId = null;

		String controlObjectiveId = "";

		try {
			//con = getConnection();
			
			con = SoxicConnectionFactory.getSoxicConnection();

			getControlObjectiveId = con
					.prepareStatement("SELECT A.CTRL_OBJ_ID FROM ACTIVITY A WHERE A.ACTIVITY_ID=?");

			getControlObjectiveId.setString(1, activityId);

			ResultSet rs = getControlObjectiveId.executeQuery();
			while (rs.next()) {
				controlObjectiveId = rs.getString("CTRL_OBJ_ID");
				return controlObjectiveId;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return controlObjectiveId;
	}

	public static void addSubCycleGap(List subCycleGapList, String id,
			String level, String gapString, String ownerId, String subCycleid) {

		Iterator subCycleIterator = subCycleGapList.iterator();

		if (level.equalsIgnoreCase("S")) {

			while (subCycleIterator.hasNext()) {

				SubCycleGap subCycleGapObj = (SubCycleGap) subCycleIterator
						.next();

				if (subCycleGapObj.getSubCycleId().equalsIgnoreCase(id)) {
					subCycleGapObj.addGap(gapString);
					return;
				}
			}

			SubCycleGap subCycleGap = new SubCycleGap();
			subCycleGap.setSubCycleId(id);
			subCycleGap.addGap(gapString);

		}

		if (level.equalsIgnoreCase("A")) {

			while (subCycleIterator.hasNext()) {

				SubCycleGap subCycleGap = (SubCycleGap) subCycleIterator.next();

				if (subCycleGap.getSubCycleId().equalsIgnoreCase(subCycleid)) {
					subCycleGap.addActivityGap(id, level, gapString, ownerId,
							subCycleid);
					return;
				}
			}

			SubCycleGap subCycleGap = new SubCycleGap();
			subCycleGap.setSubCycleId(subCycleid);
			subCycleGap.addActivityGap(id, level, gapString, ownerId,
					subCycleid);
			subCycleGapList.add(subCycleGap);
		}

	}

	public static String getControlObjectiveStatus(String controlObjectiveId)
			throws Exception {
		Connection con = null;

		PreparedStatement getControlObjectiveStatus = null;

		//List activityList = new ArrayList();

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			getControlObjectiveStatus = con
					.prepareStatement("SELECT OA.STATUS FROM ACTIVITY A,OWNER_ACTIVITY OA,LOOKUP L WHERE A.CTRL_OBJ_ID=? AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND L.TYPE='STATUS' AND L.NAME=OA.STATUS ORDER BY L.VALUE DESC");

			getControlObjectiveStatus.setString(1, controlObjectiveId);

			ResultSet rs = getControlObjectiveStatus.executeQuery();

			while (rs.next()) {

				return rs.getString("STATUS");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static void updateControlObjectiveStatus(String controlObjectiveId,
			String status, String owner_id) throws Exception {
		Connection con = null;

		PreparedStatement updateControlObjectiveStatus = null;

		//List activityList = new ArrayList();

		try {
			//con = getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

			updateControlObjectiveStatus = con
					.prepareStatement("UPDATE CTRL_OBJ CO SET CO.STATUS=? , CO.MOD_DATE=? , CO.MOD_USER=? WHERE CO.CTRL_OBJ_ID=?");

			updateControlObjectiveStatus.setString(1, status);

			updateControlObjectiveStatus.setDate(2, new Date(System
					.currentTimeMillis()));

			updateControlObjectiveStatus.setString(3, owner_id);

			updateControlObjectiveStatus.setString(4, controlObjectiveId);

			updateControlObjectiveStatus.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}


	public static Activity getActivity(String activityId) throws Exception {

		Activity activity = new Activity();

		Connection connection = null;

		try {

			//connection = getConnection();
			
			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement previouGap = connection
					.prepareStatement("SELECT * FROM ACTIVITY A WHERE A.ACTIVITY_ID=?");

			previouGap.setString(1, activityId);

			ResultSet rs = previouGap.executeQuery();

			while (rs.next()) {
				activity.setActivityId(rs.getString("ACTIVITY_ID"));
				activity.setDescription(rs.getString("DESCRIPTION"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return activity;
	}

	public static Activity getSubCycle(String subCycleId) throws Exception {

		Activity activity = new Activity();

		Connection connection = null;

		try {

			//connection = getConnection();
			
			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement previouGap = connection
					.prepareStatement("SELECT * FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID=?");

			previouGap.setString(1, subCycleId);

			ResultSet rs = previouGap.executeQuery();

			while (rs.next()) {
				activity.setActivityId(rs.getString("SUB_CYCLE_ID"));
				activity.setDescription(rs.getString("DESCRIPTION"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return activity;
	}

//	public static Connection getConnection() throws Exception {
//		Context initContext = new InitialContext();
//		Context envContext = (Context) initContext.lookup("java:/comp/env");
//		DataSource ds = (DataSource) envContext.lookup("jdbc/soxicdb");
//
//		if (SoxicUtil.isPasswordEncrypted()) {
//			String decryptedPassword = EncryptionUtils
//					.GetDecryptedStringFromExternalStorage(SoxicUtil
//							.getEnvironmentVariable(), SoxicUtil
//							.getSecurityApplicationFolder(), "CipherValue.hex",
//							"KeyValue.hex");
//			BasicDataSource bds = (BasicDataSource) ds;
//			bds.setPassword(decryptedPassword);
//		}
//		Connection conn = ds.getConnection();
//		return conn;
//	}

}

