package com.monsanto.wst.soxic.tags;

import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.NavConstants;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 * Created by IntelliJ IDEA.
 * User: VLARTER
 * Date: Aug 11, 2005
 * Time: 1:30:29 PM
 * ToDo: Need to move bulding features to separate class(es) based on type.
 */
public class SecureNav extends SimpleTagSupport {
    private String name = "";
    private String page = "";
    private String contextpath = "";
    private Owner owner = null;

    public void doTag() throws JspException, IOException {
        Navigation navigation = new Navigation(this);
        getJspContext().getOut().write(navigation.buildNavHTMLString());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getContextpath() {
        return contextpath;
    }

    public void setContextpath(String contextpath) {
        this.contextpath = contextpath;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }
}
