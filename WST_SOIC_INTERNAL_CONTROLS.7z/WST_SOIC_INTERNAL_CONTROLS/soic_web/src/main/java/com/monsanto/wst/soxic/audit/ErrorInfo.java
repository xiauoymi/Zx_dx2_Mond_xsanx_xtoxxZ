package com.monsanto.wst.soxic.audit;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 13, 2009
 * Time: 11:21:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class ErrorInfo {
  private String absolutePath;
  private String message;

  public void setFilePath(String absolutePath) {
    this.absolutePath = absolutePath;
  }

  public void setMessage(String message) {
    this.message = message;
  }


  public String getAbsolutePath() {
    return absolutePath;
  }

  public String getMessage() {
    return message;
  }
}
