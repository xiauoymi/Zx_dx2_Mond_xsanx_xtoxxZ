/*
 * Created on Mar 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.List;


/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ItemDetails {
    
    public static final String CYCLE     	  = "CYCLE";
    public static final String SUB_CYCLE 	  = "SUB_CYCLE";
    public static final String CTRL_OBJ       = "CTRL_OBJ";
    public static final String ACTIVITY       = "ACTIVITY";
    
    public static final String OWNER_CYCLE     = "OWNER_CYCLE";
    public static final String OWNER_SUB_CYCLE = "OWNER_SUB_CYCLE";
    
    public static final String OWNER_ACTIVITY  = "OWNER_ACTIVITY";
    
    public static final String CYCLE_ID      = "CYCLE_ID";
    public static final String SUB_CYCLE_ID  = "SUB_CYCLE_ID";
    public static final String CTRL_OBJ_ID   = "CTRL_OBJ_ID";
    public static final String ACTIVITY_ID   = "ACTIVITY_ID";
   
    public static final String DESCRIPTION  = "DESCRIPTION";
    public static final String START_DATE   = "START_DATE";
    public static final String DUE_DATE     = "DUE_DATE";
      
    
    private String id;
    private String description;
    private String startDate;
    private String dueDate;
    private String type;
    private List activitycodes;
    private String codestring;

    private boolean applyToAllChildren;
    

    /**
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return Returns the dueDate.
     */
    public String getDueDate() {
        return dueDate;
    }
    /**
     * @param dueDate The dueDate to set.
     */
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(String name) {
        this.id = name;
    }
    /**
     * @return Returns the startDate.
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * @param startDate The startDate to set.
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    /**
     * @return Returns the applyToAllChildren.
     */
    public boolean isApplyToAllChildren() {
        return applyToAllChildren;
    }
    /**
     * @param applyToAllChildren The applyToAllChildren to set.
     */
    public void setApplyToAllChildren(boolean applyToAllChildren) {
        this.applyToAllChildren = applyToAllChildren;
    }
    /**
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }
    /**
     * @param type The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }

    public List getActivitycodes() {
        return activitycodes;
    }

    public void setActivitycodes(List activitycodes) {
        this.activitycodes = activitycodes;
    }

    public String getCodestring() {
        return codestring;
    }

    public void setCodestring(String codestring) {
        this.codestring = codestring;
    }
}
