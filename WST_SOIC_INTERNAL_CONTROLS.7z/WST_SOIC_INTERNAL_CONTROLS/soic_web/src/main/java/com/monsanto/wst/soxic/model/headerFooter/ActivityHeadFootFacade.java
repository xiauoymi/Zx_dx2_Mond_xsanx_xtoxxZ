package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.model.HeaderFooterDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 12:49:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityHeadFootFacade extends HeaderFooterFacade{

    public String getHeader() {
        return HeaderFooterDAO.getMessage(SoxicConstants.ACTIVITY_QUESTION_HEADER,SoxicConstants.QUESTION_HEADER);
    }

    public String getFooter() {
        return HeaderFooterDAO.getMessage(SoxicConstants.ACTIVITY_QUESTION_FOOTER,SoxicConstants.QUESTION_FOOTER);
    }

}
