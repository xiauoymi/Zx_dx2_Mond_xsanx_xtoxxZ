package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.EmailHeaderForm;
import com.monsanto.wst.soxic.persistance.EmailHeaderDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.apache.struts.action.ActionForm;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 20, 2006
 * Time: 1:30:35 PM
 */
public class EmailHeaderFacade {
    EmailHeaderDAO emailHeaderDAO = new EmailHeaderDAO();

    public void populateEmailHeaderForm(ActionForm form) throws DatabaseException {

        Map emailMap = emailHeaderDAO.selectHeader();
        EmailHeaderForm emailHeaderForm = (EmailHeaderForm) form;

        String activityEmailHeader = (String) emailMap.get(SoxicConstants.ACTIVITY_EMAIL_HEADER);
        emailHeaderForm.setActivityEmailHeader(activityEmailHeader);

        emailHeaderForm.setSubCycleEmailHeader(SoxicConstants.SUB_CYCLE_EMAIL_HEADER);
        emailHeaderForm.setCycleEmailHeader((String) emailMap.get(SoxicConstants.CYCLE_EMAIL_HEADER));
    }

    public void updateEmailHeader(ActionForm form) throws DatabaseException {
        EmailHeaderForm emailHeaderForm = (EmailHeaderForm) form;
        String subcycleHeader = emailHeaderForm.getSubCycleEmailHeader();
        emailHeaderForm.getSubCycleEmailHeader();
        emailHeaderForm.getCycleEmailHeader();
        emailHeaderDAO.updateEmailHeader(emailHeaderForm);

    }
}
