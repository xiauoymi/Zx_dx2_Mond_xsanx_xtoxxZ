package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 19, 2005
 * Time: 4:22:05 PM
 */


public class NullControlActivityException extends Exception {
	public NullControlActivityException(){
		super();
	}

	public NullControlActivityException(Exception e){
		super(e);
	}
}