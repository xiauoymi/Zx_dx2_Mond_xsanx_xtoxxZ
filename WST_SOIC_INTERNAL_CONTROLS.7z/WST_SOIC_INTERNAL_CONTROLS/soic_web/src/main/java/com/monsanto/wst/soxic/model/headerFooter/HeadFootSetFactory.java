package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:13:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class HeadFootSetFactory {

    public static HeadFootSet getLevel(String level){
        HeadFootSet headFootSet = null;

        if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
            headFootSet = new CycleHeadFootSet();
        }

        if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
            headFootSet = new SubCycleHeadFootSet();
        }

        if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
            headFootSet = new ActivityHeadFootSet();
        }

        return headFootSet;
    }
}
