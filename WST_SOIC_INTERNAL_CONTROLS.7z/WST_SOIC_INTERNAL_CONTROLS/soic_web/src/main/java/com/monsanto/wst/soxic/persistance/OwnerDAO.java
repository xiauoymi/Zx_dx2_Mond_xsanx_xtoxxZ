/*
 * Created on Mar 30, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.model.NewsItem;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class OwnerDAO {

	public void populateModel(ResultSet rs,Owner owner)
			throws DatabaseException, Exception {
		try {

			if(owner.getName()==null){
				owner.setName(rs.getString(Owner.NAME));
				owner.setEmail(rs.getString(Owner.EMAIL));
				owner.setLastLogin(rs.getString(Owner.LAST_LOGIN));
				if(rs.getString(Owner.LAST_LOGIN)!=null){
					java.util.Date tempdate = rs.getDate(Owner.LAST_LOGIN);
					String temp = DateFormat.getDateInstance(DateFormat.MEDIUM).format(tempdate);
					owner.setLastLogin(temp);
				}
				owner.setRole(rs.getString("ROLE_ID"));
			}else{
				owner.setRole(owner.getRole()+", "+rs.getString("ROLE_ID"));
			}
			setRole(rs.getString("ROLE_ID"),owner);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Owner getOwnerDetails(String owner_id) throws Exception {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		Owner owner=new Owner();

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("SELECT * FROM OWNER O,OWNER_ROLE OROLE WHERE O.OWNER_ID=? AND OROLE.OWNER_ID=O.OWNER_ID");
			preparedStatement.setString(1, owner_id);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				populateModel(resultset,owner);
			}
		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}
		return owner;
	}
	
	public List getNewsItems()throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		List newsList = new ArrayList();
        NewsItem newsItem;

        try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("SELECT * FROM NEWS WHERE ROWNUM = 1 ORDER BY NEWS_ID DESC");
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
                newsItem = new NewsItem();
                newsItem.setTitle(resultset.getString("SUBJECT"));
                newsItem.setBody(resultset.getString("BODY"));
                newsList.add(newsItem);
			}
		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}
		return newsList;		
	}
	
	public void updateOwner(String owner_id)throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("UPDATE OWNER O SET O.LAST_LOGIN=?,O.MOD_DATE=?,O.MOD_USER=? WHERE O.OWNER_ID=?");
			preparedStatement.setDate(1,new Date(System
					.currentTimeMillis()));
			preparedStatement.setDate(2, new Date(System
					.currentTimeMillis()));
			preparedStatement.setString(3,owner_id);
			preparedStatement.setString(4,owner_id);
			resultset = preparedStatement.executeQuery();

		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}	
	}
	
	public boolean isPresent(String ownerid)throws Exception{
		boolean present = false;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("SELECT * FROM OWNER O WHERE O.OWNER_ID=?");
			preparedStatement.setString(1,ownerid);
			resultset = preparedStatement.executeQuery();
			while(resultset.next()){
				return true;
			}

		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}			
		return present;
	}
	
	public void insertOwner(Owner owner)throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("INSERT INTO OWNER (OWNER_ID, NAME, LOCATION, EMAIL, LAST_LOGIN, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)");
			preparedStatement.setString(1,owner.getOwnerId());
			preparedStatement.setString(2,owner.getName());
			preparedStatement.setString(3,owner.getLocation());
			preparedStatement.setString(4,owner.getEmail());
			preparedStatement.setDate(5,new Date(System.currentTimeMillis()));
			preparedStatement.setDate(6,new Date(System.currentTimeMillis()));
			preparedStatement.setString(7,owner.getOwnerId());
			
			int result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}			
	}
	
	private void setRole(String role,Owner owner){
		if(role.equalsIgnoreCase(SoxicConstants.ADMIN)){
			owner.setAdmin(true);
		}
		if(role.equalsIgnoreCase(SoxicConstants.REPORT)){
			owner.setViewReports(true);
		}
		if(role.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){
			owner.setIA(true);
		}
        if(role.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA_USER)){
            owner.setIAUser(true);
        }
	}

    public void select(SoxicBaseModel soxicBaseModel){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;

        Owner owner = (Owner)soxicBaseModel;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT O.EMAIL,O.NAME,O.LAST_LOGIN,O.LOCATION FROM OWNER O WHERE upper(O.OWNER_ID)=upper(?)");
            preparedStatement.setString(1,owner.getOwnerId());
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                owner.setEmail(rs.getString("EMAIL"));
                owner.setName(rs.getString("NAME"));
                owner.setLocation(rs.getString("LOCATION"));
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }

                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }

    }

}