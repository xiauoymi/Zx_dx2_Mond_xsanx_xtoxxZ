//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.AdminReportScreenViewForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

/** 
 * MyEclipse Struts
 * Creation date: 03-30-2005
 * 
 * XDoclet definition:
 * @struts:action path="/adminReportScreenView" name="adminReportScreenViewForm" scope="request"
 */
public class AdminReportScreenViewAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
    int currentEditID;
    
    // --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		AdminReportScreenViewForm adminReportScreenViewForm = (AdminReportScreenViewForm) form;
		
		Vector adminReportVector = new Vector();
		
		ActionErrors errors = new ActionErrors();
		
		Vector allRoles = new Vector();
		
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			Connection con = SoxicConnectionFactory.getSoxicConnection();
		 	
		 	logger.info("Connected to DB from /admin-Report-screen.");
		 
		 	PreparedStatement getActiveReports;
		 	PreparedStatement getActiveReportRoles;
		 	
		 	PreparedStatement getReport;
		 	PreparedStatement getAllRoles;
		 	
		 	PreparedStatement getReportInfo;
		 	PreparedStatement deactivateReport;
		 	
		 	PreparedStatement updateReportInfo;
		 	
		 	PreparedStatement deleteRoles;
		 	PreparedStatement addNewRoles;
		 	
		 	getActiveReports = con.prepareStatement
					("SELECT " +
						"R.REPORT_ID, R.NAME, R.DESCRIPTION " +
					"FROM " +
						"REPORT R " +
					"WHERE " +
						"R.ACTIVE = 'Y' ORDER BY R.REPORT_ID");
		 	
		 	getActiveReportRoles = con.prepareStatement
				("SELECT " +
					"RR.ROLE_ID " +
				"FROM " +
					"REPORT R, REPORT_ROLE RR " +
				"WHERE " +
					"R.REPORT_ID = RR.REPORT_ID AND " +
					"R.REPORT_ID = ?");
		 	
		 	getReportInfo = con.prepareStatement
				("SELECT " +
					"R.REPORT_ID, R.NAME, R.DESCRIPTION " +
				"FROM " +
					"REPORT R " +
				"WHERE R.REPORT_ID = ?");
		 	
		 	deactivateReport = con.prepareStatement
				("UPDATE REPORT R " +
						"SET " +
							"ACTIVE = 'N' " +
						"WHERE " +
							"R.REPORT_ID = ?");
		 	
		 	updateReportInfo = con.prepareStatement
				("UPDATE REPORT " +
					"SET NAME = ?, DESCRIPTION = ? " +
					"WHERE REPORT_ID = ?");
		 	
		 	deleteRoles = con.prepareStatement
				("DELETE " +
						"FROM " +
							"REPORT_ROLE " +
						"WHERE " +
							"REPORT_ID = ?");
		 	
		 	addNewRoles = con.prepareStatement
				("INSERT " +
						"INTO REPORT_ROLE " +
						"(REPORT_ID, ROLE_ID) " +
						"VALUES (?, ?)");
		 	
		 	//**If save and submit is clicked...
		 	if(adminReportScreenViewForm.getEditRepObj().getReportName() != null){
		 		logger.info("You clicked save & submit !!!");
		 		
		 		//**Validate the empty text box/text area etc...
		 		
		 		//**Add it to database...(name and desc)...(to be checked...)
		 		ResultSet rs5;
		 		
		 		AdminReportObject editObj = adminReportScreenViewForm.getEditRepObj();
		 		
		 		String rptName = editObj.getReportName();
		 		String rptDesc = editObj.getReportDesc();
		 		
		 		if(!rptName.equals("")){
		 			updateReportInfo.setString(1, rptName);
		 			updateReportInfo.setString(2, rptDesc);
		 			updateReportInfo.setInt(3, currentEditID);
		 		
		 			updateReportInfo.executeUpdate();
		 		}
		 		else{
		 			logger.error("Cannot Update ('SARBOX_ET.REPORT.NAME') to NULL");
		 			
		 			errors.add("reportName", new ActionError("errors.report.name.null"));
		 		
		 			adminReportScreenViewForm.setDisplayTable2(true);
		 		}
		 		
		 		
		 		//**Add it to database...(selected roles)...		 		
		 		//**Delete existing roles and add new ones....
		 		
		 		if(errors.isEmpty()){
		 			deleteRoles.setInt(1, currentEditID);		 		
		 			deleteRoles.executeUpdate();
		 		
		 			String[] selectedRoles = adminReportScreenViewForm.getRolesSelected();		 		
		 		
		 			if(selectedRoles != null){
		 				for(int i = 0; i < selectedRoles.length; i++){		 		
		 					addNewRoles.setInt(1, currentEditID);
		 					addNewRoles.setString(2, selectedRoles[i]);
		 			
		 					addNewRoles.executeUpdate();		 			
		 				}
		 			}
		 		}	
		 	}
		 	
		 	
		 	String action = getActionType(request.getParameterMap());		 	
		 	//**If edit was clicked...
		 	if (action.equalsIgnoreCase("edit")) {

		 		//**Do some separate handling, set form variables and display using Logic tags�.		 		
		 		
		 		int editRepID = Integer.parseInt(request.getParameter("edit").toString());
				
		 		currentEditID = editRepID;
		 		
		 		//logger.info("You clicked edit !!!" + editRepID);
		 		
		 		AdminReportObject editRepObj = new AdminReportObject();
		 		
		 		ResultSet rs4;
		 		
		 		getReportInfo.setInt(1, editRepID);
		 		
		 		rs4 = getReportInfo.executeQuery();
		 		
		 		while(rs4.next()){
		 			editRepObj.setReportID(rs4.getInt("REPORT_ID"));
		 			editRepObj.setReportName(rs4.getString("NAME"));
		 			editRepObj.setReportDesc(rs4.getString("DESCRIPTION"));
		 		}
		 				 		
		 		adminReportScreenViewForm.setEditRepObj(editRepObj);
		 		
		 		//return mapping.findForward("success");
		 	}
		 	
		 	if (action.equalsIgnoreCase("delete")) {
		 		
		 		int delRepID = Integer.parseInt(request.getParameter("delete").toString());
				
		 		deactivateReport.setInt(1, delRepID);		 		
		 		
		 		deactivateReport.executeUpdate();
		 		
		 		logger.info("You clicked delete !!!" + delRepID);
		 	}
		 	
//		 	if (action.equalsIgnoreCase("save_submit")) {
//		 		
//		 		int saveRepID = Integer.parseInt(request.getParameter("save_submit").toString());
//				
//		 		logger.info("You clicked save & submit !!!" + saveRepID);
//		 	}
		 	
		 	if (action.equalsIgnoreCase("reset")) {
		 		
		 		int resetRepID = Integer.parseInt(request.getParameter("reset").toString());
				
		 		logger.info("You clicked reset !!!" + resetRepID);
		 	}
		 	
		 	if(action.equalsIgnoreCase("reset") || action.equalsIgnoreCase("edit") || !errors.isEmpty()){
		 		adminReportScreenViewForm.setDisplayTable2(true);
		 	}
		 	else{
		 		adminReportScreenViewForm.setDisplayTable2(false);
		 	}
		 	
		 	
		 	ResultSet rs1 = getActiveReports.executeQuery();
		 	
		 	int orderNo = 0;
		 	while(rs1.next()){
		 		
		 		orderNo++;
		 		
		 		AdminReportObject repObj = new AdminReportObject();
		 		
		 		repObj.setOrderNumber(orderNo);
		 		repObj.setReportID(rs1.getInt("REPORT_ID"));
		 		repObj.setReportName(rs1.getString("NAME"));
		 		repObj.setReportDesc(rs1.getString("DESCRIPTION"));
		 		
		 		ResultSet rs2;
		 		
		 		getActiveReportRoles.setInt(1, rs1.getInt("REPORT_ID"));
		 		
		 		rs2 = getActiveReportRoles.executeQuery();
		 		
		 		Vector roles = new Vector();
		 		
		 		while(rs2.next()){
		 			roles.add(rs2.getString("ROLE_ID"));
		 		}
		 		
		 		repObj.setReportRoles(roles);
		 		
		 		adminReportVector.add(repObj);
		 	}
		 	
		 	ResultSet rs3;
		 	
		 	getAllRoles = con.prepareStatement
				("SELECT " +
						"ROLE_ID " +
					"FROM " +
						"ROLE " +
					"WHERE " +
						"NAME IN ('REPORT_ROLE', 'ADMIN_ROLE') " +
							"ORDER BY ROLE_ID");
		 	
		 	rs3 = getAllRoles.executeQuery();
		 	
		 	while(rs3.next()){
		 		allRoles.add(rs3.getString("ROLE_ID"));
		 	}	
		 	
		 	adminReportScreenViewForm.setAllRoles(allRoles);
			adminReportScreenViewForm.setAdminReportVector(adminReportVector);
			
		 	
		 		
		}
		catch(Exception ex){
			logger.fatal("Database error from admin report screen action " + ex.getMessage());
		}
		
		if(errors.isEmpty()){
			
			return mapping.findForward("success");
		}
		else{
			saveErrors(request, errors);
			return mapping.findForward("faliure");
		}
		
	}
	
		//**Helper Function to get the button clicked...
		public String getActionType(Map parameterMap) {

				String action = null;

				String[] valueArr = null;

				Iterator iter = parameterMap.keySet().iterator();

				while (iter.hasNext()) {

					Object key = iter.next();

					Object value = parameterMap.get(key);

					valueArr = (String[]) value;

					if (((String) key).equalsIgnoreCase("edit")) {

						return "edit";
					}

					if (((String) key).equalsIgnoreCase("delete")) {

						return "delete";
					}
					
					if (((String) key).equalsIgnoreCase("save_submit")) {

						return "save_submit";
					}
					
					if (((String) key).equalsIgnoreCase("reset")) {

						return "reset";
					}
				}
				return "type";
		}

}