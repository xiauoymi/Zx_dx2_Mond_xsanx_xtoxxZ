package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.facade.DocumentChangeFacade;

import java.util.List;
import java.util.Collection;
import java.util.Iterator;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 25, 2005
 * Time: 9:20:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocChangeDisplayAction extends Action{

    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)throws Exception {

        ActionForward forward = new ActionForward();

        //Get the owner id from the sesion
        Owner owner = (Owner) request.getSession().getAttribute("owner");

        ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) form;

        DocumentChangeFacade documentChangeFacade = new DocumentChangeFacade();

        if(request.getParameter("change")==null){
              documentChangeFacade.initializeForm(controlObjectiveForm,owner);
        } else{

            if(request.getParameter("change").equalsIgnoreCase("cycle")){
                 documentChangeFacade.changeCycle(controlObjectiveForm,owner);
            }

            if(request.getParameter("change").equalsIgnoreCase("subCycle")){
                documentChangeFacade.changeSubCycle(controlObjectiveForm,owner);
            }
        }

        forward = mapping.findForward("success");

        return forward;

    }

    public void setCycleAssocitation(ControlObjectiveForm controlObjectiveForm,Collection subcycles){

        Iterator iterator = subcycles.iterator();
        HashSet hashSet = new HashSet();

        while(iterator.hasNext()){
            SubCycle subCycle = (SubCycle)iterator.next();
            hashSet.add(subCycle.getCycleId());
        }
        controlObjectiveForm.setCycleList(hashSet);
    }
}
