/*
 * Created on Mar 1, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

package com.monsanto.wst.soxic.action;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.OwnerCopyChangeForm;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerCopyChangeViewAction extends Action {
    
    public ActionForward execute(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
            
            OwnerCopyChangeForm changeOwnerForm = (OwnerCopyChangeForm) form;
            
            setDefaultData(changeOwnerForm);

            return mapping.findForward("success");
    }
    
    private void setOperations(OwnerCopyChangeForm form){
        
        List operations = new LinkedList();
        operations.add("Select Operation");
        operations.add("Copy");
        operations.add("Change");
        
        form.setNewUser("");
        form.setNewUserLocation("");
        form.setOperations(operations);
        form.setSelectedOperation("Select Operation");
        
    }
   
    
    private void setDefaultData(OwnerCopyChangeForm form){
        
        setOperations(form);
        form.setExistingUser("");
        form.setNewUser("");
        form.setCycles(new String[0]);
        form.setSubCycles(new String[0]);
        form.setActivities(new String[0]);
        form.setSelectedCycles(new String[0]);
        form.setSelectedSubCycles(new String[0]);
        form.setSelectedActivities(new String[0]);
        
        form.setChanges( new ArrayList());
	           
    }
}
            
           



