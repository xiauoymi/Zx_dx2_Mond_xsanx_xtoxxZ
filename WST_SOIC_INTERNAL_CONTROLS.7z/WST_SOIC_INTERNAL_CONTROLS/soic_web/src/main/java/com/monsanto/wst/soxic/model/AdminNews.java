/*
 * Created on Mar 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.List;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.persistance.OracleAdminNewsDAO;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminNews {
    
       
    private static List allRoles;
    
    public static List getAllNews() throws DatabaseException{
        
       return OracleAdminNewsDAO.getAllNews();
    }
    
    public static List getAllRoles() throws DatabaseException{
        
        if(allRoles == null || allRoles.isEmpty()){
            
            allRoles = OracleAdminNewsDAO.getAllRoles();
        }
        
        return allRoles;
    }
    
    public static NewsItem getNews(String newsId) throws DatabaseException{
        
        return OracleAdminNewsDAO.getNews(newsId);
    }
    
    public static void update(NewsItem news) throws DatabaseException{
        
        OracleAdminNewsDAO.update(news);
    }
    
    public static void deleteNews(String newsId) throws DatabaseException{
        
        OracleAdminNewsDAO.delete(newsId);
    }
    

}
