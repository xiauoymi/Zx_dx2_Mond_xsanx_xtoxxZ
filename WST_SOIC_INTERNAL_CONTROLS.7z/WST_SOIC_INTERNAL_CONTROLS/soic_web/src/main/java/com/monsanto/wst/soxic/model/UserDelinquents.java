/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserDelinquents {
	String name;
	String userid;
	String dueDate;
	String upperIdentifier;
	
	
	/**
	 * @return Returns the upperIdentifier.
	 */
	public String getUpperIdentifier() {
		return upperIdentifier;
	}
	/**
	 * @param upperIdentifier The upperIdentifier to set.
	 */
	public void setUpperIdentifier(String upperIdentifier) {
		this.upperIdentifier = upperIdentifier;
	}
	/**
	 * @return Returns the dueDate.
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate The dueDate to set.
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the userid.
	 */
	public String getUserid() {
		return userid;
	}
	/**
	 * @param userid The userid to set.
	 */
	public void setUserid(String userid) {
		this.userid = userid;
	}
}
