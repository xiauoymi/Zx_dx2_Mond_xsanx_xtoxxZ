/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

/**
 * @author SPOLAVA
 *
 * AbstractDAOFactory Class can be extended by any class that wants to supply
 * different implementation of DAO interface that persists Cycle, SubCycle,
 * ControlObject, Activity, Question, Answer and Owner in the model package.
 *
 * <br>The setFactory method is called by a config object by passing a specific
 * implementation AbstractDAOFactory which implements other DAO getter methods.
 *
 * <br>Default factory is OracleDAOFactory that supplies DAO implementations that
 * persists the above mentioned model objects into a Oracle Database.
 *
 */

    public abstract class AbstractDAOFactory {
    	private static AbstractDAOFactory factory = new OracleDAOFactory();

//    	/**
//     	 * Abstract getter method for OwnerDAO.
//     	 * @return Owner DAO Object.
//     	 */
//    	public abstract DAO getOwnerDAO();
//
//    	/**
//     	 * Abstract getter method for CycleDAO.
//     	 * @return Cycle DAO Object.
//     	 */
    	public abstract DAO getCycleDAO();

    	/**
     	 * Abstract getter method for SubCycleDAO.
     	 * @return SubCycle DAO Object.
     	 */
    	public abstract DAO getSubCycleDAO();

    	/**
    	 * Abstract getter method for ControlObjectiveDAO.
    	 * @return ControlObjective DAO Object.
    	 */
    	public abstract DAO getControlObjectiveDAO();

    	/**
    	 * Abstract getter method for ActivityDAO.
    	 * @return Activity DAO Object.
    	 */
    	public abstract DAO getActivityDAO();

    	/**
    	 * Abstract getter method for QuestionDAO.
    	 * @return Question DAO Object.
    	 */
    	public abstract DAO getQuestionDAO();

    	public abstract DAO getResponseDAO();

        public abstract DAO getPeriodDAO();

        public abstract DAO getOwnerChangeRequestDAO();

    //public abstract DAO getOwnerAdminOwnerDAO();

    public abstract DAO getOracleDocumentChangeDAO();

     public abstract DAO getOwnerChangeRequestResponseDAO();
//
//
    	/**
    	 * Static method which returns the factory set by the setFactory method
    	 * @return The factory object
    	 */
    	public static AbstractDAOFactory getFactory(){
    		return factory;
    	}


    	/**
    	 * Setter method for setting the factory
    	 * @param factory that is used for setting the AbstractDAOFactory.
    	 */
    	public static void setFactory(AbstractDAOFactory factory) {
    		AbstractDAOFactory.factory = factory;
    	}

}
