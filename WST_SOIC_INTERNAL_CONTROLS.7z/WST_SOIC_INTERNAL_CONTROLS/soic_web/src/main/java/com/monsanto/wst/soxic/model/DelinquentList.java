/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DelinquentList {
	
	String text;
	
	String identifier;
	
	List delinquentList = new ArrayList();
	
	
	
	

	/**
	 * @return Returns the text.
	 */
	public String getText() {
		return text;
	}
	/**
	 * @param text The text to set.
	 */
	public void setText(String text) {
		this.text = text;
	}
	/**
	 * @return Returns the identifier.
	 */
	public String getIdentifier() {
		return identifier;
	}
	/**
	 * @param identifier The identifier to set.
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	/**
	 * @return Returns the delinquentList.
	 */
	public List getDelinquentList() {
		return delinquentList;
	}
	/**
	 * @param delinquentList The delinquentList to set.
	 */
	public void setDelinquentList(List delinquentList) {
		this.delinquentList = delinquentList;
	}
	
	public void addDelinquent(UserDelinquents delinquents){
		delinquentList.add(delinquents);
	}
}
