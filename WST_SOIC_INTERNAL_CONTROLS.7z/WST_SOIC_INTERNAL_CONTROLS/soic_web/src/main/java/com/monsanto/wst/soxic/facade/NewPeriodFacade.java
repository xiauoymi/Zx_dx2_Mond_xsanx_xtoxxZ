package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.exception.NewPeriodCreationException;
import com.monsanto.wst.soxic.exception.PeriodAlreadyExistsException;
import com.monsanto.wst.soxic.model.Period;
import com.monsanto.wst.soxic.model.PeriodDAO;
import com.monsanto.wst.soxic.persistance.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 18, 2005
 * Time: 4:36:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class NewPeriodFacade {

    Connection connection = null;
    long startTime,endTime,dif,overallstart,overallend;

    public void createNewPeriod(String sourcePeriodId, String targetPeriodId, String period_id, String description, boolean cycleOnlyPeriod)throws Exception{

        DAO periodDAO = AbstractDAOFactory.getFactory().getPeriodDAO();
        Period period = new Period();
        period.setPeriod_id(period_id);
        period.setStatus(SoxicConstants.CREATENEW_STATE);
        period.setDescription(description);
        period.setSource_period_id(sourcePeriodId);
        period.setMod_user("ADMIN");
        period.setQueryType(Period.PERIOD_TYPE);
        if (cycleOnlyPeriod){
            period.setCycleOnlyPeriod("Y");
        }
        else{
            period.setCycleOnlyPeriod("N");
        }


        int result = periodDAO.create(period);

        if(result == -1){
            throw new PeriodAlreadyExistsException();
        }

        try{
            connection = getConnection();

            //List cycleList = (List)((PeriodDAO)periodDAO).retrieveAllCyclesForPeriods(sourcePeriodId);
            //Iterator iterator = cycleList.iterator();
            String tempSourcePeriodId = sourcePeriodId+".";

            overallstart =System.currentTimeMillis();

            createCycle(tempSourcePeriodId, targetPeriodId);
            createSubCycle(tempSourcePeriodId, targetPeriodId);
            createControlObjective(tempSourcePeriodId, targetPeriodId);
            createActivity(tempSourcePeriodId, targetPeriodId);

            PeriodCreation periodCreation = new PeriodCreation();
            List periodList = periodCreation.createCycles(sourcePeriodId,targetPeriodId, connection);
            periodCreation.insertCycle(periodList, connection);
            if(cycleOnlyPeriod) {
                updateStatusToComplete(period.getPeriod_id());
            }
        }catch(Exception e){
            if(e instanceof NewPeriodCreationException){
                throw new NewPeriodCreationException();
            }
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                closeConnection();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void createActivity(String tempSourcePeriodId, String targetPeriodId) throws Exception {
        ActivityPeriodCreation activityPeriodCreation = new ActivityPeriodCreation();
        createNewActivity(activityPeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewOwnerActivity(activityPeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewActivityCodesAndQuestions(activityPeriodCreation, tempSourcePeriodId, targetPeriodId);
    }

    private void createControlObjective(String tempSourcePeriodId, String targetPeriodId) throws Exception {
        ControlObjectivePeriodCreation controlObjectivePeriodCreation = new ControlObjectivePeriodCreation();
        createNewControlObjective(controlObjectivePeriodCreation, tempSourcePeriodId, targetPeriodId);
    }

    private void createSubCycle(String tempSourcePeriodId, String targetPeriodId) throws Exception {
        SubCyclePeriodCreation subCyclePeriodCreation = new SubCyclePeriodCreation();
        createNewSubCycle(subCyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewQuestionSubCycle(subCyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewOwnerSubCycle(subCyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
    }

    private void createCycle(String tempSourcePeriodId, String targetPeriodId) throws Exception {
        CyclePeriodCreation cyclePeriodCreation = new CyclePeriodCreation();
        createNewCycle(cyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewQuestionCycle(cyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
        createNewOwnerCycle(cyclePeriodCreation, tempSourcePeriodId, targetPeriodId);
    }

    private void createNewActivityCodesAndQuestions(ActivityPeriodCreation activityPeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        List ccylist = activityPeriodCreation.getCycleList(tempSourcePeriodId,targetPeriodId);
        Iterator ccIterator = ccylist.iterator();
        while(ccIterator.hasNext()){
            String ccId = (String)ccIterator.next();
            startTime = System.currentTimeMillis();
            List questionActivityList = activityPeriodCreation.createQuestionActivity(ccId,targetPeriodId, connection);

            activityPeriodCreation.insertQuestionActivity(questionActivityList, connection);
            questionActivityList = null;
            endTime = System.currentTimeMillis();
            dif = SoxicUtil.getTimeDifference(endTime, startTime);

            startTime = System.currentTimeMillis();
            List ctlCodeActivityList = activityPeriodCreation.createControlCodeActivity(ccId,targetPeriodId, connection);

            activityPeriodCreation.insertControlCodeActivity(ctlCodeActivityList, connection);
            ctlCodeActivityList = null;
            endTime = System.currentTimeMillis();
            dif = SoxicUtil.getTimeDifference(endTime, startTime);
            overallend = System.currentTimeMillis();
        }
    }

    private void createNewOwnerActivity(ActivityPeriodCreation activityPeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List ownerActivityList = activityPeriodCreation.createOwnerActivity(tempSourcePeriodId,targetPeriodId, connection);
        activityPeriodCreation.insertOwnerActivity(ownerActivityList, connection);
        ownerActivityList = null;
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewActivity(ActivityPeriodCreation activityPeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List act = activityPeriodCreation.createActivity(tempSourcePeriodId,targetPeriodId, connection);
        activityPeriodCreation.insertNewActivity(act, connection);
        act = null;
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewControlObjective(ControlObjectivePeriodCreation controlObjectivePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List controlobjectives = controlObjectivePeriodCreation.createControlObjective(tempSourcePeriodId,targetPeriodId, connection);
        controlObjectivePeriodCreation.insertNewControlObjective(controlobjectives, connection);
        controlobjectives = null;
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewOwnerSubCycle(SubCyclePeriodCreation subCyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List ownerSubCycles = subCyclePeriodCreation.createOwnerSubCycle(tempSourcePeriodId,targetPeriodId, connection);
        subCyclePeriodCreation.insertOwnerSubCycle(ownerSubCycles, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewQuestionSubCycle(SubCyclePeriodCreation subCyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List questionSubCycles = subCyclePeriodCreation.createQuestionSubCycle(tempSourcePeriodId,targetPeriodId, connection);
        subCyclePeriodCreation.insertQuestionSubCycle(questionSubCycles, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewSubCycle(SubCyclePeriodCreation subCyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List subCycles = subCyclePeriodCreation.createSubCycle(tempSourcePeriodId,targetPeriodId, connection);
        subCyclePeriodCreation.insertSubCycle(subCycles, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewOwnerCycle(CyclePeriodCreation cyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List ownerCycleList = cyclePeriodCreation.createOwnerCycle(tempSourcePeriodId,targetPeriodId, connection);
        cyclePeriodCreation.insertOwnerCycle(ownerCycleList, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewQuestionCycle(CyclePeriodCreation cyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List questionCycleList = cyclePeriodCreation.createQuestionCycle(tempSourcePeriodId,targetPeriodId, connection);
        cyclePeriodCreation.insertQuestionCycle(questionCycleList, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    private void createNewCycle(CyclePeriodCreation cyclePeriodCreation, String tempSourcePeriodId, String targetPeriodId) throws Exception {
        startTime = System.currentTimeMillis();
        List cyclelist = cyclePeriodCreation.createCycles(tempSourcePeriodId,targetPeriodId, connection);
        cyclePeriodCreation.insertCycle(cyclelist, connection);
        endTime = System.currentTimeMillis();
        dif = SoxicUtil.getTimeDifference(endTime, startTime);
    }

    protected Connection getConnection()throws Exception{

        return SoxicConnectionFactory.getSoxicConnection();

    }

    private void updateStatusToComplete(String cycleId) throws Exception {
        CycleOnlyCertifyFacade cycleOnlyCertifyFacade = new CycleOnlyCertifyFacade();
        cycleOnlyCertifyFacade.updateStatus(cycleId,CycleOnlyConstants.OWN_ACT);
        cycleOnlyCertifyFacade.updateStatus(cycleId,CycleOnlyConstants.ACT);
        cycleOnlyCertifyFacade.updateStatus(cycleId,CycleOnlyConstants.OWN_SUB);
        cycleOnlyCertifyFacade.updateStatus(cycleId,CycleOnlyConstants.SUBCYCLE);
        cycleOnlyCertifyFacade.updateStatus(cycleId,CycleOnlyConstants.CTRL_OBJ);
    }

    public void rollBack()throws Exception{

        SoxicConnectionFactory.rollback(connection);

    }

    public void closeConnection()throws Exception{

        SoxicConnectionFactory.closeSoxicConnection(connection);

    }

    public static void main(String ar[]){
        try{
            NewPeriodFacade facade = new NewPeriodFacade();
            facade.createNewPeriod("FY05.US.EXP","FY05Q3.US.EXP","FY05Q3","",false);
        }catch(Exception e){

        }
    }
}
