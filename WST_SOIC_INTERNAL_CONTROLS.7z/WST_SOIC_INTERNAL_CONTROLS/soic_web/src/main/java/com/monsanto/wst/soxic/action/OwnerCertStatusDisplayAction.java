package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.reports.OwnerCertificationStatusReportFacade;
import com.monsanto.wst.soxic.form.OwnerCertificationStatusReportForm;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 10:41:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerCertStatusDisplayAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        OwnerCertificationStatusReportForm ownerCertificationStatusReportForm = (OwnerCertificationStatusReportForm)form;
        OwnerCertificationStatusReportFacade ownerCertificationStatusReportFacade = new OwnerCertificationStatusReportFacade();
        ActionMessages messages = new ActionMessages();

        String ownerid = ownerCertificationStatusReportForm.getOwnerid();
        String periodId = ownerCertificationStatusReportForm.getPeriod();

        List owner_cycles = ownerCertificationStatusReportFacade.getCyclesForOwner(ownerid,periodId);
        List owner_subcycles = ownerCertificationStatusReportFacade.getSubCyclesForOwner(ownerid,periodId);
        List owner_activities = ownerCertificationStatusReportFacade.getActivitiesForOwner(ownerid,periodId);

        if (owner_cycles.size()==0 && owner_subcycles.size()==0 && owner_activities.size()==0){
            displayErrorMessageForNoAssignments(messages, request);
        }else{
            ownerCertificationStatusReportFacade.setAssignmentsIntoCorrespondingLists(owner_cycles, ownerCertificationStatusReportForm, owner_subcycles, owner_activities);
        }

        return mapping.findForward("displayOwnerStatus");

    }

    private void displayErrorMessageForNoAssignments(ActionMessages messages, HttpServletRequest request) {
        messages.add(ActionMessages.GLOBAL_MESSAGE,new ActionMessage(SoxicConstants.EMPTY_OWNERID));
        saveMessages(request,messages);
    }
}
