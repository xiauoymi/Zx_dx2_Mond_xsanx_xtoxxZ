package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.shared.overflow.OverFlowMap;

import java.util.List;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 13, 2006
 * Time: 3:05:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class SignificantChangeProcessor {

    public Map processList(List sigChanges) {
        Iterator sigIt = sigChanges.iterator();
        OverFlowMap overFlowMap;
        Map sigChangeMap = new HashMap();

        while(sigIt.hasNext()){
            SignificantChangeModel significantChangeModel = (SignificantChangeModel)sigIt.next();
            if (sigChangeMap.containsKey(significantChangeModel.getSeqindex())){
                SignificantChangeModel sigModel = (SignificantChangeModel) sigChangeMap.get(significantChangeModel.getSeqindex());
                sigModel.getOverFlowMap().add(significantChangeModel.getOverFlowId(),significantChangeModel.getOverSid(),
                        significantChangeModel.getOverText(),significantChangeModel.getDescription());
            }
            else{
                SignificantChangeModel sigModel = new SignificantChangeModel(significantChangeModel.getSeqindex(),
                        significantChangeModel.getSelectedType(),
                        significantChangeModel.getSelectedPeriod(),significantChangeModel.getAmount(),
                        significantChangeModel.getKeyContact(),significantChangeModel.getSubcycles(),
                        significantChangeModel.getDescription());
                overFlowMap = new OverFlowMap();
                overFlowMap.add(significantChangeModel.getOverFlowId(),significantChangeModel.getOverSid(),
                        significantChangeModel.getOverText(),significantChangeModel.getDescription());
                sigModel.setOverFlowMap(overFlowMap);
                sigChangeMap.put(significantChangeModel.getSeqindex(),sigModel);
            }
        }
        return sigChangeMap;
    }
}
