/*
 * Created on Feb 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerCopyChangeForm extends ActionForm{
    
    private String newUser;
    private String existingUser;
    private String newUserLocation;
    
    private List   operations;
	private String selectedOperation;
    
	private List   changes;
	
	
	private String[] cycles;
	private String[] subCycles;
	private String[] activities;
	
	private String[] selectedCycles = {};
	private String[] selectedSubCycles = {};
	private String[] selectedActivities = {};
	
	
    /**
     * @return Returns the cycles.
     */
    public String[] getCycles() {
        return cycles;
    }
    /**
     * @param cycles The cycles to set.
     */
    public void setCycles(String[] cycles) {
        this.cycles = cycles;
    }
    /**
     * @return Returns the existingUser.
     */
    public String getExistingUser() {
        return existingUser;
    }
    /**
     * @param existingUser The existingUser to set.
     */
    public void setExistingUser(String existingUser) {
        this.existingUser = existingUser;
    }
    /**
     * @return Returns the newUser.
     */
    public String getNewUser() {
        return newUser;
    }
    /**
     * @param newUser The newUser to set.
     */
    public void setNewUser(String newUser) {
        this.newUser = newUser;
    }
    /**
     * @return Returns the operations.
     */
    public List getOperations() {
        return operations;
    }
    /**
     * @param operations The operations to set.
     */
    public void setOperations(List operations) {
        this.operations = operations;
    }
    /**
     * @return Returns the selectedActivities.
     */
    public String[] getSelectedActivities() {
        return selectedActivities;
    }
    /**
     * @param selectedActivities The selectedActivities to set.
     */
    public void setSelectedActivities(String[] selectedActivities) {
        this.selectedActivities = selectedActivities;
    }
    /**
     * @return Returns the selectedCycles.
     */
    public String[] getSelectedCycles() {
        return selectedCycles;
    }
    /**
     * @param selectedCycles The selectedCycles to set.
     */
    public void setSelectedCycles(String[] selectedCycles) {
        this.selectedCycles = selectedCycles;
    }
    /**
     * @return Returns the selectedOperation.
     */
    public String getSelectedOperation() {
        return selectedOperation;
    }
    /**
     * @param selectedOperation The selectedOperation to set.
     */
    public void setSelectedOperation(String selectedOperation) {
        this.selectedOperation = selectedOperation;
    }
    /**
     * @return Returns the selectedSubCycles.
     */
    public String[] getSelectedSubCycles() {
        return selectedSubCycles;
    }
    /**
     * @param selectedSubCycles The selectedSubCycles to set.
     */
    public void setSelectedSubCycles(String[] selectedSubCycles) {
        this.selectedSubCycles = selectedSubCycles;
    }
    /**
     * @return Returns the subCycles.
     */
    public String[] getSubCycles() {
        return subCycles;
    }
    /**
     * @param subCycles The subCycles to set.
     */
    public void setSubCycles(String[] subCycles) {
        this.subCycles = subCycles;
    }
   
    /**
     * @return Returns the activities.
     */
    public String[] getActivities() {
        return activities;
    }
    /**
     * @param activities The activities to set.
     */
    public void setActivities(String[] activities) {
        this.activities = activities;
    }
    /**
     * @return Returns the changes.
     */
    public List getChanges() {
        return changes;
    }
    /**
     * @param changes The changes to set.
     */
    public void setChanges(List changes) {
        
        this.changes = changes;
                
    }
    
    
    public void reset(ActionMapping mapping, HttpServletRequest request){
        
        
        if(selectedCycles != null){

            selectedCycles = new String[0];
        }
        
        if(selectedSubCycles != null){

            selectedSubCycles = new String[0];
        }
        
        if(selectedActivities != null){

            selectedActivities = new String[0];
        }
           
    }
    
    public ActionErrors validate(ActionMapping mapping,HttpServletRequest request){
    	
    	ActionErrors errors = new ActionErrors();
    	
    	if(request.getServletPath().equalsIgnoreCase("/ownerCopyChange.do")){
    	   	if(selectedOperation.equalsIgnoreCase("Select Operation")){
        		errors.add("selectedOperation",new ActionError("adminowner.change.copy.operation.error"));
        	}
    	}
 
    	return errors;
    }
    
    
	/**
	 * @return Returns the newUserLocation.
	 */
	public String getNewUserLocation() {
		return newUserLocation;
	}
	/**
	 * @param newUserLocation The newUserLocation to set.
	 */
	public void setNewUserLocation(String newUserLocation) {
		this.newUserLocation = newUserLocation;
	}
}
