package com.monsanto.wst.soxic.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.facade.reports.OwnerStatusReportFacade;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 20, 2005
 * Time: 12:06:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusReportController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException{
        OwnerStatusReportFacade ownerStatusReportFacade = new OwnerStatusReportFacade();
        try {
            buildSelectionOptions(helper,ownerStatusReportFacade);
        } catch (DatabaseException e) {
            e.printStackTrace();
        }
    }

    public void buildSelectionOptions(UCCHelper helper, OwnerStatusReportFacade ownerStatusReportFacade) throws DatabaseException, IOException {
        ownerStatusReportFacade.buildSelectionCriteria(helper);
    }
}
