package com.monsanto.wst.soxic.audit;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 1:30:59 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class OwnerCyclePK implements Serializable{

  @ManyToOne
  @JoinColumn(name = "OWNER_ID")
  private OwnerObj owner;

  @ManyToOne
  @JoinColumn(name = "CYCLE_ID")
  private CycleObj cycle;

  public OwnerObj getOwner() {
    return owner;
  }

  public void setOwner(OwnerObj owner) {
    this.owner = owner;
  }

  public CycleObj getCycle() {
    return cycle;
  }

  public void setCycle(CycleObj cycle) {
    this.cycle = cycle;
  }

  public OwnerCyclePK() {
  }
}
