package com.monsanto.wst.soxic.ownerStatusReports;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerStatus;
import com.monsanto.wst.soxic.model.OwnerStatusCycleDAO;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;
import com.monsanto.wst.soxic.reportingFramework.SoxAbstractReport;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 22, 2005
 * Time: 10:26:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusCycleReport extends SoxAbstractReport{

    OwnerStatusCycleDAO ownerStatusCycleDAO = new OwnerStatusCycleDAO();
    OwnerStatusXMLBuilder ownerStatusXMLBuilder = new OwnerStatusXMLBuilder();

    public void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException {
        String cycelid = (String) reportParameters.getReportParameter("cycle");
        String reportType="Cycle";
        List subcycles = getSubCyclesForThisCycle(cycelid);
        List reportInfo = new ArrayList();
        Iterator it = subcycles.iterator();
        populateReportOwners(it,reportInfo);
        ownerStatusXMLBuilder.createXMLReport(reportDataElement,reportInfo,reportType);
    }

    private void populateReportOwners(Iterator it, List reportInfo) throws DatabaseException {
        OwnerStatus ownerStatus;
        while(it.hasNext()){
            ownerStatus = new OwnerStatus();
            String subcycleid = (String) it.next();
            ownerStatus.setId(subcycleid);
            ownerStatus.setOwners(getReportInformation(subcycleid));
            reportInfo.add(ownerStatus);
        }
    }

    protected List getReportInformation(String subcycleid) throws DatabaseException {
        return ownerStatusCycleDAO.setByCycleReportInformation(subcycleid);
    }

    protected List getSubCyclesForThisCycle(String cycelid) throws DatabaseException {
        return ownerStatusCycleDAO.getSubCycles(cycelid);
    }
           

    public String returnExportFileNameKey() {
        return "Cycle";
    }

    public void buildFilterXML(Element rootOutputElement) throws DatabaseException {
        //To change body of implemented methods use File | Settings | File Templates.
    }


}
