package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.SignificantChangeFacade;
import com.monsanto.wst.soxic.form.SignificantChangeForm;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 14, 2006
 * Time: 11:41:33 AM
 * To change this template use File | Settings | File Templates.
 */
public interface NoReportingSigChangeInterface {

    public void createNoReportingSignificantChange(SignificantChangeFacade significantChangeFacade, SignificantChangeForm significantChangeForm, String type);

}
