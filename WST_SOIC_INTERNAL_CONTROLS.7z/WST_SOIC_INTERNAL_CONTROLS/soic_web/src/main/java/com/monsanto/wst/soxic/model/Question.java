/*
 * Created on Jan 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Question extends SoxicBaseModel{
	
    private String questionId;
    private String description;
    private String actualAnsType;
    private boolean displayLink=false;
    private String link;
    
	/**
	 * @return Returns the link.
	 */
	public String getLink() {
		return link;
	}
	/**
	 * @param link The link to set.
	 */
	public void setLink(String link) {
		this.link = link;
	}
	/**
	 * @return Returns the displayLink.
	 */
	public boolean isDisplayLink() {
		return displayLink;
	}
	/**
	 * @param displayLink The displayLink to set.
	 */
	public void setDisplayLink(boolean displayLink) {
		this.displayLink = displayLink;
	}
	/**
	 * @return Returns the actualAnsType.
	 */
	public String getActualAnsType() {
		return actualAnsType;
	}
	/**
	 * @param actualAnsType The actualAnsType to set.
	 */
	public void setActualAnsType(String actualAnsType) {
		this.actualAnsType = actualAnsType;
	}
    private int counter;
    
    
	/**
	 * @return Returns the counter.
	 */
	public int getCounter() {
		return counter;
	}
	/**
	 * @param counter The counter to set.
	 */
	public void setCounter(int counter) {
		this.counter = counter;
	}
    // type of question ex: yes/no question or essay question etc...
    private String type;
    
    //each question can contain a list of sub questions based on the answer.
    
    private ArrayList subQuestions;
    
    //private boolean answer;	
    
    private String answer;
   
	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the questionId.
	 */
	public String getQuestionId() {
		return questionId;
	}
	/**
	 * @param questionId The questionId to set.
	 */
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	/**
	 * @return Returns the subQuestions.
	 */
	public ArrayList getSubQuestions() {
		return subQuestions;
	}
	/**
	 * @param subQuestions The subQuestions to set.
	 */
	public void setSubQuestions(ArrayList subQuestions) {
		this.subQuestions = subQuestions;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
    
    /**
     * @TODO need to think about adding the answer to the question object.
     */
    
    public static void main(String[] args) {
    }
    /**
     * @return Returns the answer.
     */
    public String getAnswer() {
        return answer;
    }
    /**
     * @param answer The answer to set.
     */
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getId(){
        return questionId;
    }

    public String getOwnerId(){
        return "";
    }

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
