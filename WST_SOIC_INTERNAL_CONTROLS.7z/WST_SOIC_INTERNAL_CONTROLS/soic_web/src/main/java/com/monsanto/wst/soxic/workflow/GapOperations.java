/*
 * Created on Mar 3, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GapOperations {

	public void setControlObjectiveGap()throws Exception{
		
		List controlObjectiveList = returnControlObjectives();
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		
		while(controlObjectiveListIterator.hasNext()){
			
			String controlObjectiveId = (String)controlObjectiveListIterator.next();
			
			if(isControlObjectiveGapPresent(controlObjectiveId)){
				updateControlObjectiveGap(controlObjectiveId,"Y");
			}else{
				updateControlObjectiveGap(controlObjectiveId,"N");
			}
		}
	}

	public void updateControlObjectiveGap(String controlObjectiveId,String value)throws Exception{

		Connection con = null;

		PreparedStatement updateControlObjectiveDef = null;
	
		try {
			con = getConnection();

			updateControlObjectiveDef = con.prepareStatement("UPDATE CTRL_OBJ CO SET CO.POTENTIAL_GAP=? WHERE CO.CTRL_OBJ_ID=?");
			
			updateControlObjectiveDef.setString(1,value);
			
			updateControlObjectiveDef.setString(2,controlObjectiveId);
			
			updateControlObjectiveDef.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
	
	public boolean isControlObjectiveGapPresent(String controlObjectiveId)throws Exception{
		
		Connection con = null;
		
		int size=0;

		PreparedStatement sizeOfDeficiency = null;
	
		try {
			con = getConnection();

			sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM CTRL_OBJ CO,GAP_DC_LOE GDL,OWNER_RESPONSE ORS,ACTIVITY A WHERE CO.CTRL_OBJ_ID=? AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND A.ACTIVITY_ID=ORS.ASSOCIATED_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID");
			
			sizeOfDeficiency.setString(1,controlObjectiveId);
			
			ResultSet rs = sizeOfDeficiency.executeQuery();
			
			while(rs.next()){
				size = rs.getInt("DEFSIZE");
			}
			
			if(size>0){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

		return false;
	}	
	
	public List returnControlObjectives()throws Exception{
		
		Connection con = null;
		
		List controlObjectiveList = new ArrayList();

		PreparedStatement selectAllControlObjectives = null;
	
		try {
			con = getConnection();

			selectAllControlObjectives = con.prepareStatement("SELECT CTRL_OBJ_ID FROM CTRL_OBJ");
			
			ResultSet rs = selectAllControlObjectives.executeQuery();
			
			while(rs.next()){
				controlObjectiveList.add(rs.getString("CTRL_OBJ_ID"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return controlObjectiveList;
	}
	
	public void setActivityGap()throws Exception{
		
		List activityList = returnActivities();
		
		Iterator activityListIterator = activityList.iterator();
		
		while(activityListIterator.hasNext()){
			
			String activityId = (String)activityListIterator.next();
			
			if(isActivityGapPresent(activityId)){
				updateActivityGap(activityId,"Y");
			}else{
				updateActivityGap(activityId,"N");
			}
		}
	}

	public void updateActivityGap(String activityId,String value)throws Exception{

		Connection con = null;

		PreparedStatement updateActivityGap = null;
	
		try {
			con = getConnection();

			updateActivityGap = con.prepareStatement("UPDATE ACTIVITY A SET A.POTENTIAL_GAP=? WHERE A.ACTIVITY_ID=?");
			
			updateActivityGap.setString(1,value);
			
			updateActivityGap.setString(2,activityId);
			
			updateActivityGap.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
	
	public boolean isActivityGapPresent(String controlObjectiveId)throws Exception{
		
		Connection con = null;
		
		int size=0;

		PreparedStatement sizeOfDeficiency = null;
	
		try {
			con = getConnection();

			sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM GAP_DC_LOE GDL,OWNER_RESPONSE ORS,ACTIVITY A WHERE A.ACTIVITY_ID=? AND A.ACTIVITY_ID=ORS.ASSOCIATED_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID");
			
			sizeOfDeficiency.setString(1,controlObjectiveId);
			
			ResultSet rs = sizeOfDeficiency.executeQuery();
			
			while(rs.next()){
				size = rs.getInt("DEFSIZE");
			}
			
			if(size>0){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

		return false;
	}	
	
	public List returnActivities()throws Exception{
		
		Connection con = null;
		
		List activityList = new ArrayList();

		PreparedStatement selectAllActivities = null;
	
		try {
			con = getConnection();

			selectAllActivities = con.prepareStatement("SELECT ACTIVITY_ID FROM ACTIVITY");
			
			ResultSet rs = selectAllActivities.executeQuery();
			
			while(rs.next()){
				activityList.add(rs.getString("ACTIVITY_ID"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return activityList;
	}	
	
//	public Connection getConnection() throws Exception {
//		Context initContext = new InitialContext();
//		Context envContext = (Context) initContext.lookup("java:/comp/env");
//		DataSource ds = (DataSource) envContext.lookup("jdbc/soxicdb");
//		Connection conn = ds.getConnection();
//		return conn;
//	}	
	
	/**
	 * @return
	 * @throws Exception
	 */
	public Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@tst01.monsanto.com:1521:comgent","sarbox_et","sarbox_et_123");
		return conn;
	}		
}
