package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.model.UtilDAO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2005
 * Time: 2:19:57 PM
 *
 * This class is the facade for the SubCycleMaintenance delete operation.
 * Method countrySelection is used to select the countries.
 * Method initialCycleSelection is used to retrieve cycles based on the country
 * and set it to the first cycle.
 * Method initialSubcylesSelection is used to retrieve the subcycles based
 * on the first cycle.
 * Method performDelete is used to delete the subcycle selected.
 * Method cyclesFromCountry is used to retrieve the cycles based on the
 * country selected by the user.
 * Method subCycleFromCycle is used to retrieve the subcycles based on the
 * cycle selected by the user.
 *
 */

public class SubCycleMaintainFacade {

    private UtilDAO utildao = new UtilDAO();

    /**
     * Selects the countries that have subcycles and the cycles are in
     * INITIATED state.
     * @param subcycledeleteform
     * @throws Exception
     */
    public void countrySelection(SubCycleDeleteForm subcycledeleteform) throws Exception{
    try {
                subcycledeleteform.setCountry(showCountriesForSubCycleMaintenance());

            }
            catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
                System.err.println("Could not get country List due" + e);
                e.printStackTrace();
            }
    }

    public List showCountriesForSubCycleMaintenance() throws Exception{
        return utildao.getCountriestodelete();
    }


    /**
     * Retrieves the list of cycles and then selects the first country.
     * @param subcycledeleteform
     * @throws Exception
     */
    public void initialCycleSelection(SubCycleDeleteForm subcycledeleteform) throws Exception{
            List countries = subcycledeleteform.getCountry();
            String countrysel = String.valueOf(countries.get(0));
            subcycledeleteform.setSelectedCountry(countrysel);
            try {
                    subcycledeleteform.setCycles(cyclesBasedOnCountry(countrysel));
            }
                catch (Exception e) {
                if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
                }
                    System.err.println("Could not get cycle List due to" + e);
                    e.printStackTrace();
                }
    }

    public List cyclesBasedOnCountry(String countrysel) throws Exception{
        return utildao.getCyclesfromCountry(countrysel);
    }


    /**
     * Retrieves the List of subcycles based on the first cycle.
     * @param subcycledeleteform
     * @throws Exception
     */
    public void initialSubcylesSelection(SubCycleDeleteForm subcycledeleteform) throws Exception{
            List cycleList = subcycledeleteform.getCycles();
            String selcycle = String.valueOf(cycleList.get(0));
            subcycledeleteform.setSelectedCycles(selcycle);
            try {
                    subcycledeleteform.setSubcycle(subCyclesBasedOnCycle(selcycle));
            }catch (Exception e) {
             if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
                    System.err.println("Could not get subcycle List due to" + e);
                    e.printStackTrace();
            }
    }

    public List subCyclesBasedOnCycle(String selcycle) throws Exception{
        return utildao.getSubCyclesfromCycles(selcycle);
    }


    /**
     * Retrieves the cycles based on the country selected by the user
     * @param subcycledeleteform
     * @param countryid
     * @throws Exception
     */
    public void cyclesFromCountry(SubCycleDeleteForm subcycledeleteform, String countryid) throws Exception{
        try {
                    subcycledeleteform.setCycles(cyclesBasedOnCountry(countryid));

                }
                catch (Exception e) {
                if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
                }
                    System.err.println("Could not get cycle List due" + e);
                    e.printStackTrace();
                }
    }


    /**
     * Retrieves the subcycles based on the cycle selected by the user
     * @param subcycledeleteform
     * @param cycleid
     * @throws Exception
     */
    public void subCycleFromCycle(SubCycleDeleteForm subcycledeleteform, String cycleid) throws Exception{
        try {
                subcycledeleteform.setSubcycle(subCyclesBasedOnCycle(cycleid));

            }
            catch (Exception e) {
                if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
                }
                System.err.println("Could not get subcycle List due to" + e);
                e.printStackTrace();
            }
    }


    /**
     * Deletes the subcycle selected by the user
     * @param subcycleid
     * @throws Exception
     */
    public void performDelete(String subcycleid) throws Exception{
        deleteSubCycleSelected(subcycleid);
    }

    protected void deleteSubCycleSelected(String subcycleid) throws Exception{
        utildao.deleteSubcycles(subcycleid);
    }

  public boolean isSubCycleCertificationComplete(String subCycleId) throws Exception{
    List<String> subcycleStatusList = utildao.getOwnerSubCycleStatus(subCycleId);
    return isCertificationComplete(subcycleStatusList);
  }

  private boolean isCertificationComplete(List<String> subcycleStatusList) {
    for(String subCycleStatus: subcycleStatusList){
      if("G_COMPLETE".equalsIgnoreCase(subCycleStatus)){
        return true;
      }
    }
    return false;
  }
}
