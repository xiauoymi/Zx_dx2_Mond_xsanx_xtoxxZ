/*
 * Created on Feb 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionError;

import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFacade;
import com.monsanto.wst.soxic.model.headerFooter.CycleHeadFootFacade;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicPathUtil;
import com.monsanto.wst.soxic.action.StatusHelper;

import javax.servlet.http.HttpServletRequest;

/**
 * @author SPOLAVA
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class CycleViewForm extends ActionForm {

	private List cycles;

	private LinkedHashSet periodCycleAssociation;

	private String showCycle;

	private String showSubCycle;

	private String period;

    private String questionHeader;

    private String questionFooter;

    StatusHelper statusHelper = new StatusHelper();

   public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		String path = request.getServletPath();

		if (!path.equalsIgnoreCase("/populateCycleAction.do") && !path.equalsIgnoreCase("/cycleView.do")) {
            String cycleIdSelected = SoxicPathUtil.getKey(request, "submit");
            if(cycles!=null){
                Iterator iterator = cycles.iterator();

                while(iterator.hasNext()){
                    Cycle cycle = (Cycle) iterator.next();
                    if(cycleIdSelected!=null & cycle.getCycleId().equalsIgnoreCase(cycleIdSelected)){
                        Iterator questionIterator = cycle.getQuestions().iterator();

                        while(questionIterator.hasNext()){
                            QuestionNew questionNew = (QuestionNew) questionIterator.next();
                            if(questionNew.getAnswer()==null || questionNew.getAnswer().length()==0){
                                errors.add("age", new ActionError(
                                        "errors.required.answer"));
                                break;
                            }
                        }
                    }
                }
            }
		}

		return errors;

	}

	/**
	 * @return Returns the cycles.
	 */
	public List getCycles() {
		return cycles;
	}

	/**
	 * @param cycles
	 *            The cycles to set.
	 */
	public void setCycles(List cycles) {
		this.cycles = cycles;
	}

	/**
	 * @return Returns the showCycle.
	 */
	public String getShowCycle() {
		return showCycle;
	}

	/**
	 * @param showCycle
	 *            The showCycle to set.
	 */
	public void setShowCycle(String showCycle) {
		this.showCycle = showCycle;
	}

	/**
	 * @return Returns the showSubCycle.
	 */
	public String getShowSubCycle() {
		return showSubCycle;
	}

	/**
	 * @param showSubCycle
	 *            The showSubCycle to set.
	 */
	public void setShowSubCycle(String showSubCycle) {
		this.showSubCycle = showSubCycle;
	}

	public void setCycleToShow(String cycleId) {

		if (cycles != null && cycleId != null && cycleId.length() > 1) {

			Cycle cycle = getCycle(cycleId);

			if (cycle != null) {
				cycle.setShow(!cycle.isShow());
			}
		}
	}

	private Cycle getCycle(String cycleId) {

		Iterator itr = cycles.iterator();

		while (itr.hasNext()) {

			Cycle cycle = (Cycle) itr.next();

			if (cycle.getCycleId().equalsIgnoreCase(cycleId)) {
				return cycle;
			}
		}

		return null;
	}

	public void setSubCycleToShow(String subCycleId) {

		if (cycles != null && subCycleId != null & subCycleId.length() > 1) {

			String cycleId = getCycleId(subCycleId);
			SubCycle subCycle = getSubCycle(subCycleId, getCycle(cycleId));

			if (subCycle != null) {
				subCycle.setShow(!subCycle.isShow());
			}
		}
	}

	private SubCycle getSubCycle(String subCycleId, Cycle cycle) {

		if (subCycleId != null && cycle != null) {
			Iterator itr = cycle.getSubCycles().iterator();

			while (itr.hasNext()) {
				SubCycle subCycle = (SubCycle) itr.next();

				if (subCycle.getSubCycleId().equalsIgnoreCase(subCycleId)) {
					return subCycle;
				}
			}
		}

		return null;
	}

	private String getCycleId(String subCycleId) {

		return subCycleId.substring(0, subCycleId.lastIndexOf("."));
	}

	/**
	 * @return Returns the periodCycleAssociation.
	 */
	public LinkedHashSet getPeriodCycleAssociation() {
		return periodCycleAssociation;
	}

	/**
	 * @param cyclePeriodAssociation
	 *            The periodCycleAssociation to set.
	 */
	public void setPeriodCycleAssociation(LinkedHashSet cyclePeriodAssociation) {
		this.periodCycleAssociation = cyclePeriodAssociation;
	}

	public String getDefaultPeriod() {

		if (periodCycleAssociation != null && !periodCycleAssociation.isEmpty())
			return periodCycleAssociation.toArray()[0].toString();

		return "";
	}

	/**
	 * @return Returns the period.
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period
	 *            The period to set.
	 */
	public void setPeriod(String period) {
		this.period = period;
	}

    public String getQuestionHeader() {
        return questionHeader;
    }

    public void setQuestionHeader(String questionHeader) {
        this.questionHeader = questionHeader;
    }

    public String getQuestionFooter() {
        return questionFooter;
    }

    public void setQuestionFooter(String questionFooter) {
        this.questionFooter = questionFooter;
    }

    public void setLinkOnSubmit(String cycleId) {

		Iterator cycleIterator = cycles.iterator();

		while (cycleIterator.hasNext()) {

			Cycle cycle = (Cycle) cycleIterator.next();

			Iterator questionIterator = cycle.getQuestions().iterator();

			while (questionIterator.hasNext()) {

				QuestionNew questionNew = (QuestionNew) questionIterator.next();

				if (questionNew.getAnswer().equalsIgnoreCase(
						SoxicConstants.NORESPONSE)) {

					questionNew.setDisplayLink(true);

					questionNew.setLink(cycle.getCycleId() + SoxicUtil.getSeperator()
							+ questionNew.getQuestionId() + SoxicUtil.getSeperator() +"C");

                    String status = CycleStatusDAO.getStatusForQuestionWithOwnerAndId(questionNew.getQuestionId(),questionNew.getOwnerId(),questionNew.getAssociatedId());
                    if (status.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                        questionNew.setStatus(SoxicConstants.GREEN_COMPLETE);
                    }
                    else
                    if(cycle.getDueDate()!=null && cycle.getDueDate().length()>0){
						questionNew.setStatus(SoxicUtil
								.returnStatusPreceedingStr(cycle.getDueDate())
								+ "INPROC");
					}
				}
			}
		}
	}

	public void setLink() {
		
		if(cycles!=null){
			Iterator cycleIterator = cycles.iterator();
	
			while (cycleIterator.hasNext()) {
	
				Cycle cycle = (Cycle) cycleIterator.next();

                Iterator questionIterator = cycle.getQuestions().iterator();
	
				while (questionIterator.hasNext()) {
	
					QuestionNew questionNew = (QuestionNew) questionIterator.next();
	
					if (questionNew.getAnswer().equalsIgnoreCase(
							SoxicConstants.NORESPONSE)) {
	
						questionNew.setDisplayLink(true);
	
						questionNew.setLink(cycle.getCycleId() + SoxicUtil.getSeperator()
								+ questionNew.getQuestionId() + SoxicUtil.getSeperator()+"C");

                        String status = CycleStatusDAO.getStatusForQuestionWithOwnerAndId(questionNew.getQuestionId(),questionNew.getOwnerId(),questionNew.getAssociatedId());
                        if (status.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                            questionNew.setStatus(SoxicConstants.GREEN_COMPLETE);
                        }
                        else
                        if(cycle.getDueDate()!=null && cycle.getDueDate().length()>0){
						    questionNew.setStatus(SoxicUtil
								.returnStatusPreceedingStr(cycle.getDueDate())
							+ "INPROC");
                        }
					}
				}
	
			}
		}
	}

    public void setSigChangeStatus(String ownerId) {
        if(cycles!=null){
			Iterator cycleIterator = cycles.iterator();
			while (cycleIterator.hasNext()) {
				Cycle cycle = (Cycle) cycleIterator.next();
                String status = CycleStatusDAO.getSigChangeStatus(cycle.getCycleId(),ownerId);
                if (status==null){
                    cycle.setSignificantStatus(SoxicConstants.GREEN_IMPORTED);
                }else
                {
                    cycle.setSignificantStatus(status);
                }

            }
        }
    }

    public void setStatus(HttpServletRequest request, String ownerId) {
        if(cycles!=null){
			Iterator cycleIterator = cycles.iterator();
			while (cycleIterator.hasNext()) {
				Cycle cycle = (Cycle) cycleIterator.next();
                String status = CycleStatusDAO.getCycleOwnerStatus(cycle.getCycleId(),ownerId);
                cycle.setStatus(status);
            }
        }
    }

    public void setHeaderAndFooter(String level) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(level);
        if(cycles!=null){
			Iterator cycleIterator = cycles.iterator();
			while (cycleIterator.hasNext()) {
				Cycle cycle = (Cycle) cycleIterator.next();
                cycle.setQuestionHeader(headerFooterFacade.getHeader());
                cycle.setQuestionFooter(headerFooterFacade.getFooter());
            }
        }
    }


}