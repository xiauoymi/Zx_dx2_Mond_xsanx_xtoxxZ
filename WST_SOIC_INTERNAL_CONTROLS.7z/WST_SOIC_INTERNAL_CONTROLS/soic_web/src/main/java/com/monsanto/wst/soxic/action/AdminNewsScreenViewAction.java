//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.AdminNewsScreenViewForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

/** 
 * MyEclipse Struts
 * Creation date: 04-01-2005
 * 
 * XDoclet definition:
 * @struts:action path="/adminNewsScreenView" name="adminNewsScreenViewForm" scope="request"
 */
public class AdminNewsScreenViewAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
    int currentEditID;
    
    //**To record whether last command was edit/add for Save-and-Submit.
    String prevCommand;
    
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		AdminNewsScreenViewForm adminNewsScreenViewForm = (AdminNewsScreenViewForm) form;
		
		Vector adminNewsVector = new Vector();
		
		ActionErrors errors = new ActionErrors();
		
		Vector allRoles = new Vector();
		
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			Connection con = SoxicConnectionFactory.getSoxicConnection();
		 	
		 	logger.info("Connected to DB from /admin-Report-screen.");
		 
		 	PreparedStatement getAllNews;
		 	PreparedStatement getActiveNewsRoles;
		 	
		 	PreparedStatement getReport;
		 	PreparedStatement getAllRoles;
		 	
		 	PreparedStatement getNewsInfo;
		 	
		 	PreparedStatement deleteNews1;
		 	PreparedStatement deleteNews2;
		 	
		 	PreparedStatement updateNewsInfo;
		 	
		 	PreparedStatement deleteNewsRoles;
		 	PreparedStatement addNewNewsRoles;
		 	
		 	PreparedStatement getNewsSeqNextVal;
		 	
		 	PreparedStatement addNews;
		 	
		 	//**News_seq.nextval...
		 	int news_seq_val = 0;
		 	
		 	getAllNews = con.prepareStatement
					("SELECT " +
							"N.NEWS_ID, N.SUBJECT, N.BODY " +
						"FROM " +
							"News N " +
						"ORDER BY N.NEWS_ID");
		 	
		 	getActiveNewsRoles = con.prepareStatement
				("SELECT " +
					"NR.ROLE_ID " +
				"FROM " +
					"NEWS N, NEWS_ROLE NR " +
				"WHERE " +
					"N.NEWS_ID = NR.NEWS_ID AND " +
					"N.NEWS_ID = ?");
		 	
		 	getNewsInfo = con.prepareStatement
				("SELECT " +
					"N.NEWS_ID, N.SUBJECT, N.BODY " +
				"FROM " +
					"NEWS N " +
				"WHERE N.NEWS_ID = ?");
		 	
		 	//**With the check for NEWS_ROLE name...
//		 	getAllRoles = con.prepareStatement
//				("SELECT " +
//					"ROLE_ID " +
//				"FROM " +
//					"ROLE " +
//					"WHERE " +
//					"NAME = 'NEWS_ROLE' ORDER BY ROLE_ID");
		 	
		 	//**Without the check for NEWS_ROLE name...(as per new req.)
		 	getAllRoles = con.prepareStatement
				("SELECT " +
						"ROLE_ID " +
					"FROM " +
						"ROLE " +
					"ORDER BY ROLE_ID");
		 	
		 	deleteNews1 = con.prepareStatement
				("DELETE FROM NEWS_ROLE WHERE NEWS_ID = ?");
		 	
		 	deleteNews2 = con.prepareStatement
				("DELETE FROM NEWS WHERE NEWS_ID = ?");
		 	
		 	updateNewsInfo = con.prepareStatement
				("UPDATE NEWS " +
					"SET SUBJECT = ?, BODY = ? " +
				"WHERE NEWS_ID = ?");
		 	
		 	deleteNewsRoles = con.prepareStatement
				("DELETE FROM NEWS_ROLE WHERE NEWS_ID = ?");
		 	
		 	addNewNewsRoles = con.prepareStatement
				("INSERT INTO NEWS_ROLE (NEWS_ID, ROLE_ID) " +
						"VALUES (?, ?)");
		 	
		 	getNewsSeqNextVal = con.prepareStatement("Select news_seq.nextval from dual");
		 	
		 	addNews = con.prepareStatement("INSERT INTO NEWS " +
		 							"(NEWS_ID, SUBJECT, BODY, MOD_DATE, MOD_USER) " +
		 							"VALUES (?, ?, ?, ?, ?)");
		 	
		 	//**If save and submit is clicked...
		 	if(adminNewsScreenViewForm.getEditNewsObj().getReportName() != null){
		 		logger.info("You clicked save & submit !!!");
		 		
		 		
		 		//**Validate the empty text box/text area etc...		 		
		 		//**Add it to database...(name and desc)...(to be checked...)
		 		ResultSet rs5;
		 		
		 		AdminReportObject editObj = adminNewsScreenViewForm.getEditNewsObj();
		 		
		 		String rptName = editObj.getReportName();
		 		String rptDesc = editObj.getReportDesc();
		 		
		 		if(!rptName.equals("")){		 			
		 			if(!rptDesc.equals("")){
		 				if(prevCommand.equals("edit")){	
		 					updateNewsInfo.setString(1, rptName);
		 					updateNewsInfo.setString(2, rptDesc);
		 					updateNewsInfo.setInt(3, currentEditID);
		 		
		 					updateNewsInfo.executeUpdate();
		 				}
		 				if(prevCommand.equals("add")){
		 					
		 					//**Insert new rec...
		 					ResultSet rs9;
		 					
		 					rs9 = getNewsSeqNextVal.executeQuery();
		 					
		 					while(rs9.next()){
		 						news_seq_val = rs9.getInt("nextval");
		 					}
		 					
		 					Date todaysDate = new Date(System.currentTimeMillis());
		 					
		 					//**Add...
		 					addNews.setInt(1, news_seq_val);
		 					addNews.setString(2, rptName);
		 					addNews.setString(3, rptDesc);
		 					addNews.setDate(4, todaysDate);
		 					addNews.setString(5, "rdesai2");
		 					
		 					addNews.executeUpdate();
		 					
		 				}
		 			}
		 			else{
		 				logger.error("Cannot Update ('SARBOX_ET.News.Body') to NULL");
			 			
		 				errors.add("newsBody", new ActionError("errors.news.body.null"));
			 		
		 				adminNewsScreenViewForm.setDisplayTable2(true);
		 			}
		 		}
		 		else{
		 			logger.error("Cannot Update ('SARBOX_ET.News.Subject') to NULL");
		 			
		 			errors.add("title", new ActionError("errors.news.name.null"));
		 		
		 			adminNewsScreenViewForm.setDisplayTable2(true);
		 		}
		 		
		 		
		 		//**Add it to database...(selected roles)...		 		
		 		//**Delete existing roles and add new ones....
		 		
		 		if(errors.isEmpty()){
		 			String[] selectedRoles = adminNewsScreenViewForm.getRolesSelected();		 		
		 		
		 			if(selectedRoles != null){
		 				if(prevCommand.equals("edit")){	
		 					deleteNewsRoles.setInt(1, currentEditID);		 		
				 			deleteNewsRoles.executeUpdate();
		 					
		 					for(int i = 0; i < selectedRoles.length; i++){		 		
		 						addNewNewsRoles.setInt(1, currentEditID);
		 						addNewNewsRoles.setString(2, selectedRoles[i]);
		 			
		 						addNewNewsRoles.executeUpdate();		 			
		 					}
		 				}
		 				if(prevCommand.equals("add")){
		 					
		 					//**Add new roles with new-seq-generated news_id...
		 					for(int i = 0; i < selectedRoles.length; i++){		 		
		 						addNewNewsRoles.setInt(1, news_seq_val+1);
		 						addNewNewsRoles.setString(2, selectedRoles[i]);
		 			
		 						addNewNewsRoles.executeUpdate();		 			
		 					}
		 					
		 				}
		 			}
		 		}
		 			
		 	}
		 	
		 	
		 	String action = getActionType(request.getParameterMap());		 	
		 	//**If edit was clicked...
		 	if (action.equalsIgnoreCase("edit")) {

		 		//**Do some separate handling, set form variables and display using Logic tags�.		 		
		 		
		 		int editRepID = Integer.parseInt(request.getParameter("edit").toString());
				
		 		currentEditID = editRepID;
		 		
		 		//logger.info("You clicked edit !!!" + editRepID);
		 		
		 		AdminReportObject editRepObj = new AdminReportObject();
		 		
		 		ResultSet rs4;
		 		
		 		getNewsInfo.setInt(1, editRepID);
		 		
		 		rs4 = getNewsInfo.executeQuery();
		 		
		 		while(rs4.next()){
		 			editRepObj.setReportID(rs4.getInt("NEWS_ID"));
		 			editRepObj.setReportName(rs4.getString("SUBJECT"));
		 			editRepObj.setReportDesc(rs4.getString("BODY"));
		 		}
		 				 		
		 		adminNewsScreenViewForm.setEditNewsObj(editRepObj);
		 		
		 		prevCommand = "edit";
		 		
		 		//return mapping.findForward("success");
		 	}
		 	
		 	if (action.equalsIgnoreCase("delete")) {
		 		
		 		int delRepID = Integer.parseInt(request.getParameter("delete").toString());
				
		 		deleteNews1.setInt(1, delRepID);		 				 		
		 		deleteNews1.executeUpdate();
		 		
		 		deleteNews2.setInt(1, delRepID);		 				 		
		 		deleteNews2.executeUpdate();
		 		
		 		logger.info("You clicked delete !!!" + delRepID);
		 	}
		 	
//		 	if (action.equalsIgnoreCase("save_submit")) {
//		 		
//		 		int saveRepID = Integer.parseInt(request.getParameter("save_submit").toString());
//				
//		 		logger.info("You clicked save & submit !!!" + saveRepID);
//		 	}
		 	
		 	if(action.equalsIgnoreCase("reset") || action.equalsIgnoreCase("edit") || !errors.isEmpty()){
		 		adminNewsScreenViewForm.setDisplayTable2(true);
		 	}
		 	else{
		 		adminNewsScreenViewForm.setDisplayTable2(false);
		 	}
		 	
		 	if (action.equalsIgnoreCase("add")) {
		 		
		 		logger.info("You clicked add !!!");
		 		
		 		//**Add new News...
		 		AdminReportObject addObj = new AdminReportObject();
		 		
		 		//**Reset all the fields...
		 		addObj.setReportName("");
		 		addObj.setReportDesc("");
		 		
		 		adminNewsScreenViewForm.setEditNewsObj(addObj);
		 		
		 		adminNewsScreenViewForm.setDisplayTable2(true);
		 		
		 		prevCommand = "add";
		 	}
		 	
		 	ResultSet rs1 = getAllNews.executeQuery();
		 	
		 	int orderNo = 0;
		 	while(rs1.next()){
		 		
		 		orderNo++;
		 		
		 		AdminReportObject repObj = new AdminReportObject();
		 		
		 		repObj.setOrderNumber(orderNo);
		 		repObj.setReportID(rs1.getInt("NEWS_ID"));
		 		repObj.setReportName(rs1.getString("SUBJECT"));
		 		repObj.setReportDesc(rs1.getString("BODY"));
		 		
		 		ResultSet rs2;
		 		
		 		getActiveNewsRoles.setInt(1, rs1.getInt("NEWS_ID"));
		 		
		 		rs2 = getActiveNewsRoles.executeQuery();
		 		
		 		Vector roles = new Vector();
		 		
		 		while(rs2.next()){
		 			roles.add(rs2.getString("ROLE_ID"));
		 		}
		 		
		 		repObj.setReportRoles(roles);
		 		
		 		adminNewsVector.add(repObj);
		 	}
		 	
		 	ResultSet rs3;
		 	
		 	rs3 = getAllRoles.executeQuery();
		 	
		 	while(rs3.next()){
		 		allRoles.add(rs3.getString("ROLE_ID"));
		 	}	
		 	
		 	adminNewsScreenViewForm.setAllRoles(allRoles);
			adminNewsScreenViewForm.setAdminNewsVector(adminNewsVector);
			
		 	
		 		
		}
		catch(Exception ex){
			logger.fatal("Database error from admin report screen action " + ex.getMessage());
		}
		
		if(errors.isEmpty()){
			
			return mapping.findForward("success");
		}
		else{
			saveErrors(request, errors);
			return mapping.findForward("faliure");
		}
		
	}
	
		//**Helper Function to get the button clicked...
		public String getActionType(Map parameterMap) {

				String action = null;

				String[] valueArr = null;

				Iterator iter = parameterMap.keySet().iterator();

				while (iter.hasNext()) {

					Object key = iter.next();

					Object value = parameterMap.get(key);

					valueArr = (String[]) value;

					if (((String) key).equalsIgnoreCase("edit")) {

						return "edit";
					}

					if (((String) key).equalsIgnoreCase("delete")) {

						return "delete";
					}
					
					if (((String) key).equalsIgnoreCase("save_submit")) {

						return "save_submit";
					}
					
					if (((String) key).equalsIgnoreCase("reset")) {

						return "reset";
					}
					
					if (((String) key).equalsIgnoreCase("add")) {

						return "add";
					}
				}
				return "type";
		}

}