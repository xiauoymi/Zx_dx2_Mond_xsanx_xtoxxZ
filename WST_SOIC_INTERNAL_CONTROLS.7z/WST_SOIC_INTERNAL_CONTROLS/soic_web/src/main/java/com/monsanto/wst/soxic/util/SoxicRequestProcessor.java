/*
 * Created on Apr 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.RequestProcessor;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class SoxicRequestProcessor extends RequestProcessor {

	protected boolean processPreprocess(HttpServletRequest request,
			HttpServletResponse response) {
		// Check if user is logged in.
		// If so return true to continue processing,
		// otherwise return false to not continue processing.
		if(request.getServletPath().equalsIgnoreCase("/login.do")){
			return true;
		}
		if(request.getSession().getAttribute(SoxicConstants.OWNER)!=null){
			return true;
		}
		try{
			doForward("/login.do",request,response);
		}catch(Exception e){
			e.printStackTrace();
		}
		return (false);
	}
}