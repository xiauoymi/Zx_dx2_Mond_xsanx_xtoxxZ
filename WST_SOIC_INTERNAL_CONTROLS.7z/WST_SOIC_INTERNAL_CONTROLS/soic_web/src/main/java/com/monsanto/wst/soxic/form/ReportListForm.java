//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import org.apache.struts.action.ActionForm;

/** 
 * MyEclipse Struts
 * Creation date: 02-24-2005
 * 
 * XDoclet definition:
 * @struts:form name="reportListForm"
 */
public class ReportListForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	Vector reportList = new Vector();
    boolean reportview;

	// --------------------------------------------------------- Methods
	/**
	 * @return Returns the reportList.
	 */
	public Vector getReportList() {
		return reportList;
	}
	/**
	 * @param reportList The reportList to set.
	 */
	public void setReportList(Vector reportList) {
		this.reportList = reportList;
	}

    public boolean isReportview() {
        return reportview;
    }

    public void setReportview(boolean reportview) {
        this.reportview = reportview;
    }


	/**
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

	
	
}