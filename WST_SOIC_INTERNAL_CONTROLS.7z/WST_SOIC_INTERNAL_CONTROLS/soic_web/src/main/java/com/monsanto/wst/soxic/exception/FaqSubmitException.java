package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 12, 2006
 * Time: 10:18:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class FaqSubmitException extends Exception {

    public FaqSubmitException(String message) {
        super(message);    
    }
}
