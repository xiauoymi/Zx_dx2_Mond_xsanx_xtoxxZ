package com.monsanto.wst.soxic.audit.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 23, 2009
 * Time: 9:25:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class CategoryPopulator {
  public static Map<String,String> populateUserCatMap(Map userCatMap) {
      if(userCatMap == null){
      userCatMap = new HashMap<String,String>();
      //FIN
      userCatMap.put("FIN-Comply w/ Law & Contract","1275068481");
      userCatMap.put("FIN-Account Rec & Classification","1275068487");
      userCatMap.put("FIN-Revenue/Receivables","1275068472");
      userCatMap.put("FIN-Approval","1275068422");
      userCatMap.put("FIN-FCPA & Management Practices","1275068456");
      userCatMap.put("FIN-General Ledger","1275068460");
      userCatMap.put("FIN-Account Rec & Classification","1275068487");
      userCatMap.put("FIN-Inventory - Seed","1275068463");
      userCatMap.put("FIN-Delegation of Authority","67108959");
      userCatMap.put("FIN-Asset Valuation/Timing","1275068510");
      userCatMap.put("FIN-Timing","1275068488");
      userCatMap.put("FIN-Procurement","1275068470");
      userCatMap.put("FIN-Segregation of Duty","67108960");
      userCatMap.put("FIN-Contracts","1275068450");
      userCatMap.put("FIN-Comply w/ Law & Contract","1275068481");
      userCatMap.put("FIN-Inventory","1275068464");
      userCatMap.put("FIN-Other","1476395588");
      userCatMap.put("FIN-Asset Valuation/Timing","1275068510");
      //test
      userCatMap.put("FIN-Delegation of Authority","67108959");
      userCatMap.put("FIN - Asset Safeguarding","1275068510");
      userCatMap.put("FIN - Reconciliation and Review","1275068487");
      //IT
//      userCatMap.put("IT-Windows Security","1275068478");
      userCatMap.put("IT-Process Control","1275068469");
      userCatMap.put("IT-SAP Security","1275068473");
      userCatMap.put("IT-System Development & Maint.","1275068474");
      userCatMap.put("IT-Database Security - ORACLE","1677721597");
//      userCatMap.put("IT-Backup & Recovery","1275068449");
      userCatMap.put("IT-Exchange","1275068458");
//      userCatMap.put("IT-Network","1275068466");
      userCatMap.put("IT-Database Security - SQL","-1677721598");
      userCatMap.put("IT-Wireless Networking","1275068479");

      //Added newly
      userCatMap.put("IT-Policies & Standards","1275068519");
      userCatMap.put("IT-Physical Security","1275068520");
      userCatMap.put("IT-Windows Security","1275068523");
      userCatMap.put("IT-Backup, Recovery","1275068512");
      userCatMap.put("IT-Policies & Standards","1275068519");
      userCatMap.put("IT-Database Security","1275068516");
      userCatMap.put("IT-Network Security","1275068518");
      userCatMap.put("IT-UNIX/LINUX Security","1275068522");
      userCatMap.put("IT-Application Development","1476395524");
      userCatMap.put("IT-Management Practices","1275068517");
      userCatMap.put("IT-Electronic Data Security","1476395526");
      userCatMap.put("IT-Application Security","1275068513");

    }
    return userCatMap;
  }
  
}
