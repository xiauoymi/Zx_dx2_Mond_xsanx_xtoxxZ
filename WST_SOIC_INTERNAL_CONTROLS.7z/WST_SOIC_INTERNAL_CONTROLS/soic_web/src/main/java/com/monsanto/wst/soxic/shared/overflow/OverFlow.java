package com.monsanto.wst.soxic.shared.overflow;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.*;
import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 24, 2005
 * Time: 2:59:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class OverFlow {

    private String overFlowId="0";
    private List sequenceTextList=new ArrayList();
    private String firstTwoThousandCharacters;
    private String originalString;
    private Map sequenceMap=new HashMap();

    public OverFlow(String originalString) throws Exception {
        this.originalString = originalString;
        processChunking();
        insertOverFlow();
        insertOverFlowTextIntoDB();
    }

    public OverFlow(String overFlowId, String firstTwoThousandCharacters) {
        this.overFlowId = overFlowId;
        this.firstTwoThousandCharacters = firstTwoThousandCharacters;
    }

    protected void insertOverFlowTextIntoDB() throws Exception {
        OverFlowUtilDAO overFlowUtilDAO = new OverFlowUtilDAO();
        overFlowUtilDAO.insertOverFlowIntoDB(this);
    }

    private void processChunking() {
        if(originalString.length()<=2000){
            firstTwoThousandCharacters = originalString;
        }else{
            firstTwoThousandCharacters = originalString.substring(0, 2000);
            for(int index = 2000; index < originalString.length(); index = index + 2000){
                if(index + 2000 <= originalString.length()){
                    SequenceText sequenceText = new SequenceText(originalString.substring(index, index + 2000));
                    sequenceTextList.add(sequenceText);
                }
                else{
                    SequenceText sequenceText = new SequenceText(originalString.substring(index, originalString.length()));
                    sequenceTextList.add(sequenceText);
                }
            }
        }

    }

    public String getOverFlowId() {
        return overFlowId;
    }

    public List getSequenceTextList() {
        return sequenceTextList;
    }

    public String getFirstTwoThousandCharacters() {
        return firstTwoThousandCharacters;
    }

    protected int insertOverFlow() throws Exception {
        Connection connection = SoxicConnectionFactory.getSoxicConnection();
        int result=-1;
        if(sequenceTextList.size()>0){
            OverFlowUtilDAO overFlowUtilDAO = new OverFlowUtilDAO();
            int sequence = overFlowUtilDAO.nextSequence(connection).intValue();
            overFlowId = ""+sequence;
            setSequence(sequence);
        }

        if (connection != null) {
            connection.close();
        }

        return result;
    }

    private void setSequence(int startSequence){
        Iterator iterator = sequenceTextList.iterator();
        while(iterator.hasNext()){
            SequenceText sequenceText = (SequenceText) iterator.next();
            sequenceText.setSequence(""+startSequence);
            startSequence++;
        }
    }

   public void addToSequenceMap(String sequence,String text){
        if(sequence!=null && sequenceMap.get(sequence)==null){
            SequenceText sequenceText = new SequenceText(sequence,text);
            sequenceMap.put(sequence,sequenceText);
        }
    }

    public String buildOriginalString(){
        sequenceTextList.addAll(sequenceMap.values());
        Collections.sort(sequenceTextList);
        Iterator iterator = sequenceTextList.iterator();
        originalString=firstTwoThousandCharacters;
        while(iterator.hasNext()){
            SequenceText sequenceText = (SequenceText) iterator.next();
            String chunk=sequenceText.getText();
            originalString=originalString+chunk;
        }
        return originalString;
    }    
}

