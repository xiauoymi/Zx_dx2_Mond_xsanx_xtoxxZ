package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.facade.CycleOnlyConstants;
import com.monsanto.wst.soxic.model.AdminOwnerEntity;
import com.monsanto.wst.soxic.model.CycleOnlyCertDAO;
import com.monsanto.wst.soxic.util.MiscUtils;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 6, 2006
 * Time: 9:23:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class CycleOnlyAdminOwner {

    CycleOnlyCertDAO cycleOnlyCertDAO = new CycleOnlyCertDAO();
    private static final String OWNER_ACTIVITY = "ACTIVITY";
    private static final String OWNER_SUBCYCLE = "SUBCYCLE";
    private static final String ADMIN_ENTITY_DASH = "----";
    Date currentDate = new Date(System.currentTimeMillis());
    SimpleDateFormat sdf = new SimpleDateFormat(CycleOnlyConstants.DATE_FORMAT);

    public boolean checkForPeriodOnlyCertification(String period) {
        if (getCycleOnlyDataFromPeriod(period)){
            return true;
        }
        else return false;
    }

    protected boolean getCycleOnlyDataFromPeriod(String period) {
        return cycleOnlyCertDAO.checkForPeriodStatus(period);
    }

    public String getTokenizedCycle(String id) {
        String cycle = "";
        String country = "";
        String period = "";
        StringTokenizer st = new StringTokenizer(id,".");
        for (int i=0;i<3;i++){
            period = getPeriod(i, st, period);
            country = getTokenizedCountry(i, st, country);
            cycle = getTokenizedCycleCode(i, st, cycle);
        }
        return period+"."+country+"."+cycle;
    }

    private String getTokenizedCycleCode(int i, StringTokenizer st, String cycle) {
        if (i==2){
            cycle = st.nextToken();
        }
        return cycle;
    }

    private String getTokenizedCountry(int i, StringTokenizer st, String country) {
        if (i==1){
            country = st.nextToken();
        }
        return country;
    }

    private String getPeriod(int i, StringTokenizer st, String period) {
        if (i==0){
            period = st.nextToken();
        }
        return period;
    }

    private String setStateForAllowableUsers(AdminOwnerEntity entity, String period) {
        String status;
        String cycleId = getTokenizedCycleBasedOnType(entity);
        period = getPeriodBasedOnStatus(entity, period);
        if (checkForPeriodOnlyCertification(period)){
            status = setStateBasedOnCycleState(cycleId);
        }
        else{
            status = SoxicConstants.GREEN_IMPORTED;
        }
        return status;
    }

    private String setStateBasedOnCycleState(String cycleId) {
        String status;
        if (allowableCycleStateToSetComplete(cycleId)){
            status = SoxicConstants.GREEN_COMPLETE;
        }
        else status = SoxicConstants.GREEN_IMPORTED;
        return status;
    }

    protected boolean allowableCycleStateToSetComplete(String cycleId) {
        return cycleOnlyCertDAO.checkForCycleState(cycleId);
    }


    public String getTokenizedCycleBasedOnType(AdminOwnerEntity entity) {
        String cycleId = "";
        if (entity.getActivityId()!=ADMIN_ENTITY_DASH && entity.getSubCycleId()==ADMIN_ENTITY_DASH){
            cycleId = getTokenizedCycle(entity.getActivityId());
        }
        else if (entity.getActivityId()==ADMIN_ENTITY_DASH && entity.getSubCycleId()!=ADMIN_ENTITY_DASH){
            cycleId = getTokenizedCycle(entity.getSubCycleId());
        }
        return cycleId;
    }

    private String getPeriodBasedOnStatus(AdminOwnerEntity entity, String period) {
        if (entity.getType().equalsIgnoreCase(OWNER_ACTIVITY)){
            period = MiscUtils.getTokenizedPeriod(entity.getActivityId());
        }else
        if (entity.getType().equalsIgnoreCase(OWNER_SUBCYCLE)){
            period = MiscUtils.getTokenizedPeriod(entity.getSubCycleId());
        }
        return period;
    }

    public void insertOwnerResponseEntriesIfRequired(AdminOwnerEntity entity, String period, String user, String ownMaintType) {
        if (entity.getType().equalsIgnoreCase(OWNER_SUBCYCLE) || entity.getType().equalsIgnoreCase(OWNER_ACTIVITY)){
            period = getPeriodBasedOnStatus(entity,period);
            checkIfOnlyOwnerResponsePeriod(period, entity, user, ownMaintType);
        }
    }

    private void checkIfOnlyOwnerResponsePeriod(String period, AdminOwnerEntity entity, String user, String ownMaintType) {
        if (checkForPeriodOnlyCertification(period)){
            String cycle = getTokenizedCycleBasedOnType(entity);
            checkIfCycleOwnerRespnseRequired(cycle, entity, user, ownMaintType);
        }
    }

    private void checkIfCycleOwnerRespnseRequired(String cycle, AdminOwnerEntity entity, String user, String ownMaintType) {
        if (allowableCycleStateToSetComplete(cycle)){
            if (ownMaintType.equalsIgnoreCase(CycleOnlyConstants.CHANGE_OWNER)){
                createOwnerResponseChangeQueryBasedOnSystemType(entity, user);
            }
            if (ownMaintType.equalsIgnoreCase(CycleOnlyConstants.COPY_OWNER)){
                createOwnerResponseCopyAddQueryBasedOnSystemType(entity, user);
            }
        }
    }

    private void createOwnerResponseCopyAddQueryBasedOnSystemType(AdminOwnerEntity entity, String user) {
        if (entity.getType().equalsIgnoreCase(OWNER_SUBCYCLE)){
            createOwnerResponseAddCopyQuery(entity,OWNER_SUBCYCLE, user);
        }else
        if (entity.getType().equalsIgnoreCase(OWNER_ACTIVITY)){
            createOwnerResponseAddCopyQuery(entity,OWNER_ACTIVITY, user);
        }
    }

    private void createOwnerResponseAddCopyQuery(AdminOwnerEntity entity, String ownerSystem, String user) {
        if (ownerSystem.equalsIgnoreCase(OWNER_ACTIVITY)){
            getQuestionsAndSetActivityResponses(user, entity);
        }else
        if (ownerSystem.equalsIgnoreCase(OWNER_SUBCYCLE)){
            getQuestionsAndSetSubcycleResponses(user, entity);
        }
    }

    private void getQuestionsAndSetSubcycleResponses(String user, AdminOwnerEntity entity) {
        List questionList;
        questionList = cycleOnlyCertDAO.getQuestionList(OWNER_SUBCYCLE);
        Iterator ait = questionList.iterator();
        while(ait.hasNext()){
            String qId = String.valueOf(ait.next());
            createOwnerResponse(qId,user,entity.getSubCycleId(),CycleOnlyConstants.SUBCYCLE_ASSOC_TYPE);
        }
    }

    private void getQuestionsAndSetActivityResponses(String user, AdminOwnerEntity entity) {
        List questionList;
        questionList = cycleOnlyCertDAO.getQuestionList(OWNER_ACTIVITY);
        Iterator ait = questionList.iterator();
        while(ait.hasNext()){
            String qId = String.valueOf(ait.next());
            createOwnerResponse(qId,user,entity.getActivityId(),CycleOnlyConstants.ACT_ASSOC_TYPE);
        }
    }

    private void createOwnerResponse(String qId, String user, String sysId, String assType) {
        String query = "INSERT INTO OWNER_RESPONSE " +
                "(RESPONSE_ID,OWNER_ID,QUESTION_ID,ASSOCIATED_TYPE,ASSOCIATED_ID,RESPONSE,STATUS,MOD_DATE,MOD_USER) " +
                "VALUES (OWNER_RESPONSE_SEQ.NEXTVAL,'"+user+"','"+qId+"','"+assType+"','"+sysId+"','"+CycleOnlyConstants.YES_RESPONSE+"','"+SoxicConstants.COMPLETE+"" +
                "',to_date('"+sdf.format(currentDate)+"', 'MM/DD/YYYY'),'"+CycleOnlyConstants.CYCLE_ONLY_RESPONSE+"')";
        cycleOnlyCertDAO.updateStatusBasedOnType(query);
    }



    private void createOwnerResponseChangeQueryBasedOnSystemType(AdminOwnerEntity entity, String user) {
        if (entity.getType().equalsIgnoreCase(OWNER_SUBCYCLE)){
            createOwnerResponseChangeQuery(entity,OWNER_SUBCYCLE, user);
        }else
        if (entity.getType().equalsIgnoreCase(OWNER_ACTIVITY)){
            createOwnerResponseChangeQuery(entity,OWNER_ACTIVITY, user);
        }
    }

    private void createOwnerResponseChangeQuery(AdminOwnerEntity entity, String ownerSystem, String user) {
        String query = "";
        if (ownerSystem.equalsIgnoreCase(OWNER_ACTIVITY)){
            query = "INSERT INTO OWNER_RESPONSE( " +
                    "SELECT OWNER_RESPONSE_SEQ.NEXTVAL,'"+user+"',QA.QUESTION_ID,'"+CycleOnlyConstants.ACT_ASSOC_TYPE+"','"+entity.getActivityId()+"','"+CycleOnlyConstants.YES_RESPONSE+"','"+SoxicConstants.COMPLETE+"',to_date('"+sdf.format(currentDate)+"', 'MM/DD/YYYY'),'"+CycleOnlyConstants.CYCLE_ONLY_RESPONSE+"' " +
                    "FROM QUESTION_ACTIVITY QA, OWNER_ACTIVITY OA " +
                    "WHERE QA.ACTIVITY_ID = OA.ACTIVITY_ID " +
                    "AND QA.ACTIVITY_ID = '"+entity.getActivityId()+"' " +
                    "AND OA.OWNER_ID = '"+entity.getOwnerId()+"')";
        }else
        if (ownerSystem.equalsIgnoreCase(OWNER_SUBCYCLE)){
            query = "INSERT INTO OWNER_RESPONSE( " +
                    "SELECT OWNER_RESPONSE_SEQ.NEXTVAL,'"+user+"',QSC.QUESTION_ID,'"+CycleOnlyConstants.SUBCYCLE_ASSOC_TYPE+"','"+entity.getSubCycleId()+"','"+CycleOnlyConstants.YES_RESPONSE+"','"+SoxicConstants.COMPLETE+"',to_date('"+sdf.format(currentDate)+"', 'MM/DD/YYYY'),'"+CycleOnlyConstants.CYCLE_ONLY_RESPONSE+"' " +
                    "FROM QUESTION_SUB_CYCLE QSC,OWNER_SUB_CYCLE OSC " +
                    "WHERE QSC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID " +
                    "AND QSC.SUB_CYCLE_ID = '"+entity.getSubCycleId()+"' " +
                    "AND OSC.OWNER_ID = '"+entity.getOwnerId()+"')";
        }
        cycleOnlyCertDAO.updateStatusBasedOnType(query);
    }

    public String setCorrectStatusWhenUpdatingOwner(AdminOwnerEntity entity, String period) {
        String status;
        if (entity.getType().equalsIgnoreCase(OWNER_SUBCYCLE) || entity.getType().equalsIgnoreCase(OWNER_ACTIVITY)){
            status = setStateForAllowableUsers(entity, period);
        }
        else{
            status = SoxicConstants.GREEN_IMPORTED;
        }
        return status;
    }
}
