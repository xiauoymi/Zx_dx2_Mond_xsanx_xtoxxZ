/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/

package com.monsanto.wst.soxic.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ExportForm;

/**
 * This is the action that just forwards the user request to /report
 * action.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class ExportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());

	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		
		ExportForm exportForm = (ExportForm) form;
		
		logger.info("/export.do called...");
		
		
		
		return mapping.findForward("success");
		
	}

}