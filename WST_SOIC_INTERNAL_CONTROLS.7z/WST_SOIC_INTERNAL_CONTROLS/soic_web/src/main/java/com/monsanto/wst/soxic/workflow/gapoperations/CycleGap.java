package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 12:54:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class CycleGap extends GapEntity{
     public static final String CYCLE_ID="CYCLE_ID";
}
