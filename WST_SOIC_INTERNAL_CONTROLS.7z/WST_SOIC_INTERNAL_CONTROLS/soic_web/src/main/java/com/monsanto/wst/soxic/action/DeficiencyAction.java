/*
 * Created on Feb 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.DeficiencyForm;
import com.monsanto.wst.soxic.model.DeficiencyDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DeficiencyAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {


		ActionForward forward = new ActionForward();
		
		DeficiencyForm deficiencyForm = (DeficiencyForm)form;
		
		String id = request.getParameter(getKey(request.getParameterMap()));
		
		String level = getLevel(request.getParameterMap());
		
		deficiencyForm.setId(id);
		
		deficiencyForm.setLevel(level);
		
		//deficiencyForm.setDeficiencyList(ControlObjectiveDAO.getDeficiency(id,level));
		DeficiencyDAO deficiencyDAO = new DeficiencyDAO();
		deficiencyForm.setDeficiencyList(deficiencyDAO.getDeficiency(id,level));
		
		forward = mapping.findForward("success");

		return forward;

	}
	
	public String getLevel(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
			
			if(key.equalsIgnoreCase("controlObjectiveId")){
				
				return SoxicConstants.CONTROLOBJECTIVE;
				
			}
			
			if(key.equalsIgnoreCase("subCycleId")){
				
				return SoxicConstants.SUBCYCLE;
				
			}	
			
			if(key.equalsIgnoreCase("cycleId")){
				
				return SoxicConstants.CYCLE;
				
			}				
		
		}
		
		return key;
		
	}
	
	public String getKey(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
		
		}
		
		return key;		
	}
}
