package com.monsanto.wst.soxic.workflow;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.model.DocumentChangeDetails;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 12, 2005
 * Time: 10:17:21 AM
 * <p/>
 * This class contains the email logic to send emails when the start date
 * for cycles in INITIATED/RELEASED states are reached. The other email has
 * be sent when the 7 days prior to the end date has been reached
 */

public class DocChangeOperations {


  public static void main(String args[]) throws Exception {

    DocChangeOperations docchangeoperations = new DocChangeOperations();
    docchangeoperations.docChangeStartDate();
    docchangeoperations.docChangePriorDueDate();
  }


  /**
   * starts the operation to check for cycles whose start date is reached
   *
   * @throws Exception
   */
  public void docChangeStartDate() throws Exception {
    Map allOwnerMap = new HashMap();
    List cycleidList = getCycleidforDocChange();
    Iterator iterator = cycleidList.iterator();
    Connection conn = null;
    try{
      conn = getConnection();
      while (iterator.hasNext()) {
        String id = (String) iterator.next();
        getActivityOwnerList(id, allOwnerMap,conn);
        getSubCycleOwnerList(id, allOwnerMap,conn);
      }
      Iterator mapiterator = allOwnerMap.values().iterator();
      while (mapiterator.hasNext()) {
        OwnerWrapper ownerWrapper = (OwnerWrapper) mapiterator.next();
        SarboxMailComponent.sendStartDocChangeEmail(ownerWrapper.getEmailid(), ownerWrapper.getDateString(), ownerWrapper.getDueDateString());
      }
    }catch(Exception e){
       e.printStackTrace();
    }finally{
      try{
      closeResources(conn,null,null);
      }catch(SQLException sqlEx){
        throw new Exception("Unable to close resources : DocChangeOperations.docChangeStartDate()");
      }
    }

  }

  /**
   * retrieves the List of cycles whose start date is reached
   *
   * @return
   * @throws Exception
   */
  public List getCycleidforDocChange() throws Exception {
    Connection con = null;
    PreparedStatement getCycleid = null;
    List cycleList = new ArrayList();

    try {
      con = getConnection();
      getCycleid = con.prepareStatement("SELECT CYCLE_ID FROM CYCLE_STATE WHERE BEGIN_DATE = ? ");
      getCycleid.setDate(1, new Date(System.currentTimeMillis()));

      ResultSet rs = getCycleid.executeQuery();
      while (rs.next()) {
        cycleList.add(rs.getString("CYCLE_ID"));
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      //enclose this in a finally block to make
      //sure the connection is closed
      try {
        con.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
    return cycleList;
  }


  /**
   * updates the OwnerMap with the activity owners to whom emails have to
   * be sent
   *
   * @param cycleid
   * @param ownermap
   * @param con
   * @throws Exception
   */
  public void getActivityOwnerList(String cycleid, Map ownermap, Connection con) throws Exception {
    PreparedStatement subcycleowner = null;
    OwnerWrapper ownerwrapper = null;
    ResultSet rs = null;
    try {
      subcycleowner = con.prepareStatement
          ("SELECT OA.OWNER_ID,O.EMAIL,O.NAME,CS.BEGIN_DATE,CS.END_DATE " +
              "FROM CYCLE_STATE CS,CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO, " +
              "ACTIVITY A,OWNER O,OWNER_ACTIVITY OA " +
              "WHERE CS.CYCLE_ID = C.CYCLE_ID " +
              "AND C.CYCLE_ID = SC.CYCLE_ID " +
              "AND SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID " +
              "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
              "AND A.ACTIVITY_ID = OA.ACTIVITY_ID " +
              "AND O.OWNER_ID = OA.OWNER_ID " +
              "AND CS.CYCLE_ID = ?");
      subcycleowner.setString(1, cycleid);
      rs = subcycleowner.executeQuery();
      while (rs.next()) {
        if (ownermap.get(rs.getString("OWNER_ID")) == null) {
          ownerwrapper = new OwnerWrapper();
          populateOwnerWrapper(rs, ownerwrapper);
          ownerwrapper.setLevel(SoxicConstants.ACTIVITY);
          ownermap.put(ownerwrapper.getOwnerid(), ownerwrapper);
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        closeResources(null,rs,subcycleowner);
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * updates the Map with the subcycle owners to whom emails on the start
   * date have to be sent. If the owner is both subcycle & activity, only
   * 1 email will be sent since the Subcycle will take precedence over the
   * activity
   *
   * @param cycleid
   * @param ownermap
   * @param con
   * @throws Exception
   */
  public void getSubCycleOwnerList(String cycleid, Map ownermap, Connection con) throws Exception {
    PreparedStatement subcycleowner = null;
    OwnerWrapper ownerwrapper = null;
    ResultSet rs = null;
    try {
      subcycleowner = con.prepareStatement
          ("SELECT OSC.OWNER_ID,O.EMAIL,O.NAME,CS.BEGIN_DATE,CS.END_DATE " +
              "FROM CYCLE_STATE CS,CYCLE C,SUB_CYCLE SC,OWNER_SUB_CYCLE OSC,OWNER O " +
              "WHERE CS.CYCLE_ID = C.CYCLE_ID " +
              "AND C.CYCLE_ID = SC.CYCLE_ID " +
              "AND SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID " +
              "AND O.OWNER_ID = OSC.OWNER_ID " +
              "AND CS.CYCLE_ID = ?");
      subcycleowner.setString(1, cycleid);
      rs = subcycleowner.executeQuery();
      while (rs.next()) {

        if (ownermap.get(rs.getString("OWNER_ID")) == null) {
          ownerwrapper = new OwnerWrapper();
          populateOwnerWrapper(rs, ownerwrapper);
          ownermap.put(ownerwrapper.getOwnerid(), ownerwrapper);
          ownerwrapper.setLevel(SoxicConstants.SUBCYCLE);
        } else {
          //populateOwnerWrapper(rs,(OwnerWrapper)ownermap.get(ownerwrapper.getOwnerid()));
          ownerwrapper = (OwnerWrapper) ownermap.get(rs.getString("OWNER_ID"));
          if (ownerwrapper.getLevel().equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            ownerwrapper.setLevel(SoxicConstants.SUBCYCLE);
          }
          //ownermap.put(ownerwrapper.getOwnerid(),ownerwrapper);
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        closeResources(null,rs,subcycleowner);
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  private Connection getConnection() throws Exception {
    return SoxicConnectionFactory.getSoxicConnection();
  }

  /**
   * populates the ownerwrapper with the owner details for start date
   *
   * @param rs
   * @param ownerwrapper
   * @throws Exception
   */
  public void populateOwnerWrapper(ResultSet rs, OwnerWrapper ownerwrapper) throws Exception {
    try {

      ownerwrapper.setOwnerid(rs.getString("OWNER_ID"));
      ownerwrapper.setEmailid(rs.getString("EMAIL"));
      ownerwrapper.setOwnerName(rs.getString("NAME"));
      ownerwrapper.setDateString(DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("BEGIN_DATE")));
      ownerwrapper.setDueDateString(DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("END_DATE")));

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  /**
   * Method to send emails to owners when 7 days prior to the end date
   * has been reached
   *
   * @throws Exception
   */
  public void docChangePriorDueDate() throws Exception {
    Map allOwnerMap = new HashMap();
    List cycleidList = getCycleidforDocClosure();
    Iterator iterator = cycleidList.iterator();
    Connection conn = null;
    try {
      conn = getConnection();
      while (iterator.hasNext()) {
        String id = (String) iterator.next();
        getActivityOwnerClosureList(id, allOwnerMap, conn);
        getSubCycleOwnerClosureList(id, allOwnerMap, conn);
      }
      Iterator mapiterator = allOwnerMap.values().iterator();
      while (mapiterator.hasNext()) {
        OwnerWrapper ownerWrapper = (OwnerWrapper) mapiterator.next();
        SarboxMailComponent.sendCloseDocChangeEmail(ownerWrapper.getEmailid(), ownerWrapper.getDateString());
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        closeResources(conn,null,null);
      } catch (SQLException sqlEx) {
        throw new Exception("Unable to Close resources :DocChangeOperations.docChangePriorDueDate()");
      }
    }

  }

  /**
   * Method to retrieve the cycles for the closing date reached 7 days
   * prior. The calculation for 7 days prior to the closing date is
   * computed here.
   *
   * @return List of cycles
   * @throws Exception
   */
  public List getCycleidforDocClosure() throws Exception {
    Connection con = null;
    PreparedStatement getCycleid = null;
    List cycleList = new ArrayList();
    java.util.Date sevenDaysahead = new java.util.Date(System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000));
    Calendar seven_days = Calendar.getInstance();
    seven_days.setTime(sevenDaysahead);

    try {
      con = getConnection();
      getCycleid = con.prepareStatement("SELECT CYCLE_ID,END_DATE FROM CYCLE_STATE");
      ResultSet rs = getCycleid.executeQuery();
      while (rs.next()) {
        if ((rs.getDate("END_DATE") != null)) {
          String cycleid = rs.getString("CYCLE_ID");
          java.util.Date end_date = (rs.getDate("END_DATE"));
          Calendar endate = Calendar.getInstance();
          endate.setTime(end_date);
          if (seven_days.get(Calendar.YEAR) == endate.get(Calendar.YEAR)) {
            if (seven_days.get(Calendar.MONTH) == endate.get(Calendar.MONTH)) {
              if (seven_days.get(Calendar.DATE) == endate.get(Calendar.DATE)) {
                cycleList.add(rs.getString("CYCLE_ID"));
              }
            }
          }
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      //enclose this in a finally block to make
      //sure the connection is closed
      try {
        con.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
    return cycleList;
  }

  /**
   * retrieves the Map of owners who are activity owners for end date
   *
   * @param cycleid
   * @param ownermap
   * @param con
   * @throws Exception
   */
  public void getActivityOwnerClosureList(String cycleid, Map ownermap, Connection con) throws Exception {
    PreparedStatement preparedStatement = null;
    OwnerWrapper ownerwrapper = null;
    ResultSet rs = null;
    try {
      preparedStatement = con.prepareStatement
          ("SELECT OA.OWNER_ID,O.EMAIL,O.NAME,CS.END_DATE " +
              "FROM CYCLE_STATE CS,CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO, " +
              "ACTIVITY A,OWNER O,OWNER_ACTIVITY OA " +
              "WHERE CS.CYCLE_ID = C.CYCLE_ID " +
              "AND C.CYCLE_ID = SC.CYCLE_ID " +
              "AND SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID " +
              "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
              "AND A.ACTIVITY_ID = OA.ACTIVITY_ID " +
              "AND O.OWNER_ID = OA.OWNER_ID " +
              "AND CS.CYCLE_ID = ?");
      preparedStatement.setString(1, cycleid);
      rs = preparedStatement.executeQuery();
      while (rs.next()) {
        if (ownermap.get(rs.getString("OWNER_ID")) == null) {
          ownerwrapper = new OwnerWrapper();
          populateOwnerWrapperforClosure(rs, ownerwrapper);
          ownerwrapper.setLevel(SoxicConstants.ACTIVITY);
          ownermap.put(ownerwrapper.getOwnerid(), ownerwrapper);
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        closeResources(null, rs, preparedStatement);
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  private void closeResources(Connection conn, ResultSet rs, PreparedStatement statement) throws SQLException {
    if (rs != null) rs.close();
    if (statement != null) statement.close();
    if (conn != null) conn.close();
  }

  /**
   * populates the owner wrapper for the close date
   *
   * @param rs
   * @param ownerwrapper
   * @throws Exception
   */
  public void populateOwnerWrapperforClosure(ResultSet rs, OwnerWrapper ownerwrapper) throws Exception {
    try {

      ownerwrapper.setOwnerid(rs.getString("OWNER_ID"));
      ownerwrapper.setEmailid(rs.getString("EMAIL"));
      ownerwrapper.setOwnerName(rs.getString("NAME"));
      ownerwrapper.setDateString(DateFormat.getDateInstance(DateFormat.MEDIUM).format(rs.getDate("END_DATE")));

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  /**
   * retrieves the subcycle owners for the end date
   *
   * @param cycleid
   * @param ownermap
   * @param con
   * @throws Exception
   */
  public void getSubCycleOwnerClosureList(String cycleid, Map ownermap, Connection con) throws Exception {
    PreparedStatement subcycleowner = null;
    OwnerWrapper ownerwrapper = null;
    ResultSet rs = null;
    try {
      subcycleowner = con.prepareStatement
          ("SELECT OSC.OWNER_ID,O.EMAIL,O.NAME,CS.END_DATE " +
              "FROM CYCLE_STATE CS,CYCLE C,SUB_CYCLE SC,OWNER_SUB_CYCLE OSC,OWNER O " +
              "WHERE CS.CYCLE_ID = C.CYCLE_ID " +
              "AND C.CYCLE_ID = SC.CYCLE_ID " +
              "AND SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID " +
              "AND O.OWNER_ID = OSC.OWNER_ID " +
              "AND CS.CYCLE_ID = ?");
      subcycleowner.setString(1, cycleid);
      rs = subcycleowner.executeQuery();
      while (rs.next()) {

        if (ownermap.get(rs.getString("OWNER_ID")) == null) {
          ownerwrapper = new OwnerWrapper();
          populateOwnerWrapperforClosure(rs, ownerwrapper);
          ownermap.put(ownerwrapper.getOwnerid(), ownerwrapper);
        } else {
          //populateOwnerWrapper(rs,(OwnerWrapper)ownermap.get(ownerwrapper.getOwnerid()));
          ownerwrapper = (OwnerWrapper) ownermap.get(rs.getString("OWNER_ID"));
          if (ownerwrapper.getLevel().equalsIgnoreCase(SoxicConstants.ACTIVITY)) {
            ownerwrapper.setLevel(SoxicConstants.SUBCYCLE);
          }
          //ownermap.put(ownerwrapper.getOwnerid(),ownerwrapper);
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        closeResources(null,rs,subcycleowner);
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }
}

