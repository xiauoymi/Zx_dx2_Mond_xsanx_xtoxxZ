package com.monsanto.wst.soxic.action;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.form.GapDeficiencyForm;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.GapDAO;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.Question;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/** 
 * MyEclipse Struts
 * Creation date: 02-09-2005
 * 
 * XDoclet definition:
 * @struts:action validate="true"
 */
public class GapDeficiencyDisplayAction extends Action {

	// --------------------------------------------------------- Instance Variables

	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws Exception{

		ActionForward forward = new ActionForward();
		
		GapDeficiencyForm gapDeficiencyForm = (GapDeficiencyForm)form;
		
		gapDeficiencyForm.clear();
		
		String question = request.getParameter("question");
		
		StringTokenizer st = new StringTokenizer(question,SoxicUtil.getSeperator());
		
		String controlObjectiveId="";
		
		String questionId="";
		
		String toForward = "";
		
		Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);
		
		while(st.hasMoreElements()){
			
			controlObjectiveId = st.nextToken();
			questionId = st.nextToken();
			toForward=st.nextToken();
		}
		
		gapDeficiencyForm.setToReturn(toForward);
		
		gapDeficiencyForm.setActivityFlag(false);
		
		gapDeficiencyForm.setQuestionId(questionId);
		//Map enum = request.getParameterMap();
		
		//ArrayList controlObjectiveList = (ArrayList)request.getSession().getAttribute(SoxicConstants.CONTROLOBJECTIVELIST);
		
		List controlObjectiveList = getControlObjectiveList(request);
		
		gapDeficiencyForm.setActivityList(getActivityList(controlObjectiveList,controlObjectiveId,questionId));
		
		gapDeficiencyForm.setControlObjectiveId(controlObjectiveId);
		
		//gapDeficiencyForm.setAddedActivityList(ControlObjectiveDAO.getPreviousGap(controlObjectiveId,questionId,SoxicConstants.CONTROLOBJECTIVE,owner.getOwnerId()));
		
		GapDAO gapDAO = new GapDAO();
		//gapDeficiencyForm.setAddedActivityList(ControlObjectiveDAO.getPreviousGap(controlObjectiveId,questionId,SoxicConstants.CONTROLOBJECTIVE,owner.getOwnerId()));
		
		gapDeficiencyForm.setAddedActivityList(gapDAO.getPreviousGap(controlObjectiveId,questionId,SoxicConstants.CONTROLOBJECTIVE,owner.getOwnerId()));
		
		gapDeficiencyForm.setQuestion(getQuestion(controlObjectiveList,controlObjectiveId,questionId));
		
		forward = mapping.findForward("gap");
		
		return forward;
	}
	

	
	public List getActivityList(List controlObjectiveList,String controlObjectiveIdIn,String questionIdIn){
		
		List questionList = new ArrayList();
		
		List activityList = new ArrayList();
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		
		while(controlObjectiveListIterator.hasNext()){
			
			ControlObjective controlObjective = (ControlObjective)controlObjectiveListIterator.next();
			
			//Activity data
			
			if(controlObjective.getControlObjectiveId().equalsIgnoreCase(controlObjectiveIdIn)){
				
			
				Map questionMap = controlObjective.getQuestionMap();
				
				Set keySet = questionMap.keySet();
				
				Iterator questionIterator = keySet.iterator();
				
				while(questionIterator.hasNext()){
					
					Object questionKey = (Object)questionIterator.next();
					
					Question question =(Question)questionMap.get(questionKey);
					
	
					if(question.getType().equalsIgnoreCase("no") && question.getQuestionId().equalsIgnoreCase(questionIdIn)){
						
						addActivity(controlObjective.getAssignedActivityMap(),activityList,question.getQuestionId());
					}
					
				}
			}
		
		}
		
		return activityList;
		
	}	
	
	public String getQuestion(List controlObjectiveList,String controlObjectiveIdIn,String questionIdIn){
		
		String questionDesc="";
		
		List questionList = new ArrayList();
		
		List activityList = new ArrayList();
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		
		while(controlObjectiveListIterator.hasNext()){
			
			ControlObjective controlObjective = (ControlObjective)controlObjectiveListIterator.next();
			
			//Activity data
			
			if(controlObjective.getControlObjectiveId().equalsIgnoreCase(controlObjectiveIdIn)){
				
			
				Map questionMap = controlObjective.getQuestionMap();
				
				Set keySet = questionMap.keySet();
				
				Iterator questionIterator = keySet.iterator();
				
				while(questionIterator.hasNext()){
					
					Object questionKey = (Object)questionIterator.next();
					
					Question question =(Question)questionMap.get(questionKey);
					
	
					if(question.getType().equalsIgnoreCase("no") && question.getQuestionId().equalsIgnoreCase(questionIdIn)){
						
						return question.getDescription();
					}
					
				}
			}
		
		}
		return questionDesc;
		
		
		
	}
	
	public void addActivity(Map activityMap,List activityList,String questionId){
		
		Set keySet = activityMap.keySet();
		
		Iterator activityIterator = keySet.iterator();
		
		while(activityIterator.hasNext()){
			
			Object activityKey = (Object)activityIterator.next();
			
			Activity activity =(Activity)activityMap.get(activityKey);
			
			activity.setQuestionId(questionId);
			
			activity.clear();
			
			activityList.add(activity);
			
		}
	}
	
	private List getControlObjectiveList(HttpServletRequest request){
		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm)request.getSession().getAttribute("controlObjectiveForm");
		
		return (List)controlObjectiveForm.getControlObjectiveList();
	}

}