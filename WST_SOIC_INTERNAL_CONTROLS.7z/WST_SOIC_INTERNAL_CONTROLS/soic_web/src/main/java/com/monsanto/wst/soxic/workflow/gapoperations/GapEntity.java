package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 12:52:50 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class GapEntity {

    protected String identifier;
    protected String ownerId;
    protected String questionId;
    protected String potentialGap;
    protected boolean doUpdate;

    boolean writeToNoAnswerNoGap;
    boolean writeToNoAnswerYesGapButOnlyOneQuestion;
    boolean writeToYesAnswerNoGap;

    boolean writeToUpdateEntityGap;
    boolean writeToUpdateEntityGapYes;
    boolean writeToUpdateEntityGapNo;

    boolean writeToUpdateOwnerEntityGapYes;
    boolean writeToUpdateEntityGapYesForGaps;





    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getPotentialGap() {
        return potentialGap;
    }

    public void setPotentialGap(String potentialGap) {
        this.potentialGap = potentialGap;
    }

    public boolean isDoUpdate() {
        return doUpdate;
    }

    public void setDoUpdate(boolean doUpdate) {
        this.doUpdate = doUpdate;
    }

    public boolean isWriteToNoAnswerNoGap() {
        return writeToNoAnswerNoGap;
    }

    public void setWriteToNoAnswerNoGap(boolean writeToNoAnswerNoGap) {
        this.writeToNoAnswerNoGap = writeToNoAnswerNoGap;
    }

    public boolean isWriteToYesAnswerNoGap() {
        return writeToYesAnswerNoGap;
    }

    public void setWriteToYesAnswerNoGap(boolean writeToYesAnswerNoGap) {
        this.writeToYesAnswerNoGap = writeToYesAnswerNoGap;
    }

    public boolean isWriteToNoAnswerYesGapButOnlyOneQuestion() {
        return writeToNoAnswerYesGapButOnlyOneQuestion;
    }

    public void setWriteToNoAnswerYesGapButOnlyOneQuestion(boolean writeToNoAnswerYesGapButOnlyOneQuestion) {
        this.writeToNoAnswerYesGapButOnlyOneQuestion = writeToNoAnswerYesGapButOnlyOneQuestion;
    }

    public boolean isWriteToUpdateEntityGap() {
        return writeToUpdateEntityGap;
    }

    public void setWriteToUpdateEntityGap(boolean writeToUpdateEntityGap) {
        this.writeToUpdateEntityGap = writeToUpdateEntityGap;
    }

    public boolean isWriteToUpdateEntityGapYes() {
        return writeToUpdateEntityGapYes;
    }

    public void setWriteToUpdateEntityGapYes(boolean writeToUpdateEntityGapYes) {
        this.writeToUpdateEntityGapYes = writeToUpdateEntityGapYes;
    }

    public boolean isWriteToUpdateEntityGapNo() {
        return writeToUpdateEntityGapNo;
    }

    public void setWriteToUpdateEntityGapNo(boolean writeToUpdateEntityGapNo) {
        this.writeToUpdateEntityGapNo = writeToUpdateEntityGapNo;
    }

    public boolean isWriteToUpdateOwnerEntityGapYes() {
        return writeToUpdateOwnerEntityGapYes;
    }

    public void setWriteToUpdateOwnerEntityGapYes(boolean writeToUpdateOwnerEntityGapYes) {
        this.writeToUpdateOwnerEntityGapYes = writeToUpdateOwnerEntityGapYes;
    }

    public boolean isWriteToUpdateEntityGapYesForGaps() {
        return writeToUpdateEntityGapYesForGaps;
    }

    public void setWriteToUpdateEntityGapYesForGaps(boolean writeToUpdateEntityGapYesForGaps) {
        this.writeToUpdateEntityGapYesForGaps = writeToUpdateEntityGapYesForGaps;
    }


}
