package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.ExportTemplateForm;
import com.monsanto.wst.soxic.model.AdminTemplateDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 18, 2005
 * Time: 11:48:55 AM
 *
 * This class is the facade for the AdminViewTemplates screen which allows
 * users to view the templates before they are exported.
 */

public class AdminViewTemplateFacade {

    AdminTemplateDAO admintemplatedao = new AdminTemplateDAO();

    /**
     * Contains methods to retrieve countries, retrieve cycles based on the
     * country and retrieve subcycles based on the cycle.
     * @param exporttemplateform
     * @throws Exception
     */
    public void templateSelection(ExportTemplateForm exporttemplateform) throws Exception {
        getPeriodsToView(exporttemplateform);
        getCountriesToView(exporttemplateform);
        getCyclesToView(exporttemplateform);
        getSubcyclesToView(exporttemplateform);
    }

    private void getPeriodsToView(ExportTemplateForm exporttemplateform) throws NullAndArrayIndexException {
        try {
            getPeriodListAndSetFirstPeriod(exporttemplateform);
        } catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
            System.err.println("Could not get country List due" + e);
            e.printStackTrace();
        }
    }


    /**
     * Retrieves the countries whose state are in CERTIFICATION
     * @param exporttemplateform
     * @throws Exception
     */
    public void getCountriesToView(ExportTemplateForm exporttemplateform) throws Exception{
    try {
            getCountryListAndSetFirstCountry(exporttemplateform);
        }
        catch (Exception e) {
        if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
            System.err.println("Could not get country List due" + e);
            e.printStackTrace();
            }
    }

    /**
     * Retrieves the cycles based on the first country
     * @param exporttemplateform
     * @throws Exception
     */
    public void getCyclesToView(ExportTemplateForm exporttemplateform) throws Exception{
    String countrysel = getFirstCountryForCycle(exporttemplateform);
            try {
                    exporttemplateform.setCycles(getCycles(countrysel,getFirstPeriodForCycle(exporttemplateform)));
            }
                catch (Exception e) {
                if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
                }
                    System.err.println("Could not get cycle List due to" + e);
                    e.printStackTrace();
                }

    }



    /**
     * Retrieves the subcycles based on the first cycle
     * @param exporttemplateform
     * @throws Exception
     */
    public void getSubcyclesToView(ExportTemplateForm exporttemplateform) throws Exception{
    String selcycle = getFirstCycleForSubcycle(exporttemplateform);
            try {
                    exporttemplateform.setSubcycle(getSubCycles(selcycle));
            }catch (Exception e) {
                if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
                    System.err.println("Could not get subcycle List due to" + e);
                    e.printStackTrace();
            }
    }

    /**
     * calls the method to select the list of countries and set the first
     * country
     * @param exporttemplateform
     * @throws Exception
     */
    public void getCountryListAndSetFirstCountry(ExportTemplateForm exporttemplateform) throws Exception {
            exporttemplateform.setCountry(getContries(exporttemplateform.getSelectedPeriod()));
            List countries = exporttemplateform.getCountry();
            String initialcountry = String.valueOf(countries.get(0));
            exporttemplateform.setSelectedCountry(initialcountry);
    }

    public void getPeriodListAndSetFirstPeriod(ExportTemplateForm exportTemplateForm) throws Exception {
            exportTemplateForm.setPeriod(getPeriods());
            List periods = exportTemplateForm.getPeriod();
            String initialPeriod = String.valueOf(periods.get(0));
            exportTemplateForm.setSelectedPeriod(initialPeriod);
    }

    private String getFirstPeriodForCycle(ExportTemplateForm exporttemplateform) {
        List periods = exporttemplateform.getPeriod();
        return String.valueOf(periods.get(0));
    }

    /**
     * sets the first country
     * @param exporttemplateform
     * @return
     */
    public String getFirstCountryForCycle(ExportTemplateForm exporttemplateform){
        List countries1 = exporttemplateform.getCountry();
        String countrysel = String.valueOf(countries1.get(0));
        return countrysel;
    }

    /**
     * sets the first cycle
     * @param exporttemplateform
     * @return
     */
    public String getFirstCycleForSubcycle(ExportTemplateForm exporttemplateform){
        List cycleList = exporttemplateform.getCycles();
        String selcycle = String.valueOf(cycleList.get(0));
        return selcycle;
    }

    public List getPeriods() throws Exception {
        return admintemplatedao.getPeriodsForViewTemplates();
    }

    /**
     * call to the DAO to get the list of countries
     * @return
     * @throws Exception
     * @param selectedPeriod
     */
    public List getContries(String selectedPeriod)throws Exception{
         return admintemplatedao.getCountriesforViewTemplates(selectedPeriod);
    }

    /**
     * call to the DAO to get the list of cycles based on the country
     * selected
     * @param countrysel
     * @param firstPeriod
     * @return
     * @throws Exception
     */
    protected List getCycles(String countrysel, String firstPeriod) throws Exception {
        return admintemplatedao.getCyclesforViewTemplates(countrysel,firstPeriod);
    }

    /**
     * call to the DAO to get the list of subcycles based on the
     * cycle selected.
     * @param selcycle
     * @return
     * @throws Exception
     */
    protected List getSubCycles(String selcycle) throws Exception{
        return admintemplatedao.getSubCyclesforViewTemplates(selcycle);
    }

    public void buildCyclesAndSubCycles(ExportTemplateForm exporttemplateform) throws NullAndArrayIndexException {
        String countryid = exporttemplateform.getSelectedCountry();
        String period = exporttemplateform.getSelectedPeriod();

        try {
                exporttemplateform.setCycles(admintemplatedao.getCyclesforViewTemplates(countryid, period));

            }
            catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
            throw new NullAndArrayIndexException();
            }
                System.err.println("Could not get cycle List due" + e);
                e.printStackTrace();
            }

        List cycleList = exporttemplateform.getCycles();
        String selcycle = String.valueOf(cycleList.get(0));
        try {
                exporttemplateform.setSubcycle(admintemplatedao.getSubCyclesforViewTemplates(selcycle));
            }catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
            throw new NullAndArrayIndexException();
            }
                System.err.println("Could not get subcycle List due to" + e);
                e.printStackTrace();
        }
    }

}
