package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.model.Period;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Iterator;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 25, 2005
 * Time: 9:04:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class PeriodCreation {

    public static void main(String args[])throws Exception{
        PeriodCreation periodCreation = new PeriodCreation();
        Connection connection=null;
        List cycleList = periodCreation.createCycles("FY05","RAM01", connection);
        periodCreation.insertCycle(cycleList, connection);

    }

   public List createCycles(String sourcePeriod, String targetPeriod, Connection connection)throws Exception{
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Period period=null;
        List cycleList = new ArrayList();

        try {

            preparedStatement = connection.prepareStatement("SELECT CS.CYCLE_ID,CS.PERIOD_ID,CS.STATE,CS.BEGIN_DATE,CS.END_DATE,CS.MOD_DATE,CS.MOD_USER FROM CYCLE_STATE CS WHERE CS.PERIOD_ID=?");
            preparedStatement.setString(1,sourcePeriod);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                period = new Period();
                period.setCycle_id(rs.getString("CYCLE_ID"));
                period.setPeriod_id(rs.getString("PERIOD_ID"));
                processCycleState(period,targetPeriod);
                cycleList.add(period);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    public void processCycleState(Period period,String targetPeriod){
        StringTokenizer st = new StringTokenizer(period.getCycle_id(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String targetCycleId = targetPeriod+"."+countryId+"."+cycleId;
        period.setCycle_id(targetCycleId);
        period.setPeriod_id(targetPeriod);
    }

   public void insertCycle(List cycleList, Connection connection){
        //Connection connection = null;
        PreparedStatement preparedStatement=null;
        String query = "INSERT INTO CYCLE_STATE (CYCLE_ID, PERIOD_ID, STATE,MOD_DATE, MOD_USER)VALUES (?, ?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            //connection.setAutoCommit(false);
            Iterator iterator = cycleList.iterator();
            while(iterator.hasNext()){
                Period period = (Period)iterator.next();

                preparedStatement.setString(1,period.getCycle_id());

                preparedStatement.setString(2,period.getPeriod_id());
                preparedStatement.setString(3,SoxicConstants.CREATENEW_STATE);
                preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
                preparedStatement.setString(5,"ADMIN");
                preparedStatement.addBatch();
            }

            int result[]=preparedStatement.executeBatch();

            //connection.commit();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }
}
