package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: VIJAY
 * Date: Sep 25, 2005
 * Time: 6:31:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class CtrlObjGapDAO extends GapDAO {

    public CtrlObjGapDAO(String env,String fol){
        super(env,fol);
    }

    protected String getAllGapsPerEntityQuery() {
        return "SELECT POTENTIAL_GAP FROM ACTIVITY WHERE CTRL_OBJ_ID=?";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getUpdateEntityQuery() {
        return "UPDATE CTRL_OBJ SET POTENTIAL_GAP=? WHERE CTRL_OBJ_ID=?";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getUpdateNoGapYesAnswerQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getUpdateOwnerEntityQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getUpdateNoGapNoAnswerQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getSelectNoGapYesAnswerQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getSelectNoGapNoAnswerQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getIdentifierType() {
        return "CTRL_OBJ_ID";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getOwnerEntityQuery() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getOwnerEntityQueryWithGaps() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getEntityQuery() {
        //return "SELECT CTRL_OBJ_ID,POTENTIAL_GAP FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%FY05.AUS.BU.01.14%'";  //To change body of implemented methods use File | Settings | File Templates.
        return "SELECT CTRL_OBJ_ID,POTENTIAL_GAP FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%FY05.%'";  //To change body of implemented methods use File | Settings | File Templates.
    }
}


