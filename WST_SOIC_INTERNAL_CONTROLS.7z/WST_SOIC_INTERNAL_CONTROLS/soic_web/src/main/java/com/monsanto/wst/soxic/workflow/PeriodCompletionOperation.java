package com.monsanto.wst.soxic.workflow;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 6, 2005
 * Time: 5:14:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeriodCompletionOperation {

    List certificationCompleteCycles = new ArrayList();

    public static void main(String args[]){
        PeriodCompletionOperation periodCompletionOperation = new PeriodCompletionOperation();
        periodCompletionOperation.selectAllCompleteCycles();
        periodCompletionOperation.updateCycleStateToComplete();

    }

    public void selectAllCompleteCycles(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        Set hashSet = new HashSet();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement("SELECT C.CYCLE_ID FROM CYCLE C,CYCLE_STATE CS WHERE C.STATUS='G_COMPLETE' AND CS.STATE<>'CERT_COMP' AND C.CYCLE_ID=CS.CYCLE_ID");
            preparedStatement = connection.prepareStatement("SELECT C.CYCLE_ID FROM CYCLE C,CYCLE_STATE CS,OWNER_CYCLE OC WHERE C.STATUS='G_COMPLETE' AND CS.STATE<>'CERT_COMP' AND C.CYCLE_ID=CS.CYCLE_ID AND OC.CYCLE_ID=C.CYCLE_ID AND OC.DUE_DATE<?");
            int days = 30;
            preparedStatement.setDate(1,new java.sql.Date(System.currentTimeMillis()-(15*60*60*1000*24)-(15*60*60*1000*24)));
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                String cycleId = rs.getString("CYCLE_ID");
                if(hashSet.add(cycleId)){
                    certificationCompleteCycles.add(cycleId);
                }
            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }

    }

    public void updateCycleStateToComplete(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE CYCLE_STATE SET STATE =? WHERE CYCLE_ID=?");

            Iterator iterator = certificationCompleteCycles.iterator();

            while(iterator.hasNext()){
                String cycleId = (String)iterator.next();
                preparedStatement.setString(1,SoxicConstants.CYCLE_STATE_CERTIFICATION_COMPLETE);
                preparedStatement.setString(2,cycleId);
                preparedStatement.addBatch();
            }
            int result[]=preparedStatement.executeBatch();

        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }

    }

    public List getCertificationCompleteCycles() {
        return certificationCompleteCycles;
    }

    public void setCertificationCompleteCycles(List certificationCompleteCycles) {
        this.certificationCompleteCycles = certificationCompleteCycles;
    }
}
