package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 26, 2005
 * Time: 9:10:05 AM
 */
public class SingleOwnerDoesNotExistException extends Exception {

    public SingleOwnerDoesNotExistException(){
        super();
    }

    public SingleOwnerDoesNotExistException(String strMessage){
        super(strMessage);
    }

    public SingleOwnerDoesNotExistException(Exception e){
        super(e);
    }
}
