package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.exception.InvalidLenghtException;
import com.monsanto.wst.soxic.exception.EmptyDataException;
import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.model.headerFooter.*;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 3:03:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuestionAdminFacade {

    public void validateTextLength(String incomingText) throws InvalidLenghtException, EmptyDataException {
        if (incomingText==null || incomingText.equalsIgnoreCase("") || incomingText.length()==0){
            throw new EmptyDataException();
        }
        if (incomingText.length()>2000){
            throw new InvalidLenghtException();
        }
    }

    public void displayQuestions(QuestionAdminForm questionAdminForm) {
        setCycleHeaderAndFooter(questionAdminForm);
        setSubcycleHeaderAndFooter(questionAdminForm);
        setActivityHeaderAndFooter(questionAdminForm);
    }

    private void setCycleHeaderAndFooter(QuestionAdminForm questionAdminForm) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(SoxicConstants.CYCLE);
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.CYCLE);
        setFormDataValues(headFootSet, questionAdminForm, headerFooterFacade);
    }

    private void setSubcycleHeaderAndFooter(QuestionAdminForm questionAdminForm) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(SoxicConstants.SUBCYCLE);
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.SUBCYCLE);
        setFormDataValues(headFootSet, questionAdminForm, headerFooterFacade);
    }

    private void setActivityHeaderAndFooter(QuestionAdminForm questionAdminForm) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(SoxicConstants.ACTIVITY);
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.ACTIVITY);
        setFormDataValues(headFootSet, questionAdminForm, headerFooterFacade);
    }

    private void setFormDataValues(HeadFootSet headFootSet, QuestionAdminForm questionAdminForm, HeaderFooterFacade headerFooterFacade) {
        headFootSet.setHeaderAndFooter(questionAdminForm,headerFooterFacade);
    }

    public void processQuestions(QuestionAdminForm questionAdminForm) throws InvalidLenghtException, EmptyDataException {
        try {
                validateTextLength(questionAdminForm.getActivityHeader());
                validateTextLength(questionAdminForm.getActivityFooter());
                validateTextLength(questionAdminForm.getSubcycleHeader());
                validateTextLength(questionAdminForm.getSubcycleFooter());
                validateTextLength(questionAdminForm.getCycleHeader());
                validateTextLength(questionAdminForm.getCycleFooter());
            } catch (InvalidLenghtException e) {
                throw new InvalidLenghtException();
            } catch (EmptyDataException e) {
                throw new EmptyDataException();
            }
    }

    public void saveUpdatedQuestions(QuestionAdminForm questionAdminForm) {
        updateCycleQuestion(questionAdminForm);
        updateSubcycleQuestion(questionAdminForm);
        updateActivityQuestion(questionAdminForm);
    }

    private void updateActivityQuestion(QuestionAdminForm questionAdminForm) {
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.ACTIVITY);
        updateDBWithHeaderAndFooter(headFootSet, questionAdminForm);
    }

    private void updateSubcycleQuestion(QuestionAdminForm questionAdminForm) {
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.SUBCYCLE);
        updateDBWithHeaderAndFooter(headFootSet, questionAdminForm);
    }

    private void updateCycleQuestion(QuestionAdminForm questionAdminForm) {
        HeadFootSet headFootSet = HeadFootSetFactory.getLevel(SoxicConstants.CYCLE);
        updateDBWithHeaderAndFooter(headFootSet, questionAdminForm);
    }

    private void updateDBWithHeaderAndFooter(HeadFootSet headFootSet, QuestionAdminForm questionAdminForm) {
        headFootSet.updateHeaderIntoDB(questionAdminForm);
        headFootSet.updateFooterIntoDB(questionAdminForm);
    }


}
