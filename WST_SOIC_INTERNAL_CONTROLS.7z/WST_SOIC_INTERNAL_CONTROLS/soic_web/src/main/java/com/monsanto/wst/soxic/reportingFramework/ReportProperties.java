package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import java.util.*;
import java.io.InputStream;
import java.io.IOException;

import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 1:34:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReportProperties {
   private Document typeXmlDom;
    private String reportName;
    private String xmlFileName;
    private String filterXSL;
    private String filterClass;
    private String reportXSL;
    private String exportXSL;
    private String reportClass;
    private List exportList = new ArrayList();
    private Export export;

    private String exportFileName = "";

    private Map reportProperties= new HashMap();

    public ReportProperties(String xmlFileName) throws XmlException {
        String temp = "com/monsanto/wst/soxic/reportingFramework/xmlResources/"+xmlFileName+".xml";
        this.xmlFileName = temp;
    }

    public void parseXmlFile() throws XmlException {
        ClassLoader classLoader = ReportProperties.class.getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(xmlFileName);
        try {
            typeXmlDom = DOMUtil.newDocument(inputStream);
        } catch (SAXException e) {
            throw new XmlException(e);
        }
        catch(IOException ioe){
            throw new XmlException(ioe);
        }
        NodeList reportNodeNameList = typeXmlDom.getElementsByTagName("name");
        Node reportNode = reportNodeNameList.item(0);
        reportName = DOMUtil.getTextValue(reportNode);
        NodeList nodeList = typeXmlDom.getElementsByTagName("filterOptions");
        Node firstFilterNode = nodeList.item(0);
        NodeList filterNodes = firstFilterNode.getChildNodes();
        for(int i=0;i<filterNodes.getLength();i++){
            Node currentNode = filterNodes.item(i);
            if(currentNode.getNodeName().equalsIgnoreCase("xsl")){
                filterXSL = DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("filterClass")){
                filterClass = DOMUtil.getTextValue(currentNode);
            }
        }

        NodeList nodeListONe = typeXmlDom.getElementsByTagName("reportOptions");
        Node firstReportNode = nodeListONe.item(0);
        NodeList reportNodes = firstReportNode.getChildNodes();
        for(int i=0;i<reportNodes.getLength();i++){
            Node currentNode = reportNodes.item(i);
            if(currentNode.getNodeName().equalsIgnoreCase("xsl")){
                reportXSL = DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("filterClass")){
                reportClass = DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("export")){
                export = new Export(currentNode);
                exportFileName = export.getExportFileName();
                exportList.add(export);
            }
        }
        DOMUtil.outputXML(typeXmlDom);
    }

    public Document getTypeXmlDom() {
        return typeXmlDom;
    }

    public String getXmlFileName() {
        return xmlFileName;
    }

    public String getFilterXSL() {
        return filterXSL;
    }

    public String getFilterClass() {
        return filterClass;
    }

    public String getReportXSL() {
        return reportXSL;
    }

    public String getReportClass() {
        return reportClass;
    }

    public Map getReportProperties() {
        return reportProperties;
    }

    public String getExportXSL(String exportType) {
        Iterator iterator = exportList.iterator();
        while(iterator.hasNext()){
            Export export = (Export) iterator.next();
            if(exportType.equalsIgnoreCase(export.getType())){
                return export.getXslPath();
            }
        }
        return exportXSL;
    }

    public List getExportList() {
        return exportList;
    }

    public String getReportName() {
        return reportName;
    }

    public String getExportFileName() {
        return exportFileName;
    }
}
