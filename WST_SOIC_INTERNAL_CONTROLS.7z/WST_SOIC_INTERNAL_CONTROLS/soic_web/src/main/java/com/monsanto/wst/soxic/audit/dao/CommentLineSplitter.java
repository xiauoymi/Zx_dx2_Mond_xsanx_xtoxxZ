package com.monsanto.wst.soxic.audit.dao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 15, 2009
 * Time: 6:40:53 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CommentLineSplitter {
  String[] getEachCommentAsAString(String issueChunk, String type) throws StringSplitException;

  List buildXML(String[] data, StringBuffer issuesBuffer, String originTitle, StringBuffer errorBuffer) throws Exception, StringSplitException;
}
