/*
 * Created on Mar 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.javamail.JavaMailComponent;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class GapHelper {

	public void addGap(String level, List gapList, String ownerid)
			throws Exception {

		if (level.equalsIgnoreCase("C")) {
			insertCyleGap(gapList, ownerid);
		}
		if (level.equalsIgnoreCase("S")) {
			insertSubCyleGap(gapList, ownerid);
		}
		if (level.equalsIgnoreCase("A")) {
			insert(gapList, ownerid);
		}
		if (level.equalsIgnoreCase("AS")) {
			insert(gapList, ownerid);
		}
		if (level.equalsIgnoreCase("CS")) {
			insert(gapList, ownerid);
		}		
	}

	/**
	 * @param activityList
	 * @param ownerid
	 * @throws Exception
	 */
	private void insert(List activityList, String ownerid) throws Exception {

		int responseid = 0;

		Iterator activityIterator = activityList.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			List responseGapList = activity.getResponseGapList();

			Iterator responseIterator = responseGapList.iterator();

			while (responseIterator.hasNext()) {

				ResponseGap responseGap = (ResponseGap) responseIterator.next();

				if (responseGap.getSequenceId() <= 0) {
					responseid = insertGap(ownerid,
							activity.getActivityId(), activity.getQuestionId(),
							responseGap.getType(), responseGap.getComment(),
							responseGap.getAction());

					ControlObjectiveDAO.setGapForLevels(activity
							.getActivityId(), SoxicConstants.ACTIVITY);
					
					GapDAO gapDAO = new GapDAO();
					gapDAO.setOwnerGapToPresent(ownerid,SoxicConstants.ACTIVITY,activity.getActivityId());
					//					ControlObjectiveDAO.updateOwnerResponseStatus(responseid,
					//							SoxicConstants.GREEN_COMPLETE);
					updateOwnerResponseStatus(responseid, ownerid,
							SoxicConstants.GREEN_COMPLETE);
					//					if (ControlObjectiveDAO.isActivityComplete(ownerid,
					//							activity.getActivityId())) {
					//						ControlObjectiveDAO.updateActivityStatus(ownerid,
					//								activity.getActivityId(),
					//								SoxicConstants.GREEN_COMPLETE, true);
					//					}
					//sendEmail(SoxicConstants.ACTIVITY, activity.getActivityId());
					//SarboxMailComponent.sendEmail(SoxicConstants.ACTIVITY, activity.getActivityId());
					
					//SarboxMailComponent.sendEmail(SoxicConstants.ACTIVITY, activity.getActivityId());
				} else {
					updateGap(responseGap.getResponseId(), responseGap
							.getSequenceId(), responseGap.getType(),
							responseGap.getComment(), responseGap.getAction(),
							ownerid);

				}

			}

		}
	}

	/**
	 * Method inserts or updates a gap for a subcycle
	 * 
	 * @param activityList
	 * @param ownerid
	 * @throws Exception
	 */
	private void insertSubCyleGap(List activityList, String ownerid)
			throws Exception {

		int responseid = 0;

		String subCycleOwnerStatus = null;

		Iterator activityIterator = activityList.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			List responseGapList = activity.getResponseGapList();

			Iterator responseIterator = responseGapList.iterator();

			while (responseIterator.hasNext()) {

				ResponseGap responseGap = (ResponseGap) responseIterator.next();

				if (responseGap.getSequenceId() <= 0) {

					responseid = insertGap(ownerid,
							activity.getActivityId(), activity.getQuestionId(),
							responseGap.getType(), responseGap.getComment(),
							responseGap.getAction());

					ControlObjectiveDAO.setGapForLevels(activity
							.getActivityId(), SoxicConstants.SUBCYCLE);
					
					GapDAO gapDAO = new GapDAO();
					
					gapDAO.setOwnerGapToPresent(ownerid,SoxicConstants.SUBCYCLE,activity.getActivityId());

					updateOwnerResponseStatus(responseid, ownerid,
							SoxicConstants.GREEN_COMPLETE);

					//sendEmail(SoxicConstants.SUBCYCLE, activity.getActivityId());
					//SarboxMailComponent.sendEmail(SoxicConstants.SUBCYCLE, activity.getActivityId());

				} else {
					updateGap(responseGap.getResponseId(), responseGap
							.getSequenceId(), responseGap.getType(),
							responseGap.getComment(), responseGap.getAction(),
							ownerid);
				}

			}

		}
	}

	/**
	 * Method inserts or updates a gap for a cycle
	 * 
	 * @param activityList
	 * @param ownerid
	 * @throws Exception
	 */
	private void insertCyleGap(List activityList, String ownerid)
			throws Exception {

		int responseid = 0;

		String cycleOwnerStatus = null;

		Iterator activityIterator = activityList.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			List responseGapList = activity.getResponseGapList();

			Iterator responseIterator = responseGapList.iterator();

			while (responseIterator.hasNext()) {

				ResponseGap responseGap = (ResponseGap) responseIterator.next();

				if (responseGap.getSequenceId() <= 0) {
					responseid = insertGap(ownerid,
							activity.getActivityId(), activity.getQuestionId(),
							responseGap.getType(), responseGap.getComment(),
							responseGap.getAction());

					ControlObjectiveDAO.setGapForLevels(activity
							.getActivityId(), SoxicConstants.CYCLE);
					GapDAO gapDAO = new GapDAO();
					
					gapDAO.setOwnerGapToPresent(ownerid,SoxicConstants.CYCLE,activity.getActivityId());

					updateOwnerResponseStatus(responseid, ownerid,
							SoxicConstants.GREEN_COMPLETE);

				} else {
					updateGap(responseGap.getResponseId(), responseGap
							.getSequenceId(), responseGap.getType(),
							responseGap.getComment(), responseGap.getAction(),
							ownerid);
				}

			}

		}

	}

	private void updateOwnerResponseStatus(String ownerid, String identifier,
			String status, boolean changeStatus, String questionId) {

	}

	private void updateOwnerResponseStatus(int responseId, String ownerid,
			String status) throws Exception {
		StatusDAO statusDAO = new StatusDAO();
		statusDAO.updateOwnerResponseStatus(responseId, ownerid, status);
	}
	
	public void updateOwnerResponseStatusOtherActivity(String identifier,String questionId,String ownerid,String status)throws Exception{
		StatusDAO statusDAO = new StatusDAO();
		statusDAO.updateOwnerResponseStatusOtherActivity(ownerid,identifier,status,questionId);		
	}

	public boolean sendEmail(String level, String identifier) throws Exception {
		//String mailTo[]=new String[25];
		if(SoxicUtil.toSendEmail()){
			int counter=0;
			StatusDAO statusDAO = new StatusDAO();
			if (statusDAO.isCurrentLevelComplete(level, identifier)) {
				UtilDAO utilDAO = new UtilDAO();
				List ownerWrapperList = utilDAO.getUpperLevelOwnerWrapperList(
						level, identifier);
				Iterator ownerIterator = ownerWrapperList.iterator();
				
				while(ownerIterator.hasNext()){
					OwnerWrapper ownerWrapper = (OwnerWrapper)ownerIterator.next();
					//JavaMailComponent.sendMail(ownerWrapper.getEmailid(),"rambabu.bethina@monsanto.com","Sarbanes-Oxley Internal Controls","Please Complete the survey by following link", false);
					JavaMailComponent.sendMail("rambabu.bethina@monsanto.com","rambabu.bethina@monsanto.com","Sarbanes-Oxley Internal Controls","Please Complete the survey by following link", false);
				}
				
				return true;
			}
		}
		return false;
	}

	private void updateGap(int responseId, int sequenceid, String type,
			String comment, String action, String ownerid) throws Exception {
		GapDAO gapDAO = new GapDAO();
		gapDAO
				.updateGap(responseId, sequenceid, type, comment, action,
						ownerid);
	}

	private int insertGap(String ownerid, String activityId, String questionId,
			String type, String comment, String action) throws Exception {
		GapDAO gapDAO = new GapDAO();
		return gapDAO.insertGap(ownerid, activityId, questionId, type, comment,
				action);

	}

}