/*
 * Created on Feb 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.QuestionNew;
import com.monsanto.wst.soxic.model.SoxicBaseModel;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleResponseDAO extends OracleAbstractDAO {

    
    public void setResponse(QuestionNew question) throws DatabaseException{
        
     	Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		
		Collection resultList = new ArrayList();

		String query = buildSelectQuery(question);

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection.prepareStatement(query);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				populateResponse(resultset, question);
			}
		} 
		catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} 
		catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} 
		finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException("OracleDAO - Unable to close database connection : "
						+ e.toString());
			}
		}
		
	}

   
    protected String buildSelectQuery(QuestionNew question) {
      
        StringBuffer query = new StringBuffer();
        query.append(" SELECT RESPONSE, STATUS FROM OWNER_RESPONSE WHERE ");
        
        query.append(buildWhereCriteria(question));
        
        return query.toString();

    }

    /* (non-Javadoc)
     * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#populateModel(java.sql.ResultSet)
     */
    protected void populateResponse(ResultSet rs, QuestionNew question) throws SQLException, Exception {
        
       question.setResponse(rs.getString(QuestionNew.RESPONSE));
       question.setStatus(rs.getString(QuestionNew.STATUS));
       if(question.getResponse().equalsIgnoreCase("no")){
       		question.setDisplayLink(true);
       		//question.setLink();
       }
    }
    
    private StringBuffer buildWhereCriteria(QuestionNew question){
        
        StringBuffer whereCriteria = new StringBuffer();
        
        whereCriteria.append( QuestionNew.OWNER_ID + "= '");
        whereCriteria.append(question.getOwnerId() + "' and ");
        
        whereCriteria.append(QuestionNew.QUESTION_ID +"= '");
        whereCriteria.append(question.getQuestionId() + "' and ");
        
        whereCriteria.append(QuestionNew.ASSOCIATED_ID +"= '");
        whereCriteria.append(question.getAssociatedId() + "'");
        
        return whereCriteria;
    }

    /* (non-Javadoc)
     * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#populateModel(java.sql.ResultSet)
     */
    protected SoxicBaseModel populateModel(ResultSet rs) throws SQLException, Exception {
        // TODO Auto-generated method stub
        return null;
    }
    /* (non-Javadoc)
     * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#buildSelectQuery(java.util.Map)
     */
    protected String buildSelectQuery(Map fields) {
        
      return null;
    }
    
    /* (non-Javadoc)
     * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#update(java.util.Collection)
     */
    public void update(Collection soxicBaseModels) throws DatabaseException {
        // TODO Auto-generated method stub
        
    }

    public int create(SoxicBaseModel soxicBaseModel){
        return -1;
    }



}
