/*
 * Created on Mar 17, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminDetailsForm extends ActionForm{
    
    private List operations;
    private String selectedOperation;
    
    private List cycles;
    private String selectedCycle;
    
    private List subCycles;
    private String selectedSubCycle;
    
    private List controlObjectives;
    private String selectedControlObjective;
    
    private List activities;
    private String selectedActivity;

    private String name ;
    private String description ;
    
    private String startDate;
    private String dueDate ;

    private List activitycodes;

    private boolean applyToAllChildren;
    
    private String change;

    private String codestring;

    /**
     * @return Returns the activities.
     */
    public List getActivities() {
        return activities;
    }
    /**
     * @param activities The activities to set.
     */
    public void setActivities(List activities) {
        this.activities = activities;
    }
    
    /**
     * @return Returns the controlObjectives.
     */
    public List getControlObjectives() {
        return controlObjectives;
    }
    /**
     * @param controlObjectives The controlObjectives to set.
     */
    public void setControlObjectives(List controlObjectives) {
        this.controlObjectives = controlObjectives;
    }
    /**
     * @return Returns the cycles.
     */
    public List getCycles() {
        return cycles;
    }
    /**
     * @param cycles The cycles to set.
     */
    public void setCycles(List cycles) {
        this.cycles = cycles;
    }
    
    /**
     * @return Returns the operations.
     */
    public List getOperations() {
        return operations;
    }
    /**
     * @param operations The operations to set.
     */
    public void setOperations(List operations) {
        this.operations = operations;
    }
    /**
     * @return Returns the selectedActivity.
     */
    public String getSelectedActivity() {
        return selectedActivity;
    }
    /**
     * @param selectedActivity The selectedActivity to set.
     */
    public void setSelectedActivity(String selectedActivity) {
        this.selectedActivity = selectedActivity;
    }
    /**
     * @return Returns the selectedControlObjective.
     */
    public String getSelectedControlObjective() {
        return selectedControlObjective;
    }
    /**
     * @param selectedControlObjective The selectedControlObjective to set.
     */
    public void setSelectedControlObjective(String selectedControlObjective) {
        this.selectedControlObjective = selectedControlObjective;
    }
    /**
     * @return Returns the selectedCycle.
     */
    public String getSelectedCycle() {
        return selectedCycle;
    }
    /**
     * @param selectedCycle The selectedCycle to set.
     */
    public void setSelectedCycle(String selectedCycle) {
        this.selectedCycle = selectedCycle;
    }
    /**
     * @return Returns the selectedOperation.
     */
    public String getSelectedOperation() {
        return selectedOperation;
    }
    /**
     * @param selectedOperation The selectedOperation to set.
     */
    public void setSelectedOperation(String selectedOperation) {
        this.selectedOperation = selectedOperation;
    }
    /**
     * @return Returns the selectedSubCycle.
     */
    public String getSelectedSubCycle() {
        return selectedSubCycle;
    }
    /**
     * @param selectedSubCycle The selectedSubCycle to set.
     */
    public void setSelectedSubCycle(String selectedSubCycle) {
        this.selectedSubCycle = selectedSubCycle;
    }
    
    /**
     * @return Returns the subCycles.
     */
    public List getSubCycles() {
        return subCycles;
    }
    /**
     * @param subCycles The subCycles to set.
     */
    public void setSubCycles(List subCycles) {
        this.subCycles = subCycles;
    }
    /**
     * @return Returns the change.
     */
    public String getChange() {
        return change;
    }
    /**
     * @param change The change to set.
     */
    public void setChange(String change) {
        this.change = change;

    }

    /**
     * @return Returns the description.
     */
    public String getDescription() {

        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;

    }
    /**
     * @return Returns the due.
     */
    public String getDueDate() {

        return dueDate;
    }
    /**
     * @param due The due to set.
     */
    public void setDueDate(String dueDate) {
      if(dueDate!=null){
      	this.dueDate = dueDate.trim();
      }
    }
    /**
     * @return Returns the name.
     */
    public String getName() {

        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        
        this.name = name;
        
    }
    /**
     * @return Returns the start.
     */
    public String getStartDate() {

        return startDate;
    }
    /**
     * @param start The start to set.
     */
    public void setStartDate(String startDate) {
        if(startDate!=null){
        	this.startDate = startDate;
        }
    }
    /**
     * @return Returns the applyToAllChildren.
     */
    public boolean isApplyToAllChildren() {
        return applyToAllChildren;
    }
    /**
     * @param applyToAllChildren The applyToAllChildren to set.
     */
    public void setApplyToAllChildren(boolean applyToAllChildren) {
        this.applyToAllChildren = applyToAllChildren;

    }

    public List getActivitycodes() {
        return activitycodes;
    }

    public void setActivitycodes(List activitycodes) {
        this.activitycodes = activitycodes;
    }

    public String getCodestring() {
        return codestring;
    }

    public void setCodestring(String codestring) {
        this.codestring = codestring;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request){
                
        startDate ="";
        dueDate="";
        name="";
        description="";
        applyToAllChildren=false;
           
    }
}
