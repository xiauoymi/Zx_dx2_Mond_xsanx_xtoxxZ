/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.util;

import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SoxicConstants {
    
    
    /**
	 * Database resource bundle
	 */	
	public static final ResourceBundle dbresource =
		PropertyResourceBundle.getBundle(
			"com.monsanto.wst.soxic.properties.DatabaseResources");
	
	public static final String SUBCYCLELIST="subcyclelist";
	
	public static final String ASSIGNEDACTIVITY = "ASSIGNED";
	
	public static final String ALL = "ALL";
	
	public static final String REMAININGACTIVITY = "REMAINING";
	
    //public static final String INPROCESS   = "INPROCESS";
    
    public static final String IMPORTED   = "IMPORTED";
    
   // public static final String NOT_STARTED = "NotStarted";

    public static final String COMPLETE    = "G_COMPLETE";
    
    public static final String GREEN_IMPORTED = "G_IMPORTED";
    
    public static final String GREEN_NOTSTARTED = "G_NOTSTART";
    
    public static final String GREEN_INPROCESS = "G_INPROC";
    
    public static final String GREEN_COMPLETE = "G_COMPLETE";
    
    public static final String YELLOW_IMPORTED = "Y_IMPORTED";
    
    public static final String YELLOW_NOTSTARTED = "Y_NOTSTART";
    
    public static final String YELLOW_INPROCESS = "Y_INPROC"; 
    
    public static final String RED_IMPORTED = "R_IMPORTED";
    
    public static final String RED_NOTSTARTED = "R_NOTSTART";
    
    public static final String RED_INPROCESS = "R_INPROC";     
    
    public static final String OWNER = "owner";
    
    public static final String ACTIVITY="activity";
    
    public static final String CONTROLOBJECTIVELIST = "controlobjectivelist";
    
    public static final String CONTROLOBJECTIVE = "Control Objective";
    
    public static final String CONTROLACTIVITY = "Control Activity";

    public static final String SUBCYCLE = "Sub Cycle";
    
    public static final String CYCLE = "Cycle";
    
    public static final String NORESPONSE = "no";
    
    public static final String YESRESPONSE ="yes";
    
    public static final String ACTIVITYPRESENT="activitypresent";
    
    public static final String SUBCYCLEPRESENT="subcycleypresent";
    
    public static final String CYCLEPRESENT="cyclepresent";
    
    public static final String SOXICPROPERTYFILE="com.monsanto.wst.soxic.properties.Soxic";

    public static final String SOXIC_APP_RES_FILE="com.monsanto.wst.soxic.ApplicationResources";

    public static final String SOXICPQUERYFILE="com.monsanto.wst.soxic.properties.OracleQueries";
    
    public static final String YELLOWPERIOD="yellow.period";
    
    public static final String REDPERIOD="red.period";
    
    public static final String SMTPSERVER="smtp.server";
    
    //public static final String ORACLE_TEST_SERVER_CONNECTION="oracle.test.server.connection";
    public static final String ORACLE_TEST_SERVER_CONNECTION="oracle.ps.server.connection";
    public static final String ORACLE_PRODUCTION_SERVER_CONNECTION="oracle.prod.server.connection";    
    public static final String ORACLE_TEST_USERNAME="oracle.ps.username";
    public static final String ORACLE_PRODUCTION_USERNAME="oracle.prod.username";  
    public static final String ORACLE_TEST_PWD="oracle.ps.pwd";
    
    public static final String ORACLE_DEV_SERVER_CONNECTION="oracle.dev.server.connection";    
    public static final String ORACLE_DEV_USERNAME="oracle.dev.username";    
    public static final String ORACLE_UNIT_TEST_USERNAME="oracle.unit_test.username";    
    public static final String ORACLE_DEV_PWD="oracle.dev.pwd";
    
    public static final String PASSWORDENC="useencryptedpassword";
    
    public static final String SECFOLLOCALDEV="security.folder.dev.local";
    
    public static final String SECFOLLOCALTEST="security.folder.ps.local";
    
    public static final String SECFOLSEVDEV="security.folder.dev.server";
    
    public static final String SECFOLSEVTEST="security.folder.ps.server";
    
    public static final String SECFOLSEVPROD="security.folder.prod.server";
    
    public static final String SECFOLLOCALPROD="security.folder.prod.local";
    
    public static final String SECENVSEVDEV="env.variable.server.dev";
    
    public static final String SECENVSEVTEST="env.variable.server.ps";
    
    public static final String SECENVLOCALDEV="env.variable.local.dev";
    
    public static final String SECENVLOCALTEST="env.variable.local.ps";
    
    public static final String SECENVLOCALPROD="env.variable.local.prod";
    
    public static final String SECENVSEVPROD="env.variable.server.prod";
    
    public static final String SENDEMAIL="sendemail";
    
    public static final String OPERATION="operation";
    
    public static final String SAVEOPERATION="saveoperation";
    
    public static final String SUBMITOPERATION="submitoperation";
    
    public static final String INPROCSTR="INPROC";
    public static final String COMPSTR="COMPLETE";
    
    public static final String ADMIN="admin";
    public static final String REPORT="report";


    public static final String HOMELINKLOCALTEST="site.home.link.ps.local";
    public static final String HOMELINKLOCALDEV="site.home.link.dev.local";
    public static final String HOMELINKLOCALPROD="site.home.link.prod.local";
    public static final String HOMELINKSEVTEST="site.home.link.ps.server";
    public static final String HOMELINKSEVDEV="site.home.link.dev.server";   
    public static final String HOMELINKSEVPROD="site.home.link.prod.server";
    
    public static final String SAVEINDICATOR ="saveindicator";

    public static final String DELETESTRING="DELETESTRING";

    public static final String CREATENEW_STATE ="INITIATED";
    public static final String DOCCHANGE_STATE="RELEASED";
    public static final String CERTIFICATION_STATE="CERTIFICATION";
    public static final String PRE_CERTIFICATION_STATE="PRE_CERTIFICATION";

    public static final String DOC_CHANGE_LEVEL_ACTIVITY="ACTIVITY";
    public static final String DOC_CHANGE_LEVEL_SUB_CYCLE="SUB_CYCLE";
    
    public static final String CYCLE_STATE ="INITIATED";
    public static final String CYCLE_STATE_RELEASE ="RELEASED";
    public static final String CYCLE_STATE_LOCK ="LOCKED";
    public static final String CYCLE_STATE_PRECERTIFY ="PRE_CERTIFICATION";
    public static final String CYCLE_STATE_CERTIFICATION ="CERTIFICATION";
    public static final String CYCLE_STATE_CERTIFICATION_COMPLETE ="CERT_COMP";

    public static final String CODE="CODE";
    public static final String CATEGORY="CATEGORY";
    public static final String DOC_CHANGE_REQUEST_ADD="ADD";
    public static final String DOC_CHANGE_REQUEST_MODIFY="MODIFY";
    public static final String DOC_CHANGE_REQUEST_DELETE="DELETE";

    public static final String DOC_CHANGE_ROLE_IA="IA";
    public static final String DOC_CHANGE_ROLE_IA_USER="IA_USER";
    public static final String DOC_CHANGE_ROLE_SUB_CYCLE="SUB_CYCLE";
    public static final String DOC_CHANGE_ROLE_ACTIVITY="ACTIVITY";
    public static final String DOC_CHANGE_ROLE_OTHER_ACTIVITY="OTHER_ACTIVITY";

    public static final String DOC_CHANGE_STATUS_REQUEST="REQUESTED";
    public static final String DOC_CHANGE_STATUS_APPROVED="APPROVED";

    public static final String DOC_CHANGE_MODE_NEW="NEW";
    public static final String DOC_CHANGE_MODE_REVIEW="REVIEW";
    public static final String DOC_CHANGE_MODE_MODIFY_TRUE="TRUE";
    public static final String DOC_CHANGE_MODE_MODIFY_FALSE="FALSE";

    public static final String REPORTER = "Reporter";
    public static final String IA_Rep = "IA_Rep";
    public static final String IAU_Rep = "IAU_Rep";

    public static final String ADD_OWNER="Add New Owner";
    public static final String CHANGE_OWNER="Change Owner";
    public static final String COPY_OWNER="Copy Owner";
    public static final String REMOVE_OWNER="Remove Existing Owner";

    public static final String SELECT_PERIOD="Select Period";
    public static final String SELECT_COUNTRY="Select Country";
    public static final String SELECT_CYCLE="Select Cycle";
    public static final String SELECT_SUB_CYCLE="Select Sub Cycle";
    public static final String SELECT_ACTION="Select Action";
    public static final String SELECT_CONTROL_OBJECTIVE="Select Control Objective";
    public static final String SELECT_CONTROL_ACTIVITIES="Select Control Activities";

    public static final String FILE_IMPORT_SUCCESS="SUCCESS";

    public static final String OWNER_STATUS_REPORT_COUNTRY = "countryReport";
    public static final String OWNER_STATUS_REPORT_CYCLE = "cycleReport";
    public static final String OWNER_STATUS_REPORT_SUB_CYCLE = "subcycleReport";

    public static final String CONTEXT_PATH = "/soic";

    public static final String EXPORT_TEMPLATE_REPORT = "Export Templates";
    public static final String OWNER_CERTIFICATION_STATUS_REPORT = "Ownership and Certification Status By Person";
    public static final String ORPHAN_REPORT = "Orphan Report";
    public static final String EMPTY_OWNERID = "EMPTY_OWNER";
    public static final String ALL_UNASSIGNED = "ALL_UNASSIGNED";

    public static final String ACTIVITY_EMAIL_HEADER = "ACTIVITY_EMAIL_HEADER";
    public static final String CYCLE_EMAIL_HEADER = "CYCLE_EMAIL_HEADER";
    public static final String SUB_CYCLE_EMAIL_HEADER = "SUB_CYCLE_EMAIL_HEADER";

     public static final String SIGNIFICANT_CHANGE_BUSINESS = "SIG_CHANGES_TYPE";
    public static final String SIGNIFICANT_CHANGE_PERIOD = "SIG_CHANGE_PERIOD";

    public static final String SIG_CHANGE_SAVE = "SAVE";
    public static final String SIG_CHANGE_SUBMIT = "SUBMIT";
    public static final String NONE = "NONE";

    public static final String CYCLE_QUESTION_HEADER = "CYCLE_QUESTION_HEADER";
    public static final String CYCLE_QUESTION_FOOTER = "CYCLE_QUESTION_FOOTER";
    public static final String SUBCYCLE_QUESTION_HEADER = "SUBCYCLE_QUESTION_HEADER";
    public static final String SUBCYCLE_QUESTION_FOOTER = "SUBCYCLE_QUESTION_FOOTER";
    public static final String ACTIVITY_QUESTION_HEADER = "ACTIVITY_QUESTION_HEADER";
    public static final String ACTIVITY_QUESTION_FOOTER = "ACTIVITY_QUESTION_FOOTER";

    public static final String QUESTION_HEADER = "QUESTION_HEADER";
    public static final String QUESTION_FOOTER = "QUESTION_FOOTER";

    public static final String NOT_SYSTEM_USER = "NOT_SYSTEM_USER";
    public static final String NO_CERTIFICATIONS_FOR_USER = "NO_CERTIFICATIONS_FOR_USER";

    public static final String COUNTRY = "COUNTRY";

    public static final String FAQ_SUCCESS = "FAQ_SUCCESS";
    public static final String DOC_CHANGES_REPORT = "Document Changes Report";
    public static final String ORACLE_UNIT_SERVER_CONNECTION = "oracle.unit_test.server.connection";

    public static final String SUB_CYCLE_ID = "subCycleId";
}

