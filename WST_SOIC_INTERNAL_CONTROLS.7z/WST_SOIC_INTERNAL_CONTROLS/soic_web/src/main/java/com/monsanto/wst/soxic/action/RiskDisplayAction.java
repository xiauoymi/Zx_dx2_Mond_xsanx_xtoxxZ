/*
 * Created on Mar 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.RiskForm;
import com.monsanto.wst.soxic.model.RiskDAO;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class RiskDisplayAction extends Action {

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {

		ActionForward forward = new ActionForward();
		
		RiskForm riskForm = (RiskForm)form;
		
		String level = riskForm.getLevel(request.getParameterMap());
		
		String id = request.getParameter(riskForm.getKey(request.getParameterMap()));
		
		try{
			riskForm.setRiskList(RiskDAO.getRiskList(id,level));
		}catch(Exception e){
			
		}
		


		forward = mapping.findForward("risk");

		return forward;

	}

}