/*
 * Created on Jan 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Activity implements Serializable {

	/**
	 * id for a particular activity
	 */	
	String activityId;
	
	/**
	 * whether the activity is assigned to a particular owner or not
	 */	
	boolean assingned;
	
	/**
	 * Description for a particular activity
	 */
	String description;

	/**
	 * owner for this activity
	 */
	private Owner owner;

	/**
	 * counter for a particular activity
	 */
	private int counter;

	/**
	 * counter for a particular activity
	 */
	private String comment;
	
	/**
	 * counter for a particular activity
	 */	
	private String type;
	
	/**
	 * counter for a particular activity
	 */
	private String questionId;
	
	/**
	 * counter for a particular activity
	 */
	private List responseGapList = new ArrayList();
	
	/**
	 * counter for a particular activity
	 */
	private Date dueDate;
	
	/**
	 * counter for a particular activity
	 */
	private String status;
	
	/**
	 * counter for a particular activity
	 */
	private boolean statusModified=false;

	/**
	 * Sets the over flow id
	 */
	private String overFlowId;

    private String requestChangeId;

    private String requestRemoveId;



	/**
	 * @return Returns the overFlowId.
	 */
	public String getOverFlowId() {
		return overFlowId;
	}
	/**
	 * @param overFlowId The overFlowId to set.
	 */
	public void setOverFlowId(String overFlowId) {
		this.overFlowId = overFlowId;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the dueDate.
	 */
	public Date getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate The dueDate to set.
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return Returns the responseGapList.
	 */
	public List getResponseGapList() {
		return responseGapList;
	}
	/**
	 * @param responseGapList The responseGapList to set.
	 */
	public void setResponseGapList(List responseGapList) {
		this.responseGapList = responseGapList;
	}
	/**
	 * @return Returns the questionId.
	 */
	public String getQuestionId() {
		return questionId;
	}
	/**
	 * @param questionId The questionId to set.
	 */
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return Returns the assingned.
	 */
	public boolean isAssingned() {
		return assingned;
	}
	/**
	 * @param assingned The assingned to set.
	 */
	public void setAssingned(boolean assingned) {
		this.assingned = assingned;
	}
	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the activityId.
	 */
	public String getActivityId() {
		return activityId;
	}
	/**
	 * @param activityId The activityId to set.
	 */
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	/**
	 * @return Returns the owner.
	 */
	public Owner getOwner() {
		return owner;
	}
	/**
	 * @param owner The owner to set.
	 */
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	/**
	 * @return Returns the counter.
	 */
	public int getCounter() {
		return counter;
	}
	/**
	 * @param counter The counter to set.
	 */
	public void setCounter(int counter) {
		this.counter = counter;
	}
	
	/**
	 * @param responseGap
	 */
	public void addResponseGap(ResponseGap responseGap){
		
		int key = getKey(responseGap);
		
		responseGap.setResponseGapId(responseGap.getResponseGapId()+SoxicUtil.getSeperator()+key);
		
		responseGapList.add(responseGap);
	}
	
	/**
	 * @param resgapid
	 * @return
	 */
	public ResponseGap removeResponseGap(String resgapid){
		
		Iterator iterator = responseGapList.iterator();
		
		while(iterator.hasNext()){
			
			ResponseGap responseGap = (ResponseGap)iterator.next();
			
			if(responseGap.getResponseGapId().equalsIgnoreCase(resgapid)){
				
				iterator.remove();
				
				if(responseGap.getSequenceId()>0){
					return responseGap;
				}
				
			}
		}
		
		return null;
	}
	
	/**
	 * @param resgapid
	 * @return
	 */
	public String getResponseGapComment(String resgapid){
		
		Iterator iterator = responseGapList.iterator();
		
		while(iterator.hasNext()){
			
			ResponseGap responseGap = (ResponseGap)iterator.next();
			
			if(responseGap.getResponseGapId().equalsIgnoreCase(resgapid)){
				
				return responseGap.getComment();
			}
		}
		
		return null;
	}
	
	/**
	 * @param resgapid
	 * @param comment
	 */
	public void editResponseGapComment(String resgapid,String comment){
		
		Iterator iterator = responseGapList.iterator();
		
		while(iterator.hasNext()){
			
			ResponseGap responseGap = (ResponseGap)iterator.next();
			
			if(responseGap.getResponseGapId().equalsIgnoreCase(resgapid)){
				
				responseGap.setComment(comment);
			}
		}
		
		
	}
	
	/**
	 * @param responseGap
	 * @return
	 */
	public int getKey(ResponseGap responseGap){
		
		int max=0;
		
		Iterator iterator = responseGapList.iterator();
		
		while(iterator.hasNext()){
			
			ResponseGap resGap = (ResponseGap)iterator.next();
			
			if(responseGap.getAct_Type().equalsIgnoreCase(resGap.getAct_Type())){
				
				int temp = resGap.getKey();
				
				if(temp>max){
					max=temp;
				}
			}
		}
		return max;		
	}
	
	/**
	 * 
	 */
	public void clear(){
		if(responseGapList!=null)
		responseGapList.clear();
	}
	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "Activity Info          :"    + '\n');
        buffer.append('\n'+ "Activity Id            :"    + activityId+ '\n');
        buffer.append('\n'+ "Activity Descrtiption  :"    + description+ '\n');
        buffer.append('\n'+ "Activity Status        :"    + status+ '\n');
        buffer.append('\n'+ "Activity Due Date      :"    + dueDate+ '\n');
        return buffer.toString();
    }
	/**
	 * @return Returns the statusModified.
	 */
	public boolean isStatusModified() {
		return statusModified;
	}
	/**
	 * @param statusModified The statusModified to set.
	 */
	public void setStatusModified(boolean statusModified) {
		this.statusModified = statusModified;
	}

    public String getRequestChangeId() {
        return requestChangeId;
    }

    public void setRequestChangeId(String requestChangeId) {
        this.requestChangeId = requestChangeId;
    }

    public String getRequestRemoveId() {
        return requestRemoveId;
    }

    public void setRequestRemoveId(String requestRemoveId) {
        this.requestRemoveId = requestRemoveId;
    }
}
