/*
 * Created on Jun 23, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailWrapper {
	
	private String emailAddress = "";
	private List ownerList =null;
	private List dueDateList = null;
    /**
     * for admin owner details populate the list of activities , sub - cycles or cycles for which change has occured
     */
    private List modelList = new ArrayList();


	/**
	 * @return Returns the dueDateList.
	 */
	public List getDueDateList() {
		return dueDateList;
	}
	/**
	 * @param dueDateList The dueDateList to set.
	 */
	public void setDueDateList(List dueDateList) {
		if(this.dueDateList==null){
			this.dueDateList = new ArrayList();
		}
		this.dueDateList = dueDateList;
	}
	/**
	 * @return Returns the emailAddress.
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress The emailAddress to set.
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	/**
	 * @return Returns the ownerList.
	 */
	public List getOwnerList() {
		return ownerList;
	}
	/**
	 * @param ownerList The ownerList to set.
	 */
	public void setOwnerList(List ownerList) {
		if(this.ownerList == null){
			this.ownerList = new ArrayList();
		}
		this.ownerList = ownerList;
	}

    public List getModelList() {
        return modelList;
    }

    public void setModelList(List modelList) {
        this.modelList = modelList;
    }

    public void setAdminModelList(List cycles,List subCycles,List activities){
        if(cycles!=null){
            addModel(cycles);
        }
        if(subCycles!=null){
            addModel(subCycles);
        }
        if(activities!=null){
            addModel(activities);
        }
    }

    private void addModel(List modelListIn){
        Iterator iterator = modelListIn.iterator();
        while(iterator.hasNext()){
           modelList.add((String)iterator.next());
        }
    }
}
