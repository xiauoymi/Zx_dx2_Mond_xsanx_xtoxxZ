/*
 * Created on Mar 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.Iterator;
import java.util.List;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class NewsItem {
    
    private String id;
    private String title;
    private String body;
    private String role;
    
    private List assignedRoles;

    /**
     * @return Returns the assignedRoles.
     */
    public List getAssignedRoles() {
        return assignedRoles;
    }
    /**
     * @param assignedRoles The assignedRoles to set.
     */
    public void setAssignedRoles(List assignedRoles) {
        this.assignedRoles = assignedRoles;
    }
    /**
     * @return Returns the body.
     */
    public String getBody() {
        return body;
    }
    /**
     * @param body The body to set.
     */
    public void setBody(String body) {
        this.body = body;
    }
    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(String id) {
        this.id = id;
    }
    /**
     * @return Returns the role.
     */
    public String getRole() {
        
        role = "";
        if(assignedRoles != null && !assignedRoles.isEmpty()){
            Iterator itr = assignedRoles.iterator();
            while(itr.hasNext()){
                role = role+ ", "+itr.next().toString();
            }
        }
              
        return role;
    }
    /**
     * @param role The role to set.
     */
    public void setRole(String role) {
        this.role = role;
    }
    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }
}
