package com.monsanto.wst.soxic.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.ControlObjectiveDAO;
import com.monsanto.wst.soxic.model.ControlObjectiveFacade;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.SubCycleDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/**
 * MyEclipse Struts Creation date: 01-31-2005
 * 
 * XDoclet definition:
 * 
 * @struts:action validate="true"
 */
public class ActivityControlObjectiveDisplayAction extends Action {

	/**
	 * Method is responsible for populating the Activities for a particular 
	 * owner
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)throws Exception {
		
		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) form;

		ActionForward forward = new ActionForward();

		//Get the owner id from the sesion
		Owner owner = (Owner) request.getSession().getAttribute("owner");

		//list containing id-description of the sub cycles
		List subCycleList = null;

		//list containing ControlObjective Objects
		List controlObjList = null;

			//Get all the subcycles in which activities are present and
			//the owner is the owner of these activities
			subCycleList = SubCycleDAO.getSubCycles(owner.getOwnerId(),SoxicConstants.CERTIFICATION_STATE);

			//Set the sub-cycles
			controlObjectiveForm.setSubCycleList(subCycleList);
			
			//Get all the control objectives for the first sub-cycle			
			ControlObjectiveFacade facade = new ControlObjectiveFacade();			
			controlObjList = facade.getControlObjectives(controlObjectiveForm.getSubCycleId(0), owner);
			
			//if subcycle owner has completed his certification Submit button is locked down
			controlObjectiveForm.setLockSubmit(SubCycleDAO.isSubCycleLocked(controlObjectiveForm.getSubCycleId(0)));
			controlObjectiveForm.setCurrentSubCycle(controlObjectiveForm.getSubCycleId(0));
		
			//Get the gaps for control objectives
			ControlObjectiveDAO.getGapMap(controlObjList);

			//Set the control objective list in the form
			controlObjectiveForm.setControlObjectiveList(controlObjList);

            //test comment

		forward = mapping.findForward("success");

		return forward;

	}
}