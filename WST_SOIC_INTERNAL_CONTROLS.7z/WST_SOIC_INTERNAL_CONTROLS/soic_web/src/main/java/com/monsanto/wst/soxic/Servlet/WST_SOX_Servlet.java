package com.monsanto.wst.soxic.Servlet;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 9:43:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class WST_SOX_Servlet extends GatewayServlet{
   public static final String s_cstrResourceBundle = "com.monsanto.wst.soxic.Servlet.WST_SOX";

   public WST_SOX_Servlet()
   {
      super(600);  // Set the session timeout values in seconds. (600)
   }

   public void init(ServletConfig servletConfig) throws ServletException
   {
      super.init(servletConfig);

      Logger.traceEntry();

      try {
         Logger.register(WST_SOXLoggerFactory.buildTraceLogger(s_cstrResourceBundle));
         Logger.register(WST_SOXLoggerFactory.buildDebugLogger(s_cstrResourceBundle));
         Logger.register(WST_SOXLoggerFactory.buildInfoLogger(s_cstrResourceBundle));
         Logger.register(WST_SOXLoggerFactory.buildWarningLogger(s_cstrResourceBundle));
         Logger.register(WST_SOXLoggerFactory.buildErrorLogger(s_cstrResourceBundle));
         Logger.register(WST_SOXLoggerFactory.buildAuditLogger(s_cstrResourceBundle));

         Logger.log(new DebugLogEvent("Debug Log Event"));
      }
      catch (LogRegistrationException lre) {
         throw new ServletException(lre.toString());
      }
      catch (IOException ioe) {
         throw new ServletException(ioe.toString());
      }

      Logger.traceExit();
   }

   public void destroy()
   {
      Logger.traceEntry();

      try {
         PersistentStore.registerInstance(null);
      }
      catch (WrappingException e) {
      }

      super.destroy();

      Logger.traceExit();
   }

   /**
    * This static method will create an instance of the desired PersistentStore based on
    * data within a property file.
    * @param request - The HttpServlet Request from the servlet container
    * @param response - The HttpServletResponse to be sent back to the servlet container.
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

      try {

         /*  Register the persistent store with this servlet instance.  */
         PersistentStore ps = WST_SOX_PersistentStoreFactory.getStore(s_cstrResourceBundle);
         PersistentStore.registerInstance(ps);

         /*  Pass the doGet along.  */
         super.doGet(request, response);
      }
      catch (WrappingException we) {
         helper.reportError("Error accessing database.  Please notify your technical support contact or try again later.\n" + we.toString());
         helper.closeSession();
      }

      Logger.traceExit();
   }
}
