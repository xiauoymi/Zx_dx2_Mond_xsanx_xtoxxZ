/*
 * Created on May 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.exception;

/**
 * @author vrbethi
 */
public class InvalidUserException extends Exception {
	public InvalidUserException(){
		super();
	}
	
	public InvalidUserException(Exception e){
		super(e);
	}
}
