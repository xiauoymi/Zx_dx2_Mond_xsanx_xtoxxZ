/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.mock;

import java.util.Date;

import com.monsanto.wst.soxic.model.ControlObjective;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MockControlObjective extends ControlObjective {
    
    public MockControlObjective(String id){
        setMockData(id);
    }
    
    public void setMockData(String id){
        
        setControlObjectiveDate(new Date().toLocaleString());
        setControlObjectiveDeficiency("Defeciency " + id);
        setControlObjectiveDescription("Description "+ id);
        setControlObjectiveGap("gap "+ id);
        setControlObjectiveId(id);
       // setActivities(ActivityDAO.getAllActivities(id));
    }

    public static void main(String[] args) {
    }
}
