package com.monsanto.wst.soxic.workflow.gapoperations;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 1:04:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityGapDAO extends GapDAO{

    public ActivityGapDAO(String env,String fol){
        super(env,fol);
    }
//    public List selectEntity() {
//        List entityList = new ArrayList();
//        Connection connection = null;
//        PreparedStatement preparedStatement=null;
//        ResultSet rs=null;
//        try{
//            connection = SoxicConnectionFactory.getSoxicConnection();
//            preparedStatement = connection.prepareStatement("");
//
//
//        }catch (SQLException e) {
//            //throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        catch (Exception e) {
//            // throw new DatabaseException(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            try {
//                if(rs!=null){
//                    rs.close();
//                }
//                if (preparedStatement != null)
//                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//        return null;  //To change body of implemented methods use File | Settings | File Templates.
//    }

    protected String getAllGapsPerEntityQuery() {
        return "SELECT POTENTIAL_GAP FROM OWNER_ACTIVITY WHERE ACTIVITY_ID=?";
    }

    protected String getUpdateEntityQuery() {
        return "UPDATE ACTIVITY SET POTENTIAL_GAP=? WHERE ACTIVITY_ID=?";  //To change body of implemented methods use File | Settings | File Templates.
    }

//    public List selectOwnerEntity() {
//        return null;  //To change body of implemented methods use File | Settings | File Templates.
//    }

    protected String getIdentifierType() {
        return ActivityGap.ACTIVITY_ID;
    }

    protected String getOwnerEntityQuery() {
        //return "SELECT OA.ACTIVITY_ID,OA.OWNER_ID,OA.POTENTIAL_GAP FROM OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID LIKE '%FY05.AUS.BU.01.14.07%'";
        return "SELECT OA.ACTIVITY_ID,OA.OWNER_ID,OA.POTENTIAL_GAP FROM OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID LIKE '%FY05.%'";
        //return "SELECT OA.ACTIVITY_ID,OA.OWNER_ID,OA.POTENTIAL_GAP FROM OWNER_ACTIVITY OA";
    }

    protected String getOwnerEntityQueryWithGaps() {
        return "SELECT OA.ACTIVITY_ID,OA.OWNER_ID FROM OWNER_ACTIVITY OA,OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE OA.ACTIVITY_ID=ORS.ASSOCIATED_ID AND OA.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getEntityQuery() {
        return "SELECT A.ACTIVITY_ID,A.POTENTIAL_GAP FROM ACTIVITY A WHERE A.ACTIVITY_ID LIKE '%FY05.%'";  //To change body of implemented methods use File | Settings | File Templates.
        //return "SELECT A.ACTIVITY_ID,A.POTENTIAL_GAP FROM ACTIVITY A WHERE A.ACTIVITY_ID LIKE '%FY05.AUS.BU.01.14.07%'";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getUpdateNoGapYesAnswerQuery() {
        return "UPDATE OWNER_ACTIVITY OA SET OA.POTENTIAL_GAP=? WHERE OA.ACTIVITY_ID=? AND OA.OWNER_ID=?";
    }

    protected String getUpdateOwnerEntityQuery() {
        return "UPDATE OWNER_ACTIVITY OA SET OA.POTENTIAL_GAP=? WHERE OA.ACTIVITY_ID=? AND OA.OWNER_ID=?";
    }

    protected String getUpdateNoGapNoAnswerQuery() {
        return "UPDATE OWNER_ACTIVITY OA SET OA.POTENTIAL_GAP=? WHERE OA.ACTIVITY_ID=? AND OA.OWNER_ID=?";
    }

    protected  String getSelectNoGapYesAnswerQuery() {
        return "SELECT OA.ACTIVITY_ID,OA.OWNER_ID,OA.POTENTIAL_GAP,ORS.RESPONSE,ORS.RESPONSE_ID,ORS.QUESTION_ID FROM OWNER_ACTIVITY OA,OWNER_RESPONSE ORS WHERE OA.ACTIVITY_ID = ORS.ASSOCIATED_ID AND OA.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE = 'YES' AND OA.POTENTIAL_GAP='Y' AND ORS.RESPONSE_ID NOT IN (SELECT RESPONSE_ID FROM GAP_DC_LOE)";
    }

    protected String getSelectNoGapNoAnswerQuery() {
        return "SELECT ORS.RESPONSE_ID,OA.ACTIVITY_ID,ORS.QUESTION_ID,OA.OWNER_ID FROM OWNER_ACTIVITY OA,OWNER_RESPONSE ORS WHERE OA.ACTIVITY_ID = ORS.ASSOCIATED_ID AND OA.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE = 'NO' AND OA.POTENTIAL_GAP='Y' AND ORS.RESPONSE_ID NOT IN (SELECT RESPONSE_ID FROM GAP_DC_LOE)";
    }



}
