package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.ExportTemplateForm;
import com.monsanto.wst.soxic.model.AdminTemplateDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.facade.AdminViewTemplateFacade;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 5, 2005
 * Time: 11:41:30 AM
 * 
 * This action class contains 2 methods. The first method retrieves the cycles
 * based on the country selected from the drop-down. The second method
 * retrieves the sub-cycles for the first cycle and diplays them. If the list of
 * cycles or subcycles is empty, a NullAndArrayIndexException is thrown.
 */

public class CycleforViewTemplateAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        ExportTemplateForm exporttemplateform = (ExportTemplateForm)form;
        AdminViewTemplateFacade adminViewTemplateFacade = new AdminViewTemplateFacade();
        adminViewTemplateFacade.buildCyclesAndSubCycles(exporttemplateform);
        return mapping.findForward("cycleviewtemplates");
    }


}
