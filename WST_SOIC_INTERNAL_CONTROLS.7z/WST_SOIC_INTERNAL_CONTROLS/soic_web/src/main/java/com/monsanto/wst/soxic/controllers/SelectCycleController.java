package com.monsanto.wst.soxic.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.facade.reports.OwnerStatusReportFacade;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 22, 2005
 * Time: 10:47:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class SelectCycleController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        OwnerStatusReportFacade ownerStatusReportFacade = new OwnerStatusReportFacade();
        getCyclesOnPeriodAndCountry(ownerStatusReportFacade,helper);
    }

    private void getCyclesOnPeriodAndCountry(OwnerStatusReportFacade ownerStatusReportFacade, UCCHelper helper) throws IOException {
        try {
            ownerStatusReportFacade.buildCycleListOnSelection(helper);
        } catch (DatabaseException e) {
            e.printStackTrace();  
        }
    }
}
