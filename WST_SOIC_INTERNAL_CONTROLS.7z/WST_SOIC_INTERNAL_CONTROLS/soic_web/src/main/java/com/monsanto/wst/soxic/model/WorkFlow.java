package com.monsanto.wst.soxic.model;

import java.sql.Date;
import java.util.Calendar;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 15, 2005
 * Time: 11:02:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class WorkFlow extends SoxicBaseModel{
    public static final String WORK_FLOW_ID="WF_ID";
    public static final String DESCRIPTION="DESCRIPTION";
    public static final String ACTIVE="ACTIVE";
    public static final String LAST_RUN_DATETIME="LAST_RUN_DATETIME";
    public static final String INTERVAL_TYPE="INTERVAL_TYPE";
    public static final String INTERVAL_VALUE="INTERVAL_VALUE";
    public static final String INTERVAL_DATETIME="INTERVAL_DATETIME";

    public static final String INTERVAL_TYPE_DAILY="DAILY";
    public static final String INTERVAL_TYPE_WEEKLY="WEEKLY";
    public static final String INTERVAL_TYPE_HOURLY="HOURLY";
    public static final String INTERVAL_TYPE_MONTHLY="MONTHLY";




    private String workFlowId;
    private String description;
    private boolean active;
    private Date lastRunDate;
    private String intervalType;
    private int intervalValue;
    private Date intervalDateTime;

    public WorkFlow(Date lastRunDateIn,String intervalTypeIn,int intervalValueIn){
        lastRunDate = lastRunDateIn;
        intervalType = intervalTypeIn;
        intervalValue = intervalValueIn;
    }

    public String getId(){
        return "";
    }

    public String getWorkFlowId() {
        return workFlowId;
    }

    public void setWorkFlowId(String workFlowId) {
        this.workFlowId = workFlowId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Date getLastRunDate() {
        return lastRunDate;
    }

    public void setLastRunDate(Date lastRunDate) {
        this.lastRunDate = lastRunDate;
    }

    public String getIntervalType() {
        return intervalType;
    }

    public void setIntervalType(String intervalType) {
        this.intervalType = intervalType;
    }

    public int getIntervalValue() {
        return intervalValue;
    }

    public void setIntervalValue(int intervalValue) {
        this.intervalValue = intervalValue;
    }

    public Date getIntervalDateTime() {
        return intervalDateTime;
    }

    public void setIntervalDateTime(Date intervalDateTime) {
        this.intervalDateTime = intervalDateTime;
    }

    public boolean run(){
        if(runDailyProcess()){
            return true;
        }
        return false;
    }

    private boolean runDailyProcess(){
        if(intervalType.equalsIgnoreCase(INTERVAL_TYPE_DAILY)){
            Date lastRun = new Date(lastRunDate.getTime()+(24*60*60*1000));
            Calendar toCompareDateBasedOnLastRunDate = Calendar.getInstance();
            toCompareDateBasedOnLastRunDate.setTime(lastRun);
            Calendar todayDate = Calendar.getInstance();
            if(todayDate.get(Calendar.YEAR)==toCompareDateBasedOnLastRunDate.get(Calendar.YEAR)){
                if(todayDate.get(Calendar.MONTH)==toCompareDateBasedOnLastRunDate.get(Calendar.MONTH)){
                    if(todayDate.get(Calendar.DATE)==toCompareDateBasedOnLastRunDate.get(Calendar.DATE)){
                        return true;
                    }
                }
            }

        }
        return false;
    }

    public String getOwnerId(){
        return "";
    }
}
