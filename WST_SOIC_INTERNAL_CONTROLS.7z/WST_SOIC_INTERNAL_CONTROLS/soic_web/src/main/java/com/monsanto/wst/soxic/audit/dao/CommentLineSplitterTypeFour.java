package com.monsanto.wst.soxic.audit.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.soxic.audit.util.PatternMatcher;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 15, 2009
 * Time: 6:41:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommentLineSplitterTypeFour implements CommentLineSplitter {
  private static final String MR_RP_NOTPRESENT = "MR_RP_NOTPRESENT";


  public String[] getEachCommentAsAString(String issueChunk, String type) {
    System.out.println("issueChunk = " + issueChunk);
   String memoCommentsDelimiter = "Major";
    String typeDelimiter = "Audit Subject:";
    String[] strings = issueChunk.split(memoCommentsDelimiter);

//    String majorCount = getData(memoCommentsDelimiter, typeDelimiter, issueChunk);
//    String[] data =null;
//    if(!StringUtils.isNullOrEmpty(majorCount)){
//      if(majorCount.trim().contains(":")){
//        int count = Integer.parseInt(majorCount.replaceAll(":","").trim());
//        data = new String[count];
//        for(int j=0;j<count;j++){
//          String start = type+ (j+1) + " of " + count;
//          String end = type+ (j+2) + " of " + count;
//          data[j]= getDataModified(start, end, issueChunk);
//        }
//      }
//    }
    return strings;
  }


  private static HashMap<String,String> userCatMap;


  public CommentLineSplitterTypeFour() {
      populateUserCatMap();
  }

  private String getData(String start, String end, String issueChunk) throws StringSplitException {
    try{
//     return issueChunk;
    if(StringUtils.isNullOrEmpty(end)){
      return issueChunk.substring(issueChunk.indexOf(start)+start.length());
    }
//    int endIndex = getEndIndex(issueChunk, end);
    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),issueChunk.indexOf(end));
    }catch(Exception e){
      throw new StringSplitException("Error splitting: Start -"+start+" End -"+end, e);
    }
  }

  private String getDataModified(String start, String end, String issueChunk) {
//     return issueChunk;
    if(StringUtils.isNullOrEmpty(end)){
      return issueChunk.substring(issueChunk.indexOf(start)+start.length());
    }
    int endIndex = getEndIndex(issueChunk, end);
//    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),issueChunk.indexOf(end));
    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),endIndex);
  }

  private int getEndIndex(String issueChunk, String endString) {
    int endIndex = issueChunk.indexOf(endString);
    if(endIndex<0){
      return issueChunk.length();
    }
    return endIndex;
  }
//Comment Title: 	Improper Direct Interaction with Government Officials 
  // Comment Subject: 	Improper Direct Interaction with Government Officials 
// Observation: 	Through management interviews it was noted that an employee delivers cash to governmental agencies in Egypt for legalization. The cost is documented via government issued price list and the governmental agencies will not take a check or accept wire transfer.   In addition, Seminis Hungary has direct interaction with government officials (OMMI - field tester), universities and the seed association (QA), without receiving Working Group approval. This interaction includes payments for field testing. 
  // Cause: 	FIN - Compliance with Policy and Laws 
// Recommendation: 	Management should communicate this information to the Working Group and request an exemption. Furthermore, there should be an internal control process in place to monitor these transactions and expenses. Finally, on a quarterly basis this information should be reviewed by the Working Group.  In addition, due diligence for all seed associations and universities should be performed and approved by the Working Group prior to making a payment. 
  // Risk: 	* Possible noncompliance with the Foreign Corrupt Practices Act * Possible noncompliance with the Deferred Prosecution Agreement * Possible noncompliance with Monsanto Business Conduct policies 
// Repeat Flag: 	N   
  // Associated Activities  FCPA.03.04.02	Verify that contracts are written. Identify any activities that the licensee does on behalf of Monsanto with the government. (i.e. - licensees may file permits for Monsanto products) 2> Type:
  public List buildXML(String[] data, StringBuffer issuesBuffer, String originTitle, StringBuffer errorBuffer) throws Exception, StringSplitException {
    String[] delimiters = new String[]{"Type:","Comment Title:",
            "Comment Subject:","Observation:","Management Response:","Responsible Party:",
            "Cause:","Recommendation:","Risk:","Repeat Flag:","Associated Activities"};
    String typeStr= "";
    String titleStr= "";
    String textField4 = "";
    String finding = "";
    String textField2 = "";
    String userCat2 = "";
    String textField1 = "";
    String textField3= "";
    String textField10= "";
    String issueChunk= "";
    List issueList = new ArrayList();
    for(int i=0;i<data.length;i++){
      issueChunk = data[i].trim();
      String returnString = checkForDuplicateDelimiters(issueChunk,delimiters,i,data.length);
      if("NONE".equals(returnString)  && issueChunk.length()>50){
       // typeStr = getData(delimiters[0], delimiters[1], issueChunk);
        String condition = getCondition(issueChunk);
        if(condition!=null && condition.equalsIgnoreCase(MR_RP_NOTPRESENT)){
        
          titleStr = getData(delimiters[1], delimiters[2], issueChunk);
          textField4 = getData(delimiters[2], delimiters[3], issueChunk);
          finding = getData(delimiters[3], delimiters[6], issueChunk);
//          textField2 = getData(delimiters[4], delimiters[5], issueChunk);
          textField2 = "";
          userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
          textField1 = getData(delimiters[7], delimiters[8], issueChunk);
          textField3 = getData(delimiters[8], delimiters[9], issueChunk);
          textField10 = getData(delimiters[10],"", issueChunk);
        }   else{
          titleStr = getData(delimiters[1], delimiters[2], issueChunk);
          textField4 = getData(delimiters[2], delimiters[3], issueChunk);
          finding = getData(delimiters[3], delimiters[4], issueChunk);
          textField2 = getData(delimiters[4], delimiters[5], issueChunk);
          userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
          textField1 = getData(delimiters[7], delimiters[8], issueChunk);
          textField3 = getData(delimiters[8], delimiters[9], issueChunk);
          textField10 = getData(delimiters[10],"", issueChunk);

        }


        Issue issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
        issueList.add(issue1);
      }else{
//        errorBuffer.append(returnString);
      }
    }
    return issueList;
  }

  private String getCondition(String issueChunk) {
    if(issueChunk.indexOf("Management Response:")==-1
            && issueChunk.indexOf("Responsible Party:")==-1
             ) {
      return MR_RP_NOTPRESENT;
    }

    return null;  //To change body of created methods use File | Settings | File Templates.
  }

  private Issue constructIssueSection(StringBuffer issuesBuffer, String typeStr, String titleStr,
                                     String textField4, String finding, String textField2, String userCat2,
                                     String textField1, String textField3, String originTitle, String textField10) {
    Issue issue = new Issue();
    issue.setIssueId("1000");
    issue.setTitle(replaceOccurences(titleStr.trim()));
    issue.setType(replaceOccurences(typeStr.trim()));
    issue.setTextField4(replaceOccurences(textField4.trim()));
    issue.setFinding(replaceOccurences(finding.trim()));
    issue.setTextField2(replaceOccurences(textField2.trim()));
    issue.setTextField1(replaceOccurences(textField1.trim()));
    issue.setTextField3(replaceOccurences(textField3.trim()));
    issue.setTextField10(replaceOccurences(textField10.trim()));
    issue.setArea(originTitle);
    issue.setUserCat2(appendUserCat2(issuesBuffer, userCat2, issue));
    appendIssueTag(issuesBuffer);
    issuesBuffer.append("<TITLE>"+replaceOccurences(titleStr.trim())+"</TITLE>");
    issuesBuffer.append("<TYPE ID=\"67108931\">"+replaceOccurences(typeStr.trim())+"</TYPE>");
    issuesBuffer.append("<TEXTFIELD4 Format=\"text\">"+replaceOccurences(textField4.trim())+"</TEXTFIELD4>");
    issuesBuffer.append("<FINDING Format=\"text\">"+replaceOccurences(finding.trim())+"</FINDING>");
    issuesBuffer.append("<TEXTFIELD2 Format=\"text\">"+replaceOccurences(textField2.trim())+"</TEXTFIELD2>");
    appendUserCat2(issuesBuffer, userCat2, issue);
    issuesBuffer.append("<TEXTFIELD1 Format=\"text\">"+replaceOccurences(textField1.trim())+"</TEXTFIELD1>");
    issuesBuffer.append("<TEXTFIELD3 Format=\"text\">"+replaceOccurences(textField3.trim())+"</TEXTFIELD3>");
    issuesBuffer.append("<TEXTFIELD10 Format=\"text\">"+replaceOccurences(textField10.trim())+"</TEXTFIELD10>");
    issuesBuffer.append("<ORIGIN><AREA ID=\"-1207959550\">"+originTitle+"</AREA></ORIGIN>");
    issuesBuffer.append("</ISSUE>");
    return issue;
  }

  public String checkForDuplicateDelimiters(String issueChunk, String[] delimiters, int majorIndex, int length) {
    int count = 0;
    int index = 0;
    StringBuffer tempBuffer = new StringBuffer();
    for(int i=0;i<delimiters.length;i++){
      count = 0;
      index = 0;
      while ((index = issueChunk.indexOf(delimiters[i], index)) != -1) {
        ++index;
        ++count;
      }
      if(count > 1){
        tempBuffer.append("Major "+(majorIndex+1)+" of "+length+",\t"+delimiters[i]+"\n");
      }
    }
    if(tempBuffer.length() > 0 ) return tempBuffer.toString();
    return "NONE";
  }

  private static String replaceOccurences(String description) {
    return PatternMatcher.findAndReplace(description);
  }

  private String appendUserCat2(StringBuffer issuesBuffer, String userCat2, Issue issue) {
    String userCat2Desc = replaceOccurences(userCat2.trim());
    issue.setUserCat2(userCat2Desc);
    issuesBuffer.append("<USERCAT2 ID=\""+userCatMap.get(userCat2Desc)+"\">"+userCat2Desc+"</USERCAT2>");
    String id = userCatMap.get(userCat2Desc);
    issue.setUserCat2Id(id);
    return id;
  }

  private void populateUserCatMap() {
    if(userCatMap == null){
      userCatMap = new HashMap<String,String>();
      //FIN
      userCatMap.put("FIN - Compliance with Policy and Laws","1275068482");
      userCatMap.put("FIN-Reconciliation & Review","1275068487");
      userCatMap.put("FIN-Revenue/Receivables","1275068472");
      userCatMap.put("FIN-Approval","1275068422");
      userCatMap.put("FIN-FCPA & Management Practices","1275068456");
      userCatMap.put("FIN-General Ledger","1275068460");
      userCatMap.put("FIN-Classification","1275068480");
      userCatMap.put("FIN-Inventory - Seed","1275068463");
      userCatMap.put("FIN-DOA","67108959");
      userCatMap.put("FIN-Valuation","1275068489");
      userCatMap.put("FIN-Timing","1275068488");
      userCatMap.put("FIN-Procurement","1275068470");
      userCatMap.put("FIN-Segregation of Duties","67108960");
      userCatMap.put("FIN-Contracts","1275068450");
      userCatMap.put("FIN-Comply with Contract","1275068481");
      userCatMap.put("FIN-Inventory","1275068464");
      userCatMap.put("FIN-Other","1275068485");
      userCatMap.put("FIN-Asset Safegurading","1275068510");
      //test
      userCatMap.put("FIN - Approval","1275068422");
      userCatMap.put("FIN - Asset Safeguarding","1275068510");
      userCatMap.put("FIN - Reconciliation and Review","1275068487");




      //IT
      userCatMap.put("IT-Windows Security","1275068478");
      userCatMap.put("IT-Process Control","1275068469");
      userCatMap.put("IT-SAP Security","1275068473");
      userCatMap.put("IT-System Development & Maint.","1275068474");
      userCatMap.put("IT-Database Security - ORACLE","1677721597");
      userCatMap.put("IT-Backup & Recovery","1275068449");
      userCatMap.put("IT-Exchange","1275068458");
      userCatMap.put("IT-Network","1275068466");
      userCatMap.put("IT-Database Security - SQL","-1677721598");
      userCatMap.put("IT-Wireless Networking","1275068479");

    }

  }

  private void appendIssueTag(StringBuffer issuesBuffer) {
//    issuesBuffer.append("<ISSUE ID=\""+String.valueOf(issueId++)+"\">");
  }

}