package com.monsanto.wst.soxic.audit;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 12:33:56 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@Table(schema = "SARBOX_ET", name="OWNER_ACTIVITY")
public class OwnerActivityObj implements Serializable{

  @Id
  private OwnerActivityPK pk = new OwnerActivityPK();

  @SuppressWarnings("unused")
  @Column(name="ACTIVITY_ID",insertable = false,updatable = false,nullable = false)
  private String activityId;

  @SuppressWarnings("unused")
  @Column(name="OWNER_ID",insertable = false,updatable = false,nullable = false)
  private String ownerId;

  @Column(name="STATUS")
  private String status;

  @Column(name="START_DATE",nullable = true)
  private Date startDate;

  @Column(name="DUE_DATE",nullable = true)
  private Date dueDate;

  @Column(name="COMPLETE_DATE",nullable = true)
  private Date completeDate;

  @Column(name="POTENTIAL_GAP",nullable = true)
  private String gap;

  @Column(name="MOD_DATE")
  private Date modDate;

  @Column(name="MOD_USER")
  private String modUser;

  @OneToOne
  @JoinColumn(name = "OWNER_ID",insertable = false,updatable = false)
  private OwnerObj owner;
  
  public String getActivityId() {
    return activityId;
  }

  public void setActivityId(String activityId) {
    this.activityId = activityId;
  }

  public String getOwnerId() {
    return ownerId;
  }

  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public Date getCompleteDate() {
    return completeDate;
  }

  public void setCompleteDate(Date completeDate) {
    this.completeDate = completeDate;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public OwnerActivityPK getPk() {
    return pk;
  }

  public void setPk(OwnerActivityPK pk) {
    this.pk = pk;
  }
   public ActivityObj getActivityTest() {
    return pk.getActivity();
  }

  public void setActivityTest(ActivityObj activityTest) {
    pk.setActivity(activityTest);
  }

  public OwnerObj getOwnerTest() {
    return pk.getOwner() ;
  }

  public void setOwnerTest(OwnerObj ownerTest) {
    pk.setOwner(ownerTest);
  }

  public OwnerObj getOwner() {
    return owner;
  }

  public void setOwner(OwnerObj owner) {
    this.owner = owner;
  }
}
