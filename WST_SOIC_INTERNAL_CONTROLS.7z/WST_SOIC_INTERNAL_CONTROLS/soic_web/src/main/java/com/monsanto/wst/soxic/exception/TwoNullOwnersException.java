package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 9:50:37 AM
 */
public class TwoNullOwnersException extends Exception {
	public TwoNullOwnersException(){
		super();
	}

	public TwoNullOwnersException(Exception e){
		super(e);
	}
}
