/*
ExcelHeaderBean was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/

package com.monsanto.wst.soxic.importProject;


/**
 * For the Header info on each excel file
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */

public class ExcelHeaderBean {

	
	private String cycleOwner;  //**Cell A1
	
	private String subCycleOwner;  //**Cell A2
	
	private String worldArea;  //**Cell A3
	
	private String country;   //**Cell A4
	
	private String cycleDesc;	//**Cell E1
	
	private String subCycleDesc;	//**Cell E2

    private String cycleID;

	/**
     * @return Returns the cycleDesc.
     */
    public String getCycleDesc() {
        return cycleDesc;
    }
    /**
     * @param cycleDesc The cycleDesc to set.
     */
    public void setCycleDesc(String cycleDesc) {
        this.cycleDesc = cycleDesc;
    }
    /**
     * @return Returns the subCycleDesc.
     */
    public String getSubCycleDesc() {
        return subCycleDesc;
    }
    /**
     * @param subCycleDesc The subCycleDesc to set.
     */
    public void setSubCycleDesc(String subCycleDesc) {
        this.subCycleDesc = subCycleDesc;
    }
	
	//**Getter and Setter for CycleOwner...
	public String getCycleOwner(){
		return cycleOwner;
	}
	
	public void setCycleOwner(String val1){
		cycleOwner = val1;
	}
	
	//**Getter and Setter for SubCycleOwner...
	public String getSubCycleOwner(){
		return subCycleOwner;
	}
	
	public void setSubCycleOwner(String val2){
		subCycleOwner = val2;
	}
	
	
	//**Getter and Setter for WorldArea...
	public String getWorldArea(){
		return worldArea;
	}
	
	public void setWorldArea(String val3){
		worldArea = val3;
	}
	
	
	//**Getter and Setter for Country...
	public String getCountry(){
		return country;
	}
	
	public void setCountry(String val4){
		country = val4;
	}

    public String getCycleID() {
        return cycleID;
    }

    public void setCycleID(String cycleID) {
        this.cycleID = cycleID;
    }

//	public static void main(String[] args) {
//	}
}