package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 5, 2005
 * Time: 11:04:47 AM
 *
 * This DAO is used by the AdminViewTemplateFacade. This DAO contains methods
 * to retrieve countries, cycles based on the country selected and
 * retrieve subcycles based on the cycle selected. If the List is null in any
 * method, a NullAndArrayIndexException is thrown.
 */
public class AdminTemplateDAO {

    private static final String getAllPeriodsForTemplateExport =
            "SELECT DISTINCT P.PERIOD_ID AS PERIOD, P.SEQUENCE " +
            "FROM PERIOD P, CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC " +
            "WHERE C.CYCLE_ID = CS.CYCLE_ID " +
            "AND C.CYCLE_ID = SC.CYCLE_ID " +
            "AND CS.PERIOD_ID = P.PERIOD_ID " +
            "ORDER BY P.SEQUENCE DESC";

    public List getPeriodsForViewTemplates() throws Exception {
        List periodList = new ArrayList();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getAllPeriodsForTemplateExport);
                rs = preparedStatement.executeQuery();
                while(rs.next()){
                    periodList.add(rs.getString("PERIOD"));
                }
            if (periodList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return periodList;
    }

     /**
	 * Returns a list of Countries
	 * @return List
	 * @throws Exception
      * @param selectedPeriod
      */
	public List getCountriesforViewTemplates(String selectedPeriod)throws Exception{
		List countryList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement
                        ("SELECT DISTINCT C.COUNTRY_ID " +
                                "from CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC, PERIOD P " +
                                "WHERE C.CYCLE_ID = CS.CYCLE_ID " +
                                "AND C.CYCLE_ID = SC.CYCLE_ID " +
                                "AND CS.PERIOD_ID = P.PERIOD_ID " +
                                "AND P.PERIOD_ID = ?");
                preparedStatement.setString(1,selectedPeriod);
                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    countryList.add(rs.getString("COUNTRY_ID"));
				}
            if (countryList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return countryList;
	}

    /**
     * Returns a list of cycles based on the country selected by the user.
     * @param countryid
     * @param firstPeriod
     * @return List
     * @throws Exception
     */
    public List getCyclesforViewTemplates(String countryid, String firstPeriod)throws Exception{
		List cycleList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement
                        ("SELECT DISTINCT C.CYCLE_ID " +
                                "FROM CYCLE C, CYCLE_STATE CS,SUB_CYCLE SC, PERIOD P " +
                                "WHERE C.CYCLE_ID = CS.CYCLE_ID " +
                                "AND C.CYCLE_ID = SC.CYCLE_ID " +
                                "AND CS.PERIOD_ID = P.PERIOD_ID " +
                                "AND C.COUNTRY_ID = ? " +
                                "AND P.PERIOD_ID = ? " +
                                "ORDER BY C.CYCLE_ID ASC");
                preparedStatement.setString(1,countryid);
                preparedStatement.setString(2,firstPeriod);
                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    cycleList.add(rs.getString("CYCLE_ID"));
				}
            if (cycleList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }

		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cycleList;
	}

    /**
     * Returns a list of sub-cycles based on the cycle selected by the user
     * @param cycleid
     * @return List
     * @throws Exception
     */
    public List getSubCyclesforViewTemplates(String cycleid)throws Exception{
		List subcycleList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        SubCycle subCycle = null;

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT SC.SUB_CYCLE_ID, SC.DESCRIPTION FROM SUB_CYCLE SC,CYCLE_STATE CS WHERE SC.CYCLE_ID = CS.CYCLE_ID AND SC.CYCLE_ID=? ORDER BY SC.SUB_CYCLE_ID ASC");
			    preparedStatement.setString(1,cycleid);

                rs = preparedStatement.executeQuery();

			    while(rs.next()){
                    String subcycleId = rs.getString("SUB_CYCLE_ID");
                    String subcycleDesc = rs.getString("DESCRIPTION");
                    subCycle = new SubCycle(subcycleId,subcycleDesc);
                    subcycleList.add(subCycle);
				}
            if (subcycleList.size()==0){
                throw new NullAndArrayIndexException(new Exception());
            }
		    } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				//con.close();
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subcycleList;
	}


}
