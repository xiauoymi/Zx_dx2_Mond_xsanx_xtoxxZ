/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.text.DateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author VRBEHTI
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivityNew extends SoxicBaseModel implements Comparable{
    
    public static final String ACTIVITY_ID   = "ACTIVITY_ID";
    public static final String ACTIVITY_CODE = "ACTIVITY_CODE";
    public static final String CTRL_OBJ_ID   = "CTRL_OBJ_ID";
    public static final String DESCRIPTION   = "DESCRIPTION";
    public static final String OVERFLOW_ID   = "OVERFLOW_ID";
    public static final String STATUS        = "STATUS";
    public static final String POTENTIAL_GAP = "POTENTIAL_GAP";
    public static final String PREV_DEF      = "PREV_DEF";
    public static final String OWNER_ID      = "OWNER_ID";
    public static final String DUE_DATE      = "DUE_DATE";
    public static final String OWNER_NAME    = "NAME";
    public static final String QUESTION_ID   = "QUESTION_ID";
    public static final String CTRL_CODE_TYPE = "TYPE";
    public static final String CTRL_CODE      ="CODE";
    public static final String PRIORITY       = "PRIORITY";

    private String activityId;
    private String activityCode;
    private String ctrlObjCode;
    private String description;
    private String status;
    private String gap;
    private String deficiency;
    private String ownerName;
    
    private Date   dueDate;
    private String ownerId;
    
    private String ownerActivity;
    private String displayStatus;
    private String questionId;

    private String codeType;
    private String code;
    private String controlObjectiveId;
    private int overFlowId;

    private String priority;


	/**
	 * @return Returns the ownerActivity.
	 */
	public String getOwnerActivity() {
		return ownerActivity;
	}

    public String getActivityCode() {
        return activityCode;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    /**
	 * @param ownerActivity The ownerActivity to set.
	 */
	public void setOwnerActivity(String ownerActivity) {
		this.ownerActivity = ownerActivity;
	}

    /**
     * @return Returns the activityId.
     */
    public String getActivityId() {
        return activityId;
    }
    /**
     * @param activityId The activityId to set.
     */
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return Returns the dueDate.
     */
    public Date getDueDate() {
        return dueDate;
    }
    /**
     * @param dueDate The dueDate to set.
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
    /**
     * @return Returns the gap.
     */
    public String getGap() {
        return gap;
    }
    /**
     * @param gap The gap to set.
     */
    public void setGap(String gap) {
        this.gap = gap;
        if(gap==null){
        	if(status!=null && status.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
        		this.gap="N";
        	}
        }
        
    }
    /**
     * @return Returns the ownerId.
     */
    public String getOwnerId() {
        return ownerId;
    }
    /**
     * @param ownerId The ownerId to set.
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
    /**
     * @return Returns the ownerName.
     */
    public String getOwnerName() {
        return ownerName;
    }
    /**
     * @param ownerName The ownerName to set.
     */
    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
    /**
     * @return Returns the status.
     */
    public String getStatus() {
        
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM);
        if(getDueDate() != null)
        return status+ " - " + dateFormat.format(getDueDate());
        
        return status;
    }
    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }
        
	/**
	 * @return Returns the displayStatus.
	 */
	public String getDisplayStatus() {
		displayStatus = SoxicUtil.getDisplayStatus(status);
		return displayStatus;
	}
	
	/**
	 * @param displayStatus The displayStatus to set.
	 */
	public void setDisplayStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}
	
    /**
     * @return Returns the deficiency.
     */
    public String getDeficiency() {
        return deficiency;
    }
    /**
     * @param deficiency The deficiency to set.
     */
    public void setDeficiency(String deficiency) {
        this.deficiency = deficiency;
    }
    
    public int compareTo(Object o){
    	int value = ((ActivityNew)o).activityId.compareTo(activityId);
    	return -value;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "Activity Info :"    + '\n');
        buffer.append("ActivityId :"+ activityId + '\n');
        buffer.append("Status 	  :"+ getStatus()+'\n');
        buffer.append("Gap        :"+ gap        + '\n');
        buffer.append("Deficiency :"+ deficiency + '\n');
        buffer.append("OwnerName  :"+ ownerName  + '\n');
        buffer.append("DueDate    :"+ dueDate    + '\n');
        buffer.append("OwnerId    :"+ ownerId    + '\n');
       
        return buffer.toString();
    }

    public String getId(){
        return activityId;
    }

    public String getActivityCodeIntegerPart(){
        String intpart="";
        StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        String currentActivityId= stringTokenizer.nextToken();

        String regEx = "\\d+";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(currentActivityId);
        while(matcher.find()){
            intpart = matcher.group();
            break;
        }

        return intpart;
    }

    public String getActivityCodePart(){
        StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        String currentActivityId= stringTokenizer.nextToken();
        return currentActivityId;
    }

    public String getCtrlObjCode(){
        StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        return period+"."+countryId+"."+cycleId+"."+subCycleId+"."+controlObjectiveId;      
    }

    public void setCtrlObjCode(String codeIn){
        ctrlObjCode = codeIn;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getControlObjectiveId() {
        return controlObjectiveId;
    }

    public void setControlObjectiveId(String controlObjectiveId) {
        this.controlObjectiveId = controlObjectiveId;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

}
