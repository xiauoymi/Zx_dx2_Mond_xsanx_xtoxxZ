package com.monsanto.wst.soxic.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.facade.reports.OwnerStatusReportFacade;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 3, 2006
 * Time: 11:50:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class SelectSubCyclesOnCycleController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        OwnerStatusReportFacade ownerStatusReportFacade = new OwnerStatusReportFacade();
        getSubCycleListBasedOnCycle(helper,ownerStatusReportFacade);
    }

    private void getSubCycleListBasedOnCycle(UCCHelper helper, OwnerStatusReportFacade ownerStatusReportFacade) throws IOException {
        try {
            ownerStatusReportFacade.buildSubCyclesBasedOnCycle(helper);
        } catch (DatabaseException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
