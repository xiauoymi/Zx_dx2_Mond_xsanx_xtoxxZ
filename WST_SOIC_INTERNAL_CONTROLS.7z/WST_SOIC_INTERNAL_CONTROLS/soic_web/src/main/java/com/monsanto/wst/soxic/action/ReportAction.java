/*
ReportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/



package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ReportForm;
import com.monsanto.wst.soxic.form.RowObject;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

/**
 * This is the action that displays the template to JSP page.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class ReportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		
		Vector columnData = new Vector();
		
		ReportForm reportForm = (ReportForm) form;
		
//		String sub_cycle_id = request.getSession().getAttribute("subCycleTemplateID").toString();
		
		String sub_cycle_id = request.getParameter("showSubCycleTemplate");
		
		reportForm.setSubCycleID(sub_cycle_id);
		
		String coId = "";
		Connection con=null;
		
		
		
		//**Connecting to the Oracle DB...
		try{
			//Class.forName("oracle.jdbc.driver.OracleDriver");

//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();

		 	logger.info("Connected to DB.");

			//**Prepared Statements...
			PreparedStatement getSubCycleActivities;
			PreparedStatement getCountryWorld;
			PreparedStatement getSubCycleOwner;
			PreparedStatement getCycleOwner;
			PreparedStatement getSubCycleDesc;
            PreparedStatement getActivityCodes;
            PreparedStatement getGapDescription;
            PreparedStatement getOwners;
            PreparedStatement getLocations;

			//****************CHUNKING********************************************************************
			PreparedStatement getActivityDescChunk;
			PreparedStatement getCODescChunk;

			getActivityDescChunk = con.prepareStatement
				("SELECT " +
						"T.TEXT_CHUNK " +
					"FROM " +
						"ACTIVITY A, TEXT_OVERFLOW T " +
					"WHERE " +
						"A.ACTIVITY_ID = ? AND " +
						"T.OVERFLOW_ID = A.OVERFLOW_ID " +
					"ORDER BY T.SEQUENCE");

			getCODescChunk = con.prepareStatement
				("SELECT " +
						"T.TEXT_CHUNK " +
					"FROM " +
						"CTRL_OBJ C, TEXT_OVERFLOW T " +
					"WHERE " +
						"C.CTRL_OBJ_ID = ? AND " +
						"T.OVERFLOW_ID = C.OVERFLOW_ID    ORDER BY T.SEQUENCE");

			//********************************************************************************************


//			getSubCycleActivities = con.prepareStatement
//				("SELECT " +
//						"A.ACTIVITY_ID, CO.DESCRIPTION DESC1, CO.CATEGORY, CO.TEMPLATE_CODE, " +
//						"A.DESCRIPTION DESC2, CO.RISK, O.OWNER_ID, O.LOCATION, CO.CTRL_OBJ_ID " +
//				 "FROM " +
//				 		"CTRL_OBJ CO, ACTIVITY A, OWNER O, OWNER_ACTIVITY OA " +
//				 "WHERE " +
//				 		"CO.SUB_CYCLE_ID = ? AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
//				 		"A.ACTIVITY_ID = OA.ACTIVITY_ID AND O.OWNER_ID = OA.OWNER_ID ORDER BY A.ACTIVITY_ID");

//            getSubCycleActivities = con.prepareStatement
//				("SELECT " +
//						"A.ACTIVITY_ID, CO.DESCRIPTION DESC1, " +
//						"A.DESCRIPTION DESC2, CO.RISK, O.OWNER_ID, O.LOCATION, CO.CTRL_OBJ_ID " +
//				 "FROM " +
//				 		"CTRL_OBJ CO, ACTIVITY A, OWNER O, OWNER_ACTIVITY OA " +
//				 "WHERE " +
//				 		"CO.SUB_CYCLE_ID = ? AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
//				 		"A.ACTIVITY_ID = OA.ACTIVITY_ID AND O.OWNER_ID = OA.OWNER_ID ORDER BY A.ACTIVITY_ID");

             getSubCycleActivities = con.prepareStatement
				("SELECT " +
						"A.ACTIVITY_ID, A.PRIORITY, CO.DESCRIPTION DESC1, " +
						"A.DESCRIPTION DESC2, CO.RISK, O.OWNER_ID, O.LOCATION, CO.CTRL_OBJ_ID " +
				 "FROM " +
				 		"CTRL_OBJ CO, ACTIVITY A, OWNER O, OWNER_ACTIVITY OA " +
				 "WHERE " +
				 		"CO.SUB_CYCLE_ID = ? AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
				 		"A.ACTIVITY_ID = OA.ACTIVITY_ID AND O.OWNER_ID = OA.OWNER_ID ORDER BY A.ACTIVITY_ID");


            /**
             * @author rgeorge
             * get the activity codes & control objective codes based on activity_id
             * & subcycle_id
             */
            getActivityCodes = con.prepareStatement
                    ("SELECT COC.TYPE, COC.CODE " +
                    "  FROM ACTIVITY A, CTRL_OBJ CO, CTRL_OBJ_CODES COC " +
                    " WHERE CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                    "   AND A.ACTIVITY_ID = COC.ACTIVITY_ID " +
                    "   AND CO.SUB_CYCLE_ID = ? AND COC.ACTIVITY_ID = ?");

			getCountryWorld = con.prepareStatement
					("SELECT " +
							"CY.COUNTRY_ID, CY.WORLD_AREA_ID, CY.DESCRIPTION, CY.PERIOD_ID " +
					 "FROM " +
					 	"CYCLE CY, SUB_CYCLE SC " +
					 "WHERE " +
					 	"SC.SUB_CYCLE_ID = ? AND " +
					 	"SC.CYCLE_ID = CY.CYCLE_ID");


			getSubCycleOwner = con.prepareStatement
 				("SELECT DISTINCT " +
 						"O.OWNER_ID " +
 				"FROM " +
 					"OWNER O, SUB_CYCLE SC, OWNER_SUB_CYCLE OSC " +
 				"WHERE " +
 					"SC.SUB_CYCLE_ID = ? AND " +
 					"SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID AND " +
 					"OSC.OWNER_ID = O.OWNER_ID");

			getCycleOwner = con.prepareStatement
  				("SELECT DISTINCT " +
  						"O.OWNER_ID " +
  				"FROM " +
  					"OWNER O, SUB_CYCLE SC, OWNER_CYCLE OC, CYCLE C " +
  				"WHERE " +
  					"SC.SUB_CYCLE_ID = ? AND " +
  					"SC.CYCLE_ID = C.CYCLE_ID AND " +
  					"C.CYCLE_ID = OC.CYCLE_ID AND " +
  					"OC.OWNER_ID = O.OWNER_ID");


			getSubCycleDesc = con.prepareStatement("SELECT " +
						"SC.DESCRIPTION " +
					"FROM " +
						"SUB_CYCLE SC " +
					"WHERE " +
						"SC.SUB_CYCLE_ID = ?");


            /**
             * @author rgeorge
             * query to select the gaps depending on the activity_id
             */
            getGapDescription = con.prepareStatement
                    ("SELECT OWR.ASSOCIATED_ID, G.DESCRIPTION " +
                    "FROM OWNER_RESPONSE OWR, GAP_DC_LOE G, ACTIVITY A, CTRL_OBJ CO " +
                    "WHERE OWR.RESPONSE_ID = G.RESPONSE_ID " +
                    "AND A.ACTIVITY_ID = OWR.ASSOCIATED_ID " +
                    "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                    "AND CO.SUB_CYCLE_ID = ? " +
                    "AND A.ACTIVITY_ID = ?");

//            getOwners = con.prepareStatement
//                    ("SELECT OA.OWNER_ID " +
//                    "FROM CTRL_OBJ CO, ACTIVITY A, OWNER_ACTIVITY OA " +
//                    "WHERE A.ACTIVITY_ID = OA.ACTIVITY_ID " +
//                    "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
//                    "AND CO.SUB_CYCLE_ID = ? AND A.ACTIVITY_ID = ? " +
//                    "ORDER BY A.ACTIVITY_ID");
//
//            getLocations = con.prepareStatement
//                    ("SELECT O.LOCATION " +
//                    "FROM CTRL_OBJ CO, ACTIVITY A, OWNER_ACTIVITY OA, OWNER O " +
//                    "WHERE A.ACTIVITY_ID = OA.ACTIVITY_ID " +
//                    "AND O.OWNER_ID = OA.OWNER_ID " +
//                    "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
//                    "AND CO.SUB_CYCLE_ID = ? AND A.ACTIVITY_ID = ? " +
//                    "ORDER BY A.ACTIVITY_ID");

			getSubCycleActivities.setString(1, sub_cycle_id);
			ResultSet rs = getSubCycleActivities.executeQuery();

			//**For not displaying same CODesc/risk for same CoID
			String tempcoId = "";

			String actId = "";
			String tempActId = "";
			String lastActId = "";
            String catstring = "";
            String codestring = "";
            String gapdesc = "";
            String ownerids = "";
            String locations = "";

			RowObject row1;
			RowObject row2;

			while (rs.next()) {

				RowObject rowObject = new RowObject();

				tempActId = rs.getString("ACTIVITY_ID");

				tempcoId = rs.getString("CTRL_OBJ_ID");

			    rowObject.setCol1(rs.getString("ACTIVITY_ID") + "");

                if(rs.getString("PRIORITY") != null){
					rowObject.setCol9(rs.getString("PRIORITY"));
				}
				else{
					rowObject.setCol9("");
				}

                if(rs.getString("DESC1") != null){
						//rowObject.setCol2( rs.getString("DESC1") + "");

						String completeCODesc = "";
						completeCODesc = rs.getString("DESC1") + "";

						//*************************************CHUNKING*********************************************
						try{
							getCODescChunk.setString(1, rs.getString("CTRL_OBJ_ID").toString());
							ResultSet rsCOChunk = getCODescChunk.executeQuery();

							while(rsCOChunk.next()){
								completeCODesc += rsCOChunk.getString("TEXT_CHUNK");
							}
						}
						catch(Exception sqle){
							logger.error(sqle.getMessage());
						}
						//******************************************************************************************

						rowObject.setCol2(completeCODesc);
                }
//				if(tempcoId.equals(coId) && !tempActId.equals(actId)){
//					rowObject.setCol2("");
//
//				}
//				else{
//					if(rs.getString("DESC1") != null){
//						//rowObject.setCol2( rs.getString("DESC1") + "");
//
//						String completeCODesc = "";
//						completeCODesc = rs.getString("DESC1") + "";
//
//						//*************************************CHUNKING*********************************************
//						try{
//							getCODescChunk.setString(1, rs.getString("CTRL_OBJ_ID").toString());
//							ResultSet rsCOChunk = getCODescChunk.executeQuery();
//
//							while(rsCOChunk.next()){
//								completeCODesc += rsCOChunk.getString("TEXT_CHUNK");
//							}
//						}
//						catch(Exception sqle){
//							logger.error(sqle.getMessage());
//						}
//						//******************************************************************************************
//
//						rowObject.setCol2(completeCODesc);
//					}
//					else{
//						rowObject.setCol2("");
//
//					}
//				}

                getActivityCodes.setString(1, sub_cycle_id);
                getActivityCodes.setString(2, tempActId);
			    ResultSet rs1 = getActivityCodes.executeQuery();

                while (rs1.next()){
                    if((rs1.getString("TYPE") != null) && (rs1.getString("TYPE").equalsIgnoreCase("CATEGORY"))){
                        if(catstring.length()==0) {
                            catstring = catstring + rs1.getString("CODE");
                            } else{
                                catstring = catstring + "," + rs1.getString("CODE");
                            }
                        }
                    else if((rs1.getString("TYPE") != null) && (rs1.getString("TYPE").equalsIgnoreCase("CODE"))){
                        if(codestring.length()==0) {
                            codestring = codestring + rs1.getString("CODE");
                            } else{
                                codestring = codestring + "," + rs1.getString("CODE");
                            }
                        }
                    }

                rowObject.setCol3(catstring);
                catstring = "";
                rowObject.setCol4(codestring);
                codestring = "";


//				if(rs.getString("TYPE") != null){
//					rowObject.setCol3(rs.getString("TYPE") + "");
//				}
//				else{
//					rowObject.setCol3("");
//				}
//
//				if(rs.getString("CODE") != null){
//					rowObject.setCol4( rs.getString("CODE") + "");
//				}
//				else{
//					rowObject.setCol4("");
//				}

				if(rs.getString("DESC2") != null){

					String completeActivityDesc = "";
					completeActivityDesc = rs.getString("DESC2") + "";

					//*************************************CHUNKING*********************************************
					try{
						getActivityDescChunk.setString(1, rs.getString("ACTIVITY_ID").toString());
						ResultSet rsActivityChunk = getActivityDescChunk.executeQuery();

						while(rsActivityChunk.next()){
							completeActivityDesc += rsActivityChunk.getString("TEXT_CHUNK");
						}
					}
					catch(Exception sqle){
						logger.error(sqle.getMessage());
					}
					//******************************************************************************************

					rowObject.setCol5(completeActivityDesc);
				}
				else{
					rowObject.setCol5("");
				}

//				if(tempcoId.equals(coId) && !tempActId.equals(actId)){
//					rowObject.setCol6("");
//				}
//				else{
//					rowObject.setCol6( rs.getString("RISK") + "");
//					coId = tempcoId;
//				}

//                if(tempcoId.equals(coId) && !tempActId.equals(actId)){
//					rowObject.setCol6("");
//				}
//				else{
                    if(rs.getString("RISK")!=null){
					    rowObject.setCol6( rs.getString("RISK") + "");
					    coId = tempcoId;
                    }else{
 					    rowObject.setCol6("");
					    coId = tempcoId;
                    }
//
//				}

                if(rs.getString("OWNER_ID") != null){
					rowObject.setCol7(rs.getString("OWNER_ID"));
				}
				else{
					rowObject.setCol7(rs.getString(""));
				}

//                getOwners.setString(1, sub_cycle_id);
//                getOwners.setString(2, tempActId);
//                ResultSet rso = getOwners.executeQuery();
//                while (rso.next()){
//                    if(rso.getString("OWNER_ID") != null){
//                        if(ownerids.length()==0) {
//                            ownerids = ownerids + rso.getString("OWNER_ID");
//                        } else{
//                                ownerids = ownerids + "," + rso.getString("OWNER_ID");
//                        }
//                    }
//                }
//                rowObject.setCol7(ownerids);
//                ownerids = "";

//                getLocations.setString(1, sub_cycle_id);
//                getLocations.setString(2, tempActId);
//                ResultSet rsl = getLocations.executeQuery();
//                while (rsl.next()){
//                    if(rsl.getString("LOCATION") != null){
//                        if(locations.length()==0) {
//                            locations = locations + rsl.getString("LOCATION");
//                        } else{
//                                locations = locations + "," + rsl.getString("LOCATION");
//                        }
//                    }
//                }
//                rowObject.setCol8(locations);
//                locations = "";


                if(rs.getString("LOCATION") != null){
					rowObject.setCol8(rs.getString("LOCATION"));
				}
				else{
					rowObject.setCol8("");
				}

                getGapDescription.setString(1, sub_cycle_id);
                getGapDescription.setString(2, tempActId);
			    ResultSet rsg = getGapDescription.executeQuery();

                while (rsg.next()){
                    if (rsg.getString("DESCRIPTION")!= null){
                        if(gapdesc.length()==0) {
                            gapdesc = gapdesc + rsg.getString("DESCRIPTION");
                            } else{
                                gapdesc = gapdesc + "," + rsg.getString("DESCRIPTION");
                            }
                        rowObject.setCol12(gapdesc);
                    }

//                    else{
//                        rowObject.setCol11("");
//                    }
                }
                gapdesc = "";

				columnData.add(rowObject);

				//**check for dup ActId with multiple users...
				if(tempActId.equals(actId)){
					//**Modify user/loc of current one and Remove prev one...
					row1 = (RowObject)columnData.get(columnData.size() - 2);
					row2 = (RowObject)columnData.get(columnData.size() -1 );

					row2.setCol7(row1.getCol7() + ",\u0020" + row2.getCol7());
					row2.setCol8(row1.getCol8() + ",\u0020" + row2.getCol8());

					columnData.removeElementAt(columnData.size() - 2);

				}

				actId = tempActId;
//                coId = tempcoId;
			}

			//**Activity with more than one Owners..
			//**Remove if performance degrades.
//			RowObject row1;
//			RowObject row2;
//			for(int indx = 0; indx < columnData.size() - 1; indx++){
//				row1 = (RowObject)columnData.get(indx);
//				row2 = (RowObject)columnData.get(indx + 1);
//
//				String act1 = row1.getCol1();
//				String act2 = row2.getCol1();
//
//				if(act1.equals(act2)){
//					row2.setCol7(row1.getCol7() + ", " + row2.getCol7());
//					row2.setCol8(row1.getCol8() + ", " + row2.getCol8());
//
//					columnData.removeElementAt(indx);
//				}
//
//			}

			reportForm.setColumnVector(columnData);

			String countryId = "";
			String worldArea = "";

			Vector subcycleOwner = new Vector();
			Vector cycleOwner = new Vector();

			//**Country, World Area...
			getCountryWorld.setString(1, sub_cycle_id);
			rs = getCountryWorld.executeQuery();


			String cycleDesc = "";
			String periodID = "";
			while(rs.next()){
				countryId = rs.getString("COUNTRY_ID");
				worldArea = rs.getString("WORLD_AREA_ID");
				cycleDesc = rs.getString("DESCRIPTION");
				periodID = rs.getString("PERIOD_ID");
			}

			//**Sub Cycle Owners...
			getSubCycleOwner.setString(1, sub_cycle_id);
			rs = getSubCycleOwner.executeQuery();

			while(rs.next()){
				subcycleOwner.add(rs.getString("OWNER_ID"));
			}

			//**Cycle Owners...
			getCycleOwner.setString(1, sub_cycle_id);
			rs = getCycleOwner.executeQuery();

			while(rs.next()){
				cycleOwner.add(rs.getString("OWNER_ID"));
			}


			//**Cycle Owners...
			getSubCycleDesc.setString(1, sub_cycle_id);
			rs = getSubCycleDesc.executeQuery();

			String subCycleDesc = "";
			while(rs.next()){
				subCycleDesc = rs.getString("DESCRIPTION");
			}


			reportForm.setPeriodID(periodID);
			reportForm.setCycleDesc(cycleDesc);
			reportForm.setSubCycleDesc(subCycleDesc);
			reportForm.setCountryId(countryId);
			reportForm.setWorldArea(worldArea);
			reportForm.setSubCycleOwners(subcycleOwner);
			reportForm.setCycleOwners(cycleOwner);


		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			try{
				if(con!=null && !con.isClosed()){
					con.close();
				}
			}catch(Exception e){
				
			}
		}
		
		return mapping.findForward("success");
	}

}
