package com.monsanto.wst.soxic.form;

import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 9:40:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerCertificationStatusReportForm extends ActionForm{

    private String period;
    private List allPeriods;
    private String ownerid;
    private String ownername;
    private List cycles;
    private List sub_cycles;
    private List activities;

    public void reset(ActionMapping mapping, HttpServletRequest request) {
        this.ownerid=null;
        this.ownername=null;
        this.period=null;
    }

    public ActionErrors validate(
        ActionMapping mapping,HttpServletRequest request) {
		ActionErrors errors = new ActionErrors();

        if (ownerid==null || ownerid.length()==0){
            errors.add("own_id", new ActionError("empty.owner"));
        }
        return errors;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getOwnerid() {
        return ownerid;
    }

    public void setOwnerid(String ownerid) {
        this.ownerid = ownerid;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public List getSub_cycles() {
        return sub_cycles;
    }

    public void setSub_cycles(List sub_cycles) {
        this.sub_cycles = sub_cycles;
    }

    public List getActivities() {
        return activities;
    }

    public void setActivities(List activities) {
        this.activities = activities;
    }   

    public List getAllPeriods() {
        return allPeriods;
    }

    public void setAllPeriods(List allPeriods) {
        this.allPeriods = allPeriods;
    }

}
