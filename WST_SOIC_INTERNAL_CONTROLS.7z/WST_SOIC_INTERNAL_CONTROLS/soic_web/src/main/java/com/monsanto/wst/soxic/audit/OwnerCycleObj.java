package com.monsanto.wst.soxic.audit;

import javax.persistence.*;
import java.util.Date;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 1:23:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema="SARBOX_ET",name="OWNER_CYCLE")
public class OwnerCycleObj implements Serializable{

  @Id
  private OwnerCyclePK pk = new OwnerCyclePK();

  @SuppressWarnings("unused")
  @Column(name = "OWNER_ID",insertable = false,updatable = false,nullable = false)
  private String ownerId;

  
  @SuppressWarnings("unused")
  @Column(name = "CYCLE_ID",insertable = false,updatable = false,nullable = false)
  private String cycleId;

  @Column(name= "STATUS")
  private String status;

  @Column(name= "START_DATE")
  private Date startDate;

  @Column(name= "DUE_DATE")
  private Date dueDate;

  @Column(name= "COMPLETE_DATE")
  private Date completeDate;

  @Column(name= "POTENTIAL_GAP")
  private String gap;

  @Column(name= "MOD_DATE")
  private Date modDate;

  @Column(name= "MOD_USER")
  private String modUser;

  @Column(name= "SIGNIFICANT_CHANGE_ID")
  private Integer changeId;

 

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public Date getCompleteDate() {
    return completeDate;
  }

  public void setCompleteDate(Date completeDate) {
    this.completeDate = completeDate;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Integer getChangeId() {
    return changeId;
  }

  public void setChangeId(Integer changeId) {
    this.changeId = changeId;
  }

  public OwnerCyclePK getPk() {
    return pk;
  }

  public void setPk(OwnerCyclePK pk) {
    this.pk = pk;
  }

  public String getCycleId() {
    return cycleId;
  }

  public void setCycleId(String cycleId) {
    this.cycleId = cycleId;
  }

  public String getOwnerId() {
    return ownerId;
  }

  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }

   public CycleObj getSubCycleTest() {
    return pk.getCycle();
  }

  public void setSubCycleTest(CycleObj cycleTest) {
    pk.setCycle(cycleTest);
  }

  public OwnerObj getOwnerTest() {
    return pk.getOwner() ;
  }

  public void setOwnerTest(OwnerObj ownerTest) {
    pk.setOwner(ownerTest);
  }
}
