/*
 * Created on Apr 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DeficiencyDAO {
	
	private List getCycleLevelDeficiency(String cycleIdentifier) throws Exception{
		
		StringTokenizer stringTokenizer = new StringTokenizer(cycleIdentifier,".");
		
		String period = stringTokenizer.nextToken();
		
		String countryId = stringTokenizer.nextToken();
		
		String cycleId = stringTokenizer.nextToken(); 
		
		List deficiencyList = new ArrayList();

		Connection con = null;

		PreparedStatement getDeficiency = null;

		String deficiency = "";

		String id = "";

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getDeficiency = con.prepareStatement("SELECT * FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.COUNTRY_ID=L.VALUE AND DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"%'");

			getDeficiency.setString(1, countryId);

			ResultSet rs = getDeficiency.executeQuery();
			while (rs.next()) {

				deficiency = rs.getString("DESCRIPTION");

				id = rs.getString("OBJ_COMPOSITE_ID");

				addDeficiency(deficiencyList, id, deficiency);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return deficiencyList;
	}
	
	private List getSubCycleLevelDeficiency(String subCycleIdentifier) throws Exception{
		
		StringTokenizer stringTokenizer = new StringTokenizer(subCycleIdentifier,".");
		
		String period = stringTokenizer.nextToken();
		
		String countryId = stringTokenizer.nextToken();
		
		String cycleId = stringTokenizer.nextToken(); 
		
		String subcycleId = stringTokenizer.nextToken(); 
		
		List deficiencyList = new ArrayList();

		Connection con = null;

		PreparedStatement getDeficiency = null;

		String deficiency = "";

		String id = "";

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getDeficiency = con.prepareStatement("SELECT * FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.COUNTRY_ID=L.VALUE AND  DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"."+subcycleId+"%'");

			getDeficiency.setString(1,countryId);

			ResultSet rs = getDeficiency.executeQuery();
			while (rs.next()) {

				deficiency = rs.getString("DESCRIPTION");

				id = rs.getString("OBJ_COMPOSITE_ID");

				addDeficiency(deficiencyList, id, deficiency);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return deficiencyList;
	}
	
	private List getControlObjectiveLevelDeficiency(String controlObjectiveIdentifier) throws Exception{
		
		StringTokenizer stringTokenizer = new StringTokenizer(controlObjectiveIdentifier,".");
		
		String period = stringTokenizer.nextToken();
		
		String countryId = stringTokenizer.nextToken();
		
		String cycleId = stringTokenizer.nextToken(); 
		
		String subcycleId = stringTokenizer.nextToken(); 
		
		String controlObjectiveId = stringTokenizer.nextToken(); 
		
		List deficiencyList = new ArrayList();

		Connection con = null;

		PreparedStatement getDeficiency = null;

		String deficiency = "";

		String id = "";

		try {
			con = SoxicConnectionFactory.getSoxicConnection();

			getDeficiency = con.prepareStatement("SELECT * FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.COUNTRY_ID=L.VALUE AND  DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"."+subcycleId+"."+controlObjectiveId+"%'");

			getDeficiency.setString(1,countryId);

			ResultSet rs = getDeficiency.executeQuery();
			while (rs.next()) {

				deficiency = rs.getString("DESCRIPTION");

				id = rs.getString("OBJ_COMPOSITE_ID");

				addDeficiency(deficiencyList, id, deficiency);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return deficiencyList;
	}
	
	
	public List getDeficiency(String id, String level) throws Exception {
		if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
			return getCycleLevelDeficiency(id);
		}
		if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
			return getSubCycleLevelDeficiency(id);
		}
		if(level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)){
			return getControlObjectiveLevelDeficiency(id);
		}
		return null;

	}
	
	public void addDeficiency(List deficiencyList,
			String controlObjectiveId, String deficiencyString) {

		Iterator deficiencyListIterator = deficiencyList.iterator();

		while (deficiencyListIterator.hasNext()) {

			Deficiency deficiency = (Deficiency) deficiencyListIterator.next();

			if (deficiency.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {
				deficiency.addDeficiency(deficiencyString);
				return;
			}
		}
		Deficiency def = new Deficiency();
		def.setControlObjectiveId(controlObjectiveId);
		def.addDeficiency(deficiencyString);
		deficiencyList.add(def);

	}
}

