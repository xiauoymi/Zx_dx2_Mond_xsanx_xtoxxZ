/*
 * Created on Feb 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;
import java.util.StringTokenizer;

import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResponseGap implements Serializable {
	
	private String responseGapId;
	
	private String comment;
	
	private String type;
	
	private String action;
	
	private boolean modified=false;
	
	private int sequenceId=0;
	
	private int responseId=0;
	
	private boolean delete=false;


	/**
	 * @return Returns the delete.
	 */
	public boolean isDelete() {
		return delete;
	}
	/**
	 * @param delete The delete to set.
	 */
	public void setDelete(boolean delete) {
		this.delete = delete;
	}
	/**
	 * @return Returns the responseId.
	 */
	public int getResponseId() {
		return responseId;
	}
	/**
	 * @param responseId The responseId to set.
	 */
	public void setResponseId(int responseId) {
		this.responseId = responseId;
	}
	/**
	 * @return Returns the sequenceId.
	 */
	public int getSequenceId() {
		return sequenceId;
	}
	/**
	 * @param sequenceId The sequenceId to set.
	 */
	public void setSequenceId(int sequenceId) {
		this.sequenceId = sequenceId;
	}
	/**
	 * @return Returns the modified.
	 */
	public boolean isModified() {
		return modified;
	}
	/**
	 * @param modified The modified to set.
	 */
	public void setModified(boolean modified) {
		this.modified = modified;
	}
	/**
	 * @return Returns the action.
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action The action to set.
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return Returns the responseGapId.
	 */
	public String getResponseGapId() {
		return responseGapId;
	}
	/**
	 * @param responseGapId The responseGapId to set.
	 */
	public void setResponseGapId(String responseGapId) {
		this.responseGapId = responseGapId;
	}
	
	public int getKey(){
		
		StringTokenizer st = new StringTokenizer(responseGapId,SoxicUtil.getSeperator());
		
		String id = st.nextToken();
		
		String typ = st.nextToken();
		
		String rem = st.nextToken();
		
		return Integer.parseInt(rem)+1;
	}
	
	public String getAct_Type(){
		
		StringTokenizer st = new StringTokenizer(responseGapId,SoxicUtil.getSeperator());
		
		String id = st.nextToken();
		
		String typ = st.nextToken();
		
		return id+SoxicUtil.getSeperator()+typ;
		
	}
}
