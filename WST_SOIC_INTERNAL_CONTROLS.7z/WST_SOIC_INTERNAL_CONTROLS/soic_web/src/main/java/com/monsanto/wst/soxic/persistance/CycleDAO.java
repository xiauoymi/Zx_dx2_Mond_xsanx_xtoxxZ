package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 19, 2005
 * Time: 7:27:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class CycleDAO {



}
