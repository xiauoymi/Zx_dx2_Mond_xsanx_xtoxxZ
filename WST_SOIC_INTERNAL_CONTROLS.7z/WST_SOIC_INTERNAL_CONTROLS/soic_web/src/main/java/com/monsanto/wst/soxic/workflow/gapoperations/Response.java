package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: VIJAY
 * Date: Sep 25, 2005
 * Time: 3:10:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class Response {

    String responseId;
    String response;
    String description;

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
