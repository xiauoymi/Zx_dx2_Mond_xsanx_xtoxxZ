/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LoginForm extends ActionForm {
    
    private String ownerId;
    private String worldArea;
    private String country;
    private String period;
    private String cycle;
    
    

    /**
     * @return Returns the country.
     */
    public String getCountry() {
        return country;
    }
    /**
     * @param country The country to set.
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * @return Returns the ownerId.
     */
    public String getOwnerId() {
        return ownerId;
    }
    /**
     * @param ownerId The ownerId to set.
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
    /**
     * @return Returns the period.
     */
    public String getPeriod() {
        return period;
    }
    /**
     * @param period The period to set.
     */
    public void setPeriod(String period) {
        this.period = period;
    }
    /**
     * @return Returns the worldArea.
     */
    public String getWorldArea() {
        return worldArea;
    }
    /**
     * @param worldArea The worldArea to set.
     */
    public void setWorldArea(String worldArea) {
        this.worldArea = worldArea;
    }
    
    /**
     * @return Returns the cycle.
     */
    public String getCycle() {
        return cycle;
    }
    /**
     * @param cycle The cycle to set.
     */
    public void setCycle(String cycle) {
        this.cycle = cycle;
    }
    
    public String toString(){
        
        
        StringBuffer buffer = new StringBuffer('\n'+  "LoginForm: " +'\n');
        buffer.append("Owner :"+ ownerId + '\n');
        buffer.append("WorldArea :"+ worldArea + '\n');
        buffer.append("Country :"+ country + '\n');
        buffer.append("Period :"+ period + '\n');
        buffer.append("Cycle :"+ cycle + '\n');
        
        return buffer.toString();
    }
    
    
   
}
