package com.monsanto.wst.soxic.testreport;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.List;
import java.util.Iterator;
import java.io.InputStream;
import java.io.IOException;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.soxic.reportingFramework.AbstractReport;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;
import com.monsanto.wst.soxic.reportingFramework.SoxAbstractReport;
import com.monsanto.wst.soxic.exception.DatabaseException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 11:27:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportOptionsPageOne extends SoxAbstractReport{
   public ReportOptionsPageOne() {
    }


    public Document buildReportXML(ReportParameters reportParameters) throws DatabaseException {
        AuditOpinionDAO auditOpinionDAO = new AuditOpinionDAO();
//        auditOpinionDAO.getObjectFromDB();
        return getReportDocument(auditOpinionDAO.getObjectFromDB());  //To change body of implemented methods use File | Settings | File Templates.
//        return getSuccessDocument();
    }

    public Document buildFilterXML() throws DatabaseException {
        TypeOneFilterDAO typeOneFilterDAO = new TypeOneFilterDAO();
        List auditList = typeOneFilterDAO.getObjectFromDB();

        return getSuccessDocument(auditList);
    }


    public Document getSuccessDocument(List auditList) {
        DocumentBuilder builder = null;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        Document outputDocument = builder.newDocument();
        Element rootOutputElement = outputDocument.createElement("reportOptions");

        outputDocument.appendChild(rootOutputElement);
        rootOutputElement.appendChild(createSimpleChildNode("name","testReport",outputDocument));
        rootOutputElement.appendChild(createSimpleChildCDATANode("securenavtab",getSecureNav(),outputDocument));
        Element element = createComplexChildNode("audits",outputDocument);
        rootOutputElement.appendChild(element);
        Iterator iterator = auditList.iterator();
        while(iterator.hasNext()){
            IAudit iAudit = (IAudit) iterator.next();
            element.appendChild(createSimpleChildNode("audit",iAudit.getAuditid(),outputDocument));
        }

        return outputDocument;
    }

   public Document getReportDocument(List auditList) {
        DocumentBuilder builder = null;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        Document outputDocument = builder.newDocument();
        Element rootOutputElement = outputDocument.createElement("reportdata");

        outputDocument.appendChild(rootOutputElement);
        rootOutputElement.appendChild(createSimpleChildNode("name","testReport",outputDocument));
        rootOutputElement.appendChild(createSimpleChildCDATANode("securenavtab",getSecureNav(),outputDocument));
        Element element = createComplexChildNode("audits",outputDocument);
        rootOutputElement.appendChild(element);
        Iterator iterator = auditList.iterator();
        while(iterator.hasNext()){
            IAudit iAudit = (IAudit) iterator.next();
            Element auditElement = createComplexChildNode("audit",outputDocument);
            element.appendChild(auditElement);
            auditElement.appendChild(createSimpleChildNode("endDate",iAudit.getEnddate(),outputDocument));
            String auditName = iAudit.getAuditname();
            String opinionType = iAudit.getOpinionType();
            auditElement.appendChild(createSimpleChildCDATANode("name",auditName,outputDocument));
            if(opinionType!=null){
               auditElement.appendChild(createSimpleChildNode("opinion",opinionType,outputDocument));
            }else{
                auditElement.appendChild(createSimpleChildNode("opinion","",outputDocument));
            }

        }

        return outputDocument;
    }

    public Node createSimpleChildCDATANode(String nodeName, String nodeValue, Document document) {
        Node node = document.createElement(nodeName);
        Text textNode = document.createCDATASection(nodeValue);
        node.appendChild(textNode);
        return node;
    }

    public static Node createSimpleChildNode(String nodeName, String nodeValue, Document document) {
        Node node = document.createElement(nodeName);
        Text textNode = document.createTextNode(nodeValue);
        node.appendChild(textNode);
        return node;
    }

    private Element createComplexChildNode(String nodeName, Document outputDocument) {
        return outputDocument.createElement(nodeName);
    }

    public Document getTestDocument(){
        Document document=null;
//        try {
        ClassLoader classLoader = ReportOptionsPageOne.class.getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream("com/monsanto/wst/wst_ia_iaudit/stylesheets/reportOptionsOne.xml");
            try {
                document = DOMUtil.newDocument(inputStream);
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } catch (SAXException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
//            document = DOMUtil.newDocument("com\\monsanto\\wst\\wst_ia_iaudit\\stylesheets\\test.xml");
//        } catch (ParserException e) {
//            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//        }
        return document;
    }

    private String getSecureNav(){
        return "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"site_nav\">\n" +
                "<tr>\n" +
                "<td><a href=\"/iaudit/manageAudit\"><img src=\"/iaudit/images/audits.gif\" width=\"60\" height=\"20\" alt=\"\" border=\"0\"/></a></td>\n" +
                "<td><a href=\"/iaudit/jsp/admin.jsp\"><img src=\"/iaudit/images/maintenance_on.gif\" width=\"110\" height=\"20\" alt=\"\" border=\"0\"/></a></td>\n" +
                "<td><a href=\"/iaudit/jsp/reportList.jsp\" ><img src=\"/iaudit/images/reports.gif\" width=\"75\" height=\"20\" alt=\"\" border=\"0\" /></a></td>\n" +
                "<td class=\"pusher\"></td>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td colspan=\"7\" class=\"nav_base1\"></td>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td colspan=\"7\" class=\"nav_base2\"></td>\n" +
                "</tr>\n" +
                "</table>";
    }

    public void buildFilterXML(Element rootOutputElement) throws DatabaseException {
                Element rootElement = DOMUtil.addChildElement(rootOutputElement,"audits");
        TypeOneFilterDAO typeOneFilterDAO = new TypeOneFilterDAO();
        List auditList = typeOneFilterDAO.getObjectFromDB();
        Iterator iterator = auditList.iterator();
        while(iterator.hasNext()){
            IAudit iAudit = (IAudit) iterator.next();
            DOMUtil.addChildElement(rootElement,"audit",iAudit.getAuditid());
        }
    }

    protected void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException {
        AuditOpinionDAO auditOpinionDAO = new AuditOpinionDAO();
        List auditList= auditOpinionDAO.getObjectFromDB();

         Element element = DOMUtil.addChildElement(reportDataElement,"audits");

         Iterator iterator = auditList.iterator();
         while(iterator.hasNext()){
             IAudit iAudit = (IAudit) iterator.next();

             Element auditElement = DOMUtil.addChildElement(element,"audit");
             element.appendChild(auditElement);

             DOMUtil.addChildElement(auditElement,"endDate",iAudit.getEnddate());
         }

    }

    public String returnExportFileNameKey() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
