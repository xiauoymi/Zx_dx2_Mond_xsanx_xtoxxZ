/*
 * Created on Mar 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.Status;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlObjectiveOperations {

	//List activityList = new ArrayList();
	
	public static void main(String args[]) throws Exception{
		ControlObjectiveOperations contorlObjectiveOperations = new ControlObjectiveOperations();
		contorlObjectiveOperations.updateControlObjecitveStatus();
	}
	
	public void updateControlObjecitveStatus() throws Exception{
		List controlObjectiveList = getControlObjectiveList();
		processControlObjectiveStatus(controlObjectiveList);
	}
	
	public List getControlObjectiveList()throws Exception{
		List controlObjectiveList = new ArrayList();
		Connection con = null;
		PreparedStatement getControlObjectives = null;
	
		try {
			con = getConnection();

			getControlObjectives = con.prepareStatement("SELECT CO.CTRL_OBJ_ID,CO.STATUS FROM CTRL_OBJ CO");
			
			ResultSet rs = getControlObjectives.executeQuery();
			
			while(rs.next()){
				
				populateControlObjectiveList(rs,controlObjectiveList);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return controlObjectiveList;
	}
	
	public void populateControlObjectiveList(ResultSet rs,List controlObjectiveList)throws Exception{
		
		ControlObjective controlObjective = new ControlObjective();
		
		Status status = new Status(rs.getString("STATUS"));
		
		controlObjective.setStatus(status);
		
		controlObjective.setControlObjectiveId(rs.getString("CTRL_OBJ_ID"));
		
		controlObjectiveList.add(controlObjective);
		
	}
	
	public Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@tst01.monsanto.com:1521:comgent","sarbox_et","sarbox_et_123");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@stddba01.monsanto.com:1521:comgend","sarbox_et","sarbox_et");
		return conn;
	}	
	
	
	public void processControlObjectiveStatus(List controlObjectiveList)throws Exception{
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		
		while(controlObjectiveListIterator.hasNext()){
			
			ControlObjective controlObjective = (ControlObjective)controlObjectiveListIterator.next();

			String status = getControlObjectiveStatus(controlObjective.getControlObjectiveId());
			
			if(controlObjective.getStatus().getCurrentStatus()==null){
				updateControlObjectiveStatus(controlObjective.getControlObjectiveId(),status);
			}else{
				if(!status.equalsIgnoreCase(controlObjective.getStatus().getCurrentStatus())){
					
					updateControlObjectiveStatus(controlObjective.getControlObjectiveId(),status);
					
				}
			}

		}
			
	
	}
	
	public String getControlObjectiveStatus(String controlObjectiveId)throws Exception{
		Connection con = null;

		PreparedStatement getControlObjectiveStatus = null;
		
		//List activityList = new ArrayList();
		

		try {
			con = getConnection();

			getControlObjectiveStatus = con.prepareStatement("SELECT OA.STATUS FROM ACTIVITY A,OWNER_ACTIVITY OA,LOOKUP L WHERE A.CTRL_OBJ_ID=? AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND L.TYPE='STATUS' AND L.NAME=OA.STATUS ORDER BY L.VALUE");
			
			getControlObjectiveStatus.setString(1,controlObjectiveId);
					
			ResultSet rs = getControlObjectiveStatus.executeQuery();
			
			while(rs.next()){
				
				return rs.getString("STATUS");
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return null;
	}
	
	public void updateControlObjectiveStatus(String controlObjectiveId,String status)throws Exception{
		Connection con = null;

		PreparedStatement updateControlObjectiveStatus = null;
		
		//List activityList = new ArrayList();
		

		try {
			con = getConnection();

			updateControlObjectiveStatus = con.prepareStatement("UPDATE CTRL_OBJ CO SET CO.STATUS=? WHERE CO.CTRL_OBJ_ID=?");
					
			updateControlObjectiveStatus.setString(1,status);
			
			updateControlObjectiveStatus.setString(2,controlObjectiveId);
					
			updateControlObjectiveStatus.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
	}
}
