/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.form.SecurityVisibleForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author rgeorge
 * This class is the action class for the Administrator menu screen.
 * Using the Owner object, the security rights of the user logged in
 * (Admin/IA/IA_USER) is determnined. Based on this condition, the user will be given
 * only those options that are assigned to them.
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminAction  extends Action {
    
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
			                     HttpServletRequest request, 
			                     HttpServletResponse response) {

        SecurityVisibleForm securityvisibleform = (SecurityVisibleForm)form;

        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);

        boolean IA = owner.isIA();
        boolean Admin = owner.isAdmin();
        boolean cycle_subcycle = owner.isShowMaintainenceForCycleOrSubCycle();

        if ((cycle_subcycle) && (!Admin) && (!IA)){
            securityvisibleform.setOwnermaintain(true);
        }
        else securityvisibleform.setOwnermaintain(false);

        if ((IA) || (Admin)){
            securityvisibleform.setUsermaintain(true);
        }
        else securityvisibleform.setUsermaintain(false);

        if (Admin){
            securityvisibleform.setDeleteowner(true);
            securityvisibleform.setAdmindetails(true);
            securityvisibleform.setAdminnews(true);
            securityvisibleform.setAdminreport(true);
            securityvisibleform.setEmailAdmin(true);
            securityvisibleform.setQuestionAdmin(true);
            securityvisibleform.setFaqAdmin(true);
        }
        else {
            securityvisibleform.setDeleteowner(false);
            securityvisibleform.setAdmindetails(false);
            securityvisibleform.setAdminnews(false);
            securityvisibleform.setAdminreport(false);
            securityvisibleform.setEmailAdmin(false);
            securityvisibleform.setQuestionAdmin(false);
            securityvisibleform.setFaqAdmin(false);
        }

        return mapping.findForward("success");
    }

}
