/*
* Created on Jan 31, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.persistance;

import java.sql.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.QuestionNew;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleCycleDAO extends OracleAbstractDAO{

    private String ownerId;
    private String queryType;

    protected String buildSelectQuery(Map criteria) {

        String query = "";
        queryType = criteria.get("QUERY_TYPE").toString();

        if(queryType.equals("INIT")){

            ownerId = criteria.get(Owner.OWNER_ID).toString();
            query = buildOwnerCycleQuery(ownerId);
            return query;
        }else if(queryType.equals("OWNER")){
            ownerId = criteria.get(Owner.OWNER_ID).toString();
            return buildOwnerCycleQuery(ownerId);
        }

        return query;
    }

    private String buildOwnerCycleQuery(String ownerId){

        StringBuffer query = new StringBuffer();

        query.append("SELECT O.CYCLE_ID, O.STATUS, O.START_DATE, O.DUE_DATE, C.DESCRIPTION, C.PERIOD_ID, C.POTENTIAL_GAP, C.PREV_DEF ");
        query.append("FROM OWNER_CYCLE O, CYCLE C,CYCLE_STATE CS WHERE O.CYCLE_ID = C.CYCLE_ID AND CS.CYCLE_ID=C.CYCLE_ID AND CS.STATE='"+SoxicConstants.CERTIFICATION_STATE+"' AND ");
        query.append("O.OWNER_ID = '"+ ownerId+"'");

        return query.toString();
    }

    protected SoxicBaseModel populateModel(ResultSet rs){

        if(queryType.equals("OWNER")){
            return populateModelForOwner(rs);
        }else if(queryType.equals("INIT")){
            return populateModelForInit(rs);
        }

        return null;

    }
    /**
     * @param criteria
     * @return
     */
    private StringBuffer buildWhereCriteria(Map criteria) {

        Set keys = criteria.keySet();
        Iterator iter = keys.iterator();
        int count = 0;
        StringBuffer whereCriteria= new StringBuffer();

        while (iter.hasNext()) {
            String columnName = (String) iter.next();
            String value = SoxicUtil.replaceQuotes((String) criteria.get(columnName));

            if(columnName.equals(Owner.OWNER_ID)){
                ownerId = value;
            }

            if (!SoxicUtil.isEmpty(value)) {

                if (count > 0){
                    whereCriteria.append(" AND ");
                }

                //				whereCriteria.append(
                //						"UPPER(" + columnName.trim() + ") = UPPER('" + value.trim() + "')");
                whereCriteria.append(
                        columnName.trim() + " = '" + value.trim() + "'");

                count++;
            }
        }
        return whereCriteria;
    }

    protected SoxicBaseModel populateModelForOwner(ResultSet rs){

        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setDescription(rs.getString(Cycle.DESCRIPTION));
            cycle.setStatus(rs.getString(Cycle.STATUS));
            cycle.setDeficiency(rs.getString(Cycle.PREV_DEF));
            cycle.setGap(rs.getString(SubCycle.POTENTIAL_GAP));
            cycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            cycle.setPeriodId(rs.getString(Cycle.PERIOD_ID));
            cycle.setStartDate(rs.getDate(Cycle.START_DATE));

            //gets the subCycles belonged to this cycle by using OracleSubCycleDAO.
            cycle.setSubCycles(getSubCycles(cycle.getCycleId()));
            cycle.setSubmitLock();
            cycle.setQuestions(getCycleQuestions(cycle.getCycleId()));
            setResponseToQuestions(cycle.getQuestions());

        } catch (Exception e) {
            //throw new Exception("error while populating Cycle from resultset:" +  e.toString());
        }

        return cycle;
    }

    protected SoxicBaseModel populateModelForInit(ResultSet rs){

        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setDescription(rs.getString(Cycle.DESCRIPTION));
            cycle.setStatus(rs.getString(Cycle.STATUS));
            cycle.setDeficiency(rs.getString(Cycle.PREV_DEF));
            cycle.setGap(rs.getString(SubCycle.POTENTIAL_GAP));
            cycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            cycle.setPeriodId(rs.getString(Cycle.PERIOD_ID));

            //gets the subCycles belonged to this cycle by using OracleSubCycleDAO.
            //cycle.setSubCycles(getSubCycles(cycle.getCycleId()));
            //cycle.setSubmitLock();
            //cycle.setQuestions(getCycleQuestions(cycle.getCycleId()));
            //setResponseToQuestions(cycle.getQuestions());

        } catch (Exception e) {
            //throw new DatabaseException("error while populating Cycle from resultset:" +  e.toString());

        }

        return cycle;
    }


    // returns a list of SubCycle objects.

    private Collection getSubCycles(String cycleId) throws DatabaseException, Exception{

        DAO subCycleDAO  = AbstractDAOFactory.getFactory().getSubCycleDAO();

        return subCycleDAO.retrieveByCriteria(buildSubCycleQuery(cycleId));
    }

    private Map buildSubCycleQuery(String cycleId){

        Map subCycleQuery = new HashMap();
        subCycleQuery.put("QUERY_TYPE", "CYCLE");
        subCycleQuery.put(Cycle.CYCLE_ID, cycleId);

        return subCycleQuery;
    }

    private Collection getCycleQuestions(String cycleId) throws DatabaseException, Exception {

        DAO questionsDAO  = AbstractDAOFactory.getFactory().getQuestionDAO();

        return questionsDAO.retrieveByCriteria(buildCycleQuestionsQuery(cycleId));
    }

    private Map buildCycleQuestionsQuery(String cycleId){

        Map cycleQuestionsQuery = new HashMap();
        cycleQuestionsQuery.put("QUERY_TYPE", "CYCLE");
        cycleQuestionsQuery.put(Owner.OWNER_ID, ownerId);
        cycleQuestionsQuery.put(Cycle.CYCLE_ID, cycleId);

        return cycleQuestionsQuery;
    }

    private void setResponseToQuestions(Collection questions) throws DatabaseException{

        OracleResponseDAO responseDAO = (OracleResponseDAO) AbstractDAOFactory.getFactory().getResponseDAO();
        Iterator itr = questions.iterator();

        while(itr.hasNext()){
            responseDAO.setResponse((QuestionNew) itr.next());
        }

    }


    /* (non-Javadoc)
    * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#update(java.util.Collection)
    */
    public void update(Collection soxicBaseModels) throws DatabaseException, Exception {

        if(soxicBaseModels != null){

            Iterator itr = soxicBaseModels.iterator();

            DAO questionDAO = AbstractDAOFactory.getFactory().getQuestionDAO();
            while(itr.hasNext()){

                questionDAO.update(((Cycle)itr.next()).getQuestions());

            }

        }
    }

    public int create(SoxicBaseModel soxicBaseModel){
        return -1;
    }

    public void createCycle(String sourceCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT C.CYCLE_ID, C.CYCLE_CODE, C.WORLD_AREA_ID, C.COUNTRY_ID, C.PERIOD_ID, C.DESCRIPTION, C.OVERFLOW_ID FROM CYCLE C WHERE C.CYCLE_ID='"+sourceCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateCurrentModel(rs);
            }
            insertCycle(cycle,targetCycleId,period);
            createQuestionCycle(sourceCycleId,targetCycleId,period);
            createSubCycles(sourceCycleId,targetCycleId,period);
            createOwnerCycle(sourceCycleId,targetCycleId,period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createOwnerCycle(String sourceCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC WHERE OC.CYCLE_ID='"+sourceCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateOwnerModel(rs);
            }
            insertOwnerCycle(cycle,targetCycleId,period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createQuestionCycle(String sourceCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        Cycle cycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT QC.CYCLE_ID,QC.QUESTION_ID FROM QUESTION_CYCLE QC WHERE QC.CYCLE_ID='"+sourceCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                cycle = populateQuestionModel(rs);
                insertQuestionCycle(cycle,targetCycleId,period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public Cycle populateCurrentModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setCycleCode(rs.getString(Cycle.CYCLE_CODE));
            cycle.setWorldAreaId(rs.getString(Cycle.WORLD_AREA_ID));
            cycle.setCountryId(rs.getString(Cycle.COUNTRY_ID));
            cycle.setDescription(rs.getString(Cycle.DESCRIPTION));
            cycle.setPeriodId(rs.getString(Cycle.PERIOD_ID));
        } catch (Exception e) {
            //throw new DatabaseException("error while populating Cycle from resultset:" +  e.toString());

        }
        return cycle;
    }

    public Cycle populateOwnerModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try{
            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setOwnerId(rs.getString(Cycle.OWNERID));
        } catch (Exception e) {
            //throw new DatabaseException("error while populating Cycle from resultset:" +  e.toString());

        }
        return cycle;
    }

    public Cycle populateQuestionModel(ResultSet rs){
        Cycle cycle = new Cycle();

        try {

            cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
            cycle.setQuestionId(rs.getString(Cycle.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cycle;
    }

    public void insertCycle(Cycle cycle,String newCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO CYCLE (CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,newCycleId);
            preparedStatement.setString(2,cycle.getCycleCode());
            preparedStatement.setString(3,cycle.getWorldAreaId());
            preparedStatement.setString(4,cycle.getCountryId());
            preparedStatement.setString(5,period);
            preparedStatement.setString(6,cycle.getDescription());
            preparedStatement.setString(7,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(8,new Date(System.currentTimeMillis()));
            preparedStatement.setString(9,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

   public int insertCycle(Cycle cycle){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
       int result =0;


        String query = "INSERT INTO CYCLE (CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getCycleId());
            preparedStatement.setString(2,cycle.getCycleCode());
            preparedStatement.setString(3,cycle.getWorldAreaId());
            preparedStatement.setString(4,cycle.getCountryId());
            preparedStatement.setString(5,cycle.getPeriodId());
            preparedStatement.setString(6,cycle.getDescription());
            preparedStatement.setString(7,cycle.getStatus());
            preparedStatement.setDate(8,new Date(System.currentTimeMillis()));
            preparedStatement.setString(9,"ADMIN");


            result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
       return result;
    }


    public void insertOwnerCycle(Cycle cycle,String newCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_CYCLE (OWNER_ID, CYCLE_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getOwnerId());
            preparedStatement.setString(2,newCycleId);
            preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
            preparedStatement.setString(5,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

   public void insertOwnerCycle(Cycle cycle){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_CYCLE (OWNER_ID, CYCLE_ID, DUE_DATE, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getOwnerId());
            preparedStatement.setString(2,cycle.getCycleId());
            preparedStatement.setDate(3,cycle.getEndDate());
            preparedStatement.setString(4,cycle.getStatus());
            preparedStatement.setDate(5,new Date(System.currentTimeMillis()));
            preparedStatement.setString(6,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void createSubCycles(String sourceCycleId,String targetCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
       // SubCycleDAO subCycleDAO = new SubCycleDAO();
       DAO subCycleDAO =  AbstractDAOFactory.getFactory().getSubCycleDAO();

        String query = "SELECT SUB_CYCLE_ID FROM SUB_CYCLE WHERE CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,sourceCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                ((OracleSubCycleDAO)subCycleDAO).createSubCycle(rs.getString("SUB_CYCLE_ID"),targetCycleId,period);
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void insertQuestionCycle(Cycle cycle,String newCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO QUESTION_CYCLE (QUESTION_ID, CYCLE_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getQuestionId());
            preparedStatement.setString(2,newCycleId);
            //preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(3,new Date(System.currentTimeMillis()));
            preparedStatement.setString(4,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void deleteCycle(Cycle cycle){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "DELETE CYCLE WHERE CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getCycleId());
            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void deleteOwnerCycle(Cycle cycle){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "DELETE OWNER_CYCLE WHERE CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,cycle.getCycleId());
            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

}
