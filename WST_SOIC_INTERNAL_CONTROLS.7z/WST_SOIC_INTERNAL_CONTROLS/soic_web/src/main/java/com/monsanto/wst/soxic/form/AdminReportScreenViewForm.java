//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.action.AdminReportObject;
import com.monsanto.wst.soxic.action.ExportAction;

/** 
 * MyEclipse Struts
 * Creation date: 03-30-2005
 * 
 * XDoclet definition:
 * @struts:form name="adminReportScreenViewForm"
 */
public class AdminReportScreenViewForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	private Vector adminReportVector = new Vector();
	
	private Vector allRoles = new Vector();
	
	private String[] rolesSelected;
	
	
	private boolean displayTable2;
	
	private AdminReportObject editRepObj = new AdminReportObject();
	
	// --------------------------------------------------------- Methods


	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//			
//		logger.info("Reset clicked ...");
//			
//	}

	/**
	 * @return Returns the adminReportVector.
	 */
	public Vector getAdminReportVector() {
		return adminReportVector;
	}
	/**
	 * @param adminReportVector The adminReportVector to set.
	 */
	public void setAdminReportVector(Vector adminReportVector) {
		this.adminReportVector = adminReportVector;
	}
	
	
	
	
	/**
	 * @return Returns the displayTable2.
	 */
	public boolean isDisplayTable2() {
		return displayTable2;
	}
	/**
	 * @param displayTable2 The displayTable2 to set.
	 */
	public void setDisplayTable2(boolean displayTable2) {
		this.displayTable2 = displayTable2;
	}
	/**
	 * @return Returns the editRepObj.
	 */
	public AdminReportObject getEditRepObj() {
		return editRepObj;
	}
	/**
	 * @param editRepObj The editRepObj to set.
	 */
	public void setEditRepObj(AdminReportObject editRepObj) {
		this.editRepObj = editRepObj;
	}
	
	
	
	/**
	 * @return Returns the rolesSelected.
	 */
	public String[] getRolesSelected() {
		return rolesSelected;
	}
	/**
	 * @param rolesSelected The rolesSelected to set.
	 */
	public void setRolesSelected(String[] rolesSelected) {
		this.rolesSelected = rolesSelected;
	}
	/**
	 * @return Returns the allRoles.
	 */
	public Vector getAllRoles() {
		return allRoles;
	}
	/**
	 * @param allRoles The allRoles to set.
	 */
	public void setAllRoles(Vector allRoles) {
		this.allRoles = allRoles;
	}
	
}