package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 4, 2005
 * Time: 5:01:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeDetails extends SoxicBaseModel{

    public static final String SELECT_DOCUMENT_REQUESTS="SELECT_DOCUMENT_REQUESTS";
    public static final String SELECT_ACTIVITY_FOR_REQUESTED_ACTIVITY_OWNERS="SELECT_ACTIVITY_FOR_REQUESTED_ACTIVITY_OWNERS";
    public static final String SELECT_ACTIVITY_FOR_NON_REQUESTED_ACTIVITY_OWNERS="";
    public static final String SELECT_ACTIVITY_FOR_SUBCYCLE_OWNERS="";
    //public static final String SELECT_ACTIVITY_FOR_REQUESTED_OWNERS="";

    public static final String DOC_CHANGE_DISPLAY_STATUS_PENDING = "PENDING";
    public static final String DOC_CHANGE_DISPLAY_STATUS_APPROVED = "APPROVED";
    public static final String DOC_CHANGE_DISPLAY_STATUS_REJECTED = "REJECTED";

    private String activityId;
    /**
     * Name of the person who requested a Document Change
     */
    private String requestor;
    /**
     *
     */
    private String type;
    /**
     * Sub Cycle status can be either Y , N or P
     */
    private String subCycleStatus;
    /**
     * Sub Cycle Display Status - PENDING , APPROVED, REJECTED
     */
    private String subCycleDisplayStatus;
    /**
     * IA display status can be either Y , N or P
     */
    private String iAStatus;
    /**
     * IA Display Status - PENDING , APPROVED, REJECTED
     */
    private String iADisplayStatus;
    /**
     *
     */
    private String requestString;
    /**
     *
     */
    private String country;
    /**
     *
     */
    private String cycle;
    /**
     *
     */
    private String subCycle;
    /**
     *
     */
    private String ownerId;
    /**
     *
     */
    private String requestType;
    /**
     *
     */
    private String docChangeIdentifier;
    /**
     *
     */
    private String sourceType;
    /**
     *
     */
    private String ocreqResponseId;
    /**
     *
     */
    private String updateModifier;

    public DocumentChangeDetails(){

    }

    public DocumentChangeDetails(String activityIdIn,String typeIn,String subCycleStatusIn,String iAStatusIn,String sourceTypeIn,String requestTypeIn){
        activityId = activityIdIn;
        type = typeIn;
        subCycleStatus = subCycleStatusIn;
        iAStatus = iAStatusIn;
        sourceType = sourceTypeIn;
        requestType = requestTypeIn;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubCycleStatus() {
        return subCycleStatus;
    }

    public void setSubCycleStatus(String subCycleStatus) {
        this.subCycleStatus = subCycleStatus;
    }

    public String getiAStatus() {
        return iAStatus;
    }

    public void setiAStatus(String iAStatus) {
        this.iAStatus = iAStatus;
    }

    public String getId(){
        return "";
    }

    public String getRequestString() {
        return requestString;
    }

    public void setRequestString(String requestString) {
        this.requestString = requestString;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCycle() {
        return cycle;
    }

    public void setCycle(String cycle) {
        this.cycle = cycle;
    }

    public String getSubCycle() {
        return subCycle;
    }

    public void setSubCycle(String subCycle) {
        this.subCycle = subCycle;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    //TODO remove this method from here and put it in DAO
    public void setParameters(PreparedStatement pstmt,String queryType){
        try{
            if(queryType.equalsIgnoreCase(SELECT_DOCUMENT_REQUESTS)){

                pstmt.setString(1,getOwnerId());
                pstmt.setString(2,getOwnerId());

            }
        }catch(SQLException sqle){

        }

    }


    public void initializeDetails(){
        StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
        String period = stringTokenizer.nextToken();
        String country = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleid = stringTokenizer.nextToken();
        setCountry(country);
        setCycle(period+"."+country+"."+cycleId);
        setSubCycle(period+"."+country+"."+cycleId+"."+subCycleid);
    }

    public String getDocChangeIdentifier() {
        return docChangeIdentifier;
    }

    public void setDocChangeIdentifier(String docChangeIdentifier) {
        this.docChangeIdentifier = docChangeIdentifier;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSubCycleDisplayStatus() {
        if(getSubCycleStatus().equalsIgnoreCase("P")){
            subCycleDisplayStatus=DOC_CHANGE_DISPLAY_STATUS_PENDING;
        }
        if(getSubCycleStatus().equalsIgnoreCase("Y")){
            subCycleDisplayStatus=DOC_CHANGE_DISPLAY_STATUS_APPROVED;
        }
        if(getSubCycleStatus().equalsIgnoreCase("N")){
            subCycleDisplayStatus=DOC_CHANGE_DISPLAY_STATUS_REJECTED;
        }
        return subCycleDisplayStatus;
    }

    public void setSubCycleDisplayStatus(String subCycleDisplayStatus) {
        this.subCycleDisplayStatus = subCycleDisplayStatus;
    }

    public String getiADisplayStatus() {
        if(getiAStatus().equalsIgnoreCase("P")){
            iADisplayStatus=DOC_CHANGE_DISPLAY_STATUS_PENDING;
        }
        if(getiAStatus().equalsIgnoreCase("Y")){
            iADisplayStatus=DOC_CHANGE_DISPLAY_STATUS_APPROVED;
        }
        if(getiAStatus().equalsIgnoreCase("N")){
            iADisplayStatus=DOC_CHANGE_DISPLAY_STATUS_REJECTED;
        }
        return iADisplayStatus;
    }

    public void setiADisplayStatus(String iADisplayStatus) {
        this.iADisplayStatus = iADisplayStatus;
    }

    public String getOcreqResponseId() {
        return ocreqResponseId;
    }

    public void setOcreqResponseId(String ocreqResponseId) {
        this.ocreqResponseId = ocreqResponseId;
    }

    public String getUpdateModifier() {
        if(getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY)){
            if(getSubCycleStatus().equalsIgnoreCase("Y")|| getiAStatus().equalsIgnoreCase("Y") || getSubCycleStatus().equalsIgnoreCase("N")|| getiAStatus().equalsIgnoreCase("N")){
                return SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
            }
        }
        if(getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_OTHER_ACTIVITY)){
            return SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
        }
        if(getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
            if(getiAStatus().equalsIgnoreCase("Y")|| getiAStatus().equalsIgnoreCase("N")){
                return SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
            }
        }
        return SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE;
    }

    public void setUpdateModifier(String updateModifier) {
        this.updateModifier = updateModifier;
    }

    public String toString(){

        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "Activity id           :"    +getActivityId() +'\n');
        buffer.append('\n'+ "Requestor             :"    +getRequestor() +'\n');
        buffer.append('\n'+ "Type                  :"    +getType() +'\n');
        buffer.append('\n'+ "Country               :"    +getCountry() +'\n');
        buffer.append('\n'+ "Cycle                 :"    +getCycle() +'\n');
        buffer.append('\n'+ "DocChangeIdentifier   :"    +getDocChangeIdentifier() +'\n');
        buffer.append('\n'+ "OcreqResponseId       :"    +getOcreqResponseId() +'\n');
        buffer.append('\n'+ "OwnerId               :"    +getOwnerId() +'\n');
        buffer.append('\n'+ "iAStatus              :"    +getiAStatus() +'\n');
        buffer.append('\n'+ "SubCycleStatus        :"    +getSubCycleStatus() +'\n');
        buffer.append('\n'+ "RequestType           :"    +getRequestType() +'\n');
        buffer.append('\n'+ "SourceType            :"    +getSourceType() +'\n');
        buffer.append('\n'+ "UpdateModifier        :"    +getUpdateModifier() +'\n');
        buffer.append('\n'+ "State                 :"    +getState() +'\n');
        return buffer.toString();
    }


}
