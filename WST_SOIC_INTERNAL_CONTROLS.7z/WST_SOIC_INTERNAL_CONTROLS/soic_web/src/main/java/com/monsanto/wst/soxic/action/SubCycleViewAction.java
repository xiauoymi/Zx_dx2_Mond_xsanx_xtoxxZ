//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.SubCycleViewForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * MyEclipse Struts
 * Creation date: 01-18-2005
 * 
 * XDoclet definition:
 * @struts:action path="/subCycle" name="subCycleForm" input="/jsp/subCycle.jsp" scope="request" validate="true"
 */
public class SubCycleViewAction extends Action {

    // --------------------------------------------------------- Instance Variables

    // --------------------------------------------------------- Methods

    /**
     * Method execute
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)throws Exception {

        SubCycleViewForm subCycleViewForm = (SubCycleViewForm)form;
        Owner owner = (Owner) request.getSession().getAttribute("owner");

        if(subCycleViewForm.getShowSubCycle() != null && subCycleViewForm.getShowSubCycle().length() > 1 ){

            subCycleViewForm.setSubCycleToShow(subCycleViewForm.getShowSubCycle());
            subCycleViewForm.setShowSubCycle("");
        }

        if(subCycleViewForm.getShowControlObjective() != null && subCycleViewForm.getShowControlObjective().length() > 1){
            subCycleViewForm.setControlObjectiveToShow(subCycleViewForm.getShowControlObjective());
            subCycleViewForm.setShowControlObjective("");
        }


        subCycleViewForm.setSubCycleCycleAssociation(owner.getSubCycleCycleIds());

        if(subCycleViewForm.getCycleId() != null){
            subCycleViewForm.setSubCycles(owner.getSubCycles(subCycleViewForm.getCycleId()));
            subCycleViewForm.setLink();

        }
        else{
            subCycleViewForm.setSubCycles(owner.getSubCycles(subCycleViewForm.getDefaultCycleId()));
            subCycleViewForm.setLink();

        }

       subCycleViewForm.setHeaderFooter(SoxicConstants.SUBCYCLE);

       request.getSession().setAttribute("subCycleViewForm",subCycleViewForm);

       return mapping.findForward("success");

    }

}