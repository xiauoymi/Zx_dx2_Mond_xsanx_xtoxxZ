package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 26, 2005
 * Time: 9:22:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class DualOwnerDoesNotExistException extends Exception {


    public DualOwnerDoesNotExistException() {
        super();
    }

    public DualOwnerDoesNotExistException(String strMessage) {
        super(strMessage);
    }

    public DualOwnerDoesNotExistException(Exception e) {
        super(e.getMessage());
        e.printStackTrace();
    }
}