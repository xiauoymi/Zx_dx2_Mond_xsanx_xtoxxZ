/*
 * Created on Feb 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.Iterator;
import java.util.Map;

import org.apache.struts.action.ActionForm;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GapDeficiencyBaseForm extends ActionForm{
	
	private String id;
	
	private String level;
	
	/**
	 * @return Returns the id.
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return Returns the level.
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level The level to set.
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	
	public String getLevel(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
			
			if(key.equalsIgnoreCase("controlObjectiveId")){
				
				return SoxicConstants.CONTROLOBJECTIVE;
				
			}
			
			if(key.equalsIgnoreCase("subCycleId")){
				
				return SoxicConstants.SUBCYCLE;
				
			}	
			
			if(key.equalsIgnoreCase("cycleId")){
				
				return SoxicConstants.CYCLE;
				
			}	
			
			if(key.equalsIgnoreCase("activityId")){
				
				return SoxicConstants.ACTIVITY;
				
			}				
		
		}
		
		return key;
		
	}
	
	public String getKey(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
		
		}
		
		return key;		
	}

}
