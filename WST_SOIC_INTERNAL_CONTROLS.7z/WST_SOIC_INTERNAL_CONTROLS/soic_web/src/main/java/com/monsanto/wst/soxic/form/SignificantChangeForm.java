package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 8, 2006
 * Time: 3:11:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class SignificantChangeForm extends ActionForm {

    String cycleId;
    String currentPeriod;
    String ownerId;
    List significantChanges;
    boolean noReporting;

    public List getSignificantChanges() {
        return significantChanges;
    }

    public void setSignificantChanges(List significantChanges) {
        this.significantChanges = significantChanges;
    }

    public String getCycleId() {
        return cycleId;
    }

    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }

    public String getCurrentPeriod() {
        return currentPeriod;
    }

    public void setCurrentPeriod(String currentPeriod) {
        this.currentPeriod = currentPeriod;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public boolean isNoReporting() {
        return noReporting;
    }

    public void setNoReporting(boolean noReporting) {
        this.noReporting = noReporting;
    }    


}
