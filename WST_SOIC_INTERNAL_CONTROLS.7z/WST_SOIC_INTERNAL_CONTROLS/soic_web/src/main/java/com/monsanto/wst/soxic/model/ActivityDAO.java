package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.Util.StringUtils;

public class ActivityDAO {

  public static Map getOverFlowActivityDescList(String ownerId) throws Exception {
    Map activityDescriptionOverFlow = new HashMap();
    Connection con = null;
    try {
      con = SoxicConnectionFactory.getSoxicConnection();

      PreparedStatement getOverflowActDesc = con
          .prepareStatement("SELECT TOV.SEQUENCE,TOV.TEXT_CHUNK,A.ACTIVITY_ID FROM OWNER_ACTIVITY OA,ACTIVITY A,TEXT_OVERFLOW TOV WHERE OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND TOV.OVERFLOW_ID=A.OVERFLOW_ID ORDER BY ACTIVITY_ID,TEXT_CHUNK");

      getOverflowActDesc.setString(1, ownerId);

      ResultSet rs = getOverflowActDesc.executeQuery();
      while (rs.next()) {
        String activityId = rs.getString("ACTIVITY_ID");
        if (activityDescriptionOverFlow.get(activityId) == null) {
          activityDescriptionOverFlow.put(activityId, rs.getString("TEXT_CHUNK"));
        } else {
          String firstPart = (String) activityDescriptionOverFlow.get(activityId);
          activityDescriptionOverFlow.put(activityId, firstPart + rs.getString("TEXT_CHUNK"));
        }

      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      //enclose this in a finally block to make
      //sure the connection is closed
      try {
        con.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
    return activityDescriptionOverFlow;

  }

  public boolean ownerActivitiesComplete(String ownerid) throws Exception {
    boolean complete = false;

    Connection con = null;
    PreparedStatement getOverAllOwnerStatus = null;
    try {
      con = SoxicConnectionFactory.getSoxicConnection();

      getOverAllOwnerStatus = con
          .prepareStatement("SELECT OA.STATUS FROM OWNER_ACTIVITY OA,LOOKUP L WHERE OA.OWNER_ID=? AND L.TYPE='STATUS' AND L.NAME=OA.STATUS ORDER BY L.VALUE DESC");

      getOverAllOwnerStatus.setString(1, ownerid);

      ResultSet rs = getOverAllOwnerStatus.executeQuery();
      while (rs.next()) {
        if (rs.getString("STATUS").equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)) {
          return true;
        } else {
          return false;
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      //enclose this in a finally block to make
      //sure the connection is closed
      try {
        getOverAllOwnerStatus.close();
        con.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
    return complete;
  }

  public static void updateActivitiies(Set<String> activitySet, int priorityCode) throws Exception {
    Connection conn = null;
    PreparedStatement ps = null;
    try {
      conn = SoxicConnectionFactory.getSoxicConnection();
      conn.setAutoCommit(false);
      ps = conn.prepareStatement("UPDATE ACTIVITY SET PRIORITY = ? WHERE ACTIVITY_ID IN (?,?)");

      for (String activityId : activitySet) {
        System.out.println("activityId ************* " + activityId);
        if (priorityCode == 2) {
          ps.setInt(1, 0);
        } else {
          ps.setInt(1, priorityCode);
        }
        ps.setString(2, ("FY09-Q2." + activityId).trim());
        ps.setString(3, ("FY09-Q3." + activityId).trim());
        ps.addBatch();
      }
      int[] updatedCount = ps.executeBatch();
      conn.commit();
      System.out.println("Number of records updated = " + updatedCount[0]);
    } catch (Exception e) {
      throw new Exception("Exception updating activities with priority codes...." + e.getMessage());
    } finally {
      try {
        if (ps != null) ps.close();
        if (conn != null) conn.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

  }
}