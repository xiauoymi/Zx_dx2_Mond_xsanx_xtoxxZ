/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.mock;

import com.monsanto.wst.soxic.model.Question;


/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MockQuestion extends Question {
    
    public MockQuestion(String id){
        setMockData(id);
    }
    
    public void setMockData(String id){
        
        setQuestionId("question "+ id);
        setDescription(id + " are we gettign data from Database yet?");
    }

    public static void main(String[] args) {
    }
}
