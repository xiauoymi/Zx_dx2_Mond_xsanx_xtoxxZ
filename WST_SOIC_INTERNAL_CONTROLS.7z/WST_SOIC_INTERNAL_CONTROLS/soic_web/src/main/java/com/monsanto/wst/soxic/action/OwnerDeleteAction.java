/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.LookupDispatchAction;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.OwnerDeleteForm;
import com.monsanto.wst.soxic.model.AdminOwner;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerDeleteAction extends LookupDispatchAction{
    
    /* (non-Javadoc)
     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
     */
    protected Map getKeyMethodMap() {
        Map map = new HashMap();
        map.put("button.preview",   "preview");
        map.put("button.delete",    "delete");
        return map;
    }
    
    public ActionForward preview(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        
        OwnerDeleteForm ownerDeleteForm = (OwnerDeleteForm) form;
        AdminOwner adminOwner = new AdminOwner();
        
        try {
            ownerDeleteForm.setChanges(adminOwner.getPreviewChanges(convertArrayToList(ownerDeleteForm.getSelectedCycles()),
                                                                   convertArrayToList(ownerDeleteForm.getSelectedSubCycles()), 
                                                                   convertArrayToList(ownerDeleteForm.getSelectedActivities()),
                                                                   ownerDeleteForm.getUser()));
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
  
        return mapping.findForward("success");
    }
    
    public ActionForward delete(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        
        OwnerDeleteForm ownerDeleteForm = (OwnerDeleteForm) form;
        AdminOwner adminOwner = new AdminOwner();
       
        try {
                      
               adminOwner.deleteOwner(ownerDeleteForm.getChanges());
            
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        ownerDeleteForm.setChanges(new ArrayList());
        return mapping.findForward("delete");
        
    }
    
        
    private List convertArrayToList(String[] array){
        
        List list = new ArrayList();
        
        for(int i=0; i < array.length; i++){
            list.add(array[i]);
        }
        
        return list;
    }
     
}