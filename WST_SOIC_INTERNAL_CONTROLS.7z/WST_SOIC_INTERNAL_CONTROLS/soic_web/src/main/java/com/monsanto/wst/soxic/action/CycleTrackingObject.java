/*
 * Created on Mar 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.sql.Date;



/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CycleTrackingObject {
		
		private boolean activityComplete;
		private String activityDate;
		private String activityColor;
		
		private boolean subCycleComplete;
		private String subCycleDate;
		private String subCycleColor;
		
		private boolean cycleComplete;
		private String cycleDate;
		private String cycleColor;
		
		
		

		
		/**
		 * @return Returns the activityColor.
		 */
		public String getActivityColor() {
			return activityColor;
		}
		/**
		 * @param activityColor The activityColor to set.
		 */
		public void setActivityColor(String activityColor) {
			this.activityColor = activityColor;
		}
		/**
		 * @return Returns the activityComplete.
		 */
		public boolean isActivityComplete() {
			return activityComplete;
		}
		/**
		 * @param activityComplete The activityComplete to set.
		 */
		public void setActivityComplete(boolean activityComplete) {
			this.activityComplete = activityComplete;
		}
		/**
		 * @return Returns the activityDate.
		 */
		public String getActivityDate() {
			return activityDate;
		}
		/**
		 * @param activityDate The activityDate to set.
		 */
		public void setActivityDate(String activityDate) {
			this.activityDate = activityDate;
		}
		/**
		 * @return Returns the cycleColor.
		 */
		public String getCycleColor() {
			return cycleColor;
		}
		/**
		 * @param cycleColor The cycleColor to set.
		 */
		public void setCycleColor(String cycleColor) {
			this.cycleColor = cycleColor;
		}
		/**
		 * @return Returns the cycleComplete.
		 */
		public boolean isCycleComplete() {
			return cycleComplete;
		}
		/**
		 * @param cycleComplete The cycleComplete to set.
		 */
		public void setCycleComplete(boolean cycleComplete) {
			this.cycleComplete = cycleComplete;
		}
		/**
		 * @return Returns the cycleDate.
		 */
		public String getCycleDate() {
			return cycleDate;
		}
		/**
		 * @param cycleDate The cycleDate to set.
		 */
		public void setCycleDate(String cycleDate) {
			this.cycleDate = cycleDate;
		}
		/**
		 * @return Returns the subCycleColor.
		 */
		public String getSubCycleColor() {
			return subCycleColor;
		}
		/**
		 * @param subCycleColor The subCycleColor to set.
		 */
		public void setSubCycleColor(String subCycleColor) {
			this.subCycleColor = subCycleColor;
		}
		/**
		 * @return Returns the subCycleComplete.
		 */
		public boolean isSubCycleComplete() {
			return subCycleComplete;
		}
		/**
		 * @param subCycleComplete The subCycleComplete to set.
		 */
		public void setSubCycleComplete(boolean subCycleComplete) {
			this.subCycleComplete = subCycleComplete;
		}
		/**
		 * @return Returns the subCycleDate.
		 */
		public String getSubCycleDate() {
			return subCycleDate;
		}
		/**
		 * @param subCycleDate The subCycleDate to set.
		 */
		public void setSubCycleDate(String subCycleDate) {
			this.subCycleDate = subCycleDate;
		}
}
