/*
 * Created on Mar 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.AdminNewsForm;
import com.monsanto.wst.soxic.model.AdminNews;
import com.monsanto.wst.soxic.model.NewsItem;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminNewsEditAction extends Action {
    
    public ActionForward execute(ActionMapping mapping, 
			 ActionForm form,
			 HttpServletRequest request, 
			 HttpServletResponse response) {

        AdminNewsForm newsForm = (AdminNewsForm)form;
        try {
            setData(newsForm);
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return mapping.findForward("success");
    }
    
    private void setData(AdminNewsForm form) throws DatabaseException{
        
        NewsItem news = AdminNews.getNews(form.getSelectedNewsId());
        form.setId(news.getId());
        form.setTitle(news.getTitle());
        form.setBody(news.getBody());
       // form.setNewsSelected(true);
        
        if(news.getAssignedRoles() != null && !news.getAssignedRoles().isEmpty()){
            form.setAssignedRoles( (String[]) news.getAssignedRoles().toArray(new String[news.getAssignedRoles().size()]));
        }
        else{
            form.setAssignedRoles(new String[0]);
        }
            
        
    }
}
