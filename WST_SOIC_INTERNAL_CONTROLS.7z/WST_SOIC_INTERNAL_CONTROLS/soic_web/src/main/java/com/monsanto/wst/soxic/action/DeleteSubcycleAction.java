package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 21, 2005
 * Time: 4:54:14 PM
 *
 * This class contains 3 method. the 1st method deletes the subcycle selected
 * by the user. The 2nd method selects the cycles based on the country id
 * available in the session. The 3rd method selects the subcycles based on the
 * 1st cycle selected. If the list of countries, cycles or subcycles is empty,
 * a NullAndArrayIndexException is thrown.
 */

public class DeleteSubcycleAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        SubCycleDeleteForm subcycledeleteform = (SubCycleDeleteForm)form;
        UtilDAO utildao = new UtilDAO();
        String subcycleid = (String)request.getParameter("remove");
        String cycleid = subcycledeleteform.getSelectedCycles();
        String countrysel = subcycledeleteform.getSelectedCountry();
//        String countrysel = (String)request.getSession().getAttribute("COUNTRYSEL");
//        String cycleid = (String)request.getSession().getAttribute("CYCLE");
        SubCycleMaintainFacade subCycleMaintainFacade = new SubCycleMaintainFacade();


                subCycleMaintainFacade.performDelete(subcycleid);

                if ((utildao.getSubCyclesfromCycles(cycleid)).size()!=0){

                    subcycledeleteform.setSelectedCountry(countrysel);
                    subcycledeleteform.setSelectedCycles(cycleid);
                    subCycleMaintainFacade.subCycleFromCycle(subcycledeleteform, cycleid);
                }else

                if (utildao.getCyclesfromCountry(countrysel).size()!=0){
                    subcycledeleteform.setSelectedCountry(countrysel);
                    subCycleMaintainFacade.cyclesFromCountry(subcycledeleteform,countrysel);
                    subCycleMaintainFacade.initialSubcylesSelection(subcycledeleteform);

                }
            else{
                    subCycleMaintainFacade.countrySelection(subcycledeleteform);
                    subCycleMaintainFacade.initialCycleSelection(subcycledeleteform);
                    subCycleMaintainFacade.initialSubcylesSelection(subcycledeleteform);

                }
        
        return mapping.findForward("deletedsubcycle");
    }
}
