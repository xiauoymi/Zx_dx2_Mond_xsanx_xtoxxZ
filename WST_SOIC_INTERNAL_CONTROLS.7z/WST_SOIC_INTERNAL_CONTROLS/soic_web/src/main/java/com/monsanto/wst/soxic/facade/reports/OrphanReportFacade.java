package com.monsanto.wst.soxic.facade.reports;

import com.monsanto.wst.soxic.model.OwnerStatusReportDAO;
import com.monsanto.wst.soxic.model.OrphanReportDAO;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 9, 2006
 * Time: 10:00:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class OrphanReportFacade {

    OwnerStatusReportDAO ownerStatusReportDAO = new OwnerStatusReportDAO();
    OrphanReportDAO orphanReportDAO = new OrphanReportDAO();

    public List getPeriodsInSystem() throws DatabaseException {
        return ownerStatusReportDAO.getPeriods();
    }

    public List getCyclesNotAssigned(String selperiod) throws Exception {
        return orphanReportDAO.getNoOwnerCycles(selperiod);
    }

    public List getSubCyclesNotAssigned(String selperiod) throws Exception {
        return orphanReportDAO.getNoOwnerSubCycles(selperiod);
    }

    public List getActivitiesNotAssigned(String selperiod) throws Exception {
        return orphanReportDAO.getNoOwnerActivities(selperiod);
    }
}
