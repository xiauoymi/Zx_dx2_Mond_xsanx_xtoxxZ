/*
 * Created on Mar 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.sql.Date;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivityReportRowObject {
	
	private String cycleCode;
	private String country;
	private Date startDate;
	private String activityID;
	private String ctrlObjDesc;
	private String activityDesc;
	private String location;
	private String name;
	private String gapDesc;
	private String gapType;
	
	
	

	/**
	 * @return Returns the activityDesc.
	 */
	public String getActivityDesc() {
		return activityDesc;
	}
	/**
	 * @param activityDesc The activityDesc to set.
	 */
	public void setActivityDesc(String activityDesc) {
		this.activityDesc = activityDesc;
	}
	/**
	 * @return Returns the activityID.
	 */
	public String getActivityID() {
		return activityID;
	}
	/**
	 * @param activityID The activityID to set.
	 */
	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}
	/**
	 * @return Returns the country.
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country The country to set.
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return Returns the ctrlObjDesc.
	 */
	public String getCtrlObjDesc() {
		return ctrlObjDesc;
	}
	/**
	 * @param ctrlObjDesc The ctrlObjDesc to set.
	 */
	public void setCtrlObjDesc(String ctrlObjDesc) {
		this.ctrlObjDesc = ctrlObjDesc;
	}
	/**
	 * @return Returns the cycleCode.
	 */
	public String getCycleCode() {
		return cycleCode;
	}
	/**
	 * @param cycleCode The cycleCode to set.
	 */
	public void setCycleCode(String cycleCode) {
		this.cycleCode = cycleCode;
	}
	/**
	 * @return Returns the gapDesc.
	 */
	public String getGapDesc() {
		return gapDesc;
	}
	/**
	 * @param gapDesc The gapDesc to set.
	 */
	public void setGapDesc(String gapDesc) {
		this.gapDesc = gapDesc;
	}
	/**
	 * @return Returns the gapType.
	 */
	public String getGapType() {
		return gapType;
	}
	/**
	 * @param gapType The gapType to set.
	 */
	public void setGapType(String gapType) {
		this.gapType = gapType;
	}
	/**
	 * @return Returns the location.
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location The location to set.
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the startDate.
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
}
