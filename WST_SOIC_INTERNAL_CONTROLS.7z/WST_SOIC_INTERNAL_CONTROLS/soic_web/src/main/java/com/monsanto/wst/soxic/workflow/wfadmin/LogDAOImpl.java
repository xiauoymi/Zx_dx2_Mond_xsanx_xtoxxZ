/*
 LogDAOImpl was created on Jun 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.workflow.wfadmin;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: LogDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-29 19:09:59 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class LogDAOImpl implements LogDAO {
  
  public Document retrieve() {

    return null;
  }
}