package com.monsanto.wst.soxic.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.facade.EmailHeaderFacade;


/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 20, 2006
 * Time: 1:16:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayEmailHeaderAction extends org.apache.struts.action.Action{

    public ActionForward execute(ActionMapping actionMapping, ActionForm form,
                                 HttpServletRequest httpServletRequest,
                                 HttpServletResponse httpServletResponse) throws Exception {
        ActionForward actionForward = new ActionForward();
        EmailHeaderFacade emailHeaderFacade = new EmailHeaderFacade();
        emailHeaderFacade.populateEmailHeaderForm(form);
        actionForward = actionMapping.findForward("displayEmailHeader");
        return actionForward;
    }
}
