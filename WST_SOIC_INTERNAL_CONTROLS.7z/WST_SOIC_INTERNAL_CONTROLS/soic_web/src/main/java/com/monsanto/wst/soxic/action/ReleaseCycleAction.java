package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.CycleManageFacade;
import com.monsanto.wst.soxic.facade.CycleOnlyCertifyFacade;
import com.monsanto.wst.soxic.facade.CycleOnlyConstants;
import com.monsanto.wst.soxic.form.DocChangeForm;
import com.monsanto.wst.soxic.model.CycleMaintainObject;
import com.monsanto.wst.soxic.util.MiscUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 27, 2005
 * Time: 9:08:23 AM
 *
 * This class contains the methods to set the cycles into various states based
 * on the user selection. If the action coming from the JSP is an UPDATE, the
 * Cyclemaintainobjectlist is iterated over and data for each cycleMaintainObject
 * is retrieved. The states RELEASED, LOCKED and PRE_CERTIFICATION are set based
 * on the boolean variables docrelease, locked and published which are true if
 * they are selected. The methods to change states are contained in CycleManageFacade.
 *
 */

public class ReleaseCycleAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        DocChangeForm dochangeform = (DocChangeForm)form;
        CycleManageFacade cycleManageFacade = new CycleManageFacade();
        String docaction = request.getParameter("method");
        String countryid = dochangeform.getSelectedCountry();

//        List periodList = new ArrayList();
        Vector periodList = new Vector();
        CycleOnlyCertifyFacade cycleOnlyCertifyFacade = new CycleOnlyCertifyFacade();

        List tempList = dochangeform.getCyclemaintainobjectlist();
        Iterator iterator = tempList.iterator();

        if (docaction.equalsIgnoreCase("UPDATE")){
            while(iterator.hasNext()){
            CycleMaintainObject cycleMaintainObject = (CycleMaintainObject)iterator.next();
                if ((cycleMaintainObject.isPublished()) && (!cycleMaintainObject.isLocked()) && (!cycleMaintainObject.isDocrelease())){
                    preCertifyCycles(cycleMaintainObject.getCycle(), cycleOnlyCertifyFacade, periodList, cycleManageFacade);
                }

                if ((cycleMaintainObject.isLocked()) && (!cycleMaintainObject.isDocrelease()) && (!cycleMaintainObject.isPublished())){
                    cycleManageFacade.lockedCycles(dochangeform,cycleMaintainObject,cycleMaintainObject.getCycle(),cycleMaintainObject.getState(),cycleMaintainObject.getBegin_date(),cycleMaintainObject.getEnd_date(),cycleMaintainObject.isLocked());
                }

                if ((cycleMaintainObject.isDocrelease()) && (!cycleMaintainObject.isLocked()) && (!cycleMaintainObject.isPublished())){
                    cycleManageFacade.releaseCycles(dochangeform,cycleMaintainObject,countryid,cycleMaintainObject.getCycle(),cycleMaintainObject.getState(),cycleMaintainObject.getBegin_date(),cycleMaintainObject.getEnd_date(),cycleMaintainObject.isDocrelease());
                }

                if ((!cycleMaintainObject.isDocrelease()) && (!cycleMaintainObject.isLocked()) && (!cycleMaintainObject.isPublished())){
                    cycleManageFacade.initiateCycles(dochangeform,cycleMaintainObject,countryid,cycleMaintainObject.getCycle(),cycleMaintainObject.getState(),cycleMaintainObject.getBegin_date(),cycleMaintainObject.getEnd_date(),cycleMaintainObject.isDocrelease());
                }
            }
        }

        cycleManageFacade.createCycleMaintainObjectList(dochangeform,countryid);

        return mapping.findForward("doreleasecyclelist");

        }

    public void preCertifyCycles(String cycleid, CycleOnlyCertifyFacade cycleOnlyCertifyFacade, Vector periodList, CycleManageFacade cycleManageFacade) throws Exception {
        String period = MiscUtils.getTokenizedPeriod(cycleid);
        if (cycleOnlyCertifyFacade.checkCycleExistenceInList(periodList,period)){
            cycleOnlyCertifyFacade.processCycleOnlyPublish(cycleOnlyCertifyFacade, cycleid, cycleManageFacade);
            cycleManageFacade.preCertifyCycles(cycleid);
            cycleManageFacade.putIntoPreCertifyState(cycleid);
        }else{
            if (cycleManageFacade.preCertifyCycles(cycleid)){
                cycleManageFacade.putIntoPreCertifyState(cycleid);
            }
        }
    }


}


