/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.sql.Date;
import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CountryObject {
	
	private String countryName;
	private int totalActivities;
	private int activityPercentageComplete;
	private Date estimatedCompletionDate;
	
	private Vector periodVector = new Vector();
	
	
	/**
	 * @return Returns the activityPercentageComplete.
	 */
	public int getActivityPercentageComplete() {
		return activityPercentageComplete;
	}
	/**
	 * @param activityPercentageComplete The activityPercentageComplete to set.
	 */
	public void setActivityPercentageComplete(int activityPercentageComplete) {
		this.activityPercentageComplete = activityPercentageComplete;
	}
	/**
	 * @return Returns the countryName.
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName The countryName to set.
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * @return Returns the estimatedCompletionDate.
	 */
	public Date getEstimatedCompletionDate() {
		return estimatedCompletionDate;
	}
	/**
	 * @param estimatedCompletionDate The estimatedCompletionDate to set.
	 */
	public void setEstimatedCompletionDate(Date estimatedCompletionDate) {
		this.estimatedCompletionDate = estimatedCompletionDate;
	}
	/**
	 * @return Returns the periodVector.
	 */
	public Vector getPeriodVector() {
		return periodVector;
	}
	/**
	 * @param periodVector The periodVector to set.
	 */
	public void setPeriodVector(Vector periodVector) {
		this.periodVector = periodVector;
	}
	/**
	 * @return Returns the totalActivities.
	 */
	public int getTotalActivities() {
		return totalActivities;
	}
	/**
	 * @param totalActivities The totalActivities to set.
	 */
	public void setTotalActivities(int totalActivities) {
		this.totalActivities = totalActivities;
	}
}
