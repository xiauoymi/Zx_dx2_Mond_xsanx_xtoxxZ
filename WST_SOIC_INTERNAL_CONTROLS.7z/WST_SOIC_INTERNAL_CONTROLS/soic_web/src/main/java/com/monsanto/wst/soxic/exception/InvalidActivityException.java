package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 3, 2005
 * Time: 4:21:46 PM
 */
public class InvalidActivityException extends Exception{

    public InvalidActivityException(){
		super();
	}

	public InvalidActivityException(Exception e){
		super(e);
	}


}
