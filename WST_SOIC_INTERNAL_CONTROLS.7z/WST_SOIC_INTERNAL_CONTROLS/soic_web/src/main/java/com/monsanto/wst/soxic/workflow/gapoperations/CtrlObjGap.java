package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: VIJAY
 * Date: Sep 25, 2005
 * Time: 6:30:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class CtrlObjGap extends GapEntity {
}
