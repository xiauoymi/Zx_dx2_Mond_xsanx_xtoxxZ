/*
 DocChangesReportDAO was created on Jan 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.model;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.TextDifference;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Filename:    $RCSfile: DocChangesReportDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-01-16 21:16:24 $
 *
 * @author emgoode
 * @version $Revision: 1.6 $
 */
public class DocChangesReportDAO {

    private static final String RETRIEVE_CYCLES_QUERY = "select distinct cycle_code from sarbox_et.cycle order by cycle_code asc";
    private static final String RETRIEVE_REPORT_LIST_QUERY = "select regular.OCREQ_ID,\n" +
        "       nvl(activity.activity_id, request.source_id) activity_id,\n" +
        "\t   owner.name, \n" +
        "\t   decode(regular.approved, 'Y', 'Approved','N','Rejected','Pending') as reg_approval,\n" +
        "\t   decode(iaudit.approved, 'Y', 'Approved','N','Rejected','Pending') as iaudit_approval,\n" +
        "\t   request.req_type\n" +
        "from sarbox_et.owner owner, \n" +
        "     sarbox_et.owner_change_request request, \n" +
        "\t sarbox_et.ocreq_response regular, \n" +
        "\t sarbox_et.ocreq_response iaudit,\n" +
        "\t sarbox_et.activity \n" +
        "where regular.ocreq_id = iaudit.ocreq_id \n" +
        "  and request.ocreq_id = regular.ocreq_id\n" +
        "  and request.owner_id = owner.OWNER_ID \n" +
        "  and activity.ACTIVITY_ID(+) = request.source_id \n" +
        "  and regular.resp_type = 'SUB_CYCLE' \n" +
        "  and iaudit.resp_type = 'IA' \n" +
        "  and request.TARGET_PERIOD = ? \n" ;

    private static final String RETRIEVE_DOCCHANGES_DETAILS = "select regular.OCREQ_ID as request_id,\n" +
        "     nvl(activity.activity_id, request.source_id ) activity_id,\n" +
        "\t   owner.name as owner_name, \n" +
        "\t   request.REQ_TEXT as new_text,\n" +
        "\t   activity.description as old_text,\n" +
        "\t   decode(regular.approved, 'Y', 'Approved','N','Rejected','Pending') as reg_approval,\n" +
        "\t   decode(iaudit.approved, 'Y', 'Approved','N','Rejected','Pending') as iaudit_approval,\n" +
        "\t   request.req_type as request_type,\n" +
        "\t   regular.NOTES as regular_notes,\n" +
        "\t   iaudit.NOTES as iaudit_notes\n" +
        "from sarbox_et.owner owner, \n" +
        "     sarbox_et.owner_change_request request, \n" +
        "\t sarbox_et.ocreq_response regular, \n" +
        "\t sarbox_et.ocreq_response iaudit,\n" +
        "\t sarbox_et.activity \n" +
        "where regular.ocreq_id = iaudit.ocreq_id \n" +
        "  and request.ocreq_id = regular.ocreq_id\n" +
        "  and request.owner_id = owner.OWNER_ID \n" +
        "  and activity.ACTIVITY_ID(+) = request.source_id \n" +
        "  and regular.resp_type = 'SUB_CYCLE' \n" +
        "  and iaudit.resp_type = 'IA' \n" +
        "  and request.ocreq_id = ?";
    private static final String CYCLE_CODE = "CYCLE_CODE";

    private static final String RETRIEVE_OLD_DESCRIPTION = "select description from activity where activity.ACTIVITY_ID = " +
        "(select concat(period.SOURCE_PERIOD_ID, substr(source_id, instr(source_id, '.', 1))) \n" +
        "                                                               from sarbox_et.owner_change_request request,\n" +
        "                                                                    sarbox_et.period period \n" +
        "                                                               where target_period = period.PERIOD_ID \n" +
        "                                                                 and request.ocreq_id = ?)";
    private static final String RETRIEVE_OVERFLOW_TEXT_FROM_DOC_CHANGE = "select text_overflow.TEXT_CHUNK as overflow_text, \n" +
            "request.source_id as source_id from sarbox_et.owner owner, \n" +
            "     sarbox_et.owner_change_request request, \n" +
            "\t sarbox_et.ocreq_response regular, \n" +
            "\t sarbox_et.ocreq_response iaudit,\n" +
            "\t sarbox_et.activity,\n" +
            "\t sarbox_et.text_overflow\n" +
            "where regular.ocreq_id = iaudit.ocreq_id \n" +
            "  and request.ocreq_id = regular.ocreq_id\n" +
            "  and request.owner_id = owner.OWNER_ID\n" +
            "  and request.overflow_id = text_overflow.overflow_id \n" +
            "  and activity.ACTIVITY_ID(+) = request.source_id \n" +
            "  and regular.resp_type = 'SUB_CYCLE' \n" +
            "  and iaudit.resp_type = 'IA' \n" +
            "  and request.ocreq_id = ?";

    public ArrayList getDocChangesBySearchParams(Connection connection, HashMap params) throws SQLException {
        ResultSet result = createDocChangesSearchStatement(connection, params).executeQuery();
        ArrayList docChangesList = getDocChangesFromResultSet(result);
        SoxicConnectionFactory.closeResultSet(result);
        return docChangesList;
    }

    public DocChangesReportDetailBean getDocChangeDetailsByRequestId(Connection connection, HashMap params) throws
            Exception {
        TextDifference textDifference = new TextDifference();
        ResultSet result = createDocChangeDetailsStatement(connection, params).executeQuery();
        ResultSet resultOverflow = createOverflowStatementForDocChange (connection, params).executeQuery ();
        DocChangesReportDetailBean docChangesReportDetailBean = createDetailBeanFromResultSet(result, resultOverflow);
        SoxicConnectionFactory.closeResultSet(result);
        docChangesReportDetailBean.setOldText(retrieveOldText(connection, params, docChangesReportDetailBean.getRequestId()));
        docChangesReportDetailBean.setNewText(textDifference.highlightTextDifferences(docChangesReportDetailBean.getOldText(), docChangesReportDetailBean.getNewText()));
        return docChangesReportDetailBean;
    }

    private PreparedStatement  createOverflowStatementForDocChange(Connection connection, HashMap params) throws SQLException {
       PreparedStatement statement = connection.prepareStatement (RETRIEVE_OVERFLOW_TEXT_FROM_DOC_CHANGE);
       statement.setString(1, (String) params.get("ID"));
        return statement;
    }

    private String retrieveOldText(Connection connection, HashMap params, String requestID) throws SQLException {
        ResultSet result = createOldTextStatement(connection, params, requestID).executeQuery();

        if (result.next()) {
            return result.getString(1);
        }
        return "No Old Text Data Found!";
    }

    private PreparedStatement createOldTextStatement(Connection connection, HashMap params, String requestID) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(RETRIEVE_OLD_DESCRIPTION);
        statement.setString(1, requestID);

        return statement;
    }

    public ArrayList getCyclesInSystem(Connection connection) throws WrappingException, SQLException {
        PreparedStatement statement = connection.prepareStatement(RETRIEVE_CYCLES_QUERY);
        ResultSet result = statement.executeQuery();
        ArrayList cyclesList = getCyclesFromResultSet(result);
        SoxicConnectionFactory.closeResultSet(result);

        return cyclesList;
    }

    private ArrayList getCyclesFromResultSet(ResultSet result) throws SQLException {
        ArrayList cycleList = new ArrayList();
        while (result.next()) {
            String cycleCode = SoxicUtil.nullToEmpty(result.getString(CYCLE_CODE));
            cycleList.add(cycleCode);
        }
        return cycleList;
    }

    private ArrayList getDocChangesFromResultSet(ResultSet result) throws SQLException {
        ArrayList docChangesList = new ArrayList();
        while (result.next()) {
            docChangesList.add(createDocChangesReportListBeanFromResultSet(result));
        }
        return docChangesList;
    }

    private DocChangesReportListBean createDocChangesReportListBeanFromResultSet(ResultSet result) throws SQLException {
        return new DocChangesReportListBean(result.getString("OCREQ_ID"),
            result.getString("ACTIVITY_ID"),
            result.getString("NAME"), result.getString("REQ_TYPE"), result.getString("REG_APPROVAL"),
            result.getString("IAUDIT_APPROVAL"));
    }

    //TODO Refactor
    private PreparedStatement createDocChangesSearchStatement(Connection connection, HashMap params) throws SQLException {
        StringBuffer searchStatement = new StringBuffer(RETRIEVE_REPORT_LIST_QUERY);

        ArrayList paramList = new ArrayList();
        paramList.add((String) params.get("PERIOD"));
        if (!"".equals(params.get("COUNTRY"))) {
//            searchStatement.append("  and " +
//                //"trim('.' from substr(activity.activity_id, instr(activity.activity_id, '.', 1, 1) + 1, 3) = " +
//                //" substr((select name from lookup where value = ?), 1, 3) \n" );
//                "trim('.' from substr(activity.activity_id, instr(activity.activity_id, '.', 1, 1), instr(substr(activity.activity_id, instr(activity.activity_id, '.', 1, 1)),'.',1,2))) = " +
//                " (select name from lookup where value = ?) \n");

            searchStatement.append(" and request.source_id like ('%" + (String) params.get("PERIOD") + "%' ");
            searchStatement.append(" || (select name from lookup where value = ?) || '%') ");
                
            paramList.add((String) params.get("COUNTRY"));
        }

        if (!"".equals((String) params.get("CYCLE"))) {
            searchStatement.append(" and request.cycle_code = ? " );
            paramList.add((String) params.get("CYCLE"));
        }
        if (!"".equals((String) params.get("TYPE"))) {
            searchStatement.append(" and request.req_type = ? " );
            paramList.add((String) params.get("TYPE"));            
        }

//        searchStatement.append(" order by activity.activity_id ");
        searchStatement.append(" order by request.source_id ");                

        PreparedStatement statement = connection.prepareStatement(searchStatement.toString());
        statement.setString(1, (String) params.get("PERIOD"));
        int paramCounter = 2;
        if (!"".equals((String) params.get("COUNTRY"))) {
            statement.setString(2, (String) params.get("COUNTRY"));
            paramCounter++;
        }
        if (!"".equals((String) params.get("CYCLE"))) {
            
            statement.setString(paramCounter, (String) params.get("CYCLE"));
            paramCounter++;
        }
        if (!"".equals((String) params.get("TYPE"))) {

            statement.setString(paramCounter, (String) params.get("TYPE"));
        }
        return statement;
    }

    private PreparedStatement createDocChangeDetailsStatement(Connection connection, HashMap params) throws
        SQLException {
        PreparedStatement statement = connection.prepareStatement(RETRIEVE_DOCCHANGES_DETAILS);
        statement.setString(1, (String) params.get("ID"));
        return statement;
    }

    private DocChangesReportDetailBean createDetailBeanFromResultSet(ResultSet result, ResultSet resultOverflow) throws SQLException {
        StringBuffer overflow = new StringBuffer();
        while (resultOverflow.next())
        {
            overflow.append(resultOverflow.getString("overflow_text"));
        }
        if (result.next()) {
            StringBuffer newTextBuffer = new StringBuffer();
            newTextBuffer.append(result.getString("new_text"));
            newTextBuffer.append(overflow.toString());
//           String new_text = result.getString("new_text").concat(overflow.toString());
            String new_text = newTextBuffer.toString();
            return new DocChangesReportDetailBean(result.getString("request_id"),
                result.getString("activity_id"),
                result.getString("owner_name"), new_text,
                //result.getString("new_text"),
                result.getString("old_text"),
                result.getString("reg_approval"),
                result.getString("iaudit_approval"),
                result.getString("request_type"), result.getString("regular_notes"), result.getString("iaudit_notes")
            );
        }
        return null;
    }
}