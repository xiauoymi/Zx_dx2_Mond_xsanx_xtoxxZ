package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 3:16:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmptyDataException extends Exception {

    public EmptyDataException() {
        super();
    }

    public EmptyDataException(Exception e) {
        super(e);
    }
}
