package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 1, 2005
 * Time: 10:06:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class IncorrectDateException extends Exception{

    public IncorrectDateException(){
		super();
	}

	public IncorrectDateException(Exception e){
		super(e);
	}
}
