package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 29, 2005
 * Time: 2:38:19 PM
 */
public class PeriodAlreadyExistsException extends Exception {

    public PeriodAlreadyExistsException(){
        super();
    }

    public PeriodAlreadyExistsException(Exception e){
        super(e);
    }
}
