package com.monsanto.wst.soxic.audit;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 28, 2008
 * Time: 11:23:42 AM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class OwnerSubCyclePK implements Serializable {

//  private String ownerId;
//
//
//  private String subCycleId;

  @ManyToOne
  @JoinColumn(name = "SUB_CYCLE_ID")
  private SubCycleObj subCycleTest;

  @ManyToOne
  @JoinColumn(name = "OWNER_ID")
  private OwnerObj ownerTest;


  public SubCycleObj getSubCycleTest() {
    return subCycleTest;
  }

  public void setSubCycleTest(SubCycleObj subCycleTest) {
    this.subCycleTest = subCycleTest;
  }




  public OwnerSubCyclePK() {
  }

//  public String getSubCycleId() {
//    return subCycleId;
//  }
//
//  public void setSubCycleId(String subCycleId) {
//    this.subCycleId = subCycleId;
//  }
//
//  public String getOwnerId() {
//    return ownerId;
//  }
//
//  public void setOwnerId(String ownerId) {
//    this.ownerId = ownerId;
//  }


  public OwnerObj getOwnerTest() {
    return ownerTest;
  }

  public void setOwnerTest(OwnerObj ownerTest) {
    this.ownerTest = ownerTest;
  }
}
