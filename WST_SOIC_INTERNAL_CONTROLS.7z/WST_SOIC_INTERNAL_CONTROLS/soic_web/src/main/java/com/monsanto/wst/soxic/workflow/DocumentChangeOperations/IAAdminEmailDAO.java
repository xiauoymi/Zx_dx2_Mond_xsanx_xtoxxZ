package com.monsanto.wst.soxic.workflow.DocumentChangeOperations;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.mocks.IAAdminEmailDAOInt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 8:38:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class IAAdminEmailDAO implements IAAdminEmailDAOInt{

    public List select(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        OwnerChangeRequestResponse ownerChangeRequestResponse=null;
        List ownerRequestResponseList = new ArrayList();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OCRR.APPROVED,OCRR.RESP_DATE,OCRR.RESP_TYPE FROM OCREQ_RESPONSE OCRR");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                ownerChangeRequestResponse = new OwnerChangeRequestResponse();
                ownerChangeRequestResponse.setResponseDate(rs.getDate("RESP_DATE"));
                ownerChangeRequestResponse.setApproved(rs.getString("APPROVED"));
                ownerChangeRequestResponse.setResponseType(rs.getString("RESP_TYPE"));
                ownerRequestResponseList.add(ownerChangeRequestResponse);

            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return ownerRequestResponseList;
    }

    public List selectForIAResponseApproval(){
       Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        OwnerChangeRequest ownerChangeRequest=null;
        List ownerRequestResponseList = new ArrayList();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OCR.TARGET_ID,OCRR.RESP_DATE,OCR.OWNER_ID,OCR.SOURCE_TYPE FROM OWNER_CHANGE_REQUEST OCR,OCREQ_RESPONSE OCRR WHERE OCR.OCREQ_ID=OCRR.OCREQ_ID AND RESP_TYPE ='IA' AND OCRR.APPROVED='Y'");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                ownerChangeRequest = new OwnerChangeRequest ();
                ownerChangeRequest.setTargetId(rs.getString("TARGET_ID"));
                ownerChangeRequest.setRespApprovedDate(rs.getDate("RESP_DATE"));
                ownerChangeRequest.setSourceType(rs.getString("SOURCE_TYPE"));
                ownerRequestResponseList.add(ownerChangeRequest);

            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return ownerRequestResponseList;
    }

   public List selectForSubCycleApprovalRequest(){
       Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        OwnerChangeRequest ownerChangeRequest=null;
        List ownerRequestResponseList = new ArrayList();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OCR.TARGET_ID,OCR.REQUEST_DATE,OCR.SOURCE_TYPE  FROM OWNER_CHANGE_REQUEST OCR WHERE OCR.SOURCE_TYPE='ACTIVITY'");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                ownerChangeRequest = new OwnerChangeRequest ();
                ownerChangeRequest.setTargetId(rs.getString("TARGET_ID"));
                ownerChangeRequest.setRespApprovedDate(rs.getDate("REQUEST_DATE"));
                ownerChangeRequest.setSourceType(rs.getString("SOURCE_TYPE"));
                ownerRequestResponseList.add(ownerChangeRequest);

            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return ownerRequestResponseList;
    }
}
