package com.monsanto.wst.soxic.action;

import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.FAQForm;
import com.monsanto.wst.soxic.facade.CreateFAQFacade;
import com.monsanto.wst.soxic.exception.FaqSubmitException;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 12, 2006
 * Time: 9:13:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaveAdminFAQAction extends Action {

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception{

        FAQForm faqForm = (FAQForm) form;
        CreateFAQFacade facade = new CreateFAQFacade();
        ActionMessages messages = new ActionMessages();

        facade.process(faqForm);
        messages.add(ActionMessages.GLOBAL_MESSAGE,new ActionMessage(SoxicConstants.FAQ_SUCCESS));
        saveMessages(request,messages);

        return mapping.findForward("success");
    }
}
