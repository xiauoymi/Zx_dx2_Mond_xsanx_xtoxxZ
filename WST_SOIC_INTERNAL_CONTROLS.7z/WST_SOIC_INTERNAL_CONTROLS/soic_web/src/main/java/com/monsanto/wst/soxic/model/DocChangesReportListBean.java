/*
 DocChangesReportListBean was created on Feb 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.model;

/**
 * Filename:    $RCSfile: DocChangesReportListBean.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: emgoode $    	 On:	$Date: 2007-06-08 15:03:24 $
 *
 * @author emgoode
 * @version $Revision: 1.1 $
 */
public class DocChangesReportListBean extends Object {

    private String requestId = "";
    private String activity = "";
    private String requestor = "";
    private String type = "";
    private String subCycleStatus = "";
    private String iAuditStatus = "";

    public DocChangesReportListBean(String requestId, String activity, String requestor, String type, String subCycleStatus, String iAuditStatus) {
        this.requestId = requestId;
        this.activity = activity;
        this.requestor = requestor;
        this.type = type;
        this.subCycleStatus = subCycleStatus;
        this.iAuditStatus = iAuditStatus;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getIAuditStatus() {
        return iAuditStatus;
    }

    public void setiAuditStatus(String iAuditStatus) {
        this.iAuditStatus = iAuditStatus;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public String getSubCycleStatus() {
        return subCycleStatus;
    }

    public void setSubCycleStatus(String subCycleStatus) {
        this.subCycleStatus = subCycleStatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}