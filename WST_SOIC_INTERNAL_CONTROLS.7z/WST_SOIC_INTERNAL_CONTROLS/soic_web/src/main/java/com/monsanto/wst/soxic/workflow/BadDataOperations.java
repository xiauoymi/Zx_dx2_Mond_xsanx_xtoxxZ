package com.monsanto.wst.soxic.workflow;

import com.monsanto.wst.soxic.exception.BadDataException;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 1, 2005
 * Time: 3:05:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class BadDataOperations {

    	public static void main(String args[]){
		BadDataOperations badDataOperations = new BadDataOperations();
		try{
			badDataOperations.runCheckForBadData();
		}catch(BadDataException badDataException){

		}

	}

	public void runCheckForBadData()throws BadDataException{

		List activityList  = getBadDataList(SoxicConstants.ACTIVITY);

		List subCycleList  = getBadDataList(SoxicConstants.SUBCYCLE);

		List cycleList  = getBadDataList(SoxicConstants.CYCLE);

		if(activityList.size()>0){

			throw new BadDataException();
		}

		if(subCycleList.size()>0){

			throw new BadDataException();
		}

		if(cycleList.size()>0){

			throw new BadDataException();
		}
	}

	public List getBadDataList(String level){
		List levelBadDataList = new ArrayList();
		Connection con = null;

		PreparedStatement preparedStatement = null;

		try {
			con = getConnection();

			preparedStatement = con.prepareStatement(getQuery(level));

			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()){
				if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
					levelBadDataList.add(rs.getString("IDENTI"));
				}
				if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
					levelBadDataList.add(rs.getString("IDENTI"));
				}
				if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
					levelBadDataList.add(rs.getString("IDENTI"));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return levelBadDataList;
	}

	public Connection getConnection() throws Exception {
		return SoxicConnectionFactory.getSoxicConnection();
	}

	public String getQuery(String level){
		if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
			return "SELECT ACTIVITY_ID AS IDENTI FROM ACTIVITY WHERE ACTIVITY_ID NOT IN (SELECT ACTIVITY_ID FROM OWNER_ACTIVITY)";
		}
		if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
			return "SELECT SUB_CYCLE_ID AS IDENTI FROM SUB_CYCLE WHERE SUB_CYCLE_ID NOT IN (SELECT SUB_CYCLE_ID FROM OWNER_SUB_CYCLE)";
		}
		if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
			return "SELECT CYCLE_ID AS IDENTI FROM CYCLE WHERE CYCLE_ID NOT IN (SELECT CYCLE_ID FROM OWNER_CYCLE)";
		}
		return "";
	}

}
