/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.form;

import java.io.Serializable;

/**
 * This is a bean that is used to store elements of one row.
 * This object is stored in a Column Vector, that is iterated over
 * while displaying on JSP or a excel file.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class RowObject implements Serializable{
	
	String col1;
	String col2;
	String col3;
	String col4;
	String col5;
	String col6;
	String col7;
	String col8;
    String col9;
    String col12;




	/**
	 * @return Returns the col1.
	 */
	public String getCol1() {
		return col1;
	}
	/**
	 * @param col1 The col1 to set.
	 */
	public void setCol1(String col1) {
		this.col1 = col1;
	}
	/**
	 * @return Returns the col2.
	 */
	public String getCol2() {
		return col2;
	}
	/**
	 * @param col2 The col2 to set.
	 */
	public void setCol2(String col2) {
		this.col2 = col2;
	}
	/**
	 * @return Returns the col3.
	 */
	public String getCol3() {
		return col3;
	}
	/**
	 * @param col3 The col3 to set.
	 */
	public void setCol3(String col3) {
		this.col3 = col3;
	}
	/**
	 * @return Returns the col4.
	 */
	public String getCol4() {
		return col4;
	}
	/**
	 * @param col4 The col4 to set.
	 */
	public void setCol4(String col4) {
		this.col4 = col4;
	}
	/**
	 * @return Returns the col5.
	 */
	public String getCol5() {
		return col5;
	}
	/**
	 * @param col5 The col5 to set.
	 */
	public void setCol5(String col5) {
		this.col5 = col5;
	}
	/**
	 * @return Returns the col6.
	 */
	public String getCol6() {
		return col6;
	}
	/**
	 * @param col6 The col6 to set.
	 */
	public void setCol6(String col6) {
		this.col6 = col6;
	}
	/**
	 * @return Returns the col7.
	 */
	public String getCol7() {
		return col7;
	}
	/**
	 * @param col7 The col7 to set.
	 */
	public void setCol7(String col7) {
		this.col7 = col7;
	}
	/**
	 * @return Returns the col8.
	 */
	public String getCol8() {
		return col8;
	}
	/**
	 * @param col8 The col8 to set.
	 */
	public void setCol8(String col8) {
		this.col8 = col8;
	}

    public String getCol9() {
        return col9;
    }

    public void setCol9(String col9) {
        this.col9 = col9;
    }

    public String getCol12() {
        return col12;
    }

    public void setCol12(String col12) {
        this.col12 = col12;
    }


}
