package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;
import com.monsanto.wst.soxic.model.ReportOwners;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 9, 2006
 * Time: 9:44:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class OrphanReportForm extends ActionForm{

    private List periodList;
    private String selperiod;
    private String id;
    private List allCycles;
    private List allSubcycles;
    private List allActivities;

    public List getPeriodList() {
        return periodList;
    }

    public void setPeriodList(List periodList) {
        this.periodList = periodList;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSelperiod() {
        return selperiod;
    }

    public void setSelperiod(String selperiod) {
        this.selperiod = selperiod;
    }

    public List getAllCycles() {
        return allCycles;
    }

    public void setAllCycles(List allCycles) {
        this.allCycles = allCycles;
    }

    public List getAllSubcycles() {
        return allSubcycles;
    }

    public void setAllSubcycles(List allSubcycles) {
        this.allSubcycles = allSubcycles;
    }

    public List getAllActivities() {
        return allActivities;
    }

    public void setAllActivities(List allActivities) {
        this.allActivities = allActivities;
    }


    public OrphanReportForm() {
    }


}
