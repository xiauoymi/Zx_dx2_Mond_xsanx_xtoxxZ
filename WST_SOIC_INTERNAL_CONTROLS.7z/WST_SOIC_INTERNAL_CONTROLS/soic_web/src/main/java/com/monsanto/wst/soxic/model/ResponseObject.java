package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 22, 2006
 * Time: 3:24:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ResponseObject {

    private String responseId;
    private String response;
    private String gapId;

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getGapId() {
        return gapId;
    }

    public void setGapId(String gapId) {
        this.gapId = gapId;
    }
}
