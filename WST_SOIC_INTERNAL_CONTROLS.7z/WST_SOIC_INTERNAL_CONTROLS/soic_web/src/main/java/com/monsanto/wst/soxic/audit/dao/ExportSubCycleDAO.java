package com.monsanto.wst.soxic.audit.dao;

import com.monsanto.wst.soxic.audit.SubCycleObj;
import org.w3c.dom.Document;

import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.util.Set;
import java.io.IOException;

import com.monsanto.XMLUtil.ParserException;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 9, 2008
 * Time: 11:08:48 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ExportSubCycleDAO {
  public List<SubCycleObj> getSubCycleObjs(String subCycleId) throws Exception;
}
