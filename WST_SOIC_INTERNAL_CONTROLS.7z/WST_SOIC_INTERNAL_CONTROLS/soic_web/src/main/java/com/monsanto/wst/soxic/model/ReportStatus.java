package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 4:02:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReportStatus implements Comparable{

    private String repid;
    private String status;

    public String getRepid() {
        return repid;
    }

    public String getStatus() {
        return status;
    }

    public ReportStatus(String repid, String status) {
        this.repid = repid;
        this.status = status;
    }

    public ReportStatus() {
    }

    public int compareTo(Object o) {
        if(o instanceof ReportStatus)  {
            return repid.compareTo(((ReportStatus)o).getRepid());
        }
        return repid.compareTo(((ReportStatus)o).getRepid()); 
    }
}
