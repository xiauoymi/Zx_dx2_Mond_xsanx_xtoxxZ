package com.monsanto.wst.soxic.testreport;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 11:29:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class TypeOneFilterDAO {
   public List getObjectFromDB() throws DatabaseException {
        PersistentStore persistentStore = null;
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        IAudit iAudit=null;
        List auditList = new ArrayList();
        try {
            persistentStore = WST_SOX_PersistentStoreFactory.getStore();
            PersistentStore.registerInstance(persistentStore);
            psConnection = persistentStore.connect();

            String getObjectFromDBQuery = "SELECT AUDIT_ID,SITE_ID,FISCAL_YEAR,TYPE FROM IAUDIT";

            persistentStoreStatement =  psConnection.prepareStatement(getObjectFromDBQuery);

            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();
            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();

            while(persistentStoreResultSetFwdIterator.next()){
                String auditId = persistentStoreResultSetFwdIterator.getString("AUDIT_ID");
                String siteId = persistentStoreResultSetFwdIterator.getString("SITE_ID");
                String fiscalYear = persistentStoreResultSetFwdIterator.getString("FISCAL_YEAR");
                String type = persistentStoreResultSetFwdIterator.getString("TYPE");

                iAudit = new IAudit();
                iAudit.setAuditid(auditId);
                iAudit.setSiteid(siteId);
                iAudit.setPeriod(fiscalYear);
                iAudit.setAuditype(type);

                auditList.add(iAudit);
            }

            return auditList;

        } catch (WrappingException e) {
            e.printStackTrace();
            throw new DatabaseException(e);
        }
        finally{
            if(persistentStoreStatement != null){
                try {
                    persistentStoreStatement.close();
                } catch (WrappingException e) {
                    e.printStackTrace();
                    throw new DatabaseException(e);
                }
            }
            if(psConnection != null){
                try {
                    psConnection.close();
                } catch (WrappingException e) {
                    e.printStackTrace();
                    throw new DatabaseException(e);
                }
            }
        }
    }

}
