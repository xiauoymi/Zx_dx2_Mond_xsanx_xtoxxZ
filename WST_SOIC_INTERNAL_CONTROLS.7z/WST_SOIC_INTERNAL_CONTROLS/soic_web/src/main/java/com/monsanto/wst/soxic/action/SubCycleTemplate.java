/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycleTemplate {
	
	SubCycleHeaderTemplate header;
	
	//ActivityTemplate activities[];
	Vector activityTemplateList = new Vector();
	
	//SubCycleOwnerTemplate owners[];
	Vector scOwnerTemplateList = new Vector();
	
	

	
	
	/**
	 * @return Returns the activityTemplateList.
	 */
	public Vector getActivityTemplateList() {
		return activityTemplateList;
	}
	/**
	 * @param activityTemplateList The activityTemplateList to set.
	 */
	public void setActivityTemplateList(Vector activityTemplateList) {
		this.activityTemplateList = activityTemplateList;
	}
	
	
	
	/**
	 * @return Returns the scOwnerTemplateList.
	 */
	public Vector getScOwnerTemplateList() {
		return scOwnerTemplateList;
	}
	/**
	 * @param scOwnerTemplateList The scOwnerTemplateList to set.
	 */
	public void setScOwnerTemplateList(Vector scOwnerTemplateList) {
		this.scOwnerTemplateList = scOwnerTemplateList;
	}
	/**
	 * @return Returns the header.
	 */
	public SubCycleHeaderTemplate getHeader() {
		return header;
	}
	/**
	 * @param header The header to set.
	 */
	public void setHeader(SubCycleHeaderTemplate header) {
		this.header = header;
	}
	
}
