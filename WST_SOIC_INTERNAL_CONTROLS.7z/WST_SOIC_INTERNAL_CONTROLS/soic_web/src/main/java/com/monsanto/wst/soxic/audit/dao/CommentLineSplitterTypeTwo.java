package com.monsanto.wst.soxic.audit.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.soxic.audit.util.PatternMatcher;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 15, 2009
 * Time: 6:54:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommentLineSplitterTypeTwo implements CommentLineSplitter {
  private static final String RISK_NOT_PRESENT = "RiskNotPresent";
  private static final String MANAGEMENT_RESPONSE_NOT_PRESENT = "ManagementResponseNotPresent";
  private static final String RECOMMENDATION_NOT_PRESENT = "RecommendationNotPresent";
  private static final String AUDIT_SUBJECT_CHANGED_TO_COMMENT_SUBJECT = "AUDIT_SUBJECT_CHANGED_TO_COMMENT_SUBJECT";
  private static final String TITLE_CHANGED_TO_COMMENT_TITLE = "TITLE_CHANGED_TO_COMMENT_TITLE";
  private static final String IMPLEMENTATIONDATE_ONWARDS_NOT_PRESENT = "IMPLEMENTATIONDATE_ONWARDS_NOT_PRESENT";


// Major 
// Audit Subject:  HR Payroll 
// Title:Employee Advances (Loans) 
// Observation:The review of cash advances established that the site allows advances to employees for various reasons such as:  ?? Salary, vacation, and relocation purposes. The calendar year to date advances as at June 2005 was USD50K.     The approval of these advances goes through the HR Lead, but there is no documented policy or approval as required by the Board of Directors Resolution.
// Risk:?? Unauthorized transactions ?? Safeguarding of company assets 
// Recommendation:Per Board of Directors resolution, all employee loan programs must be approved by the corporate HR Director along with the CEO, CFO, or Treasurer.  The site should work with Legal and External Reporting in St. Louis to ensure all appropriate approvals are in place for this program and a delegation of authority to approve these advances have been properly established. 
// Implementation Date: 
// Remediation Plan: 
// Department Responsible:  
// Responsible Person, Title:  
// Major 
// Audit Subject:  Credit & Collections and Customer Operations/ HR Payroll 
// Title:Segregation of Duties  
// Observation:Internal audit interviewed various employees and selected a sample of user privileges.  Issues identified as of July 22 2005 include the following: ?? 6 LAS employees had access to post incoming payments and maintain credit master data. ?? 14 LAS employees had access to post incoming payments and release credit holds ?? 1 LAS employee had access to post incoming payments and process customer invoices ?? 2 LAS employees had access to process sales orders and process customer invoices ?? 5 LAS employees had access to process sales orders and post goods issues to customers ?? 1 LAS employee can perform customer master data maintenance and post incoming payments   ?? HR employee is responsible for reconciling all HR payroll accounts. ?? Same personnel responsible for payroll data/salaries/ news are responsible for checking the output from Outsourced payroll system.  No independent control is being performed 
// Risk:Safeguarding of assets - Potential loss of company assets and misstatement of account balances 
// Recommendation:?? The site should consider instituting controls that would ensure proper segregation of duties. ?? Have Accounting reconcile all / most of the accounts and make this person sign a confidentiality agreement.   
// Implementation Date: 
// Management Response: 
// Department Responsible:  
// Responsible Person, Title:

  public String[] getEachCommentAsAString(String issueChunk, String type) throws StringSplitException {
//    String data[] = new String[1];
//    data[0]=issueChunk;
//    return data;  //To change body of implemented methods use File | Settings | File Templates.
    issueChunk = issueChunk.replace("Recommendations:", "Recommendation:");
    if(issueChunk!=null && (
            issueChunk.contains("Observation:Monsanto Caribe")   ||
            issueChunk.contains("Observation:There is no formal management review process in place for reconciliations") ||
            issueChunk.contains("Observation:Currently the product costing methodology used does not include many components defined in CCP 40000.20")

    )){
      issueChunk = issueChunk.replace("Management Response", "Management Response:");
    }
    String memoCommentsDelimiter = "Major";
    String typeDelimiter = "Audit Subject:";
    String[] strings = issueChunk.split(memoCommentsDelimiter);

//    String majorCount = getData(memoCommentsDelimiter, typeDelimiter, issueChunk);
//    String[] data =null;
//    if(!StringUtils.isNullOrEmpty(majorCount)){
//      if(majorCount.trim().contains(":")){
//        int count = Integer.parseInt(majorCount.replaceAll(":","").trim());
//        data = new String[count];
//        for(int j=0;j<count;j++){
//          String start = type+ (j+1) + " of " + count;
//          String end = type+ (j+2) + " of " + count;
//          data[j]= getDataModified(start, end, issueChunk);
//        }
//      }
//    }
    return strings;
  }

  private static HashMap<String,String> userCatMap;


  public CommentLineSplitterTypeTwo() {
      populateUserCatMap();
  }

  private String getData(String start, String end, String issueChunk) throws StringSplitException {
//     return issueChunk;
    int index=0;
    int endIndex=0;
    int startStrIndex = issueChunk.indexOf(start);
    int endstrIndex = issueChunk.indexOf(end);

    if(startStrIndex==-1 ){
      System.out.println("issueChunk = " + issueChunk);
      throw new StringSplitException(start + " Start Delimiter not present", null);
    }

    if(endstrIndex==-1 ){
      throw new StringSplitException(end + " End Delimiter not present", null);
    }
    if(startStrIndex > endstrIndex){
      String temp= end;
      end=start;
      start = temp;
//      throw new StringSplitException("Start Index Greater than end index", null);
    }

    try{
      if(StringUtils.isNullOrEmpty(end)){
        return issueChunk.substring(issueChunk.indexOf(start)+start.length());
      }
      //    int endIndex = getEndIndex(issueChunk, end);
      index = issueChunk.indexOf(start) + start.length();
      endIndex = issueChunk.indexOf(end);
      return issueChunk.substring(index, endIndex);
    }catch(Exception e){
      throw new StringSplitException("Error splitting: Start -"+start+" End -"+end, e);
    }
  }

  private String getDataModified(String start, String end, String issueChunk) {
//     return issueChunk;
    if(StringUtils.isNullOrEmpty(end)){
      return issueChunk.substring(issueChunk.indexOf(start)+start.length());
    }
    int endIndex = getEndIndex(issueChunk, end);
//    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),issueChunk.indexOf(end));
    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),endIndex);
  }

  private int getEndIndex(String issueChunk, String endString) {
    int endIndex = issueChunk.indexOf(endString);
    if(endIndex<0){
      return issueChunk.length();
    }
    return endIndex;
  }


//New             "\u0000Major\u0000Audit Subject: Cash and Cash equivalents\u0000Title:Bank reconciliations and cash application\u0000Observation:?? As of March 31, 2003 the Bank Boston reconciliation has approximately $7.4M in bank deposits that have yet to be recorded in MONARG books.  As per site management, the bank has failed to provide detailed information identifying depositors. According to the site such deposits are most likely related to accounts receivable payments.\u0000?? Auditing Services selected a sample of the bank reconciliations as of March 2003. The following was noted:\u0000?? Bank Boston:  There were approximately 3,000 reconciling items totaling $10.6M (absolute value of $23M). Approximately 38% of them are aged more than 6 months and more than 50% of them are related to checks to vendors outstanding.\u0000?? Biesel Bank:  Approximately 1,000 reconciling items are still outstanding (62% are greater than 6 months old). The current value of these items is considered non-material.\u0000?? BBVA-Franc??s Bank: Approximately 204 reconciling items (83% of the total) are over six months old. The amount of these items is considered non-material.\u0000RiskMisstatement of financial records.\u0000Recommendation:Management should continue identifying depositors and other reconciling items in order to record them in a timely manner. The site should assess the most likely source of the deposits and other transactions. Reconciling deposits aged over a year should be recorded to receivables. \u0000Implementation Date:Q2, 2003\u0000Management Response:Management wants to reinforce that all efforts to identify depositors have been made and will continue to be made in the future. However, regardless of the local staff efforts, this issue will not be solved until the banks provide full support in the identification of the reconciling items.\u0000Currently we perform an annual clean up run of all unidentified deposits of less than 5,000 Arg pesos (around $1,600 dollars) which have been pending for more than 3 years. We suggest changing that procedure in order to run 2 annual cleanups of unidentified deposits of less than 10,000 Arg pesos. On the payment side we???ll keep the present procedure of 1 annual cleanup of all legally overdue unpaid checks.\u0000The proposed recommendation about reconciling deposits will be implemented immediately. However we???d like to point out that this change in procedure will only change the way we report the item, as the unidentified deposits will remain as ???Unassigned collections??? until we can get formal identification of the depositor.\u0000Department Responsible:  Finance Team\u0000Responsible Person, Title:  Abelardo Gomez, Controller; Mabel Valcarce, Accounting Operations Manager.\u0000\t";
//Old             "\u0000Major 1 of 1:\u0000Type: \tMajor\u0000Comment Title: \tAccount Reconciliations\u0000Comment Subject: \tAccount Reconciliations\u0000Observation: \t* Account 11810000 Prepaid Insurance includes an insurance service for $1.6M PHP that started on January 07 and will end on December 07. The monthly amortization of $134K PHP for this service was not recognized on the account on the Balance Sheet for the months of January and February, and was over amortized ($134K PHP) on March. This issue was adjusted in April. \u0000* Account 11900100 Deferred Tax Assets shows a discrepancy between March's reconciliation and the actual balance sheet. The amount stated on the balance sheet was from February, misstating the Balance Sheet by $6M PHP. This issue was adjusted on April's balance sheet. \u0000* Bank reconciliation for the USD Citibank account - 10125200 did not tie to March's Balance Sheet since an unadjusted exchange rate was used. Bank reconciliation for the PHP Citibank account - 10125190 did not tie to March's balance either by the amount of 11.5 M PHP. On April's Balance Sheet both accounts were adjusted. \u0000* Preparer and reviewer signature was missing on five out of the 16 reconciliations received. None of the reconciliations had the sign-off date. \u0000* Three account reconciliations were prepared inadequately. They did not explain the balance properly.\u0000Management Response: \t\u0000Responsible Party: \t\u0000Anticipated Completion: \t\u0000Cause: \tFIN - Reconciliation and Review\u0000Recommendation: \tThe site should be in compliance of CCP#85007.10. \u0000Risk: \tNon-compliance with Company policies. - Possible Inaccurate Financial Records\u0000Repeat Flag: \tN\u0000\u0000\u0000Associated Activities\u0000\u0000FCPA.05.01.01\tDetermine whether the entities have financial records that comply with the FCPA accounting requirements and appear adequate for GAAP reporting.\u0000ADH.01.01\tQuestion 1\u0000\t";
//                  Major Audit Subject: Management Practices  Title Awareness on issues relating to management Practices Observation:Internal audit conducted interviews on the general awareness of various management issues. The general awareness was realized at below 50% in the following areas: ?? Guidelines on gathering competitive information within the corporate policies; ?? Anti boycott provisions; and ?? Record retention. Ten members of the management team were interviewed.  Risk:Potential risk of non compliance with legal provisions and corporate policies Recommendation:The site should consider commencing training programs that would ensure dissemination of information to the entire leadership team aimed at eventually cascading downwards to the entire organization. Implementation Date:October 31 Management Response:Appropriate training materials will be identified and rolled out to the organization. Department Responsible: Legal/ Finance Responsible Person, Title: Fernando Giannoni / Phil McMahon 
//  Major Audit Subject: Management Practices  Title Awareness on issues relating to management Practices Observation:Internal audit conducted interviews on the general awareness of various management issues. The general awareness was realized at below 50% in the following areas: ?? Guidelines on gathering competitive information within the corporate policies; ?? Anti boycott provisions; and ?? Record retention. Ten members of the management team were interviewed.  Risk:Potential risk of non compliance with legal provisions and corporate policies Recommendation:The site should consider commencing training programs that would ensure dissemination of information to the entire leadership team aimed at eventually cascading downwards to the entire organization. Implementation Date:October 31 Management Response:Appropriate training materials will be identified and rolled out to the organization. Department Responsible: Legal/ Finance Responsible Person, Title: Fernando Giannoni / Phil McMahon
//  Major Audit Subject: Management Practices  Title Awareness on issues relating to management Practices Observation:Internal audit conducted interviews on the general awareness of various management issues. The general awareness was realized at below 50% in the following areas: ?? Guidelines on gathering competitive information within the corporate policies; ?? Anti boycott provisions; and ?? Record retention. Ten members of the management team were interviewed.  Risk:Potential risk of non compliance with legal provisions and corporate policies Recommendation:The site should consider commencing training programs that would ensure dissemination of information to the entire leadership team aimed at eventually cascading downwards to the entire organization. Implementation Date:October 31 Management Response:Appropriate training materials will be identified and rolled out to the organization. Department Responsible: Legal/ Finance Responsible Person, Title: Fernando Giannoni / Phil McMahon


  public List buildXML(String[] data, StringBuffer issuesBuffer, String originTitle, StringBuffer errorBuffer) throws Exception, StringSplitException {
//    String[] delimiters = new String[]{"Type:","Comment Title:",
//            "Comment Subject:","Observation:","Management Response:","Responsible Party:",
//            "Cause:","Recommendation:","Risk:","Repeat Flag:","Associated Activities"};

//    String[] delimiters = new String[]{"Audit Subject:","Title:",
//            "Observation:","Recommendation:","Management Response:",
//            "Responsible Person, Title:","Recommendation:","Risk:","Repeat Flag:","Associated Activities"};

    String typeStr= "";
    String titleStr= "";
    String textField4 = "";
    String finding = "";
    String textField2 = "";
    String userCat2 = "";
    String textField1 = "";
    String textField3= "";
    String textField10= "";
    String issueChunk= "";
    List issueList = new ArrayList();
    for(int i=0;i<data.length;i++){
      Issue issue1;
      issueChunk = data[i].trim();
      if(issueChunk.length()>0){
        String condition = getCondition(issueChunk);
        String[] delimiters = getDelimetersBasedOnCondition(condition);
//      try{
        String returnString = checkForDuplicateDelimiters(issueChunk,delimiters,i,data.length);
//      if("NONE".equals(returnString)){
        //Type
//        typeStr = getData(delimiters[0], delimiters[1], issueChunk);
        if(issueReported(issueChunk)){

          issue1 = getIssueBasedOnDelimiters(issuesBuffer, originTitle, issueChunk, delimiters,condition);
        } else{
          issue1 = new Issue();
        }
//      } catch (StringSplitException e) {
//        issue1 = new Issue();
//        issue1.setError(e.getMessage());
//        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//      }
//      }else{
      issueList.add(issue1);
      }
//        errorBuffer.append(returnString);
//      }
    }
    return issueList;
  }

  private boolean issueReported(String issueChunk) {
    if(issueChunk.contains("Audit Subject:")
            || issueChunk.contains("Title:")
            || issueChunk.contains("Observation:")
            || issueChunk.contains("Recommendation:")
            || issueChunk.contains("Implementation Date:")
            || issueChunk.contains("Management Response:")
            || issueChunk.contains("Title:")
            || issueChunk.contains("Title:")
            )  {
      return true;
    }
    return false;  //To change body of created methods use File | Settings | File Templates.
  }

  private String getCondition(String issueChunk) {
    if(issueChunk.indexOf("Implementation Date:")==-1
            && issueChunk.indexOf("Management Response:")==-1
            && issueChunk.indexOf("Department Responsible:")==-1
            && issueChunk.indexOf("Responsible Person, Title:")==-1 ) {
      return IMPLEMENTATIONDATE_ONWARDS_NOT_PRESENT;
    }
    if(issueChunk.indexOf("Risk:")==-1) {
      return  RISK_NOT_PRESENT;
    }
    if(issueChunk.indexOf("Management Response:")==-1) {
      return  MANAGEMENT_RESPONSE_NOT_PRESENT;
    }
    if(issueChunk.indexOf("Recommendation:")==-1) {
      return  RECOMMENDATION_NOT_PRESENT;
    }
    if(issueChunk.indexOf("Comment Subject:")!=-1) {
          return  AUDIT_SUBJECT_CHANGED_TO_COMMENT_SUBJECT;
    }
//    if(issueChunk.indexOf("Comment Title:")!=-1) {
//          return  TITLE_CHANGED_TO_COMMENT_TITLE;
//    }
    return "";  //To change body of created methods use File | Settings | File Templates.
  }

  //Audit Subject: Cash and Cash equivalents\u0000
  //Title:Bank reconciliations and cash application\u0000
  //Observation:?? As of March 31, 2003 the Bank Boston reconciliation has approximately $7.4M in bank deposits that have yet to be recorded in MONARG books.  As per site management, the bank has failed to provide detailed information identifying depositors. According to the site such deposits are most likely related to accounts receivable payments.\u0000?? Auditing Services selected a sample of the bank reconciliations as of March 2003. The following was noted:\u0000?? Bank Boston:  There were approximately 3,000 reconciling items totaling $10.6M (absolute value of $23M). Approximately 38% of them are aged more than 6 months and more than 50% of them are related to checks to vendors outstanding.\u0000?? Biesel Bank:  Approximately 1,000 reconciling items are still outstanding (62% are greater than 6 months old). The current value of these items is considered non-material.\u0000?? BBVA-Franc??s Bank: Approximately 204 reconciling items (83% of the total) are over six months old. The amount of these items is considered non-material.\u0000RiskMisstatement of financial records.\u0000
  // Recommendation:Management should continue identifying depositors and other reconciling items in order to record them in a timely manner. The site should assess the most likely source of the deposits and other transactions. Reconciling deposits aged over a year should be recorded to receivables. \u0000
  // Implementation Date:Q2, 2003\u0000
  // Management Response:Management wants to reinforce that all efforts to identify depositors have been made and will continue to be made in the future. However, regardless of the local staff efforts, this issue will not be solved until the banks provide full support in the identification of the reconciling items.\u0000Currently we perform an annual clean up run of all unidentified deposits of less than 5,000 Arg pesos (around $1,600 dollars) which have been pending for more than 3 years. We suggest changing that procedure in order to run 2 annual cleanups of unidentified deposits of less than 10,000 Arg pesos. On the payment side we???ll keep the present procedure of 1 annual cleanup of all legally overdue unpaid checks.\u0000The proposed recommendation about reconciling deposits will be implemented immediately. However we???d like to point out that this change in procedure will only change the way we report the item, as the unidentified deposits will remain as ???Unassigned collections??? until we can get formal identification of the depositor.\u0000
  // Department Responsible:  Finance Team\u0000
  // Responsible Person, Title:  Abelardo Gomez, Controller; Mabel Valcarce, Accounting Operations Manager."

//Audit Subject: Fixed Assets 
//Title:Carman ??? Buzza Research Center 
//Observation:Fixed Asset inventory count conducted for Advanta???s Carman facility.  The following issues were noted: ?? A 2004 Combine with an approximate value of $122K CAD was observed at the location; however, it was not on the most recent asset register at the time of the audit being conducted. ?? Serial numbers are not listed in the asset register for over 70% of the assets. ?? Several items with a current net book value of $25K CAD on the asset list appear to be overvalued such as parking lot expenses, landscaping, and research center signage.  ?? Several additional items of value were observed at the location, which were not on the asset list such as a desktop computer, air compressor, generator, snow blower, older model tractor, and a land leveler. ?? The asset list contained names of items only once when there were multiple quantities of these assets such as Canola Drill Hedges. ?? 5 items on the asset list were not able to be located and 6 items listed as being at the Carman site were said to be in other places per the facility manager. ??  Based upon observation there are several items that should be disposed. 
//Risk:?? Safeguarding of assets ?? Asset records and valuation misrepresented ?? Inability to locate assets or prove ownership 
//Recommendation:?? Asset records should be inputted into SAP as they are now maintained manually in an excel spreadsheet. ?? Format, details, and accuracy of asset register should be improved. ?? A process should be established to capture Construction in Progress Assets so that all assets in the company???s possession are timely recorded in the asset register. ?? Serial numbers should be on file for all assets. ?? Assets should be reviewed for any needed value adjustments and/or disposals. ?? Physical asset count should take place for pollination tents.



  private String[] getDelimetersBasedOnCondition(String condition) {
    String[] delimiters=null;
    if(condition.equalsIgnoreCase(AUDIT_SUBJECT_CHANGED_TO_COMMENT_SUBJECT)){
      delimiters = new String[]{"Comment Subject:","Title:",
              "Observation:","Risk:","Recommendation:","Implementation Date:","Management Response:",
              "Department Responsible:","Responsible Person, Title:"};
    } else if(condition.equalsIgnoreCase(TITLE_CHANGED_TO_COMMENT_TITLE)){
      delimiters = new String[]{"Comment Subject:","Comment Title:",
              "Observation:","Risk:","Recommendation:","Implementation Date:","Management Response:",
              "Department Responsible:","Responsible Person, Title:"};
    }
    else{
      delimiters = new String[]{"Audit Subject:","Title:",
              "Observation:","Risk:","Recommendation:","Implementation Date:","Management Response:",
              "Department Responsible:","Responsible Person, Title:"};
    }

    return delimiters;
  }

  private Issue getIssueBasedOnDelimiters(StringBuffer issuesBuffer, String originTitle, String issueChunk,
                                          String[] delimiters, String condition) throws StringSplitException {
    String typeStr;
    String titleStr;
    String textField4;
    String finding;
    String textField2;
    String userCat2;
    String textField1;
    String textField3;
    String textField10;
    Issue issue1 = null;

    if(condition.equalsIgnoreCase(RISK_NOT_PRESENT))  {
      typeStr = "Major";

      //Comment Title
      titleStr = getData(delimiters[1], delimiters[2], issueChunk);

      //Comment Subject : is this same as Audit Subject
      textField4 = getData(delimiters[0], delimiters[1], issueChunk);

      //observation
      finding = getData(delimiters[2], delimiters[4], issueChunk);

      //Management Response
      textField2 = getData(delimiters[5], delimiters[6], issueChunk);

      //Cause : look for cause
//        userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
      userCat2 = "";

      //Recommendation
      textField1 = getData(delimiters[4], delimiters[5], issueChunk);

      //  Risk
      textField3 = ""
      ;

      //Associated Activities
      textField10 = "";

      issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
    }
    else    if(condition.equalsIgnoreCase(MANAGEMENT_RESPONSE_NOT_PRESENT))  {
      typeStr = "Major";

      //Comment Title
      titleStr = getData(delimiters[1], delimiters[2], issueChunk);

      //Comment Subject : is this same as Audit Subject
      textField4 = getData(delimiters[0], delimiters[1], issueChunk);

      //observation
      finding = getData(delimiters[2], delimiters[3], issueChunk);

      //Management Response
      textField2 = "";

      //Cause : look for cause
//        userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
      userCat2 = "";

      //Recommendation
      textField1 = getData(delimiters[4], delimiters[5], issueChunk);

      //  Risk
      textField3 = getData(delimiters[3], delimiters[4], issueChunk);
      ;

      //Associated Activities
      textField10 = "";

      issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
    }
    else    if(condition.equalsIgnoreCase(RECOMMENDATION_NOT_PRESENT))  {
      typeStr = "Major";

      //Comment Title
      titleStr = getData(delimiters[1], delimiters[2], issueChunk);

      //Comment Subject : is this same as Audit Subject
      textField4 = getData(delimiters[0], delimiters[1], issueChunk);

      //observation
      finding = getData(delimiters[2], delimiters[3], issueChunk);

      //Management Response
      textField2 = getData(delimiters[5], delimiters[6], issueChunk);

      //Cause : look for cause
//        userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
      userCat2 = "";

      //Recommendation
      textField1 = "";
//      textField1 = getData(delimiters[4], delimiters[5], issueChunk);

      //  Risk
      textField3 = getData(delimiters[3], delimiters[5], issueChunk);
      ;

      //Associated Activities
      textField10 = "";

      issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
    }
    else    if(condition.equalsIgnoreCase(IMPLEMENTATIONDATE_ONWARDS_NOT_PRESENT))  {
      typeStr = "Major";

      //Comment Title
      titleStr = getData(delimiters[1], delimiters[2], issueChunk);

      //Comment Subject : is this same as Audit Subject
      textField4 = getData(delimiters[0], delimiters[1], issueChunk);

      //observation
      finding = getData(delimiters[2], delimiters[3], issueChunk);

      //Management Response
      textField2 = "";

      //Cause : look for cause
//        userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
      userCat2 = "";

      //Recommendation
      textField1 = issueChunk.substring(issueChunk.indexOf("Recommendation:")+"Recommendation:".length(),issueChunk.length());

      //  Risk
      textField3 = getData(delimiters[3], delimiters[4], issueChunk);
      ;

      //Associated Activities
      textField10 = "";

      issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
    }
    else{
      typeStr = "Major";

      //Comment Title
      titleStr = getData(delimiters[1], delimiters[2], issueChunk);

      //Comment Subject : is this same as Audit Subject
      textField4 = getData(delimiters[0], delimiters[1], issueChunk);

      //observation
      finding = getData(delimiters[2], delimiters[3], issueChunk);

      //Management Response
      textField2 = getData(delimiters[5], delimiters[6], issueChunk);

      //Cause : look for cause
//        userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
      userCat2 = "";

      //Recommendation
      textField1 = getData(delimiters[4], delimiters[5], issueChunk);

      //  Risk
      textField3 = getData(delimiters[3], delimiters[4], issueChunk);
      ;

      //Associated Activities
      textField10 = "";

      issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);

    }
    return issue1;
  }



  private Issue constructIssueSection(StringBuffer issuesBuffer, String typeStr, String titleStr,
                                     String textField4, String finding, String textField2, String userCat2,
                                     String textField1, String textField3, String originTitle, String textField10) {
    Issue issue = new Issue();
    issue.setIssueId("1000");
    issue.setTitle(replaceOccurences(titleStr.trim()));
    issue.setType(replaceOccurences(typeStr.trim()));
    issue.setTextField4(replaceOccurences(textField4.trim()));
    issue.setFinding(replaceOccurences(finding.trim()));
    issue.setTextField2(replaceOccurences(textField2.trim()));
    issue.setTextField1(replaceOccurences(textField1.trim()));
    issue.setTextField3(replaceOccurences(textField3.trim()));
    issue.setTextField10(replaceOccurences(textField10.trim()));
    issue.setArea(originTitle);
    issue.setUserCat2(appendUserCat2(issuesBuffer, userCat2, issue));
    appendIssueTag(issuesBuffer);
    issuesBuffer.append("<TITLE>"+replaceOccurences(titleStr.trim())+"</TITLE>");
    issuesBuffer.append("<TYPE ID=\"67108931\">"+replaceOccurences(typeStr.trim())+"</TYPE>");
    issuesBuffer.append("<TEXTFIELD4 Format=\"text\">"+replaceOccurences(textField4.trim())+"</TEXTFIELD4>");
    issuesBuffer.append("<FINDING Format=\"text\">"+replaceOccurences(finding.trim())+"</FINDING>");
    issuesBuffer.append("<TEXTFIELD2 Format=\"text\">"+replaceOccurences(textField2.trim())+"</TEXTFIELD2>");
    appendUserCat2(issuesBuffer, userCat2, issue);
    issuesBuffer.append("<TEXTFIELD1 Format=\"text\">"+replaceOccurences(textField1.trim())+"</TEXTFIELD1>");
    issuesBuffer.append("<TEXTFIELD3 Format=\"text\">"+replaceOccurences(textField3.trim())+"</TEXTFIELD3>");
    issuesBuffer.append("<TEXTFIELD10 Format=\"text\">"+replaceOccurences(textField10.trim())+"</TEXTFIELD10>");
    issuesBuffer.append("<ORIGIN><AREA ID=\"-1207959550\">"+originTitle+"</AREA></ORIGIN>");
    issuesBuffer.append("</ISSUE>");
    return issue;
  }

  public String checkForDuplicateDelimiters(String issueChunk, String[] delimiters, int majorIndex, int length) {
    int count = 0;
    int index = 0;
    StringBuffer tempBuffer = new StringBuffer();
    for(int i=0;i<delimiters.length;i++){
      count = 0;
      index = 0;
      while ((index = issueChunk.indexOf(delimiters[i], index)) != -1) {
        ++index;
        ++count;
      }
      if(count > 1){
        tempBuffer.append("Major "+(majorIndex+1)+" of "+length+",\t"+delimiters[i]+"\n");
      }
    }
    if(tempBuffer.length() > 0 ) return tempBuffer.toString();
    return "NONE";
  }

  private static String replaceOccurences(String description) {
    return PatternMatcher.findAndReplace(description);
  }

  private String appendUserCat2(StringBuffer issuesBuffer, String userCat2, Issue issue) {
    String userCat2Desc = replaceOccurences(userCat2.trim());
    issue.setUserCat2(userCat2Desc);
    issuesBuffer.append("<USERCAT2 ID=\""+userCatMap.get(userCat2Desc)+"\">"+userCat2Desc+"</USERCAT2>");
    String id = userCatMap.get(userCat2Desc);
    issue.setUserCat2Id(id);
    return id;
  }

  private void populateUserCatMap() {
    if(userCatMap == null){
      userCatMap = new HashMap<String,String>();
      //FIN
      userCatMap.put("FIN - Compliance with Policy and Laws","1275068482");
      userCatMap.put("FIN-Reconciliation & Review","1275068487");
      userCatMap.put("FIN-Revenue/Receivables","1275068472");
      userCatMap.put("FIN-Approval","1275068422");
      userCatMap.put("FIN-FCPA & Management Practices","1275068456");
      userCatMap.put("FIN-General Ledger","1275068460");
      userCatMap.put("FIN-Classification","1275068480");
      userCatMap.put("FIN-Inventory - Seed","1275068463");
      userCatMap.put("FIN-DOA","67108959");
      userCatMap.put("FIN-Valuation","1275068489");
      userCatMap.put("FIN-Timing","1275068488");
      userCatMap.put("FIN-Procurement","1275068470");
      userCatMap.put("FIN-Segregation of Duties","67108960");
      userCatMap.put("FIN-Contracts","1275068450");
      userCatMap.put("FIN-Comply with Contract","1275068481");
      userCatMap.put("FIN-Inventory","1275068464");
      userCatMap.put("FIN-Other","1275068485");
      userCatMap.put("FIN-Asset Safegurading","1275068510");
      //test
      userCatMap.put("FIN - Approval","1275068422");
      userCatMap.put("FIN - Asset Safeguarding","1275068510");
      userCatMap.put("FIN - Reconciliation and Review","1275068487");




      //IT
      userCatMap.put("IT-Windows Security","1275068478");
      userCatMap.put("IT-Process Control","1275068469");
      userCatMap.put("IT-SAP Security","1275068473");
      userCatMap.put("IT-System Development & Maint.","1275068474");
      userCatMap.put("IT-Database Security - ORACLE","1677721597");
      userCatMap.put("IT-Backup & Recovery","1275068449");
      userCatMap.put("IT-Exchange","1275068458");
      userCatMap.put("IT-Network","1275068466");
      userCatMap.put("IT-Database Security - SQL","-1677721598");
      userCatMap.put("IT-Wireless Networking","1275068479");


//      category = FIN - Timing
//category = IT - Contracts and Miscellaneous
//category = IT - Physical Asset Protection
//category = IT - Windows
//category = FIN - Classification
//category = IT - Backup and Recovery &amp; DRP
//category = FIN - DOA
//category = FIN - Other
//category = FIN - Approval
//category = FIN - Asset Safeguarding
//category = FIN - Valuation
//category = IT - Policies &amp; Standards
//category = IT - Database Controls
//category = IT - Network
//category = FIN - Segregation of Duties
//category = FIN - Compliance with Contract
//category = IT - UNIX  Non-Windows OS
//category = IT - SOD
//category = IT - Management Practices
//category = IT - Data Integrity
//category = IT - Application Security &amp; Controls
//category = FIN - Reconciliation and Review
//category = FIN - Compliance with Policy and Laws

    }

  }

  private void appendIssueTag(StringBuffer issuesBuffer) {
//    issuesBuffer.append("<ISSUE ID=\""+String.valueOf(issueId++)+"\">");
  }

}
