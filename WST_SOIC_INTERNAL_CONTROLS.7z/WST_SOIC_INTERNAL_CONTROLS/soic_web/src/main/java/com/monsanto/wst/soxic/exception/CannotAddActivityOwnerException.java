package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Mar 3, 2009
 * Time: 10:10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CannotAddActivityOwnerException extends Exception {

  public CannotAddActivityOwnerException() {
    super("SubCycle has already been certified.Cannot Add users to activities");
  }
  public CannotAddActivityOwnerException(Exception e) {
      super(e);
    }


}
