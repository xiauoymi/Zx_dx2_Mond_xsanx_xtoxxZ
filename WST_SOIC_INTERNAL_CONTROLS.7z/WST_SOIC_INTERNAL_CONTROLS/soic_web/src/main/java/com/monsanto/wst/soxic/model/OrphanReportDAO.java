package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 9, 2006
 * Time: 1:37:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrphanReportDAO {

    private static final String noOwnerCycles = "SELECT CYCLE_ID " +
            "FROM CYCLE " +
            "WHERE PERIOD_ID = ? " +
            "AND CYCLE_ID NOT IN (SELECT CYCLE_ID FROM OWNER_CYCLE)";

    private static final String noOwnerSubcycles = "SELECT SC.SUB_CYCLE_ID\n" +
            "FROM SUB_CYCLE SC, CYCLE C " +
            "WHERE SC.CYCLE_ID = C.CYCLE_ID " +
            "AND C.PERIOD_ID = ? " +
            "AND SC.SUB_CYCLE_ID NOT IN (SELECT SUB_CYCLE_ID FROM OWNER_SUB_CYCLE)";

    private static final String noOwnerActivity = "SELECT A.ACTIVITY_ID " +
            "  FROM ACTIVITY A, CTRL_OBJ CO, SUB_CYCLE SC, CYCLE C " +
            " WHERE A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
            "   AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
            "   AND SC.CYCLE_ID = C.CYCLE_ID " +
            "   AND C.PERIOD_ID = ? " +
            "   AND A.ACTIVITY_ID NOT IN (SELECT ACTIVITY_ID FROM OWNER_ACTIVITY)";

    private void closeDBConnection(ResultSet rs, PreparedStatement preparedStatement, Connection con) {
        SoxicConnectionFactory.closeResultSet(rs);
        SoxicConnectionFactory.closePreparedStatement(preparedStatement);
        SoxicConnectionFactory.closeSoxicConnection(con);
    }

    public List getNoOwnerCycles(String selperiod) throws Exception {
        List cycles = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(noOwnerCycles);
                preparedStatement.setString(1, selperiod);
                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    addNoOwnerCycleIntoList(rs, cycles);
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(cycles);
        return cycles;
    }

    private void addNoOwnerCycleIntoList(ResultSet rs, List cycleList) throws SQLException {
        String cycleid = rs.getString("CYCLE_ID");
        cycleList.add(cycleid);
    }

    public List getNoOwnerSubCycles(String selperiod) throws Exception {
        List subcycles = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(noOwnerSubcycles);
                preparedStatement.setString(1, selperiod);
                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    addNoOwnerSubCycleIntoList(rs, subcycles);
                }
            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(subcycles);
        return subcycles;
    }

    private void addNoOwnerSubCycleIntoList(ResultSet rs, List subCycles) throws SQLException {
        String subcycleid = rs.getString("SUB_CYCLE_ID");
        subCycles.add(subcycleid);
    }

    public List getNoOwnerActivities(String selperiod) throws Exception {
        List activities = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(noOwnerActivity);
                preparedStatement.setString(1, selperiod);
                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    addNoOwnerActivityIntoList(rs, activities);
                }
            } catch (SQLException e) {
			    e.printStackTrace();
		    } finally {
			try {
                closeDBConnection(rs, preparedStatement, con);
            } catch (Exception e) {
				e.printStackTrace();
			}
		}
        Collections.sort(activities);
        return activities;
    }

    private void addNoOwnerActivityIntoList(ResultSet rs, List activities) throws SQLException {
        String activityid = rs.getString("ACTIVITY_ID");
        activities.add(activityid);
    }
}
