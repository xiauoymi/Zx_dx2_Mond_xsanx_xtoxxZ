package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.exception.OwnerAlreadyExistsException;
import com.monsanto.wst.soxic.exception.NullControlObjectiveException;
import com.monsanto.wst.soxic.exception.DualOwnerDoesNotExistException;
import com.monsanto.wst.soxic.exception.SingleOwnerDoesNotExistException;
import com.monsanto.wst.soxic.form.MaintenanceWizardForm;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.persistance.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.javamail.UserMaintainenceMailComponent;
import org.apache.struts.action.ActionForm;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 16, 2005
 * Time: 9:24:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerMaintainenceFacade implements OwnerMaintainable {

    /**
     * Based on who logs into the system the form variables are set
     * If Admin logs into the system he wll be able to administer Cycle , Sub cycle and Activity owners
     * If Cycle owner logs into the system he will be able to administer Sub cycle and Activity owners
     * If Sub cycle owner logs into the system he will be able to administer Activity owners
     *
     * @param actionForm
     * @param owner
     */
    public void setOwnerLevel(ActionForm actionForm, Owner owner) {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) actionForm;

        maintenanceWizardForm.setSelectedOwnerLevel(null);

        if (owner.isAdmin()) {
            maintenanceWizardForm.setCycleOwner(true);
            maintenanceWizardForm.setSubCycleOwner(true);
            maintenanceWizardForm.setControlObjectiveOwner(true);
            maintenanceWizardForm.setCurrentOwnerLevel(SoxicConstants.ADMIN);
        }

        OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
        List stateList = setValidStateForOwnerChangeProcess();

        if (maintenanceWizardForm.getCurrentOwnerLevel() == null || maintenanceWizardForm.getCurrentOwnerLevel().length() == 0) {
            if (oracleAdminOwnerDAO.isCycleOwner(owner, stateList)) {
                maintenanceWizardForm.setSubCycleOwner(true);
                maintenanceWizardForm.setControlObjectiveOwner(true);
                //if (maintenanceWizardForm.getCurrentOwnerLevel() != null && (maintenanceWizardForm.getCurrentOwnerLevel().length() == 0)) {
                maintenanceWizardForm.setCurrentOwnerLevel(SoxicConstants.CYCLE);
                //}
            }
        }

        if (maintenanceWizardForm.getCurrentOwnerLevel() == null || maintenanceWizardForm.getCurrentOwnerLevel().length() == 0) {
            if (oracleAdminOwnerDAO.isSubCycleOwner(owner, stateList)) {
                maintenanceWizardForm.setControlObjectiveOwner(true);
                //if (maintenanceWizardForm.getCurrentOwnerLevel() != null && (maintenanceWizardForm.getCurrentOwnerLevel().length() == 0)) {
                maintenanceWizardForm.setCurrentOwnerLevel(SoxicConstants.SUBCYCLE);
                //}
            }
        }
    }

    /**
     * Based on what the user selects the following filter criteria are set
     * All the periods except COMPLETE_CERTIFICATION will be populated
     * Based on the period selected and based on the owner the cycles will be populated
     * Based on the period selected ,owner and cylce selected sub cycle will be populated
     *
     * @param form
     * @param owner
     */
    public void setPeriodFilterCriteria(ActionForm form, Owner owner) throws OwnerAlreadyExistsException {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        List stateList = setValidStateForOwnerChangeProcess();
        setOverAllSubCycleList(maintenanceWizardForm, owner, stateList);


        clearPeriod(maintenanceWizardForm);
        setPeriods(maintenanceWizardForm);
        clearCountries(maintenanceWizardForm);
        clearCycles(maintenanceWizardForm);
        clearSubCycles(maintenanceWizardForm);

    }

    /**
     * Set sub cycle list based on the owner level you want to add
     *
     * @param maintenanceWizardForm
     * @param owner
     * @param stateList
     * @throws OwnerAlreadyExistsException
     */
    private void setOverAllSubCycleList(MaintenanceWizardForm maintenanceWizardForm, Owner owner, List stateList) throws OwnerAlreadyExistsException {
        if (maintenanceWizardForm.getSelectedOwnerLevel().equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {
            processControlObjectiveLevel(maintenanceWizardForm, owner);
        } else {
            processCycleAndSubCycleModel(maintenanceWizardForm, owner, stateList);

        }
    }

    /**
     * based on user who logs in get the list of sub cycles for which user can be administered
     *
     * @param maintenanceWizardForm
     * @param owner
     */
    private void processControlObjectiveLevel(MaintenanceWizardForm maintenanceWizardForm, Owner owner) {
        List stateList = setValidStateForOwnerChangeProcess();
        OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
        String selectedAction = maintenanceWizardForm.getSelectedAction();
        String strChosenOwner = null;

        //determine the source Owner of the control objectives
        //this is not necessary for the ADD operation
        if (selectedAction.equalsIgnoreCase(SoxicConstants.COPY_OWNER) ||
                selectedAction.equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
            strChosenOwner = maintenanceWizardForm.getSourceOwner();
        } else if (selectedAction.equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            strChosenOwner = maintenanceWizardForm.getSelectedAvailableOwner();
        }


        maintenanceWizardForm.setOverAllSubCycleList(oracleAdminOwnerDAO.getListToShow(maintenanceWizardForm.getCurrentOwnerLevel(), owner.getOwnerId(), "", stateList, maintenanceWizardForm.getSelectedAction(), strChosenOwner));
    }

    /**
     * States during which owners can be changed
     *
     * @return
     */
    private List setValidStateForOwnerChangeProcess() {
        UserMaintainenceUtilDAO userMaintainenceUtilDAO = new UserMaintainenceUtilDAO();
        return userMaintainenceUtilDAO.selectUserMaintainenceStates();
        //return stateList;
    }

    /**
     * Set owner details
     *
     * @param maintenanceWizardForm
     */
    public void setOwnerDetails(MaintenanceWizardForm maintenanceWizardForm) throws DualOwnerDoesNotExistException, SingleOwnerDoesNotExistException {
        OwnerDAO ownerDAO = new OwnerDAO();
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER) || maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
            Owner sourceOwner = new Owner();
            sourceOwner.setOwnerId(maintenanceWizardForm.getSourceOwner());
            Owner destinationOwner = new Owner();
            destinationOwner.setOwnerId(maintenanceWizardForm.getDestinationOwner());
            ownerDAO.select(sourceOwner);
            if (sourceOwner.getName() == null || sourceOwner.getName().trim().length() == 0) {
                throw new DualOwnerDoesNotExistException(sourceOwner.getOwnerId() + " does not exist in the system.");
            }

            ownerDAO.select(destinationOwner);
            if (destinationOwner.getName() == null || sourceOwner.getName().trim().length() == 0) {
                throw new DualOwnerDoesNotExistException(destinationOwner.getOwnerId() + " does not exist in the system.");
            }

            maintenanceWizardForm.setSourceOwnerEmail(sourceOwner.getEmail());
            maintenanceWizardForm.setSourceOwnerName(sourceOwner.getName());
            maintenanceWizardForm.setDestinationOwnerEmail(destinationOwner.getEmail());
            maintenanceWizardForm.setDestinationOwnerName(destinationOwner.getName());
        }

        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            Owner sourceOwner = new Owner();
            sourceOwner.setOwnerId(maintenanceWizardForm.getSelectedAvailableOwner());
            ownerDAO.select(sourceOwner);

            if (sourceOwner.getName() == null || sourceOwner.getName().trim().length() == 0) {
                throw new SingleOwnerDoesNotExistException(sourceOwner.getOwnerId() + " does not exist in the system.");
            }

            maintenanceWizardForm.setSelectedAvailableOwnerEmail(sourceOwner.getEmail());
            maintenanceWizardForm.setSelectedAvailableOwnerName(sourceOwner.getName());
        }


    }

    public void setCountryFilterCriteria(ActionForm form, Owner owner) {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        clearCountries(maintenanceWizardForm);
        setCountries(maintenanceWizardForm);
        clearCycles(maintenanceWizardForm);
        clearSubCycles(maintenanceWizardForm);


    }

    public void setCycleFilterCriteria(ActionForm form, Owner owner) {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        clearCycles(maintenanceWizardForm);
        setCycles(maintenanceWizardForm);
        clearSubCycles(maintenanceWizardForm);

    }

    public void setSubCycleFilterCriteria(ActionForm form, Owner owner) {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        clearSubCycles(maintenanceWizardForm);
        setSubCycles(maintenanceWizardForm);

    }

    /**
     * Based on Period , cycle and sub cycle control objectives are populated
     *
     * @param form
     * @param owner
     */
    public void populateControlObjectives(ActionForm form, Owner owner) throws NullControlObjectiveException {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        processControlObjectiveAndActivityModel(maintenanceWizardForm, maintenanceWizardForm.getSelectedAction(), maintenanceWizardForm.getSelectedSubCycle(), maintenanceWizardForm.getSourceOwner(), maintenanceWizardForm.getDestinationOwner());

    }

    /**
     * Based on control objective the activities are populated
     *
     * @param form
     * @param owner
     */
    public void populateActivities(ActionForm form, Owner owner) {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        populateControlActivityList(maintenanceWizardForm);
    }

    private void setPeriods(MaintenanceWizardForm maintenanceWizardForm) {
        List periodList = new ArrayList();
        Iterator iterator = maintenanceWizardForm.getOverAllSubCycleList().iterator();
        Set set = new HashSet();
        StringTokenizer st = null;
        periodList.add(SoxicConstants.SELECT_PERIOD);
        while (iterator.hasNext()) {
            st = new StringTokenizer((String) iterator.next(), ".");

            String token = st.nextToken();
            if (set.add(token)) {
                periodList.add(token);
            }
        }
        maintenanceWizardForm.setPeriods(periodList);
    }

    private void clearPeriod(MaintenanceWizardForm maintenanceWizardForm) {
        maintenanceWizardForm.setPeriods(null);
        maintenanceWizardForm.setSelectedPeriod("Select Period");

    }

    private void setCycles(MaintenanceWizardForm maintenanceWizardForm) {
        List periodList = new ArrayList();
        periodList.add(SoxicConstants.SELECT_CYCLE);

        Set set = new HashSet();
        Iterator iterator = maintenanceWizardForm.getOverAllSubCycleList().iterator();
        StringTokenizer stringTokenizer = null;
        while (iterator.hasNext()) {
            String currentSubCycle = (String) iterator.next();
            int index = currentSubCycle.indexOf(maintenanceWizardForm.getSelectedCountry() + ".");
            if (index >= 0) {
                stringTokenizer = new StringTokenizer(currentSubCycle, ".");
                String periodId = stringTokenizer.nextToken();
                String country = stringTokenizer.nextToken();
                String cycle = stringTokenizer.nextToken();
                String cycleId = periodId + "." + country + "." + cycle;

                if (set.add(cycleId)) {
                    periodList.add(cycleId);
                }

            }
        }
        maintenanceWizardForm.setCycles(periodList);
    }

    private void clearCycles(MaintenanceWizardForm maintenanceWizardForm) {
        maintenanceWizardForm.setCycles(null);
        maintenanceWizardForm.setSelectedCycle("Select Cycle");
    }

    private void setSubCycles(MaintenanceWizardForm maintenanceWizardForm) {
        List periodList = new ArrayList();
        periodList.add(SoxicConstants.SELECT_SUB_CYCLE);
        Set set = new HashSet();
        Iterator iterator = maintenanceWizardForm.getOverAllSubCycleList().iterator();
        StringTokenizer stringTokenizer = null;
        while (iterator.hasNext()) {
            String currentSubCycle = (String) iterator.next();
            int index = currentSubCycle.indexOf(maintenanceWizardForm.getSelectedCycle() + ".");
            if (index >= 0) {
                stringTokenizer = new StringTokenizer(currentSubCycle, ".");
                String periodId = stringTokenizer.nextToken();
                String country = stringTokenizer.nextToken();
                String cycle = stringTokenizer.nextToken();
                String subCycle = stringTokenizer.nextToken();
                String subCycleId = periodId + "." + country + "." + cycle + "." + subCycle;

                if (set.add(subCycleId)) {
                    periodList.add(subCycleId);
                }

            }
        }
        maintenanceWizardForm.setSubCycles(periodList);
    }

    private void clearSubCycles(MaintenanceWizardForm maintenanceWizardForm) {
        maintenanceWizardForm.setSubCycles(null);
        maintenanceWizardForm.setSelectedSubCycle(SoxicConstants.SELECT_SUB_CYCLE);
    }

    private void setCountries(MaintenanceWizardForm maintenanceWizardForm) {
        List periodList = new ArrayList();
        Set set = new HashSet();
        periodList.add(SoxicConstants.SELECT_COUNTRY);
        Iterator iterator = maintenanceWizardForm.getOverAllSubCycleList().iterator();
        StringTokenizer stringTokenizer = null;
        while (iterator.hasNext()) {
            String currentSubCycle = (String) iterator.next();
            int index = currentSubCycle.indexOf(maintenanceWizardForm.getSelectedPeriod() + ".");
            if (index >= 0) {
                stringTokenizer = new StringTokenizer(currentSubCycle, ".");
                String periodId = stringTokenizer.nextToken();
                String country = stringTokenizer.nextToken();
                String countryId = periodId + "." + country;

                if (set.add(countryId)) {
                    periodList.add(countryId);
                }

            }
        }
        maintenanceWizardForm.setCountries(periodList);
    }

    private void clearCountries(MaintenanceWizardForm maintenanceWizardForm) {

        maintenanceWizardForm.setCountries(null);
        maintenanceWizardForm.setSelectedCountry(SoxicConstants.SELECT_COUNTRY);
    }

    /**
     * Get and modify the control objectives and activities based on user operation
     *
     * @param maintenanceWizardForm
     * @param mode
     * @param subCycleId
     * @param oldOwner
     * @param newOwner
     */
    public void processControlObjectiveAndActivityModel(MaintenanceWizardForm maintenanceWizardForm, String mode, String subCycleId, String oldOwner, String newOwner) throws NullControlObjectiveException {
        Collection controlObjectiveList = getControlObjectivesForSubCycle(subCycleId);
        modifyControlObjectiveAndActivityModel(controlObjectiveList, newOwner, oldOwner, maintenanceWizardForm);

    }

    /**
     * based on user operation populate the activities and control objectives
     *
     * @param controlObjectiveList
     * @param newOwner
     * @param oldOwner
     * @param maintenanceWizardForm
     */
    private void modifyControlObjectiveAndActivityModel(Collection controlObjectiveList, String newOwner, String oldOwner, MaintenanceWizardForm maintenanceWizardForm) throws NullControlObjectiveException {
        Collection controlListToShow = new ArrayList();
        List activityList = new ArrayList();
        //String mode = maintenanceWizardForm.getSelectedAction();
        setControlObjectiveDataForAddMode(controlObjectiveList, controlListToShow, activityList, newOwner, maintenanceWizardForm);

        setControlObjectivesForRemoveMode(controlObjectiveList, controlListToShow, activityList, newOwner, maintenanceWizardForm);
        setControlObjectivesForChangeMode(controlObjectiveList, controlListToShow, activityList, oldOwner, newOwner, maintenanceWizardForm);
        setControlObjectivesForCopyMode(controlObjectiveList, controlListToShow, activityList, oldOwner, newOwner, maintenanceWizardForm);
        if (controlListToShow.size() == 0) {
            throw new NullControlObjectiveException();
        }
        maintenanceWizardForm.setControlObjectives((List) controlListToShow);
        maintenanceWizardForm.setOverAllActivitiyList(activityList);
    }

    public void populateControlActivityList(MaintenanceWizardForm maintenanceWizardForm) {
        String arr[] = maintenanceWizardForm.getSelectedControlObjectives();

        List displayActList = new ArrayList();
        StringTokenizer stringTokenizer = null;
        String activityId;

        for (int i = 0; i < arr.length; i++) {
            String contlObj = arr[i];
            List actList = maintenanceWizardForm.getOverAllActivitiyList();
            Iterator iterator = actList.iterator();
            while (iterator.hasNext()) {
                activityId = (String) iterator.next();
                stringTokenizer = new StringTokenizer(activityId, ".");
                String periodId = stringTokenizer.nextToken();
                String country = stringTokenizer.nextToken();
                String cycle = stringTokenizer.nextToken();
                String subCycle = stringTokenizer.nextToken();
                String controlObjective = stringTokenizer.nextToken();
                String ctrlId = periodId + "." + country + "." + cycle + "." + subCycle + "." + controlObjective;
                if (contlObj.equalsIgnoreCase(ctrlId)) {
                    displayActList.add(activityId);
                }
            }

        }
        maintenanceWizardForm.setControlActivities(displayActList);

    }

    /**
     * Add control obejectives and activities to show for add mode
     *
     * @param controlObjectiveList
     * @param ctlList
     * @param activityList
     * @param newOwner
     * @param maintenanceWizardForm
     */
    private void setControlObjectiveDataForAddMode(Collection controlObjectiveList, Collection ctlList, List activityList, String newOwner, MaintenanceWizardForm maintenanceWizardForm) {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
            try {
                Iterator iterator = controlObjectiveList.iterator();
                while (iterator.hasNext()) {
                    ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
                    ctlList.add(controlObjectiveNew.getControlObjectiveId());

                    Iterator activityIterator = controlObjectiveNew.getActivities().iterator();

                    while (activityIterator.hasNext()) {
                        ActivityNew activityNew = (ActivityNew) activityIterator.next();
                        activityList.add(activityNew.getActivityId());

                    }
                }
            } catch (Exception e) {

            }
        }
    }

    /**
     * Add control objectives and activities to show for remove mode
     * @param controlObjectiveList
     * @param ctlList
     * @param activityList
     * @param oldOwner
     * @param maintenanceWizardForm
     */
//    protected void setControlObjectivesForRemoveMode(Collection controlObjectiveList, Collection ctlList, List activityList, String oldOwner, MaintenanceWizardForm maintenanceWizardForm){
//        if(maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)){
//            Set activitySet = new HashSet();
//            Set controlObjectiveSet = new HashSet();
//
//                Iterator iterator = controlObjectiveList.iterator();
//                while(iterator.hasNext()){
//                    ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew)iterator.next();
//                    Iterator activityIterator =controlObjectiveNew.getActivities().iterator();
//                    while(activityIterator.hasNext()){
//                        ActivityNew activityNew = (ActivityNew)activityIterator.next();
//                        String id = activityNew.getActivityId();
//                        if(!activitySet.add(id)){
//                            activityList.add(id);
//                            if(controlObjectiveSet.add(controlObjectiveNew.getControlObjectiveId())){
//                                ctlList.add(controlObjectiveNew.getControlObjectiveId());
//                            }
//
//                        }
//                    }
//                }
//        }
//    }

    /**
     * Sets control objectives and activities for remove mode.
     *
     * @param controlObjectiveList
     * @param ctlList
     * @param activityList
     * @param oldOwner
     * @param maintenanceWizardForm
     */
    protected void setControlObjectivesForRemoveMode(Collection controlObjectiveList, Collection ctlList, List activityList, String oldOwner, MaintenanceWizardForm maintenanceWizardForm) {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            Set activitySet = new HashSet();
            Set controlObjectiveSet = new HashSet();
            Set multipleOwnerSet = new HashSet();

            Iterator iterator = controlObjectiveList.iterator();
            while (iterator.hasNext()) {
                ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
                multipleOwnerSet.clear();
                multipleOwnerSet = getModelWithMultipleOwners((List) controlObjectiveNew.getActivities());
                setActivitesThatCanBeDeleted(multipleOwnerSet, activitySet, activityList, controlObjectiveSet, controlObjectiveNew, ctlList, maintenanceWizardForm);
            }
            //removeOtherOwnerActivities(activityList,controlObjectiveList);
        }
    }

    private ActivityNew getActivityWithId(ControlObjectiveNew controlObjectiveNew, String activityId, String ownerid) {
//        List tempList = new ArrayList();
//            Iterator iterator = controlObjectiveList.iterator();
//            while (iterator.hasNext()) {
        //ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
        Iterator activityIterator = controlObjectiveNew.getActivities().iterator();
        while (activityIterator.hasNext()) {
            ActivityNew activityNew = (ActivityNew) activityIterator.next();
            if (activityNew.getActivityId().equalsIgnoreCase(activityId) && activityNew.getOwnerId().equalsIgnoreCase(ownerid)) {
                return activityNew;
            }
        }

        //           }
        return null;
    }

    /**
     * @param multipleOwnerSet
     * @param activitySet
     * @param activityList
     * @param controlObjectiveSet
     * @param controlObjectiveNew
     * @param ctlList
     * @param maintenanceWizardForm
     */
    private void setActivitesThatCanBeDeleted(Set multipleOwnerSet, Set activitySet, List activityList, Set controlObjectiveSet, ControlObjectiveNew controlObjectiveNew, Collection ctlList, MaintenanceWizardForm maintenanceWizardForm) {
        Iterator activityIterator = multipleOwnerSet.iterator();
        while (activityIterator.hasNext()) {

            String id = (String) activityIterator.next();
            ActivityNew activityNew = getActivityWithId(controlObjectiveNew, id, maintenanceWizardForm.getSelectedAvailableOwner());
            if (activityNew != null) {
                if (activitySet.add(id)) {
                    activityList.add(id);
                    if (controlObjectiveSet.add(controlObjectiveNew.getControlObjectiveId())) {
                        ctlList.add(controlObjectiveNew.getControlObjectiveId());
                    }
                }
            }

        }
    }

    private void setControlObjectivesForCopyMode(Collection controlObjectiveList, Collection ctlList, List activityList, String oldOwner, String newOwner, MaintenanceWizardForm maintenanceWizardForm) {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
            setControlObjectivesForCopyChangeMode(controlObjectiveList, oldOwner, newOwner, activityList, ctlList);
        }
    }

    protected void setControlObjectivesForChangeMode(Collection controlObjectiveList, Collection ctlList, List activityList, String oldOwner, String newOwner, MaintenanceWizardForm maintenanceWizardForm) {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
            setControlObjectivesForCopyChangeMode(controlObjectiveList, oldOwner, newOwner, activityList, ctlList);
        }
    }

    private void setControlObjectivesForCopyChangeMode(Collection controlObjectiveList, String oldOwner, String newOwner, List activityList, Collection ctlList) {
        List newOwnerActivitylist = new ArrayList();
        List oldOwnerActivityList = new ArrayList();
        List oldControlObjectiveList = new ArrayList();
        List newControlObjectiveList = new ArrayList();
        try {
            Iterator iterator = controlObjectiveList.iterator();
            while (iterator.hasNext()) {
                ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
                Iterator activityIterator = controlObjectiveNew.getActivities().iterator();

                while (activityIterator.hasNext()) {
                    ActivityNew activityNew = (ActivityNew) activityIterator.next();
                    String ownerId = activityNew.getOwnerId();
                    if (ownerId.equalsIgnoreCase(oldOwner)) {
                        oldOwnerActivityList.add(activityNew.getActivityId());
                        oldControlObjectiveList.add(controlObjectiveNew.getControlObjectiveId());
                    }
                    if (ownerId.equalsIgnoreCase(newOwner)) {
                        newOwnerActivitylist.add(activityNew.getActivityId());
                        newControlObjectiveList.add(controlObjectiveNew.getControlObjectiveId());
                    }
                }
                oldOwnerActivityList.removeAll(newOwnerActivitylist);
            }

        } catch (Exception e) {

        }
        oldControlObjectiveList.removeAll(newControlObjectiveList);
        activityList.addAll(oldOwnerActivityList);
        populateCtlListForChangeMode(controlObjectiveList, ctlList, activityList);
    }

    private void populateCtlListForChangeMode(Collection controlObjectiveList, Collection ctlList, List activityList) {
        Set hashSet = new HashSet();
        Iterator iterator = controlObjectiveList.iterator();
        while (iterator.hasNext()) {
            ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
            Iterator activityIterator = controlObjectiveNew.getActivities().iterator();
            while (activityIterator.hasNext()) {
                Iterator modifiedActivityListIterator = activityList.iterator();
                ActivityNew activityNew = (ActivityNew) activityIterator.next();
                while (modifiedActivityListIterator.hasNext()) {
                    String modifiedActivityId = (String) modifiedActivityListIterator.next();
                    String currentActivityId = activityNew.getActivityId();
                    if (modifiedActivityId.equalsIgnoreCase(currentActivityId)) {
                        if (hashSet.add(controlObjectiveNew.getControlObjectiveId())) {
                            ctlList.add(controlObjectiveNew.getControlObjectiveId());
                        }

                    }
                }
            }
        }
    }

    /**
     * get the list of control objectives for current sub cycle id
     *
     * @param subCycleId
     * @return
     */
    protected Collection getControlObjectivesForSubCycle(String subCycleId) {
        Collection controlObjectiveModelList = null;
        try {
            OracleSubCycleDAO subCycleDAO = (OracleSubCycleDAO) AbstractDAOFactory.getFactory().getSubCycleDAO();
            controlObjectiveModelList = subCycleDAO.getControlObjectives(subCycleId);
        } catch (Exception e) {

        }
        return controlObjectiveModelList;
    }

    /**
     * @param maintenanceWizardForm
     */
    public void process(MaintenanceWizardForm maintenanceWizardForm) throws Exception{
        AdminOwner adminOwner = new AdminOwner();
        List cycles = new ArrayList();
        List subCycles = new ArrayList();
        List changes = null;
        try {
            if (maintenanceWizardForm.getSelectedOwnerLevel().equalsIgnoreCase(SoxicConstants.CYCLE)) {
                cycles.add(maintenanceWizardForm.getSelectedCycle());
            }
            if (maintenanceWizardForm.getSelectedOwnerLevel().equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
                subCycles.add(maintenanceWizardForm.getSelectedSubCycle());
            }

            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER) || maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
                changes = adminOwner.getPreviewChanges(cycles, subCycles, maintenanceWizardForm.getStoredControlActivitiesforProcessing(), maintenanceWizardForm.getSourceOwner());
                sendAdminOnwerEmail(maintenanceWizardForm, cycles, subCycles, getActivityList(maintenanceWizardForm.getSelectedControlActivities()));
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
                changes = adminOwner.getPreviewChangesNewUser(cycles, subCycles, maintenanceWizardForm.getStoredControlActivitiesforProcessing());
                sendAdminOnwerEmail(maintenanceWizardForm, cycles, subCycles, getActivityList(maintenanceWizardForm.getSelectedControlActivities()));
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
                changes = adminOwner.getPreviewChanges(cycles, subCycles, maintenanceWizardForm.getStoredControlActivitiesforProcessing(), maintenanceWizardForm.getSelectedAvailableOwner());
                sendAdminOnwerEmail(maintenanceWizardForm, cycles, subCycles, getActivityList(maintenanceWizardForm.getSelectedControlActivities()));
            }
            //-----
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
                adminOwner.deleteOwner(changes);

            }

            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
                adminOwner.copyOwner(setOwnerInChangesToCopy(changes, maintenanceWizardForm.getDestinationOwner()), maintenanceWizardForm.getDestinationOwner(), "1000");
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
                adminOwner.copyOwner(setOwnerInChangesToCopy(changes, maintenanceWizardForm.getSelectedAvailableOwner()), maintenanceWizardForm.getSelectedAvailableOwner(), "1000");
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
                adminOwner.changeOwner(changes, maintenanceWizardForm.getDestinationOwner(), "1000");
            }

        } catch (Exception e) {
              throw e;
        }
    }

    private List getActivityList(String act[]) {
        if (act != null) {
            List activityList = new ArrayList();
            for (int i = 0; i < act.length; i++) {
                activityList.add(act[i]);
            }
            return activityList;
        }
        return null;
    }

    private List setOwnerInChangesToCopy(List changes, String newUser) {

        Iterator itr = changes.iterator();

        while (itr.hasNext()) {

            ((AdminOwnerEntity) itr.next()).setOwnerId(newUser);
        }

        return changes;
    }

    /**
     * get all cycles and sub cycles that can be modified and preform necessary oprations on them
     *
     * @param maintenanceWizardForm
     * @throws OwnerAlreadyExistsException
     */
    private void processCycleAndSubCycleModel(MaintenanceWizardForm maintenanceWizardForm, Owner owner, List stateList) throws OwnerAlreadyExistsException {


        List modelList = getCycleAndSubCycleModelList(maintenanceWizardForm, owner.getOwnerId(), stateList);
        modifyCycleAndSubCycleListForOperation(maintenanceWizardForm, modelList);

    }

    /**
     * get list of cycle and sub cycles for which owners can be administered
     *
     * @param maintenanceWizardForm
     * @return
     */
    private List getCycleAndSubCycleModelList(MaintenanceWizardForm maintenanceWizardForm, String strUserId, List stateList) {

        OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
        List modelList = null;

        String userType = maintenanceWizardForm.getCurrentOwnerLevel();

        if (maintenanceWizardForm.getSelectedOwnerLevel().equalsIgnoreCase(SoxicConstants.CYCLE)) {
            if (userType.equalsIgnoreCase(SoxicConstants.ADMIN)) {
                //Select all  cycles
                modelList = oracleAdminOwnerDAO.getCyclesInPeriodforAdmin(stateList);
            }
            if (userType.equalsIgnoreCase(SoxicConstants.CYCLE)) {
                //Select all cycles for which the user is a cycle owner
                modelList = oracleAdminOwnerDAO.getCyclesInPeriodforCycleOwner(stateList, strUserId);
            }
            if (userType.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
                //Select all sub cycles for which person is a sub cycle owner and that are owned by strItemOwnerId
                modelList = oracleAdminOwnerDAO.getCyclesInPeriodforSubCycleOwner(stateList, strUserId);
            }
        } else {

            if (userType.equalsIgnoreCase(SoxicConstants.ADMIN)) {
                //Select all  Subcycles
                modelList = oracleAdminOwnerDAO.getSubCyclesInPeriodforAdmin(stateList);
            }
            if (userType.equalsIgnoreCase(SoxicConstants.CYCLE)) {
                //Select all Subcycles for which the user is a cycle owner
                modelList = oracleAdminOwnerDAO.getSubCyclesInPeriodforCycleOwner(stateList, strUserId);
            }
            if (userType.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
                //Select all Sub cycles for which person is a sub cycle owner
                modelList = oracleAdminOwnerDAO.getSubCyclesInPeriodforSubCycleOwner(stateList, strUserId);
            }

        }

        return modelList;
    }

    /**
     * Based on user operation and users to administer modify (remove etc ) the model list
     *
     * @param maintenanceWizardForm
     * @param modelList
     * @throws OwnerAlreadyExistsException
     */
    private void modifyCycleAndSubCycleListForOperation(MaintenanceWizardForm maintenanceWizardForm, List modelList) throws OwnerAlreadyExistsException {
        List tempList = new ArrayList();
        processAddModel(maintenanceWizardForm, modelList, tempList);
        processRemoveModel(maintenanceWizardForm, modelList, tempList);
        processModifyModel(maintenanceWizardForm, modelList, tempList);
        maintenanceWizardForm.setOverAllSubCycleList(tempList);
    }

    /**
     * Get a list of all models owned by the destination owner but not owned by the new owner
     *
     * @param maintenanceWizardForm
     * @param modelList
     * @param tempList
     */
    private void processModifyModel(MaintenanceWizardForm maintenanceWizardForm, List modelList, List tempList) {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER) || maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
            Iterator iterator = modelList.iterator();
            List newOwnerList = new ArrayList();
            List oldOwnerList = new ArrayList();
            while (iterator.hasNext()) {
                SoxicBaseModel model = (SoxicBaseModel) iterator.next();
                if (model.getOwnerId().equalsIgnoreCase(maintenanceWizardForm.getDestinationOwner())) {
                    newOwnerList.add(model.getId());
                }
                if (model.getOwnerId().equalsIgnoreCase(maintenanceWizardForm.getSourceOwner())) {
                    oldOwnerList.add(model.getId());
                }

            }
            oldOwnerList.removeAll(newOwnerList);
            tempList.addAll(oldOwnerList);
        }
    }

    /**
     * If the owner is the last owner(or only owner) remove it from the list of cycle or sub cycles shown to the user
     *
     * @param maintenanceWizardForm
     * @param modelList
     * @param tempList
     */
    private void processRemoveModel(MaintenanceWizardForm maintenanceWizardForm, List modelList, List tempList) {
        Set multipleOwnerModelSet = null;
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            multipleOwnerModelSet = getModelWithMultipleOwners(modelList);
            tempList.addAll(getDeleteModelForOwner(modelList, multipleOwnerModelSet, maintenanceWizardForm));
            //maintenanceWizardForm.set
        }
    }

    /**
     * Get the list of model(cycle or sub cycle) for particular owner
     *
     * @param modelList
     * @param multipleOwnerModelSet
     * @param maintenanceWizardForm
     */
    private List getDeleteModelForOwner(List modelList, Set multipleOwnerModelSet, MaintenanceWizardForm maintenanceWizardForm) {
        List deletableModelList = new ArrayList();
        Iterator iterator;
        iterator = modelList.iterator();
        while (iterator.hasNext()) {
            SoxicBaseModel cycle = (SoxicBaseModel) iterator.next();
            if (multipleOwnerModelSet.contains(cycle.getId())) {
                if (maintenanceWizardForm.getSelectedAvailableOwner().equalsIgnoreCase(cycle.getOwnerId())) {

                    deletableModelList.add(cycle.getId());
                }
            }
        }

        return deletableModelList;
    }


    /**
     * Get a set containing cycles or sub cycles having multiple owners
     *
     * @param modelList model list is a cycle or sub cycle list
     * @return
     */
    private Set getModelWithMultipleOwners(List modelList) {
        Set hashSet = new HashSet();
        Set multipleOwnerModelSet = new HashSet();
        Iterator iterator = modelList.iterator();
        while (iterator.hasNext()) {
            SoxicBaseModel model = (SoxicBaseModel) iterator.next();
            if (!hashSet.add(model.getId())) {
                multipleOwnerModelSet.add(model.getId());
            }
        }
        return multipleOwnerModelSet;
    }


    /**
     * If owner is already present at that level throw an exception else add list of cycles or sub cyles to which he can be added to
     *
     * @param maintenanceWizardForm
     * @param modelList
     * @param tempList
     * @throws OwnerAlreadyExistsException
     */
    private void processAddModel(MaintenanceWizardForm maintenanceWizardForm, List modelList, List tempList) throws OwnerAlreadyExistsException {
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
            Iterator iterator = modelList.iterator();
            while (iterator.hasNext()) {
                SoxicBaseModel model = (SoxicBaseModel) iterator.next();
                if (model.getOwnerId().equalsIgnoreCase(maintenanceWizardForm.getSelectedAvailableOwner())) {
                    throw new OwnerAlreadyExistsException();
                } else {
                    tempList.add(model.getId());
                }
            }
        }
    }

    public void sendAdminOnwerEmail(MaintenanceWizardForm maintenanceWizardForm, List cycles, List subCycles, List activities) {
        try {
            EmailWrapper wrapper = null;
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
                UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_ADD, getWrapperForAddMode(maintenanceWizardForm, cycles, subCycles, activities));
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
                //UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_REMOVE,wrapper);
                UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_REMOVE, getWrapperForRemoveMode(maintenanceWizardForm, cycles, subCycles, activities));
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
                UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_ADD, getWrapperForAddMode(maintenanceWizardForm, cycles, subCycles, activities));
                UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_REMOVE, getWrapperForRemoveMode(maintenanceWizardForm, cycles, subCycles, activities));
            }
            if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
                UserMaintainenceMailComponent.userMaintainEmail(UserMaintainenceMailComponent.USER_MAINTAIN_ADD, getWrapperForAddMode(maintenanceWizardForm, cycles, subCycles, activities));
            }
        } catch (Exception e) {

        }
    }

    private EmailWrapper getWrapperForAddMode(MaintenanceWizardForm maintenanceWizardForm, List cycles, List subCycles, List activities) {
        EmailWrapper wrapper = new EmailWrapper();
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
            wrapper.setEmailAddress(maintenanceWizardForm.getSelectedAvailableOwnerEmail());
            //wrapper.setEmailAddress("CCARTE1@MONSANTO.COM");
            //wrapper.setEmailAddress("VRBETHI@MONSANTO.COM");
        }
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
            wrapper.setEmailAddress(maintenanceWizardForm.getDestinationOwnerEmail());
            //wrapper.setEmailAddress("CCARTE1@MONSANTO.COM");
            //wrapper.setEmailAddress("VRBETHI@MONSANTO.COM");
        }
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
            wrapper.setEmailAddress(maintenanceWizardForm.getDestinationOwnerEmail());
            //wrapper.setEmailAddress("CCARTE1@MONSANTO.COM");
            //wrapper.setEmailAddress("VRBETHI@MONSANTO.COM");
        }
        wrapper.setAdminModelList(cycles, subCycles, activities);
        return wrapper;
    }

    private EmailWrapper getWrapperForRemoveMode(MaintenanceWizardForm maintenanceWizardForm, List cycles, List subCycles, List activities) {
        EmailWrapper wrapper = new EmailWrapper();
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            wrapper.setEmailAddress(maintenanceWizardForm.getSelectedAvailableOwnerEmail());
            //wrapper.setEmailAddress("CCARTE1@MONSANTO.COM");
            //wrapper.setEmailAddress("VRBETHI@MONSANTO.COM");
        }
        if (maintenanceWizardForm.getSelectedAction().equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
            wrapper.setEmailAddress(maintenanceWizardForm.getSourceOwnerEmail());
            //wrapper.setEmailAddress("CCARTE1@MONSANTO.COM");
            //wrapper.setEmailAddress("VRBETHI@MONSANTO.COM");
        }
        wrapper.setAdminModelList(cycles, subCycles, activities);
        return wrapper;
    }

}
