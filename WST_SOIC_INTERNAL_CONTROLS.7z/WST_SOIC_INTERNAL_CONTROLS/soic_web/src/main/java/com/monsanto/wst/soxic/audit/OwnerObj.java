package com.monsanto.wst.soxic.audit;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 10:00:47 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@Table(schema = "SARBOX_ET",name = "OWNER")
public class OwnerObj {

  @Id
  @Column(name = "OWNER_ID")
  private String ownerId;

  @Column(name="EMAIL")
  private String email;

  @Column(name="NAME")
  private String name;

  @Column(name="LOCATION")
  private String location;

  @Column(name = "LAST_LOGIN")
  private Date lastLogin;

  @Column(name="MOD_DATE")
  private Date modDate;

  @Column(name="MOD_USER")
  private String modUser;

  @OneToMany(mappedBy = "ownerId",fetch = FetchType.LAZY)
  private List<OwnerSubCycleObj> ownerSubCycleList = new ArrayList<OwnerSubCycleObj>();

  @OneToMany(mappedBy = "ownerId",fetch = FetchType.LAZY)
  private List<OwnerActivityObj> ownerActivityList = new ArrayList<OwnerActivityObj>();

  @OneToMany(mappedBy = "ownerId",fetch = FetchType.LAZY)
  private List<OwnerCycleObj> ownerCycleList = new ArrayList<OwnerCycleObj>();

//  @ManyToOne
//  @JoinColumn(name = "OWNER_ID",insertable = false,updatable = false)
//  private CycleTest cycle;
//  
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public Date getLastLogin() {
    return lastLogin;
  }

  public void setLastLogin(Date lastLogin) {
    this.lastLogin = lastLogin;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public List<OwnerSubCycleObj> getOwnerSubCycleList() {
    return ownerSubCycleList;
  }

  public void setOwnerSubCycleList(List<OwnerSubCycleObj> ownerSubCycleList) {
    this.ownerSubCycleList = ownerSubCycleList;
  }

  public String getOwnerId() {
    return ownerId;
  }

  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }

  public List<OwnerActivityObj> getOwnerActivityList() {
    return ownerActivityList;
  }

  public void setOwnerActivityList(List<OwnerActivityObj> ownerActivityList) {
    this.ownerActivityList = ownerActivityList;
  }

 

  public List<OwnerCycleObj> getOwnerCycleList() {
    return ownerCycleList;
  }

  public void setOwnerCycleList(List<OwnerCycleObj> ownerCycleList) {
    this.ownerCycleList = ownerCycleList;
  }

//  public CycleTest getCycle() {
//    return cycle;
//  }
//
//  public void setCycle(CycleTest cycle) {
//    this.cycle = cycle;
//  }
}

