//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ReportOptionsForm;
import com.monsanto.wst.soxic.form.SubcycleReportForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/** 
 * MyEclipse Struts
 * Creation date: 02-25-2005
 * 
 * XDoclet definition:
 * @struts:action path="/subcycleReport" name="subcycleReportForm" scope="request" validate="true"
 */
public class SubcycleReportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		
		Connection con = null;
		ResultSet rs;
		
		PreparedStatement getHeaderInfo;
		PreparedStatement getSubCycleIds;
		
		//**Connecting to the Oracle DB...
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	con = ds.getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();
		
		SubcycleReportForm subcycleReportForm = (SubcycleReportForm) form;
		
		
		Vector cyclesSelected = new Vector();
		
		if(subcycleReportForm.getCyclesSelected()[0].equals("All Cycles")){
//			cyclesSelected = ((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleList();
			for(int i = 1; i < ((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleList().size(); i++){
				cyclesSelected.add(((ReportOptionsForm)request.getSession().getAttribute("reportOptionsForm")).getCycleList().get(i));
			}
		}
		else{
			for(int i = 0; i < subcycleReportForm.getCyclesSelected().length; i++){
				cyclesSelected.add(subcycleReportForm.getCyclesSelected()[i]);
			}
		}
		
		
		//**Cycles-Selected Vector has all cycles to be processed...
		
		//**Nested:root#1
		Vector listOfCycles = new Vector();
		
		for(int cyc = 0; cyc < cyclesSelected.size(); cyc++){
			
			//**For each cycle...
			try{
				//**Nested#2
				SubCycleReportObject reportObject = new SubCycleReportObject();
				
				reportObject.setCycleName(cyclesSelected.get(cyc).toString());
				
				Vector listOfSubCycles = new Vector();
				
				String currentPeriodId = "";
				String currentCountryId = "";
				String currentSubCycleId = "";
				String currentSubCycleDesc = "";
				
				getHeaderInfo = con.prepareStatement
					("SELECT C.PERIOD_ID, C.COUNTRY_ID " +
							"FROM CYCLE C " +
							"WHERE CYCLE_ID = ?");
		
				getHeaderInfo.setString(1, cyclesSelected.get(cyc).toString());
				rs = getHeaderInfo.executeQuery();
		
		
				while(rs.next()){
					currentPeriodId = rs.getString("PERIOD_ID");
					currentCountryId = rs.getString("COUNTRY_ID");
				}
				
				
				getSubCycleIds = con.prepareStatement
					("SELECT SC.SUB_CYCLE_ID, SC.DESCRIPTION " +
							"FROM SUB_CYCLE SC " +
							"WHERE CYCLE_ID = ? " +
							"ORDER BY SC.SUB_CYCLE_ID");
				
				getSubCycleIds.setString(1, cyclesSelected.get(cyc).toString());
				rs = getSubCycleIds.executeQuery();
				
				//**For all sub-cycles...
				while(rs.next()){
					
					currentSubCycleId = rs.getString("SUB_CYCLE_ID");
					currentSubCycleDesc = rs.getString("DESCRIPTION");
					
					//**Nested#3
					SubCycleTemplate subCycleTemplate = new SubCycleTemplate();
					
					//**Header...
					SubCycleHeaderTemplate currHeader = new SubCycleHeaderTemplate();
					
					currHeader.setPeriodID(currentPeriodId);
					currHeader.setCountryID(currentCountryId);
					currHeader.setSubCycleID(currentSubCycleId);
					currHeader.setSubCycleDesc(currentSubCycleDesc);
					
					
					//**SubCycleOwner Template...
					Vector subCycleTemplateList = new Vector();
					
					PreparedStatement getSubCycleOwners;
					ResultSet rs2;
					
					getSubCycleOwners = con.prepareStatement
						("SELECT OSC.OWNER_ID " +
							"FROM OWNER_SUB_CYCLE OSC " +
							"WHERE SUB_CYCLE_ID = ? ORDER BY OSC.OWNER_ID");
					
					getSubCycleOwners.setString(1, currentSubCycleId);
					rs2 = getSubCycleOwners.executeQuery();
					
					
					while(rs2.next()){
						
						String currentSubCycleOwner = rs2.getString("OWNER_ID");
						
						//**For each sub-cycle owner get the details...
						SubCycleOwnerTemplate scTemplate = new SubCycleOwnerTemplate();
						
						//**Step1: get #gaps...
						PreparedStatement getSCGaps;
						ResultSet rs3;
						
						getSCGaps = con.prepareStatement
							("SELECT COUNT(*) NUMBER_OF_GAPS " +
								"FROM " +
									"OWNER_SUB_CYCLE OSC, OWNER_RESPONSE R, GAP_DC_LOE G " +
								"WHERE " +
									"R.RESPONSE_ID = G.RESPONSE_ID AND " +
									"OSC.OWNER_ID = R.OWNER_ID AND " +
									"R.ASSOCIATED_TYPE = 'S' AND " +
									"OSC.OWNER_ID = ? AND " +
									"OSC.SUB_CYCLE_ID = R.ASSOCIATED_ID AND "+
									"SUB_CYCLE_ID = ?");
						
						getSCGaps.setString(1, currentSubCycleOwner);
						getSCGaps.setString(2, currentSubCycleId);
						
						rs3 = getSCGaps.executeQuery();
						
						int numberOfGaps = 0;
						while(rs3.next()){
							numberOfGaps = rs3.getInt("NUMBER_OF_GAPS");
						}
						
						scTemplate.setGapsReported(numberOfGaps);
						
						
						//**Step2: get other info like name, startdate, enddate...
						PreparedStatement getSCOwnerInfo;
						ResultSet rs4;
						
						getSCOwnerInfo = con.prepareStatement
							("SELECT " +
									"O.NAME  OWNER_NAME, " +
									"OSC.START_DATE START_DATE, " +
									"OSC.DUE_DATE DUE_DATE, OSC.STATUS " +
								"FROM " +
									"OWNER O, OWNER_SUB_CYCLE OSC " +
								"WHERE " +
									"O.OWNER_ID = OSC.OWNER_ID AND " +
									"OSC.OWNER_ID = ? AND	" +
									"OSC.SUB_CYCLE_ID = ?");
						
						getSCOwnerInfo.setString(1, currentSubCycleOwner);
						getSCOwnerInfo.setString(2, currentSubCycleId);
						
						rs4 = getSCOwnerInfo.executeQuery();
						
						String scOwnerName = "";
						Date scStartDate = new Date(System.currentTimeMillis());
						Date scEndDate = new Date(System.currentTimeMillis());
                        String certStatus = "";

						while(rs4.next()){
							scOwnerName = rs4.getString("OWNER_NAME");
							scStartDate = rs4.getDate("START_DATE");
							scEndDate = rs4.getDate("DUE_DATE");
                            certStatus = rs4.getString("STATUS");
						}
						
						scTemplate.setOwnerName(scOwnerName);
						scTemplate.setStartDate(scStartDate);
						scTemplate.setEndDate(scEndDate);
                        if (certStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                            scTemplate.setCertificationStatus("Y");
                        }


						//**Step3: Add that obj to its list
						subCycleTemplateList.add(scTemplate);
					}
					
					//**Total Gaps calculations...
					int totalGaps = 0;
					
					
					//**Activity Template...
					Vector activityTemplateList = new Vector();

                    String cerStatus = "";
					PreparedStatement getActivityOwners;
					ResultSet rs5;

					getActivityOwners = con.prepareStatement
						("SELECT DISTINCT O.NAME OWNER_NAME, O.OWNER_ID OWNER_ID, OA.STATUS " +
							"FROM ACTIVITY A, CTRL_OBJ CO, SUB_CYCLE SC, OWNER O, OWNER_ACTIVITY OA " +
							"WHERE " +
								"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
								"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
								"A.ACTIVITY_ID = OA.ACTIVITY_ID AND " +
								"O.OWNER_ID = OA.OWNER_ID AND " +
								"SC.SUB_CYCLE_ID = ?");
					
					getActivityOwners.setString(1, currentSubCycleId);
					rs5 = getActivityOwners.executeQuery();
					
					while(rs5.next()){
						
						String currentActivityOwnerName = rs5.getString("OWNER_NAME");						
						String currentActivityOwnerId = rs5.getString("OWNER_ID");

                        ResultSet rsCert;
                        PreparedStatement getCertificationStatus = con.prepareStatement
                                ("select min(oa.STATUS) CERT_STATUS " +
                                "from owner_activity oa, lookup lo, CTRL_OBJ CO, SUB_CYCLE SC, OWNER O, activity a " +
                                "where oa.STATUS = lo.name " +
                                "and lo.TYPE = 'STATUS' " +
                                "and oa.OWNER_ID = ? " +
                                "AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
                                "AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
                                "AND A.ACTIVITY_ID = OA.ACTIVITY_ID " +
                                "AND O.OWNER_ID = OA.OWNER_ID " +
                                "AND SC.SUB_CYCLE_ID = ? " +
                                "order by lo.VALUE desc");

                        getCertificationStatus.setString(1, currentActivityOwnerId);
                        getCertificationStatus.setString(2, currentSubCycleId);
                        rsCert = getCertificationStatus.executeQuery();

                        while (rsCert.next()){
                            cerStatus = rsCert.getString("CERT_STATUS");
                        }
//                        String cerStatus = rs5.getString("STATUS");

						//**For each owner-id get the details...
						ActivityTemplate activityTemplate = new ActivityTemplate();
						
						//**Set the owner name field...
						activityTemplate.setOwnerName(currentActivityOwnerName);
                        if (cerStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                            activityTemplate.setCertificationStatus("Y");
                        }

						//**Step1: GAp info for activity owners...
						PreparedStatement getActivityGaps;
						ResultSet rs6;
						
						getActivityGaps = con.prepareStatement
							("SELECT COUNT(*) NUMBER_OF_GAPS " +
								"FROM " +
									"OWNER_ACTIVITY OA, OWNER_RESPONSE R, GAP_DC_LOE G, " +
									"CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A " +
								"WHERE " +
									"R.RESPONSE_ID = G.RESPONSE_ID AND " +
									"OA.OWNER_ID = R.OWNER_ID AND " +
									"R.ASSOCIATED_TYPE = 'A' AND " +
									"OA.OWNER_ID = ? AND " +
									"OA.ACTIVITY_ID = R.ASSOCIATED_ID AND " +
									"A.ACTIVITY_ID = OA.ACTIVITY_ID AND " +
									"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
									"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
									"SC.SUB_CYCLE_ID = ?");
						
						getActivityGaps.setString(1, currentActivityOwnerId);
						getActivityGaps.setString(2, currentSubCycleId);

                        rs6 = getActivityGaps.executeQuery();
						
						int numberOfAcitivityGaps = 0;
						while(rs6.next()){
							numberOfAcitivityGaps = rs6.getInt("NUMBER_OF_GAPS");
						}
						
						totalGaps += numberOfAcitivityGaps;
						
						activityTemplate.setGapsReported(numberOfAcitivityGaps);
						
						//**Step2: Date Info for activity owners...
						PreparedStatement getActivityDateInfo;
						ResultSet rs7;
						
						getActivityDateInfo = con.prepareStatement
							("SELECT MIN(OA.START_DATE) START_DATE, MAX(OA.DUE_DATE) COMPLETE_DATE " +
								"FROM " +
									"OWNER O, OWNER_Activity OA, CTRL_OBJ CO, " +
									"SUB_CYCLE SC, ACTIVITY A " +
								"WHERE " +
									"O.OWNER_ID = OA.OWNER_ID AND " +
									"A.ACTIVITY_ID = OA.ACTIVITY_ID AND " +
									"OA.OWNER_ID = ? AND " +
									"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
									"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
									"SC.SUB_CYCLE_ID = ? AND " +
									"A.ACTIVITY_ID IN " +
										"(SELECT R.ASSOCIATED_ID " +
											"FROM " +
												"OWNER_ACTIVITY OA, OWNER_RESPONSE R, GAP_DC_LOE G, " +
												"CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A " +
											"WHERE " +
												"R.RESPONSE_ID = G.RESPONSE_ID(+) AND " +
												"OA.OWNER_ID = R.OWNER_ID AND " +
												"R.ASSOCIATED_TYPE = 'A' AND " +
												"OA.OWNER_ID = ? AND " +
												"OA.ACTIVITY_ID = R.ASSOCIATED_ID AND " +
												"A.ACTIVITY_ID = OA.ACTIVITY_ID AND " +
												"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
												"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
												"SC.SUB_CYCLE_ID = ? " +
												"Group BY R.ASSOCIATED_ID)");
						
						
						getActivityDateInfo.setString(1, currentActivityOwnerId);
						getActivityDateInfo.setString(2, currentSubCycleId);
						getActivityDateInfo.setString(3, currentActivityOwnerId);
						getActivityDateInfo.setString(4, currentSubCycleId);
						
						rs7 = getActivityDateInfo.executeQuery();
						
						Date activityStartDate = new Date(System.currentTimeMillis());
						Date activityEndDate = new Date(System.currentTimeMillis());


						while(rs7.next()){
							activityStartDate = rs7.getDate("START_DATE");
							activityEndDate = rs7.getDate("COMPLETE_DATE");
						}
						
						activityTemplate.setStartDate(activityStartDate);
						activityTemplate.setEndDate(activityEndDate);


						//**Step3: Add that obj to its list
						activityTemplateList.add(activityTemplate);
					}
					
					
					//**Set the total Gaps...
					currHeader.setTotalGaps(totalGaps);
					
					subCycleTemplate.setActivityTemplateList(activityTemplateList);
					subCycleTemplate.setScOwnerTemplateList(subCycleTemplateList);
					subCycleTemplate.setHeader(currHeader);
					
					
					listOfSubCycles.add(subCycleTemplate);
				}
				
				reportObject.setListOfSubCycles(listOfSubCycles);
				if(listOfSubCycles.size() > 0)
					reportObject.setReportAvailable(true);
				
				listOfCycles.add(reportObject);
				logger.info("Done populating sub-cycle report info !!!");
				
			}
			catch(Exception e){
				logger.error("DB errror " + e.getMessage());
			}
			
			
		}//end for
		
		//**Set updated list of selected Cycles...
		subcycleReportForm.setFinalCycleList(cyclesSelected);
		
		//**Set the listOfCycles in the Form Bean...
		subcycleReportForm.setListOfCycles(listOfCycles);
		
		//**Close DB connection..
		con.close();
		
		}
		catch(Exception ex){
			logger.error("DB connection error " + ex.getMessage());
		}
		
		
		
		return mapping.findForward("success");
	}

}