/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.mock;

import com.monsanto.wst.soxic.model.Owner;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MockOwner extends Owner {
    
    
    public MockOwner(String name){
        
        
//        setOwnerName(name);
//        setOwnerId("Id "+ name);
    }

    public static void main(String[] args) {
    }
}
