//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import org.apache.struts.action.ActionForm;

/** 
 * MyEclipse Struts
 * Creation date: 02-28-2005
 * 
 * XDoclet definition:
 * @struts:form name="reportOptionsForm"
 */
public class ReportOptionsForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	private String reportSelected;
	private Vector cycleList = new Vector();
	private Vector cycleCodeList = new Vector();
	private Vector allCountryList = new Vector();
	private Vector periodList = new Vector();
	private String periodSelected;
	
	

	

	/**
	 * @return Returns the periodSelected.
	 */
	public String getPeriodSelected() {
		return periodSelected;
	}
	/**
	 * @param periodSelected The periodSelected to set.
	 */
	public void setPeriodSelected(String periodSelected) {
		this.periodSelected = periodSelected;
	}
	/**
	 * @return Returns the cycleCodeList.
	 */
	public Vector getCycleCodeList() {
		return cycleCodeList;
	}
	/**
	 * @param cycleCodeList The cycleCodeList to set.
	 */
	public void setCycleCodeList(Vector cycleCodeList) {
		this.cycleCodeList = cycleCodeList;
	}
	/**
	 * @return Returns the periodList.
	 */
	public Vector getPeriodList() {
		return periodList;
	}
	/**
	 * @param periodList The periodList to set.
	 */
	public void setPeriodList(Vector periodList) {
		this.periodList = periodList;
	}
	/**
	 * @return Returns the allCountryList.
	 */
	public Vector getAllCountryList() {
		return allCountryList;
	}
	/**
	 * @param allCountryList The allCountryList to set.
	 */
	public void setAllCountryList(Vector allCountryList) {
		this.allCountryList = allCountryList;
	}
	/**
	 * @return Returns the reportSelected.
	 */
	public String getReportSelected() {
		return reportSelected;
	}
	/**
	 * @param reportSelected The reportSelected to set.
	 */
	public void setReportSelected(String reportSelected) {
		this.reportSelected = reportSelected;
	}
	/**
	 * @return Returns the cycleList.
	 */
	public Vector getCycleList() {
		return cycleList;
	}
	/**
	 * @param cycleList The cycleList to set.
	 */
	public void setCycleList(Vector cycleList) {
		this.cycleList = cycleList;
	}
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

}