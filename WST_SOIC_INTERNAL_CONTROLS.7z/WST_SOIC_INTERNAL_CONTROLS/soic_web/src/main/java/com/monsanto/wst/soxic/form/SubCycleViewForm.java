// Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import com.monsanto.wst.soxic.model.ControlObjectiveNew;
import com.monsanto.wst.soxic.model.QuestionNew;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFacade;
import com.monsanto.wst.soxic.model.headerFooter.SubCycleHeadFootFacade;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicPathUtil;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * @author SPOLAVA MyEclipse Struts Creation date: 01-18-2005
 * 
 * XDoclet definition:
 * @struts:form name="subCycleViewForm"
 */
public class SubCycleViewForm extends ActionForm {

	// --------------------------------------------------------- Instance
	// Variables

	//private Owner owner;

	private String showSubCycle;

	private String showControlObjective;

	private List subCycles;

	private LinkedHashSet subCycleCycleAssociation;

	private String cycleId;

	//    public void setOwner(Owner owner) {
	//        this.owner = owner;
	//// if(owner!= null)
	//        //setSubCycles(owner.getSubCycles());
	//    }
	//    
	//    /**
	//     * @return Returns the owner.
	//     */
	//    public Owner getOwner() {
	//        return owner;
	//    }
	//

  	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		String path = request.getServletPath();

		if (!path.equalsIgnoreCase("/populateSubCycleAction.do") && !path.equalsIgnoreCase("/subCycleView.do")) {
            String subCycleId = SoxicPathUtil.getKey(request, "submit");
            if(subCycles!=null){
                Iterator iterator = subCycles.iterator();

                while(iterator.hasNext()){
                    SubCycle subCycle = (SubCycle) iterator.next();
                    if(subCycleId!=null & subCycle.getSubCycleId().equalsIgnoreCase(subCycleId)){
                        Iterator questionIterator = subCycle.getQuestions().iterator();

                        while(questionIterator.hasNext()){
                            QuestionNew questionNew = (QuestionNew) questionIterator.next();
                            if(questionNew.getAnswer()==null || questionNew.getAnswer().length()==0){
                                errors.add("age", new ActionError(
                                        "errors.required.answer"));
                                break;
                            }
                        }
                    }
                }
            }
		}

		return errors;

	}
	/**
	 * @return Returns the showSubCycle.
	 */
	public String getShowSubCycle() {
		return showSubCycle;
	}

	/**
	 * @param showSubCycle
	 *            The showSubCycle to set.
	 */
	public void setShowSubCycle(String showSubCycle) {
		this.showSubCycle = showSubCycle;
	}

	/**
	 * @return Returns the showControlObjective.
	 */
	public String getShowControlObjective() {
		return showControlObjective;
	}

	/**
	 * @param showControlObjective
	 *            The showControlObjective to set.
	 */
	public void setShowControlObjective(String showControlObjective) {
		this.showControlObjective = showControlObjective;
	}

	/**
	 * @return Returns the subCycles.
	 */
	public List getSubCycles() {
		return subCycles;
	}

	/**
	 * @param subCycles
	 *            The subCycles to set.
	 */
	public void setSubCycles(List subCycles) {
		this.subCycles = subCycles;
	}

	public void setSubCycleToShow(String subCycleId) {

		if (subCycles != null && subCycleId != null && subCycleId.length() > 1) {

			SubCycle subCycle = getSubCycle(subCycleId);

			if (subCycle != null) {
				subCycle.setShow(!subCycle.isShow());
			}
		}
	}

	/**
	 * @param subCycleId
	 */
	private SubCycle getSubCycle(String subCycleId) {

		Iterator itr = subCycles.iterator();

		while (itr.hasNext()) {

			SubCycle subCycle = (SubCycle) itr.next();

			if (subCycle.getSubCycleId().equalsIgnoreCase(subCycleId)) {
				return subCycle;
			}
		}

		return null;
	}

	public void setControlObjectiveToShow(String controlObjectiveId) {

		if (subCycles != null && controlObjectiveId != null
				& controlObjectiveId.length() > 1) {

			String subCycleId = getSubCycleId(controlObjectiveId);
			ControlObjectiveNew controlObjective = getControlObjective(
					controlObjectiveId, getSubCycle(subCycleId));

			if (controlObjective != null) {
				controlObjective.setShow(!controlObjective.isShow());
			}
		}
	}

	private ControlObjectiveNew getControlObjective(String controlObjectiveId,
			SubCycle subCycle) {

		if (controlObjectiveId != null && subCycle != null) {
			Iterator itr = subCycle.getControlObjectives().iterator();

			while (itr.hasNext()) {
				ControlObjectiveNew controlObjective = (ControlObjectiveNew) itr
						.next();

				if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
						controlObjectiveId)) {
					return controlObjective;
				}
			}
		}

		return null;
	}

	private String getSubCycleId(String controlObjectiveId) {

		return controlObjectiveId.substring(0, controlObjectiveId
				.lastIndexOf("."));
	}

	/**
	 * @return Returns the subCycleCycleAssociation.
	 */
	public LinkedHashSet getSubCycleCycleAssociation() {
		return subCycleCycleAssociation;
	}

	/**
	 * @param subCycleCycleAssociation
	 *            The subCycleCycleAssociation to set.
	 */
	public void setSubCycleCycleAssociation(
			LinkedHashSet subCycleCycleAssociation) {
		this.subCycleCycleAssociation = subCycleCycleAssociation;
	}

	/**
	 * @return Returns the cycleId.
	 */
	public String getCycleId() {
		return cycleId;
	}

	/**
	 * @param cycleId
	 *            The cycleId to set.
	 */
	public void setCycleId(String cycleId) {
		this.cycleId = cycleId;
	}

	/**
	 * @return Returns the defaultCycleId.
	 */
	public String getDefaultCycleId() {
		if (subCycleCycleAssociation != null
				&& !subCycleCycleAssociation.isEmpty())
			return subCycleCycleAssociation.toArray()[0].toString();

		return "";
	}

	public void setLinkOnSubmit(String currentSubCycleId) {

		Iterator subCycleIterator = subCycles.iterator();

		while (subCycleIterator.hasNext()) {

			SubCycle subCycle = (SubCycle) subCycleIterator.next();

			//if(currentSubCycleId.equalsIgnoreCase(subCycle.getSubCycleId())){

			Iterator questionIterator = subCycle.getQuestions().iterator();

			while (questionIterator.hasNext()) {

				QuestionNew questionNew = (QuestionNew) questionIterator.next();

				if (questionNew.getAnswer().equalsIgnoreCase(
						SoxicConstants.NORESPONSE)) {

					questionNew.setDisplayLink(true);

					//questionNew.setLink(currentSubCycleId+"-"+questionNew.getQuestionId()+"-"+"S");
					questionNew.setLink(subCycle.getSubCycleId() + SoxicUtil.getSeperator()
							+ questionNew.getQuestionId() + SoxicUtil.getSeperator() + "S");

					if(subCycle.getDueDate()!=null && subCycle.getDueDate().length()>0){
						questionNew.setStatus(SoxicUtil
								.returnStatusPreceedingStr(subCycle.getDueDate())
								+ "INPROC");
					}

				}
			}
		}
	}

	public void setLink() {

		Iterator subCycleIterator = subCycles.iterator();

		while (subCycleIterator.hasNext()) {

			SubCycle subCycle = (SubCycle) subCycleIterator.next();

			Iterator questionIterator = subCycle.getQuestions().iterator();

			while (questionIterator.hasNext()) {

				QuestionNew questionNew = (QuestionNew) questionIterator.next();

				if (questionNew.getAnswer().equalsIgnoreCase(
						SoxicConstants.NORESPONSE)) {

					questionNew.setDisplayLink(true);
					
					questionNew.setLink(subCycle.getSubCycleId() + SoxicUtil.getSeperator()
							+ questionNew.getQuestionId() + SoxicUtil.getSeperator() + "S");

					if(subCycle.getDueDate()!=null && subCycle.getDueDate().length()>0 && !questionNew.getStatus().equalsIgnoreCase(SoxicConstants.COMPLETE)){
						questionNew.setStatus(SoxicUtil
								.returnStatusPreceedingStr(subCycle.getDueDate())
								+ "INPROC");
					}

//					subCycle.setStatus(SoxicUtil
//							.returnStatusPreceedingStr(subCycle.getDueDate())
//							+ "INPROC");
				}
			}

		}
	}

    public void setHeaderFooter(String level) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(level);
        if (subCycles!=null){
            Iterator subCycleIterator = subCycles.iterator();
		    while (subCycleIterator.hasNext()) {
			    SubCycle subCycle = (SubCycle) subCycleIterator.next();
                subCycle.setQuestionHeader(headerFooterFacade.getHeader());
                subCycle.setQuestionFooter(headerFooterFacade.getFooter());
            }
        }
    }

}