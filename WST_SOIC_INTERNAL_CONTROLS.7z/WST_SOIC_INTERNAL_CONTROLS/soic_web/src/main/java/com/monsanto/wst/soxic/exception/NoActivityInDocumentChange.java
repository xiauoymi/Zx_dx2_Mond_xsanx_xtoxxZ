package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 24, 2005
 * Time: 11:16:54 AM
 */
public class NoActivityInDocumentChange extends Exception{
	public NoActivityInDocumentChange(){
		super();
	}

	public NoActivityInDocumentChange(Exception e){
		super(e);
	}
}
