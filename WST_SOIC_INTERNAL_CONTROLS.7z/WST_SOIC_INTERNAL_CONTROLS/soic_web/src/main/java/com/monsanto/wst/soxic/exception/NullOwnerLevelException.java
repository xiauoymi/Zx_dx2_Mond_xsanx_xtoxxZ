package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 10:23:55 AM
 */

public class NullOwnerLevelException extends Exception {
	public NullOwnerLevelException(){
		super();
	}

	public NullOwnerLevelException(Exception e){
		super(e);
	}
}