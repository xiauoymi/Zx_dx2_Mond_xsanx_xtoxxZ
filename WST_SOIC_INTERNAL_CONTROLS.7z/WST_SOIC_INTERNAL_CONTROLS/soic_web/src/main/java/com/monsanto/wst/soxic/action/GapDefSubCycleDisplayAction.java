/*
 * Created on Mar 1, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.CycleViewForm;
import com.monsanto.wst.soxic.form.GapDeficiencyForm;
import com.monsanto.wst.soxic.form.SubCycleViewForm;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.Cycle;
import com.monsanto.wst.soxic.model.GapDAO;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.QuestionNew;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GapDefSubCycleDisplayAction extends Action {
	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)throws Exception {

		ActionForward forward = new ActionForward();
		
		GapDAO gapDAO = new GapDAO();
		
		GapDeficiencyForm gapDeficiencyForm = (GapDeficiencyForm)form;
		
		Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);
		
		gapDeficiencyForm.clear();
		String question = request.getParameter("question");
		
		StringTokenizer st = new StringTokenizer(question,SoxicUtil.getSeperator());
		
		String subCycleId="";
		
		String questionId="";
		String toReturn="";
		
		while(st.hasMoreElements()){
			
			subCycleId = st.nextToken();
			questionId = st.nextToken();
			toReturn=st.nextToken();
			
		}
		
		gapDeficiencyForm.setActivityFlag(false);
		
		Enumeration enume = request.getSession().getAttributeNames();
		
		gapDeficiencyForm.setQuestionId(questionId);
		
		if(toReturn.equalsIgnoreCase("S")){
			SubCycleViewForm subcycleform = (SubCycleViewForm)request.getSession().getAttribute("subCycleViewForm");
			gapDeficiencyForm.setQuestion(getQuestion(subcycleform,subCycleId,questionId));
		}
		
		if(toReturn.equalsIgnoreCase("C")){
			CycleViewForm cycleform = (CycleViewForm)request.getSession().getAttribute("cycleViewForm");
			gapDeficiencyForm.setQuestion(getCycleQuestion(cycleform,subCycleId,questionId));
		}
		
		gapDeficiencyForm.setActivityList(getActivityList(subCycleId,questionId));
		
		
		
		gapDeficiencyForm.setControlObjectiveId(subCycleId);
		
		if(toReturn.equalsIgnoreCase("S")){
			//gapDeficiencyForm.setAddedActivityList(ControlObjectiveDAO.getPreviousGap(subCycleId,questionId,SoxicConstants.SUBCYCLE,owner.getOwnerId()));
			gapDeficiencyForm.setAddedActivityList(gapDAO.getPreviousGap(subCycleId,questionId,SoxicConstants.SUBCYCLE,owner.getOwnerId()));
		}
		if(toReturn.equalsIgnoreCase("C")){
			//gapDeficiencyForm.setAddedActivityList(ControlObjectiveDAO.getPreviousGap(subCycleId,questionId,SoxicConstants.CYCLE,owner.getOwnerId()));
			gapDeficiencyForm.setAddedActivityList(gapDAO.getPreviousGap(subCycleId,questionId,SoxicConstants.CYCLE,owner.getOwnerId()));
		}
		
		gapDeficiencyForm.setToReturn(toReturn);
		
		forward = mapping.findForward("gap");
		
		return forward;
	}

//    /**
//     * @param subcylceform
//     * @param subcycleid
//     * @param questionid
//     * @return
//     */
//    public List getActivityList(ActionForm subcylceform,String subcycleid,String questionid){
//    	
//    	List actList = new ArrayList();
//    	
//    	Activity activity = new Activity();
//    	
//    	activity.setActivityId(subcycleid);
//    	
//    	activity.setQuestionId(questionid);
//    	
//    	actList.add(activity);
//    	
//    	return actList;
//    }
    
    /**
     * @param subcylceform
     * @param subcycleid
     * @param questionid
     * @return
     */
    public List getActivityList(String identifier,String questionid){
 
    	List actList = new ArrayList();
    	
    	Activity activity = new Activity();
    	
    	activity.setActivityId(identifier);
    	
    	activity.setQuestionId(questionid);
    	
    	actList.add(activity);
    	
    	return actList;
    }
	
    /**
     * @param subcylceform
     * @param subcycleid
     * @param questionid
     * @return
     */
    public String getQuestion(ActionForm subcylceform,String subcycleid,String questionid){
    	
    	String question="";
    	
    	Iterator iterator =((SubCycleViewForm)subcylceform).getSubCycles().iterator();
    	
    	while(iterator.hasNext()){
    		
    		SubCycle subCycle = (SubCycle)iterator.next();
    		
    		if(subCycle.getSubCycleId().equalsIgnoreCase(subcycleid)){
    			
    			Iterator questionIterator = subCycle.getQuestions().iterator();
    			while(questionIterator.hasNext()){
                    QuestionNew questionNew = (QuestionNew)questionIterator.next();
                    if(questionNew.getQuestionId().equalsIgnoreCase(questionid)){
                        question = questionNew.getQuestion();
                    }    
                }
    		}
    	}
    	
    	return question;
    }
    
    /**
     * @param subcylceform
     * @param subcycleid
     * @param questionid
     * @return
     */
    public String getCycleQuestion(ActionForm cylceform,String subcycleid,String questionid){
    	
    	String question="";
    	
    	Iterator iterator =((CycleViewForm)cylceform).getCycles().iterator();
    	
    	while(iterator.hasNext()){
    		
    		Cycle cycle = (Cycle)iterator.next();
    		
    		if(cycle.getCycleId().equalsIgnoreCase(subcycleid)){
    			
    			Iterator questionIterator = cycle.getQuestions().iterator();
    			while (questionIterator.hasNext()){
                    QuestionNew questionNew = (QuestionNew)questionIterator.next();
                    if(questionNew.getQuestionId().equalsIgnoreCase(questionid)){
                        question = questionNew.getQuestion();
                    }
                }
    		}
    	}
    	return question;
    }
	
	/**
	 * @param activityMap
	 * @param activityList
	 * @param questionId
	 */
	public void addActivity(Map activityMap,List activityList,String questionId){
		
		Set keySet = activityMap.keySet();
		
		Iterator activityIterator = keySet.iterator();
		
		while(activityIterator.hasNext()){
			
			Object activityKey = (Object)activityIterator.next();
			
			Activity activity =(Activity)activityMap.get(activityKey);
			
			activity.setQuestionId(questionId);
			
			activityList.add(activity);
			
		}
	}

}
