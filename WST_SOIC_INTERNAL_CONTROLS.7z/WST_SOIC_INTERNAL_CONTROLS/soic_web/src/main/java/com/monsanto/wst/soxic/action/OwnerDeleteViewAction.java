/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.OwnerDeleteForm;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerDeleteViewAction extends Action{
    
    public ActionForward execute(ActionMapping mapping, 
                                 ActionForm form,
			                     HttpServletRequest request, 
			                     HttpServletResponse response) {
        
        OwnerDeleteForm deleteOwnerForm = (OwnerDeleteForm) form;
        
        setDefaultData(deleteOwnerForm);
        
        return mapping.findForward("success");
    }
    
    private void setDefaultData(OwnerDeleteForm form){
        
        form.setUser("");
        form.setChanges(new ArrayList());
        form.setCycles(new String[0]);
        form.setSubCycles(new String[0]);
        form.setActivities(new String[0]);
        form.setSelectedCycles(new String[0]);
        form.setSelectedSubCycles(new String[0]);
        form.setSelectedActivities(new String[0]);
    }
}
