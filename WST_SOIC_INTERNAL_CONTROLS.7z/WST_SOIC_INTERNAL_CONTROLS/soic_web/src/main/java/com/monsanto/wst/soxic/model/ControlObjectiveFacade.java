/*
* Created on May 3, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.model;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.persistance.OwnerResponseDAO;
import com.monsanto.wst.soxic.persistance.OracleOwnerChangeRequestDAO;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlObjectiveFacade {

    /**
     * @param subcycleId
     * @param owner
     * @return
     * @throws Exception
     */
    public List getControlObjectives(String subcycleId,Owner owner) throws Exception{

        String ownerid= owner.getOwnerId();

        List controlObjectiveList = ControlObjectiveDAO.getAllControlObjectives(subcycleId,ownerid);

        correctActivityDescription(controlObjectiveList,ownerid);

        correctControlObjectiveDescription(controlObjectiveList);

        OwnerResponseDAO ownerResponseDAO = new OwnerResponseDAO();

        ownerResponseDAO.setAnswers(ownerid,controlObjectiveList);

        OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO = new OracleOwnerChangeRequestDAO();

        List alreadyPresentList = oracleOwnerChangeRequestDAO.selectActivitiesForWhichDocumentChangeRequested(ownerid,subcycleId);

        setControlObjectiveDocumentRequestIdentifier(controlObjectiveList,owner,SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY,alreadyPresentList);

        return controlObjectiveList;
    }

    public List getControlObjectivesDoc(String subcycleId,Owner owner) throws Exception{

        String ownerid = owner.getOwnerId();

        List controlObjectiveList = ControlObjectiveDAO.getAllControlObjectives(subcycleId);

        correctActivityDescription(controlObjectiveList,ownerid);

        correctControlObjectiveDescription(controlObjectiveList);

        OwnerResponseDAO ownerResponseDAO = new OwnerResponseDAO();

        ownerResponseDAO.setAnswers(ownerid,controlObjectiveList);

        OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO = new OracleOwnerChangeRequestDAO();

        List alreadyPresentList = oracleOwnerChangeRequestDAO.selectActivitiesForWhichDocumentChangeRequested(ownerid,subcycleId);

        setControlObjectiveDocumentRequestIdentifier(controlObjectiveList,owner,SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE,alreadyPresentList);

        return controlObjectiveList;
    }

    /**
     * @param controlObjectiveList
     * @param ownerid
     * @throws Exception
     */
    private void correctActivityDescription(List controlObjectiveList,String ownerid)throws Exception{

        if(isActivityDescOverFlowTextPresent(controlObjectiveList)){

            Map activityMap = ActivityDAO.getOverFlowActivityDescList(ownerid);

            if(activityMap!=null){

                Iterator activityIterator = activityMap.keySet().iterator();

                while(activityIterator.hasNext()){

                    String key = (String)activityIterator.next();

                    replaceActivityDescription(key,(String)activityMap.get(key),controlObjectiveList);

                }
            }
        }
    }

    /**
     * @param controlObjectiveList
     * @throws Exception
     */
    private void correctControlObjectiveDescription(List controlObjectiveList)throws Exception{

        if(isControlObjectiveDescOverFlowTextPresent(controlObjectiveList)){
            Map controlObjectiveMap = ControlObjectiveDAO.getOverFlowControlObjectiveDescList(getControlObjectiveIds(controlObjectiveList));

            if(controlObjectiveMap!=null){

                Iterator controlObjIterator = controlObjectiveMap.keySet().iterator();

                while(controlObjIterator.hasNext()){

                    String key = (String)controlObjIterator.next();

                    replaceControlObjectiveDescription(key,(String)controlObjectiveMap.get(key),controlObjectiveList);

                }
            }
        }
    }

    /**
     * @param controlObjectiveList
     * @return
     */
    private boolean isActivityDescOverFlowTextPresent(List controlObjectiveList){

        Iterator controlObjectiveiterator = controlObjectiveList.iterator();

        while(controlObjectiveiterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveiterator.next();

            if(controlObjective.getAssignedActivityMap()!=null){

                Iterator activityIterator = controlObjective.getAssignedActivityMap().values().iterator();

                while(activityIterator.hasNext()){

                    Activity activity = (Activity)activityIterator.next();

                    if(activity.getOverFlowId()!=null){
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * @param controlObjectiveList
     * @return
     */
    private boolean isControlObjectiveDescOverFlowTextPresent(List controlObjectiveList){

        Iterator controlObjectiveiterator = controlObjectiveList.iterator();

        while(controlObjectiveiterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveiterator.next();

            if(controlObjective.getOverFlowId()!=null){
                return true;
            }
        }

        return false;
    }


    /**
     * @param activityId
     * @param description
     * @param controlObjectiveList
     */
    private void replaceActivityDescription(String activityId,String description,List controlObjectiveList){

        Iterator controlObjectiveiterator = controlObjectiveList.iterator();

        while(controlObjectiveiterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveiterator.next();

            if(controlObjective.getAssignedActivityMap()!=null){

                Iterator activityIterator = controlObjective.getAssignedActivityMap().values().iterator();

                while(activityIterator.hasNext()){

                    Activity activity = (Activity)activityIterator.next();

                    if(activity.getActivityId().equalsIgnoreCase(activityId)){

                        activity.setDescription(activity.getDescription()+description);
                    }
                }
            }
        }
    }

    /**
     * @param controlObjectiveId
     * @param description
     * @param controlObjectiveList
     */
    private void replaceControlObjectiveDescription(String controlObjectiveId,String description,List controlObjectiveList){

        Iterator controlObjectiveiterator = controlObjectiveList.iterator();

        while(controlObjectiveiterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveiterator.next();

            if(controlObjective.getControlObjectiveId().equalsIgnoreCase(controlObjectiveId)){

                controlObjective.setControlObjectiveDescription(controlObjective.getControlObjectiveDescription()+description);
            }
        }
    }

    /**
     * @param controlObjectiveList
     * @return
     */
    private String getControlObjectiveIds(List controlObjectiveList){

        String inCondition = "";
        Iterator controlObjectiveiterator = controlObjectiveList.iterator();

        while(controlObjectiveiterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveiterator.next();

            if(inCondition.length()==0){
                inCondition = inCondition+"'"+controlObjective.getControlObjectiveId()+"'";
            }else{
                inCondition = inCondition+ ","+"'"+controlObjective.getControlObjectiveId()+"'";
            }
        }

        return inCondition;
    }

    private void setControlObjectiveDocumentRequestIdentifier(List controlObjectiveList,Owner owner,String docChangeLevel,List alreadyPresentList){

        Iterator controlObjectiveIterator = controlObjectiveList.iterator();

        String docIdentifier="";

        while(controlObjectiveIterator.hasNext()){

            ControlObjective controlObjective = (ControlObjective)controlObjectiveIterator.next();

            if(owner.isIA()){
                docIdentifier = controlObjective.getControlObjectiveId()+SoxicUtil.getSeperator()+owner.getDocChangeLevel()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_ADD+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE;
            }else if(owner.isIAUser()){
                docIdentifier = controlObjective.getControlObjectiveId()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_ROLE_IA_USER+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_ADD+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE;
            } else{
                docIdentifier = controlObjective.getControlObjectiveId()+SoxicUtil.getSeperator()+docChangeLevel+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_ADD+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE;
            }
            controlObjective.setDocumentChangeId(docIdentifier);

            Map activityList = controlObjective.getAssignedActivityMap();
            if(activityList!=null){
                setActivityDocumentRequestIdentifierForModifyAndDelete(activityList,owner,docChangeLevel,alreadyPresentList);
            }


        }
    }

    private void setActivityDocumentRequestIdentifierForModifyAndDelete(Map activityMap,Owner owner,String docChangeLevel,List alreadyPresentList){

        Iterator iterator = activityMap.values().iterator();

        String docRequestIdentifier,docRemovalIdentifier;

        while(iterator.hasNext()){

            Activity activity = (Activity)iterator.next();

            if(owner.isIA()){
                docRequestIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+owner.getDocChangeLevel()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_MODIFY+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);
                docRemovalIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+owner.getDocChangeLevel()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_DELETE+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);
            } else if(owner.isIAUser()){
               docRequestIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_ROLE_IA_USER+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_MODIFY+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);
                docRemovalIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_ROLE_IA_USER+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_DELETE+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);
            } else{
                docRequestIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+docChangeLevel+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_MODIFY+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);
                docRemovalIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+docChangeLevel+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_DELETE+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_NEW+SoxicUtil.getSeperator()+getModifier(activity.getActivityId(),alreadyPresentList);

            }

            activity.setRequestChangeId(docRequestIdentifier);
            activity.setRequestRemoveId(docRemovalIdentifier);
        }
    }

    private String getModifier(String activityId,List documentChangePresentList){

        if(documentChangePresentList!=null){
            Iterator iterator  = documentChangePresentList.iterator();

            while(iterator.hasNext()){
                String id = (String)iterator.next();
                if(id.equalsIgnoreCase(activityId)){
                    return SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
                }
            }
        }
        return SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE;
    }
}
