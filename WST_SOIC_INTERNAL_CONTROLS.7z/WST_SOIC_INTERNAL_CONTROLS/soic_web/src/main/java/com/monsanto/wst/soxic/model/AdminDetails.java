/*
 * Created on Mar 17, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.InvalidCertificationStateException;
import com.monsanto.wst.soxic.persistance.OracleAdminDetailsDAO;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminDetails {
    
    private static final String CHOOSE_CYCLE 		= "Choose Cycle";
    private static final String CHOOSE_SUB_CYCLE 	= "Choose SC";
    private static final String CHOOSE_CTRL_OBJ 	=  "Choose CO";
    private static final String CHOOSE_ACTIVITY 	=  "Choose Activity";
    
    
    public static List getCycles() throws DatabaseException, Exception{
        
        List cycles = getDefaultCycles();
        cycles.addAll(OracleAdminDetailsDAO.getCycles());
        
        return cycles;
    }
    
    public static List getSubCycles(String cycleId) throws DatabaseException, Exception{
        
        List subCycles = getDefaultSubCycles();
        if(cycleId != null && !cycleId.equals("") && !cycleId.equals(CHOOSE_CYCLE)){
            subCycles.addAll(OracleAdminDetailsDAO.getSubCycles(cycleId));
        }
        
        return subCycles;
    }
    
    public static List getControlObjectives(String subCycleId) throws DatabaseException, Exception{
        
        List controlObjectives = getDefaultControlObjectives();
        if(subCycleId != null && !subCycleId.equals("") && !subCycleId.equals(CHOOSE_SUB_CYCLE)){
            controlObjectives.addAll(OracleAdminDetailsDAO.getControlObjectives(subCycleId));
        }
        
        return controlObjectives;
    }
    
    public static List getActivities(String controlObjectiveId) throws DatabaseException, Exception{
        
        List activities = getDefaultActivities();
        if(controlObjectiveId != null && !controlObjectiveId.equals("") && !controlObjectiveId.equals(CHOOSE_CTRL_OBJ) ){
            activities.addAll(OracleAdminDetailsDAO.getActivities(controlObjectiveId));
        }
        
        return activities;
    }
    
    private static List getDefaultCycles() {
        List cycles = new ArrayList();
        cycles.add(CHOOSE_CYCLE);
        return cycles;
    }
    
    private static List getDefaultSubCycles() {
        List subCycles = new ArrayList();
        subCycles.add(CHOOSE_SUB_CYCLE);
        return subCycles;
    }
    
    private static List getDefaultControlObjectives() {
        List controlObjectives = new ArrayList();
        controlObjectives.add(CHOOSE_CTRL_OBJ);
        return controlObjectives;
    }

    private static List getDefaultActivities() {
        List activities = new ArrayList();
        activities.add(CHOOSE_ACTIVITY);
        return activities;
    }
    
    public static ItemDetails getItemDetails(String type, String id) throws DatabaseException{
        
//        if( id.equals("Choose Cycle") || id.equals("Choose SC") || id.equals("Choose CO") || id.equals("Choose Activity"))
//            return new ItemDetails();
//        
        if(type.equals("CYCLE"))
            return OracleAdminDetailsDAO.getCycleDetails(id);
        
        else if(type.equals("SUB_CYCLE"))
            return OracleAdminDetailsDAO.getSubCycleDetails(id);
        
        else if(type.equals("CTRL_OBJ"))            
            return OracleAdminDetailsDAO.getControlObjectiveDetails(id);
        
        else
            return OracleAdminDetailsDAO.getActivityDetails(id);
    }
//            return OracleAdminDetailsDAO.getActivityCodes(id);

    
    public static void update(ItemDetails details) throws Exception,DatabaseException, InvalidCertificationStateException{
        
        OracleAdminDetailsDAO.updateDetails(details);
     
    }


    public static void sendEmail(ItemDetails details){
    	
    }
    
}
