/*
 * Created on Feb 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReportListingObject {
	
	String reportName;
	String reportDescription;
	String reportLocation;
    String reportType;



	/**
	 * @return Returns the reportDescription.
	 */
	public String getReportDescription() {
		return reportDescription;
	}
	/**
	 * @param reportDescription The reportDescription to set.
	 */
	public void setReportDescription(String reportDescription) {
		this.reportDescription = reportDescription;
	}
	/**
	 * @return Returns the reportLocation.
	 */
	public String getReportLocation() {
		return reportLocation;
	}
	/**
	 * @param reportLocation The reportLocation to set.
	 */
	public void setReportLocation(String reportLocation) {
		this.reportLocation = reportLocation;
	}
	/**
	 * @return Returns the reportName.
	 */
	public String getReportName() {
		return reportName;
	}
	/**
	 * @param reportName The reportName to set.
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }
}
