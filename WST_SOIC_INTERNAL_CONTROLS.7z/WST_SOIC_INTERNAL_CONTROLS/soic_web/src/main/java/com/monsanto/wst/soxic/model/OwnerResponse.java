/*
 * Created on May 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerResponse {
	private String responseid;
	private String ownerid;
	private int questionid;
	private String associatedType;
	private String associatedId;
	private String response;
	private String status;
	
	
	
	/**
	 * @return Returns the associatedId.
	 */
	public String getAssociatedId() {
		return associatedId;
	}
	/**
	 * @param associatedId The associatedId to set.
	 */
	public void setAssociatedId(String associatedId) {
		this.associatedId = associatedId;
	}
	/**
	 * @return Returns the associatedType.
	 */
	public String getAssociatedType() {
		return associatedType;
	}
	/**
	 * @param associatedType The associatedType to set.
	 */
	public void setAssociatedType(String associatedType) {
		this.associatedType = associatedType;
	}
	/**
	 * @return Returns the ownerid.
	 */
	public String getOwnerid() {
		return ownerid;
	}
	/**
	 * @param ownerid The ownerid to set.
	 */
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	
	/**
	 * @return Returns the questionid.
	 */
	public int getQuestionid() {
		return questionid;
	}
	/**
	 * @param questionid The questionid to set.
	 */
	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}
	/**
	 * @return Returns the response.
	 */
	public String getResponse() {
		return response;
	}
	/**
	 * @param response The response to set.
	 */
	public void setResponse(String response) {
		this.response = response;
	}
	/**
	 * @return Returns the responseid.
	 */
	public String getResponseid() {
		return responseid;
	}
	/**
	 * @param responseid The responseid to set.
	 */
	public void setResponseid(String responseid) {
		this.responseid = responseid;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	 public String toString(){
	     
	     StringBuffer buffer = new StringBuffer();
	     buffer.append('\n'+ "Owner Response History :"         + '\n');
	     buffer.append("Response Id    :"+ responseid    +'\n');
	     buffer.append("Response       :"+ response      + '\n');
	     buffer.append("Associated Id  :"+ associatedId  + '\n');
	     buffer.append("Ownerid        :"+ ownerid       + '\n');
	     return buffer.toString();
	     
	 }	
}
