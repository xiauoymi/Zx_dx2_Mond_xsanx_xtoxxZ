/*
 * Created on Jun 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.importProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RemoveSubCycleStoredProcedure {
	public static void removeSubCycleOne(String subCycleId){
		Connection con = null;
		PreparedStatement questionActivityStmt,questionSubCycle,ownerActivity,ownerSubCycle,activity,ctrlObj,subCycle,owner;
		ResultSet rs=null;
		int result=0;
		
		try{
			con = DriverManager.getConnection("jdbc:default:connection:");
			questionActivityStmt = con.prepareStatement("DELETE FROM QUESTION_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subCycleId+"%'");			
			result = questionActivityStmt.executeUpdate();
			
			questionSubCycle = con.prepareStatement("DELETE FROM QUESTION_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subCycleId+"%'");			
			questionSubCycle.executeUpdate();
			
			ownerActivity = con.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subCycleId+"%'");			
			ownerActivity.executeUpdate();
			
			ownerSubCycle = con.prepareStatement("DELETE FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subCycleId+"%'");			
			ownerSubCycle.executeUpdate();

			activity = con.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID LIKE '%"+subCycleId+"%'");			
			activity.executeUpdate();
			
			ctrlObj = con.prepareStatement("DELETE FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%"+subCycleId+"%'");			
			ctrlObj.executeUpdate();
			
			subCycle = con.prepareStatement("DELETE FROM SUB_CYCLE WHERE SUB_CYCLE_ID LIKE '%"+subCycleId+"%'");			
			subCycle.executeUpdate();				
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
