package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 8, 2005
 * Time: 9:55:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmailForm extends ActionForm{
}
