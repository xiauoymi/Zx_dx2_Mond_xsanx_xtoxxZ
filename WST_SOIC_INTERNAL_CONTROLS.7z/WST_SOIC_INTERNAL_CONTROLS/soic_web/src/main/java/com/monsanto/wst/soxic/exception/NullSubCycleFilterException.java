package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 10:03:02 AM
 */

public class NullSubCycleFilterException extends Exception {
	public NullSubCycleFilterException(){
		super();
	}

	public NullSubCycleFilterException(Exception e){
		super(e);
	}
}