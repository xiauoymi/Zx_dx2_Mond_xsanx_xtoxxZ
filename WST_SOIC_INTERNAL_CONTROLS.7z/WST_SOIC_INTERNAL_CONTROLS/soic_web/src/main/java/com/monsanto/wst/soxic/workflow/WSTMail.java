/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class WSTMail {

	public static void main(String[] argv) {

		String to, subject = null, from = null, cc = null, bcc = null, url = null;
		String mailhost = null;
		String mailer = "msgsend";
		String protocol = null, host = null, user = null, password = null;
		String record = null; // name of folder in which to record mail
		boolean debug = false;
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int optind;

		for (optind = 0; optind < argv.length; optind++) {
			if (argv[optind].equals("-T")) {
				protocol = argv[++optind];
			} else if (argv[optind].equals("-H")) {
				host = argv[++optind];
			} else if (argv[optind].equals("-U")) {
				user = argv[++optind];
			} else if (argv[optind].equals("-P")) {
				password = argv[++optind];
			} else if (argv[optind].equals("-M")) {
				mailhost = argv[++optind];
			} else if (argv[optind].equals("-f")) {
				record = argv[++optind];
			} else if (argv[optind].equals("-s")) {
				subject = argv[++optind];
			} else if (argv[optind].equals("-o")) { // originator
				from = argv[++optind];
			} else if (argv[optind].equals("-c")) {
				cc = argv[++optind];
			} else if (argv[optind].equals("-b")) {
				bcc = argv[++optind];
			} else if (argv[optind].equals("-L")) {
				url = argv[++optind];
			} else if (argv[optind].equals("-d")) {
				debug = true;
			} else if (argv[optind].equals("--")) {
				optind++;
				break;
			} else if (argv[optind].startsWith("-")) {
				System.out
						.println("Usage: msgsend [[-L store-url] | [-T prot] [-H host] [-U user] [-P passwd]]");
				System.out
						.println("\t[-s subject] [-o from-address] [-c cc-addresses] [-b bcc-addresses]");
				System.out
						.println("\t[-f record-mailbox] [-M transport-host] [-d] [address]");
				System.exit(1);
			} else {
				break;
			}
		}

		try {
			if (optind < argv.length) {
				// XXX - concatenate all remaining arguments
				to = argv[optind];
			} else {
				to = in.readLine();
			}
			if (subject == null) {
				//subject = in.readLine();
				subject ="Hello";
			}

			Properties props = System.getProperties();
			// XXX - could use Session.getTransport() and Transport.connect()
			// XXX - assume we're using SMTP
			//if (mailhost != null)
				props.put("mail.smtp.host", "mail.monsanto.com");

			// Get a Session object
			Session session = Session.getInstance(props, null);
			if (debug)
				session.setDebug(true);

			// construct the message
			Message msg = new MimeMessage(session);
			from = "rambabu.bethina@monsanto.com";
			to = "rambabu.bethina@monsanto.com";
			if (from != null)
				msg.setFrom(new InternetAddress(from));
			else
				msg.setFrom();

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(
					to, false));
			if (cc != null)
				msg.setRecipients(Message.RecipientType.CC, InternetAddress
						.parse(cc, false));
			if (bcc != null)
				msg.setRecipients(Message.RecipientType.BCC, InternetAddress
						.parse(bcc, false));

			msg.setSubject(subject);

			collect(in, msg);

			msg.setHeader("X-Mailer", mailer);
			msg.setSentDate(new Date());

			// send the thing off
			Transport.send(msg);

			// Keep a copy, if requested.

			if (record != null) {
				// Get a Store object
				Store store = null;
				if (url != null) {
					URLName urln = new URLName(url);
					store = session.getStore(urln);
					store.connect();
				} else {
					if (protocol != null)
						store = session.getStore(protocol);
					else
						store = session.getStore();

					// Connect
					if (host != null || user != null || password != null)
						store.connect(host, user, password);
					else
						store.connect();
				}

				// Get record Folder. Create if it does not exist.
				Folder folder = store.getFolder(record);
				if (folder == null) {
					System.err.println("Can't get record folder.");
					System.exit(1);
				}
				if (!folder.exists())
					folder.create(Folder.HOLDS_MESSAGES);

				Message[] msgs = new Message[1];
				msgs[0] = msg;
				folder.appendMessages(msgs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void collect(BufferedReader in, Message msg)
			throws MessagingException, IOException {
		String line;
		StringBuffer sb = new StringBuffer();
		sb.append("Hello world");
		//	while ((line = in.readLine()) != null) {
		//	    sb.append(line);
		//	    sb.append("\n");
		//	}

		// If the desired charset is known, you can use
		// setText(text, charset)
		msg.setText(sb.toString());
	}

}