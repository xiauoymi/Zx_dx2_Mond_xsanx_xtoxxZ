package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.AdminOwnerEntity;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import com.monsanto.wst.soxic.shared.overflow.OverFlow;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 8, 2006
 * Time: 4:13:38 PM
 * To change this template use File | Settings | File Templates.
 */

public class SignficantChangeDAO {

    private static final String getSignificantChangeSequence =
            "SELECT SEQUENCE AS SIG_SEQUENCE " +
            "FROM SIGNIFICANT_CHANGE " +
            "WHERE CYCLE_ID = ? " +
            "AND OWNER_ID = ?";

    private static final String getCurrentPeriodFromOwnerAndCycle = "SELECT P.PERIOD_ID " +
            "FROM OWNER_CYCLE OC, CYCLE C, PERIOD P " +
            "WHERE OC.CYCLE_ID = C.CYCLE_ID " +
            "AND C.PERIOD_ID = P.PERIOD_ID " +
            "AND OC.OWNER_ID = ? " +
            "AND C.CYCLE_ID = ?";

    private static final String getSignificantBusinessOrPeriod = "SELECT NAME " +
            "FROM LOOKUP " +
            "WHERE TYPE = ?";

    private static final String createSignificantChangeRow = "INSERT INTO SIGNIFICANT_CHANGE" +
            "(CYCLE_ID, OWNER_ID, SEQUENCE," +
            "BUSINESS_TYPE, PERIOD_IMPACTED, COST, KEY_CONTACT, SUB_CYCLE_IMPACTED, " +
            "DESCRIPTION, OVERFLOW_ID, STATUS, MOD_DATE, MOD_USER) " +
            "VALUES (?,?,SIGCHANGE_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";

    private static final String createNoReportingSigChangeRow = "INSERT INTO SIGNIFICANT_CHANGE " +
            "(CYCLE_ID, OWNER_ID, SEQUENCE, " +
            "BUSINESS_TYPE, PERIOD_IMPACTED, COST, KEY_CONTACT, SUB_CYCLE_IMPACTED, " +
            "DESCRIPTION, OVERFLOW_ID, STATUS, MOD_DATE, MOD_USER) " +
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";



    public String returnCurrentPeriod(String cycleId, String ownerid) {
        String period = "";
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getCurrentPeriodFromOwnerAndCycle);
                preparedStatement.setString(1, ownerid);
                preparedStatement.setString(2,cycleId);
                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    period = rs.getString("PERIOD_ID");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return period;
    }

    public List returnDynamicBusinessOrPeriod(String significantChangeType) {
        List dynList = new ArrayList();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getSignificantBusinessOrPeriod);
                if (significantChangeType.equalsIgnoreCase(SoxicConstants.SIGNIFICANT_CHANGE_BUSINESS)){
                    preparedStatement.setString(1, SoxicConstants.SIGNIFICANT_CHANGE_BUSINESS);
                }
                else
                if (significantChangeType.equalsIgnoreCase(SoxicConstants.SIGNIFICANT_CHANGE_PERIOD)){
                    preparedStatement.setString(1, SoxicConstants.SIGNIFICANT_CHANGE_PERIOD);
                }
                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    dynList.add(rs.getString("NAME"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        dynList.add("");
        Collections.sort(dynList);
        return dynList;
    }    

    public void createSigChangesForOwnerAndCycle(String cycleId, String ownerId, List sigCycles, String type) {
        Connection con = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement(createSignificantChangeRow);

            Iterator iterator = sigCycles.iterator();
            while(iterator.hasNext()){
                SignificantChangeModel sigModel = (SignificantChangeModel)iterator.next();
                OverFlow descOverFlow = new OverFlow(sigModel.getDescription());
                String first2kDesc = descOverFlow.getFirstTwoThousandCharacters();
                preparedStatement.setString(1,cycleId);
                preparedStatement.setString(2, ownerId);
                preparedStatement.setString(3,sigModel.getSelectedType());
                preparedStatement.setString(4,sigModel.getSelectedPeriod());
                preparedStatement.setString(5,sigModel.getAmount());
                preparedStatement.setString(6,sigModel.getKeyContact());
                preparedStatement.setString(7,sigModel.getSubcycles());
                preparedStatement.setString(8,first2kDesc);
                preparedStatement.setString(9,descOverFlow.getOverFlowId());
                if (type.equalsIgnoreCase(SoxicConstants.SIG_CHANGE_SAVE)){
                    preparedStatement.setString(10,SoxicConstants.GREEN_IMPORTED);
                }else
                if (type.equalsIgnoreCase(SoxicConstants.SIG_CHANGE_SUBMIT)){
                    preparedStatement.setString(10,SoxicConstants.GREEN_COMPLETE);
                }
                preparedStatement.setDate(11,new Date(System.currentTimeMillis()));
                preparedStatement.setString(12,ownerId);
                preparedStatement.addBatch();
            }
            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }

    public String createSigChangeSequence() {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String generatedId = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT SARBOX_ET.SIGCHANGE_SEQ.NEXTVAL FROM DUAL");
                rs = preparedStatement.executeQuery();
                while(rs.next()){
                    generatedId = rs.getString(1);
                }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return generatedId;
    }

    public void createSignificantChangeRowForNoReporting(SignificantChangeModel significantChangeModel, String cycleId, String ownerId, String type) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(createNoReportingSigChangeRow);
                preparedStatement.setString(1, cycleId);
                preparedStatement.setString(2, ownerId);
                preparedStatement.setString(3, significantChangeModel.getSeqindex());
                preparedStatement.setString(4, significantChangeModel.getSelectedType());
                preparedStatement.setString(5, significantChangeModel.getSelectedPeriod());
                preparedStatement.setString(6, significantChangeModel.getAmount());
                preparedStatement.setString(7, significantChangeModel.getKeyContact());
                preparedStatement.setString(8, significantChangeModel.getSubcycles());
                preparedStatement.setString(9, significantChangeModel.getDescription());
                preparedStatement.setString(10, "0");
                if (type.equalsIgnoreCase(SoxicConstants.SIG_CHANGE_SAVE)){
                    preparedStatement.setString(11,SoxicConstants.GREEN_IMPORTED);
                }else
                if (type.equalsIgnoreCase(SoxicConstants.SIG_CHANGE_SUBMIT)){
                    preparedStatement.setString(11,SoxicConstants.GREEN_COMPLETE);
                }
                preparedStatement.setDate(12, new Date(System.currentTimeMillis()));
                preparedStatement.setString(13, ownerId);
                int n = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }

    public String checkSequenceIDForOwnerAndCycle(String cycleId, String ownerid) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String significantId = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getSignificantChangeSequence);
                preparedStatement.setString(1, cycleId);
                preparedStatement.setString(2, ownerid);
                rs = preparedStatement.executeQuery();
                while(rs.next()){
                    significantId = rs.getString("SIG_SEQUENCE");
                }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return significantId;
    }

    public  boolean cycleWithSignificantChanges(AdminOwnerEntity entity) throws Exception{
        boolean result = false;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = null;
        ResultSet rs = null;

        try {

             if (entity.getType().equals("CYCLE")) {
                connection = SoxicConnectionFactory.getSoxicConnection();
                query = "select * from significant_change " +
                        " where cycle_id = ? " +
                        " and owner_id = ? ";

                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, entity.getCycleId());
                preparedStatement.setString(2, entity.getOwnerId());
                rs = preparedStatement.executeQuery();
                if(rs.next()) {
                    result = true;
                }
             }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {            
              DBUtils.closeConnection(rs, preparedStatement, connection);
        }
        return result;
    }

    public void updateSignificantChanges(AdminOwnerEntity entity, String user) throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = null;

        try {

             if (entity.getType().equals("CYCLE")) {
                connection = SoxicConnectionFactory.getSoxicConnection();
                query = "update significant_change " +
                        " set owner_id = ? " +
                        " where cycle_id = ? " +
                        " and owner_id = ? ";

                preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, user);
                preparedStatement.setString(2, entity.getCycleId());
                preparedStatement.setString(3, entity.getOwnerId());

                System.out.println("query:" + query);
                System.out.println("user: " + user + " cycleId: " + entity.getCycleId() + " ownerId: " +  entity.getOwnerId());

                preparedStatement.executeUpdate();
             }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
              DBUtils.closeConnection(null, preparedStatement, connection);
        }
    }
    
}
