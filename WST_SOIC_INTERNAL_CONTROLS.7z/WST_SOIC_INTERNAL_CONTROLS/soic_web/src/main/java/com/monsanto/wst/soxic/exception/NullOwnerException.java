package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 9:27:34 AM
 */


public class NullOwnerException extends Exception {
	public NullOwnerException(){
		super();
	}

	public NullOwnerException(Exception e){
		super(e);
	}
}