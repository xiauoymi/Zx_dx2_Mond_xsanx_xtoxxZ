package com.monsanto.wst.soxic.workflow.gapoperations;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 1:00:22 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class GapDAO {

    protected String environment="";
    protected String folder="";

   public GapDAO(String env,String fol){
       environment=env;
       folder = fol;
   }


    public List selectOwnerEntity(){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getOwnerEntityQuery());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                entity.setOwnerId(rs.getString("OWNER_ID"));
                String potentialGap = rs.getString("POTENTIAL_GAP");
                if(potentialGap!=null){
                    entity.setPotentialGap(potentialGap);
                }else{
                   entity.setPotentialGap("");
                }

                entityList.add(entity);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectOwnerEntityWithGaps(){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getOwnerEntityQueryWithGaps());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                entity.setOwnerId(rs.getString("OWNER_ID"));
                entity.setDoUpdate(true);
                entity.setWriteToUpdateOwnerEntityGapYes(true);
                entity.setPotentialGap("Y");
                entityList.add(entity);

            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectEntity(){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getEntityQuery());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                String gap = rs.getString("POTENTIAL_GAP");
                if(gap!=null){
                    entity.setPotentialGap(gap);
                }else{
                    entity.setPotentialGap("");
                }

                entityList.add(entity);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectAllGapsPerEntity(GapEntity gapEntity){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getAllGapsPerEntityQuery());
            preparedStatement.setString(1,gapEntity.getIdentifier());

            rs = preparedStatement.executeQuery();

            while(rs.next()){

                String potentialGap = (rs.getString("POTENTIAL_GAP"));
                if(potentialGap!=null){
                 entityList.add(potentialGap);
                }else{
                    entityList.add("");
                }

            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected abstract String getAllGapsPerEntityQuery();



    public List getResponseList(GapEntity gapEntity){
        List responseList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        Response response;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement("SELECT ORS.RESPONSE_ID,ORS.RESPONSE,GDL.DESCRIPTION FROM  OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND ORS.RESPONSE_ID=GDL.RESPONSE_ID(+)");
            preparedStatement.setString(1,gapEntity.getOwnerId());
            preparedStatement.setString(2,gapEntity.getIdentifier());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                response = new Response();
                response.setResponseId(rs.getString("RESPONSE_ID"));
                response.setResponse(rs.getString("RESPONSE"));
                if(rs.getString("DESCRIPTION")!=null){
                    response.setDescription(rs.getString("DESCRIPTION"));
                }else{
                    response.setDescription("");
                }
                responseList.add(response);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return responseList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getResponseListOnlyForGaps(GapEntity gapEntity){
        List responseList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        Response response;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement("SELECT ORS.RESPONSE_ID,ORS.RESPONSE,GDL.DESCRIPTION FROM  OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND ORS.RESPONSE_ID=GDL.RESPONSE_ID");
            preparedStatement.setString(1,gapEntity.getOwnerId());
            preparedStatement.setString(2,gapEntity.getIdentifier());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                response = new Response();
                response.setResponseId(rs.getString("RESPONSE_ID"));
                response.setResponse(rs.getString("RESPONSE"));
                if(rs.getString("DESCRIPTION")!=null){
                    response.setDescription(rs.getString("DESCRIPTION"));
                }else{
                    response.setDescription("");
                }
                responseList.add(response);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return responseList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectNoGapYesAnswer() {
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getSelectNoGapYesAnswerQuery());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                entity.setOwnerId(rs.getString("OWNER_ID"));
                entity.setQuestionId(rs.getString("QUESTION_ID"));
                entityList.add(entity);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectNoGapNoAnswer() {
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getSelectNoGapNoAnswerQuery());
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                entity.setOwnerId(rs.getString("OWNER_ID"));
                entity.setQuestionId(rs.getString("QUESTION_ID"));

                entityList.add(entity);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List updateNoGapYesAnswer(List entityList) {
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getUpdateNoGapYesAnswerQuery());
            Iterator iterator = entityList.iterator();

            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity) iterator.next();
                String id = gapEntity.getIdentifier();
                String own = gapEntity.getOwnerId();
                preparedStatement.setString(1,"");
                preparedStatement.setString(2,gapEntity.getIdentifier());
                preparedStatement.setString(3,gapEntity.getOwnerId());

                preparedStatement.addBatch();
            }

            int result[] = preparedStatement.executeBatch();
            connection.commit();
        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List updateOwnerEntity(List entityList) {
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getUpdateOwnerEntityQuery());
            Iterator iterator = entityList.iterator();

            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity) iterator.next();
                if(gapEntity.doUpdate){
                    String id = gapEntity.getIdentifier();
                    String own = gapEntity.getOwnerId();
                    preparedStatement.setString(1,gapEntity.getPotentialGap());
                    preparedStatement.setString(2,gapEntity.getIdentifier());
                    preparedStatement.setString(3,gapEntity.getOwnerId());

                    preparedStatement.addBatch();
                }

            }

            int result[] = preparedStatement.executeBatch();
            connection.commit();
        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List updateEntity(List entityList) {
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getUpdateEntityQuery());
            Iterator iterator = entityList.iterator();

            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity) iterator.next();
                String id = gapEntity.getIdentifier();
                String own = gapEntity.getOwnerId();
                boolean update = gapEntity.isDoUpdate();

                if(update){
                    preparedStatement.setString(1,gapEntity.getPotentialGap());
                    preparedStatement.setString(2,gapEntity.getIdentifier());
                    preparedStatement.addBatch();
                }

            }

            int result[] = preparedStatement.executeBatch();
            connection.commit();
        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List updateEntitySetYesGapsForGaps(List entityList) {
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getUpdateEntityQuery());
            Iterator iterator = entityList.iterator();

            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity) iterator.next();
                String id = gapEntity.getIdentifier();
                String own = gapEntity.getOwnerId();
                boolean update = gapEntity.isDoUpdate();

                if(update){
                    preparedStatement.setString(1,gapEntity.getPotentialGap());
                    preparedStatement.setString(2,gapEntity.getIdentifier());
                    preparedStatement.addBatch();
                }

            }

            int result[] = preparedStatement.executeBatch();
            connection.commit();
        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected abstract String getUpdateEntityQuery();

    public List updateNoGapNoAnswer(List entityList) {
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getUpdateNoGapYesAnswerQuery());
            Iterator iterator = entityList.iterator();

            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity) iterator.next();
                preparedStatement.setString(1,"");
                preparedStatement.setString(2,gapEntity.getIdentifier());
                preparedStatement.setString(3,gapEntity.getOwnerId());

                preparedStatement.addBatch();
            }

            int result[] = preparedStatement.executeBatch();
        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected abstract String getUpdateNoGapYesAnswerQuery();

    protected abstract String getUpdateOwnerEntityQuery();

    protected abstract String getUpdateNoGapNoAnswerQuery();

    protected abstract String getSelectNoGapYesAnswerQuery() ;

    protected abstract String getSelectNoGapNoAnswerQuery() ;

    protected abstract String getIdentifierType();

    protected abstract String getOwnerEntityQuery();

    protected abstract String getOwnerEntityQueryWithGaps();

    protected abstract String getEntityQuery();

    public List selectResponseList(){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        GapEntity entity;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement("SELECT ORS.RESPONSE,ORS.RESPONSE_ID FROM OWNER_RESPONSE ORS WHERE ORS.ASSOCIATED_ID=? AND ORS.OWNER_ID=?");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                entity = new ActivityGap();
                entity.setIdentifier(rs.getString(getIdentifierType()));
                entity.setOwnerId(rs.getString("OWNER_ID"));
                entity.setPotentialGap(rs.getString("POTENTIAL_GAP"));
                entityList.add(entity);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
