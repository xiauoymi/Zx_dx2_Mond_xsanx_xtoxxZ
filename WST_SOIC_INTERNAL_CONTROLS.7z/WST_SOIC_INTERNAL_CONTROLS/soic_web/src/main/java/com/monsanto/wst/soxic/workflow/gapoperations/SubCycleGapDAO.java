package com.monsanto.wst.soxic.workflow.gapoperations;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 1:05:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubCycleGapDAO extends GapDAO{

     public SubCycleGapDAO(String env,String fol){
        super(env,fol);
    }
//    public List selectEntity() {
//        return null;  //To change body of implemented methods use File | Settings | File Templates.
//    }

    protected String getAllGapsPerEntityQuery() {
        return "SELECT POTENTIAL_GAP FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID=?";
    }

    protected String getUpdateEntityQuery() {
        return "UPDATE SUB_CYCLE SET POTENTIAL_GAP=? WHERE SUB_CYCLE_ID=?";  //To change body of implemented methods use File | Settings | File Templates.
    }

//    public List selectOwnerEntity() {
//        return null;  //To change body of implemented methods use File | Settings | File Templates.
//    }


    protected String getUpdateNoGapYesAnswerQuery() {
        return "UPDATE OWNER_SUB_CYCLE OSC SET OSC.POTENTIAL_GAP=? WHERE OSC.SUB_CYCLE_ID=? AND OSC.OWNER_ID=?";
    }

    protected String getUpdateOwnerEntityQuery() {
        return "UPDATE OWNER_SUB_CYCLE OSC SET OSC.POTENTIAL_GAP=? WHERE OSC.SUB_CYCLE_ID=? AND OSC.OWNER_ID=?";
    }

    protected String getUpdateNoGapNoAnswerQuery() {
        return "UPDATE OWNER_SUB_CYCLE OSC SET OSC.POTENTIAL_GAP=? WHERE OSC.SUB_CYCLE_ID=? AND OSC.OWNER_ID=?";
    }

    protected String getSelectNoGapYesAnswerQuery() {
        return "SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID,OSC.POTENTIAL_GAP,ORS.RESPONSE,ORS.RESPONSE_ID,ORS.QUESTION_ID FROM OWNER_SUB_CYCLE OSC,OWNER_RESPONSE ORS WHERE OSC.SUB_CYCLE_ID = ORS.ASSOCIATED_ID AND OSC.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE = 'YES' AND OSC.POTENTIAL_GAP='Y' AND ORS.RESPONSE_ID NOT IN (SELECT RESPONSE_ID FROM GAP_DC_LOE)";
    }

    protected String getSelectNoGapNoAnswerQuery() {
        return "SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID,OSC.POTENTIAL_GAP,ORS.RESPONSE,ORS.RESPONSE_ID,ORS.QUESTION_ID FROM OWNER_SUB_CYCLE OSC,OWNER_RESPONSE ORS WHERE OSC.SUB_CYCLE_ID = ORS.ASSOCIATED_ID AND OSC.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE = 'NO' AND OSC.POTENTIAL_GAP='Y' AND ORS.RESPONSE_ID NOT IN (SELECT RESPONSE_ID FROM GAP_DC_LOE)";
    }

    protected String getIdentifierType() {
       return SubCycleGap.SUB_CYCLE_ID;
    }

    protected String getOwnerEntityQuery() {
        return "SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID,OSC.POTENTIAL_GAP FROM OWNER_SUB_CYCLE OSC WHERE OSC.SUB_CYCLE_ID LIKE '%FY05.%'";
        //return "SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID,OSC.POTENTIAL_GAP FROM OWNER_SUB_CYCLE OSC WHERE OSC.SUB_CYCLE_ID LIKE '%FY05.AUS.BU.01%'";
    }

    protected String getOwnerEntityQueryWithGaps() {
        return "SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC,OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE OSC.SUB_CYCLE_ID=ORS.ASSOCIATED_ID AND OSC.OWNER_ID=ORS.OWNER_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID";  //To change body of implemented methods use File | Settings | File Templates.
    }

    protected String getEntityQuery() {
        //return "SELECT SC.SUB_CYCLE_ID,SC.POTENTIAL_GAP FROM SUB_CYCLE SC";  //To change body of implemented methods use File | Settings | File Templates.
        return "SELECT SC.SUB_CYCLE_ID,SC.POTENTIAL_GAP FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID LIKE '%FY05.%'";  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List selectAllGapsPerEntity(GapEntity gapEntity){
        List entityList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getLocalConnection(environment,folder);
            preparedStatement = connection.prepareStatement(getAllGapsPerEntityQuery());
            preparedStatement.setString(1,gapEntity.getIdentifier());

            rs = preparedStatement.executeQuery();

            while(rs.next()){

                String potentialGap = (rs.getString("POTENTIAL_GAP"));
                entityList.add(potentialGap);
            }

            preparedStatement = connection.prepareStatement("SELECT POTENTIAL_GAP FROM CTRL_OBJ WHERE SUB_CYCLE_ID=?");
            preparedStatement.setString(1,gapEntity.getIdentifier());

            rs = preparedStatement.executeQuery();

            while(rs.next()){

                String potentialGap = (rs.getString("POTENTIAL_GAP"));
                entityList.add(potentialGap);
            }


        }catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entityList;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
