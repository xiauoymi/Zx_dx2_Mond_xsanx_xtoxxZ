/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.util.Collection;
import java.util.Map;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface DAO {
    
    public Collection retrieveByCriteria(Map fields) throws Exception;
    
    public void update(Collection soxicBaseModel)throws Exception;

    public int create(SoxicBaseModel soxicBaseModel) throws Exception;

    // add methods for insert, update, delete upon need. implement them in the OracleAbstractDAO class.
    // building  the queries and populating the models with the data should be coded in the correspoding Oraclexxx classes.
}
