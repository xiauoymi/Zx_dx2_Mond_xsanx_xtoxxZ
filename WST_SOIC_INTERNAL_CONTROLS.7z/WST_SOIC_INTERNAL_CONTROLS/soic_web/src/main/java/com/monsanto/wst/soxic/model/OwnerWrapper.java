/*
 * Created on Mar 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerWrapper {
	
	String ownerid;
	
	String emailid;
	
	String level;
	
	String dateString="";
	
	String subCycleString;
	
	String ownerName;

    String dueDateString;

    List subCycleList = new ArrayList();
    List dueDate = new ArrayList();

    public List getSubCycleList() {
        return subCycleList;
    }

    public void setSubCycleList(List subCycleList) {
        this.subCycleList = subCycleList;
    }


	/**
	 * @return Returns the ownerName.
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName The ownerName to set.
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return Returns the dateString.
	 */
	public String getDateString() {
		return dateString;
	}
	/**
	 * @param dateString The dateString to set.
	 */
	public void setDateString(String dateString) {
		this.dateString = dateString;
	}
	/**
	 * @return Returns the subCycleString.
	 */
	public String getSubCycleString() {
		return subCycleString;
	}
	/**
	 * @param subCycleString The subCycleString to set.
	 */
	public void setSubCycleString(String subCycleString) {
		this.subCycleString = subCycleString;
	}
	/**
	 * @return Returns the emailid.
	 */
	public String getEmailid() {
		return emailid;
	}
	/**
	 * @param emailid The emailid to set.
	 */
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	/**
	 * @return Returns the level.
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level The level to set.
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return Returns the ownerid.
	 */
	public String getOwnerid() {
		return ownerid;
	}
	/**
	 * @param ownerid The ownerid to set.
	 */
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	
	public void populate(ResultSet rs)throws Exception{
		setOwnerid(rs.getString("OWNER_ID"));
		setEmailid(rs.getString("EMAIL"));
		setDateString(rs.getString("DUE_DATE"));
		setSubCycleString(rs.getString("SUB_CYCLE_ID"));
		//setLevel(rs.getString("OWNER_ID"));
	}

    public void addSubToList(String subCycleId) {
        subCycleList.add(subCycleId);
    }

    public List getDueDate() {
        return dueDate;
    }

    public void setDueDate(List dueDate) {
        this.dueDate = dueDate;
    }

    public void addDueDateToList(String dueDateStr) {
        dueDate.add(dueDateStr);
    }

    public String getDueDateString() {
        return dueDateString;
    }

    public void setDueDateString(String dueDateString) {
        this.dueDateString = dueDateString;
    }
}
