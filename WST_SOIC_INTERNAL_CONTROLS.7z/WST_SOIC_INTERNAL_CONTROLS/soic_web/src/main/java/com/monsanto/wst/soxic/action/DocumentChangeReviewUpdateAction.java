package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.facade.DocumentChangeReviewFacade;
import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;
import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.util.List;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 28, 2005
 * Time: 11:56:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeReviewUpdateAction extends Action {

    public ActionForward execute(ActionMapping mapping,
			 ActionForm form,
			 HttpServletRequest request,
			 HttpServletResponse response) throws Exception{
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;
        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);
        DocumentChangeReviewFacade documentChangeReviewFacade = new DocumentChangeReviewFacade();
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW)){
            documentChangeReviewFacade.processUpdate(documentChangeReviewForm,owner);

        }else{
            documentChangeReviewFacade.process(documentChangeReviewForm,owner);
            setUpdateToFalse(request,documentChangeReviewForm);
        }
        request.setAttribute("processedActivity",documentChangeReviewForm.getIdentifier());
        return mapping.findForward(documentChangeReviewFacade.findForward(documentChangeReviewForm));
    }

    public void setUpdateToFalse(HttpServletRequest request,DocumentChangeReviewForm documentChangeReviewForm){

        ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm)request.getSession().getAttribute("controlObjectiveForm");
        List controlObjectiveList = (List)controlObjectiveForm.getControlObjectiveList();
        Iterator iterator = controlObjectiveList.iterator();
        while(iterator.hasNext()){
            ControlObjective controlObjective = (ControlObjective)iterator.next();

            Map activityList = controlObjective.getAssignedActivityMap();

            if(activityList!=null){
                Iterator activityIterator = activityList.values().iterator();
                while(activityIterator.hasNext()){
                     Activity activity = (Activity)activityIterator.next();
                    if(activity.getActivityId().equalsIgnoreCase(documentChangeReviewForm.getIdentifier())){
                        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE) ||documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
                            String docChangeIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+documentChangeReviewForm.getSource_type()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_MODIFY+SoxicUtil.getSeperator()+documentChangeReviewForm.getMode()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
                            String docRemoveIdentifier = activity.getActivityId()+SoxicUtil.getSeperator()+documentChangeReviewForm.getSource_type()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_REQUEST_DELETE+SoxicUtil.getSeperator()+documentChangeReviewForm.getMode()+SoxicUtil.getSeperator()+SoxicConstants.DOC_CHANGE_MODE_MODIFY_FALSE;
                            activity.setRequestChangeId(docChangeIdentifier);
                            activity.setRequestRemoveId(docRemoveIdentifier);
                        }
                    }
                }


            }
        }

    }
}
