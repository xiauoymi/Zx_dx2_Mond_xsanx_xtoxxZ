package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.exception.NewPeriodCreationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 24, 2005
 * Time: 4:36:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubCyclePeriodCreation {

    public static void main(String args[])throws Exception{
//
       SubCyclePeriodCreation subCyclePeriodCreation = new SubCyclePeriodCreation();
//
        long startTime,endTime,dif;
        startTime = System.currentTimeMillis();
        Connection connection=null;
        List subCycles = subCyclePeriodCreation.createSubCycle("FY05.","RAM01", connection);
        subCyclePeriodCreation.insertSubCycle(subCycles, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;

        startTime = System.currentTimeMillis();
        List questionSubCycles = subCyclePeriodCreation.createQuestionSubCycle("FY05.","RAM01", connection);
        subCyclePeriodCreation.insertQuestionSubCycle(questionSubCycles, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;

        startTime = System.currentTimeMillis();
        List ownerSubCycles = subCyclePeriodCreation.createOwnerSubCycle("FY05.","RAM01", connection);
        subCyclePeriodCreation.insertOwnerSubCycle(ownerSubCycles, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;
    }

    public List createSubCycle(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List subCycles = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            preparedStatement = connection.prepareStatement("SELECT S.SUB_CYCLE_ID, S.SUB_CYCLE_CODE, S.DESCRIPTION,S.OVERFLOW_ID FROM SUB_CYCLE S WHERE S.SUB_CYCLE_ID LIKE'%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateModel(rs,targetPeriodId);
                processSubCycle(subCycle,targetPeriodId);
                subCycles.add(subCycle);

            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
                throw new NewPeriodCreationException(e);
            }
        }
        return subCycles;
    }

    public List createOwnerSubCycle(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List subCycles = new ArrayList();

        PreparedStatement preparedStatement = null;        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            preparedStatement = connection.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC WHERE OSC.SUB_CYCLE_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateOwnerModel(rs);
                processSubCycle(subCycle, targetPeriodId);
                subCycles.add(subCycle);
            }
            //insertOwnerSubCycle(subCycle,targetCycleId,period);

        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return subCycles;
    }

    public List createQuestionSubCycle(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List subCycles = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            preparedStatement = connection.prepareStatement("SELECT QSC.SUB_CYCLE_ID,QSC.QUESTION_ID FROM QUESTION_SUB_CYCLE QSC WHERE QSC.SUB_CYCLE_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateQuestionModel(rs);
                processSubCycle(subCycle, targetPeriodId);
                subCycles.add(subCycle);
                //insertQuestionSubCycle(subCycle,targetCycleId,period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return subCycles;
    }

    public void insertOwnerSubCycle(List subCycles, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_SUB_CYCLE (OWNER_ID, SUB_CYCLE_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = subCycles.iterator();
            while(iterator.hasNext()){
                SubCycle subCycle = (SubCycle)iterator.next();
            preparedStatement.setString(1,subCycle.getOwnerId());
            preparedStatement.setString(2,subCycle.getSubCycleId());
            preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
            preparedStatement.setString(5,"ADMIN");
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }

    }

    public SubCycle populateModel(ResultSet rs,String targetPeriodId){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setSubCycleCode(rs.getString(SubCycle.SUB_CYCLE_CODE));
            subCycle.setDescription(rs.getString(SubCycle.DESCRIPTION));
            subCycle.setOverFlowId(rs.getInt(SubCycle.OVERFLOW_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public SubCycle populateOwnerModel(ResultSet rs){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setOwnerId(rs.getString(SubCycle.OWNERID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public SubCycle populateQuestionModel(ResultSet rs){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setQuestionId(rs.getString(SubCycle.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public void insertSubCycle(List subCycleList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO SUB_CYCLE (SUB_CYCLE_ID, SUB_CYCLE_CODE, CYCLE_ID, DESCRIPTION,OVERFLOW_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?,?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = subCycleList.iterator();
            while(iterator.hasNext()){
                SubCycle subCycle = (SubCycle)iterator.next();
                preparedStatement.setString(1,subCycle.getSubCycleId());
                preparedStatement.setString(2,subCycle.getSubCycleCode());
                preparedStatement.setString(3,subCycle.getCycleId());
                preparedStatement.setString(4,subCycle.getDescription());
                preparedStatement.setInt(5,subCycle.getOverFlowId());
                preparedStatement.setString(6,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(7,new Date(System.currentTimeMillis()));
                preparedStatement.setString(8,"ADMIN");
                preparedStatement.addBatch();
            }



            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void createControlObjectives(String sourceSubCycleId,String targetSubCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        //ControlObjectiveDAO controlObjectiveDAO = new ControlObjectiveDAO();
        DAO controlObjectiveDAO =  AbstractDAOFactory.getFactory().getControlObjectiveDAO();

        String query = "SELECT CTRL_OBJ_ID FROM CTRL_OBJ WHERE SUB_CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,sourceSubCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                ((OracleControlObjectiveDAO)controlObjectiveDAO).createControlObjective(rs.getString("CTRL_OBJ_ID"),targetSubCycleId,period);
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void insertQuestionSubCycle(List subCycles, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO QUESTION_SUB_CYCLE (QUESTION_ID, SUB_CYCLE_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            Iterator iterator = subCycles.iterator();
            while(iterator.hasNext()){
                SubCycle subCycle = (SubCycle)iterator.next();
                preparedStatement.setString(1,subCycle.getQuestionId());
                preparedStatement.setString(2,subCycle.getSubCycleId());
                //preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
                preparedStatement.setDate(3,new Date(System.currentTimeMillis()));
                preparedStatement.setString(4,"ADMIN");
                preparedStatement.addBatch();
            }


            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();

        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }



    public boolean isSubCycleOwner(Owner owner,String subCycleId){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;

        String query = "SELECT SUB_CYCLE_ID FROM OWNER_SUB_CYCLE OSC WHERE OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,owner.getOwnerId());
            preparedStatement.setString(2,subCycleId);
            rs= preparedStatement.executeQuery();
            while(rs.next()){
                return true;
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
        return false;
    }

    public void processSubCycle(SubCycle subCycle,String targetPeriodId){

        StringTokenizer st = new StringTokenizer(subCycle.getSubCycleId(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String subCycleId = st.nextToken();
        String targetCycleId = targetPeriodId+"."+countryId+"."+cycleId;
        String targetSubCycleId = targetPeriodId+"."+countryId+"."+cycleId+"."+subCycleId;
        subCycle.setSubCycleId(targetSubCycleId);
        subCycle.setCycleId(targetCycleId);
    }
}
