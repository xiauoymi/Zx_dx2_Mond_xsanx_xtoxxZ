package com.monsanto.wst.soxic.audit;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 1:51:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "SARBOX_ET",name = "CYCLE_STATE")
public class CycleStateObj implements Serializable {
    @Id
    @Column(name = "CYCLE_ID")
    private String cycleId;

    @Column(name = "PERIOD_ID")
    private String periodId;

    @Column(name = "STATE")
    private String state;

    public String getCycleId() {
      return cycleId;
    }

    public void setCycleId(String cycleId) {
      this.cycleId = cycleId;
    }

    public String getPeriodId() {
      return periodId;
    }

    public void setPeriodId(String periodId) {
      this.periodId = periodId;
    }

    public String getState() {
      return state;
    }

    public void setState(String state) {
      this.state = state;
    }

  
}
