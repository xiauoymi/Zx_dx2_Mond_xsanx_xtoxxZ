package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.model.HeaderFooterDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:19:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityHeadFootSet extends HeadFootSet{

    public void setHeaderAndFooter(QuestionAdminForm questionAdminForm, HeaderFooterFacade headerFooterFacade) {
        questionAdminForm.setActivityHeader(headerFooterFacade.getHeader());
        questionAdminForm.setActivityFooter(headerFooterFacade.getFooter());
    }

    public void updateHeaderIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getActivityHeader(), SoxicConstants.ACTIVITY_QUESTION_HEADER,SoxicConstants.QUESTION_HEADER);
    }

    public void updateFooterIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getActivityFooter(), SoxicConstants.ACTIVITY_QUESTION_FOOTER,SoxicConstants.QUESTION_FOOTER);
    }
}
