package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.form.QuestionAdminForm;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:03:11 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class HeadFootSet {

    public abstract void setHeaderAndFooter(QuestionAdminForm questionAdminForm, HeaderFooterFacade headerFooterFacade);

    public abstract void updateHeaderIntoDB(QuestionAdminForm questionAdminForm);

    public abstract void updateFooterIntoDB(QuestionAdminForm questionAdminForm);

}
