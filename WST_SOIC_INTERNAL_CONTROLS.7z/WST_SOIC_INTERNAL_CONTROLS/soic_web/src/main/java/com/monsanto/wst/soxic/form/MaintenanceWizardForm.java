package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 8, 2005
 * Time: 10:32:02 AM
 * To change this template use File | Settings | File Templates.
 */

public class MaintenanceWizardForm extends ActionForm {

    private String sourceOwner;
    private String sourceOwnerName;
    private String sourceOwnerEmail;

    private String destinationOwner;
    private String destinationOwnerName;
    private String destinationOwnerEmail;

    private String selectedAvailableOwner;
    private String selectedAvailableOwnerName;
    private String selectedAvailableOwnerEmail;

    private boolean cycleOwner ;
    private boolean subCycleOwner ;
    private boolean controlObjectiveOwner ;

    private List actions;
    private List ownerLevels;
    private List periods ;
    private List countries ;
    private List cycles ;
    private List subCycles ;
    private List controlObjectives;
    private List controlActivities;
    private List availableOwners;

    private String selectedAction;
    private String selectedOwnerLevel;
    private String selectedPeriod;
    private String selectedCountry;
    private String selectedCycle;
    private String selectedSubCycle;
    private String[] selectedControlObjectives;
    private String[] selectedControlActivities;

     /**
     * Current Level can be only Admin,Cycle or Sub cycle
     */
    private String currentOwnerLevel;
    /**
     * List containing all the sub cycles
     */
    private List overAllSubCycleList;
    /**
     * List of all activities
     */
    private List overAllActivitiyList;

    private List storedControlActivitiesforProcessing = new ArrayList();



    public String getSourceOwnerName() {
        return sourceOwnerName;
    }

    public void setSourceOwnerName(String sourceOwnerName) {
        this.sourceOwnerName = sourceOwnerName;
    }

    public String getSourceOwnerEmail() {
        return sourceOwnerEmail;
    }

    public void setSourceOwnerEmail(String sourceOwnerEmail) {
        this.sourceOwnerEmail = sourceOwnerEmail;
    }

    public String getDestinationOwnerName() {
        return destinationOwnerName;
    }

    public void setDestinationOwnerName(String destinationOwnerName) {
        this.destinationOwnerName = destinationOwnerName;
    }

    public String getDestinationOwnerEmail() {
        return destinationOwnerEmail;
    }

    public void setDestinationOwnerEmail(String destinationOwnerEmail) {
        this.destinationOwnerEmail = destinationOwnerEmail;
    }

    public String getSelectedAvailableOwnerName() {
        return selectedAvailableOwnerName;
    }

    public void setSelectedAvailableOwnerName(String selectedOwnerName) {
        this.selectedAvailableOwnerName = selectedOwnerName;
    }

    public String getSelectedAvailableOwnerEmail() {
        return selectedAvailableOwnerEmail;
    }

    public void setSelectedAvailableOwnerEmail(String selectedOwnerEmail) {
        this.selectedAvailableOwnerEmail = selectedOwnerEmail;
    }

    public List getStoredControlActivitiesforProcessing() {
        return storedControlActivitiesforProcessing;
    }

    public void addToStoredControlActivitiesforProcessing(String[] in_strActivities) {

        for (int i = 0; i < in_strActivities.length; i++) {
            if (storedControlActivitiesforProcessing.contains(in_strActivities[i])) {
            } else {
                storedControlActivitiesforProcessing.add(in_strActivities[i]);
            }
        }
    }

    public void removeFromStoredControlActivitiesforProcessing(List in_lstActivities) {
        storedControlActivitiesforProcessing.removeAll(in_lstActivities);
    }

    public void clearAllStoredControlActivitiesforProcessing() {
        storedControlActivitiesforProcessing.clear();
    }


    public String getSourceOwner() {
        return sourceOwner;
    }

    public void setSourceOwner(String sourceOwner) {
        if ( sourceOwner != null ) {
            this.sourceOwner = sourceOwner.toUpperCase().trim();
        }
        else{
           this.sourceOwner = sourceOwner;
        }
    }

    public String getDestinationOwner() {
        return destinationOwner;
    }

    public void setDestinationOwner(String destinationOwner) {

        if ( destinationOwner != null ) {
            this.destinationOwner = destinationOwner.toUpperCase().trim();
        }
        else{
           this.destinationOwner = destinationOwner;
        }
    }

    public String getSelectedOwnerLevel() {
        return selectedOwnerLevel;
    }

    public void setSelectedOwnerLevel(String selectedOwnerLevel) {
        this.selectedOwnerLevel = selectedOwnerLevel;
    }

    public boolean isSubCycleOwner() {
        return subCycleOwner;
    }

    public void setSubCycleOwner(boolean subCycleOwner) {
        this.subCycleOwner = subCycleOwner;
    }

    public boolean isControlObjectiveOwner() {
        return controlObjectiveOwner;
    }

    public void setControlObjectiveOwner(boolean controlObjectiveOwner) {
        this.controlObjectiveOwner = controlObjectiveOwner;
    }

    public List getControlObjectives() {
        return controlObjectives;
    }

    public void setControlObjectives(List controlObjectives) {
        this.controlObjectives = controlObjectives;
    }

    public List getControlActivities() {
        return controlActivities;
    }

    public void setControlActivities(List controlActivities) {
        this.controlActivities = controlActivities;
    }

    public List getAvailableOwners() {
        return availableOwners;
    }

    public void setAvailableOwners(List availableOwners) {
        this.availableOwners = availableOwners;
    }

    public String[] getSelectedControlObjectives() {
        return selectedControlObjectives;
    }

    public void setSelectedControlObjectives(String[] selectedControlObjectives) {
        this.selectedControlObjectives = selectedControlObjectives;
    }

    public String[] getSelectedControlActivities() {
        return selectedControlActivities;
    }

    public void setSelectedControlActivities(String[] selectedControlActivities) {
        this.selectedControlActivities = selectedControlActivities;
    }

    public String getSelectedAvailableOwner() {
        return selectedAvailableOwner;
    }

    public void setSelectedAvailableOwner(String selectedAvailableOwner) {

         if ( selectedAvailableOwner != null ) {
            this.selectedAvailableOwner = selectedAvailableOwner.toUpperCase().trim();
        }
        else{
           this.selectedAvailableOwner = selectedAvailableOwner;
        }


    }


    public List getPeriods() {
        return periods;
    }

    public void setPeriods(List periods) {
        this.periods = periods;
    }

    public List getCountries() {
        return countries;
    }

    public void setCountries(List countries) {
        this.countries = countries;
    }

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public List getSubCycles() {
        return subCycles;
    }

    public void setSubCycles(List subCycles) {
        this.subCycles = subCycles;
    }

    public String getSelectedPeriod() {
        return selectedPeriod;
    }

    public void setSelectedPeriod(String selectedPeriod) {
        this.selectedPeriod = selectedPeriod;
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public String getSelectedCycle() {
        return selectedCycle;
    }

    public void setSelectedCycle(String selectedCycle) {
        this.selectedCycle = selectedCycle;
    }

    public String getSelectedSubCycle() {
        return selectedSubCycle;
    }

    public void setSelectedSubCycle(String selectedSubCycle) {
        this.selectedSubCycle = selectedSubCycle;
    }

    public List getActions() {
        return actions;
    }

    public void setActions(List in_actions) {
        this.actions = in_actions;
    }

    public String getSelectedAction() {
        return selectedAction;
    }

    public void setSelectedAction(String in_selectedAction) {
        this.selectedAction = in_selectedAction;
    }

    public List getOwnerLevels() {
        return ownerLevels;
    }

    public void setOwnerLevels(List in_ownerlevels) {
        this.ownerLevels = in_ownerlevels;
    }

    public boolean isCycleOwner() {
        return cycleOwner;
    }

    public void setCycleOwner(boolean cycleOwner) {
        this.cycleOwner = cycleOwner;
    }

    public String getCurrentOwnerLevel() {
        return currentOwnerLevel;
    }

    public void setCurrentOwnerLevel(String currentOwnerLevel) {
        this.currentOwnerLevel = currentOwnerLevel;
    }

    public List getOverAllSubCycleList() {
        return overAllSubCycleList;
    }

    public void setOverAllSubCycleList(List overAllSubCycleList) {
        this.overAllSubCycleList = overAllSubCycleList;
    }

    public List getOverAllActivitiyList() {
        return overAllActivitiyList;
    }

    public void setOverAllActivitiyList(List overAllActivitiyList) {
        this.overAllActivitiyList = overAllActivitiyList;
    }
}
