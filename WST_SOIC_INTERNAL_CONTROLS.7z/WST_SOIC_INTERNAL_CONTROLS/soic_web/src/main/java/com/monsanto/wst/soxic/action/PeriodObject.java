/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PeriodObject {
	
	private String periodID;
	private int totalDefRef;
	private int openDefRef;
	
	

	/**
	 * @return Returns the openDefRef.
	 */
	public int getOpenDefRef() {
		return openDefRef;
	}
	/**
	 * @param openDefRef The openDefRef to set.
	 */
	public void setOpenDefRef(int openDefRef) {
		this.openDefRef = openDefRef;
	}
	
	public void incOpenDefRef(int val) {
		openDefRef += val;
	}
	
	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}
	/**
	 * @return Returns the totalDefRef.
	 */
	public int getTotalDefRef() {
		return totalDefRef;
	}
	/**
	 * @param totalDefRef The totalDefRef to set.
	 */
	public void setTotalDefRef(int totalDefRef) {
		this.totalDefRef = totalDefRef;
	}
	
	public void incTotalDefRef(int val) {
		totalDefRef += val;
	}
	
}
