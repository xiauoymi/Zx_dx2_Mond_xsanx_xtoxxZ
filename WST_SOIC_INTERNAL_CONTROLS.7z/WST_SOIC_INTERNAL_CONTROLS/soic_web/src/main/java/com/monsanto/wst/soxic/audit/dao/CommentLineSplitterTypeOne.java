package com.monsanto.wst.soxic.audit.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.soxic.audit.util.PatternMatcher;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 15, 2009
 * Time: 6:41:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommentLineSplitterTypeOne implements CommentLineSplitter {
  private static final String MR_RP_NOTPRESENT = "MR_RP_NOTPRESENT";

  public String[] getEachCommentAsAString(String issueChunk, String type) throws StringSplitException {
    issueChunk = issueChunk.replace("Audit Comment Report","");
    issueChunk = issueChunk.replace("MAJOR 1 OF","Major 1 of");
    String memoCommentsDelimiter = type+"1 of";
    String typeDelimiter = "Type:";

    String majorCount = getData(memoCommentsDelimiter, typeDelimiter, issueChunk);
    String[] data =null;
    if(!StringUtils.isNullOrEmpty(majorCount)){
      if(majorCount.trim().contains(":")){
        int count = Integer.parseInt(majorCount.replaceAll(":","").trim());
        data = new String[count];
        for(int j=0;j<count;j++){
          String start = type+ (j+1) + " of " + count;
          String end = type+ (j+2) + " of " + count;
          data[j]= getDataModified(start, end, issueChunk);
        }
      }
    }
    return data;

  }

  private static HashMap<String,String> userCatMap;


  public CommentLineSplitterTypeOne() {
      populateUserCatMap();
  }

  private String getData(String start, String end, String issueChunk) throws StringSplitException {
//     return issueChunk;
    try{
    if(StringUtils.isNullOrEmpty(end)){
      return issueChunk.substring(issueChunk.indexOf(start)+start.length());
    }
//    int endIndex = getEndIndex(issueChunk, end);
    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),issueChunk.indexOf(end));
    }catch(Exception e){
      throw new StringSplitException("Error splitting: Start -"+start+" End -"+end, e);
    }

  }

  private String getDataModified(String start, String end, String issueChunk) {
//     return issueChunk;
    if(StringUtils.isNullOrEmpty(end)){
      return issueChunk.substring(issueChunk.indexOf(start)+start.length());
    }
    int endIndex = getEndIndex(issueChunk, end);
//    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),issueChunk.indexOf(end));
    return issueChunk.substring(issueChunk.indexOf(start)+start.length(),endIndex);
  }

  private int getEndIndex(String issueChunk, String endString) {
    int endIndex = issueChunk.indexOf(endString);
    if(endIndex<0){
      return issueChunk.length();
    }
    return endIndex;
  }

// Comment Title: 	Inadequate segregation of duties in the journal entry process 
//Comment Subject: 	Segregation of duties 
//Observation: 	While reviewing the process for journal entries it was identified that one individual has access to prepare, key and approve their own journal entries with no additional approval needed. In the past any journal entry posted by this individual would be approved by the controller, but since the controller left the company at the end of August this approval process has not been followed. Once the JE is entered and approved in JD Edwards it will get posted by the Systems Analyst or a batch process will run at the end of the night and post all journal entries that have been approved.  It was also observed that one power user has access to multiple screens and the access privileged within them are too generic and provide inadequate security and segregation of duties controls. This user reviews integrity reports, which show out of balance amounts between two systems (for example: Inventory to GL) and will then go into the system and add a line to the additional entry to make the system balance. Currently there is no process in place to approve these types of entries.   
//Cause: 	FIN - Segregation of Duties 
//Recommendation: 	Internal audit recommends that the functions of preparing and keying journal entries be segregated from the approval of journal entries and that integrity reports be reviewed by an independent person with any adjutments being explained within the integrity report or correcting entry. For Sarbanes Oxley purposes internal audit is also recommending that the process for preparing, keying and approving entries, both on paper and in the system be identified, documented and followed.  
//Risk: 	The lack of segregation of duties could result in unapproved transactions being made, which increases the likelihood of fraud and financial loss to the company.  
//Repeat Flag: 	N   Associated Activities  FIN.03..01	Select an adequate sample of journal entries for detail testing based on total population from site. Select appropriate amount based on frequency of entries. Focus on high dollar or critical accounts.  2> 
//Type: 

  public List buildXML(String[] data, StringBuffer issuesBuffer, String originTitle, StringBuffer errorBuffer) throws Exception, StringSplitException {
    String[] delimiters = new String[]{"Type:","Comment Title:",
            "Comment Subject:","Observation:","Management Response:","Responsible Party:",
            "Cause:","Recommendation:","Risk:","Repeat Flag:","Associated Activities"};
    String typeStr= "";
    String titleStr= "";
    String textField4 = "";
    String finding = "";
    String textField2 = "";
    String userCat2 = "";
    String textField1 = "";
    String textField3= "";
    String textField10= "";
    String issueChunk= "";
    List issueList = new ArrayList();
    for(int i=0;i<data.length;i++){
      issueChunk = data[i].trim();
      String returnString = checkForDuplicateDelimiters(issueChunk,delimiters,i,data.length);
      if("NONE".equals(returnString)){
//        typeStr = getData(delimiters[0], delimiters[1], issueChunk);
        String condition = getCondition(issueChunk);
        if(condition!=null && condition.equalsIgnoreCase(MR_RP_NOTPRESENT)){
          typeStr = "Major";
          titleStr = getData(delimiters[1], delimiters[2], issueChunk);
          textField4 = getData(delimiters[2], delimiters[3], issueChunk);
          finding = getData(delimiters[3], delimiters[6], issueChunk);
          //mr
          textField2 = "";
//          textField2 = getData(delimiters[4], delimiters[5], issueChunk);
          userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
          textField1 = getData(delimiters[7], delimiters[8], issueChunk);
          textField3 = getData(delimiters[8], delimiters[9], issueChunk);
          textField10 = getData(delimiters[10],"", issueChunk);
          

        } else{

          typeStr = "Major";
          titleStr = getData(delimiters[1], delimiters[2], issueChunk);
          textField4 = getData(delimiters[2], delimiters[3], issueChunk);
          finding = getData(delimiters[3], delimiters[4], issueChunk);
          textField2 = getData(delimiters[4], delimiters[5], issueChunk);
          userCat2 = getData(delimiters[6], delimiters[7], issueChunk);
          textField1 = getData(delimiters[7], delimiters[8], issueChunk);
          textField3 = getData(delimiters[8], delimiters[9], issueChunk);
          textField10 = getData(delimiters[10],"", issueChunk);
        }
        Issue issue1 = constructIssueSection(issuesBuffer, typeStr, titleStr, textField4, finding, textField2, userCat2, textField1, textField3, originTitle, textField10);
        issueList.add(issue1);
      }else{
        errorBuffer.append(returnString);
      }
    }
    return issueList;
  }

  private String getCondition(String issueChunk) {
    if(issueChunk.indexOf("Management Response:")==-1
            && issueChunk.indexOf("Responsible Party:")==-1
             ) {
      return MR_RP_NOTPRESENT;
    }

    return null;  //To change body of created methods use File | Settings | File Templates.
  }

  private Issue constructIssueSection(StringBuffer issuesBuffer, String typeStr, String titleStr,
                                     String textField4, String finding, String textField2, String userCat2,
                                     String textField1, String textField3, String originTitle, String textField10) {
    Issue issue = new Issue();
    issue.setIssueId("1000");
    issue.setTitle(replaceOccurences(titleStr.trim()));
    issue.setType(replaceOccurences(typeStr.trim()));
    issue.setTextField4(replaceOccurences(textField4.trim()));
    issue.setFinding(replaceOccurences(finding.trim()));
    issue.setTextField2(replaceOccurences(textField2.trim()));
    issue.setTextField1(replaceOccurences(textField1.trim()));
    issue.setTextField3(replaceOccurences(textField3.trim()));
    issue.setTextField10(replaceOccurences(textField10.trim()));
    issue.setArea(originTitle);
    issue.setUserCat2(appendUserCat2(issuesBuffer, userCat2, issue));
    appendIssueTag(issuesBuffer);
    issuesBuffer.append("<TITLE>"+replaceOccurences(titleStr.trim())+"</TITLE>");
    issuesBuffer.append("<TYPE ID=\"67108931\">"+replaceOccurences(typeStr.trim())+"</TYPE>");
    issuesBuffer.append("<TEXTFIELD4 Format=\"text\">"+replaceOccurences(textField4.trim())+"</TEXTFIELD4>");
    issuesBuffer.append("<FINDING Format=\"text\">"+replaceOccurences(finding.trim())+"</FINDING>");
    issuesBuffer.append("<TEXTFIELD2 Format=\"text\">"+replaceOccurences(textField2.trim())+"</TEXTFIELD2>");
    appendUserCat2(issuesBuffer, userCat2, issue);
    issuesBuffer.append("<TEXTFIELD1 Format=\"text\">"+replaceOccurences(textField1.trim())+"</TEXTFIELD1>");
    issuesBuffer.append("<TEXTFIELD3 Format=\"text\">"+replaceOccurences(textField3.trim())+"</TEXTFIELD3>");
    issuesBuffer.append("<TEXTFIELD10 Format=\"text\">"+replaceOccurences(textField10.trim())+"</TEXTFIELD10>");
    issuesBuffer.append("<ORIGIN><AREA ID=\"-1207959550\">"+originTitle+"</AREA></ORIGIN>");
    issuesBuffer.append("</ISSUE>");
    return issue;
  }

  public String checkForDuplicateDelimiters(String issueChunk, String[] delimiters, int majorIndex, int length) {
    int count = 0;
    int index = 0;
    StringBuffer tempBuffer = new StringBuffer();
    for(int i=0;i<delimiters.length;i++){
      count = 0;
      index = 0;
      while ((index = issueChunk.indexOf(delimiters[i], index)) != -1) {
        ++index;
        ++count;
      }
      if(count > 1){
        tempBuffer.append("Major "+(majorIndex+1)+" of "+length+",\t"+delimiters[i]+"\n");
      }
    }
    if(tempBuffer.length() > 0 ) return tempBuffer.toString();
    return "NONE";
  }

  private static String replaceOccurences(String description) {
    return PatternMatcher.findAndReplace(description);
  }

  private String appendUserCat2(StringBuffer issuesBuffer, String userCat2, Issue issue) {
    String userCat2Desc = replaceOccurences(userCat2.trim());
    issue.setUserCat2(userCat2Desc);
    issuesBuffer.append("<USERCAT2 ID=\""+userCatMap.get(userCat2Desc)+"\">"+userCat2Desc+"</USERCAT2>");
    String id = userCatMap.get(userCat2Desc);
    issue.setUserCat2Id(id);
    return id;
  }

  private void populateUserCatMap() {
    if(userCatMap == null){
      userCatMap = new HashMap<String,String>();
      //FIN
      userCatMap.put("FIN - Compliance with Policy and Laws","1275068482");
      userCatMap.put("FIN-Reconciliation & Review","1275068487");
      userCatMap.put("FIN-Revenue/Receivables","1275068472");
      userCatMap.put("FIN-Approval","1275068422");
      userCatMap.put("FIN-FCPA & Management Practices","1275068456");
      userCatMap.put("FIN-General Ledger","1275068460");
      userCatMap.put("FIN-Classification","1275068480");
      userCatMap.put("FIN-Inventory - Seed","1275068463");
      userCatMap.put("FIN-DOA","67108959");
      userCatMap.put("FIN-Valuation","1275068489");
      userCatMap.put("FIN-Timing","1275068488");
      userCatMap.put("FIN-Procurement","1275068470");
      userCatMap.put("FIN-Segregation of Duties","67108960");
      userCatMap.put("FIN-Contracts","1275068450");
      userCatMap.put("FIN-Comply with Contract","1275068481");
      userCatMap.put("FIN-Inventory","1275068464");
      userCatMap.put("FIN-Other","1275068485");
      userCatMap.put("FIN-Asset Safegurading","1275068510");
      //test
      userCatMap.put("FIN - Approval","1275068422");
      userCatMap.put("FIN - Asset Safeguarding","1275068510");
      userCatMap.put("FIN - Reconciliation and Review","1275068487");




      //IT
      userCatMap.put("IT-Windows Security","1275068478");
      userCatMap.put("IT-Process Control","1275068469");
      userCatMap.put("IT-SAP Security","1275068473");
      userCatMap.put("IT-System Development & Maint.","1275068474");
      userCatMap.put("IT-Database Security - ORACLE","1677721597");
      userCatMap.put("IT-Backup & Recovery","1275068449");
      userCatMap.put("IT-Exchange","1275068458");
      userCatMap.put("IT-Network","1275068466");
      userCatMap.put("IT-Database Security - SQL","-1677721598");
      userCatMap.put("IT-Wireless Networking","1275068479");

    }

  }

  private void appendIssueTag(StringBuffer issuesBuffer) {
//    issuesBuffer.append("<ISSUE ID=\""+String.valueOf(issueId++)+"\">");
  }

}
