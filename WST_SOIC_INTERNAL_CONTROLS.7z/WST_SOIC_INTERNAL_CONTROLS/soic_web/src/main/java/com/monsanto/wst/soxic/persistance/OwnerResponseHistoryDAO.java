/*
 * Created on May 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerResponseHistory;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerResponseHistoryDAO {
	
	/**
	 * Whenever the user changes the response an entry is added to the owner response table
	 * @param ownerResponseHistoryIn
	 * @return
	 * @throws Exception
	 */
	public void insert(OwnerResponseHistory ownerResponseHistoryIn)throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection
					.prepareStatement("INSERT INTO OWNER_RESPONSE_HISTORY (RESPONSE_ID,RESPONSE,MOD_DATE,MOD_USER) VALUES(?,?,?,?)");
			preparedStatement.setString(1, ownerResponseHistoryIn.getResponseId());
			preparedStatement.setString(2, ownerResponseHistoryIn.getResponse());
			preparedStatement.setDate(3, new Date(System.currentTimeMillis()));
			preparedStatement.setString(4, ownerResponseHistoryIn.getOwnerid());
			//int result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException(
						"OracleDAO - Unable to close database connection : "
								+ e.toString());
			}
		}	
	}
}
