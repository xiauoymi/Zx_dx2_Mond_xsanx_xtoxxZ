package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 10, 2006
 * Time: 1:53:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CostInvalidException extends Exception {

    public CostInvalidException(){
		super();
	}

	public CostInvalidException(Exception e){
		super(e);
	}

}
