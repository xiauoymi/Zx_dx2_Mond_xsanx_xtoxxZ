package com.monsanto.wst.soxic.workflow.DocumentChangeOperations;

import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;

import java.util.List;
import java.util.Iterator;
import java.util.Date;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 8:33:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class IAAdminDocumentChangeRequestEmailer {

    public void process(DocumentChangeRequestResponseListInt documentChangeRequestResponseList){
        documentChangeRequestResponseList.processEmails();
        documentChangeRequestResponseList.sendEmails();

    }

}
