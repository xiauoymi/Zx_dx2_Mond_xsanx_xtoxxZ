package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import org.w3c.dom.Text;
import com.monsanto.AbstractLogging.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 1:44:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class SoxDOMUtil {

            /**
     * <P>Creates a child element with a given name and text content and adds it
     * to a given parent element.</P>
     * <P>Note that the parent must already be directly or indirectly attached
     * to a Document.</P>
     * <p/>
     * <P><B>To be deprecated ~12/2004.  </B>
     * Use {@link com.monsanto.XMLUtil.DOMUtil#addChildElementWithNS(String cstrNamespaceURL, org.w3c.dom.Node parent, String cstrChildElementName, String cstrValue)}</P>
     *
     * @param parent               the parent Node (should be an Element)
     * @param cstrChildElementName the name of the child Element to be created
     * @param cstrText             the text value of the child Element
     * @return the new child Element
     * @see com.monsanto.XMLUtil.Test.DOMUtil_UT#testAddChildElementWithText()
     *      <p/>
     *      deprecated Use {@link com.monsanto.XMLUtil.DOMUtil#addChildElementWithNS(String cstrNamespaceURL, org.w3c.dom.Node parent, String cstrChildElementName, String cstrValue)}
     */
    public static Element addCDATAChildElement(Node parent, String cstrChildElementName, String cstrText) {
        Logger.traceEntry();

        Element childElement;

        final Document doc = parent.getNodeType() == Node.DOCUMENT_NODE ? (Document) parent : parent.getOwnerDocument();
        childElement = doc.createElement(cstrChildElementName);
        parent.appendChild(childElement);

        if (cstrText != null) {
            final Text textNode = doc.createCDATASection(cstrText);
            childElement.appendChild(textNode);
        }

        return (Element) Logger.traceExit(childElement);
    }
}
