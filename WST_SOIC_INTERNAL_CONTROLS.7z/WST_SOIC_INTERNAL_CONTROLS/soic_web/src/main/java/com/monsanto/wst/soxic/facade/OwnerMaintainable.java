package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.exception.OwnerAlreadyExistsException;
import com.monsanto.wst.soxic.exception.NullControlObjectiveException;
import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 16, 2005
 * Time: 9:43:57 AM
 * To change this template use File | Settings | File Templates.
 */
public interface OwnerMaintainable {
    /**
     * Based on who logs into the system the form variables are set
     * If Admin logs into the system he wll be able to administer Cycle , Sub cycle and Activity owners
     * If Cycle owner logs into the system he will be able to administer Sub cycle and Activity owners
     * If Sub cycle owner logs into the system he will be able to administer Activity owners
     * @param form
     * @param owner
     */
    public void setOwnerLevel(ActionForm form,Owner owner);

    /**
     * Based on what the user selects the following filter criteria are set
     * All the periods except COMPLETE_CERTIFICATION will be populated
     * Based on the period selected and based on the owner the cycles will be populated
     * Based on the period selected ,owner and cylce selected sub cycle will be populated
     * @param form
     * @param owner
     */
    //public void setFilterCriteria(ActionForm form,Owner owner);

    public void setPeriodFilterCriteria(ActionForm form,Owner owner)throws OwnerAlreadyExistsException;

    public void setCountryFilterCriteria(ActionForm form,Owner owner);

    public void setCycleFilterCriteria(ActionForm form,Owner owner);

    public void setSubCycleFilterCriteria(ActionForm form,Owner owner);

    /**
     *Based on Period , cycle and sub cycle control objectives are populated
     * @param form
     * @param owner
     */
    public void populateControlObjectives(ActionForm form,Owner owner)throws NullControlObjectiveException;

    /**
     *Based on control objective the activities are populated
     * @param form
     * @param owner
     */
    public void populateActivities(ActionForm form,Owner owner);

    
}
