package com.monsanto.wst.soxic.audit.dao;

import com.monsanto.wst.soxic.audit.SubCycleObj;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 8, 2008
 * Time: 10:32:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class StringSubCycleExportDAOImpl implements ExportSubCycleDAO {
  private Session session;
  public StringSubCycleExportDAOImpl(Session session) {
    this.session = session;
  }

  public List<SubCycleObj> getSubCycleObjs(String searchCriteria) throws Exception{
    session.beginTransaction();
    Criteria subCycleCriteria = session.createCriteria(SubCycleObj.class);
    subCycleCriteria.add(Expression.like(SoxicConstants.SUB_CYCLE_ID, searchCriteria+"%"));
    subCycleCriteria.addOrder(Order.asc(SoxicConstants.SUB_CYCLE_ID));
    List<SubCycleObj> subCycleList = subCycleCriteria.list();

    return subCycleList;
  }

}
