/*
 * Created on Feb 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SoxicPathUtil {

	
	/**
	 * @param request
	 * @return
	 */
	public static String returnForward(HttpServletRequest request) {

		String forwardToReturn = null;
		Map map = request.getParameterMap();

		Iterator iter = map.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = map.get(key);

			String[] valueArr = (String[]) value;

			if (valueArr[0].equalsIgnoreCase("Save")) {

				return "save";
			}

			if (valueArr[0].equalsIgnoreCase("Submit")) {

				return "submit";
			}
		}

		return "newcycle";
	}
	
	/**
	 * @param request
	 * @return
	 */
	public static String getOperation(HttpServletRequest request) {

		String forwardToReturn = null;
		Map map = request.getParameterMap();

		Iterator iter = map.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = map.get(key);

			String[] valueArr = (String[]) value;

			if (valueArr[0].equalsIgnoreCase("Save")) {

				return "save";
			}

			if (valueArr[0].equalsIgnoreCase("Submit")) {

				return "submit";
			}
		}

		return "newcycle";
	}
	
	/**
	 * @param request
	 * @param valueIn
	 * @return
	 */
	public static String getKey(HttpServletRequest request,String valueIn){

		Map map = request.getParameterMap();

		Iterator iter = map.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = map.get(key);

			String[] valueArr = (String[]) value;

			if (valueArr[0].equalsIgnoreCase(valueIn)) {

				return (String)key;
			}
		}
		
		return null;
	}
	
	/**
	 * @return
	 */
	public Properties getPropertyFile(){
		boolean useClasspath=true;
		
		Properties props = new Properties();
		InputStream in;
		try {
			if (useClasspath) {
				in = getClass().getClassLoader().getResourceAsStream("src/com/monsanto/soxic/properties/DatabaseResources.properties");
	

				//in = getClass().getClassLoader().getResourceAsStream("DatabaseResources.properties");
			} else {
				in = new FileInputStream("example.properties");
			}

			props.load(in);
			String pro=props.getProperty("ownerSubcycle");
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return props;
	}
}
