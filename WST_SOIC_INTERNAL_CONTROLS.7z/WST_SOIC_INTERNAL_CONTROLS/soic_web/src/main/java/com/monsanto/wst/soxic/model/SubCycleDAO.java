/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicQueryUtil;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class SubCycleDAO {

	public static List getAllSubCycles(String ownerId) {

		List subCycles = new ArrayList();

		//subCycles.add(new MockSubCycle(ownerId + " SubCycle 1111"));
		//		subCycles.add(new MockSubCycle(ownerId + " SubCycle 2222"));
		//		subCycles.add(new MockSubCycle(ownerId + " SubCycle 3333"));

		return subCycles;
	}

	/**
	 * returns a list subcycles objects for a particular owner
	 */
	public static List getSubCycles(String ownerid,String state) throws Exception{
		
		List subCycleList = new ArrayList();
		
		Connection con = null;
		PreparedStatement retrieveSubcycleList=null,currentPeriod=null;
		ResultSet rs=null,rs1=null;
		String period ="";
		
		
		try {
			//Get the connection to the database
			con = SoxicConnectionFactory.getSoxicConnection();
			UtilDAO utilDAO = new UtilDAO();
			period = utilDAO.getCurrentActivePeriod();
			
			SoxicQueryUtil queryUtil = new SoxicQueryUtil();

			String query = queryUtil.getQueryByName("subcyclesforactivities",state);

			retrieveSubcycleList = con
					.prepareStatement(query);
			
			//SoxicQueryUtil queryUtil = new SoxicQueryUtil();

			//String query = queryUtil.getQueryByName("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND SC.SUB_CYCLE_ID LIKE '%"+period+"%'ORDER BY SC.SUB_CYCLE_ID");
			//String query = queryUtil.getQueryByName("subcyclesforactivities");

//			retrieveSubcycleList = con
//					.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND SC.SUB_CYCLE_ID LIKE '%"+period+"%'ORDER BY SC.SUB_CYCLE_ID");

            if(state.equalsIgnoreCase(SoxicConstants.CERTIFICATION_STATE)){
                retrieveSubcycleList.setString(1, SoxicConstants.CERTIFICATION_STATE);
            }else{
                retrieveSubcycleList.setString(1, SoxicConstants.DOCCHANGE_STATE);
            }
             retrieveSubcycleList.setString(2, ownerid);
			//Get the subcycle id and description from the result set
			rs = retrieveSubcycleList.executeQuery();
			while (rs.next()) {
				subCycleList.add(populateSubCycle(rs,state));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(retrieveSubcycleList);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subCycleList;
	}

	/**
	 * returns a list subcycles objects for a particular owner
	 */
	public static List getSubCyclesForDocChangeStateAsSubCycleOwner(String ownerid,String state) throws Exception{

		List subCycleList = new ArrayList();

		Connection con = null;
		PreparedStatement preparedStatement=null;
		ResultSet rs=null,rs1=null;

		try {

			con = SoxicConnectionFactory.getSoxicConnection();


			preparedStatement = con.prepareStatement("SELECT SC.SUB_CYCLE_ID,SC.CYCLE_ID,SC.DESCRIPTION,OSC.STATUS,CS.STATE FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS WHERE OSC.OWNER_ID = ? AND CS.CYCLE_ID=SC.CYCLE_ID AND OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND CS.STATE='RELEASED'");


            preparedStatement.setString(1, ownerid);
			//Get the subcycle id and description from the result set
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				subCycleList.add(populateSubCycle(rs,state));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subCycleList;
	}

    public static List selectAllSubCycles(String state){
        List allSubCycles = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            preparedStatement = connection.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS,SC.CYCLE_ID,CS.STATE FROM CTRL_OBJ CO,SUB_CYCLE SC,ACTIVITY A,OWNER_ACTIVITY OA,CYCLE_STATE CS WHERE CS.CYCLE_ID = SC.CYCLE_ID AND CS.STATE=? AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID ORDER BY SC.SUB_CYCLE_ID");
            if(state.equalsIgnoreCase(SoxicConstants.CERTIFICATION_STATE)){
                preparedStatement.setString(1, SoxicConstants.CERTIFICATION_STATE);
            }else{
                preparedStatement.setString(1, SoxicConstants.DOCCHANGE_STATE);
            }
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				allSubCycles.add(populateSubCycle(rs,state));
			}

        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return allSubCycles;

    }

    public static List selectAllSubCyclesForIAAndAdminForDocChange(){
        List allSubCycles = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            preparedStatement = connection.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS,SC.CYCLE_ID,CS.STATE FROM CTRL_OBJ CO,SUB_CYCLE SC,ACTIVITY A,OWNER_ACTIVITY OA,CYCLE_STATE CS WHERE CS.CYCLE_ID = SC.CYCLE_ID AND (CS.STATE='RELEASED' OR CS.STATE='LOCKED') AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID ORDER BY SC.SUB_CYCLE_ID");
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				allSubCycles.add(populateSubCycle(rs,SoxicConstants.DOCCHANGE_STATE));
			}

        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return allSubCycles;

    }

    	/**
	 * returns a list subcycles objects for a particular owner
	 */
	public static List getSubCycles(String ownerid) throws Exception{

		List subCycleList = new ArrayList();

		Connection con = null;
		PreparedStatement retrieveSubcycleList=null,currentPeriod=null;
		ResultSet rs=null,rs1=null;
		String period ="";


		try {
			//Get the connection to the database
			con = SoxicConnectionFactory.getSoxicConnection();
			UtilDAO utilDAO = new UtilDAO();
			period = utilDAO.getCurrentActivePeriod();

			SoxicQueryUtil queryUtil = new SoxicQueryUtil();

			//String query = queryUtil.getQueryByName("subcyclesforactivities",state);

			retrieveSubcycleList = con
					.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS,CS.STATE FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA,CYCLE_STATE CS WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND SC.CYCLE_ID=CS.CYCLE_ID ORDER BY SC.SUB_CYCLE_ID");

			//SoxicQueryUtil queryUtil = new SoxicQueryUtil();

			//String query = queryUtil.getQueryByName("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND SC.SUB_CYCLE_ID LIKE '%"+period+"%'ORDER BY SC.SUB_CYCLE_ID");
			//String query = queryUtil.getQueryByName("subcyclesforactivities");

//			retrieveSubcycleList = con
//					.prepareStatement("SELECT DISTINCT SC.SUB_CYCLE_ID,SC.DESCRIPTION,SC.STATUS FROM CTRL_OBJ CO, SUB_CYCLE SC, ACTIVITY A,OWNER_ACTIVITY OA WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND OA.OWNER_ID=? AND OA.ACTIVITY_ID=A.ACTIVITY_ID AND SC.SUB_CYCLE_ID LIKE '%"+period+"%'ORDER BY SC.SUB_CYCLE_ID");




             retrieveSubcycleList.setString(1, ownerid);
			//Get the subcycle id and description from the result set
			rs = retrieveSubcycleList.executeQuery();
			while (rs.next()) {
				subCycleList.add(populateSubCycle(rs,""));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(retrieveSubcycleList);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subCycleList;
	}

	/**
	 * Method returns true if all the sub-cycle owners has completed certification.
	 * (ie If the sub-cycle is complete)
	 * @param subCycleId
	 * @return
	 * @throws Exception
	 */
	public static boolean isSubCycleLocked(String subCycleId) throws Exception {

		boolean subCycleLoked = false;

		Connection con = null;		
		PreparedStatement retrieveSubCycleLock=null;		
		ResultSet rs=null;
		
		try {

			con = SoxicConnectionFactory.getSoxicConnection();
			
			SoxicQueryUtil queryUtil = new SoxicQueryUtil();

			String query = queryUtil.getQueryByName("subcyclelock",SoxicConstants.CERTIFICATION_STATE);

			retrieveSubCycleLock = con
					.prepareStatement("SELECT SC.STATUS FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID=?");
			retrieveSubCycleLock.setString(1, subCycleId);

			rs = retrieveSubCycleLock.executeQuery();
			while (rs.next()) {
				String status = rs.getString("STATUS");
				if(status!=null && status.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
					subCycleLoked=true;
					return subCycleLoked;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(retrieveSubCycleLock);
				SoxicConnectionFactory.closeSoxicConnection(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return subCycleLoked;
	}

	public static void main(String[] args) {
	}

	public static String getQueryString() {
		//String queryString = "";
		String queryString = "SELECT O.NAME,SC.DESCRIPTION,CO.DESCRIPTION,O.OWNER_ID,Q.QUESTION,Q.QUESTION_TYPE_ID,A.ACTIVITY_ID,A.DESCRIPTION,OW.OWNER_ID,OW.ACTIVITY_ID,OA.STATUS "
				+ "FROM OWNER_SUB_CYCLE OSC,OWNER O,SUB_CYCLE SC,OWNER_ACTIVITY OA,ACTIVITY A,CTRL_OBJ CO,QUESTION_CTRL_OBJ QCO,QUESTION Q,OWNER_ACTIVITY OW "
				+ "WHERE OSC.OWNER_ID=100    AND "
				+ "OSC.OWNER_ID=O.OWNER_ID    AND "
				+ "OSC.SUB_CYCLE_ID=SC.SUB_CYCLE_ID AND "
				+ "OA.OWNER_ID=OSC.OWNER_ID AND "
				+ "OA.ACTIVITY_ID=A.ACTIVITY_ID AND "
				+ "A.CONTROL_OBJECT_ID = CO.CTRL_OBJ_ID AND "
				+ "OSC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND "
				+ "QCO.CTRL_OBJ_ID=CO.CTRL_OBJ_ID AND "
				+ "QCO.QUESTION_ID=Q.QUESTION_ID AND "
				+ "OW.ACTIVITY_ID=A.ACTIVITY_ID";

		String query = "Select * from OWNER";

		return queryString;
	}
	
	public static SubCycle populateSubCycle(ResultSet rs,String state) throws Exception{
		
		SubCycle subCycle = new SubCycle();
		if(state.equalsIgnoreCase(SoxicConstants.CERTIFICATION_STATE)){
    		subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
		    subCycle.setDescription(rs.getString("DESCRIPTION"));
		    subCycle.setStatus(rs.getString("STATUS"));
        }
		if(state.equalsIgnoreCase(SoxicConstants.DOCCHANGE_STATE)){
    		subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
		    subCycle.setDescription(rs.getString("DESCRIPTION"));
		    subCycle.setStatus(rs.getString("STATUS"));
            subCycle.setState(rs.getString("STATE"));
            subCycle.setCycleId(rs.getString("CYCLE_ID"));
        }
        if(state==null || state.equals(""))   {
                           		subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
		    subCycle.setDescription(rs.getString("DESCRIPTION"));
		    subCycle.setStatus(rs.getString("STATUS"));
            subCycle.setState(rs.getString("STATE"));

        }

		return subCycle;
		
	}
}