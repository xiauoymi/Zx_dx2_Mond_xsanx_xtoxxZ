package com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces;

import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.DocumentChangeRequestResponseListInt;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.DocumentChangeRequestResponseList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 4:36:49 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DocumentChangeEmailStrategy {
    void processRequestResponseObjects(DocumentChangeRequestResponseListInt documentChangeRequestResponseListInt);

    void processEmails(DocumentChangeRequestResponseListInt documentChangeRequestResponseListInt);
}
