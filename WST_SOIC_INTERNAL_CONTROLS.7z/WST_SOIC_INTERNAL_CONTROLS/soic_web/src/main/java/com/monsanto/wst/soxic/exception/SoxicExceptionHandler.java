/*
 * Created on Apr 12, 2005
 */
package com.monsanto.wst.soxic.exception;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

public class SoxicExceptionHandler extends ExceptionHandler{
	
	Date errorDate = new Date(System.currentTimeMillis());
	
	public ActionForward execute(
		      Exception ex,
		      ExceptionConfig ae,
		      ActionMapping mapping,
		      ActionForm formInstance,
		      HttpServletRequest request,
		      HttpServletResponse response)
		   throws ServletException {
			  ex.printStackTrace();
			  ByteArrayOutputStream stream = new ByteArrayOutputStream();
			  ex.printStackTrace(new PrintStream(stream));
			  
		      return new ActionForward(ae.getPath());
		   }

}
