package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionError;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.ArrayList;

import com.monsanto.wst.soxic.facade.PeriodFacade;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 28, 2005
 * Time: 11:00:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeReviewForm extends ActionForm{

    private String identifier;
    private String source_type;
    private String request_type;
    private String newActivityDescription;
    private String oldActivityDescription;
    private String reasonForRemoval;
    private String reasonToDisapprove;
    private String status;
    private List   newActivityIdsAvaliable;
    private String selectedNewActivityId;
    private String mode;
    private String ocreqResponse;
    private String priority;
    //IA New activity
    private String iaSelectedNewActivityId;
    private String iaActivityList;
    private String iaNewStringAddedToActivity;
    private int overFlowId=0;

    private boolean viewNewActivityDescription;
    private boolean viewOldActivityDescription;
    private boolean viewOldDescriptionLabel;
    private boolean viewReasonForRemoval;
    private boolean viewReasonToDiapprove;
    private boolean viewNewActivityIdsAvaliable;
    private boolean viewSubCycleApprovalLabel;
    private boolean viewIAApprovalLabel;
    private boolean viewUpdateButton=true;
    private boolean viewIAActivityIdNewDetails;
    private boolean viewPriority;
    private String url;
    private String diffActivityDescription;

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        if(request.getServletPath().equalsIgnoreCase("/documentChangeReviewCancelAction.do")){
            return errors;
        }
        if(viewNewActivityDescription){
            if(newActivityDescription==null || newActivityDescription.length()==0){

                errors.add("newActivityDescription", new ActionError(
                        "errors.docchange.newdescription.empty"));
            }
        }
        if(viewReasonForRemoval){
            if(reasonForRemoval==null || reasonForRemoval.length()==0){

                errors.add("reasonForRemoval", new ActionError(
                        "errors.docchange.reasontoremove.empty"));
            }
        }
        if(viewReasonToDiapprove){
            if(status!=null && status.equalsIgnoreCase("reject")){
                if(reasonToDisapprove==null || reasonToDisapprove.length()==0){

                    errors.add("reasonToDisapprove", new ActionError(
                            "errors.docchange.reasontodisallow.empty"));
                }
            }
        }
        if(viewSubCycleApprovalLabel || viewIAApprovalLabel){
            if(status==null || status.length()==0){
                    errors.add("reasonToDisapprove", new ActionError(
                            "errors.docchange.approvallabel.empty"));
            }
        }
        if (viewPriority){
            if (status.equalsIgnoreCase("approve")){
                if (priority.length()==0 || priority.equals("") || priority==null){
                    errors.add("prioritySetting", new ActionError(
                            "errors.docchange.priority.empty"));
                }else
                if (priority.length()>1){
                    errors.add("prioritySetting", new ActionError(
                            "errors.docchange.incorrect.size"));
                }else
                if (isValidPriority()==false){
                    errors.add("prioritySetting", new ActionError(
                            "errors.docchange.wrong.priority"));
                }
            }
        }

        return errors;
    }

    public String getDiffActivityDescription() {
        return diffActivityDescription;
    }

    public void setDiffActivityDescription(String diffActivityDescription) {
        this.diffActivityDescription = diffActivityDescription;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getSource_type() {
        return source_type;
    }

    public void setSource_type(String source_type) {
        this.source_type = source_type;
    }

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }

    public String getNewActivityDescription() {
        return newActivityDescription;
    }

    public void setNewActivityDescription(String newActivityDescription) {
        this.newActivityDescription = newActivityDescription;
    }

    public String getOldActivityDescription() {
        return oldActivityDescription;
    }

    public void setOldActivityDescription(String oldActivityDescription) {
        this.oldActivityDescription = oldActivityDescription;
    }

    public String getReasonForRemoval() {
        return reasonForRemoval;
    }

    public void setReasonForRemoval(String reasonForRemoval) {
        this.reasonForRemoval = reasonForRemoval;
    }

    public String getReasonToDisapprove() {
        return reasonToDisapprove;
    }

    public void setReasonToDisapprove(String reasonToDisapprove) {
        this.reasonToDisapprove = reasonToDisapprove;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List getNewActivityIdsAvaliable() {
        return newActivityIdsAvaliable;
    }

    public void setNewActivityIdsAvaliable(List newActivityIdsAvaliable) {
        this.newActivityIdsAvaliable = newActivityIdsAvaliable;
    }

    public String getSelectedNewActivityId() {
        return selectedNewActivityId;
    }

    public void setSelectedNewActivityId(String selectedNewActivityId) {
        this.selectedNewActivityId = selectedNewActivityId;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public boolean isViewNewActivityDescription() {
        return viewNewActivityDescription;
    }

    public void setViewNewActivityDescription(boolean viewNewActivityDescription) {
        this.viewNewActivityDescription = viewNewActivityDescription;
    }

    public boolean isViewOldActivityDescription() {
        return viewOldActivityDescription;
    }

    public void setViewOldActivityDescription(boolean viewOldActivityDescription) {
        this.viewOldActivityDescription = viewOldActivityDescription;
    }

    public boolean isViewReasonForRemoval() {
        return viewReasonForRemoval;
    }

    public void setViewReasonForRemoval(boolean viewReasonForRemoval) {
        this.viewReasonForRemoval = viewReasonForRemoval;
    }

    public boolean isViewReasonToDiapprove() {
        return viewReasonToDiapprove;
    }

    public void setViewReasonToDiapprove(boolean viewReasonToDiapprove) {
        this.viewReasonToDiapprove = viewReasonToDiapprove;
    }

    public boolean isViewNewActivityIdsAvaliable() {
        return viewNewActivityIdsAvaliable;
    }

    public void setViewNewActivityIdsAvaliable(boolean viewNewActivityIdsAvaliable) {
        this.viewNewActivityIdsAvaliable = viewNewActivityIdsAvaliable;
    }

    public boolean isViewOldDescriptionLabel() {
        return viewOldDescriptionLabel;
    }

    public void setViewOldDescriptionLabel(boolean viewOldDescriptionLabel) {
        this.viewOldDescriptionLabel = viewOldDescriptionLabel;
    }

    public boolean isViewSubCycleApprovalLabel() {
        return viewSubCycleApprovalLabel;
    }

    public void setViewSubCycleApprovalLabel(boolean viewSubCycleApprovalLabel) {
        this.viewSubCycleApprovalLabel = viewSubCycleApprovalLabel;
    }

    public boolean isViewIAApprovalLabel() {
        return viewIAApprovalLabel;
    }

    public void setViewIAApprovalLabel(boolean viewIAApprovalLabel) {
        this.viewIAApprovalLabel = viewIAApprovalLabel;
    }

    public String getOcreqResponse() {
        return ocreqResponse;
    }

    public void setOcreqResponse(String ocreqResponse) {
        this.ocreqResponse = ocreqResponse;
    }

    public boolean isViewUpdateButton() {
        return viewUpdateButton;
    }

    public void setViewUpdateButton(boolean viewUpdateButton) {
        this.viewUpdateButton = viewUpdateButton;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getIaSelectedNewActivityId() {
        return iaSelectedNewActivityId;
    }

    public void setIaSelectedNewActivityId(String iaSelectedNewActivityId) {
        this.iaSelectedNewActivityId = iaSelectedNewActivityId;
    }

    public String getIaActivityList() {
        return iaActivityList;
    }

    public void setIaActivityList(String iaActivityList) {
        this.iaActivityList = iaActivityList;
    }

    public String getIaNewStringAddedToActivity() {
        return iaNewStringAddedToActivity;
    }

    public void setIaNewStringAddedToActivity(String iaNewStringAddedToActivity) {
        this.iaNewStringAddedToActivity = iaNewStringAddedToActivity;
    }

    public boolean isViewIAActivityIdNewDetails() {
        return viewIAActivityIdNewDetails;
    }

    public void setViewIAActivityIdNewDetails(boolean viewIAActivityIdNewDetails) {
        this.viewIAActivityIdNewDetails = viewIAActivityIdNewDetails;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public boolean isViewPriority() {
        return viewPriority;
    }

    public void setViewPriority(boolean viewPriority) {
        this.viewPriority = viewPriority;
    }

    public boolean isValidPriority(){
        List validPriorityList = new ArrayList();
        validPriorityList.add("0");
        validPriorityList.add("1");
        validPriorityList.add("2");
        validPriorityList.add("3");
        if(!validPriorityList.contains(priority)){
            return false;
        }
        return true;
    }

}
