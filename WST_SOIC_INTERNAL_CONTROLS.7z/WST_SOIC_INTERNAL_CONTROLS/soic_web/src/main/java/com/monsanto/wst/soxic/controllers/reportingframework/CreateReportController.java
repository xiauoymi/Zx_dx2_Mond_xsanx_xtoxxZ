package com.monsanto.wst.soxic.controllers.reportingframework;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.soxic.reportingFramework.*;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:27:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateReportController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        String selectedReport = (String) helper.getRequestParameterValue(SoxReportConstants.FRAMEWORK_REPORTID);
        String selectedOption = helper.getRequestParameterValue("selectedOption");
        ReportProperties reportProperties=null;
        Document outputDocument=null;
        try{
            reportProperties = new ReportProperties(selectedReport);
            reportProperties.parseXmlFile();
            String reportClassString = reportProperties.getReportClass();
            Class reportClass= Class.forName(reportClassString.toString());
            Object reportClassInstance = reportClass.newInstance();
            AbstractReport testReportOne = (AbstractReport) reportClassInstance;
            ReportParameters reportParameters = new ReportParameters(helper,reportProperties.getExportList());
            helper.setSessionParameter(SoxReportConstants.REPORT_PARAMETERS,reportParameters);
            outputDocument = testReportOne.buildReportXML(reportParameters, reportProperties);
            DOMUtil.outputXML(outputDocument);
        }catch(Exception e){
            e.printStackTrace();
        }
       helper.applyStylesheet(outputDocument,reportProperties.getReportXSL());
    }
}
