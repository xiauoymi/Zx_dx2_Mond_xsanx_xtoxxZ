package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.CycleManageFacade;
import com.monsanto.wst.soxic.form.DocChangeForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 26, 2005
 * Time: 3:35:49 PM
 *
 * This class contains the method in the CycleManageFacade which retrieves
 * the cycles based on the country. 
 */
public class DochangeCycleAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        DocChangeForm dochangeform = (DocChangeForm)form;
        String countryid = (String)request.getParameter("selectedCountry");
        request.getSession().setAttribute("COUNTRY",countryid);

        CycleManageFacade cycleManageFacade = new CycleManageFacade();
        cycleManageFacade.createCycleMaintainObjectList(dochangeform,countryid);

        return mapping.findForward("dochangecyclelist");
    }

}
