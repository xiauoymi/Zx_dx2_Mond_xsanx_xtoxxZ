package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 17, 2005
 * Time: 1:48:51 PM
 */

public class NullAndArrayIndexException extends Exception{
    public NullAndArrayIndexException(){
        super();
    }

    public NullAndArrayIndexException(Exception e){
        super(e);
    }

}
