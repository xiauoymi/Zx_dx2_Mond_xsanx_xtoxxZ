package com.monsanto.wst.soxic.facade;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 1, 2006
 * Time: 1:05:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CycleOnlyConstants {

    public static final String OWN_ACT = "OWNER_ACTIVITY";
    public static final String ACT = "ACTIVITY";
    public static final String OWN_SUB = "OWNER_SUBCYCLE";
    public static final String SUBCYCLE = "SUBCYCLE";
    public static final String CTRL_OBJ = "CTRL_OBJ";
    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String SUBCYCLE_ASSOC_TYPE = "S";
    public static final String ACT_ASSOC_TYPE = "A";
    public static final String CYCLE_ONLY_RESPONSE = "CYCLE_ONLY";
    public static final String YES_RESPONSE = "YES";
    public static final String CHANGE_OWNER = "CHANGE_OWNER";
    public static final String COPY_OWNER = "COPY_OWNER";
    public static final String QUEST_ACT = "ACT";
    public static final String QUEST_SC = "SC";

}
