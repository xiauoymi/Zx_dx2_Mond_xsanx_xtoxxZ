package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.form.QuestionAdminForm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 9:23:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class HeaderFooterDAO {

    public static String getMessage(String type, String questionHeaderFooter) {
        String text = "";
        String query = SoxicUtil.getQuery("question.header.footer.retrieve");

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, questionHeaderFooter);
                preparedStatement.setString(2, type);


                rs = preparedStatement.executeQuery();
            while(rs.next()){
                text = rs.getString("TEXT");
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return text;
    }

    public static void updateMessage(String text, String levelType, String type) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String query = SoxicUtil.getQuery("question.header.footer.update");
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, text);
                preparedStatement.setString(2, levelType);
                preparedStatement.setString(3, type);
                preparedStatement.executeUpdate();

        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }
}
