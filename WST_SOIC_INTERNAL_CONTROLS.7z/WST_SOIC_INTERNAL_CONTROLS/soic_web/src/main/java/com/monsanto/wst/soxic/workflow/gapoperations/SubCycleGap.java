package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 12:53:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubCycleGap extends GapEntity{
    public static final String SUB_CYCLE_ID="SUB_CYCLE_ID";
}
