/*
 * Created on Mar 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StatusOperation {
	
	public static void main(String args[]) throws Exception{
		StatusOperation statusOperation = new StatusOperation();
		try{
			statusOperation.addAllStatus();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@tst01.monsanto.com:1521:comgent","sarbox_et","sarbox_et_123");
		return conn;
	}	
	
	
	public void addStatus(String status,int statuslevel) throws Exception{
		Connection con = null;

		PreparedStatement addStatus = null;
		
		//List activityList = new ArrayList();
		

		try {
			con = getConnection();

			addStatus = con.prepareStatement("INSERT INTO LOOKUP(NAME,TYPE,VALUE,MOD_DATE,MOD_USER)"
					+ "VALUES(?,'STATUS',?,?,'VLARTER')");
			
			addStatus.setString(1,status);
			
			addStatus.setInt(2,statuslevel);
			
			addStatus.setDate(3,new Date(System.currentTimeMillis()));
			
			addStatus.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public void addAllStatus() throws Exception{
		addStatus("G_COMPLETE",1);
		addStatus("G_INPROC",2);
		addStatus("G_NOTSTART",3);
		addStatus("G_IMPORTED",4);
		addStatus("IMPORTED",4);
		addStatus("Y_INPROC",5);
		addStatus("Y_NOTSTART",6);
		addStatus("Y_IMPORTED",6);
		addStatus("R_INPROC",7);
		addStatus("R_NOTSTART",8);
		addStatus("R_IMPORTED",8);		
	}

}
