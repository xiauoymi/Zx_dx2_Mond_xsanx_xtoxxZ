package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.ExportTemplateForm;
import com.monsanto.wst.soxic.model.AdminTemplateDAO;
import com.monsanto.wst.soxic.exception.IncorrectDateException;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.facade.AdminViewTemplateFacade;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 5, 2005
 * Time: 11:00:38 AM
 * 
 * This class contains the method to the AdminViewTemplateFacade which
 * is used to select the country, the cycles of the country,
 * and the subcycles for that cycle.
 */

public class AdminViewTemplatesAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception {

        ExportTemplateForm exporttemplateform = (ExportTemplateForm)form;
        AdminViewTemplateFacade adminviewtemplatefacade = new AdminViewTemplateFacade();

        adminviewtemplatefacade.templateSelection(exporttemplateform);

        return mapping.findForward("viewtemplates");
    }


}
