package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 16, 2005
 * Time: 1:52:58 PM
 * To change this template use File | Settings | File Templates.
 */

public class SecurityVisibleForm extends ActionForm{

    boolean activityreview;
    boolean dochangereq;
    boolean viewcreatenewperiod;
    boolean cyclemaintain;
    boolean subcyclemaintain;
    boolean usermaintain;
    boolean deleteowner;
    boolean admindetails;
    boolean adminnews;
    boolean adminreport;
    boolean ownermaintain;
    boolean emailAdmin;
    boolean questionAdmin;
    boolean faqAdmin;

    public boolean isActivityreview() {
        return activityreview;
    }

    public void setActivityreview(boolean activityreview) {
        this.activityreview = activityreview;
    }

    public boolean isDochangereq() {
        return dochangereq;
    }

    public void setDochangereq(boolean dochangereq) {
        this.dochangereq = dochangereq;
    }

    public boolean isViewcreatenewperiod() {
        return viewcreatenewperiod;
    }

    public void setViewcreatenewperiod(boolean viewcreatenewperiod) {
        this.viewcreatenewperiod = viewcreatenewperiod;
    }

    public boolean isCyclemaintain() {
        return cyclemaintain;
    }

    public void setCyclemaintain(boolean cyclemaintain) {
        this.cyclemaintain = cyclemaintain;
    }

    public boolean isSubcyclemaintain() {
        return subcyclemaintain;
    }

    public void setSubcyclemaintain(boolean subcyclemaintain) {
        this.subcyclemaintain = subcyclemaintain;
    }

    public boolean isUsermaintain() {
        return usermaintain;
    }

    public void setUsermaintain(boolean usermaintain) {
        this.usermaintain = usermaintain;
    }

    public boolean isDeleteowner() {
        return deleteowner;
    }

    public void setDeleteowner(boolean deleteowner) {
        this.deleteowner = deleteowner;
    }

    public boolean isAdmindetails() {
        return admindetails;
    }

    public void setAdmindetails(boolean admindetails) {
        this.admindetails = admindetails;
    }

    public boolean isAdminnews() {
        return adminnews;
    }

    public void setAdminnews(boolean adminnews) {
        this.adminnews = adminnews;
    }

    public boolean isAdminreport() {
        return adminreport;
    }

    public void setAdminreport(boolean adminreport) {
        this.adminreport = adminreport;
    }

    public boolean isOwnermaintain() {
        return ownermaintain;
    }

    public void setOwnermaintain(boolean ownermaintain) {
        this.ownermaintain = ownermaintain;
    }

    public boolean isEmailAdmin() {
        return emailAdmin;
    }

    public void setEmailAdmin(boolean emailAdmin) {
        this.emailAdmin = emailAdmin;
    }

    public boolean isQuestionAdmin() {
        return questionAdmin;
    }

    public void setQuestionAdmin(boolean questionAdmin) {
        this.questionAdmin = questionAdmin;
    }

    public boolean isFaqAdmin() {
        return faqAdmin;
    }

    public void setFaqAdmin(boolean faqAdmin) {
        this.faqAdmin = faqAdmin;
    }
}
