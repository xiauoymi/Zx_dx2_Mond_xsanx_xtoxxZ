package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.DocChangeForm;
import com.monsanto.wst.soxic.facade.CycleManageFacade;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.model.CycleMaintainObject;
import com.monsanto.wst.soxic.exception.*;

import java.util.List;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 19, 2005
 * Time: 2:24:21 PM
 *
 * This class contains the call to the methods to do a mass update of the Start &
 * End dates. Only if the cycles are in INITIATED or RELEASED are the dates
 * applied. The methods are contained in CycleManageFacade. If incorrect dates/
 * date sequences/date formats are entered, the respective validations are done.
 *   
 */

public class SelectAllDatesAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        DocChangeForm dochangeform = (DocChangeForm)form;
        CycleManageFacade cycleManageFacade = new CycleManageFacade();
        String countryid = dochangeform.getSelectedCountry();

        try{
                cycleManageFacade.checkdates(dochangeform,countryid);
            }
            catch (Exception e){
                if(e instanceof IncorrectDateException ){
                    setNulldates(dochangeform);
                    throw new IncorrectDateException();
                }
                if(e instanceof DateSequenceException ){
                    setNulldates(dochangeform);
                    throw new DateSequenceException();
                }
                if(e instanceof DateFormatException ){
                    setNulldates(dochangeform);
                    throw new DateFormatException();
                }
                if(e instanceof NoInitiatedCycleException){
                    setNulldates(dochangeform);
                    throw new NoInitiatedCycleException();
                }
            }

            cycleManageFacade.createCycleMaintainObjectList(dochangeform,countryid);

        setNulldates(dochangeform);

        return mapping.findForward("success");
    }

    private void setNulldates(DocChangeForm dochangeform){
        dochangeform.setSdate(null);
        dochangeform.setEdate(null);
    }

}
