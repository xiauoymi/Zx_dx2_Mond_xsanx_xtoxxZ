package com.monsanto.wst.soxic.audit.dao;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 13, 2009
 * Time: 5:51:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class Issue {
  private String issueId;
  private String type;
  private String textField4;
  private String finding;
  private String textField2;
  private String textField1;
  private String textField3;
  private String area;
  private String title;
  private String textField10;
  private String userCat2;
  private String userCat2Id;
  private String message;

  public void setIssueId(String issueId) {
    //To change body of created methods use File | Settings | File Templates.
    this.issueId = issueId;
  }

  public void setType(String type) {
    //To change body of created methods use File | Settings | File Templates.
    this.type = type;
  }

  public void setTextField4(String textField4) {
    //To change body of created methods use File | Settings | File Templates.
    this.textField4 = textField4;
  }

  public void setFinding(String finding) {
    //To change body of created methods use File | Settings | File Templates.
    this.finding = finding;
  }

  public void setTextField2(String textField2) {
    //To change body of created methods use File | Settings | File Templates.
    this.textField2 = textField2;
  }

  public void setTextField1(String textField1) {
    //To change body of created methods use File | Settings | File Templates.
    this.textField1 = textField1;
  }

  public void setTextField3(String textField3) {
    //To change body of created methods use File | Settings | File Templates.
    this.textField3 = textField3;
  }

  public void setArea(String area) {
    //To change body of created methods use File | Settings | File Templates.
    this.area = area;
  }

  public void setTitle(String title) {
    //To change body of created methods use File | Settings | File Templates.
    this.title = title;
  }

  public void setTextField10(String textField10) {
    //To change body of created methods use File | Settings | File Templates.
    this.textField10 = textField10;
  }

  public void setUserCat2(String userCat2) {
    //To change body of created methods use File | Settings | File Templates.
    this.userCat2 = userCat2;
  }


  public String getIssueId() {
    return issueId;
  }

  public String getType() {
    return type;
  }

  public String getTextField4() {
    return textField4;
  }

  public String getFinding() {
    return finding;
  }

  public String getTextField2() {
    return textField2;
  }

  public String getTextField1() {
    return textField1;
  }

  public String getTextField3() {
    return textField3;
  }

  public String getArea() {
    return area;
  }

  public String getTitle() {
    return title;
  }

  public String getTextField10() {
    return textField10;
  }

  public String getUserCat2() {
    return userCat2;
  }

  public void setUserCat2Id(String id) {

    this.userCat2Id = id;
  }

  public String getUserCat2Id() {
    return userCat2Id;
  }

  public void setError(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }
}
