package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import java.util.Map;
import java.util.HashMap;
import java.io.InputStream;
import java.io.IOException;

import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:21:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportXmlParser {
    private Document typeXmlDom;
    private String xmlFileName;
    private String filterXSL;
    private String filterClass;
    private String reportXSL;
    private String reportClass;

    private Map reportProperties= new HashMap();

    public ReportXmlParser(String xmlFileName) throws XmlException {
        String temp = "com/monsanto/wst/soxic/reportingFramework/xmlResources/"+xmlFileName+".xml";
        this.xmlFileName = temp;
    }

    public void parseXmlFile() throws XmlException {
        ClassLoader classLoader = ReportXmlParser.class.getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(xmlFileName);
        try {
            typeXmlDom = DOMUtil.newDocument(inputStream);
        } catch (SAXException e) {
            throw new XmlException(e);
        }
        catch(IOException ioe){
            throw new XmlException(ioe);
        }
        NodeList nodeList = typeXmlDom.getElementsByTagName("filterOptions");
        Node firstFilterNode = nodeList.item(0);
        NodeList filterNodes = firstFilterNode.getChildNodes();
        for(int i=0;i<filterNodes.getLength();i++){
            Node currentNode = filterNodes.item(i);
            if(currentNode.getNodeName().equalsIgnoreCase("xsl")){
                filterXSL = DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("filterClass")){
                filterClass = DOMUtil.getTextValue(currentNode);
            }
        }

        NodeList nodeListONe = typeXmlDom.getElementsByTagName("reportOptions");
        Node firstReportNode = nodeListONe.item(0);
        NodeList reportNodes = firstReportNode.getChildNodes();
        for(int i=0;i<reportNodes.getLength();i++){
            Node currentNode = reportNodes.item(i);
            if(currentNode.getNodeName().equalsIgnoreCase("xsl")){
                reportXSL = DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("filterClass")){
                reportClass = DOMUtil.getTextValue(currentNode);
            }
        }
        DOMUtil.outputXML(typeXmlDom);
    }

    public Document getTypeXmlDom() {
        return typeXmlDom;
    }

    public String getXmlFileName() {
        return xmlFileName;
    }

    public String getFilterXSL() {
        return filterXSL;
    }

    public String getFilterClass() {
        return filterClass;
    }

    public String getReportXSL() {
        return reportXSL;
    }

    public String getReportClass() {
        return reportClass;
    }

    public Map getReportProperties() {
        return reportProperties;
    }
}
