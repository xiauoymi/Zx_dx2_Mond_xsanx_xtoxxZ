/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.persistance.EmailHeaderDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.exception.BadDataException;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycleStatusOperation {
    public static void main(String args[]) throws Exception{

        SubCycleStatusOperation subCycleObjectiveOperations = new SubCycleStatusOperation();

        subCycleObjectiveOperations.updateOwnerSubCycleStatus();

        //subCycleObjectiveOperations.updateSubCycleStatus();

        subCycleObjectiveOperations.sendStartEmail();
    }

    /**
     * @throws Exception
     */
    public void updateOwnerSubCycleStatus() throws Exception{
        Connection conn = null;
        try{
        conn = getConnection();
        List subCycleList = getOwnerSubCycleStatusList(conn);
        processOwnerSubCycleStatus(subCycleList);
        updateOwnerStatus(subCycleList,conn);
        email(subCycleList);
        }catch(Exception e){
          e.printStackTrace();
        }
        finally{
          try{
          closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources : SubCycleStatusOperation.updateOwnerSubCycleStatus()");
          }
        }

    }

    /**
     * @throws Exception
     */
    public void updateSubCycleStatus() throws Exception{

        List subCycleList = getSubCycleList();

        updateStatus(subCycleList);

    }

    public void sendStartEmail()throws Exception{

                EmailHeaderDAO emailHeaderDAO=new EmailHeaderDAO();

        Map headerMap = emailHeaderDAO.selectHeader();

        String customString = (String) headerMap.get(SoxicConstants.SUB_CYCLE_EMAIL_HEADER);

        List subCycleList = getStartSubCycleList();

        Map ownerMap = processStartSubcycleListNew(subCycleList);

        Iterator iterator = ownerMap.values().iterator();

        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            SarboxMailComponent.sendStartWorkFlowEmail(SoxicConstants.SUBCYCLE,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString(), customString);
        }

        UtilDAO utilDAO = new UtilDAO();
        Map ownerSubCycleMap = utilDAO.getStartDateUpperLevelOwnerWrapper(SoxicConstants.SUBCYCLE);

        Iterator ownerSubCycleIterator = ownerSubCycleMap.values().iterator();

        while(ownerSubCycleIterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)ownerSubCycleIterator.next();
            SarboxMailComponent.sendStartUpperWorkFlowEmail(SoxicConstants.SUBCYCLE,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString());
        }
    }

    public void sendPastDueEmail()throws Exception{

        EmailWrapper emailWrapper = new EmailWrapper();

        List dueDateList = new ArrayList();

        List ownerList = new ArrayList();

        List subCycleList = getPastDueSubCycleList();

        Map ownerMap = processStartSubcycleList(subCycleList);

        Iterator iterator = ownerMap.values().iterator();

        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            emailWrapper.setEmailAddress(ownerWrapper.getEmailid());
            SarboxMailComponent.workFlowEmail(SarboxMailComponent.WORKFLOW_PAST_DUE_CURRENT_LEVEL,SoxicConstants.SUBCYCLE,emailWrapper);
            dueDateList.add(ownerWrapper.getDateString());
            ownerList.add(ownerWrapper.getOwnerName());
        }
        //emailWrapper.setDueDateList(dueDateList);
        //emailWrapper.setOwnerList(ownerList);
        UtilDAO utilDAO = new UtilDAO();
        Map ownerSubCycleMap = utilDAO.getOverDueUpperLevelOwnerWrapper(SoxicConstants.SUBCYCLE);


        Iterator ownerSubCycleIterator = ownerSubCycleMap.values().iterator();

        while(ownerSubCycleIterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)ownerSubCycleIterator.next();
            emailWrapper.setEmailAddress(ownerWrapper.getEmailid());
            List subCycleOwnerPastDueList = utilDAO.getOverDueOwnersPerCycleOwner(ownerWrapper.getOwnerid());
            List justOwnerList = getOwnerList(subCycleOwnerPastDueList);
            emailWrapper.setOwnerList(justOwnerList);
            SarboxMailComponent.workFlowEmail(SarboxMailComponent.WORKFLOW_PAST_DUE_UPPER_LEVEL,SoxicConstants.SUBCYCLE,emailWrapper);
        }
    }

    public List getOwnerList(List ownerWrapperList){
        List tempList = new ArrayList();
        Iterator iterator = ownerWrapperList.iterator();
        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
            tempList.add(ownerWrapper.getOwnerName());
        }
        return tempList;
    }

    public Map processStartSubcycleList(List subCycleList)throws Exception{

        Iterator iterator = subCycleList.iterator();
        UtilDAO utilDAO = new UtilDAO();
        Map subCycleOwnerMap = new HashMap();

        while(iterator.hasNext()){

            SubCycle subCycle = (SubCycle)iterator.next();
            if(!subCycleOwnerMap.containsKey(subCycle.getOwnerId())){
                OwnerWrapper ownerWrapper = utilDAO.getSubCycleStartOwnerWrapper(subCycle.getOwnerId());
                subCycleOwnerMap.put(subCycle.getOwnerId(),ownerWrapper);
            }

        }

        return subCycleOwnerMap;

    }

    public Map processStartSubcycleListNew(List subCycleList)throws Exception{

        Iterator iterator = subCycleList.iterator();
        UtilDAO utilDAO = new UtilDAO();
        Map subCycleOwnerMap = new HashMap();

        while(iterator.hasNext()){

            SubCycle subCycle = (SubCycle)iterator.next();
            if(!subCycleOwnerMap.containsKey(subCycle.getOwnerId())){
                OwnerWrapper ownerWrapper = utilDAO.getSubCycleStartOwnerWrapperOnlyIncompleteOnes(subCycle.getOwnerId());
                subCycleOwnerMap.put(subCycle.getOwnerId(),ownerWrapper);
            }

        }

        return subCycleOwnerMap;

    }

    /**
     * @return
     * @throws Exception
     */
    public List getSubCycleList()throws Exception{
        List subCycleList = new ArrayList();
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement getSubCycleList = null;

        try {
            con = getConnection();
            getSubCycleList = con.prepareStatement("SELECT SUB_CYCLE_ID,STATUS FROM SUB_CYCLE");
            rs = getSubCycleList.executeQuery();
            while(rs.next()){
                populateSubCycleList(rs,subCycleList,con);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(con,rs,getSubCycleList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return subCycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public List getOwnerSubCycleList()throws Exception{

        List subCycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getControlObjectiveList = null;

        try {
            con = getConnection();

            getControlObjectiveList = con.prepareStatement("SELECT * FROM OWNER_SUB_CYCLE");

            ResultSet rs = getControlObjectiveList.executeQuery();

            while(rs.next()){
                populateOwnerSubCycleList(rs,subCycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return subCycleList;
    }

    /**
     * @return
     * @throws Exception
     * @param con
     */
    public List getOwnerSubCycleStatusList(Connection con)throws Exception{
        List subCycleList = new ArrayList();
        ResultSet rs =null;
        PreparedStatement ownerSubCycleStatement = null;

        try {
            ownerSubCycleStatement = con.prepareStatement("SELECT * FROM OWNER_SUB_CYCLE OSC,OWNER O WHERE O.OWNER_ID=OSC.OWNER_ID");
            rs = ownerSubCycleStatement.executeQuery();
            while(rs.next()){
                populateOwnerSubCycleStatusList(rs,subCycleList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
              closeResources(null, rs, ownerSubCycleStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return subCycleList;
    }

  private void closeResources(Connection con, ResultSet rs, PreparedStatement ownerSubCycleStatement) throws SQLException {
    if(rs != null) rs.close();
    if(ownerSubCycleStatement != null) ownerSubCycleStatement.close();
    if(con !=null)  con.close();
  }

  /**
     * @return
     * @throws Exception
     */
    public List getStartSubCycleList()throws Exception{

        List subCycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getControlObjectiveList = null;

        try {
            con = getConnection();

            getControlObjectiveList = con.prepareStatement("SELECT * FROM OWNER_SUB_CYCLE OSC WHERE OSC.START_DATE=? AND OSC.STATUS <> 'G_COMPLETE'");

            getControlObjectiveList.setDate(1,new java.sql.Date(System.currentTimeMillis()));

            ResultSet rs = getControlObjectiveList.executeQuery();

            while(rs.next()){
                populateOwnerSubCycleList(rs,subCycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return subCycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public List getPastDueSubCycleList()throws Exception{

        List subCycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getControlObjectiveList = null;

        try {
            con = getConnection();

            getControlObjectiveList = con.prepareStatement("SELECT * FROM OWNER_SUB_CYCLE OSC WHERE OSC.DUE_DATE<? AND OSC.STATUS <> 'G_COMPLETE'");

            getControlObjectiveList.setDate(1,new java.sql.Date(System.currentTimeMillis()));

            ResultSet rs = getControlObjectiveList.executeQuery();

            while(rs.next()){
                populateOwnerSubCycleList(rs,subCycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return subCycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public Connection getConnection() throws Exception {
        return SoxicConnectionFactory.getSoxicConnection();
    }

    /**
     * @param rs
     * @param subCyclelist
     * @param con
     * @throws Exception
     */
    public void populateSubCycleList(ResultSet rs, List subCyclelist, Connection con)throws Exception{
        String status="";
        SubCycle subCycle = new SubCycle();
        subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
        //subCycle.setDueDate(getSubCycleDueDate(subCycle.getSubCycleId()));
        subCycle.setStatus(rs.getString(SubCycle.STATUS));
        status = getSubCycleStatus(subCycle.getSubCycleId(),con);
        if(!subCycle.getStatus().equalsIgnoreCase(status)){
            subCycle.setShow(true);
            subCycle.setStatus(status);
        }
        subCyclelist.add(subCycle);
    }

    /**
     * @param rs
     * @param subCyclelist
     * @throws Exception
     */
    public void populateOwnerSubCycleList(ResultSet rs,List subCyclelist)throws Exception{
        SubCycle subCycle = new SubCycle();
        subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
        subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
        subCycle.setStatus(rs.getString(SubCycle.STATUS));
        subCycle.setOwnerId(rs.getString(SubCycle.OWNERID));
        subCyclelist.add(subCycle);
    }

    public void populateOwnerSubCycleStatusList(ResultSet rs,List subCyclelist)throws Exception{
        SubCycle subCycle = new SubCycle();
        subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
        subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
        subCycle.setStatus(rs.getString(SubCycle.STATUS));
        subCycle.setOwnerId(rs.getString(SubCycle.OWNERID));
        subCycle.setSubcycleEmailId(rs.getString("EMAIL"));
        subCycle.setDueDateString(""+rs.getDate("DUE_DATE"));
        subCyclelist.add(subCycle);
    }

    /**
     * @param subCycleList
     */
    public void processSubCycleStatus(List subCycleList){

        Iterator subCycleListIterator = subCycleList.iterator();
        Status newStatus;

        while(subCycleListIterator.hasNext()){

            SubCycle subCycle = (SubCycle)subCycleListIterator.next();

            Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

            Long redValue = new Long(SoxicUtil.getRedPeriod());

            Date yellowDate = new Date(System.currentTimeMillis()
                    + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

            Date redDate = new Date(System.currentTimeMillis()
                    + (redValue.longValue() * 24 * 60 * 60 * 1000));

            Date date = new Date(subCycle.getDueDate());

            Date currentDate = new Date(System.currentTimeMillis());

            //Date fifteenDate = new Date(System.currentTimeMillis()+1296000000);

            //Date thirtyDate = new Date(System.currentTimeMillis()+1296000000+1296000000);

            boolean valueone = date.before(redDate);

            boolean valuetwo = date.before(yellowDate);

            if(date!=null && !subCycle.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){

                if(date.before(redDate) && toModify(subCycle.getStatus(),"R_")){


                    subCycle.setStatus("R_"+getStatusToAppend(subCycle.getStatus()));
                    subCycle.setShow(true);
                }else{
                    if(date.before(yellowDate) && date.after(redDate) && toModify(subCycle.getStatus(),"Y_")){
                        subCycle.setStatus("Y_"+getStatusToAppend(subCycle.getStatus()));
                        subCycle.setShow(true);
                    }

                    if(date.after(yellowDate) && toModify(subCycle.getStatus(),"G_")){

                        //subCycle.setStatus("G_"+getStatusToAppend(subCycle.getStatus()));
                        subCycle.setStatus(SoxicConstants.GREEN_COMPLETE);
                        subCycle.setShow(true);
                    }
                }
            }
        }
    }

    /**
     * @param subCycleList
     */
    public void processOwnerSubCycleStatus(List subCycleList){

        Iterator subCycleListIterator = subCycleList.iterator();
        Status newStatus;

        while(subCycleListIterator.hasNext()){

            SubCycle subCycle = (SubCycle)subCycleListIterator.next();

            Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

            Long redValue = new Long(SoxicUtil.getRedPeriod());

            Date yellowDate = new Date(System.currentTimeMillis()
                    + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

            Date redDate = new Date(System.currentTimeMillis()
                    + (redValue.longValue() * 24 * 60 * 60 * 1000));



            //if(date.before(fifteenDate) && (toModify(subCycle.getStatus(),"R_")|| (subCycle.getStatus().equalsIgnoreCase(SoxicConstants.IMPORTED)))){
            if(subCycle.getDueDate()!=null && subCycle.getDueDate().length()>0  && !subCycle.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){

                java.util.Date date = new Date(subCycle.getDueDate());

                Date currentDate = new Date(System.currentTimeMillis());

                boolean valueone = date.before(redDate);

                boolean valuetwo = date.before(yellowDate);

                if(date.before(redDate) && (toModify(subCycle.getStatus(),"R_"))){


                    subCycle.setStatus("R_"+getStatusToAppend(subCycle.getStatus()));
                    subCycle.setShow(true);
                }else{
                    if(date.before(yellowDate) && date.after(redDate) && toModify(subCycle.getStatus(),"Y_")){
                        subCycle.setStatus("Y_"+getStatusToAppend(subCycle.getStatus()));
                        subCycle.setShow(true);
                    }

                    if(date.after(yellowDate) && toModify(subCycle.getStatus(),"G_")){

                        subCycle.setStatus("G_"+getStatusToAppend(subCycle.getStatus()));
                        //subCycle.setStatus(SoxicConstants.GREEN_COMPLETE);
                        subCycle.setShow(true);
                    }
                }
            }
        }
    }

    /**
     * @param subCyleList
     * @throws Exception
     */
    public void updateStatus(List subCyleList)throws Exception{
      Iterator subCyleListIterator = subCyleList.iterator();
      Connection conn = null;
      try{
          conn = getConnection();
          while(subCyleListIterator.hasNext()){
            SubCycle subcycle = (SubCycle)subCyleListIterator.next();
            if(subcycle.isShow()){
              updateSubCycle(subcycle,conn);
            }
          }
        }catch(Exception e){
          e.printStackTrace();
        }finally{
          try{
            closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources in "+getClass().getName()+"updateStatus()");
          }
        }
    }

    /**
     * @param subCyleList
     * @param conn
     * @throws Exception
     */
    public void updateOwnerStatus(List subCyleList, Connection conn)throws Exception{
        Iterator subCyleListIterator = subCyleList.iterator();
        while(subCyleListIterator.hasNext()){
            SubCycle subcycle = (SubCycle)subCyleListIterator.next();
            if(subcycle.isShow()){
                updateOwnerSubCycle(subcycle,conn);
            }
        }
    }

    /**
     * @param subCycle
     * @param con
     * @throws Exception
     */
    public void updateSubCycle(SubCycle subCycle, Connection con)throws Exception{
        PreparedStatement updateSubCycleStatement = null;
        try {
            updateSubCycleStatement = con.prepareStatement("UPDATE SUB_CYCLE SC SET SC.STATUS=? WHERE SC.SUB_CYCLE_ID=?");
            updateSubCycleStatement.setString(1,subCycle.getStatus());
            updateSubCycleStatement.setString(2,subCycle.getSubCycleId());
            updateSubCycleStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(null,null,updateSubCycleStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param subCycle
     * @param 
     * @throws Exception
     */
    public void updateOwnerSubCycle(SubCycle subCycle, Connection con)throws Exception{
        PreparedStatement updateOwnerSubCycleStatement = null;

        try {
            updateOwnerSubCycleStatement = con.prepareStatement("UPDATE OWNER_SUB_CYCLE OSC SET OSC.STATUS=? WHERE OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=?");
            updateOwnerSubCycleStatement.setString(1,subCycle.getStatus());
            updateOwnerSubCycleStatement.setString(2,subCycle.getOwnerId());
            updateOwnerSubCycleStatement.setString(3,subCycle.getSubCycleId());
            updateOwnerSubCycleStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
               closeResources(null,null,updateOwnerSubCycleStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param currentStatus
     * @return
     */
    public String getStatusToAppend(String currentStatus){
        if(currentStatus.indexOf("_")>0){
            return currentStatus.substring(currentStatus.indexOf("_")+1,currentStatus.length());
        }
        return currentStatus;
    }

    /**
     * @param currentStatus
     * @param currentString
     * @return
     */
    public boolean toModify(String currentStatus,String currentString){

        if(currentStatus.indexOf(currentString)<0){
            return true;
        }
        return false;
    }


    /**
     * @param subCycleId
     * @param con
     * @return
     * @throws Exception
     */
    public String getSubCycleStatus(String subCycleId, Connection con)throws Exception{
        PreparedStatement subCycleStatusStatement = null;
        String status=null;
        ResultSet rs = null;
        try {
            subCycleStatusStatement = con.prepareStatement("SELECT OSC.STATUS FROM OWNER_SUB_CYCLE OSC,LOOKUP L WHERE OSC.SUB_CYCLE_ID=? AND L.TYPE='STATUS' AND L.NAME=OSC.STATUS ORDER BY L.VALUE");
            subCycleStatusStatement.setString(1,subCycleId);
            rs = subCycleStatusStatement.executeQuery();
            while(rs.next()){
                status = rs.getString("STATUS");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(null,rs,subCycleStatusStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return status;
    }

    public void email(List subCycleList)throws Exception{

        UtilDAO utilDAO = new UtilDAO();
        Iterator subCycleListIterator = subCycleList.iterator();

        Map subCycleOwnerMap = new HashMap();

        while(subCycleListIterator.hasNext()){

            SubCycle subCycle = (SubCycle)subCycleListIterator.next();

            if(subCycle.isShow()){
                if(subCycleOwnerMap.containsKey(subCycle.getOwnerId())){
                    OwnerWrapper ownerWrapper = (OwnerWrapper) subCycleOwnerMap.get(subCycle.getOwnerId());
                    if(!ownerWrapper.getDueDate().contains(subCycle.getDueDateString())){
                            String dateString = ownerWrapper.getDateString()+","+subCycle.getDueDateString();
                        ownerWrapper.setDateString(dateString);
                        ownerWrapper.addDueDateToList(subCycle.getDueDateString());
                    }

                    if(!ownerWrapper.getSubCycleList().contains(subCycle.getSubCycleId())){
                                String subString = ownerWrapper.getSubCycleString()+","+subCycle.getSubCycleId();
                                ownerWrapper.setSubCycleString(subString);
                        ownerWrapper.addSubToList(subCycle.getSubCycleId());
                    }
                }else{
                    OwnerWrapper ownerWrapper = new OwnerWrapper();
                    ownerWrapper.setEmailid(subCycle.getSubcycleEmailId());
                    ownerWrapper.setOwnerid(subCycle.getOwnerId());
                    ownerWrapper.setDateString(subCycle.getDueDateString());
                    ownerWrapper.setSubCycleString(subCycle.getSubCycleId());
                    ownerWrapper.addSubToList(subCycle.getSubCycleId());
                    ownerWrapper.addDueDateToList(subCycle.getDueDateString());
                    subCycleOwnerMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
                }
            }
        }
        sendEmail(subCycleOwnerMap);
    }

    public void sendEmail(Map ownerMap){
        try{
            Iterator ownerActivityIterator = ownerMap.values().iterator();

            while(ownerActivityIterator.hasNext()){
                OwnerWrapper ownerWrapper =(OwnerWrapper)ownerActivityIterator.next();
                SarboxMailComponent.sendStatusChangeWorkFlowEmail(SoxicConstants.SUBCYCLE,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString());
            }
        }catch(Exception e){

        }
    }

    	//----New Code

  public void updateOverAllSubCycleStatus() throws Exception {
    List overAllSubCycleList = subCycleList();
    Iterator iterator = overAllSubCycleList.iterator();
    SubCycle subCycle = null;
    Connection conn = null;
    try{
    conn = getConnection();
    while (iterator.hasNext()) {
      subCycle = (SubCycle) iterator.next();
      String status = getOwnerSubCycleStatus(subCycle.getSubCycleId(),conn);
      if (status != null || subCycle.getStatus() != null) {
        if (!status.equalsIgnoreCase(subCycle.getStatus())) {
          updateOverAllSubCycleStatus(subCycle.getSubCycleId(), status,conn);
        }
      }
    }
  }catch(Exception e){
    e.printStackTrace();
  }
  finally{
      try{
        closeResources(conn,null,null);
      }catch(SQLException sqlEx){
        throw new Exception("Unable to close resources : SubCycleStatusOperation.updateOverAllSubCycleStatus ");
      }
    }
  }

	public List subCycleList()throws Exception{
		List cycleList = new ArrayList();
		Connection con = null;
		PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    try {
			con = getConnection();
			preparedStatement = con.prepareStatement("SELECT * FROM SUB_CYCLE SC,CYCLE_STATE CS WHERE SC.CYCLE_ID =CS.CYCLE_ID AND CS.STATE='CERTIFICATION'");
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				populateOverAllSubCycleList(rs,cycleList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(con,rs,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cycleList;
	}

	public void populateOverAllSubCycleList(ResultSet rs,List subCycleList)throws Exception{
		SubCycle subCycle = new SubCycle();
		subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
		subCycle.setStatus(rs.getString(SubCycle.STATUS));
		subCycleList.add(subCycle);
	}

	public String getOwnerSubCycleStatus(String subCycleId, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
    ResultSet rs =null;
		try {
			preparedStatement = con.prepareStatement("SELECT STATUS FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID=? ORDER BY STATUS DESC");
			preparedStatement.setString(1,subCycleId);
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				return rs.getString("STATUS");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
			closeResources(null,rs,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	public void updateOverAllSubCycleStatus(String subCycleId, String status, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = con.prepareStatement("UPDATE SUB_CYCLE SC SET SC.STATUS=? WHERE SC.SUB_CYCLE_ID=?");
			preparedStatement.setString(1,status);
			preparedStatement.setString(2,subCycleId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {
				closeResources(null,null,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
