package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.form.SignificantChangeForm;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 10, 2006
 * Time: 10:16:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveSigChangeRowAction extends Action {

    String addForward = "newRemove";
    String updateForward = "updateRemove";
    String forward = "";

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        String type = request.getParameter("type");
        String removeid = request.getParameter("remove").trim();
        SignificantChangeForm significantChangeForm = (SignificantChangeForm)request.getSession().getAttribute("sigChangeForm");
        processRemoval(significantChangeForm, removeid);
        request.getSession().setAttribute("sigChangeForm",significantChangeForm);
        forward = forwardBasedOnPage(type, forward);
        return mapping.findForward(forward);
    }

    public void processRemoval(SignificantChangeForm significantChangeForm, String removeid) {
        List sigChangeList = significantChangeForm.getSignificantChanges();
        List newList = new ArrayList();
        Iterator it = sigChangeList.iterator();
        while (it.hasNext()){
            SignificantChangeModel significantChangeModel = (SignificantChangeModel)it.next();
            String seqId = significantChangeModel.getSeqindex().trim();
            insertModelIntoNewListIfNotSelectedToRemove(seqId, removeid, newList, significantChangeModel);
        }
        significantChangeForm.setSignificantChanges(newList);
    }

    private void insertModelIntoNewListIfNotSelectedToRemove(String seqId, String removeid, List newList, SignificantChangeModel significantChangeModel) {
        if (!seqId.equalsIgnoreCase(removeid)){
            newList.add(significantChangeModel);
        }
    }

    public String forwardBasedOnPage(String type, String forward) {
        if (type.equalsIgnoreCase("NEW")){
            forward = addForward;
        }else
        if (type.equalsIgnoreCase("UPDATE")){
            forward = updateForward;
        }
        return forward;
    }
}
