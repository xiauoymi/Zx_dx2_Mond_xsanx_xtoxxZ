package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.CycleManageFacade;
import com.monsanto.wst.soxic.form.DocChangeForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 29, 2005
 * Time: 4:58:33 PM
 * 
 * This class contains the method to set the cycles to the PRE_CERTIFICATION
 * state once they are in LOCKED state. 2 methods in the CycleManageFacade are called
 * by this class. First is the method to set the cycle into the PRE_CERTIFICATION
 * state, and the other populates the CycleMaintainObjectList after the state
 * has been modified.
 *
 */
public class PreCertifyAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        DocChangeForm dochangeform = (DocChangeForm)form;
//        UtilDAO utildao = new UtilDAO();
        String cycleid = request.getParameter("precert");
        String countryid = (String)request.getSession().getAttribute("COUNTRY");

        CycleManageFacade cycleManageFacade = new CycleManageFacade();
        cycleManageFacade.preCertifyCycles(cycleid);
        cycleManageFacade.createCycleMaintainObjectList(dochangeform,countryid);

       return mapping.findForward("doprecertifycyclelist");
    }
}
