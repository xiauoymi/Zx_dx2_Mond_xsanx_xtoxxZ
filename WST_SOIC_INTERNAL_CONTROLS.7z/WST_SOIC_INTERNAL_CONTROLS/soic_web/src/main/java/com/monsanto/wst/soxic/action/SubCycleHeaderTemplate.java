/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycleHeaderTemplate {
	
	String periodID;
	
	String countryID;
	
	String subCycleID;
	
	String subCycleDesc;
	
	int totalGaps;
	
	

	/**
	 * @return Returns the totalGaps.
	 */
	public int getTotalGaps() {
		return totalGaps;
	}
	/**
	 * @param totalGaps The totalGaps to set.
	 */
	public void setTotalGaps(int totalGaps) {
		this.totalGaps = totalGaps;
	}
	/**
	 * @return Returns the countryID.
	 */
	public String getCountryID() {
		return countryID;
	}
	/**
	 * @param countryID The countryID to set.
	 */
	public void setCountryID(String countryID) {
		this.countryID = countryID;
	}
	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}
	/**
	 * @return Returns the subCycleDesc.
	 */
	public String getSubCycleDesc() {
		return subCycleDesc;
	}
	/**
	 * @param subCycleDesc The subCycleDesc to set.
	 */
	public void setSubCycleDesc(String subCycleDesc) {
		this.subCycleDesc = subCycleDesc;
	}
	/**
	 * @return Returns the subCycleID.
	 */
	public String getSubCycleID() {
		return subCycleID;
	}
	/**
	 * @param subCycleID The subCycleID to set.
	 */
	public void setSubCycleID(String subCycleID) {
		this.subCycleID = subCycleID;
	}
}
