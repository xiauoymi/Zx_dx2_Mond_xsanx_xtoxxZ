/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.Status;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.exception.BadDataException;
import com.monsanto.Util.StringUtils;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlObjectiveStatusOperation {

	
	
	public static void main(String args[]) throws Exception{
		
		ControlObjectiveStatusOperation controlObjectiveOperations = new ControlObjectiveStatusOperation();
				
		//controlObjectiveOperations.updateControlObjectiveStatus();
        controlObjectiveOperations.updateOverAllControlObjectiveStatus();
	}
	
	/**
	 * @throws Exception
	 */
	public void updateControlObjectiveStatus() throws Exception{
		
		List controlObjectiveList = getControlObjectiveList();
		
		processControlObjectiveStatus(controlObjectiveList);
		
		updateStatus(controlObjectiveList);
		
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public List getControlObjectiveList()throws Exception{
		
		List controlObjectiveList = new ArrayList();
		
		Connection con = null;
    ResultSet rs = null;
		PreparedStatement controlObjectiveStatement = null;
	
		try {
			con = getConnection();

			controlObjectiveStatement = con.prepareStatement("SELECT CTRL_OBJ_ID,STATUS FROM CTRL_OBJ CO");
			
			rs = controlObjectiveStatement.executeQuery();
			
			while(rs.next()){
				populateControlObjectiveList(rs,controlObjectiveList,con);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
        closeResources(con, rs, controlObjectiveStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return controlObjectiveList;
	}

  private void closeResources(Connection con, ResultSet rs, PreparedStatement controlObjectiveStatement) throws SQLException {
    if(rs != null) rs.close();
    if(controlObjectiveStatement != null) controlObjectiveStatement.close();
    if (con != null) con.close();
  }

  public Connection getConnection() throws Exception {
		return SoxicConnectionFactory.getSoxicConnection();
	}	
	
	public void populateControlObjectiveList(ResultSet rs, List controlObjectivelist, Connection con)throws Exception{

		ControlObjective controlObjective = new ControlObjective();
		controlObjective.setControlObjectiveId(rs.getString("CTRL_OBJ_ID"));
		Status status = new Status(rs.getString("STATUS"));
		controlObjective.setStatus(status);
		controlObjective.setDueDate(getControlObjectiveDueDate(controlObjective.getControlObjectiveId(),con));
		controlObjective.setStatusModified(false);
		controlObjectivelist.add(controlObjective);
	}
	
	public void processControlObjectiveStatus(List controlObjectiveList){
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		Status newStatus;
		
		while(controlObjectiveListIterator.hasNext()){
			
			ControlObjective controlObjective = (ControlObjective)controlObjectiveListIterator.next();
			
			Date date = controlObjective.getDueDate();
			
			Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

			Long redValue = new Long(SoxicUtil.getRedPeriod());

			Date yellowDate = new Date(System.currentTimeMillis()
					+ (yellowValue.longValue() * 24 * 60 * 60 * 1000));

			Date redDate = new Date(System.currentTimeMillis()
					+ (redValue.longValue() * 24 * 60 * 60 * 1000));
			
			Date currentDate = new Date(System.currentTimeMillis());
			
			//Date fifteenDate = new Date(System.currentTimeMillis()+1296000000);
			
			//Date thirtyDate = new Date(System.currentTimeMillis()+1296000000+1296000000);
			
			if(date!=null && !controlObjective.getStatus().getCurrentStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
						
				boolean valueone = date.before(redDate);
				
				boolean valuetwo = date.before(yellowDate);
	
				if(date.before(redDate) && toModify(controlObjective.getStatus().getCurrentStatus(),"R_")){
					
					newStatus = new Status("R_"+getStatusToAppend(controlObjective.getStatus().getCurrentStatus()));
					controlObjective.setStatus(newStatus);
					controlObjective.setStatusModified(true);
				}else{
					if(date.before(yellowDate) && date.after(redDate) && toModify(controlObjective.getStatus().getCurrentStatus(),"Y_")){
						newStatus = new Status("Y_"+getStatusToAppend(controlObjective.getStatus().getCurrentStatus()));
						controlObjective.setStatus(newStatus);
						controlObjective.setStatusModified(true);
					}
					
					if(date.after(yellowDate) && toModify(controlObjective.getStatus().getCurrentStatus(),"G_")){
						newStatus = new Status("G_"+getStatusToAppend(controlObjective.getStatus().getCurrentStatus()));
						controlObjective.setStatus(newStatus);
						//newStatus = new Status(SoxicConstants.GREEN_COMPLETE);
						//controlObjective.setStatus(newStatus);
						controlObjective.setStatusModified(true);
					}				
				}
			}
		}
	}
	
	public void updateStatus(List controlObjectiveList)throws Exception{
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
    Connection conn = null;
    try{
      conn = getConnection();
      while(controlObjectiveListIterator.hasNext()){
        ControlObjective controlObjective = (ControlObjective)controlObjectiveListIterator.next();
        if(controlObjective.isStatusModified()){
          updateControlObjective(controlObjective,conn);
        }
      }
    }catch(Exception e){
      e.printStackTrace();
    }finally{
      try{
        closeResources(conn,null,null);
      }catch(SQLException sqlEx){
        throw new Exception("Unable to close resources in "+getClass().getName()+"updateStatus()");
      }
    }
	}
	
	public void updateControlObjective(ControlObjective controlObjective, Connection con)throws Exception{
		PreparedStatement updateControlObjective = null;
		try {
			updateControlObjective = con.prepareStatement("UPDATE CTRL_OBJ CO SET CO.STATUS=? WHERE CO.CTRL_OBJ_ID=?");
			updateControlObjective.setString(1,controlObjective.getStatus().getCurrentStatus());
			updateControlObjective.setString(2,controlObjective.getControlObjectiveId());
			updateControlObjective.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(null,null,updateControlObjective);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public String getStatusToAppend(String currentStatus){
		if(currentStatus.indexOf("_")>0){
			return currentStatus.substring(currentStatus.indexOf("_")+1,currentStatus.length());
		}
		return currentStatus;
	}
	
	public boolean toModify(String currentStatus,String currentString){
		
		if(currentStatus.indexOf(currentString)<0){
			return true;
		}
		return false;
	}
	

	public Date getControlObjectiveDueDate(String controlObjectiveId, Connection con)throws Exception{
    
    PreparedStatement controlObjectiveDateStatement = null;
		
		Date dueDate=null;
		ResultSet rs = null;

		try {
			controlObjectiveDateStatement = con.prepareStatement("SELECT MIN(OA.DUE_DATE) AS DUE_DATE FROM CTRL_OBJ CO,ACTIVITY A,OWNER_ACTIVITY OA WHERE CO.CTRL_OBJ_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND OA.ACTIVITY_ID=A.ACTIVITY_ID");
				
			controlObjectiveDateStatement.setString(1,controlObjectiveId);
					
			rs = controlObjectiveDateStatement.executeQuery();
			
			while(rs.next()){
				dueDate = rs.getDate("DUE_DATE");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}catch(Exception e){
      e.printStackTrace();
    }
    finally {

			try {
				closeResources(null,rs,controlObjectiveDateStatement);
      } catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dueDate;
	}

    	//----New Code

	public void updateOverAllControlObjectiveStatus()throws Exception{
    List overAllctrlList = controlObjectiveList();
    Iterator iterator = overAllctrlList.iterator();
    ControlObjective controlObjective = null;
    Connection conn = null;
    try{
      conn = getConnection();
      while (iterator.hasNext()) {
        controlObjective = (ControlObjective) iterator.next();
        String status = getActivityStatus(controlObjective.getControlObjectiveId(),conn);
        if (status != null || controlObjective.getStatus().getCurrentStatus() != null) {
          if (!status.equalsIgnoreCase(controlObjective.getStatus().getCurrentStatus())) {
            updateOverAllObjStatus(controlObjective.getControlObjectiveId(), status,conn);
          }
        }
      }
    }catch(Exception e){
      e.printStackTrace();
    }finally{
      try{
        closeResources(conn,null,null);
      }catch(SQLException sqlEx){
        throw new Exception("Unable to close resources :CpntrolObjectvieStatusOperation.updateOverAllControlObjectiveStatus() ");
      }
    }
	}

	public List controlObjectiveList()throws Exception{
		List ctrlList = new ArrayList();

		Connection con = null;

		PreparedStatement preparedStatement = null;

		try {
			con = getConnection();

			preparedStatement = con.prepareStatement("SELECT * FROM CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND SC.CYCLE_ID =CS.CYCLE_ID AND CS.STATE='CERTIFICATION'");

			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()){
				populateOverAllControlObjList(rs,ctrlList);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ctrlList;
	}

	public void populateOverAllControlObjList(ResultSet rs,List ctrlList)throws Exception{
		ControlObjective controlObjective = new ControlObjective();
		controlObjective.setControlObjectiveId(rs.getString("CTRL_OBJ_ID"));
		Status status = new Status(rs.getString("STATUS"));
		controlObjective.setStatus(status);
		ctrlList.add(controlObjective);
	}

	public String getActivityStatus(String activityId, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    try {
			preparedStatement = con.prepareStatement("SELECT STATUS FROM ACTIVITY WHERE CTRL_OBJ_ID=? ORDER BY STATUS DESC");
			preparedStatement.setString(1,activityId);
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				return rs.getString("STATUS");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(null,rs,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	public void updateOverAllObjStatus(String ctrlObjId, String status, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = con.prepareStatement("UPDATE CTRL_OBJ CO SET CO.STATUS=? WHERE CO.CTRL_OBJ_ID=?");
			preparedStatement.setString(1,status);
			preparedStatement.setString(2,ctrlObjId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(null,null,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
