/*
* Created on Jan 28, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.persistance;

import java.sql.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleSubCycleDAO  extends OracleAbstractDAO {

    private String ownerId ;
    private String queryType;


    protected String buildSelectQuery(Map queryCriteria){

        String query = "";
        queryType = queryCriteria.get("QUERY_TYPE").toString();

        if(queryType.equals("OWNER") || queryType.equals("INIT")){

            ownerId = queryCriteria.get(Owner.OWNER_ID).toString();
            query = buildOwnerSubCyclesQuery(ownerId);
        }
        else if(queryType.equals("CYCLE")){

            query = buildCycleSubCyclesQuery(queryCriteria.get(Cycle.CYCLE_ID).toString());
        }else if(queryType.equals("SUB_CYCLE")){
            query = buildSubCyclesQuery(queryCriteria.get(SubCycle.SUB_CYCLE_ID).toString());
        }

        return query.toString();
    }

    private String buildOwnerSubCyclesQuery(String ownerId){

        StringBuffer query = new StringBuffer();

        query.append("SELECT O.SUB_CYCLE_ID, O.STATUS, O.START_DATE, O.DUE_DATE, S.DESCRIPTION, S.POTENTIAL_GAP, S.PREV_DEF, C.STATUS AS CSTAT, S.CYCLE_ID || ' ' || C.DESCRIPTION CYCLE_ID ");

        query.append("FROM OWNER_SUB_CYCLE O, SUB_CYCLE S, CYCLE C,CYCLE_STATE CS WHERE O.SUB_CYCLE_ID = S.SUB_CYCLE_ID AND S.CYCLE_ID = C.CYCLE_ID AND CS.CYCLE_ID=C.CYCLE_ID AND CS.STATE='"+SoxicConstants.CERTIFICATION_STATE+"' AND ");

        query.append("O.OWNER_ID = '"+ ownerId+"'");

        return query.toString();
    }

    private String buildCycleSubCyclesQuery(String cycleId){

        StringBuffer query = new StringBuffer();

        query.append("SELECT S.SUB_CYCLE_ID, S.CYCLE_ID, S.DESCRIPTION, S.STATUS, S.POTENTIAL_GAP, S.PREV_DEF ");

        query.append("FROM SUB_CYCLE S WHERE S.CYCLE_ID = '"+ cycleId + "'" );

        return query.toString();
    }

    private String buildSubCyclesQuery(String subCycleId){

        StringBuffer query = new StringBuffer();

        query.append("SELECT O.SUB_CYCLE_ID, O.STATUS, O.DUE_DATE, O.POTENTIAL_GAP, O.OWNER_ID ");

        query.append("FROM OWNER_SUB_CYCLE O WHERE ");

        query.append("O.SUB_CYCLE_ID = '"+ subCycleId+"'");

        return query.toString();
    }

    protected String buildUpdateQuery(SoxicBaseModel baseModel){

        return "";
    }




    private String getOwnerSubCycleColumnName(String columnName){

        //eventually this should go from here. either get this from a properties file or through a defined constant.
        return "OWNER_SUB_CYCLE."+columnName;
    }



    protected SoxicBaseModel populateModel(ResultSet rs){

        if(queryType.equals("OWNER")){
            return populateModelForOwner(rs);
        }else if(queryType.equals("CYCLE")){
            return populateModelForCycle(rs);
        }else if(queryType.equals("SUB_CYCLE")){
            return populateModelSubCycle(rs);
        }else if(queryType.equals("INIT")){
            return populateModelForInit(rs);
        }

        return null;

    }

    private SoxicBaseModel populateModelForOwner(ResultSet rs){

        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setStatus(rs.getString(SubCycle.STATUS));
            subCycle.setStartDate(rs.getDate(SubCycle.START_DATE));
            subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            subCycle.setDescription(rs.getString(SubCycle.DESCRIPTION));
            subCycle.setDeficiency(rs.getString(SubCycle.PREV_DEF));
            subCycle.setGap(rs.getString(SubCycle.POTENTIAL_GAP));
            subCycle.setCycleId(rs.getString(SubCycle.CYCLE_ID));
            subCycle.setSubmitLock(SoxicUtil.isStatusComplete(rs.getString("CSTAT")));
            //subCycle.setOwnerSubCycle(rs.getString(SubCycle.CYCLE_ID)+"-"+rs.getString(ActivityNew.OWNER_ID));

            subCycle.setControlObjectives(getControlObjectives(subCycle.getSubCycleId()));
            subCycle.setSubmitLock();
            subCycle.setQuestions(getSubCycleQuestions(subCycle.getSubCycleId()));
            setResponseToQuestions(subCycle.getQuestions());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;

    }

    private SoxicBaseModel populateModelForInit(ResultSet rs){

        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setStatus(rs.getString(SubCycle.STATUS));
            subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            subCycle.setDescription(rs.getString(SubCycle.DESCRIPTION));
            subCycle.setDeficiency(rs.getString(SubCycle.PREV_DEF));
            subCycle.setGap(rs.getString(SubCycle.POTENTIAL_GAP));
            subCycle.setCycleId(rs.getString(SubCycle.CYCLE_ID));

            setDocChangeState(subCycle);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;

    }
    private SoxicBaseModel populateModelSubCycle(ResultSet rs){

        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setStatus(rs.getString(SubCycle.STATUS));
            subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            subCycle.setOwnerId(rs.getString(SubCycle.OWNERID));
            subCycle.setSubGap(rs.getString(SubCycle.POTENTIAL_GAP));
            subCycle.setOwnerSubCycle(rs.getString(SubCycle.SUB_CYCLE_ID)+SoxicUtil.getSeperator()+rs.getString(SubCycle.OWNERID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;

    }
    private SoxicBaseModel populateModelForCycle(ResultSet rs){

        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setStatus(rs.getString(SubCycle.STATUS));
            //subCycle.setDueDate(rs.getDate(SubCycle.DUE_DATE));
            subCycle.setDescription(rs.getString(SubCycle.DESCRIPTION));
            subCycle.setDeficiency(rs.getString(SubCycle.PREV_DEF));
            subCycle.setGap(rs.getString(SubCycle.POTENTIAL_GAP));
            //subCycle.setSubGap(rs.getString(SubCycle.POTENTIAL_GAP));
            subCycle.setCycleId(rs.getString(SubCycle.CYCLE_ID));

            subCycle.setSub_cycles(getSub_Cycles(rs.getString(SubCycle.SUB_CYCLE_ID)));
            subCycle.setControlObjectives(getControlObjectives(subCycle.getSubCycleId()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;

    }



    private void setResponseToQuestions(Collection questions){

        OracleResponseDAO responseDAO = (OracleResponseDAO) AbstractDAOFactory.getFactory().getResponseDAO();

        Iterator itr = questions.iterator();

        while(itr.hasNext()){

            try {
                responseDAO.setResponse((QuestionNew) itr.next());
            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    public Collection getControlObjectives(String subCycleId) throws DatabaseException, Exception{

        DAO controlObjectiveDAO  = AbstractDAOFactory.getFactory().getControlObjectiveDAO();

        return controlObjectiveDAO.retrieveByCriteria(buildControlObjectiveQuery(subCycleId));
    }

    private Collection getSub_Cycles(String subCycleId) throws DatabaseException, Exception{

        DAO subCycleDAO  = AbstractDAOFactory.getFactory().getSubCycleDAO();

        return subCycleDAO.retrieveByCriteria(buildSubCycleQuery(subCycleId));
    }


    private Map buildSubCycleQuery(String subCycleId){

        Map subCycleQuery = new HashMap();
        subCycleQuery.put(SubCycle.SUB_CYCLE_ID, subCycleId);
        subCycleQuery.put("QUERY_TYPE", "SUB_CYCLE");

        return subCycleQuery;
    }

    private Map buildControlObjectiveQuery(String subCycleId){

        Map controlObjectiveQuery = new HashMap();
        controlObjectiveQuery.put(SubCycle.SUB_CYCLE_ID, subCycleId);

        return controlObjectiveQuery;
    }


    private Collection getSubCycleQuestions(String subCycleId) throws DatabaseException, Exception{

        DAO questionsDAO  = AbstractDAOFactory.getFactory().getQuestionDAO();

        return questionsDAO.retrieveByCriteria(buildSubCycleQuestionsQuery(subCycleId));
    }

    private Map buildSubCycleQuestionsQuery(String subCycleId){

        Map subCycleQuestionsQuery = new HashMap();

        subCycleQuestionsQuery.put(Owner.OWNER_ID, ownerId);
        subCycleQuestionsQuery.put(SubCycle.SUB_CYCLE_ID, subCycleId);
        subCycleQuestionsQuery.put("QUERY_TYPE", "SUB_CYCLE");



        return subCycleQuestionsQuery;
    }

    public void update(Collection soxicBaseModels) throws DatabaseException {


        if(soxicBaseModels != null){
            Iterator itr = soxicBaseModels.iterator();
            DAO questionDAO = AbstractDAOFactory.getFactory().getQuestionDAO();
            while(itr.hasNext()){
                try {
                    questionDAO.update(((SubCycle)itr.next()).getQuestions());
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new DatabaseException("OraclaSubCycleDAO --"+ e.toString());

                }
            }

        }
    }


    //
//  /**
//   * @param criteria
//   * @return
//   */
//  private StringBuffer buildWhereCriteria(Map criteria) {
//      
//      Set keys = criteria.keySet();
//		Iterator iter = keys.iterator();
//		int count = 0;
//		
//		StringBuffer whereCriteria= new StringBuffer();
//
//		while (iter.hasNext()) {
//		    
//			String columnName = (String) iter.next();
//			String value = SoxicUtil.replaceQuotes((String) criteria.get(columnName));
//			
//			if(columnName.equals(Owner.OWNER_ID)){
//			    ownerId = value;
//			}
//			
//			if (!SoxicUtil.isEmpty(value)) {
//			    
//				if (count > 0){
//					whereCriteria.append(" AND ");
//				}
//				
//				whereCriteria.append(
//						getOwnerSubCycleColumnName(columnName).trim() + " = '" + value.trim() + "'");
//				       
//				
//				count++;
//			}
//		}
//		
//      return whereCriteria;
//  }

    public int create(SoxicBaseModel soxicBaseModel){
        return -1;
    }

    private void setDocChangeState(SoxicBaseModel soxicBaseModel){
        DAO dAO = AbstractDAOFactory.getFactory().getPeriodDAO();
        PeriodDAO periodDAO = (PeriodDAO)dAO;
        try{
            periodDAO.setState(soxicBaseModel);
        }catch(Exception e){

        }

    }

    public void createSubCycle(String sourceSubCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT S.SUB_CYCLE_ID, S.SUB_CYCLE_CODE, S.DESCRIPTION FROM SUB_CYCLE S WHERE S.SUB_CYCLE_ID='"+sourceSubCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateModel(rs,targetCycleId);
            }
            insertSubCycle(subCycle,targetCycleId,period);
            createQuestionSubCycle(sourceSubCycleId,targetCycleId+"."+subCycle.getSubCycleCode(),period);
            createOwnerSubCycle(sourceSubCycleId,targetCycleId+"."+subCycle.getSubCycleCode(),period);
            createControlObjectives(sourceSubCycleId,targetCycleId+"."+subCycle.getSubCycleCode(),period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createOwnerSubCycle(String sourceSubCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC WHERE OSC.SUB_CYCLE_ID='"+sourceSubCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateOwnerModel(rs);
            }
            insertOwnerSubCycle(subCycle,targetCycleId,period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createQuestionSubCycle(String sourceSubCycleId,String targetCycleId,String period)throws Exception{

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        SubCycle subCycle=null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT QSC.SUB_CYCLE_ID,QSC.QUESTION_ID FROM QUESTION_SUB_CYCLE QSC WHERE QSC.SUB_CYCLE_ID='"+sourceSubCycleId+"'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                subCycle = populateQuestionModel(rs);
                insertQuestionSubCycle(subCycle,targetCycleId,period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void insertOwnerSubCycle(SubCycle subCycle,String newSubCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO OWNER_SUB_CYCLE (OWNER_ID, SUB_CYCLE_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,subCycle.getOwnerId());
            preparedStatement.setString(2,newSubCycleId);
            preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
            preparedStatement.setString(5,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public SubCycle populateModel(ResultSet rs,String newCycleId){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setSubCycleCode(rs.getString(SubCycle.SUB_CYCLE_CODE));
            subCycle.setDescription(rs.getString(SubCycle.DESCRIPTION));
            subCycle.setCycleId(newCycleId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public SubCycle populateOwnerModel(ResultSet rs){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setSubCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            //subCycle.setSubCycleCode(rs.getString(SubCycle.SUB_CYCLE_CODE));
            subCycle.setOwnerId(rs.getString(SubCycle.OWNERID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public SubCycle populateQuestionModel(ResultSet rs){
        SubCycle subCycle = new SubCycle();

        try {

            subCycle.setCycleId(rs.getString(SubCycle.SUB_CYCLE_ID));
            subCycle.setQuestionId(rs.getString(SubCycle.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return subCycle;
    }

    public void insertSubCycle(SubCycle subCycle,String newCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO SUB_CYCLE (SUB_CYCLE_ID, SUB_CYCLE_CODE, CYCLE_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,newCycleId+"."+subCycle.getSubCycleCode());
            preparedStatement.setString(2,subCycle.getSubCycleCode());
            preparedStatement.setString(3,newCycleId);
            preparedStatement.setString(4,subCycle.getDescription());
            preparedStatement.setString(5,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(6,new Date(System.currentTimeMillis()));
            preparedStatement.setString(7,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void createControlObjectives(String sourceSubCycleId,String targetSubCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        //ControlObjectiveDAO controlObjectiveDAO = new ControlObjectiveDAO();
        DAO controlObjectiveDAO =  AbstractDAOFactory.getFactory().getControlObjectiveDAO();

        String query = "SELECT CTRL_OBJ_ID FROM CTRL_OBJ WHERE SUB_CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,sourceSubCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                ((OracleControlObjectiveDAO)controlObjectiveDAO).createControlObjective(rs.getString("CTRL_OBJ_ID"),targetSubCycleId,period);
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void insertQuestionSubCycle(SubCycle subCycle,String newSubCycleId,String period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "INSERT INTO QUESTION_SUB_CYCLE (QUESTION_ID, SUB_CYCLE_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,subCycle.getQuestionId());
            preparedStatement.setString(2,newSubCycleId);
            //preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(3,new Date(System.currentTimeMillis()));
            preparedStatement.setString(4,"ADMIN");


            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    

    public boolean isSubCycleOwner(Owner owner,String subCycleId){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;

        String query = "SELECT SUB_CYCLE_ID FROM OWNER_SUB_CYCLE OSC WHERE OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,owner.getOwnerId());
            preparedStatement.setString(2,subCycleId);
            rs= preparedStatement.executeQuery();
            while(rs.next()){
                return true;
            }
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
        return false;
    }
}
