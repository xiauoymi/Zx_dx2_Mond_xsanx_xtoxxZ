package com.monsanto.wst.soxic.workflow.gapoperations;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 12:59:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class GapProcessor {

    public static void main(String args[]){

//        GapEntityType gapEntityType = new GapEntityType(GapEntityType.ACTIVITY_ENTITY);
//        gapEntityType.processNoGapYesAnswer();
//        gapEntityType.processNoGapNoAnswer();
//
//        gapEntityType = new GapEntityType(GapEntityType.SUB_CYCLE_ENTITY);
//        gapEntityType.processNoGapYesAnswer();
//        gapEntityType.processNoGapNoAnswer();
//
//        gapEntityType = new GapEntityType(GapEntityType.CYCLE_ENTITY);
//        gapEntityType.processNoGapYesAnswer();
//        gapEntityType.processNoGapNoAnswer();

        //
        String environment=args[0];
        String folder=args[1];

        GapEntityType gapEntityType = null;
//        gapEntityType = new GapEntityType(GapEntityType.ACTIVITY_ENTITY, environment, folder);
//        gapEntityType.processOwnerEntityList();
//        gapEntityType.processEntity();
//
//
//        gapEntityType = new GapEntityType(GapEntityType.CTRL_OBJ_ENTITY, environment, folder);
//        gapEntityType.processEntity();
//
//        gapEntityType = new GapEntityType(GapEntityType.SUB_CYCLE_ENTITY, environment, folder);
//        gapEntityType.processOwnerEntityList();
//        gapEntityType.processEntity();
//
//        gapEntityType = new GapEntityType(GapEntityType.CYCLE_ENTITY, environment, folder);
//        gapEntityType.processOwnerEntityList();
//        gapEntityType.processEntity();

        // New code

        gapEntityType = new GapEntityType(GapEntityType.ACTIVITY_ENTITY, environment, folder);
        gapEntityType.processOwnerEntityListSetGapToYesForGaps();
        gapEntityType.processEntitySetGapsToYesForGaps();


        gapEntityType = new GapEntityType(GapEntityType.CTRL_OBJ_ENTITY, environment, folder);
        gapEntityType.processEntitySetGapsToYesForGaps();

        gapEntityType = new GapEntityType(GapEntityType.SUB_CYCLE_ENTITY, environment, folder);
        gapEntityType.processOwnerEntityListSetGapToYesForGaps();
        gapEntityType.processEntitySetGapsToYesForGaps();

        gapEntityType = new GapEntityType(GapEntityType.CYCLE_ENTITY, environment, folder);
        gapEntityType.processOwnerEntityListSetGapToYesForGaps();
        gapEntityType.processEntitySetGapsToYesForGaps();





    }

}
