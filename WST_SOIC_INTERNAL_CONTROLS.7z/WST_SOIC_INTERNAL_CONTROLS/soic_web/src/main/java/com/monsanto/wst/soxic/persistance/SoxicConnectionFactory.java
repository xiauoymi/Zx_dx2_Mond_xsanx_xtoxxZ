/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.soxic.Servlet.PropertyFileUtil;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.commons.dbcp.BasicDataSource;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.*;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * @author SPOLAVA
 *
 *         TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style -
 *         Code Templates
 */
public class SoxicConnectionFactory {

    private static final String PREDEFINED_CONTEXT = "java:/comp/env/";
    private static DataSource dataSource;
    /**
     * This method gets the sql connection object from the Tomcat Connection pool.
     *
     * @return java.sql.Connection returns sql Connection object to the database. Parameters:
     *
     * @exception java.sql.SQLException - if a database-access error occurs.
     */
    public static Connection getSoxicConnection() throws Exception {
        Connection conn = null;

        try {
                ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.Soxic");
                String jndiDataSourceName = bundle.getString("jndi-name");
                Context initContext = new InitialContext();
                    dataSource = (DataSource) initContext
                    .lookup(jndiDataSourceName);
                conn = dataSource.getConnection();

        }
        catch (NamingException ne) {
            System.err.println("Exception Occured, unable to connect to database ");
            ne.printStackTrace();
        }

        return conn;
    }

//    public static Connection getSoxicConnection() throws Exception {
//        Connection conn = null;
//
//        try {
//
////            if (SoxicUtil.isUnitTest()) {
////                String environment = System.getProperty("lsi.function");
////                ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.Soxic");
////                String userName = bundle.getString("oracle."+environment+".username");
////                String password = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "soic", "CipherValue.hex", "KeyValue.hex");
////                Class.forName("oracle.jdbc.driver.OracleDriver");
////                String connectionString = bundle.getString("oracle."+environment+".server.connection");
////                conn = DriverManager.getConnection(connectionString,
////                        userName, password);
////            }
////            else {
//
//                // this is to get the connection from Tomcat Server through JNDI
//                // naming service.
////                Class.forName("oracle.jdbc.driver.OracleDriver");
////                Properties parms = new Properties();
//                // add the corresponding parameters if we are using other than
//                // tomcat server.
//                //Context initContext = new InitialContext(parms);
//                ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.Soxic");
//                String jndiDataSourceName = bundle.getString("jndi-name");
//                Context initContext = new InitialContext();
////                Context envContext = (Context) initContext
////                    .lookup("java:/comp/env");
//                //DataSource dataSource = null;
//                    dataSource = (DataSource) initContext
//                    .lookup(jndiDataSourceName);
////                if (SoxicUtil.isPasswordEncrypted()) {
////                  String decryptedPassword = EncryptionUtils
////                      .GetDecryptedStringFromExternalStorage("MONCRYPTJV", "soic",
////                          "CipherValue.hex", "KeyValue.hex");
////                  String envt = System.getProperty("lsi.function");
////                    BasicDataSource bds = (BasicDataSource) dataSource;
////                    bds.setPassword(decryptedPassword);
////                    bds.setRemoveAbandoned(true);
////                    bds.setRemoveAbandonedTimeout(60);
////                    String cstrResourceBundleName = "com.monsanto.wst.soxic.Servlet.WST_SOX";
////                    String userName = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "UserName");
////                    String sid = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "DataSource");
////                    String server = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "Server");
////                  String url = "jdbc:oracle:thin:@" + server + ":1521:" + sid;
////                  System.out.println("url = " + url);
////                  bds.setUrl(url);
//////                    bds.setUrl("jdbc:oracle:oci:@" + server + ":1521:" + sid);
//////                  String cstrURL = new StringBuffer("jdbc:oracle:thin:@").append(hostname).append(":").append(port).append(":").append(dataSource()).toString();
////
////                    bds.setUsername(userName);
////                }
//                conn = dataSource.getConnection();
//            //}
//
//        }
//        catch (NamingException ne) {
//            System.err.println("Exception Occured, unable to connect to database ");
//            ne.printStackTrace();
//        }
//
//        return conn;
//    }

    /**
     * Releases a SoxicConnection's database and JDBC resources immediately instead of waiting for them to be automatically
     * released. when we do connection pooling, find the connection in the pool and mark it as available
     *
     * @param connection
     */
    public static void closeSoxicConnection(Connection connection) {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void closeResultSet(ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void closePreparedStatement(
        PreparedStatement preparedStatement) {
        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method rollbacks the specified connection if it is not null
     *
     * @param con Connection representing the connection to the DB.
     */
    public static void rollback(Connection con) {
        if (con != null) {
            try {
                con.rollback();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void commit(Connection con) {
        if (con != null) {
            try {
                con.commit();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

      public static Connection getLocalConnection(String environmentIn, String folder) throws Exception {
           Connection conn = null;

          try {
                  ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.soxic.properties.Soxic");
                  String jndiDataSourceName = bundle.getString("jndi-name");
                  Context initContext = new InitialContext();
                      dataSource = (DataSource) initContext
                      .lookup(jndiDataSourceName);
                  conn = dataSource.getConnection();

          }
          catch (NamingException ne) {
              System.err.println("Exception Occured, unable to connect to database ");
              ne.printStackTrace();
          }

        return conn;
      }

//    public static Connection getLocalConnection(String environmentIn, String folder) throws Exception {
//        Connection conn = null;
//
//        if (SoxicUtil.isUnitTest()) {
//
//            Class.forName("oracle.jdbc.driver.OracleDriver");
//            String environment = environmentIn;
//            String envVariable = folder;
//            //**For connecting to DEV Database...
//            System.setProperty("DMONCRYPTJV", envVariable);
//            BufferedReader brIn = null;
//            String hexKey = null;
//            String keyFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "KeyValue.hex";
//            String cipherFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "CipherValue.hex";
//            try {
//                brIn = new BufferedReader(new FileReader(keyFile));
//                hexKey = brIn.readLine();
//            }
//            catch (FileNotFoundException ex) {
//                throw new EncryptorException(
//                    "EncryptionUtils::GetDecryptedStringFromExternalStorage - Invalid key file name.");
//            }
//
//            if (environment.equalsIgnoreCase("development")) {
//                String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile(cipherFile, hexKey);
//                conn = DriverManager.getConnection(SoxicUtil.getOracleDevServerConnectionString(),
//                    SoxicUtil.getOracleDevServerUserName(), decryptedPassword);
//            }
//
//            if (environment.equalsIgnoreCase("test")) {
//                String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile(cipherFile, hexKey);
//                //**For connecting to Test Database...
//                conn = DriverManager.getConnection(SoxicUtil.getOracleTestServerConnectionString(),
//                    SoxicUtil.getOracleTestServerUserName(), decryptedPassword);
//            }
//
//            if (environment.equalsIgnoreCase("production")) {
//
//                String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile(cipherFile, hexKey);
//                //**For connecting to Test Database...
//                conn = DriverManager.getConnection(SoxicUtil.getOracleProductionServerConnectionString(),
//                    SoxicUtil.getOracleProductionServerUserName(), decryptedPassword);
//            }
//        }
//        //conn.setAutoCommit(false);
//        return conn;
//    }

    public static Connection getUnitTestConnection() throws Exception {
          Connection connection = null;
          try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("url", "username", "password");
          } catch (ClassNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
          } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
          }

        return connection;
    }

}