package com.monsanto.wst.soxic.javamail;

import com.monsanto.wst.soxic.model.EmailWrapper;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 22, 2005
 * Time: 9:56:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserMaintainenceMailComponent {

    public static String USER_MAINTAIN_ADD = "USER_MAINTAIN_ADD";
    public static String USER_MAINTAIN_REMOVE = "USER_MAINTAIN_REMOVE";


    public static boolean userMaintainEmail(String emailType,EmailWrapper emailWrapper)throws Exception {
        if(emailType.equalsIgnoreCase(USER_MAINTAIN_ADD)){
            sendAddOwner(emailWrapper,"");
        }
        if(emailType.equalsIgnoreCase(USER_MAINTAIN_REMOVE)){
            sendRemoveOwner(emailWrapper,"");
        }
        return false;
    }

    private static boolean sendAddOwner(EmailWrapper emailWrapper,String toType)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailWrapper.getEmailAddress(), SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getAddOwnerSubject(),
                    addOwnerMessage(SoxicUtil.getHomeLink(),toType,emailWrapper), true);
            return true;
        }

        return false;
    }

       /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String addOwnerMessage(String link,String toType,EmailWrapper emailWrapper) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "A change in your assigned ownership has occurred.  You have been assigned as an owner of the following:"
                + "<br>"
                + "</td>"
                + "</tr>"
                + getChangeList(emailWrapper)
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + " Thank you for your help.<br>"
                + " Sarbanes-Oxley Internal Controls<br>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }



    private static boolean sendRemoveOwner(EmailWrapper emailWrapper,String toType)
            throws Exception {

        if (SoxicUtil.toSendEmail()) {
            JavaMailComponent.sendMail(emailWrapper.getEmailAddress(), SoxicUtil
                    .getFromEmailAddress(), SoxicUtil.getRemoveOwnerSubject(),
                    removeOwnerMessage(SoxicUtil.getHomeLink(),toType,emailWrapper), true);
            return true;
        }

        return false;
    }

       /**
     * This method returns body for overdue notification
     *
     * @param link
     * @return
     */
    public static String removeOwnerMessage(String link,String toType,EmailWrapper emailWrapper) {
        String toSend = "";
        toSend = toSend
                + "<html>"
                + "<head>"
                + "<style>"
                + ".redtext{ color: #C00 }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">"
                + "<tr bgcolor=\"#5F7D99\">"
                + "<td align=\"center\" colspan=\"2\" valign=\"middle\">"
                + "<h4>"
                + "<img src=\""
                + SoxicUtil.getImageLink()
                + "images/404_internal_control_logo.gif\">"
                + "</h4>"
                + "</td>"
                + "</tr>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "A change in your assigned ownership has occurred.  You have been removed as an owner of the following:"
                + "<br>"
                + "</td>"
                + "</tr>"
                + getChangeList(emailWrapper)
                + "<tr>"
                + "</tr>"
                + "<tr>"
                + "</tr>"
                + "<p>"
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + " Thank you for your help.<br>"
                + " Sarbanes-Oxley Internal Controls<br>"
                + "<br>" + "</td>" + "</tr>" + "</BODY>"
                + "</HTML>";
        return toSend;
    }

    private static String getChangeList(EmailWrapper emailWrapper){
        String changeTable ="";
        changeTable = changeTable
                + "<tr>"
                + "<td align=\"left\" colspan=\"2\" valign=\"middle\">"
                + "<table border=\"1\">";
                for(int i =0;i<emailWrapper.getModelList().size();i++){
                    changeTable = changeTable +
                    "<tr><td>"+emailWrapper.getModelList().get(i)+"</td></tr>";
                 }
                    changeTable = changeTable+
                  "</table>";
        return changeTable;

    }
}
