package com.monsanto.wst.soxic.ownerStatusReports;

import com.monsanto.wst.soxic.reportingFramework.AbstractReport;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;
import com.monsanto.wst.soxic.reportingFramework.ReportProperties;
import com.monsanto.wst.soxic.reportingFramework.SoxAbstractReport;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerStatusSubCycleDAO;
import com.monsanto.wst.soxic.model.OwnerStatus;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 3, 2006
 * Time: 1:39:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusSubCycleReport extends SoxAbstractReport{

    OwnerStatusSubCycleDAO ownerStatusSubCycleDAO = new OwnerStatusSubCycleDAO();
    OwnerStatusXMLBuilder ownerStatusXMLBuilder = new OwnerStatusXMLBuilder();

    public void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException {
        String subcycleid = (String) reportParameters.getReportParameter("subCycle");
        String reportType="Sub-Cycle";
        List activities = getAllActivitiesForSubCycle(subcycleid);
        List reportInfo = new ArrayList();
        Iterator it = activities.iterator();
        populateReportOwners(it,reportInfo);
        ownerStatusXMLBuilder.createXMLReport(reportDataElement,reportInfo,reportType);
    }

    private void populateReportOwners(Iterator it, List reportInfo) throws DatabaseException {
        OwnerStatus ownerStatus;
        while(it.hasNext()){
            ownerStatus = new OwnerStatus();
            String activityId = (String) it.next();
            ownerStatus.setId(activityId);
            ownerStatus.setOwners(getReportInformation(activityId));
            reportInfo.add(ownerStatus);
        }
    }

    protected List getReportInformation(String activityId) throws DatabaseException {
        return ownerStatusSubCycleDAO.setActivityOwnersForSelectedActivity(activityId);
    }

    protected List getAllActivitiesForSubCycle(String subcycleid) throws DatabaseException {
        return ownerStatusSubCycleDAO.getAllActivities(subcycleid);
    }
    
    public String returnExportFileNameKey() {
        return "Subcycle";
    }

    public void buildFilterXML(Element rootOutputElement) throws DatabaseException {
        //To change body of implemented methods use File | Settings | File Templates.
    }


}
