/*
 * Created on Mar 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TotalDataObject {
	
	private Vector periodVector = new Vector();
	
	
	
	
	/**
	 * @return Returns the periodVector.
	 */
	public Vector getPeriodVector() {
		return periodVector;
	}
	/**
	 * @param periodVector The periodVector to set.
	 */
	public void setPeriodVector(Vector periodVector) {
		this.periodVector = periodVector;
	}
}
