package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.monsanto.wst.soxic.form.OrphanReportForm;
import com.monsanto.wst.soxic.facade.reports.OrphanReportFacade;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 9, 2006
 * Time: 9:57:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class OrphanReportAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws IOException, Exception {

        OrphanReportForm orphanReportForm = (OrphanReportForm)form;
        OrphanReportFacade orphanReportFacade = new OrphanReportFacade();

        orphanReportForm.setPeriodList(orphanReportFacade.getPeriodsInSystem());

        return mapping.findForward("displayOrphanPeriods");
    }
}
