package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.model.ReportStatus;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 1, 2006
 * Time: 3:30:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class DashBoardHomeDAO {

    private static String checkOwnerCycle = "SELECT CYCLE_ID AS ID FROM OWNER_CYCLE WHERE OWNER_ID = ?";
    private static String checkOwnerSubCycle = "SELECT SUB_CYCLE_ID AS ID FROM OWNER_SUB_CYCLE WHERE OWNER_ID = ?";
    private static String checkOwnerActivity = "SELECT ACTIVITY_ID AS ID FROM OWNER_ACTIVITY WHERE OWNER_ID = ?";

    private static String getCycleDetails =
                    "SELECT C.CYCLE_ID, OC.STATUS " +
                    "FROM CYCLE C, OWNER_CYCLE OC, CYCLE_STATE CS " +
                    "WHERE CS.CYCLE_ID = C.CYCLE_ID " +
                    "AND OC.CYCLE_ID = C.CYCLE_ID " +
                    "AND CS.STATE = ? " +
                    "AND OC.OWNER_ID = ?";

    private static String getSubcycleDetails =
                        "SELECT OSC.SUB_CYCLE_ID, OSC.STATUS " +
                        "FROM CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC, OWNER_SUB_CYCLE OSC " +
                        "WHERE C.CYCLE_ID = CS.CYCLE_ID " +
                        "AND C.CYCLE_ID = SC.CYCLE_ID " +
                        "AND SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID " +
                        "AND CS.STATE = ? " +
                        "AND OSC.OWNER_ID = ?";

    private static String getActivityDetails =
                    "SELECT A.ACTIVITY_ID, OA.STATUS " +
                    "FROM CYCLE C, CYCLE_STATE CS, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A, OWNER_ACTIVITY OA " +
                    "WHERE C.CYCLE_ID = CS.CYCLE_ID " +
                    "AND C.CYCLE_ID = SC.CYCLE_ID " +
                    "AND SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID " +
                    "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                    "AND A.ACTIVITY_ID = OA.ACTIVITY_ID " +
                    "AND CS.STATE = ? " +
                    "AND OA.OWNER_ID = ?";
    private static final String COMPLETE = "COMPLETE";
    private static final String INCOMPLETE = "INCOMPLETE";


    public List getCycleListForOwner(List typeList, String ownerId) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(checkOwnerCycle);
                preparedStatement.setString(1, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                typeList.add("ID");
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return typeList;
    }

    public List getSubCycleListForOwner(List typeList, String ownerId) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(checkOwnerSubCycle);
                preparedStatement.setString(1, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                typeList.add("ID");
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return typeList;
    }

    public List getActivityListForOwner(List typeList, String ownerId) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(checkOwnerActivity);
                preparedStatement.setString(1, ownerId);

                rs = preparedStatement.executeQuery();
            while(rs.next()){
                typeList.add("ID");
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return typeList;
    }

    public List getCycleAndStatus(String ownerId) {
        List cycleOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getCycleDetails);
                preparedStatement.setString(1, SoxicConstants.CERTIFICATION_STATE);
                preparedStatement.setString(2, ownerId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String cycleid = rs.getString("CYCLE_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(cycleid, status, cycleOwners);
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        Collections.sort(cycleOwners);
        return cycleOwners;
    }

    private String setStatusToDisplay(String tablestatus) {
        String status;
        if (tablestatus.equalsIgnoreCase(SoxicConstants.COMPLETE)){
            status = COMPLETE;
        }
        else{
            status = INCOMPLETE;
        }
        return status;
    }

    private void setIdAndStatusIntoList(String id, String status, List ownerList) {
        ReportStatus reportStatus;
        reportStatus = new ReportStatus(id,status);
        ownerList.add(reportStatus);
    }

    public List getActivityAndStatus(String ownerId) {
        List actOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getActivityDetails);
                preparedStatement.setString(1, SoxicConstants.CERTIFICATION_STATE);
                preparedStatement.setString(2, ownerId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String cycleid = rs.getString("ACTIVITY_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(cycleid, status, actOwners);
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        Collections.sort(actOwners);
        return actOwners;
    }

    public List getSubcycleAndStatus(String ownerId) {
        List subCycleOwners = new ArrayList();
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        String status = "";
		try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getSubcycleDetails);
                preparedStatement.setString(1, SoxicConstants.CERTIFICATION_STATE);
                preparedStatement.setString(2, ownerId);

                rs= preparedStatement.executeQuery();

                while(rs.next()){
                    String cycleid = rs.getString("SUB_CYCLE_ID");
                    String tablestatus = rs.getString("STATUS");
                    status = setStatusToDisplay(tablestatus);
                    setIdAndStatusIntoList(cycleid, status, subCycleOwners);
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        Collections.sort(subCycleOwners);
        return subCycleOwners;
    }
}
