package com.monsanto.wst.soxic.reportingFramework;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 1:39:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class SoxReportConstants {

    public static final String REPORT_TAG = "report";
    public static final String REPORT_OPTIONS_TAG = "reportOptions";
    public static final String REPORT_PARAMTER = "report";
    public static final String REPORT_DATA = "reportdata";
    public static final String REPORT_OPTIONS_DATA = "reportoptionsdata";
    public static final String EXPORT_TYPE = "exporttype";
    public static final String EXPORT_OPTIONS = "exportoptions";
    public static final String EXPORT = "export";
    public static final String EXPORT_TYPE_WORD = "WORD";
    public static final String EXPORT_TYPE_EXCEL = "EXCEL";
    public static final String WORDING = "wording";
    public static final String REPORT_PARAMETERS = "reportParameters";

    public static final String CONTEXT_PATH = "/soic";
    public static final String REPORT_NAME = "name";
    public static final String SECURE_NAV = "securenavtab";
    public static final String FRAMEWORK_REPORTID = "framework_reportid";
    public static final String REPORT_ACTION_FILENAME = "actionname";
}
