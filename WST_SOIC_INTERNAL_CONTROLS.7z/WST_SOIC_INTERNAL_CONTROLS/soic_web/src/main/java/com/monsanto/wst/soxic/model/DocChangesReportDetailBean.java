/*
 DocChangesReportDetailBean was created on Mar 26, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.model;

/**
 * Filename:    $RCSfile: DocChangesReportDetailBean.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-03-25 14:40:09 $
 *
 * @author emgoode
 * @version $Revision: 1.2 $
 */
public class DocChangesReportDetailBean {
    private String requestId = "";
    private String activityId = "";
    private String ownerName = "";
    private String newText = "";
    private String oldText = "";
    private String regularApproval = "";
    private String iAuditApproval = "";
    private String requestType = "";
    private String regularNotes = "";
    private String iauditNotes = "";

    public DocChangesReportDetailBean(String requestId, String activityId, String ownerName, String newText,
                                      String oldText, String regularApproval, String iAuditApproval,
                                      String requestType, String regularNotes, String iAuditNotes
    ) {
        this.activityId = activityId;
        this.iAuditApproval = iAuditApproval;
        this.iauditNotes = iAuditNotes;
        this.newText = newText;
        this.oldText = oldText;
        this.ownerName = ownerName;
        this.regularApproval = regularApproval;
        this.regularNotes = regularNotes;
        this.requestId = requestId;
        this.requestType = requestType;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getIauditApproval() {
        return iAuditApproval;
    }

    public void setIauditApproval(String iAuditApproval) {
        this.iAuditApproval = iAuditApproval;
    }

    public String getIauditNotes() {
        return iauditNotes;
    }

    public void setIauditNotes(String iAuditNotes) {
        this.iauditNotes = iAuditNotes;
    }

    public String getNewText() {
        return newText;
    }

    public void setNewText(String newText) {
        this.newText = newText;
    }

    public String getOldText() {
        return oldText;
    }

    public void setOldText(String oldText) {
        this.oldText = oldText;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getRegularApproval() {
        return regularApproval;
    }

    public void setRegularApproval(String regularApproval) {
        this.regularApproval = regularApproval;
    }

    public String getRegularNotes() {
        return regularNotes;
    }

    public void setRegularNotes(String regularNotes) {
        this.regularNotes = regularNotes;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
}