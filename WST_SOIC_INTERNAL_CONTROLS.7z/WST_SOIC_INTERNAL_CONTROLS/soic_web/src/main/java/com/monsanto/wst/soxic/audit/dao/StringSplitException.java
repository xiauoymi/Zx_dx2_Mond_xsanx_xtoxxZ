package com.monsanto.wst.soxic.audit.dao;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 16, 2009
 * Time: 2:22:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class StringSplitException extends Throwable {
  public StringSplitException(String message, Throwable cause) {
    super(message, cause);    //To change body of overridden methods use File | Settings | File Templates.
  }
}
