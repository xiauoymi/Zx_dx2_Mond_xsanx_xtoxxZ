package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.DocChangeForm;
import com.monsanto.wst.soxic.exception.*;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.model.CycleMaintainObject;
import com.monsanto.wst.soxic.model.DocPublishObject;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Date;
import java.text.ParseException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 19, 2005
 * Time: 2:25:19 PM
 *
 * This class is the facade for the Cycle Management. It contains methods to
 * select the countries that are in INITAITED, RELEASED, LOCKED and
 * PRE_CERTIFICATION states, select the cycles based on the country,
 * perform RELEASE operation, LOCK operation, PRE_CERTIFICATIOn operation,
 * Date validation for individual cycle & mass selection of dates, and populating start and end
 * dates for cycles in INITIATED and RELEASED states.
 */

public class CycleManageFacade {

    private static final String DATE_FORMAT = "MM/dd/yyyy";
    UtilDAO utilDAO = new UtilDAO();
    DocChangeForm docChangeForm;


    /**
     * Retrieves the countries based on 4 states - INITIATED, LOCKED, RELEASED
     * and PRE_CERTIFICATION
     * @param dochangeform
     * @throws Exception
     */
    public void getCountryforCycles(DocChangeForm dochangeform) throws Exception {
        try {
                    //dochangeform.setCountry(utilDAO.getCountriesforCycleManage());
                dochangeform.setCountry(selectCountriesForCycleManage());
                }
                catch (Exception e) {
                    if (e instanceof NullAndArrayIndexException){
                    throw new NullAndArrayIndexException();
                }
                    System.err.println("Could not get country List due" + e);
                    e.printStackTrace();
                }
    }

    private List selectCountriesForCycleManage() throws Exception{
        return utilDAO.getCountriesforCycleManage();
    }

    /**
     * Retrieves the Cycles and populates the List of cycle objects with
     * the CycleIds, Start & End Dates and State.
     * @param countryid
     * @throws Exception
     */
    public void createCycleMaintainObjectList(DocChangeForm dochangeform, String countryid) throws Exception{
        try {
               //ochangeform.setCyclemaintainobjectlist(utilDAO.getCycleStatefromCountry(countryid));
                dochangeform.setCyclemaintainobjectlist(selectCyclesFromCountry(countryid));
            }
            catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
                System.err.println("Could not get cycle List due" + e);
                e.printStackTrace();
            }
    }

    protected List selectCyclesFromCountry(String countryid) throws Exception{
        return utilDAO.getCycleStatefromCountry(countryid);
    }


    /**
     * Performs the PRE_CERTIFICATION operation for the selected cycles.
     * @param cycleid
     */
    public boolean preCertifyCycles(String cycleid){
        boolean status = false;
        try{
                List templist = getIApprovedCycles(cycleid);
                if (templist.size()==0){
                    //putIntoPreCertifyState(cycleid);
                    status = true;
                }
                else{
                    List modifiedList = removeRejectedActivities(templist);
                    if(modifiedList.size()==0){
                        status = true;
                    }
                    HashSet set =  new HashSet();
                    Iterator iterator = modifiedList.iterator();
                    while(iterator.hasNext()){
                        DocPublishObject docPublishObject = (DocPublishObject)iterator.next();
                        String activityid = docPublishObject.getActivity_id();
                        String reqtype = docPublishObject.getReq_type();
                        String text = docPublishObject.getDoc_text();
                        String ctrlobjid = docPublishObject.getCobj_id();
                        String priority = docPublishObject.getPriority();
                        int overflowid = docPublishObject.getOverflow_id ();

                        if (reqtype.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                            if (utilDAO.checkIApproved(activityid)){
                                if (utilDAO.add_question_Precertify(activityid,priority))
                                    status = true;
                                    //utilDAO.setPreCertifyState(cycleid);
                            }else{
                                    removeIANotApproved(activityid);
                                    status = true;
                                    //utilDAO.setPreCertifyState(cycleid);
                            }
                        } else
                        if(set.add(activityid))
                        {
                            if (reqtype.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
                               // if (utilDAO.checkIApproved(activityid)){
                                    if (utilDAO.addModifyPreCertify(activityid,text,priority, overflowid))
                                        status = true;
                                        //utilDAO.setPreCertifyState(cycleid);
                               // }
                            } else

                            if (reqtype.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
                                //if (utilDAO.checkIApproved(activityid)){
                                    if (utilDAO.remove_PreCertify(activityid,ctrlobjid))
                                        status = true;
                                        //utilDAO.setPreCertifyState(cycleid);
                                //}
                            }
                        }
                    }
                }
        }
        catch (Exception e) {
            System.err.println("Could not get new List" + e);
            e.printStackTrace();
        }

        return status;
//        try {
//                if (utilDAO.checkIANotApproved(cycleid)){
//                    utilDAO.setPreCertifyState(cycleid);
//                }
//                else
//                putIntoPreCertifyState(cycleid);
////                utilDAO.setInitialActiontoPreCertify(cycleid);
//                    }
//                    catch (Exception e) {
//                       System.err.println("Could not get new List" + e);
//                        e.printStackTrace();
//                    }

    }

    public void removeIANotApproved(String activityid) throws Exception{
        utilDAO.remove_IANotApproved(activityid);
    }

    public List getIApprovedCycles(String cycleid) throws Exception{
        return utilDAO.getIApprovedCycles(cycleid);
    }

    /**
     * call to the DAO to set selected cycle into PRE_CERTIFICATION state
     * @param cycleid
     * @throws Exception
     */
    public void putIntoPreCertifyState(String cycleid) throws Exception{
        utilDAO.setPreCertifyState(cycleid);
    }

    /**
     * Performs date validations, retrives the countries that are in ONLY
     * INITIATED and RELEASED states to populate with dates and populates
     * these cycles with the start & end dates entered
     * @param dochangeform
     * @param countryid
     * @throws Exception
     */
    public void checkdates(DocChangeForm dochangeform,String countryid) throws Exception{
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String sdate = dochangeform.getSdate();
        String edate = dochangeform.getEdate();
        List tempList = new ArrayList();
        try {
                    Date b_date = new Date(df.parse(sdate).getTime());
                    Date e_date = new Date(df.parse(edate).getTime());

                    String st_date = (df.format((b_date)));
                    String ed_date = (df.format((e_date)));

                    if ((!st_date.equals(sdate)) || (!ed_date.equals(edate))){
                        throw new DateFormatException(new Exception("Date Format is Incorrect"));
                    }

                    if ((e_date.after(b_date)) || (e_date.equals(b_date))){
                        try{
                            tempList = countriesforDates(countryid);
                        }
                        catch (Exception e){
                            if (e instanceof NoInitiatedCycleException)
                                throw new NoInitiatedCycleException();
                        }

                        Iterator iterator = tempList.iterator();
                        while(iterator.hasNext()){
                            String cycleid = (String)iterator.next();
                            insertDatesforCycles(cycleid,b_date,e_date);
                        }
                    }
                    else throw new DateSequenceException(new Exception("Date Sequence is Incorrect"));
                }catch (ParseException e){
                throw new IncorrectDateException(new Exception("Incorrect Date Entered"));
            }
    }

    /**
     * call to DAO to insert start & end dates for the respective cycles
     * @param cycleid
     * @param b_date
     * @param e_date
     * @throws Exception
     */
    protected void insertDatesforCycles(String cycleid, Date b_date, Date e_date) throws Exception{
        utilDAO.putDatesInCycles(cycleid,b_date,e_date);
    }

    /**
     * Sets the respective cycles into the LOCKED state.
     * @param cycleMaintainObject
     * @param cycleid
     * @param state
     * @param begin_date
     * @param end_date
     * @param locked
     * @throws Exception
     */
    public void lockedCycles(DocChangeForm dochangeform, CycleMaintainObject cycleMaintainObject, String cycleid, String state, String begin_date, String end_date, boolean locked) throws Exception{
        if (((!begin_date.equals("")) && (!(begin_date == null))) && ((!(end_date == null)) && (!end_date.equals(""))) && (locked)){
                    try {
                            putIntoLockedState(cycleid,state,begin_date,end_date,locked);
                        }
                    catch (Exception e) {
                        if(e instanceof IncorrectDateException ){
                            setFalseLockChecks(dochangeform);
                            throw new IncorrectDateException();
                        }
                        if(e instanceof DateSequenceException ){
                            setFalseLockChecks(dochangeform);
                            throw new DateSequenceException();
                        }
                        if(e instanceof DateFormatException ){
                            setFalseLockChecks(dochangeform);
                            throw new DateFormatException();
                        }
                        System.err.println("Could not set Release info due to" + e);
                        e.printStackTrace();
                        }

                }
    }

    /**
     * call to DAO to set the respective cycle to LOCKED State
     * @param cycleid
     * @param state
     * @param begin_date
     * @param end_date
     * @param locked
     * @throws Exception
     */
    protected void putIntoLockedState(String cycleid, String state, String begin_date, String end_date, boolean locked) throws Exception{
        utilDAO.setLockedState(cycleid,state,begin_date,end_date,locked);
    }

    /**
     * sets the respective cycles into the RELEASED state.
     * @param cycleMaintainObject
     * @param cycleid
     * @param state
     * @param begin_date
     * @param end_date
     * @param docrelease
     * @throws Exception
     */
    public void releaseCycles(DocChangeForm dochangeform, CycleMaintainObject cycleMaintainObject, String countryid, String cycleid, String state, String begin_date, String end_date, boolean docrelease) throws Exception{
        if (((!begin_date.equals("")) && (!(begin_date == null))) && ((!(end_date == null)) && (!end_date.equals(""))) && (docrelease)){
                try {
                        putIntoReleaseState(cycleid,state,begin_date,end_date,docrelease);
                    }
                    catch (Exception e) {
                        if(e instanceof IncorrectDateException ){
                            setFalseReleaseChecks(dochangeform);
                            throw new IncorrectDateException();
                        }
                        if(e instanceof DateSequenceException ){
                            setFalseReleaseChecks(dochangeform);
                            throw new DateSequenceException();
                        }
                        if(e instanceof DateFormatException ){
                            setFalseReleaseChecks(dochangeform);
                            throw new DateFormatException();
                        }
                        System.err.println("Could not set Release info due to" + e);
                        e.printStackTrace();
                        }
                }
        }

    /**
     * call to DAO to set the respective cycle to RELEASE state
     * @param cycleid
     * @param state
     * @param begin_date
     * @param end_date
     * @param docrelease
     * @throws Exception
     */
    public void putIntoReleaseState(String cycleid, String state, String begin_date, String end_date, boolean docrelease) throws Exception{
        utilDAO.setReleaseState(cycleid,state,begin_date,end_date,docrelease);
    }

    /**
     * call to DAO to return List of cycles for the selected country
     * @param countryid
     * @return
     * @throws Exception
     */
    protected List countriesforDates(String countryid) throws Exception{
        return utilDAO.getCountriesInitiated(countryid);
    }

    private void setFalseReleaseChecks(DocChangeForm dochangeform){
        List tempList = dochangeform.getCyclemaintainobjectlist();
        Iterator iterator = tempList.iterator();
        while(iterator.hasNext()){
            CycleMaintainObject cycleMaintainObject = (CycleMaintainObject)iterator.next();
            cycleMaintainObject.setDocrelease(false);
        }
    }

    private void setFalseLockChecks(DocChangeForm dochangeform){
        List tempList = dochangeform.getCyclemaintainobjectlist();
        Iterator iterator = tempList.iterator();
        while(iterator.hasNext()){
            CycleMaintainObject cycleMaintainObject = (CycleMaintainObject)iterator.next();
            cycleMaintainObject.setLocked(false);
        }
    }

    public void initiateCycles(DocChangeForm dochangeform, CycleMaintainObject cycleMaintainObject, String countryid, String cycleid, String state, String begin_date, String end_date, boolean docrelease) throws Exception{
        if (((!begin_date.equals("")) && (!(begin_date == null))) && ((!(end_date == null)) && (!end_date.equals("")))){
                try {
                        putIntoInitiateState(cycleid,state,begin_date,end_date);
                    }
                    catch (Exception e) {
                        if(e instanceof IncorrectDateException ){
                            throw new IncorrectDateException();
                        }
                        if(e instanceof DateSequenceException ){
                            throw new DateSequenceException();
                        }
                        if(e instanceof DateFormatException ){
                            throw new DateFormatException();
                        }
                        System.err.println("Could not set Release info due to" + e);
                        e.printStackTrace();
                        }
                }
    }

    private void putIntoInitiateState(String cycleid, String state, String begin_date, String end_date) throws Exception{
        utilDAO.setInitiateState(cycleid, state, begin_date, end_date);
    }

    public List removeRejectedActivities(List activityList){
        List tempList = new ArrayList();
        Iterator iterator = activityList.iterator();
        while(iterator.hasNext()){
          DocPublishObject docPublishObject = (DocPublishObject)iterator.next();
            String requestType = docPublishObject.getReq_type();
            boolean approval = docPublishObject.isApproved();

            if(approval && (requestType.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE) || requestType.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY))){
                tempList.add(docPublishObject);
            }

            if(requestType.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                tempList.add(docPublishObject);
            }


        }
        return tempList;
    }
}
