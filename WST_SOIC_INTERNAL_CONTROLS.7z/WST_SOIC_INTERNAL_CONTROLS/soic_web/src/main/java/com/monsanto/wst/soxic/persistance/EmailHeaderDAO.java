package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.EmailHeaderForm;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.Map;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 20, 2006
 * Time: 1:33:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmailHeaderDAO {
    public Map selectHeader() throws DatabaseException {
        Map emailHeaderMap = new HashMap();
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT NAME,TYPE,VALUE FROM LOOKUP WHERE TYPE='EMAIL_HEADER'");
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                String name=resultSet.getString("NAME");
                String value=resultSet.getString("VALUE");
                emailHeaderMap.put(name,value);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            throw new DatabaseException(e.getMessage());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new DatabaseException(e.getMessage());
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("");
            }
        }
        return emailHeaderMap;
    }

    public void updateEmailHeader(EmailHeaderForm emailHeaderForm) throws DatabaseException {
       Connection connection = null;
        PreparedStatement preparedStatement=null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE LOOKUP SET VALUE=? WHERE NAME=?");
            preparedStatement.setString(1,emailHeaderForm.getActivityEmailHeader());
            preparedStatement.setString(2,SoxicConstants.ACTIVITY_EMAIL_HEADER);
            preparedStatement.addBatch();
            preparedStatement.setString(1,emailHeaderForm.getSubCycleEmailHeader());
            preparedStatement.setString(2,SoxicConstants.SUB_CYCLE_EMAIL_HEADER);
            preparedStatement.addBatch();
            preparedStatement.setString(1,emailHeaderForm.getCycleEmailHeader());
            preparedStatement.setString(2,SoxicConstants.CYCLE_EMAIL_HEADER);
            preparedStatement.addBatch();

            preparedStatement.executeBatch();

        }
        catch (SQLException e) {
            e.printStackTrace();
            throw new DatabaseException(e.getMessage());
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new DatabaseException(e.getMessage());
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("");
            }
        }
    }
}
