package com.monsanto.wst.soxic.shared.overflow;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 24, 2005
 * Time: 2:56:26 PM
 * To change this template use File | Settings | File Templates.
 */

public class OverFlowUtilDAO {

    public static final String MAX_SEQ ="SELECT MAX(SEQUENCE) AS MAXSEQ FROM TEXT_OVERFLOW";
    public static final String INSERT_TEXT_OVERFLOW ="INSERT INTO TEXT_OVERFLOW (OVERFLOW_ID,SEQUENCE,TEXT_CHUNK) VALUES(?,?,?)";
    public static final String SEQUENCE_QUERY = "select overflow_id_sequence.nextval as SEQUENCE from dual";


    public int getMaxSequenceOverFlowId() throws Exception {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int result=-1;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement =  con.prepareStatement(MAX_SEQ);
            rs = preparedStatement.executeQuery();
            while (rs.next()){
                result = rs.getInt("MAXSEQ");
            }
        }
        catch (EmptyResultSetException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        catch (WrappingException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return result;
    }

    public int insertOverFlowIntoDB(OverFlow overFlow) throws Exception {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            String query ="INSERT INTO TEXT_OVERFLOW (OVERFLOW_ID,SEQUENCE,TEXT_CHUNK) VALUES (?,?,?)";
            preparedStatement = con.prepareStatement(query);
            Iterator iterator = overFlow.getSequenceTextList().iterator();
            while(iterator.hasNext()){
                SequenceText sequenceText = (SequenceText) iterator.next();
                preparedStatement.setString(1, overFlow.getOverFlowId());
                preparedStatement.setString(2, sequenceText.getSequence());
                preparedStatement.setString(3, sequenceText.getText());
                preparedStatement.addBatch();
            }
            int result[] = preparedStatement.executeBatch();
        }
        catch (WrappingException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return -1;
    }

    public Integer nextSequence(Connection connection) throws WrappingException, EmptyResultSetException,
        SQLException {
        Integer retVal = new Integer(0);
        PreparedStatement statement = connection.prepareStatement(SEQUENCE_QUERY);

        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            retVal = new Integer(resultSet.getString(1));
        }

        return retVal;
    }

    public void deleteOverFlow(SignificantChangeModel significantChange) throws Exception {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            String query ="DELETE FROM TEXT_OVERFLOW WHERE OVERFLOW_ID = ? AND SEQUENCE = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, significantChange.getOverFlowId());
            preparedStatement.setString(2, significantChange.getSeqindex());

            preparedStatement.executeQuery();
        }
        catch (WrappingException e) {
            e.printStackTrace(); 
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }
}

