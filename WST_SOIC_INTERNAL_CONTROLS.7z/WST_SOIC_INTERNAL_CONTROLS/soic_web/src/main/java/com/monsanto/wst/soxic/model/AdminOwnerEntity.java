/*
 * Created on Mar 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Date;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminOwnerEntity {
    
    private String  ownerId;
    private String  cycleId   ;
    private String  subCycleId ;
    private String  activityId ;
    
    private String  status;
    private Date    startDate;
    private Date    dueDate;
    private Date    completeDate;
    private Date    modDate;
    private String  modUser;
    
    private String  type;

    /**
     * @return Returns the completeDate.
     */
    public Date getCompleteDate() {
        return completeDate;
    }
    /**
     * @param completeDate The completeDate to set.
     */
    public void setCompleteDate(Date completeDate) {
        this.completeDate = completeDate;
    }
    /**
     * @return Returns the dueDate.
     */
    public Date getDueDate() {
        return dueDate;
    }
    /**
     * @param dueDate The dueDate to set.
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
   
    /**
     * @return Returns the modDate.
     */
    public Date getModDate() {
        return modDate;
    }
    /**
     * @param modDate The modDate to set.
     */
    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }
    /**
     * @return Returns the modUser.
     */
    public String getModUser() {
        return modUser;
    }
    /**
     * @param modUser The modUser to set.
     */
    public void setModUser(String modUser) {
        this.modUser = modUser;
    }
    /**
     * @return Returns the ownerId.
     */
    public String getOwnerId() {
        return ownerId;
    }
    /**
     * @param ownerId The ownerId to set.
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
    /**
     * @return Returns the startDate.
     */
    public Date getStartDate() {
        return startDate;
    }
    /**
     * @param startDate The startDate to set.
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }
    /**
     * @param type The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return Returns the activityId.
     */
    public String getActivityId() {
        if(activityId== null || activityId == "")
            activityId="----";
        return activityId;
    }
    /**
     * @param activityId The activityId to set.
     */
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }
    /**
     * @return Returns the cycleId.
     */
    public String getCycleId() {
        
        if(cycleId == null || cycleId == "")
            cycleId="----";
        return cycleId;
    }
    /**
     * @param cycleId The cycleId to set.
     */
    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }
    /**
     * @return Returns the subCycleId.
     */
    public String getSubCycleId() {
        if(subCycleId == null || subCycleId=="")
            subCycleId="----";
        return subCycleId;
    }
    /**
     * @param subCycleId The subCycleId to set.
     */
    public void setSubCycleId(String subCycleId) {
        this.subCycleId = subCycleId;
    }
}
