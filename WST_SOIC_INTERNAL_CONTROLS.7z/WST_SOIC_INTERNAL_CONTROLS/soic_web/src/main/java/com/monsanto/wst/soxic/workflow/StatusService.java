/*
 * Created on Apr 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import com.monsanto.wst.soxic.exception.BadDataException;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.*;
import com.monsanto.wst.soxic.workflow.certificationstartemails.ActivityStartOpertions;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.TimerTask;

/**
 * @author vrbethi
 * Preferences - Java - Code Style - Code Templates
 */
public class StatusService extends TimerTask {

	public void run() {
		if(doRun()){
			try {
				addEntryToDatabase();
				ActivityOperations activityOperations = new ActivityOperations();
                ActivityStartOpertions activityStartOpertions = new ActivityStartOpertions(SoxicConstants.ACTIVITY);
				ControlObjectiveStatusOperation controlObjectiveOperations = new ControlObjectiveStatusOperation();
				SubCycleStatusOperation subCycleObjectiveOperations = new SubCycleStatusOperation();
				CycleStatusOperation cycleObjectiveOperations = new CycleStatusOperation();
    			activityOperations.updateActivityStatus();
				activityStartOpertions.sendStartEmail();
				activityOperations.sendOverDueNotificationEmail();
				controlObjectiveOperations.updateControlObjectiveStatus();
				subCycleObjectiveOperations.sendStartEmail();
				subCycleObjectiveOperations.sendPastDueEmail();
				subCycleObjectiveOperations.updateOwnerSubCycleStatus();
				subCycleObjectiveOperations.updateSubCycleStatus();
				cycleObjectiveOperations.sendStartEmail();
				cycleObjectiveOperations.sendOverDueEmail();
				cycleObjectiveOperations.updateOwnerCycleStatus();
				cycleObjectiveOperations.updateCycleStatus();

        PeriodCompletionOperation periodCompletionOperation = new PeriodCompletionOperation();
        periodCompletionOperation.selectAllCompleteCycles();
        periodCompletionOperation.updateCycleStateToComplete();

        DocChangeOperations dochangeoperations = new DocChangeOperations();
        dochangeoperations.docChangeStartDate();
        dochangeoperations.docChangePriorDueDate();

        TempIAResponseNotification tempIAResponseNotification = new TempIAResponseNotification();
        tempIAResponseNotification.process();

        TempSubCycleApprovalRequestNotification tempSubCycleApprovalRequestNotification = new TempSubCycleApprovalRequestNotification();
        tempSubCycleApprovalRequestNotification.process();

        DocumentChangeRequestResponseListInt documentChangeRequestResponseList = new DocumentChangeRequestResponseList();
        IAAdminDocumentChangeRequestEmailer iaAdminDocumentChangeRequestEmailer = new IAAdminDocumentChangeRequestEmailer();
        iaAdminDocumentChangeRequestEmailer.process(documentChangeRequestResponseList);

        activityOperations.updateOverAllActivityStatus();
        controlObjectiveOperations.updateOverAllControlObjectiveStatus();
        subCycleObjectiveOperations.updateOverAllSubCycleStatus();
        cycleObjectiveOperations.updateOverAllCycleStatus();
			} catch (Exception e) {
				if(e instanceof BadDataException){
					addFailureEntryToDatabase();
					sendBadDataEmail();
				}
         e.printStackTrace();
			}

			System.out.println("Done Executing schedule service");
		}else{
			Date date = new Date(System.currentTimeMillis());
			System.err.println("Scheduled process executed for today already "+date);
		}
	}

	private boolean doRun() {
		Connection connection = null;
		PreparedStatement addTimeEntry = null;
		ResultSet rs=null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			addTimeEntry = connection
					.prepareStatement("SELECT * FROM LOG WHERE LOG_DATE=?");
			Date today = new Date(System.currentTimeMillis());
			addTimeEntry.setDate(1,today);	
			rs = addTimeEntry.executeQuery();
			
			while(rs.next()){
				return false;
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(addTimeEntry);
				SoxicConnectionFactory.closeSoxicConnection(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return true;
	}

	private void addEntryToDatabase() {

		Connection connection = null;
		PreparedStatement addTimeEntry = null;
		Calendar calendar = Calendar.getInstance();
		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			addTimeEntry = connection
					.prepareStatement("INSERT INTO LOG (LOG_DATE,LOG_TITLE,LOG_TEXT) VALUES(?,?,?)");
			Date today = new Date(System.currentTimeMillis());
			addTimeEntry.setDate(1,today);
			addTimeEntry.setString(2,"WORKFLOW");
			addTimeEntry.setString(3,"SUCCESS "+calendar.getTime()+" "+calendar.getTimeZone());
			addTimeEntry.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closePreparedStatement(addTimeEntry);
				SoxicConnectionFactory.closeSoxicConnection(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	private void addFailureEntryToDatabase() {

		Connection connection = null;
		PreparedStatement addTimeEntry = null;
		Calendar calendar = Calendar.getInstance();
		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			addTimeEntry = connection
					.prepareStatement("INSERT INTO LOG (LOG_DATE,LOG_TITLE,LOG_TEXT) VALUES(?,?,?)");
			Date today = new Date(System.currentTimeMillis());
			addTimeEntry.setDate(1,today);
			addTimeEntry.setString(2,"WORKFLOW");
			addTimeEntry.setString(3,"FAILURE "+calendar.getTime()+" "+calendar.getTimeZone());
			addTimeEntry.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closePreparedStatement(addTimeEntry);
				SoxicConnectionFactory.closeSoxicConnection(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void sendBadDataEmail(){
		try{
			SarboxMailComponent.sendBadDataEmail();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}