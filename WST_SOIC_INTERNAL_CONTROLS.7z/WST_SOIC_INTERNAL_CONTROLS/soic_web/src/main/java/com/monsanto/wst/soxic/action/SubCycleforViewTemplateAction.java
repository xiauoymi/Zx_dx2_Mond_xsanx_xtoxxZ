package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.ExportTemplateForm;
import com.monsanto.wst.soxic.model.AdminTemplateDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 5, 2005
 * Time: 11:45:32 AM
 * 
 * This class selects the subcycles based on the cycle selected from the
 * drop-down menu. If no subcycles exists, a NullAndArrayIndexException
 * is thrown.
 */

public class SubCycleforViewTemplateAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        ExportTemplateForm exporttemplateform = (ExportTemplateForm)form;
        AdminTemplateDAO admintemplatedao = new AdminTemplateDAO();
        String cycleid = exporttemplateform.getSelectedCycles();

        try {
                exporttemplateform.setSubcycle(admintemplatedao.getSubCyclesforViewTemplates(cycleid));

            }
            catch (Exception e) {
            if (e instanceof NullAndArrayIndexException){
                throw new NullAndArrayIndexException();
            }
                System.err.println("Could not get subcycle List due to" + e);
                e.printStackTrace();
            }

        return mapping.findForward("subcycleviewtemplates");
    }
}
