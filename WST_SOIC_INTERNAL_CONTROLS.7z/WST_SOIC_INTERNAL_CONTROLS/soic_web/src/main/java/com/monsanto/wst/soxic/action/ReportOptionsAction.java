//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.form.ReportOptionsForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

/** 
 * MyEclipse Struts
 * Creation date: 02-28-2005
 * 
 * XDoclet definition:
 * @struts:action path="/reportOptions" name="reportOptionsForm" scope="request" validate="true"
 */
public class ReportOptionsAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	String reportSelected = "";
	
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		ReportOptionsForm reportOptionsForm = (ReportOptionsForm) form;
		
		reportSelected = request.getParameter("selectedReport");
		
//		if(reportSelected.equalsIgnoreCase("Delinquents Report")){
//			return mapping.findForward("delinquentReport");
//		}

        if(reportSelected.equalsIgnoreCase(SoxicConstants.EXPORT_TEMPLATE_REPORT)){
			return mapping.findForward("adminExportScreen");
		}

        if (reportSelected.equalsIgnoreCase(SoxicConstants.OWNER_CERTIFICATION_STATUS_REPORT)){
            return mapping.findForward("ownerCertStatus");
        }

        if (reportSelected.equalsIgnoreCase(SoxicConstants.ORPHAN_REPORT)){
            return mapping.findForward("orpReport");
        }


        if (reportSelected.equalsIgnoreCase(SoxicConstants.DOC_CHANGES_REPORT)) {
            return mapping.findForward("docChangesReport");
        }


//		if(reportSelected.equalsIgnoreCase("Activity Dashboard Report")){
//			return mapping.findForward("activityDashboardReport");
//		}
		
//		if(reportSelected.equalsIgnoreCase("Subcycle Dashboard Report")){
//			return mapping.findForward("subcycleDashboardReport");
//		}
//		
//		if(reportSelected.equalsIgnoreCase("Cycle Dashboard Report")){
//			return mapping.findForward("cycleDashboardReport");
//		}
		
//		if(reportSelected.equalsIgnoreCase("Summary Dashboard Report")){
//			return mapping.findForward("summaryDashboardReport");
//		}
		
		reportOptionsForm.setReportSelected(request.getParameter("selectedReport"));
		
		Vector cycleList = new Vector();		
		cycleList.add("All Cycles");
		
		Vector cycleCodeList = new Vector();		
		cycleCodeList.add("All Cycles");
		
		Vector allCountryList = new Vector();		
		allCountryList.add("All Countries");
		
		Vector periodList = new Vector();
		//periodList.add("");
		
		//**Connecting to the Oracle DB...
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			Connection con = SoxicConnectionFactory.getSoxicConnection();
			ResultSet rs;
		 	
		 	logger.info("Connected to DB from /reportOptions.");
			
			//**Prepared Statements...
			PreparedStatement getCycleList;
			PreparedStatement getCycleIDList;
			PreparedStatement getAllCountryList;
			PreparedStatement getPeriodList;

//            getPeriodList = con.prepareStatement
//                    ("SELECT DISTINCT PERIOD_ID " +
//                            "FROM CYCLE");
            getPeriodList = con.prepareStatement("SELECT PERIOD_ID FROM PERIOD ORDER BY SEQUENCE DESC");

            ResultSet rs1 = getPeriodList.executeQuery();
            while (rs1.next()) {
                periodList.add(rs1.getString("PERIOD_ID"));
            }
            rs1.close ();

            getCycleIDList = con.prepareStatement
                    ("SELECT CYCLE_ID " +
                            "FROM CYCLE");
            ResultSet rs2 = getCycleIDList.executeQuery();
            while (rs2.next()) {
                cycleList.add(rs2.getString("CYCLE_ID"));
            }
            rs2.close();

            getCycleList = con.prepareStatement
                    ("SELECT DISTINCT CYCLE_CODE " +
                            "FROM CYCLE");
            ResultSet rs3 = getCycleList.executeQuery();
            while (rs3.next()) {
                cycleCodeList.add(rs3.getString("CYCLE_CODE"));
            }
            rs3.close ();


            getAllCountryList = con.prepareStatement
                    ("SELECT VALUE FROM LOOKUP WHERE TYPE='COUNTRYID'");
            ResultSet rs4 = getAllCountryList.executeQuery();
            while (rs4.next()) {
                allCountryList.add(rs4.getString("VALUE"));
            }
            rs4.close();

            con.close();
		
		}
		catch(Exception ex){
			logger.error("DB problem" + ex.getMessage());
		}

        reportOptionsForm.setAllCountryList(allCountryList);
		reportOptionsForm.setCycleList(cycleList);
		reportOptionsForm.setCycleCodeList(cycleCodeList);
        reportOptionsForm.setPeriodList(periodList);
		
		return mapping.findForward("success");
		
	}

}