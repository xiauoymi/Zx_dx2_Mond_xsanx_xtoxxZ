package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.model.HeaderFooterDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:05:14 AM
 * To change this template use File | Settings | File Templates.
 */

public class CycleHeadFootSet extends HeadFootSet{

    public void setHeaderAndFooter(QuestionAdminForm questionAdminForm, HeaderFooterFacade headerFooterFacade) {
        questionAdminForm.setCycleHeader(headerFooterFacade.getHeader());
        questionAdminForm.setCycleFooter(headerFooterFacade.getFooter());
    }

    public void updateHeaderIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getCycleHeader(), SoxicConstants.CYCLE_QUESTION_HEADER,SoxicConstants.QUESTION_HEADER);
    }

    public void updateFooterIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getCycleFooter(), SoxicConstants.CYCLE_QUESTION_FOOTER, SoxicConstants.QUESTION_FOOTER);
    }
}
