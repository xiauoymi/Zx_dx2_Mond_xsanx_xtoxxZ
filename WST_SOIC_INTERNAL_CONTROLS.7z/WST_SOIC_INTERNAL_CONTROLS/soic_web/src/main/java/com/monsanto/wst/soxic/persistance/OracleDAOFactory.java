/*
* Created on Jan 28, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.PeriodDAO;


/**
 * @author SPOLAVA
 *
 * OracleDAOFactory class extends the AbstractDAOFactory. This class implements getter
 * methods that returns DAO objects like OracleCycleDAO, OracleSubCycleDAO, 
 * OracleControlObjectiveDAO, OracleActivityDAO etc...
 *   
 */
public class OracleDAOFactory extends AbstractDAOFactory {

    /**
     * getOwnerDAO method returns OracleOwnerDAO
     * @return OracleOwnerDAO
     */
//	public DAO getOwnerDAO() {
//		return new OracleOwnerDAO();
//	}
    /**
     * getCycleDAO method returns OracleCycleDAO
     * @return OracleCycleDAO
     */
    public DAO getCycleDAO() {
        return new OracleCycleDAO();
    }
    /**
     * getSubCycleDAO method returns OracleSubCycleDAO
     * @return OracleSubCycleDAO
     */
    public DAO getSubCycleDAO() {
        return new OracleSubCycleDAO();
    }
    /**
     * getControlObjectiveDAO method returns OracleControlObjectiveDAO
     * @return OracleControlObjectiveDAO
     */
    public DAO getControlObjectiveDAO() {
        return new OracleControlObjectiveDAO();
    }

    public DAO getQuestionDAO(){
        return new OracleQuestionDAO();
    }
    /**
     * getActivityDAO method returns OracleActivityDAO
     * @return OracleActivityDAO
     */
    public DAO getActivityDAO() {
        return new OracleActivityDAO();
    }

    public DAO getResponseDAO() {
        return new OracleResponseDAO();
    }

    public DAO getPeriodDAO(){
        return new PeriodDAO();
    }

    public DAO getOwnerChangeRequestDAO(){
        return new OracleOwnerChangeRequestDAO();
    }

    public DAO getOwnerChangeRequestResponseDAO(){
        return new OracleOwnerChangeRequestResponseDAO();
    }

    public DAO getOracleDocumentChangeDAO(){
        return new OracleDocumentChangeDAO();
    }

//    public DAO getOwnerAdminOwnerDAO(){
//        return new OracleAdminOwnerDAO();
//    }

}
