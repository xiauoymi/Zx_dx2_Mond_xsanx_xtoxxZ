package com.monsanto.wst.soxic.importProject;

import org.apache.poi.hssf.record.Record;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.log4j.Category;

import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CharacterCodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.exception.*;
import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 9, 2005
 * Time: 8:46:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportTemplateActivityCodes {

    //**Questions: Level_types...
	//***********************************************************************************
	String activityLevelTypeCode = "ACT";
	String subCycleLevelTypeCode = "SC";
	String cycleLevelTypeCode = "C";

	Vector activityQuestionId = new Vector();
	Vector subCycleQuestionId = new Vector();
	Vector cycleQuestionId = new Vector();

	ResultSet rs2;

	//***********************************************************************************

	private String filename = null;
	//private static String folderName = "ExcelFiles";
	private static String folderName = "//finch/wst/$Team/Private/IntranetPractice/SOXIC/Templates/FY05Loaded";

    // private POIFSFileSystem     fs           = null;
    private InputStream    stream       = null;
    private Record[]       records      = null;
    protected HSSFWorkbook hssfworkbook = null;
    protected HSSFWorkbook wb = null;
    protected HSSFSheet sheet = null;

    //**For storing excel header info (cycle owner, coutry, world area etc..)
    public ExcelHeaderBean headerBean = new ExcelHeaderBean();

    //**For storing the rowset...
    Vector ExcelRow = new Vector();
    Vector ExcelRowSet = new Vector();

    Vector cycleOwners = new Vector();
	Vector subCycleOwners = new Vector();

    //**Todays Date...
    Date date = new Date(System.currentTimeMillis());

    //**Database Objects...
    Connection con;

    //**Prepared Statements...(for 8 tables)
    PreparedStatement insertCycle;
    PreparedStatement insertOwnerCycle;

    PreparedStatement insertSubCycle;
    PreparedStatement insertOwnerSubCycle;

    PreparedStatement insertControlObj;

    PreparedStatement insertOwner;
    PreparedStatement insertActivity;
    PreparedStatement insertOwnerActivity;

    PreparedStatement insertControlObjectiveCode;

    PreparedStatement insertCycleState;

    //** Update loc for cycle/subcycle owners.
    PreparedStatement getLocation;
    PreparedStatement updateLocation;

    //**Integrating Questions in Import...
    //***********************************************************************************
    PreparedStatement getQuestionId;

    PreparedStatement insertQuestionActivity;
    PreparedStatement insertQuestionSubCycle;
    PreparedStatement insertQuestionCycle;
    //***********************************************************************************

    //**Large-Text-Handling
    PreparedStatement insertTextOverflow;
    PreparedStatement insertActivityOverflowId;
    PreparedStatement insertCtrlObjOverflowId;
    PreparedStatement getOverflowTableSize;

    //**Log4j logger
    static Category logger = Category.getInstance(ImportTemplateActivityCodes.class.getName());

    //**Row info
    int rowSkipped = 0;
    int totalRows = 0;


	/**
     * Constructor - creates an HSSFStream from an InputStream.  The HSSFStream
     * reads in the records allowing modification.
     *
     *
     * @param filename
     *
     * @exception IOException
     *
     */

//    public ImportExcel2DB(FormFile ff,String environment,String envVariable) throws IOException
    public ImportTemplateActivityCodes(String filename,String environment,String envVariable) throws IOException
    {
            	//**Connecting to the Oracle DB...
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//**For connecting to DEV Database...
			System.setProperty("DMONCRYPTJV",envVariable);
			BufferedReader brIn = null;
			String hexKey = null;
			String keyFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "KeyValue.hex";
			String cipherFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "CipherValue.hex";
			try
			{
				brIn = new BufferedReader(new FileReader(keyFile));
				hexKey = brIn.readLine();
			}
			catch (FileNotFoundException ex)
			{
				throw new EncryptorException("EncryptionUtils::GetDecryptedStringFromExternalStorage - Invalid key file name.");
			}

			if(environment.equalsIgnoreCase("development")){
				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
				con = DriverManager.getConnection (SoxicUtil.getOracleDevServerConnectionString(), SoxicUtil.getOracleDevServerUserName(), decryptedPassword);
			}

			if(environment.equalsIgnoreCase("test")){
				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
				//**For connecting to Test Database...
				con = DriverManager.getConnection (SoxicUtil.getOracleTestServerConnectionString(), SoxicUtil.getOracleTestServerUserName(), decryptedPassword);
			}

			if(environment.equalsIgnoreCase("production")){

				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
				//**For connecting to Test Database...
				con = DriverManager.getConnection (SoxicUtil.getOracleProductionServerConnectionString(),SoxicUtil.getOracleProductionServerUserName(), decryptedPassword);
			}
			//**Code that creates Prepared statements for import...
			//**Table1
			insertOwner = con.prepareStatement("INSERT INTO OWNER (OWNER_ID, NAME, LOCATION, EMAIL, LAST_LOGIN, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)");

			//**Table2...(modified)
			insertCycle = con.prepareStatement("INSERT INTO CYCLE "
                    +"(CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            //**Table 2a... (added)
            insertCycleState = con.prepareStatement("INSERT INTO CYCLE_STATE (CYCLE_ID, PERIOD_ID, STATE, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)");

			//**Table3
			insertOwnerCycle = con.prepareStatement("INSERT INTO OWNER_CYCLE "
                    +"(OWNER_ID, CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

			//**Table4...(modified)
			insertSubCycle = con.prepareStatement("INSERT INTO SUB_CYCLE "
                    +"(SUB_CYCLE_ID, SUB_CYCLE_CODE, CYCLE_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)");

			//**Table5
			insertOwnerSubCycle = con.prepareStatement("INSERT INTO OWNER_SUB_CYCLE "
                    +"(OWNER_ID, SUB_CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

			//**Table6
			insertControlObj = con.prepareStatement("INSERT INTO CTRL_OBJ "
                    +"(CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

			//**Table7
			insertActivity = con.prepareStatement("INSERT INTO ACTIVITY "
			                       +"(ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
			                       + "VALUES (?, ?, ?, ?, ?, ?, ?)");

			//**Table8
			insertOwnerActivity = con.prepareStatement("INSERT INTO OWNER_ACTIVITY "
                    +"(OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

            insertControlObjectiveCode = con.prepareStatement("INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID,TYPE,CODE) VALUES(?,?,?)");

			//**Query for adding Location info for Cycle/SubCycle Owners as Users...
			getLocation = con.prepareStatement
				("SELECT LOCATION " +
					"FROM OWNER " +
					"WHERE OWNER_ID = ?");

			updateLocation = con.prepareStatement
				("UPDATE OWNER " +
						"SET LOCATION = ?  " +
						"WHERE OWNER_ID = ?");


			//**Queries for integrating Questions...
			//***********************************************************************************
			getQuestionId = con.prepareStatement
									("SELECT QUESTION_ID " +
										"FROM QUESTION " +
										"WHERE LEVEL_TYPE = ?");

			insertQuestionActivity = con.prepareStatement("INSERT INTO QUESTION_ACTIVITY "
                    +"(QUESTION_ID, ACTIVITY_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");

			insertQuestionSubCycle = con.prepareStatement("INSERT INTO QUESTION_SUB_CYCLE "
                    +"(QUESTION_ID, SUB_CYCLE_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");

			insertQuestionCycle = con.prepareStatement("INSERT INTO QUESTION_CYCLE "
                    +"(QUESTION_ID, CYCLE_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");
			//***********************************************************************************

			//**Large-Text-Handling
			insertTextOverflow = con.prepareStatement
					("INSERT INTO TEXT_OVERFLOW "
                    +"(OVERFLOW_ID, SEQUENCE, TEXT_CHUNK) "
                    + "VALUES (?, ?, ?)");

			insertActivityOverflowId = con.prepareStatement
					("UPDATE ACTIVITY " +
							"SET " +
								"OVERFLOW_ID = ? " +
							"WHERE " +
								"ACTIVITY_ID = ?");

			insertCtrlObjOverflowId = con.prepareStatement
					("UPDATE CTRL_OBJ " +
							"SET " +
								"OVERFLOW_ID = ? " +
							"WHERE " +
								"CTRL_OBJ_ID = ?");

			getOverflowTableSize = con.prepareStatement
				("SELECT COUNT(*) TABLESIZE FROM TEXT_OVERFLOW");



			//con.close();

		 	logger.info("-> Connected to DB.");
		}
		catch(Exception ex){
		    logger.fatal("Exception connecting to DB."+ ex.getMessage());
		}


        int startOfFileName = ImportTemplateActivityCodes.folderName.length();

                this.filename = filename.substring(startOfFileName+1);

                POIFSFileSystem fs =
                    new POIFSFileSystem(new FileInputStream(filename));

                hssfworkbook  = new HSSFWorkbook(fs);




        // records = RecordFactory.createRecords(stream);
    }



//	/**
//	 * @return Returns the folderName.
//	 */
//	public static String getFolderName() {
//		return folderName;
//	}
//	/**
//	 * @param folderName The folderName to set.
//	 */
//	public static void setFolderName(String folderName) {
//		ImportExcel2DB.folderName = folderName;
//	}


	/**
	 * @return Returns the hssfworkbook.
	 */
	public HSSFWorkbook getHssfworkbook() {
		return hssfworkbook;
	}
	/**
	 * @param hssfworkbook The hssfworkbook to set.
	 */
	public void setHssfworkbook(HSSFWorkbook hssfworkbook) {
		this.hssfworkbook = hssfworkbook;
	}
	/**
	 * @return Returns the sheet.
	 */
	public HSSFSheet getSheet() {
		return sheet;
	}
	/**
	 * @param sheet The sheet to set.
	 */
	public void setSheet(HSSFSheet sheet) {
		this.sheet = sheet;
	}
	/**
	 * @return Returns the wb.
	 */
	public HSSFWorkbook getWb() {
		return wb;
	}
	/**
	 * @param wb The wb to set.
	 */
	public void setWb(HSSFWorkbook wb) {
		this.wb = wb;
	}


	/**
	 * @return Returns the excelRowSet.
	 */
	public Vector getExcelRowSet() {
		return ExcelRowSet;
	}


	/**
	 * @return Returns the headerBean.
	 */
	public ExcelHeaderBean getHeaderBean() {
		return headerBean;
	}
	/**
	 * @param headerBean The headerBean to set.
	 */
	public void setHeaderBean(ExcelHeaderBean headerBean) {
		this.headerBean = headerBean;
	}
	/**
	 * @param excelRowSet The excelRowSet to set.
	 */
	public void setExcelRowSet(Vector excelRowSet) {
		ExcelRowSet = excelRowSet;
	}
    /**
     * Method importFile()
     * Reads the Excel file and saves the header and rowset information
     * in java objects.
     *
     *
     *
     */

    public void importFile() throws Exception{



        logger.info("-> Reading file " + filename + "...");
    	try
        {
            //**Getting the header information into the ExcelHeaderBean...
            Iterator rowIt = sheet.rowIterator();
            int totalRows = sheet.getLastRowNum();

            for (int rowno = 0; rowno < totalRows + 1; rowno++)
            //while(rowIt.hasNext())
            {
            	HSSFRow row = sheet.getRow(rowno);
//            	HSSFRow row = (HSSFRow)rowIt.next();
//            	//sheet.removeRow(row);

            	//Iterator cellIt = row.cellIterator();

            	int totalColumns = row.getLastCellNum();
            	//JOptionPane.showMessageDialog(null, "" + totalColumns);

            	for(int cellno = 0; cellno < 8; cellno++)
            	//while(cellIt.hasNext())
            	{
            		//**Get the cell value...
            		HSSFCell cell = row.getCell((short)cellno);

            		//cell.setEncoding(HSSFCell.ENCODING_UTF_16 ) ;
            		//HSSFCell cell = (HSSFCell)cellIt.next();

            		String stringval = "";

            		//**Null Cell (probably a blank/untouched or erronious cell)...
            		if(cell == null){
            			stringval = "";
            			//ExcelRow.add(cellno, "");
                		if(rowno >= 7){
                			ExcelRow.add(cellno, stringval);
                		}
            			continue;
            		}

            		if(cell.getCellType() == 0)//numeric type const
            		{
            			double numericval = cell.getNumericCellValue();
            			stringval = numericval + "";
            		}
            		else
            		{
            			if(cell.getCellType() == 1)//string type const
            			{
            				stringval = cell.getStringCellValue();
            			}
            			else
            				if(cell.getCellType() == 3)//blank type const
            				{
            					stringval = "";
            				}
            				else{ //**all other types like formula, error etc.. handled.
            					stringval = "";
            				}

            		}

            		//**Set Cycle Owner...
            		if(rowno == 0 && cellno == 0){ //**Cell A1
            			headerBean.setCycleOwner(stringval);

            			if(headerBean.getCycleOwner() != null && !headerBean.getCycleOwner().equals("")){
            				StringTokenizer cycOwntk = new StringTokenizer(headerBean.getCycleOwner(), ",");

            				int tkc = 0;
            				while(cycOwntk.hasMoreTokens()){
            				    cycleOwners.add(tkc, cycOwntk.nextToken().trim());
            				    tkc++;
            				}
            			}
            		}

            		//**Set Sub Cycle Owner...
            		if(rowno == 1 && cellno == 0){ //**Cell A2
            			headerBean.setSubCycleOwner(stringval);

            			if(headerBean.getSubCycleOwner() != null && !headerBean.getSubCycleOwner().equals("")){
            				StringTokenizer subOwntk = new StringTokenizer(headerBean.getSubCycleOwner(), ",");

            				int tkc = 0;
            				while(subOwntk.hasMoreTokens()){
            				    subCycleOwners.add(tkc, subOwntk.nextToken().trim());
            				    tkc++;
            				}
            			}
            		}

            		//**Set Cycle Desc...
            		if(rowno == 0 && cellno == 4){ //**Cell E1
            			headerBean.setCycleDesc(stringval);
            		}

            		//**Set Sub Cycle Desc...
            		if(rowno == 1 && cellno == 4){ //**Cell E2
            			headerBean.setSubCycleDesc(stringval);
            		}

            		//**Set World Area...
            		if(rowno == 2 && cellno == 0){ //**Cell A3
            			headerBean.setWorldArea(stringval);
            		}

            		//**Set Country...
            		if(rowno == 3 && cellno == 0){ //**Cell A4
            			headerBean.setCountry(stringval);
            		}



            		//**Populating the Row...
            		if(rowno >= 7){
            			ExcelRow.add(cellno, stringval);
            		}

            	}//end while cells



            	//**Populating the RowSet...
        		if(rowno >= 7){
        			ExcelRowSet.add(rowno - 7, ExcelRow);
        		}


        		ExcelRow = new Vector();

            }//end while row

            logger.info("-> Done Reading the file.");

            logger.info("-> Check Well formedness");

            //isFileWellFormed();

            logger.info("-> Begin Importing to the Database...");


            //****DB Insert...

            //**Get all Question Ids...depending on codes...{ACT, SC, C}
            //***********************************************************************************
//            getQuestionId.setString(1, activityLevelTypeCode);
//            rs2 = getQuestionId.executeQuery();
//
//            while(rs2.next()){
//            	activityQuestionId.add(rs2.getString("QUESTION_ID"));
//            }
//
//            //**Similaryly for subCycle
//            getQuestionId.setString(1, subCycleLevelTypeCode);
//            rs2 = getQuestionId.executeQuery();
//
//            while(rs2.next()){
//            	subCycleQuestionId.add(rs2.getString("QUESTION_ID"));
//            }
//
//            //**Similaryly for Cycle
//            getQuestionId.setString(1, cycleLevelTypeCode);
//            rs2 = getQuestionId.executeQuery();
//
//            while(rs2.next()){
//            	cycleQuestionId.add(rs2.getString("QUESTION_ID"));
//            }
            //***********************************************************************************

    		System.setProperty("xmlservice.peoplepicker.server","w3.ent.monsanto.com");
    		System.setProperty("xmlservice.peoplepicker.vdir","/ccca/pps");
    		System.setProperty("xmlservice.peoplepicker.endpoint","PeoplePicker.rem");
    		PeopleService svc = new PeopleService();

    		//PersonInfo[] p = svc.GetPeople(lastName, firstName, phone, mailStop, userId, site, mailZone);


            //**Add Cycle Owner to this table...
//            for(int cycnt =  0; cycnt < cycleOwners.size(); cycnt++){
//            	try{
//            		//PersonInfo[] cycOwner = svc.GetPeople("", "", "", "", cycleOwners.get(cycnt).toString().trim(), "", "");
//            		PersonInfo cycOwner = returnPeople(cycleOwners.get(cycnt).toString().trim());
//            		if(cycOwner==null){
//            			throw new InvalidUserException();
//            		}
//            		insertOwner.setString(1, cycleOwners.get(cycnt).toString().trim()); 				   //n/w id
//            		//insertOwner.setString(2, cycleOwners.get(cycnt).toString().trim()); 				   //name
//            		insertOwner.setString(2, cycOwner.getFirstName()+" "+cycOwner.getLastName()); 				   //name
//            		insertOwner.setString(3, "?");		  				         							//loc
//            		//insertOwner.setString(4, cycleOwners.get(cycnt).toString().trim() + "@monsanto.com");   //email
//            		insertOwner.setString(4, cycOwner.getEmail() + "@monsanto.com");
//
//            		insertOwner.setDate(5, date);											           			//login_date
//
//            		insertOwner.setDate(6, date);											           			//mod_date
//            		insertOwner.setString(7, "rdesai2"); 									          			 //mod_user
//
//            		insertOwner.executeUpdate();
//            	}
//            	catch(InvalidUserException e){
//            		logger.error("Invalid User " + cycleOwners.get(cycnt).toString().trim());
//            	}
//            	catch(SQLException e){
//            		if(e.getErrorCode() == 1){
//            			//***Duplicate value being added...expected error
//            			logger.warn("Duplicate Entry while adding Cycle Owner: " + e.getMessage());
//            		}
//            		else{
//            			logger.warn("Critical Unknown Error: " + e.getMessage());
//            		}
//
//            	}
//        	}

            //**Add SubCycle Owner to this table...
//            for(int sccnt =  0; sccnt < subCycleOwners.size(); sccnt++){
//            	try{
//            		//PersonInfo[] subCycOwner = svc.GetPeople("", "", "", "", subCycleOwners.get(sccnt).toString().trim(), "", "");
//            		PersonInfo subCycOwner = returnPeople(subCycleOwners.get(sccnt).toString().trim());
//            		if(subCycOwner==null){
//            			throw new InvalidUserException();
//            		}
//            		insertOwner.setString(1, subCycleOwners.get(sccnt).toString().trim()); 				   	//n/w id
//            		//insertOwner.setString(2, subCycleOwners.get(sccnt).toString().trim()); 				   //name
//            		insertOwner.setString(2, subCycOwner.getFirstName()+" "+subCycOwner.getLastName()); 				   //name
//            		insertOwner.setString(3, "?");		           											//loc
//            		//insertOwner.setString(4, subCycleOwners.get(sccnt).toString().trim() + "@monsanto.com");//email
//            		insertOwner.setString(4, subCycOwner.getEmail() + "@monsanto.com");//email
//
//            		insertOwner.setDate(5, date);											           			//login_date
//
//            		insertOwner.setDate(6, date);											           			 //mod_date
//            		insertOwner.setString(7, "rdesai2"); 									          			 //mod_user
//
//            		insertOwner.executeUpdate();
//            	}
//            	catch(InvalidUserException e){
//            		logger.error("Invalid User " + subCycleOwners.get(sccnt).toString().trim());
//            	}
//            	catch(SQLException e){
//            		if(e.getErrorCode() == 1){
//            			//***Duplicate value being added...expected error
//            			logger.warn("Duplicate Entry while adding SC Owner: " + e.getMessage());
//            		}
//            		else{
//            			logger.warn("Critical Unknown Error: " + e.getMessage());
//            		}
//            	}
//            }

            totalRows = ExcelRowSet.size();

            //**For each row, in the rowset...
            for(int rowno = 0; rowno < ExcelRowSet.size(); rowno++){

            	ExcelRow = (Vector)ExcelRowSet.get(rowno);

            	//**PeriodID..
            	String periodID = "";

            	String countryIDFromFilename = "";

            	//**Reset Codes...
            	String activityCode = "";
            	String activityID = "";

            	String controlObjCode = "";
    			String controlObjID = "";

            	String cycleCode = "";
            	String cycleID = "";

    			String subCycleCode = "";
    			String subCycleID = "";

    			//**Reset Control Objective...

    			//******Implementing the Large-Desc-Handling repair work....
    			//**Stores chunk of 2k characters...
    			Vector ctrlObjDescChunk = new Vector();
    			String controlObjDesc = "";

    			String controlObjCat = "";
    			String templateCode = "";

    			//**Reset Activity...

    			//******Implementing the Large-Desc-Handling repair work....
    			//**Stores chunk of 2k characters...
    			Vector activityDescChunk = new Vector();
    			String activityDesc = "";

    			//**Reset Risk...
    			String controlObjRisk = "";

    			//**Reset Userid and Location...
    			Vector ownerID = new Vector();
    			Vector location = new Vector();





            	//**For exactly 8 cells...
            	for(int cellno = 0; cellno < 8; cellno++){

            		//**Extract the (first cell)codes...(Required Attribute)
            		if(cellno == 0){

            		    //**Skip the row, if activity id is not present...
            		    if(ExcelRow.size() >= 1){
            		        activityID = (String)ExcelRow.get(cellno);
            		    }
            		    else{
            		        logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
            		        rowSkipped++;
            		        break;
            		    }

            			//**Double check...(for empty string)
            			if(activityID == null || activityID.equals("")){
            			    logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
            		        rowSkipped++;
            			    break;
            			}

            			//**Remove spaces...
            			activityID = activityID.trim();

            			//**Get the CycleCode from the filename...
            			StringTokenizer filest = new StringTokenizer(filename, ".");

            			//**we need first 3 tokens...
            			for(int i = 0; i < 3; i++){
            					if(i == 0){
            					    periodID = filest.nextToken();
            					}
            					if(i == 1){
            						countryIDFromFilename = filest.nextToken();
            					}
            					if(i == 2){
            					    cycleCode = filest.nextToken();
            					    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
            					}
            					logger.debug("CycleCode = " + cycleCode);
            			}

            			StringTokenizer st = new StringTokenizer(activityID, ".");

//            			//**There will be exactly 3 tokens formed...
//            			for(int i = 0; i < 3; i++){
//            				if(i==0){
//            					String tempcode = st.nextToken();
//            					subCycleCode = tempcode.substring(cycleCode.length() , tempcode.length());
//            					subCycleID = cycleID + "." + subCycleCode;
//
//            					logger.debug("SubCycleCode = " + subCycleCode);
//            				}
//            				if(i==1){
//            					controlObjCode = st.nextToken();
//            					controlObjID = subCycleID + "." + controlObjCode;
//            					logger.debug("ControlObjectiveCode = " + controlObjCode);
//            				}
//            				if(i==2){
//            					activityCode = st.nextToken();
//            					activityID = controlObjID + "." + activityCode;
//
//            					logger.debug("ActivityCode = " + activityCode);
//            				}
//            			}
        				//**There will be exactly 3 tokens formed...now exactly 4 tokens...
            			for(int i = 0; i < 4; i++){
            				if(i==0){
            					String tempcode = st.nextToken();
            					logger.info(tempcode);
            					//subCycleCode = tempcode.substring(cycleCode.length() , tempcode.length());
            					//subCycleID = cycleID + "." + subCycleCode;

            					//logger.debug("SubCycleCode = " + subCycleCode);
            				}
            				if(i==1){
            					String tempcode = st.nextToken();
            					logger.info(tempcode);
            					subCycleCode = tempcode;
            					subCycleID = cycleID + "." + tempcode;

            					logger.debug("SubCycleCode = " + subCycleCode);
            				}
            				if(i==2){
            					controlObjCode = st.nextToken();
            					controlObjID = subCycleID + "." + controlObjCode;
            					logger.debug("ControlObjectiveCode = " + controlObjCode);
            				}
            				if(i==3){
            					activityCode = st.nextToken();
            					activityID = controlObjID + "." + activityCode;

            					logger.debug("ActivityCode = " + activityCode);
            				}
            			}

            		}//end if cell 0

            		//**Cell 1: Control Objective Description...
//            		if(cellno == 1){
//
//            		    controlObjDesc = "";
//
//            		    //**Enter empty string, if enough elements not found...
//            		    if(ExcelRow.size() >= 2){
//            				controlObjDesc = (String)ExcelRow.get(cellno);
//            				//controlObjDesc = controlObjDesc.replace('',"'".charAt(0));
//            		    }
//
//        		    		//**Check for size, partition it and put it into Vector...
//        		    		if(controlObjDesc.length() <= 2000){
//        		    			if(controlObjDesc != null){
//        		    				ctrlObjDescChunk.add(controlObjDesc);
//        		    			}
//        		    			else{
//        		    				ctrlObjDescChunk.add("");
//        		    			}
//        		    		}
//        		    		else{
//        		    			for(int chCnt = 0; chCnt < controlObjDesc.length(); chCnt = chCnt + 2000){
//        		    				if(chCnt + 2000 <= controlObjDesc.length()){
//        		    					ctrlObjDescChunk.add(controlObjDesc.substring(chCnt, chCnt + 2000));
//        		    				}
//        		    				else{
//        		    					ctrlObjDescChunk.add(controlObjDesc.substring(chCnt, controlObjDesc.length()));
//        		    				}
//        		    			}
//        		    		}
//            		}

            		//**Cell 2: Control Objective Category...
            		if(cellno == 2){

            		    controlObjCat = "";

            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 3)
            				controlObjCat = (String)ExcelRow.get(cellno);
            		}


            		//**Cell 3: Template Code...
            		if(cellno == 3){

            		    templateCode = "";

            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 4)
            				templateCode = (String)ExcelRow.get(cellno);
            		}
            	}//end cell no


            	//**Enter the row into the Database...(for each row do...)
            	//(use prep stmt created in constr + transaction mgmt)

            	try{
                insertControlObjectiveCode(activityID.toString().trim(),templateCode.toString().trim());
                insertControlObjectiveCategory(activityID.toString().trim(),controlObjCat.toString().trim());
            	}
            	catch(Exception ex){
            	    logger.error("Some Critical Database error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + ex.getMessage());
            	}
            }//end row no

            //**Close the connection...
            con.close();

            logger.info("-> Successful Import !!!");
            logger.info("Number of Rows added: " + (totalRows - rowSkipped));
            if(rowSkipped == 0){
                logger.info("Rows Added: " + (totalRows - rowSkipped) +", Rows Skipped: " + (rowSkipped) + "\n");
                //logger.error(""+filename+" imported Successfully");
                Date outputDate = new Date(System.currentTimeMillis());
                (System.out).println("Success "+outputDate+" :"+filename+" imported Successfully");
            }
            else{
                logger.error("Rows Added: " + (totalRows - rowSkipped) +", Rows Skipped: " + (rowSkipped) + "\n");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            if(e instanceof SubCycleAlreadyPresent){
                throw new SubCycleAlreadyPresent();
            }
            logger.error("File Error :"+filename+" :"+e.getMessage());
        }

    }

    public void insertControlObjectiveCode(String activityId,String controlObjectiveCodeString){
        List templateCodeList =  new ArrayList();
        StringTokenizer st = new StringTokenizer(controlObjectiveCodeString,",");

        while(st.hasMoreTokens()) {
            templateCodeList.add(st.nextToken().trim());
        }

        Iterator iterator = templateCodeList.iterator();

        while(iterator.hasNext()){
            try{
                insertControlObjectiveCode.setString(1,activityId);
                insertControlObjectiveCode.setString(2,"CODE");
                insertControlObjectiveCode.setString(3,(String)iterator.next());
                insertControlObjectiveCode.executeUpdate() ;
            }catch(SQLException sqle){
                if(sqle.getErrorCode() == 1){
                    //***Duplicate value being added...expected error
                    logger.error("Unknown template Code: " + sqle.getMessage());
                }
            }
        }

    }

    public void insertControlObjectiveCategory(String activityId,String controlObjectiveCategoryString){
        List templateCategoryList =  new ArrayList();
        StringTokenizer st = new StringTokenizer(controlObjectiveCategoryString,",");

        while(st.hasMoreTokens()) {
            templateCategoryList.add(st.nextToken().trim());
        }

        Iterator iterator = templateCategoryList.iterator();

        while(iterator.hasNext()){
            try{
                insertControlObjectiveCode.setString(1,activityId);
                insertControlObjectiveCode.setString(2,"CATEGORY");
                insertControlObjectiveCode.setString(3,(String)iterator.next());
                insertControlObjectiveCode.executeUpdate() ;
            }catch(SQLException sqle){
                if(sqle.getErrorCode() == 1){
                    //***Duplicate value being added...expected error
                    logger.error("Unknown template Category: " + sqle.getMessage());
                }
            }
        }

    }

    /**
     * This method returns false if the cycle id and subcycle id passed in do not match the
     * respective parts in activityid
     * @param cycleId
     * @param subCycleId
     * @param activityId
     * @return
     */
    public static boolean isActivityInRightPlace(String cycleId,String subCycleId,String activityId){

    	StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
    	String activityCycleId = stringTokenizer.nextToken()+"."+stringTokenizer.nextToken()+"."+stringTokenizer.nextToken();
    	String activitySubCycleId = stringTokenizer.nextToken();
    	if(activityCycleId.equalsIgnoreCase(cycleId) && activitySubCycleId.equalsIgnoreCase(subCycleId)){
    		return true;
    	}
    	return false;

    }

    public void isFileWellFormed()throws ActivityInWrongTemplate,InCorrectCountryException,InCorrectCycleDescription,SubCycleAlreadyPresent{

    	//Step 1 Check if country is correct or not.
    	isCountryCorrect();

    	//Step 2 Check for Cycle Description (If cycle is present in the database
    	// check against that for the description)
    	isCycleDesriptionCorrect();
    	//Step 3 Check if sub-cycle is already present in the system
    	isSubCyclePresent();
    	//Step 4 Check if activity is already present in the system

    	//Step 5 Check if all the activities present are activities of the current cycle and subcycle
    	isActivityInRightPlace();
    }

    public void isCycleDesriptionCorrect()throws InCorrectCycleDescription{
		StringTokenizer filest = new StringTokenizer(filename, ".");

		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}

    	String cycleDescription = headerBean.getCycleDesc();
    	try{
	    	PreparedStatement ps = con.prepareStatement("SELECT C.DESCRIPTION FROM CYCLE C WHERE C.CYCLE_ID=?");
	    	ps.setString(1,cycleID);
	    	ResultSet rs = ps.executeQuery();

	    	while(rs.next()){
	    		String description = rs.getString("DESCRIPTION");
	    		if(!description.trim().equalsIgnoreCase(cycleDescription.trim())){
	    			throw new InCorrectCycleDescription(new Exception("In Correct Cycle Description"));
	    		}
	    	}
    	}catch(SQLException ex){
    		logger.error("Database Error");
    	}
    }

    public void isSubCyclePresent()throws SubCycleAlreadyPresent{
		StringTokenizer filest = new StringTokenizer(filename, ".");

		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}
	   	try{
	    	PreparedStatement ps = con.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID=?");
	    	ps.setString(1,cycleID+"."+subCycleID);
	    	ResultSet rs = ps.executeQuery();

	    	while(rs.next()){
                throw new SubCycleAlreadyPresent(new Exception("Subcycle already present"));
	    	}
    	}catch(SQLException ex){
    		logger.error("Database Error");
    	}

    }

    public void isCountryCorrect()throws InCorrectCountryException{

		StringTokenizer filest = new StringTokenizer(filename, ".");

		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}

    	String cellCountryName = headerBean.getCountry();

    	String countryCode = SoxicUtil.getCountryCode(countryIDFromFilename);
    	if(!countryCode.trim().equalsIgnoreCase(cellCountryName.trim())){
    		throw new InCorrectCountryException(new Exception("InCorrect Country"));
    	}
    }

    public PersonInfo returnPeople(String userid)throws Exception{

   		PeopleService svc = new PeopleService();
    	PersonInfo[] person = svc.GetPeople("", "", "", "", userid, "", "");

    	if(person==null){
    		throw new InvalidUserException();
    	}

    	for(int i=0;i<person.length;i++){
    		PersonInfo personInfo = person[i];
    		if(personInfo.getUserId().equalsIgnoreCase(userid)){
    			return personInfo;
    		}
    	}
    	return null;

    }


    public void isActivityInRightPlace() throws ActivityInWrongTemplate{

		StringTokenizer filest = new StringTokenizer(filename, ".");

		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}

        for(int rowno = 0; rowno < ExcelRowSet.size(); rowno++){

        	ExcelRow = (Vector)ExcelRowSet.get(rowno);

        	//**Reset Codes...
        	String activityID = "";
           	String activityCycleId = "";
			String activitySubCycleId = "";


        	//**For exactly 8 cells...
        	for(int cellno = 0; cellno < 8; cellno++){

        		//**Extract the (first cell)codes...(Required Attribute)
        		if(cellno == 0){

        		    //**Skip the row, if activity id is not present...
        		    if(ExcelRow.size() >= 1){
        		        activityID = (String)ExcelRow.get(cellno);
        		        activityID = activityID.trim();
        		    }
        		    else{
        		        logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
        		        rowSkipped++;
        		        break;
        		    }

        			//**Double check...(for empty string)
        			if(activityID == null || activityID.equals("")){
        			    logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
        		        rowSkipped++;
        			    break;
        			}
        		}

        	   	StringTokenizer stringTokenizer = new StringTokenizer(activityID,".");
            	activityCycleId = stringTokenizer.nextToken();
            	activitySubCycleId = stringTokenizer.nextToken();

            	if(!activityCycleId.equalsIgnoreCase(cycleCode) || !activitySubCycleId.equalsIgnoreCase(subCycleID)){
            		logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" File skipped");
            		throw new ActivityInWrongTemplate(new Exception("Activity in Wrong File"));
            	}
        	}
        }

    }


	public static void main(String[] args) {
        try{
                    ImportTemplateActivityCodes importCodes;

                    //**Reading all from a given Folder...[ExcelFiles\...filename.xls]
                    logger.error("Argument passed :"+args[0]);
                    logger.error("Argument passed :"+args[1]);
                    File directory = new File(ImportTemplateActivityCodes.folderName);
                    //logger.warn("Current File path :"+args[0]);
                    //File directory = new File(args[0]);
                    File [] files = directory.listFiles();
                    if(files == null || files.length == 0){
                        logger.warn("Please put all the excel files to be imported in the folder 'ExcelFiles' directly under the project.");
                    }
                    else{
                        for (int i = 0; i < files.length; i++) {

                            logger.debug("File-name found !!!");

                            //**Call Constructor with diff filenames...
                            importCodes = new ImportTemplateActivityCodes(files[i].toString(),args[0],args[1]);
                            importCodes.wb = importCodes.hssfworkbook;

                            importCodes.sheet= importCodes.wb.getSheetAt(0);
                            importCodes.importFile();
                        }
                    }

                }

		catch(Exception ex){
			ex.printStackTrace();
		}


	}
}
