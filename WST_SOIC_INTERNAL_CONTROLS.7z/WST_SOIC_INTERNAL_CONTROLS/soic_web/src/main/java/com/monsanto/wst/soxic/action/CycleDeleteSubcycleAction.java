package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 21, 2005
 * Time: 1:37:53 PM
 *
 * This action class selects the subcycles based on the cycle selected by the
 * user. If there are no subcycles for the particular cycle, a NullAndArrayIndexException
 * is thrown.
 */

public class CycleDeleteSubcycleAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        SubCycleDeleteForm subcycledeleteform = (SubCycleDeleteForm)form;
        String cycleid = subcycledeleteform.getSelectedCycles();
        SubCycleMaintainFacade subCycleMaintainFacade = new SubCycleMaintainFacade();

        subCycleMaintainFacade.subCycleFromCycle(subcycledeleteform,cycleid);
        subcycledeleteform.setSelectedCycles(cycleid);

        return mapping.findForward("subcyclelist");
    }

}
