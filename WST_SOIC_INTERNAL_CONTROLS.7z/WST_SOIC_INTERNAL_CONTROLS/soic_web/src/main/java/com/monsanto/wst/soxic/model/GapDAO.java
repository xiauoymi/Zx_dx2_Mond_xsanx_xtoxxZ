/*
 * Created on Mar 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class GapDAO {

	/**
	 * Remove gap with response id and sequence id
	 * @param responseId
	 * @param sequenceId
	 * @throws Exception
	 */
	public void removeGap(int responseId, int sequenceId) throws Exception {

		Connection connection = null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement previouGap = connection
					.prepareStatement("DELETE FROM GAP_DC_LOE GDL WHERE GDL.RESPONSE_ID=? AND GDL.SEQUENCE=?");

			previouGap.setInt(1, responseId);
			previouGap.setInt(2, sequenceId);

			previouGap.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Update gap with this response id and sequence with the following type,comment,action
	 * 
	 * @param responseId
	 * @param sequence
	 * @param type
	 * @param comment
	 * @param action
	 * @param ownerid
	 * @throws Exception
	 */
	public void updateGap(int responseId, int sequence, String type,
			String comment, String action, String ownerid) throws Exception {
		Connection connection = null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement updateGap = connection
					.prepareStatement("UPDATE GAP_DC_LOE GDL SET GDL.DESCRIPTION=?,GDL.MOD_DATE=?,GDL.MOD_USER=? WHERE GDL.RESPONSE_ID=? AND GDL.SEQUENCE=?");

			updateGap.setString(1, comment);

			updateGap.setDate(2, new Date(System.currentTimeMillis()));

			updateGap.setString(3, ownerid);

			updateGap.setInt(4, responseId);

			updateGap.setInt(5, sequence);

			updateGap.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Insert gap into table
	 * @param owner_id
	 * @param activityId
	 * @param questionId
	 * @param type
	 * @param comment
	 * @param action
	 * @return
	 * @throws Exception
	 */
	public int insertGap(String owner_id, String activityId, String questionId,
			String type, String comment, String action) throws Exception {
		Connection con = null;
		int responseid = 0;
		int sequenceid = 1;
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			responseid = getResponseId(owner_id, questionId, activityId);
			sequenceid = getSequenceId(responseid);

			PreparedStatement insertGap = null;
			insertGap = con
					.prepareStatement("INSERT INTO GAP_DC_LOE(RESPONSE_ID,SEQUENCE,TYPE,DESCRIPTION,MOD_DATE,MOD_USER,ACTION)"
							+ "VALUES(?,?,?,?,?,?,?)");
			insertGap.setInt(1, responseid);
			insertGap.setInt(2, sequenceid);
			insertGap.setString(3, type);
			insertGap.setString(4, comment);
			insertGap.setDate(5, new Date(System.currentTimeMillis()));
			insertGap.setString(6, owner_id);
			insertGap.setString(7, action);

			insertGap.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseid;
	}

	/**
	 * Get the response id for this particular owner,question and identifier
	 * @param owner_id
	 * @param questionId
	 * @param identifier
	 * @return
	 * @throws Exception
	 */
	private int getResponseId(String owner_id, String questionId,
			String identifier) throws Exception {
		Connection con = null;
		int responseid = 0;
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			PreparedStatement getResponsId = null;

			getResponsId = con
					.prepareStatement("SELECT * FROM OWNER_RESPONSE OWR WHERE OWR.OWNER_ID=? AND OWR.QUESTION_ID=? AND OWR.ASSOCIATED_ID=?");
			getResponsId.setString(1, owner_id);
			getResponsId.setString(2, questionId);
			getResponsId.setString(3, identifier);
			ResultSet rs = getResponsId.executeQuery();

			while (rs.next()) {
				responseid = rs.getInt("RESPONSE_ID");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return responseid;
	}

	/**
	 * Get the max sequence id with particular response id
	 * @param responseid
	 * @return
	 * @throws Exception
	 */
	private int getSequenceId(int responseid) throws Exception {
		int sequenceid = 0;
		Connection con = null;
		PreparedStatement getSequenceId = null;

		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			getSequenceId = con
					.prepareStatement("SELECT MAX(SEQUENCE) ID FROM GAP_DC_LOE WHERE RESPONSE_ID=?");

			getSequenceId.setInt(1, responseid);

			ResultSet rsseq = getSequenceId.executeQuery();
			while (rsseq.next()) {
				sequenceid = rsseq.getInt("ID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		sequenceid = sequenceid + 1;
		return sequenceid;
	}

	/**
	 * @param ownerid
	 * @param level
	 * @param identifier
	 * @throws Exception
	 */
	public void setOwnerGapToPresent(String ownerid, String level,
			String identifier) throws Exception {
		Connection connection = null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement updateGap = connection
					.prepareStatement(getGapPresentOwnerQuery(level));

			updateGap.setString(1, "Y");

			updateGap.setDate(2, new Date(System.currentTimeMillis()));

			updateGap.setString(3, ownerid);

			updateGap.setString(4, identifier);

			updateGap.setString(5, ownerid);

			updateGap.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Return a list of previous gaps present for this owner,activity and question
	 * @param identifier
	 * @param questionId
	 * @param level
	 * @param ownerid
	 * @return
	 * @throws Exception
	 */
	public List getPreviousGap(String identifier, String questionId,
			String level, String ownerid) throws Exception {

		List previousGapList = new ArrayList();

		Connection connection = null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement previouGap = connection
					.prepareStatement(getPreviousGapQuery(level));

			previouGap.setString(1, identifier);

			previouGap.setString(2, questionId);

			previouGap.setString(3, ownerid);

			ResultSet rs = previouGap.executeQuery();

			while (rs.next()) {
				String identi = rs.getString("ASSOCIATED_ID");

				Activity activity = getActivity(previousGapList, identi);
				if (activity != null) {
					activity.setActivityId(rs.getString("ASSOCIATED_ID"));
					activity.setQuestionId(questionId);
					ResponseGap responseGap = new ResponseGap();
					responseGap.setAction(rs.getString("ACTION"));
					responseGap.setComment(rs.getString("DESCRIPTION"));
					responseGap.setType(rs.getString("TYPE"));
					responseGap.setResponseGapId(activity.getActivityId()
							+ SoxicUtil.getSeperator() + rs.getString("TYPE"));
					responseGap.setSequenceId(rs.getInt("SEQUENCE"));
					responseGap.setResponseId(rs.getInt("RESPONSE_ID"));
					activity.addResponseGap(responseGap);
					//previousGapList.add(activity);
				} else {
					activity = new Activity();
					activity.setActivityId(rs.getString("ASSOCIATED_ID"));
					activity.setQuestionId(questionId);
					ResponseGap responseGap = new ResponseGap();
					responseGap.setAction(rs.getString("ACTION"));
					responseGap.setComment(rs.getString("DESCRIPTION"));
					responseGap.setType(rs.getString("TYPE"));
					responseGap.setResponseGapId(activity.getActivityId()
							+ SoxicUtil.getSeperator() + rs.getString("TYPE"));
					responseGap.setSequenceId(rs.getInt("SEQUENCE"));
					responseGap.setResponseId(rs.getInt("RESPONSE_ID"));
					activity.addResponseGap(responseGap);
					previousGapList.add(activity);
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return previousGapList;
	}
	
	/**
	 * @param identifier
	 * @param ownerId
	 * @return
	 * @throws Exception
	 */
	public List getPreviousOwnerGap(String identifier,String ownerId)throws Exception{
		
		List previousGapList = new ArrayList();
		
		Connection connection = null;

		try {
			
			connection = SoxicConnectionFactory.getSoxicConnection();

			PreparedStatement previouGap = connection
					.prepareStatement("SELECT * FROM OWNER_RESPONSE ORS,GAP_DC_LOE GDL WHERE ORS.ASSOCIATED_ID=? AND ORS.OWNER_ID=? AND ORS.RESPONSE_ID=GDL.RESPONSE_ID");

			previouGap.setString(1,identifier);
			
			previouGap.setString(2,ownerId);

			ResultSet rs = previouGap.executeQuery();
			
			while(rs.next()){
				String identi = rs.getString("ASSOCIATED_ID");
				
				Activity activity=getActivity(previousGapList,identi);
				if(activity!=null){
					activity.setActivityId(rs.getString("ASSOCIATED_ID"));
					//activity.setQuestionId(questionId);
					ResponseGap responseGap = new ResponseGap();
					responseGap.setAction(rs.getString("ACTION"));
					responseGap.setComment(rs.getString("DESCRIPTION"));
					responseGap.setType(rs.getString("TYPE"));
					responseGap.setResponseGapId(activity.getActivityId() + SoxicUtil.getSeperator()
							+ rs.getString("TYPE"));
					responseGap.setSequenceId(rs.getInt("SEQUENCE"));
					responseGap.setResponseId(rs.getInt("RESPONSE_ID"));
					activity.addResponseGap(responseGap);
					
				}else{
					activity = new Activity();
					activity.setActivityId(rs.getString("ASSOCIATED_ID"));
					//activity.setQuestionId(questionId);
					ResponseGap responseGap = new ResponseGap();
					responseGap.setAction(rs.getString("ACTION"));
					responseGap.setComment(rs.getString("DESCRIPTION"));
					responseGap.setType(rs.getString("TYPE"));
					responseGap.setResponseGapId(activity.getActivityId() + SoxicUtil.getSeperator()
							+ rs.getString("TYPE"));
					responseGap.setSequenceId(rs.getInt("SEQUENCE"));
					responseGap.setResponseId(rs.getInt("RESPONSE_ID"));
					activity.addResponseGap(responseGap);
					previousGapList.add(activity);
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return previousGapList;
	}	

	/**
	 * @param level
	 * @return
	 */
	public String getGapPresentQuery(String level) {
		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "UPDATE SUB_CYCLE SC SET SC.POTENTIAL_GAP=? WHERE SC.SUB_CYCLE_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "UPDATE CYCLE C SET C.POTENTIAL_GAP=? WHERE C.CYCLE_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			query = "UPDATE CTRL_OBJ CO SET CO.POTENTIAL_GAP=? WHERE CO.CTRL_OBJ_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "UPDATE ACTIVITY A SET A.POTENTIAL_GAP=? WHERE A.ACTIVITY_ID=?";
		}
		return query;
	}

	/**
	 * @param level
	 * @return
	 */
	public String getGapPresentOwnerQuery(String level) {
		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "UPDATE OWNER_SUB_CYCLE OSC SET OSC.POTENTIAL_GAP=?,OSC.MOD_DATE=?,OSC.MOD_USER=? WHERE OSC.SUB_CYCLE_ID=? AND OSC.OWNER_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "UPDATE OWNER_CYCLE OC SET OC.POTENTIAL_GAP=?,OC.MOD_DATE=?,OC.MOD_USER=? WHERE OC.CYCLE_ID=? AND OC.OWNER_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "UPDATE OWNER_ACTIVITY OA SET OA.POTENTIAL_GAP=?,OA.MOD_DATE=?,OA.MOD_USER=? WHERE OA.ACTIVITY_ID=? AND OA.OWNER_ID=?";
		}
		return query;
	}

	/**
	 * @param level
	 * @return
	 */
	public static String getPreviousGapQuery(String level) {
		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT GDL.TYPE,GDL.DESCRIPTION,GDL.ACTION,ORS.ASSOCIATED_ID,GDL.SEQUENCE,GDL.RESPONSE_ID FROM GAP_DC_LOE GDL,OWNER_RESPONSE ORS WHERE ORS.ASSOCIATED_ID=? AND ORS.RESPONSE_ID=GDL.RESPONSE_ID AND ORS.QUESTION_ID=? AND ORS.OWNER_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT GDL.TYPE,GDL.DESCRIPTION,GDL.ACTION,ORS.ASSOCIATED_ID,GDL.SEQUENCE,GDL.RESPONSE_ID FROM GAP_DC_LOE GDL,OWNER_RESPONSE ORS WHERE ORS.ASSOCIATED_ID=? AND ORS.RESPONSE_ID=GDL.RESPONSE_ID AND ORS.QUESTION_ID=? AND ORS.OWNER_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {

			query = "SELECT GDL.TYPE,GDL.DESCRIPTION,GDL.ACTION,ORS.ASSOCIATED_ID,GDL.SEQUENCE,GDL.RESPONSE_ID FROM CTRL_OBJ CO,ACTIVITY A,GAP_DC_LOE GDL,OWNER_RESPONSE ORS WHERE CO.CTRL_OBJ_ID=? AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND ORS.ASSOCIATED_ID=A.ACTIVITY_ID AND ORS.RESPONSE_ID=GDL.RESPONSE_ID AND ORS.QUESTION_ID=? AND ORS.OWNER_ID=?";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "UPDATE ACTIVITY A SET A.POTENTIAL_GAP=? WHERE A.ACTIVITY_ID=?";
		}
		return query;
	}

	
	/**
	 * Returns an activity from the list with the particular identifier else returns null
	 * @param activityList
	 * @param identifier
	 * @return
	 */
	private Activity getActivity(List activityList, String identifier) {
		Activity activity = null;
		if (activityList != null) {
			Iterator iterator = activityList.iterator();
			while (iterator.hasNext()) {
				activity = (Activity) iterator.next();
				if (activity.getActivityId().equalsIgnoreCase(identifier)) {
					return activity;
				}
			}
		}
		return null;
	}

}