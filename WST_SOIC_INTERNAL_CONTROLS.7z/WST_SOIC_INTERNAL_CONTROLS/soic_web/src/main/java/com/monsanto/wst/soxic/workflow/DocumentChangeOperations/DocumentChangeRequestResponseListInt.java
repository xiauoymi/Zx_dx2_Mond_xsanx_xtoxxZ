package com.monsanto.wst.soxic.workflow.DocumentChangeOperations;

import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 4:19:23 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DocumentChangeRequestResponseListInt {
    List getDocumentChangeRequestResponseList();
    
    void setDocumentChangeRequestResponseList(List documentChangeRequestResponseList);

    void remove(OwnerChangeRequestResponse ownerChangeRequestResponse);

    void processEmails();

    void sendEmails();

    int getNumberOfEmailsSent();

    void setNumberOfEmailsSent(int numberOfEmailsSent);
}
