package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 23, 2005
 * Time: 2:55:49 PM
 */
public class NullControlObjectiveException extends Exception{
	public NullControlObjectiveException(){
		super();
	}

	public NullControlObjectiveException(Exception e){
		super(e);
	}
}
