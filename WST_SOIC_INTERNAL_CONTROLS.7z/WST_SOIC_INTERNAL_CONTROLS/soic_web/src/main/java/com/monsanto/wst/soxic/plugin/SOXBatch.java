package com.monsanto.wst.soxic.plugin;

/**
 * User: ssanna
 * Date: Dec 8, 2008
 * Time: 1:33:54 PM
 */
/*
 * RunSOXBatch.java - Execute and return the output of a native command
 */

import com.monsanto.wst.soxic.workflow.StatusService;

public class SOXBatch{
    private static final String LSI_FUNCTION_PROPERTY = "lsi.function";
    private static final String MONCRYPTJV_PROPERTY = "MONCRYPTJV";

    public static void main(String argv[]) {
        if (argv.length != 1) {
            System.err.println("Syntax: java -jar thisjar.jar ENVIROMENT_ID");
            System.err.println("Where ENVIRONMENT is: 'win', 'dev', 'test', or 'prod' (without quotes).");
            System.exit(1);
        }
        String lsiFunction = argv[0];

        setMoncryptJVFromEnvironmentVariable();
        System.setProperty(LSI_FUNCTION_PROPERTY, lsiFunction);
        StatusService service = new StatusService();
        service.run();
    }

    private static void setMoncryptJVFromEnvironmentVariable() {
        String moncryptjv = System.getenv(MONCRYPTJV_PROPERTY);
        if (moncryptjv == null) {
            System.err.println("The " + MONCRYPTJV_PROPERTY + " environment variable must be set.");
            System.exit(1);
        }
        System.setProperty(MONCRYPTJV_PROPERTY, moncryptjv);
    }
}

