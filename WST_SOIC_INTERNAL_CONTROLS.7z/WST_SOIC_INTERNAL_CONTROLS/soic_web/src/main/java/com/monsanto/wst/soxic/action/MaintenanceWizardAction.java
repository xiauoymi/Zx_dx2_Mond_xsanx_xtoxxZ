package com.monsanto.wst.soxic.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.facade.OwnerMaintainenceFacade;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;
import com.monsanto.wst.soxic.facade.CycleOnlyCertifyFacade;
import com.monsanto.wst.soxic.form.MaintenanceWizardForm;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.exception.*;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 8, 2005
 * Time: 10:29:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaintenanceWizardAction extends DispatchAction {


    public ActionForward createActions(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        resetForm(maintenanceWizardForm);
        setActions(maintenanceWizardForm);
        return mapping.findForward("actions");
    }


    public ActionForward createOwnerLevels(ActionMapping mapping, ActionForm form,
                                           HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        String strSelectedAction = maintenanceWizardForm.getSelectedAction();
        String strSelectedAvailableOwner = maintenanceWizardForm.getSelectedAvailableOwner();
        String strSourceOwner = maintenanceWizardForm.getSourceOwner();
        String strDestinationOwner = maintenanceWizardForm.getDestinationOwner();


        //check required fields for selecting  Adding or Removing Owner
        if (strSelectedAction.equalsIgnoreCase(SoxicConstants.ADD_OWNER) ||
                strSelectedAction.equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {

            if (strSelectedAvailableOwner == null || strSelectedAvailableOwner.trim().length() == 0) {
                throw new NullOwnerException();
            }
        }

        //check required fields for selecting  Copy or Change Owner
        if (strSelectedAction.equalsIgnoreCase(SoxicConstants.COPY_OWNER) ||
                strSelectedAction.equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {

            if (strSourceOwner == null || strSourceOwner.trim().length() == 0) {
                throw new TwoNullOwnersException();
            }

            if (strDestinationOwner == null || strDestinationOwner.trim().length() == 0) {
                throw new TwoNullOwnersException();
            }
        }

        //Get the owner id from the sesion
        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();

        //set details for multiple owners
        facade.setOwnerDetails(maintenanceWizardForm);

        facade.setOwnerLevel(form, owner);
        return mapping.findForward("ownerLevels");
    }


    public ActionForward createPeriodList(ActionMapping mapping, ActionForm form,
                                          HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        if (null == maintenanceWizardForm.getSelectedOwnerLevel()) {
            throw new NullOwnerLevelException();
            //return mapping.findForward("ownerLevels");
        } else {
            Owner owner = (Owner) request.getSession().getAttribute("owner");
            OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
            facade.setPeriodFilterCriteria(form, owner);
            return mapping.findForward("hierarchy");
        }


    }


    public ActionForward createControlObjectives(ActionMapping mapping, ActionForm form,
                                                 HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        maintenanceWizardForm.setControlObjectives(null);
        maintenanceWizardForm.setControlActivities(null);
        maintenanceWizardForm.setSelectedControlActivities(null);

        String strSelectedOwnerLevel = maintenanceWizardForm.getSelectedOwnerLevel();
        String strPeriod = maintenanceWizardForm.getSelectedPeriod();
        String strCountry = maintenanceWizardForm.getSelectedCountry();
        String strCycle = maintenanceWizardForm.getSelectedCycle();
        String strSubCycle = maintenanceWizardForm.getSelectedSubCycle();

        //check required field for selecting Control Objectives
        if (strSelectedOwnerLevel.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {
            if (strCycle.equalsIgnoreCase(SoxicConstants.SELECT_CYCLE) ||
                    strPeriod.equalsIgnoreCase(SoxicConstants.SELECT_PERIOD) ||
                    strCountry.equalsIgnoreCase(SoxicConstants.SELECT_COUNTRY) ||
                    strSubCycle.equalsIgnoreCase(SoxicConstants.SELECT_SUB_CYCLE)) {
                throw new NullControlObjectiveFilterException();
            }
        }

        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
        try {
            facade.populateControlObjectives(form, owner);
        } catch (NullControlObjectiveException e) {
            throw new NullControlObjectiveException();
        }
        return mapping.findForward("controlObjectives");
    }


    public ActionForward createControlActivities(ActionMapping mapping, ActionForm form,
                                                 HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        //maintenanceWizardForm.setControlActivities(null);
        maintenanceWizardForm.setSelectedControlActivities(null);
        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
        facade.populateActivities(form, owner);
        return mapping.findForward("controlObjectives");
    }


    public ActionForward addToStoredControlActivities(ActionMapping mapping, ActionForm form,
                                                      HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        maintenanceWizardForm.addToStoredControlActivitiesforProcessing(maintenanceWizardForm.getSelectedControlActivities());

        return mapping.findForward("controlObjectives");
    }

    public ActionForward clearAllStoredControlActivities(ActionMapping mapping, ActionForm form,
                                                         HttpServletRequest request, HttpServletResponse response) throws Exception {

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        maintenanceWizardForm.clearAllStoredControlActivitiesforProcessing();

        return mapping.findForward("controlObjectives");
    }


    public ActionForward processChanges(ActionMapping mapping, ActionForm form,
                                        HttpServletRequest request, HttpServletResponse response) throws Exception {
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();

        try {
            facade.process(maintenanceWizardForm);
        } catch (Exception e) {
            e.printStackTrace();
            return mapping.findForward("processFailure");
        }

        return mapping.findForward("processSuccess");
    }

    public ActionForward showSelectedControlActivities(ActionMapping mapping, ActionForm form,
                                                       HttpServletRequest request, HttpServletResponse response) throws Exception {

        return mapping.findForward("controlObjectives");
    }


    public ActionForward createCountryList(ActionMapping mapping, ActionForm form,
                                           HttpServletRequest request, HttpServletResponse response) throws Exception {

        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
        facade.setCountryFilterCriteria(form, owner);
        return mapping.findForward("hierarchy");
    }


    public ActionForward createCycleList(ActionMapping mapping, ActionForm form,
                                         HttpServletRequest request, HttpServletResponse response) throws Exception {

        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
        facade.setCycleFilterCriteria(form, owner);
        return mapping.findForward("hierarchy");
    }


    public ActionForward createSubCycleList(ActionMapping mapping, ActionForm form,
                                            HttpServletRequest request, HttpServletResponse response) throws Exception {

        Owner owner = (Owner) request.getSession().getAttribute("owner");
        OwnerMaintainenceFacade facade = new OwnerMaintainenceFacade();
        facade.setSubCycleFilterCriteria(form, owner);
        return mapping.findForward("hierarchy");
    }

    public ActionForward previewChanges(ActionMapping mapping, ActionForm form,
                                        HttpServletRequest request, HttpServletResponse response) throws Exception {
      
        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        String strSelectedOwnerLevel = maintenanceWizardForm.getSelectedOwnerLevel();
        String strPeriod = maintenanceWizardForm.getSelectedPeriod();
        String strCountry = maintenanceWizardForm.getSelectedCountry();
        String strCycle = maintenanceWizardForm.getSelectedCycle();
        String strSubCycle = maintenanceWizardForm.getSelectedSubCycle();
        List strControlActivities = maintenanceWizardForm.getStoredControlActivitiesforProcessing();

        //check required field for selecting cycles
        if (strSelectedOwnerLevel.equalsIgnoreCase(SoxicConstants.CYCLE)) {
            if (strCycle.equalsIgnoreCase(SoxicConstants.SELECT_CYCLE) ||
                    strPeriod.equalsIgnoreCase(SoxicConstants.SELECT_PERIOD) ||
                    strCountry.equalsIgnoreCase(SoxicConstants.SELECT_COUNTRY)) {
                throw new NullCycleFilterException();
            }
        }

        //check required field for selecting subcycles
        if (strSelectedOwnerLevel.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
            if (strCycle.equalsIgnoreCase(SoxicConstants.SELECT_CYCLE) ||
                    strPeriod.equalsIgnoreCase(SoxicConstants.SELECT_PERIOD) ||
                    strCountry.equalsIgnoreCase(SoxicConstants.SELECT_COUNTRY) ||
                    strSubCycle.equalsIgnoreCase(SoxicConstants.SELECT_SUB_CYCLE)) {
                throw new NullSubCycleFilterException();
            }
        }

        //make sure that Control Activities have been selected when selecting next from
        //the Control Activity Page ... should probably refactor this constannt but it's used elsewhere

        if (strSelectedOwnerLevel.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)) {
            if (strControlActivities == null || strControlActivities.isEmpty()) {
                throw new NullControlActivityException();
            }

            if(!isCycleOnlyPeriod(strPeriod)) {
                //Check for the status of Sub-Cycle certification
                if(isSubCycleCertificationComplete(strSubCycle)){
                  throw new CannotAddActivityOwnerException();
                }
            }
        }

        return mapping.findForward("preview_changes");
    }

  private boolean isCycleOnlyPeriod(String periodId) throws Exception {
      CycleOnlyCertifyFacade facade = new CycleOnlyCertifyFacade();
      return facade.checkIfPeriodIsCycleOnlyPeriod(periodId);
  }

  private boolean isSubCycleCertificationComplete(String subcycleId) throws Exception{
    SubCycleMaintainFacade facade = new SubCycleMaintainFacade();
    return facade.isSubCycleCertificationComplete(subcycleId);
  }


  public ActionForward selectAction(ActionMapping mapping, ActionForm form,
                                      HttpServletRequest request, HttpServletResponse response) throws Exception {

        String strSelectedAction = "";

        MaintenanceWizardForm maintenanceWizardForm = (MaintenanceWizardForm) form;

        maintenanceWizardForm.setSelectedAvailableOwner(null);
        maintenanceWizardForm.setSelectedAvailableOwnerEmail(null);
        maintenanceWizardForm.setSelectedAvailableOwnerName(null);

        maintenanceWizardForm.setSourceOwner(null);
        maintenanceWizardForm.setSourceOwnerEmail(null);
        maintenanceWizardForm.setSourceOwnerName(null);

        maintenanceWizardForm.setDestinationOwner(null);
        maintenanceWizardForm.setDestinationOwnerEmail(null);
        maintenanceWizardForm.setDestinationOwnerName(null);

        strSelectedAction = maintenanceWizardForm.getSelectedAction();

        if (strSelectedAction.equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
            //maintenanceWizardForm.setSelectedAvailableOwner("");
            return mapping.findForward("select_owner");

        } else if (strSelectedAction.equalsIgnoreCase(SoxicConstants.REMOVE_OWNER)) {
            //maintenanceWizardForm.setSelectedAvailableOwner(null);
            return mapping.findForward("select_owner");


        } else if (strSelectedAction.equalsIgnoreCase(SoxicConstants.CHANGE_OWNER)) {
            //maintenanceWizardForm.setSourceOwner(null);
            //maintenanceWizardForm.setDestinationOwner(null);
            return mapping.findForward("select_two_owners");

        } else if (strSelectedAction.equalsIgnoreCase(SoxicConstants.COPY_OWNER)) {
            //maintenanceWizardForm.setSourceOwner(null);
            //maintenanceWizardForm.setDestinationOwner(null);
            return mapping.findForward("select_two_owners");

        } else if (strSelectedAction.equalsIgnoreCase(SoxicConstants.SELECT_ACTION)) {
            throw new NullMaintenanceActionException();

        } else {
            return mapping.findForward("failure_owner");
        }
    }


    private void setActions(MaintenanceWizardForm form) {

        List actions = new LinkedList();
        actions.add(SoxicConstants.SELECT_ACTION);
        actions.add(SoxicConstants.ADD_OWNER);
        actions.add(SoxicConstants.CHANGE_OWNER);
        actions.add(SoxicConstants.COPY_OWNER);
        actions.add(SoxicConstants.REMOVE_OWNER);

        form.setActions(actions);
        form.setSelectedAction(SoxicConstants.SELECT_ACTION);

    }

    private void resetForm(MaintenanceWizardForm form) {

        form.setSourceOwner(null);
        form.setSourceOwnerName(null);
        form.setSourceOwnerEmail(null);

        form.setDestinationOwner(null);
        form.setDestinationOwnerName(null);
        form.setDestinationOwnerEmail(null);

        form.setSelectedAvailableOwner(null);
        form.setSelectedAvailableOwnerName(null);
        form.setSelectedAvailableOwnerEmail(null);

        form.setCycleOwner(false);
        form.setSubCycleOwner(false);
        form.setControlObjectiveOwner(false);

        form.setActions(null);
        form.setOwnerLevels(null);
        form.setPeriods(null);
        form.setCountries(null);
        form.setCycles(null);
        form.setSubCycles(null);
        form.setControlObjectives(null);
        form.setControlActivities(null);
        form.setAvailableOwners(null);

        form.setSelectedAction(null);
        form.setSelectedOwnerLevel(null);
        form.setSelectedPeriod(null);
        form.setSelectedCountry(null);
        form.setSelectedCycle(null);
        form.setSelectedSubCycle(null);
        form.setSelectedControlObjectives(null);
        form.setSelectedControlActivities(null);

        form.setCurrentOwnerLevel(null);
        form.setOverAllSubCycleList(null);
        form.setOverAllActivitiyList(null);
        form.clearAllStoredControlActivitiesforProcessing();

    }


}