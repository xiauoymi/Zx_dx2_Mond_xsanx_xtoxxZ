package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.ControlObjectiveFacade;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.model.SubCycleDAO;
import com.monsanto.wst.soxic.persistance.AbstractDAOFactory;
import com.monsanto.wst.soxic.persistance.OracleSubCycleDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.exception.NoActivityInDocumentChange;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 25, 2005
 * Time: 1:58:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeFacade {

    public void populateForm(ControlObjectiveForm controlObjectiveForm,String subCycleId,Owner owner){
        List controlObjList = null;
        try{
            ControlObjectiveFacade facade = new ControlObjectiveFacade();
            boolean isSubCycleOwner =  ((OracleSubCycleDAO)AbstractDAOFactory.getFactory().getSubCycleDAO()).isSubCycleOwner(owner,subCycleId);
//            if(owner.getDocChangeLevel().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE)){
//                controlObjList = facade.getControlObjectivesDoc(subCycleId,owner);
//            }else{
//                controlObjList = facade.getControlObjectives(subCycleId, owner);
//            }
            if(owner.isIA()){
                controlObjList = facade.getControlObjectivesDoc(subCycleId,owner);
            }else if(isSubCycleOwner){
                controlObjList = facade.getControlObjectivesDoc(subCycleId,owner);
            }else if(owner.isIAUser()){
                controlObjList = facade.getControlObjectivesDoc(subCycleId,owner);
            }
            else{
                controlObjList = facade.getControlObjectives(subCycleId, owner);
            }
            controlObjectiveForm.setControlObjectiveList(controlObjList);
        }catch(Exception e){

        }

    }

    private void setSubCyclesForOwner(ControlObjectiveForm controlObjectiveForm,Owner owner)throws NoActivityInDocumentChange{
        List subCycleList =null;
        try{
            if(owner.isIA() || owner.isIAUser()){
                if(owner.isIAUser()){
                    subCycleList = SubCycleDAO.selectAllSubCycles(SoxicConstants.DOCCHANGE_STATE);
                }
                if(owner.isIA()){
                    subCycleList = SubCycleDAO.selectAllSubCyclesForIAAndAdminForDocChange();
                }

            }else{
               //subCycleList = SubCycleDAO.getSubCycles(owner.getOwnerId(),SoxicConstants.DOCCHANGE_STATE);
               subCycleList = getSubCycleListForDocChange(controlObjectiveForm,owner);

            }
            if(subCycleList.size()==0){
                throw new NoActivityInDocumentChange();
            }
             //subCycleList = SubCycleDAO.getSubCycles(owner.getOwnerId(),SoxicConstants.DOCCHANGE_STATE);
            controlObjectiveForm.setSubCycleList(subCycleList);
        }catch(Exception e){
            if(e instanceof NoActivityInDocumentChange){
                throw new NoActivityInDocumentChange();
            }
        }
    }

    private List getSubCycleListForDocChange(ControlObjectiveForm controlObjectiveForm,Owner owner){
        List subCyleList = new ArrayList();
        Set hashSet = new HashSet();
        try{
            List activitySubCycleList = SubCycleDAO.getSubCycles(owner.getOwnerId(),SoxicConstants.DOCCHANGE_STATE);
            List subownerSubCycleList = SubCycleDAO.getSubCyclesForDocChangeStateAsSubCycleOwner(owner.getOwnerId(),SoxicConstants.DOCCHANGE_STATE);

            Iterator activityIterator = activitySubCycleList.iterator();
            while(activityIterator.hasNext()){
                SubCycle subCycle = (SubCycle)activityIterator.next();
                hashSet.add(subCycle.getSubCycleId());
                subCyleList.add(subCycle);
            }

            Iterator subCycleIterator = subownerSubCycleList.iterator();
            while(subCycleIterator.hasNext()){

                SubCycle subCycle = (SubCycle)subCycleIterator.next();
                if(hashSet.add(subCycle.getSubCycleId())){
                    subCyleList.add(subCycle);
                }
            }

        }catch(Exception e){

        }
        return subCyleList;
    }

    public void initializeForm(ControlObjectiveForm controlObjectiveForm,Owner owner)throws NoActivityInDocumentChange{
        setSubCyclesForOwner(controlObjectiveForm,owner);
        setCycleAssocitation(controlObjectiveForm);
        String cycleId = getFirstCycleId(controlObjectiveForm);
        setSubCycleAssocitation(controlObjectiveForm,cycleId);
        populateForm(controlObjectiveForm,getFirstSubCycleId(controlObjectiveForm),owner);

    }

    public void changeCycle(ControlObjectiveForm controlObjectiveForm,Owner owner){
        setSubCycleAssocitation(controlObjectiveForm,controlObjectiveForm.getCurrentCycle());
        String subCycleId = getFirstSubCycleId(controlObjectiveForm);
        populateForm(controlObjectiveForm,subCycleId,owner);
        //String subCycleId =
    }

    public void changeSubCycle(ControlObjectiveForm controlObjectiveForm,Owner owner){
        populateForm(controlObjectiveForm,controlObjectiveForm.getSubCycleSelected(),owner);
    }

    public void setCycleAssocitation(ControlObjectiveForm controlObjectiveForm){
        Collection subcycles = controlObjectiveForm.getSubCycleList();
        Iterator iterator = subcycles.iterator();
        HashSet hashSet = new HashSet();

        while(iterator.hasNext()){
            SubCycle subCycle = (SubCycle)iterator.next();
            hashSet.add(subCycle.getCycleId());
        }
        List tempList = new ArrayList(hashSet);
        Collections.sort(tempList);
        controlObjectiveForm.setCycleList(tempList);
    }

    public void setSubCycleAssocitation(ControlObjectiveForm controlObjectiveForm,String cycleId){
        Collection subcycles = controlObjectiveForm.getSubCycleList();
        Iterator iterator = subcycles.iterator();
        HashSet hashSet = new HashSet();

        while(iterator.hasNext()){
            SubCycle subCycle = (SubCycle)iterator.next();
            if(subCycle.getCycleId().equalsIgnoreCase(cycleId)){
                hashSet.add(subCycle.getSubCycleId());
            }
        }
        List tempList = new ArrayList(hashSet);
        Collections.sort(tempList);
        controlObjectiveForm.setSubCyclesCurrentCycle(tempList);
    }

    public String getFirstSubCycleId(ControlObjectiveForm controlObjectiveForm){
        //return (String)((List)controlObjectiveForm.getCycleList()).get(0);
        List currentCycleSubCycles = (List)controlObjectiveForm.getSubCyclesCurrentCycle();
        //SubCycle subCycle = (SubCycle) currentCycleSubCycles.get(0);
        //return subCycle.getSubCycleId();
        return (String)currentCycleSubCycles.get(0);
    }

    public String getFirstCycleId(ControlObjectiveForm controlObjectiveForm){
        //return (String)((List)controlObjectiveForm.getCycleList()).get(0);
        List currentCycles =  (List)controlObjectiveForm.getCycleList();
        return (String)currentCycles.get(0);
    }
}
