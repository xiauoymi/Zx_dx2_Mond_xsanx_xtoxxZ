package com.monsanto.wst.soxic.Servlet;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 9:52:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestController implements UseCaseController{
    public void run(UCCHelper helper) throws IOException {
    }
}
