/*
 * Created on Feb 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.CycleViewForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.StatusDAO;
import com.monsanto.wst.soxic.model.CycleStatusDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicPathUtil;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//public class UpdateCycleViewAction extends LookupDispatchAction{
//    
//    /* (non-Javadoc)
//     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
//     */
//    protected Map getKeyMethodMap() {
//        Map map = new HashMap();
//        map.put("button.save",   "submit");
//        map.put("button.submit", "submit");
//        return map;
//    }
//    
//    public ActionForward save(ActionMapping mapping,
//            ActionForm form,
//            HttpServletRequest request,
//            HttpServletResponse response)
//            throws IOException, ServletException {
//                
//        return mapping.findForward("success");
//    }
//    
//    public ActionForward submit(ActionMapping mapping,
//            ActionForm form,
//            HttpServletRequest request,
//            HttpServletResponse response)
//            throws IOException, ServletException {
//        
//    	CycleViewForm cycleViewForm = (CycleViewForm)form;
//    	
//    	cycleViewForm.setLinkOnSubmit("PBO");
//        
//        Owner owner = (Owner) request.getSession().getAttribute("owner");
//        try {
//            owner.updateCycleQuestions();
//        } catch (DatabaseException e) {
//            e.printStackTrace();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        
//        return mapping.findForward("success");
//    }
//}

public class UpdateCycleViewAction extends Action{
    
    /* (non-Javadoc)
     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
     */
//    protected Map getKeyMethodMap() {
//        Map map = new HashMap();
//        map.put("button.save",   "submit");
//        map.put("button.submit", "submit");
//        return map;
//    }
	
    public ActionForward execute(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)throws IOException, ServletException{
    	if(SoxicPathUtil.returnForward(request).equalsIgnoreCase("save")){
    		return save(mapping,form,request,response);
    	}
    	return submit(mapping,form,request,response);
    }
    
    public ActionForward save(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        Owner owner = (Owner) request.getSession().getAttribute("owner");
	       try{
	       		owner.updateCycleQuestions(SoxicConstants.SAVEOPERATION);
	       }catch(Exception e){
	       	
	       }               
        return mapping.findForward("success");
    }
    
    public ActionForward submit(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        
    	CycleViewForm cycleViewForm = (CycleViewForm)form;
    	
    	String cycleId = SoxicPathUtil.getKey(request, "submit");
    	
    	cycleViewForm.setLinkOnSubmit(cycleId);
        
        Owner owner = (Owner) request.getSession().getAttribute("owner");
        try {
            owner.updateCycleQuestions(SoxicConstants.SUBMITOPERATION);
            StatusHelper statusHelper = new StatusHelper();
            String status = statusHelper.setCycleStatus(cycleId,owner.getOwnerId());
            statusHelper.setCycleStatus(request,cycleId,status);
            GapHelper gapHelper = new GapHelper();
            //gapHelper.sendEmail(SoxicConstants.CYCLE,cycleId); 
            StatusDAO statusDAO = new StatusDAO();
            String cycleOwnerStatus = statusDAO.getOwnerOverAllStatus(SoxicConstants.CYCLE,owner.getOwnerId());
            String sigCycleOwnerStatus = CycleStatusDAO.getSigChangeStatus(cycleId,owner.getOwnerId());
            if (cycleOwnerStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) && sigCycleOwnerStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                request.setAttribute("test","test");
            }
//            if(statusDAO.getOwnerOverAllStatus(SoxicConstants.CYCLE,owner.getOwnerId()).equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
//            	request.setAttribute("test","test");
//            }
        } catch (DatabaseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return mapping.findForward("success");
    }
}