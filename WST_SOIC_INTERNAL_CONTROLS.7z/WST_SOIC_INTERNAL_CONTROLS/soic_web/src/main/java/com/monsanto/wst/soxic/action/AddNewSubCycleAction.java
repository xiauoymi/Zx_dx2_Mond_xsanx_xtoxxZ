package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.exception.FileImportException;
import com.monsanto.wst.soxic.exception.SubCycleAlreadyPresent;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;
import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.importProject.ExcelHeaderBean;
import com.monsanto.wst.soxic.importProject.ImportExcel2DB;
import org.apache.struts.action.*;
import org.apache.struts.upload.FormFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 22, 2005
 * Time: 10:23:32 AM
 *
 * This Action class is used to upload templates into the database.
 * It uses the FormFile object which contains the parameters for the file such as,
 * FileName, Size and Input Stream.
 * It calls the class ImportExcel2D which contains the actual Import methods.
 */

public class AddNewSubCycleAction extends Action{

  public ActionForward execute(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response) throws IOException, Exception {

    SubCycleDeleteForm subcycledeleteform = (SubCycleDeleteForm)form;
    ActionMessages messages = new ActionMessages();
    SubCycleMaintainFacade subCycleMaintainFacade = new SubCycleMaintainFacade();
    ExcelHeaderBean excelHeaderBean = null;

    FormFile ff = subcycledeleteform.getRequestedFile();

    ImportExcel2DB importExcel2DB = new ImportExcel2DB(ff.getFileName(),ff.getInputStream(),"C://WSTTemp");
    importExcel2DB.setWb(importExcel2DB.getHssfworkbook());
    importExcel2DB.setSheet(importExcel2DB.getWb().getSheetAt(0));

    try{

      excelHeaderBean =  (ExcelHeaderBean)importExcel2DB.importFile();
      String cycleid = excelHeaderBean.getCycleID();
      subcycledeleteform.setSelectedCountry(excelHeaderBean.getCountry());
      subCycleMaintainFacade.cyclesFromCountry(subcycledeleteform,excelHeaderBean.getCountry());
      subcycledeleteform.setSelectedCycles(cycleid);
      subCycleMaintainFacade.subCycleFromCycle(subcycledeleteform, cycleid);

    }catch(Exception e){
      e.printStackTrace();
      request.setAttribute("errormessage", e.getMessage());
      if (e instanceof FileImportException){
        throw new FileImportException();
      }
      if (e instanceof SubCycleAlreadyPresent){
        throw new SubCycleAlreadyPresent();
      }
    }

    return mapping.findForward("seeform");

  }
}
