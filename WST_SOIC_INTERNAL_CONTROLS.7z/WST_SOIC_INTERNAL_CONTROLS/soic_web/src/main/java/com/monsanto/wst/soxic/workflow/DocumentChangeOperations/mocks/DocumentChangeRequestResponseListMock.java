package com.monsanto.wst.soxic.workflow.DocumentChangeOperations.mocks;

import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.IAAdminEmailDAO;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.DocumentChangeRequestResponseListInt;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces.DocumentChangeEmailStrategy;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces.DocumentChangeEmailStrategy;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces.DocumentChangeEmailIAStrategy;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces.DocumentChangeEmailIAStrategy;
import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 4:21:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeRequestResponseListMock implements DocumentChangeRequestResponseListInt{

    private List documentChangeRequestResponseList = new ArrayList();
    DocumentChangeEmailStrategy documentChangeEmailStrategy = new DocumentChangeEmailIAStrategy();
    int numberOfEmailsSent=0;

    public DocumentChangeRequestResponseListMock() {
        this.documentChangeRequestResponseList = new ArrayList();
        IAAdminEmailDAOInt iaAdminEmailDAO = new IAAdminEmailDAOMock();
        documentChangeRequestResponseList.addAll(iaAdminEmailDAO.select());
    }

    public List getDocumentChangeRequestResponseList() {
        return documentChangeRequestResponseList;
    }

    public void setDocumentChangeRequestResponseList(List documentChangeRequestResponseList) {
        this.documentChangeRequestResponseList = documentChangeRequestResponseList;
    }

    public void remove(OwnerChangeRequestResponse ownerChangeRequestResponse) {
        documentChangeRequestResponseList.remove(ownerChangeRequestResponse);
    }

    public void processEmails() {
        //To change body of implemented methods use File | Settings | File Templates.
        documentChangeEmailStrategy.processRequestResponseObjects(this);
    }

    public void sendEmails(){
        documentChangeEmailStrategy.processEmails(this);
    }

    public int getNumberOfEmailsSent() {
        return numberOfEmailsSent;
    }

    public void setNumberOfEmailsSent(int numberOfEmailsSent) {
        this.numberOfEmailsSent = numberOfEmailsSent;
    }


}
