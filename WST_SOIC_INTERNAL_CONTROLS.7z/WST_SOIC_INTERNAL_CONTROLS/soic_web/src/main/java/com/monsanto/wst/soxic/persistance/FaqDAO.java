package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.form.FAQForm;
import com.monsanto.wst.soxic.util.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 12, 2006
 * Time: 10:32:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class FaqDAO{

    private static String insertFaqIntoDB = "INSERT INTO FAQ (FAQ_ID,QUESTION,DESCRIPTION) VALUES (FAQ_SEQ.NEXTVAL,?,?)";

    public void createNewFaq(FAQForm faqForm) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement(insertFaqIntoDB);
            preparedStatement.setString(1, faqForm.getQuestion());
            preparedStatement.setString(2, faqForm.getAnswer());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }
}
