package com.monsanto.wst.soxic.model;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 21, 2005
 * Time: 10:17:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatus {

    private String id;
    private List owners;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List getOwners() {
        return owners;
    }

    public void setOwners(List owners) {
        this.owners = owners;
    }

}
