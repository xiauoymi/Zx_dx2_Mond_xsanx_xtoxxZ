package com.monsanto.wst.soxic.tags;

import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.servlet.jsp.JspException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vlarter
 * Date: Aug 15, 2005
 * Time: 1:49:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class PageHeader extends SimpleTagSupport {
    private String name = "";
    private String contextpath = "";

    public void doTag() throws JspException, IOException {
        getJspContext().getOut().write(buildHeaderHTMLString());
    }

    private String buildHeaderHTMLString() {
        StringBuffer tagContent = new StringBuffer();

        tagContent.append("<!-- Site Header Starts -->\n");
        tagContent.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"site_hdr\">\n");
        tagContent.append("<tr>\n");
        tagContent.append("<td><img src=\"" + contextpath + "/images/404_internal_control_logo.gif\" width=\"213\" height=\"58\" alt=\"\" border=\"0\"></td>\n");
        tagContent.append("<td class=\"util_links\">\n");
        tagContent.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
        tagContent.append("<tr>\n");
        tagContent.append("<td><img src=\"" + contextpath + "/images/home_start.gif\" width=\"25\" height=\"19\" alt=\"\" border=\"0\"></td>\n");
        tagContent.append("<td class=\"cell\"><a href=\"" + contextpath + "/login.do\">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=\"" + contextpath + "/jsp/contact_us.jsp\">Contact Us</a></td>\n");
        tagContent.append("</tr>\n");
        tagContent.append("</table>\n");
        tagContent.append("</td>\n");
        tagContent.append("<td class=\"mon_logo\"><img src=\"" + contextpath + "/images/mon_logo.gif\" width=\"134\" height=\"58\" alt=\"\" border=\"0\"></td>\n");
        tagContent.append("</tr>\n");
        tagContent.append("<tr>\n<td colspan=\"3\" class=\"nav_rule\"></td>\n</tr>\n</table>\n");
        tagContent.append("<!-- Site Header Ends -->\n");

        return tagContent.toString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContextpath() {
        return contextpath;
    }

    public void setContextpath(String contextpath) {
        this.contextpath = contextpath;
    }
}
