/*
 * Created on Apr 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.form.GapDeficiencyForm;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.ControlObjectiveDAO;
import com.monsanto.wst.soxic.model.GapDAO;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GapDefSubCycleOwnerDisplayAction extends Action {
	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)throws Exception {

		ActionForward forward = new ActionForward();
		
		GapDeficiencyForm gapDeficiencyForm = (GapDeficiencyForm)form;
		
		gapDeficiencyForm.clear();
		String activityIdentifier = request.getParameter("subCycleId");
		
		StringTokenizer st = new StringTokenizer(activityIdentifier,SoxicUtil.getSeperator());
		
		String activityId="";
		
		String ownerId="";
		
		
		while(st.hasMoreElements()){
			
			activityId = st.nextToken();
			ownerId = st.nextToken();
			
		}
		
		Map paramMap = request.getParameterMap();
		
		GapDAO gapDAO = new GapDAO();
		
		//gapDeficiencyForm.setAddedActivityList(ControlObjectiveDAO.getPreviousOwnerGap(activityId,ownerId));
		gapDeficiencyForm.setAddedActivityList(gapDAO.getPreviousOwnerGap(activityId,ownerId));
		
		gapDeficiencyForm.setActivityFlag(true);
		
		gapDeficiencyForm.setActivityList(getActivityList(ControlObjectiveDAO.getSubCycle(activityId)));
		
		gapDeficiencyForm.setControlObjectiveId(activityId);
		
		gapDeficiencyForm.setToReturn("CS");
		
		forward = mapping.findForward("gap");
		
		return forward;
	}

    public List getActivityList(Activity activity){
    	
    	List actList = new ArrayList();
    	
    	actList.add(activity);
    	
    	return actList;
    }
	
	
	public void addActivity(Map activityMap,List activityList,String questionId){
		
		Set keySet = activityMap.keySet();
		
		Iterator activityIterator = keySet.iterator();
		
		while(activityIterator.hasNext()){
			
			Object activityKey = (Object)activityIterator.next();
			
			Activity activity =(Activity)activityMap.get(activityKey);
			
			activity.setQuestionId(questionId);
			
			activityList.add(activity);
			
		}
	}
}
