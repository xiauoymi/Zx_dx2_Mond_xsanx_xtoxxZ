package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 1, 2005
 * Time: 11:35:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class DateSequenceException extends Exception{

    public DateSequenceException(){
		super();
	}

	public DateSequenceException(Exception e){
		super(e);
	}
}
