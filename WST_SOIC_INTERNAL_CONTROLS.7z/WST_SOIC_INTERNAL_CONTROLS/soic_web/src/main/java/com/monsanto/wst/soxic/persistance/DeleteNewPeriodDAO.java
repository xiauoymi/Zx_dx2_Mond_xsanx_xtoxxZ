package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 6, 2005
 * Time: 8:49:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteNewPeriodDAO {

    public void delete(String newPeriodId){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("delete from ctrl_obj_codes where activity_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from question_activity where activity_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from owner_activity where activity_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from activity where activity_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from ctrl_obj where ctrl_obj_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from question_sub_cycle where sub_cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from owner_sub_cycle where sub_cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from sub_cycle where sub_cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from question_cycle where cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from owner_cycle where cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from cycle_state where cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from cycle where cycle_id like '%"+newPeriodId+".%'");
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("delete from period where period_id like '%"+newPeriodId+"%'");
            preparedStatement.executeUpdate();



        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }

    }
}
