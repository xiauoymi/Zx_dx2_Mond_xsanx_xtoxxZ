package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.persistance.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.TextDifference;
import org.apache.struts.action.ActionForm;

import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 1, 2005
 * Time: 7:23:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeReviewFacade {

    public static final String REQUEST_NEW_SCREEN="requestnewscreen";
    public static final String REVIEW_SCREEN="reviewscreen";

    /**
     *Based on requested activity and owner ship details sets which fields can be viewed
     * by the user
     * @param documentChangeReviewForm
     * @param owner
     * @throws Exception
     */
    public void setViewDetails(DocumentChangeReviewForm documentChangeReviewForm,Owner owner)throws Exception{
        //OracleDocumentChangeDAO oracleDocumentChangeDAO= (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        setViewDetailsBasedOnRequestType(documentChangeReviewForm);

//        if(owner.getDocChangeLevel().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY)){
//            documentChangeReviewForm.setViewIAApprovalLabel(false);
//            documentChangeReviewForm.setViewSubCycleApprovalLabel(false);
//            documentChangeReviewForm.setViewReasonToDiapprove(false);
//        }
        setViewDetailsBasedOnSource(documentChangeReviewForm, owner);
        setViewDetailsNewMode(documentChangeReviewForm);
    }

    /**
     * Source can be either IA or IAUser or Sub Cycle onwer or Activity Owner
     * @param documentChangeReviewForm
     * @param owner
     */
    private void setViewDetailsBasedOnSource(DocumentChangeReviewForm documentChangeReviewForm, Owner owner) {
        setViewDetailsActivitySource(documentChangeReviewForm);
        setViewDetailsIAorSub(owner, documentChangeReviewForm);
    }

    /**
     * Request type can be either Add, Delete or Modify
     * @param documentChangeReviewForm
     */
    private void setViewDetailsBasedOnRequestType(DocumentChangeReviewForm documentChangeReviewForm) {
        setViewDetailsAddRequest(documentChangeReviewForm);
        setViewDetailsDeleteRequest(documentChangeReviewForm);
        setViewDetailsModifyRequest(documentChangeReviewForm);
    }

    /**
     * if mode is new set all the fields to empty values
     * @param documentChangeReviewForm
     */
    private void setViewDetailsNewMode(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
            documentChangeReviewForm.setNewActivityDescription("");
            documentChangeReviewForm.setReasonForRemoval("");
            documentChangeReviewForm.setReasonToDisapprove("");
            documentChangeReviewForm.setPriority("");
        }
    }

    /**
     *for IA or sub Cycle set their respective approval to true and reason to disapprove to true
     * @param owner
     * @param documentChangeReviewForm
     */
    private void setViewDetailsIAorSub(Owner owner, DocumentChangeReviewForm documentChangeReviewForm) {

        if(owner.getDocChangeLevel()!=null && owner.getDocChangeLevel().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){
            documentChangeReviewForm.setViewIAApprovalLabel(true);
            documentChangeReviewForm.setViewReasonToDiapprove(true);
            documentChangeReviewForm.setViewPriority(true);
            if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                documentChangeReviewForm.setViewIAActivityIdNewDetails(true);
            }else{
                documentChangeReviewForm.setViewIAActivityIdNewDetails(false);
            }

        }else{
            if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
                documentChangeReviewForm.setViewSubCycleApprovalLabel(true);
                documentChangeReviewForm.setViewReasonToDiapprove(true);
                documentChangeReviewForm.setViewIAActivityIdNewDetails(false);
            }
        }
    }

    /**
     * For an activity owner he should not be able to view IA or Sub Cycle approval radio buttons and reson for disapproving
     * @param documentChangeReviewForm
     */
    private void setViewDetailsActivitySource(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY) || documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA_USER)){
            documentChangeReviewForm.setViewIAApprovalLabel(false);
            documentChangeReviewForm.setViewSubCycleApprovalLabel(false);
            documentChangeReviewForm.setViewReasonToDiapprove(false);
            documentChangeReviewForm.setViewIAActivityIdNewDetails(false);
        }
    }

    /**
     * For modify request only thing viewable are old description and new description .
     * @param documentChangeReviewForm
     */
    private void setViewDetailsModifyRequest(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
            documentChangeReviewForm.setViewNewActivityDescription(true);
            documentChangeReviewForm.setViewOldActivityDescription(true);
            documentChangeReviewForm.setViewReasonForRemoval(false);
        }
    }

    /**
     * For remove request only things viewable are old description and reason for removal
     * @param documentChangeReviewForm
     */
    private void setViewDetailsDeleteRequest(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
            documentChangeReviewForm.setViewOldActivityDescription(true);
            documentChangeReviewForm.setViewReasonForRemoval(true);
            documentChangeReviewForm.setViewNewActivityDescription(false);
        }
    }

    /**
     * For add request only things viewable are new description
     * @param documentChangeReviewForm
     */
    protected void setViewDetailsAddRequest(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
            documentChangeReviewForm.setViewNewActivityDescription(true);
            documentChangeReviewForm.setViewOldActivityDescription(false);
            documentChangeReviewForm.setViewReasonForRemoval(false);
            //documentChangeReviewForm.setViewReasonToDiapprove(false);
        }
    }

    /**
     * Break up the url and set the respective form paramters
     * Expected url ActityIdentifer|sourceTye|requestType|mode|responseId|ViewUpdateButton
     * @param documentChangeReviewForm
     */
    public void setFormDetails(DocumentChangeReviewForm documentChangeReviewForm){
        String url = documentChangeReviewForm.getUrl();
        StringTokenizer st = new StringTokenizer(url,SoxicUtil.getSeperator());
        String activityIdentifier = st.nextToken();
        String sourceType = st.nextToken();
        String requestType = st.nextToken();
        String mode = st.nextToken();
        String responseId="";
        if(mode.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
            String update = st.nextToken();
            if(update.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE)){
                documentChangeReviewForm.setViewUpdateButton(true);
            }else{
                documentChangeReviewForm.setViewUpdateButton(false);
            }
        }
        if(mode.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW)){
            String update = st.nextToken();
            if(update.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_MODIFY_TRUE)){
                documentChangeReviewForm.setViewUpdateButton(true);
            }else{
                documentChangeReviewForm.setViewUpdateButton(false);
            }

            responseId = st.nextToken();
        }

        documentChangeReviewForm.setIdentifier(activityIdentifier);
        documentChangeReviewForm.setSource_type(sourceType);
        documentChangeReviewForm.setRequest_type(requestType);
        documentChangeReviewForm.setMode(mode);
        documentChangeReviewForm.setOcreqResponse(responseId);
    }

    /**
     *Based on the activity and the requested mode populate the details of the activity(Populate Old description)
     * @param documentChangeReviewForm
     * @param owner
     * @throws Exception
     */
    public void initializeParameters(DocumentChangeReviewForm documentChangeReviewForm,Owner owner)throws Exception{
        initializeDetailsBasedOnRequest(documentChangeReviewForm);
        initializeDetailsBasedOnSourceType(documentChangeReviewForm);
        initializeDetailsBasedOnMode(documentChangeReviewForm);
        initializeDetailsAddNewActivitiesIdsForIA(documentChangeReviewForm);
    }

    protected void highlightTextDifferencesForNewActivityDescription(DocumentChangeReviewForm documentChangeReviewForm) {
        TextDifference textDiff = new TextDifference();
        documentChangeReviewForm.setDiffActivityDescription(textDiff.highlightTextDifferences(documentChangeReviewForm.getOldActivityDescription(), documentChangeReviewForm.getNewActivityDescription()));
    }

    /**
     * If IA or Sub Cycle requests something new pre approve
     * @param documentChangeReviewForm
     */
    private void initializeDetailsBasedOnSourceType(DocumentChangeReviewForm documentChangeReviewForm) {
        // New Mode -- Add for sub-cycle level and IA level Set the Approve to true.
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
            if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){
                documentChangeReviewForm.setStatus("approve");
            }

            if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
                documentChangeReviewForm.setStatus("approve");
            }
        }
    }

    protected void initializeDetailsBasedOnMode(DocumentChangeReviewForm documentChangeReviewForm) throws Exception {
        OracleDocumentChangeDAO oracleDocumentChangeDAO = (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW) || (documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW) && !documentChangeReviewForm.isViewUpdateButton())){
            oracleDocumentChangeDAO.initializeDocumentChangeReviewFormDetails(documentChangeReviewForm);
        }
        if(documentChangeReviewForm.getOverFlowId()>0){
            oracleDocumentChangeDAO.correctNewActivityDescription(documentChangeReviewForm);
        }

        if (documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW) && documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY))
            highlightTextDifferencesForNewActivityDescription(documentChangeReviewForm);
    }

    private void initializeDetailsAddNewRequest(DocumentChangeReviewForm documentChangeReviewForm) {
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
            if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                String id = getNextActivityIdForControlObjective(documentChangeReviewForm);
                documentChangeReviewForm.setIdentifier(id);
            }
        }
    }

    private void initializeDetailsAddNewActivitiesIdsForIA(DocumentChangeReviewForm documentChangeReviewForm){
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA) && documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
            documentChangeReviewForm.setNewActivityIdsAvaliable(getNextActivityIdListForControlObjective(documentChangeReviewForm));
            if(documentChangeReviewForm.getIdentifier()!=null){
                documentChangeReviewForm.setIaNewStringAddedToActivity(stripIdGetExtraCharacters(documentChangeReviewForm.getIdentifier()));
            }
        }
    }

    private void initializeDetailsBasedOnRequest(DocumentChangeReviewForm documentChangeReviewForm) throws Exception {
        initializeDetailsAddNewRequest(documentChangeReviewForm);
        initializeDetailsModifyRequest(documentChangeReviewForm);
        initializeDetailsDeleteRequest(documentChangeReviewForm);
    }

    private void initializeDetailsDeleteRequest(DocumentChangeReviewForm documentChangeReviewForm) throws Exception {
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
            setOldDescription(documentChangeReviewForm);
        }
    }

    private void initializeDetailsModifyRequest(DocumentChangeReviewForm documentChangeReviewForm) throws Exception {
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
            setOldDescription(documentChangeReviewForm);
        }
    }

    protected void setOldDescription(DocumentChangeReviewForm documentChangeReviewForm) throws Exception {
        OracleDocumentChangeDAO oracleDocumentChangeDAO = (OracleDocumentChangeDAO) AbstractDAOFactory.getFactory().getOracleDocumentChangeDAO();
        oracleDocumentChangeDAO.setOldActivityDescription(documentChangeReviewForm);
    }

    private OwnerChangeRequest updateParameters(ActionForm form,Owner owner){
        OwnerChangeRequest ownerChangeRequest = new OwnerChangeRequest();
        ownerChangeRequest.setParameters(form,owner);
        return ownerChangeRequest;
    }

    public Collection createOwnerRequestResponseObjects(ActionForm form,Owner owner,OwnerChangeRequest ownerChangeRequest){
        List ownerRequestResponseList = new ArrayList();
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;

        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY)){
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
        }
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA_USER)){
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
        }
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
        }
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
        }
        return ownerRequestResponseList;
    }

    public Collection createOwnerUpdateRequestResponseObjects(ActionForm form,Owner owner,OwnerChangeRequest ownerChangeRequest){
        List ownerRequestResponseList = new ArrayList();
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;

        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY)){
            //ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            //ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
        }
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE)){
            if(documentChangeReviewForm.getStatus().equalsIgnoreCase("approve")){
                ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
                //sendIARequestApprovalEmail(ownerChangeRequest);
                //ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAOwnerResponse(ownerChangeRequest.getOwnerChangeRequestId(),owner));
            }else{
                ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleReject(ownerChangeRequest.getOwnerChangeRequestId(),owner,documentChangeReviewForm.getReasonToDisapprove()));
            }

        }
        if(documentChangeReviewForm.getSource_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_IA)){
            if(documentChangeReviewForm.getStatus().equalsIgnoreCase("approve")){
                //ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivitySubCycleApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
                ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAApproved(ownerChangeRequest.getOwnerChangeRequestId(),owner));
                //sendIAApprovedEmail(ownerChangeRequest);
            }else{
                ownerRequestResponseList.add(OwnerChangeRequestResponse.createNewActivityIAReject(ownerChangeRequest.getOwnerChangeRequestId(),owner,documentChangeReviewForm.getReasonToDisapprove()));
            }
        }
        return ownerRequestResponseList;
    }

    protected void createOwnerRequest(OwnerChangeRequest ownerChangeRequest){
        DAO oracleOwnerChangeRequestDAO= (OracleOwnerChangeRequestDAO) AbstractDAOFactory.getFactory().getOwnerChangeRequestDAO();
        try{
            oracleOwnerChangeRequestDAO.create(ownerChangeRequest);
        }catch(Exception e){

        }
    }

    protected void updateOwnerRequest(OwnerChangeRequest ownerChangeRequest){
        OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO= (OracleOwnerChangeRequestDAO) AbstractDAOFactory.getFactory().getOwnerChangeRequestDAO();
        try{
            oracleOwnerChangeRequestDAO.updateModel(ownerChangeRequest);
        }catch(Exception e){

        }
    }

    protected SoxicBaseModel selectIdForOwnerRequest(OwnerChangeRequest ownerChangeRequest){
        OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO= (OracleOwnerChangeRequestDAO) AbstractDAOFactory.getFactory().getOwnerChangeRequestDAO();
        try{
            return oracleOwnerChangeRequestDAO.select(ownerChangeRequest,OwnerChangeRequest.SELECT_TYPE_OCREQ_ID);
        }catch(Exception e){

        }
        return null;
    }

    public void createOwnerResponse(OwnerChangeRequestResponse ownerChangeRequestResponse){
        DAO oracleOwnerChangeRequestResponseDAO= (OracleOwnerChangeRequestResponseDAO) AbstractDAOFactory.getFactory().getOwnerChangeRequestResponseDAO();
        try{
            oracleOwnerChangeRequestResponseDAO.create(ownerChangeRequestResponse);
        }catch(Exception e){

        }
    }

    public void updateOwnerResponse(OwnerChangeRequestResponse ownerChangeRequestResponse){
        OracleOwnerChangeRequestResponseDAO oracleOwnerChangeRequestResponseDAO= (OracleOwnerChangeRequestResponseDAO) AbstractDAOFactory.getFactory().getOwnerChangeRequestResponseDAO();
        try{
            oracleOwnerChangeRequestResponseDAO.updateModel(ownerChangeRequestResponse);
        }catch(Exception e){

        }
    }

    protected void createResponses(List ownerResponseObjects){
        Iterator iterator = ownerResponseObjects.iterator();
        while(iterator.hasNext()){
            OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)iterator.next();
            createOwnerResponse(ownerChangeRequestResponse);
        }
    }

    protected void updateResponses(List ownerResponseObjects){
        Iterator iterator = ownerResponseObjects.iterator();
        while(iterator.hasNext()){
            OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)iterator.next();
            updateOwnerResponse(ownerChangeRequestResponse);
        }
    }

    public void process(ActionForm form,Owner owner){
        OwnerChangeRequest ownerChangeRequest=  updateParameters(form,owner);
        insertOverFlowId(ownerChangeRequest);
        createOwnerRequest(ownerChangeRequest);

        ownerChangeRequest = (OwnerChangeRequest)selectIdForOwnerRequest(ownerChangeRequest);
        if(ownerChangeRequest.getOwnerChangeRequestId()!=null){
            ((DocumentChangeReviewForm)form).setOcreqResponse(ownerChangeRequest.getOwnerChangeRequestId());
        }
        List ownerRequestResponseObjects = (List)createOwnerRequestResponseObjects(form,owner,ownerChangeRequest);
        createResponses(ownerRequestResponseObjects);
        if(ownerChangeRequest.getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
            createNewActivity(form,owner,ownerChangeRequest);
        }
        updateForModifiedActivityId(form, owner, ownerChangeRequest);
    }

    /**
     *In the review mode based on user reponses update the database
     * @param form
     * @param owner
     */
    public void processUpdate(ActionForm form,Owner owner){
        OwnerChangeRequest ownerChangeRequest=  updateParameters(form,owner);
        insertOverFlowId(ownerChangeRequest);
        updateOverFlowId(ownerChangeRequest);
        ownerChangeRequest.setOwnerChangeRequestId(((DocumentChangeReviewForm)form).getOcreqResponse());
        updateOwnerRequest(ownerChangeRequest);

        //ownerChangeRequest = (OwnerChangeRequest)selectIdForOwnerRequest(ownerChangeRequest);
        List ownerRequestResponseObjects = (List)createOwnerUpdateRequestResponseObjects(form,owner,ownerChangeRequest);
        updateResponses(ownerRequestResponseObjects);
        updateForModifiedActivityId(form, owner, ownerChangeRequest);
    }

    public String getNextActivityIdForControlObjective(DocumentChangeReviewForm documentChangeReviewForm){

        List controlActivities = getControlActivitiesList(documentChangeReviewForm);
        List intPart = new ArrayList();
        Iterator iterator = controlActivities.iterator();
        ActivityNew activityNew=null;
        while(iterator.hasNext()){
            activityNew = (ActivityNew)iterator.next();
            intPart.add(activityNew.getActivityCodeIntegerPart());
        }
        Collections.sort(intPart);
        String highestPart = (String)intPart.get(intPart.size()-1);
        int highest =  Integer.parseInt(highestPart)+1;
        String newId = "";
        if(highest<=9){
            newId = activityNew.getCtrlObjCode()+".0"+highest;
        }else{
            newId = activityNew.getCtrlObjCode()+"."+highest;
        }
        return newId;
    }

    public List getNextActivityIdListForControlObjective(DocumentChangeReviewForm documentChangeReviewForm){
        List newActivitylist = new ArrayList();
        newActivitylist.add("SELECT");
        int count=0;
        String id = documentChangeReviewForm.getIdentifier();
        StringTokenizer st = new StringTokenizer(id,".");
        String period = st.nextToken();
        String country = st.nextToken();
        String cycle = st.nextToken();
        String subCycle = st.nextToken();
        String ctrlobj = st.nextToken();
        String objId = period+"."+country+"."+cycle+"."+subCycle+"."+ctrlobj;
        List controlActivities = getControlActivitiesList(objId);
        List intPart = new ArrayList();
        Iterator iterator = controlActivities.iterator();
        ActivityNew activityNew=null;
        while(iterator.hasNext()){
            activityNew = (ActivityNew)iterator.next();
            intPart.add(activityNew.getActivityCodeIntegerPart());
        }
        Collections.sort(intPart);
        String highestPart = (String)intPart.get(intPart.size()-1);
        int highest =  Integer.parseInt(highestPart)+1;
        String newId = "";
        while(count<5){
            if(highest<=9){
                newId = activityNew.getCtrlObjCode()+".0"+highest;
            }else{
                newId = activityNew.getCtrlObjCode()+"."+highest;
            }
            highest++;
            newActivitylist.add(newId);
            count++;
        }
        return newActivitylist;
    }
    protected List getControlActivitiesList(DocumentChangeReviewForm documentChangeReviewForm){
        List controlActivities =null;
        OracleControlObjectiveDAO oracleControlObjectiveDAO= (OracleControlObjectiveDAO) AbstractDAOFactory.getFactory().getControlObjectiveDAO();
        try{
            controlActivities = (List)oracleControlObjectiveDAO.getActivities(documentChangeReviewForm.getIdentifier());
        }catch(Exception e){

        }
        return controlActivities;
    }

    protected List getControlActivitiesList(String controlObjectiveId){
        List controlActivities =null;
        OracleControlObjectiveDAO oracleControlObjectiveDAO= (OracleControlObjectiveDAO) AbstractDAOFactory.getFactory().getControlObjectiveDAO();
        try{
            controlActivities = (List)oracleControlObjectiveDAO.getActivities(controlObjectiveId);
        }catch(Exception e){

        }
        return controlActivities;
    }

    private void createNewActivity(ActionForm form,Owner owner){
        DocumentChangeReviewForm documentChangeReviewForm =(DocumentChangeReviewForm)form;
        OracleActivityDAO oracleActivityDAO = (OracleActivityDAO) AbstractDAOFactory.getFactory().getActivityDAO();
        ActivityNew activityNew = new ActivityNew();
        activityNew.setActivityId(documentChangeReviewForm.getIdentifier());
        activityNew.setActivityCode(activityNew.getActivityCodePart());
        activityNew.setDescription(documentChangeReviewForm.getNewActivityDescription());
        activityNew.setCtrlObjCode(activityNew.getCtrlObjCode());
        activityNew.setOwnerId(owner.getOwnerId());
        oracleActivityDAO.create(activityNew);

    }

    protected void createNewActivity(ActionForm form,Owner owner,OwnerChangeRequest ownerChangeRequest){
        DocumentChangeReviewForm documentChangeReviewForm =(DocumentChangeReviewForm)form;
        OracleActivityDAO oracleActivityDAO = (OracleActivityDAO) AbstractDAOFactory.getFactory().getActivityDAO();
        ActivityNew activityNew = new ActivityNew();
        activityNew.setActivityId(documentChangeReviewForm.getIdentifier());
        activityNew.setActivityCode(activityNew.getActivityCodePart());
        activityNew.setDescription(ownerChangeRequest.getRequestText());
        activityNew.setCtrlObjCode(activityNew.getCtrlObjCode());
        activityNew.setOverFlowId(ownerChangeRequest.getOverFlowId());
        activityNew.setOwnerId(owner.getOwnerId());
        activityNew.setPriority(documentChangeReviewForm.getPriority());
        oracleActivityDAO.create(activityNew);

    }



    public String findForward(DocumentChangeReviewForm documentChangeReviewForm){
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
//            return "requestnewscreen";
            return REQUEST_NEW_SCREEN;
        }
        if(documentChangeReviewForm.getMode().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_REVIEW)){
            //return "reviewscreen";
            return REVIEW_SCREEN;
        }
        return "success";
    }

    private void updateForModifiedActivityId(ActionForm form, Owner owner, OwnerChangeRequest ownerChangeRequest){
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;
        OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO = new OracleOwnerChangeRequestDAO();
        OracleActivityDAO oracleActivityDAO = new OracleActivityDAO();
        String id = returnModifiedControlActivityId(documentChangeReviewForm);
        String ocreq = documentChangeReviewForm.getOcreqResponse();
        try{
            if(id.length()>0 && documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                oracleOwnerChangeRequestDAO.updateWithNewIdForIA(id,ocreq);
                oracleActivityDAO.delete(documentChangeReviewForm.getIdentifier(),id);
                documentChangeReviewForm.setIdentifier(id);
                createNewActivity(documentChangeReviewForm,owner,ownerChangeRequest);
            }

        }catch(Exception e){

        }
    }

    private String returnModifiedControlActivityId(DocumentChangeReviewForm documentChangeReviewForm){
        String id="";
        if(documentChangeReviewForm.getRequest_type().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
           if(documentChangeReviewForm.getIaSelectedNewActivityId()!=null){
               if(!documentChangeReviewForm.getIaSelectedNewActivityId().equalsIgnoreCase("SELECT")){
                    String newSelectedId = documentChangeReviewForm.getIaSelectedNewActivityId();
                    if(documentChangeReviewForm.getIaNewStringAddedToActivity()!=null){
                        //id = newSelectedId+ documentChangeReviewForm.getIaNewStringAddedToActivity();
                        id = stripExtraCharactersOfId(newSelectedId)+ documentChangeReviewForm.getIaNewStringAddedToActivity();
                    }
                }else{
                    String newSelectedId = documentChangeReviewForm.getIdentifier();
                    if(documentChangeReviewForm.getIaNewStringAddedToActivity()!=null){
                       // id = newSelectedId+ documentChangeReviewForm.getIaNewStringAddedToActivity();
                        id = stripExtraCharactersOfId(newSelectedId)+ documentChangeReviewForm.getIaNewStringAddedToActivity();
                    }
               }
           }
        }

        return id;
    }

    private String stripExtraCharactersOfId(String id){
        String intpart="";
        StringTokenizer stringTokenizer = new StringTokenizer(id,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        String currentActivityId= stringTokenizer.nextToken();

        String regEx = "\\d+";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(currentActivityId);
        while(matcher.find()){
            intpart = matcher.group();
        }

        return period+"."+countryId+"."+cycleId+"."+subCycleId+"."+controlObjectiveId+"."+intpart;
    }

    public String stripIdGetExtraCharacters(String id){
        String intpart="";
        StringTokenizer stringTokenizer = new StringTokenizer(id,".");
        String period = stringTokenizer.nextToken();
        String countryId = stringTokenizer.nextToken();
        String cycleId = stringTokenizer.nextToken();
        String subCycleId= stringTokenizer.nextToken();
        String controlObjectiveId= stringTokenizer.nextToken();
        String currentActivityId= stringTokenizer.nextToken();

        String regEx = "(\\d+)?";
//        String regEx = "[a-zA-Z]+([0-9]+)?";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(currentActivityId);
        int startIndex = 0;
        while(matcher.find()){
            startIndex = matcher.end();
            break;
        }

        intpart = currentActivityId.substring(startIndex, currentActivityId.length());

        return intpart;
    }

    public void insertOverFlowId(OwnerChangeRequest ownerChangeRequest){

        if(ownerChangeRequest.getRequestText().length()>2000){
            Vector chunk = getDescriptionChunk(ownerChangeRequest.getRequestText());
            OracleOwnerChangeRequestDAO oracleOwnerChangeRequestDAO = new OracleOwnerChangeRequestDAO();
            int overFlowId =oracleOwnerChangeRequestDAO.insertOverFlowText(chunk);
            ownerChangeRequest.setOverFlowId(overFlowId);
            ownerChangeRequest.setRequestText(chunk.get(0).toString());
        }

    }

    public Vector getDescriptionChunk(String descriptionIn){
        Vector descriptionChunk = new Vector();
        for(int chCnt = 0; chCnt < descriptionIn.length(); chCnt = chCnt + 2000){
            if(chCnt + 2000 <= descriptionIn.length()){
                descriptionChunk.add(descriptionIn.substring(chCnt, chCnt + 2000));
            }
            else{
                descriptionChunk.add(descriptionIn.substring(chCnt, descriptionIn.length()));
            }
        }
        return descriptionChunk;
    }

    private void updateOverFlowId(OwnerChangeRequest ownerChangeRequest){
        if(ownerChangeRequest.getOverFlowId()>0){
            ActivityNew activityNew = new ActivityNew();
            activityNew.setActivityId(ownerChangeRequest.getTargetId());
            activityNew.setOverFlowId(ownerChangeRequest.getOverFlowId());
            OracleActivityDAO oracleActivityDAO = (OracleActivityDAO) AbstractDAOFactory.getFactory().getActivityDAO();
            oracleActivityDAO.updateOverFlowId(activityNew);
        }
    }

}
