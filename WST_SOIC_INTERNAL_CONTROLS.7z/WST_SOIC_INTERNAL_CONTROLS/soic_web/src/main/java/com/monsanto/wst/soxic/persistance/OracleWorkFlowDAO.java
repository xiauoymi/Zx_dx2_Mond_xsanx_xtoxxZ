package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 15, 2005
 * Time: 10:55:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class OracleWorkFlowDAO extends OracleAbstractDAO{
    public void update(Collection soxicBaseModels) throws DatabaseException, Exception{};


    protected  String buildSelectQuery(Map fields){
        return "";
    }

    protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception{
        return null;
    }

    public int create(SoxicBaseModel soxicBaseModel)throws Exception{
        return -1;
    }
}
