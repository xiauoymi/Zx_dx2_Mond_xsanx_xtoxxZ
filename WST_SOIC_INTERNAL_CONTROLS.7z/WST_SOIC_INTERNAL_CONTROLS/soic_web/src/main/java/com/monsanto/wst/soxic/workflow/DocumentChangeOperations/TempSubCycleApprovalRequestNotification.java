package com.monsanto.wst.soxic.workflow.DocumentChangeOperations;

import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 2, 2005
 * Time: 11:04:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class TempSubCycleApprovalRequestNotification {



    List initialList = new ArrayList();

    List responseList = new ArrayList();

    public static void main(String args[]){
        TempSubCycleApprovalRequestNotification tempIAResponseNotification = new TempSubCycleApprovalRequestNotification();
//        IAAdminEmailDAO iaAdminEmailDAO = new IAAdminEmailDAO();
//        tempIAResponseNotification.setInitialList(iaAdminEmailDAO.selectForSubCycleApprovalRequest());
//        tempIAResponseNotification.processRequestResponseObjects();
//        tempIAResponseNotification.sendRequestApprovalEmail();


    }

    public void process(){
        IAAdminEmailDAO iaAdminEmailDAO = new IAAdminEmailDAO();
        setInitialList(iaAdminEmailDAO.selectForSubCycleApprovalRequest());
        processRequestResponseObjects();
        sendRequestApprovalEmail();
    }


    public void processRequestResponseObjects(){

        Iterator iterator =initialList.iterator();
        List tempList = new ArrayList();

        while(iterator.hasNext()){
            OwnerChangeRequest ownerChangeRequestResponse = (OwnerChangeRequest)iterator.next();
            if(SoxicUtil.isYesterday(ownerChangeRequestResponse.getRespApprovedDate())){
                tempList.add(ownerChangeRequestResponse);
            }
        }
        responseList.addAll(tempList);

    }

    private void sendRequestApprovalEmail(){
        List upperLevelOwnerWrapperList = new ArrayList();
        try{
            UtilDAO utilDAO = new UtilDAO();
            String toType="";
//            List upperLevelOwnerWrapperList=null;
//            if(ownerChangeRequest.getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY)){
//                upperLevelOwnerWrapperList = utilDAO.getUpperLevelOwnerWrapperList(ownerChangeRequest.getSourceType(),ownerChangeRequest.getTargetId());
//                toType="Sub-cycle Owner";
//            }else{
//                upperLevelOwnerWrapperList = utilDAO.getIAOwnerWrapper();
//                toType="IA Admin";
//            }

            Iterator aiterator = responseList.iterator();

            while(aiterator.hasNext()){
                OwnerChangeRequest ownerChangeRequest = (OwnerChangeRequest)aiterator.next();
                upperLevelOwnerWrapperList.addAll(utilDAO.getUpperLevelOwnerWrapperList(ownerChangeRequest.getSourceType(),ownerChangeRequest.getTargetId()));
                toType="Sub-cycle Owner";
            }

            Iterator iterator = upperLevelOwnerWrapperList.iterator();
            while(iterator.hasNext()){
                OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
                SarboxMailComponent.workFlowEmail(SarboxMailComponent.WF_DOC_CHANGE_SUB_APPROVAL_REQUEST,toType,ownerWrapper);
            }
        }catch(Exception e){

        }
    }

    public List getInitialList() {
        return initialList;
    }

    public void setInitialList(List initialList) {
        this.initialList = initialList;
    }

    public List getResponseList() {
        return responseList;
    }

    public void setResponseList(List responseList) {
        this.responseList = responseList;
    }
}
