/*
 * Created on Jan 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.InvalidUserException;
//import com.monsanto.wst.soxic.persistance.AbstractDAOFactory;
import com.monsanto.wst.soxic.persistance.DAO;
import com.monsanto.wst.soxic.persistance.OwnerDAO;
import com.monsanto.wst.soxic.persistance.AbstractDAOFactory;
import com.monsanto.wst.soxic.persistance.OracleAdminOwnerDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Owner extends SoxicBaseModel{
        

//  following feilds represents the Column Names of Sub_Cycle, Owner_Sub_cycle table in the DB.
    
    public static final String OWNER_ID      = "OWNER_ID";
    public static final String NAME          = "NAME";
    public static final String EMAIL         = "EMAIL";
    public static final String LAST_LOGIN    = "LAST_LOGIN";
            
    private String	ownerId;
    private String  name;
    private String  email;
    private String  lastLogin;
    private String  role;
    private String  periodId;
    private boolean isAdmin;
    private boolean showMaintainenceForCycleOrSubCycle;
    private boolean isIA;
    private boolean isIAUser;
    private boolean viewReports;
    private boolean docChange;
    private boolean certification;
    private boolean documentChangeTab;
    private boolean isActivityCertification=false;
    private boolean isDocChangeCertification = false;
    /**
     * Doc Change Level can be either Activity or Sub Cycle or IA
     */
    private String  docChangeLevel;
    private List    newsList;
    private String  location;
    
    protected List    subCycles;
    protected List    docChangeSubCycles;
    protected List    cycles;


    // a map of subCycles keyed with corresponding cycleId.
    private Map    cycleSubCycleAssociation;
    private Map    periodCycleAssociation;
    private Map    upperOwnerList;
    
    protected List activitySubCycleAssociation;
    public Owner(){
        
    }
    
    public Owner(String ownerId){
        // based on the level in the owner table determine what all the data he needs to query for.
        
        //Map key is: subCycleId and the Value is a list of controlobjectives, contains all the activities owned 
        //by this user aswell as others).
        
        //A Map with CycleId as key and the list of subcycles owned by this owner.
        
        //A map with periodId as key and the list of Cycles owned by this owner.
        
        this.ownerId = ownerId;
       // init();
    }
    
    public void init() throws DatabaseException, Exception {
    	initalizeOwnerDetails();
    	initalizePeriod();
        getAllCycles("INIT");
        getAllSubCycles("INIT");
        setDocChangeForSubCycleOwners();
        setActivitySubCycleAssociation();
        setDocChangeParameters();
        setDocumentChangeIfIa();
        setDocumentChangeIfIaUser();
        setMaintainenceParamters();
        if(subCycles.size()>0 ){

            certificationAvaliable();
        }
        if(docChangeSubCycles.size()>0){
            docChangeAvaliable();
        }
        if(activitySubCycleAssociation.size()>0) {
              activityoDcChangeAvaliable();
            activityCertificationAvaliable();
        }
//        if(subCycles.size()>0  || activitySubCycleAssociation.size()>0 ){
//             if(docChangeAvaliable()){
//                 setDocChangeParameters();
//             }
//            certificationAvaliable();
//
//        }
        setDocumentChangeTab();
        initializeUpperLevelDetails();
          
    }

    public void setMaintainenceParamters(){
        OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
        List stateList = new ArrayList();
        stateList.add(SoxicConstants.CYCLE_STATE);
        stateList.add(SoxicConstants.CYCLE_STATE_CERTIFICATION);
        stateList.add(SoxicConstants.CYCLE_STATE_LOCK);
        stateList.add(SoxicConstants.CYCLE_STATE_PRECERTIFY);
        stateList.add(SoxicConstants.CYCLE_STATE_RELEASE);
        if(oracleAdminOwnerDAO.isSubCycleOwner(this,stateList)){
            showMaintainenceForCycleOrSubCycle=true;
        }
        if(oracleAdminOwnerDAO.isCycleOwner(this,stateList)){
            showMaintainenceForCycleOrSubCycle=true;
        }

    }

    public void setDocChangeForSubCycleOwners(){
        try{
            docChangeSubCycles = SubCycleDAO.getSubCyclesForDocChangeStateAsSubCycleOwner(ownerId,SoxicConstants.DOCCHANGE_STATE);

        }catch(Exception e){

        }

    }

    public void setDocChangeParameters(){
        if(activitySubCycleAssociation.size()>0){
              docChangeLevel =SoxicConstants.DOC_CHANGE_LEVEL_ACTIVITY;
        }
        if(subCycles.size()>0){
            docChangeLevel =SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE;
        }
        if(isIA){
            docChangeLevel =SoxicConstants.DOC_CHANGE_ROLE_IA;
        }
        if(isIAUser){
            //docChangeLevel =SoxicConstants.DOC_CHANGE_ROLE_IA_USER;
        }
    }

    public boolean docChangeAvaliable(){
        Iterator iterator = docChangeSubCycles.iterator();
        SubCycle subCycle=null;

        while(iterator.hasNext()){
            subCycle = (SubCycle)iterator.next();
            if(subCycle.getState()!= null && subCycle.getState().equals(SoxicConstants.DOCCHANGE_STATE)){
                docChange = true;
            }

        }
        return true;
    }

    public boolean certificationAvaliable(){
        Iterator iterator = subCycles.iterator();
        SubCycle subCycle=null;

        while(iterator.hasNext()){
            subCycle = (SubCycle)iterator.next();
            if(subCycle.getState()!= null && subCycle.getState().equals(SoxicConstants.CERTIFICATION_STATE)){
                certification = true;
            }

        }
        return true;
    }

        public boolean activityoDcChangeAvaliable(){
        Iterator iterator = activitySubCycleAssociation.iterator();
        SubCycle subCycle=null;

        while(iterator.hasNext()){
            subCycle = (SubCycle)iterator.next();
            if(subCycle.getState()!= null && subCycle.getState().equals(SoxicConstants.DOCCHANGE_STATE)){
                docChange = true;
                //isDocChangeCertification=true;

            }

        }
        return true;
    }

    public boolean activityCertificationAvaliable(){
        Iterator iterator =activitySubCycleAssociation.iterator();
        SubCycle subCycle=null;

        while(iterator.hasNext()){
            subCycle = (SubCycle)iterator.next();
            if(subCycle.getState()!= null && subCycle.getState().equals(SoxicConstants.CERTIFICATION_STATE)){
                //certification = true;
                isActivityCertification=true;
            }

        }
        return true;
    }

    public void cycleTab()throws DatabaseException, Exception {
    	initalizePeriod();
        getAllCycles("OWNER");
        //getAllSubCycles();
        //setActivitySubCycleAssociation();
          
    }



    public void subCycleTab()throws DatabaseException, Exception {
    	initalizePeriod();
    	getAllSubCycles("OWNER");
        //getAllSubCycles();
        //setActivitySubCycleAssociation();
          
    }    
    
    /**
     * @return Returns the ownerId.
     */
    public String getOwnerId() {
        return ownerId; 
    }
    /**
     * @param ownerId The ownerId to set.
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
   
    /**
     * @return Returns the subCycles.
     */
    public List getSubCycles(String cycleId) {
        return (List)cycleSubCycleAssociation.get(cycleId);
    }
    
    /**
	 * find SubCycles by search criteria.
	 * calls getSubCycleQueryMap to get the query criteria.
	 * @throws DatabaseException throws DatabaseException
	 * @throws Exception throws an generic exception if any 
	 */
    
    
    protected void getAllSubCycles(String queryType) throws DatabaseException, Exception {
        
        if(subCycles == null || queryType.equalsIgnoreCase("OWNER")){
            try {
                DAO subCycleDAO = AbstractDAOFactory.getFactory().getSubCycleDAO();
                subCycles = (List) subCycleDAO.retrieveByCriteria(getQuery(queryType));
                generateCycleSubCycleAssociation(subCycles);
            } catch (DatabaseException e) {
                e.printStackTrace();
                throw new DatabaseException("Unable to get the Sub-Cycles Data from DB "+ e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            } 
        }
        
    }
      
    public void updateSubCycleQuestions(String operation) throws DatabaseException, Exception{
        
        if(subCycles != null ){
            try {
                DAO subCycleDAO = AbstractDAOFactory.getFactory().getSubCycleDAO();
               
                updateSubCycleStatus(operation);
                subCycleDAO.update(subCycles);
            } catch (DatabaseException e) {
                e.printStackTrace();
                throw new DatabaseException("Unable to update the owner data "+ e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            } 
        }
    }
    
    public void generateCycleSubCycleAssociation(List subCycles){
        cycleSubCycleAssociation = new HashMap();
        
        Iterator itr = subCycles.iterator();
        
        while(itr.hasNext()){
            
            SubCycle subCycle = (SubCycle)itr.next();
            String cycleId = subCycle.getCycleId();
            
            if(cycleSubCycleAssociation.containsKey(cycleId)){
               ((List)cycleSubCycleAssociation.get(cycleId)).add(subCycle);
            }
            else{
                List newSubCycles  = new ArrayList();
                newSubCycles.add(subCycle);
                cycleSubCycleAssociation.put(cycleId, newSubCycles);
            }
        }
                       
    }
    /**
     * @return Returns the subCycleCycleIds.
     */
    public LinkedHashSet getSubCycleCycleIds() {
        
        return new LinkedHashSet(cycleSubCycleAssociation.keySet());
        
    }
    
    
    
    protected void getAllCycles(String queryType) throws DatabaseException , Exception {
        
        if(cycles == null || queryType.equalsIgnoreCase("OWNER")){
            try{
                DAO cycleDAO = AbstractDAOFactory.getFactory().getCycleDAO();
                cycles = (List) cycleDAO.retrieveByCriteria(getQuery(queryType));
                generatePeriodCycleAssociation(cycles);
            } catch(DatabaseException e){
                e.printStackTrace();
                throw new DatabaseException("Unable to get the Cycle data from DB "+ e.getMessage());
            } catch(Exception e){
                e.printStackTrace();
                throw e;
            }
                 
        }
    }
    
//    private Map getQuery(){
//        Map criteria = new HashMap();
//        criteria.put("QUERY_TYPE", "OWNER");
//        criteria.put(Owner.OWNER_ID, ownerId);
//       
//        return criteria;
//    }
    
  private Map getQuery(String queryType) {
		Map criteria = new HashMap();
		criteria.put("QUERY_TYPE", queryType);
		criteria.put(Owner.OWNER_ID, ownerId);

		return criteria;
	}
    
    
    public void updateCycleQuestions(String operation) throws DatabaseException, Exception{
        
        if(cycles != null ){
            try {
                DAO cycleDAO = AbstractDAOFactory.getFactory().getCycleDAO();
                updateCycleStatus(operation);
                cycleDAO.update(cycles);
            } catch (DatabaseException e) {
                e.printStackTrace();
                throw new DatabaseException("Unable to update the Cycle Question/Answers "+ e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            } 
        }
    }
    
    /**
     * @return Returns the cycles.
     */
    public List getCycles(String period) {
        return (List)periodCycleAssociation.get(period);
    }
    
    
    public void generatePeriodCycleAssociation(List cycles){
        periodCycleAssociation = new HashMap();
        
        Iterator itr = cycles.iterator();
        
        while(itr.hasNext()){
            
            Cycle cycle = (Cycle)itr.next();
            String period = cycle.getPeriodId();
            
            if(periodCycleAssociation.containsKey(period)){
               ((List)periodCycleAssociation.get(period)).add(cycle);
            }
            else{
                List newCycles  = new ArrayList();
                newCycles.add(cycle);
                periodCycleAssociation.put(period, newCycles);
                
            }
        }
                       
    }
    /**
     * @return Returns the subCycleCycleIds.
     */
    public LinkedHashSet getPeriodCycleIds() {
              
        return new LinkedHashSet(periodCycleAssociation.keySet());
        
    } 
   
	/**
	 * @return Returns the activitySubCycleAssociation.
	 */
	public List getActivitySubCycleAssociation() {
		return activitySubCycleAssociation;
	}
	
	/**
	 *
	 */
	public void setActivitySubCycleAssociation() throws Exception {
		this.activitySubCycleAssociation = SubCycleDAO.getSubCycles(ownerId);
	}
	
	/**
	 * @return Returns the subCycles for this owner.
	 */
	public List getSubCycles() {
		return subCycles;
	}
	/**
	 * @return Returns the cycles.
	 */
	public List getCycles() {
		return cycles;
	}
	
	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return Returns the lastLogin.
	 */
	public String getLastLogin() {
		return lastLogin;
	}
	/**
	 * @param lastLogin The lastLogin to set.
	 */
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return Returns the role.
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role The role to set.
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	protected void initalizeOwnerDetails(){
		try{
			OwnerDAO ownerDAO = new OwnerDAO();
			Owner owner = ownerDAO.getOwnerDetails(ownerId);
			setEmail(owner.getEmail());
			setName(owner.getName());
			setLastLogin(owner.getLastLogin());
			setRole(owner.getRole());
			setAdmin(owner.isAdmin());
            setIA(owner.isIA());
            setIAUser(owner.isIAUser());
			setViewReports(owner.isViewReports());
			ownerDAO.updateOwner(ownerId);
//			setNewsList(ownerDAO.getNewsItems(ownerId));
            setNewsList(ownerDAO.getNewsItems());
            if(owner.isAdmin()){
                setIA(true);
            }

		}catch(Exception e){
			
		}
	}
	
	/**
	 * This method initializes upper level details to be displayed on the contact us page.
	 * for the activity owners display the sub-cycle owners and cycle owners
	 * for the sub-cycle owners display the cycle owners.
	 * @throws Exception
	 */
	protected void initializeUpperLevelDetails()throws Exception{
		Iterator iterator=null;
		UtilDAO utilDAO = new UtilDAO();
    	if(getActivitySubCycleAssociation()!=null && getActivitySubCycleAssociation().size()>0){
    		iterator = getActivitySubCycleAssociation().iterator();
    		while(iterator.hasNext()){
    			SubCycle subCycle =(SubCycle)iterator.next();
    			addToUpperOwnerList(utilDAO.getLevelOwnerWrapperList(SoxicConstants.SUBCYCLE,subCycle.getSubCycleId()));
    		}
    	}
    	if(getSubCycles()!=null && getSubCycles().size()>0){
    		iterator = getSubCycles().iterator();
    		while(iterator.hasNext()){
    			SubCycle subCycle =(SubCycle)iterator.next();
    			StringTokenizer tempSt = new StringTokenizer(subCycle.getCycleId()," ");
    			addToUpperOwnerList(utilDAO.getLevelOwnerWrapperList(SoxicConstants.CYCLE,tempSt.nextToken()));
    		}
    	}
		//utilDAO.getUpperLevelOwnerWrapperList();
	}
	
	protected void initalizePeriod(){
		UtilDAO utilDAO = new UtilDAO();
		try{
			setPeriodId(utilDAO.getPeriod());
		}catch(Exception e){
			
		}
	}
	/**
	 * @return Returns the periodId.
	 */
	public String getPeriodId() {
		return periodId;
	}
	/**
	 * @param periodId The periodId to set.
	 */
	public void setPeriodId(String periodId) {
		this.periodId = periodId;
	}
	
	private void updateSubCycleStatus(String operation){
		
		Iterator subCycleIterator = subCycles.iterator();
		
		while(subCycleIterator.hasNext()){
			SubCycle subCycle = (SubCycle)subCycleIterator.next();
			Iterator questionIterator = subCycle.getQuestions().iterator();
			while(questionIterator.hasNext()){
				QuestionNew questionNew = (QuestionNew)questionIterator.next();
				setQuestionStatus(operation,questionNew,subCycle.getDueDate());
			}
			
		}
	}
	
	private void updateCycleStatus(String operation){
		
		Iterator cycleIterator = cycles.iterator();
		
		while(cycleIterator.hasNext()){
			Cycle cycle = (Cycle)cycleIterator.next();
			Iterator questionIterator = cycle.getQuestions().iterator();
			while(questionIterator.hasNext()){
				QuestionNew questionNew = (QuestionNew)questionIterator.next();
				setQuestionStatus(operation,questionNew,cycle.getDueDate());
			}
			
		}
	}
	
	private void setQuestionStatus(String operation,QuestionNew questionNew,String dueDate){
		if(dueDate!=null && dueDate.length()>0){
			if(operation.equalsIgnoreCase(SoxicConstants.SAVEOPERATION)){
				if(questionNew.getAnswer()!=null){
					questionNew.setStatus(SoxicUtil.returnStatusPreceedingStr(dueDate)+SoxicConstants.INPROCSTR);
				}
			}
			if(operation.equalsIgnoreCase(SoxicConstants.SUBMITOPERATION)){
				if(questionNew.getAnswer()!=null && questionNew.getAnswer().equalsIgnoreCase(SoxicConstants.NORESPONSE)){
					questionNew.setStatus(SoxicUtil.returnStatusPreceedingStr(dueDate)+SoxicConstants.INPROCSTR);
				}
				if(questionNew.getAnswer()!=null && questionNew.getAnswer().equalsIgnoreCase(SoxicConstants.YESRESPONSE)){
					questionNew.setStatus(SoxicConstants.GREEN_COMPLETE);
				}
			}		
		}
	}
	
	/**
	 * @param isAdmin The isAdmin to set.
	 */
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	
	/**
	 * @return Returns the isAdmin.
	 */
	public boolean isAdmin() {
		return isAdmin;
	}
	
	
	/**
	 * @return Returns the viewReports.
	 */
	public boolean isViewReports() {
		return viewReports;
	}
	/**
	 * @param viewReports The viewReports to set.
	 */
	public void setViewReports(boolean viewReports) {
		this.viewReports = viewReports;
	}

    public boolean isDocChange() {
        return docChange;
    }

    public void setDocChange(boolean docChange) {
        this.docChange = docChange;
    }


	/**
	 * @return Returns the newsList.
	 */
	public List getNewsList() {
		return newsList;
	}
	/**
	 * @param newsList The newsList to set.
	 */
	public void setNewsList(List newsList) {
		this.newsList = newsList;
	}
	
	
	/**
	 * @return Returns the upperOwnerList.
	 */
	public Collection getUpperOwnerList() {
		return upperOwnerList.values();
	}
	/**
	 * @param upperOwnerList The upperOwnerList to set.
	 */
	public void setUpperOwnerList(Map upperOwnerList) {
		this.upperOwnerList = upperOwnerList;
	}
	
	public void addToUpperOwnerList(List ownerWrapperList){
		
		Iterator iterator = ownerWrapperList.iterator();
		
		while(iterator.hasNext()){
			
			OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
			
			if(upperOwnerList==null){
				upperOwnerList = new HashMap();
			}
			upperOwnerList.put(ownerWrapper.getOwnerid(),ownerWrapper);
		}
		
	}
	
	/**
	 * @return Returns the location.
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location The location to set.
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	
	/**
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public static Owner getNewOwner(String user) throws Exception{
		Owner owner = new Owner();
    	//PeopleService svc = new PeopleService();
    	///PersonInfo[] p = svc.GetPeople("", "", "", "", user, "", "");
		PersonInfo personInfo = returnPeople(user);
    	if(personInfo==null || personInfo==null){
    		throw new InvalidUserException();
    	}
    	owner.setOwnerId(user);
    	owner.setName(personInfo.getFirstName()+" "+personInfo.getLastName());
    	owner.setEmail(personInfo.getEmail()+"@monsanto.com");
    	owner.setLocation(personInfo.getSite());
		return owner;
	}

        public static PersonInfo returnPeople(String userid)throws Exception{

   		PeopleService svc = new PeopleService();
    	PersonInfo[] person = svc.GetPeople("", "", "", "", userid, "", "");

    	if(person==null){
    		throw new InvalidUserException();
    	}

    	for(int i=0;i<person.length;i++){
    		PersonInfo personInfo = person[i];
    		if(personInfo.getUserId().equalsIgnoreCase(userid)){
    			return personInfo;
    		}
    	}
    	return null;

    }

    public String getDocChangeLevel() {
        return docChangeLevel;
    }

    public void setDocChangeLevel(String docChangeLevel) {
        this.docChangeLevel = docChangeLevel;
    }

    public boolean isCertification() {
        return certification;
    }

    public void setCertification(boolean certification) {
        this.certification = certification;
    }

    public boolean isIA() {
        return isIA;
    }

    public void setIA(boolean IA) {
        isIA = IA;
    }

    public boolean isActivityCertification() {
        return isActivityCertification;
    }

    public void setActivityCertification(boolean activityCertification) {
        isActivityCertification = activityCertification;
    }

    protected void setDocumentChangeIfIa(){
        PeriodDAO periodDAO = new PeriodDAO();

       if(isIA() && periodDAO.isAnyPeriodInDocumnetChange()){
           setDocChange(true);
       }
    }

    protected void setDocumentChangeIfIaUser(){
        PeriodDAO periodDAO = new PeriodDAO();
       if(isIAUser() && periodDAO.isAnyPeriodInDocumnetChange()){
           setDocChange(true);
       }
    }

    public boolean isIAUser() {
        return isIAUser;
    }

    public void setIAUser(boolean IAUser) {
        isIAUser = IAUser;
    }

    public boolean isDocChangeCertification() {
        return isDocChangeCertification;
    }

    public void setDocChangeCertification(boolean docChangeCertification) {
        isDocChangeCertification = docChangeCertification;
    }

    public String getId(){
        return ownerId;
    }

    public boolean isDocumentChangeTab() {
        return documentChangeTab;
    }

    public void setDocumentChangeTab(boolean documentChangeTab) {
        this.documentChangeTab = documentChangeTab;
    }

    /**
     * if IA or Admin set the doc change tab to true
     * for activity owners or sub cycle owner or IA users if doc change is avalible set doc change tab to true
     */
    public void setDocumentChangeTab(){
        if(isIA() || isAdmin()){
            documentChangeTab = true;
        }
        if(docChange){
            documentChangeTab = true;
        }
    }

    public List getDocChangeSubCycles() {
        return docChangeSubCycles;
    }

    public boolean isShowMaintainenceForCycleOrSubCycle() {
        return showMaintainenceForCycleOrSubCycle;
    }

    public void setShowMaintainenceForCycleOrSubCycle(boolean showMaintainenceForCycleOrSubCycle) {
        this.showMaintainenceForCycleOrSubCycle = showMaintainenceForCycleOrSubCycle;
    }

    public void setDocChangeSubCycles(List docChangeSubCycles) {
        this.docChangeSubCycles = docChangeSubCycles;
    }
}
