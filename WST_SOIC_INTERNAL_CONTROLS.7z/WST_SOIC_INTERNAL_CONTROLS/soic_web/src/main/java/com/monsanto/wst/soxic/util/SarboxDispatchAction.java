/*
 * Created on Apr 7, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.util;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SarboxDispatchAction extends DispatchAction {
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String method  = getMethod(request.getParameterMap());
		return dispatchMethod(mapping,form,request,response,method);
	}
	
	private String getMethod(Map parMap){
		Iterator iterator = parMap.values().iterator();
		Iterator iter = parMap.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			if(key.toString().equalsIgnoreCase("method")){
				return key.toString();
			}
		}
		return "";
	}

}
