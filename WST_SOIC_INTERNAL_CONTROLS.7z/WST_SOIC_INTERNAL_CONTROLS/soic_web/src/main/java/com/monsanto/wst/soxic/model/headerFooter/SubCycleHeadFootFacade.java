package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.model.HeaderFooterDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 11:40:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class SubCycleHeadFootFacade extends HeaderFooterFacade{

    public String getHeader() {
        return HeaderFooterDAO.getMessage(SoxicConstants.SUBCYCLE_QUESTION_HEADER,SoxicConstants.QUESTION_HEADER);
    }

    public String getFooter() {
        return HeaderFooterDAO.getMessage(SoxicConstants.SUBCYCLE_QUESTION_FOOTER,SoxicConstants.QUESTION_FOOTER);
    }
}
