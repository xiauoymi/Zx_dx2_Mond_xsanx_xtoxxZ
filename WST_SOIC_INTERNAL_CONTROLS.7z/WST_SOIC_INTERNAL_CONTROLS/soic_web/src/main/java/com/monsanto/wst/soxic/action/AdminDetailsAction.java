/*
 * Created on Mar 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.*;
import org.apache.struts.actions.LookupDispatchAction;
import org.apache.struts.actions.DispatchAction;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.InvalidActivityException;
import com.monsanto.wst.soxic.exception.IncorrectDateException;
import com.monsanto.wst.soxic.exception.InvalidCertificationStateException;
import com.monsanto.wst.soxic.form.AdminDetailsForm;
import com.monsanto.wst.soxic.model.AdminDetails;
import com.monsanto.wst.soxic.model.ItemDetails;
import com.monsanto.wst.soxic.persistance.OracleAdminDetailsDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 * @author rgeorge
 * 
 * This action class determines whether the Administrator wants to delete
 * or modify activities. If the administrator wants to publish cycles to
 * CERTIFICATION, a check is made to ensure that the cycle is already in
 * PRE_CERTIFICATION state, else InvalidCertificationStateException is thrown.
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminDetailsAction extends Action{
    
    /* (non-Javadoc)
     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
     */
//    protected Map getKeyMethodMap() {
//        Map map = new HashMap();
//        map.put("button.update",    "updateDetails");
//        map.put("button.cancel",    "cancel");
//
//        return map;
//    }

    public ActionForward execute(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException, Exception{

        AdminDetailsForm adminDetailsForm  = (AdminDetailsForm)form;
        String docaction = request.getParameter("method");
        ActionMessages messages = new ActionMessages();

        if (docaction.equalsIgnoreCase("CHANGE")){
            adminDetailsForm.setSelectedOperation("Change");

            if(adminDetailsForm.getSelectedOperation().equalsIgnoreCase("Change")){

		        try {
		            AdminDetails.update(getItemDetailsFromTheForm(adminDetailsForm));
                } catch (Exception e) {
                    if(e instanceof InvalidCertificationStateException ){
                            adminDetailsForm.setStartDate(null);
                            adminDetailsForm.setDueDate(null);
                            throw new InvalidCertificationStateException();
                    }
		        }
            }

           //return mapping.findForward("success");
        }

        else

        if (docaction.equalsIgnoreCase("Remove")){
           try{

                String cycleid = adminDetailsForm.getSelectedCycle();
                String subcycleid = adminDetailsForm.getSelectedSubCycle();
                String controlobjid = adminDetailsForm.getSelectedControlObjective();
                String activityid = adminDetailsForm.getSelectedActivity();

                OracleAdminDetailsDAO.deleteactivity(cycleid,subcycleid,controlobjid,activityid);
                setAdminDetailsFormnull(adminDetailsForm);

           }catch (Exception e) {
                if(e instanceof InvalidActivityException ){
                            throw new InvalidActivityException();
                }
           }
       }

        return mapping.findForward("success");
    }

    private void setAdminDetailsFormnull(AdminDetailsForm adminDetailsForm) {
        adminDetailsForm.setSelectedCycle(null);
        adminDetailsForm.setSelectedControlObjective(null);
        adminDetailsForm.setSelectedSubCycle(null);
        adminDetailsForm.setSelectedActivity(null);
        adminDetailsForm.setName(null);
        adminDetailsForm.setDescription(null);
        adminDetailsForm.setCodestring(null);
        adminDetailsForm.setStartDate(null);
        adminDetailsForm.setDueDate(null);
    }


    private ItemDetails getItemDetailsFromTheForm(AdminDetailsForm form){
        
        ItemDetails details = new ItemDetails();
        
        details.setId(form.getName());
        details.setDescription(form.getDescription());
        details.setApplyToAllChildren(form.isApplyToAllChildren());
        details.setType(form.getChange());
        
        details.setStartDate(form.getStartDate());
        details.setDueDate(form.getDueDate());
        details.setCodestring(form.getCodestring());

        return details;
    }    


}
