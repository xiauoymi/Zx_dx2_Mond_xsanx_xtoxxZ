package com.monsanto.wst.soxic.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.persistance.AbstractDAOFactory;
import com.monsanto.wst.soxic.persistance.DeleteNewPeriodDAO;
import com.monsanto.wst.soxic.facade.NewPeriodFacade;
import com.monsanto.wst.soxic.facade.PeriodFacade;
import com.monsanto.wst.soxic.form.NewPeriodForm;
import com.monsanto.wst.soxic.exception.PeriodAlreadyExistsException;
import com.monsanto.wst.soxic.exception.NewPeriodCreationException;

import java.util.Map;
import java.util.HashMap;


/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 14, 2005
 * Time: 3:33:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateNewPeriodAction extends Action{
    public ActionForward execute(ActionMapping mapping,
			 ActionForm form,
			 HttpServletRequest request,
			 HttpServletResponse response) throws Exception{

        PeriodFacade periodFacade = new PeriodFacade();
        NewPeriodForm newPeriodForm = (NewPeriodForm)form;
        NewPeriodFacade newPeriodFacade = new NewPeriodFacade();
        try{
            newPeriodFacade.createNewPeriod(newPeriodForm.getSourcePeriod(),newPeriodForm.getTargetPeriod(),newPeriodForm.getTargetPeriod(),newPeriodForm.getDescription(),newPeriodForm.isCycleOnlyPeriod());

            periodFacade.getPeriod(newPeriodForm);

            request.setAttribute("PERIOD_CREATION_SUCCESS","TRUE");
        }catch(Exception e){
             if(e instanceof PeriodAlreadyExistsException){
                 periodFacade.getPeriod(newPeriodForm);
                 throw new PeriodAlreadyExistsException();
             }
            if(e instanceof NewPeriodCreationException){
                 periodFacade.getPeriod(newPeriodForm);
                 DeleteNewPeriodDAO deleteNewPeriodDAO = new DeleteNewPeriodDAO();
                 deleteNewPeriodDAO.delete(newPeriodForm.getTargetPeriod());
                 throw new NewPeriodCreationException();

             }
        }
        return mapping.findForward("success");
    }

}
