package com.monsanto.wst.soxic.util;

import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 1, 2006
 * Time: 11:17:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class MiscUtils {

        public static String getTokenizedPeriod(String fullId) {
        if (fullId!="" || fullId.length()!=0){
            StringTokenizer st = new StringTokenizer(fullId,".");
            return st.nextToken();
        }
        else return "";
    }

}
