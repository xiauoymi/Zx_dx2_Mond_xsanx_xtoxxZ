package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.NewPeriodForm;
import com.monsanto.wst.soxic.model.PeriodDAO;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 18, 2005
 * Time: 1:40:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeriodFacade {

    public void getPeriod(NewPeriodForm newPeriodForm)throws Exception{
        
        PeriodDAO periodDAO = new PeriodDAO();

        newPeriodForm.setNewPeriodList(periodDAO.getPeriods());
    }
}
