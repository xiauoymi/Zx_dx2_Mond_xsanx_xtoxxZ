/*
 * Created on Mar 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.OwnerCopyChangeForm;
import com.monsanto.wst.soxic.model.AdminOwner;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerCopyChangeDataAction extends Action {
    
    public ActionForward execute(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
            
            OwnerCopyChangeForm changeOwnerForm = (OwnerCopyChangeForm) form;
            
            try {
                setData(changeOwnerForm);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return mapping.findForward("success");
    }
    
    private void setData(OwnerCopyChangeForm form) throws DatabaseException, Exception{
        
        // check for the values existing user, new user and throw an error accordingly.
        AdminOwner adminOwner = new AdminOwner();
        
        List cycles = adminOwner.getCycles(form.getExistingUser(), form.getNewUser());
        form.setCycles((String[]) cycles.toArray(new String[0]));
        
        List subCycles = adminOwner.getSubCycles(form.getExistingUser(), form.getNewUser());
        form.setSubCycles((String[]) subCycles.toArray(new String[0]));
        
        List activities = adminOwner.getActivities(form.getExistingUser(), form.getNewUser());
        form.setActivities((String[]) activities.toArray(new String[0]));
        
    }
    
}
