package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.persistance.DashBoardHomeDAO;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 1, 2006
 * Time: 2:27:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class DashBoardHomeFacade {

    DashBoardHomeDAO dashBoardHomeDAO = new DashBoardHomeDAO();


    public boolean checkIfUserIsOwnerInSystem(String ownerId) {
        boolean status = true;
        List typeList = new ArrayList();
        typeList = getCyclesForOwner(typeList,ownerId);
        typeList = getSubcyclesForOwner(typeList,ownerId);
        typeList = getActivitiesForOwner(typeList,ownerId);
        status = setFalseStatusForNoOwner(typeList, status);
        return status;
    }

    private boolean setFalseStatusForNoOwner(List typeList, boolean status) {
        if (typeList.size()==0){
            status = false;
        }
        return status;
    }

    public List getCyclesForOwner(List typeList, String ownerId) {
        return dashBoardHomeDAO.getCycleListForOwner(typeList,ownerId);
    }

    public List getSubcyclesForOwner(List typeList, String ownerId) {
        return dashBoardHomeDAO.getSubCycleListForOwner(typeList,ownerId);
    }

    public List getActivitiesForOwner(List typeList, String ownerId) {
        return dashBoardHomeDAO.getActivityListForOwner(typeList,ownerId);
    }

    public List getActivityDetailsForOwner(String ownerId) {
        return dashBoardHomeDAO.getActivityAndStatus(ownerId);
    }

    public List getSubCycleDetailsForOwner(String ownerId) {
        return dashBoardHomeDAO.getSubcycleAndStatus(ownerId);
    }

    public List getCycleDetailsForOwner(String ownerId) {
        return dashBoardHomeDAO.getCycleAndStatus(ownerId);
    }

    
}
