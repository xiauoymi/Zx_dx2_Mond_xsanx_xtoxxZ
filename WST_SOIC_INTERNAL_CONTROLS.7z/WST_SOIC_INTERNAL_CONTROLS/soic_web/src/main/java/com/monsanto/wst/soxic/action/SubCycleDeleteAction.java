package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 20, 2005
 * Time: 11:37:10 AM
 * 
 * This class sets the initial screen for the Subcycle Maintenance page.
 * The first method selects the countries, the second selects the first
 * cycle for that country and the 3rd selects the subcycles corresponding
 * to the first cycle.
 *
 */
public class SubCycleDeleteAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        SubCycleDeleteForm subcycledeleteform = (SubCycleDeleteForm)form;
        UtilDAO utildao = new UtilDAO();
        SubCycleMaintainFacade subCycleMaintainFacade = new SubCycleMaintainFacade();

        subCycleMaintainFacade.countrySelection(subcycledeleteform);

        subCycleMaintainFacade.initialCycleSelection(subcycledeleteform);

        subCycleMaintainFacade.initialSubcylesSelection(subcycledeleteform);

        return mapping.findForward("countrylist");
    }
}
