/*
 * Created on Mar 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GapNew {
	
	private String identifier;
	
	private String level;
	
	private List gapOwnerList = new ArrayList();
	
	

	/**
	 * @return Returns the gapOwnerList.
	 */
	public List getGapOwnerList() {
		return gapOwnerList;
	}
	/**
	 * @param gapOwnerList The gapOwnerList to set.
	 */
	public void setGapOwnerList(List gapOwnerList) {
		this.gapOwnerList = gapOwnerList;
	}
	/**
	 * @return Returns the identifier.
	 */
	public String getIdentifier() {
		return identifier;
	}
	/**
	 * @param identifier The identifier to set.
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	/**
	 * @return Returns the level.
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level The level to set.
	 */
	public void setLevel(String level) {
		this.level = level;
	}
}
