/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DelinquentFacade {
	
	public List getDelinquents(String periodId)throws Exception{
		
		List overAllList = new ArrayList();
		
		Iterator activityDelinquents = getDelinquents(SoxicConstants.ACTIVITY,"Sub-Cycle", periodId).iterator();
		
		while(activityDelinquents.hasNext()){
			overAllList.add((DelinquentList)activityDelinquents.next());
		}
		
		Iterator subCycleDelinquents = getDelinquents(SoxicConstants.SUBCYCLE,"Cycle", periodId).iterator();
		
		while(subCycleDelinquents.hasNext()){
			overAllList.add((DelinquentList)subCycleDelinquents.next());
		}
		
		Iterator cycleDelinquents = getDelinquents(SoxicConstants.CYCLE,"", periodId).iterator();
		
		while(cycleDelinquents.hasNext()){
			overAllList.add((DelinquentList)cycleDelinquents.next());
		}
		
		
		return overAllList;
	}
	
	
	private List getDelinquents(String level, String displayString, String currentPeriod)throws Exception{
		
		DelinquentDAO delinquentDAO = new DelinquentDAO();
		
		List activityDelinquentList = delinquentDAO.getDelinquents(level, currentPeriod);
		
		List overAllList = new ArrayList();
		
		DelinquentList delinquentList = new DelinquentList();
		
		delinquentList.setText(displayString);
		
		Iterator iterator = activityDelinquentList.iterator();
		
		String currentSubCycleId=null;
		while(iterator.hasNext()){
			
			UserDelinquents delinquents = (UserDelinquents)iterator.next();
			
			if(currentSubCycleId==null){
				currentSubCycleId = delinquents.getUpperIdentifier();
				delinquentList.setIdentifier(delinquents.getUpperIdentifier());
			}
			
			if(!currentSubCycleId.equalsIgnoreCase(delinquents.getUpperIdentifier())){
				currentSubCycleId = delinquents.getUpperIdentifier();
				overAllList.add(delinquentList);
				delinquentList = new DelinquentList();
				delinquentList.setText(displayString);
				delinquentList.setIdentifier(delinquents.getUpperIdentifier());
			}
			delinquentList.addDelinquent(delinquents);
		}
		
		//return activityDelinquentList;
		overAllList.add(delinquentList);
		return overAllList;
		
	}
}
