package com.monsanto.wst.soxic.facade.reports;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerStatusCountryDAO;
import com.monsanto.wst.soxic.model.OwnerStatusReportDAO;
import com.monsanto.wst.soxic.model.OwnerStatusSubCycleDAO;
import com.monsanto.wst.soxic.model.OwnerStatusCycleDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 20, 2005
 * Time: 12:07:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusReportFacade {

    OwnerStatusReportDAO ownerStatusReportDAO = new OwnerStatusReportDAO();
    OwnerStatusCountryDAO ownerStatusCountryDAO = new OwnerStatusCountryDAO();
    OwnerStatusCycleDAO ownerStatusCycleDAO = new OwnerStatusCycleDAO();
    OwnerStatusSubCycleDAO ownerStatusSubCycleDAO = new OwnerStatusSubCycleDAO();

    public void buildSelectionCriteria(UCCHelper helper) throws IOException, DatabaseException {
        String reportType = helper.getRequestParameterValue("type");
        destroySessionVariables(helper);
        if (reportType.equalsIgnoreCase(SoxicConstants.OWNER_STATUS_REPORT_COUNTRY)){
            setCountryReportOptions(helper);
        }
        if (reportType.equalsIgnoreCase(SoxicConstants.OWNER_STATUS_REPORT_CYCLE)){
            setCycleReportOptions(helper);
        }
        if (reportType.equalsIgnoreCase(SoxicConstants.OWNER_STATUS_REPORT_SUB_CYCLE)){
            setSubCycleReportOptions(helper);
        }
    }

    private void setSubCycleReportOptions(UCCHelper helper) throws DatabaseException, IOException {
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        String firstPeriod = (String) periods.get(0);
        String firstCountry = (String) countries.get(0);
        List cycles = getAllCyclesForCountryAndPeriod(firstPeriod,firstCountry);
        String firstCycle = (String) cycles.get(0);
        List subcycles = getAllSubCyclesForCycle(firstCycle);
        setPeriodAndCountryInSession(helper,periods,countries);
        helper.setSessionParameter("statusCycles",cycles);
        forwardForSubCycles(helper, subcycles);
    }

    private void forwardForSubCycles(UCCHelper helper, List subcycles) throws IOException {
        helper.setSessionParameter("statusSubCycles",subcycles);
        helper.forward("jsp/ownerStatusSubCycleReport.jsp");
    }

    protected List getAllSubCyclesForCycle(String firstCycle) throws DatabaseException {
        return ownerStatusCycleDAO.getSubCycles(firstCycle);
    }

    private void destroySessionVariables(UCCHelper helper) {
        setPeriodAndCountryInSession(helper, null, null);
        helper.setSessionParameter("statusCycles",null);
        helper.setSessionParameter("statusSubCycles",null);
        setSelectedPeriodAndCountryInSession(helper, null, null);
    }

    private void setCountryReportOptions(UCCHelper helper) throws DatabaseException, IOException {
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        setPeriodAndCountryInSession(helper, periods, countries);
        helper.forward("jsp/ownerStatusCountryReport.jsp");
    }

    private void setCycleReportOptions(UCCHelper helper) throws DatabaseException, IOException {
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        String firstPeriod = (String) periods.get(0);
        String firstCountry = (String) countries.get(0);
        List cycles = getAllCyclesForCountryAndPeriod(firstPeriod,firstCountry);
        forwardOwnerCycleReportInfo(helper, periods, countries, cycles);
    }

    private void forwardOwnerCycleReportInfo(UCCHelper helper, List periods, List countries, List cycles) throws IOException {
        setPeriodAndCountryInSession(helper, periods, countries);
        helper.setSessionParameter("statusCycles",cycles);
        helper.forward("jsp/ownerStatusCycleReport.jsp");
    }

    private void setPeriodAndCountryInSession(UCCHelper helper, List periods, List countries) {
        helper.setSessionParameter("statusPeriods",periods);
        helper.setSessionParameter("statusCountries",countries);
    }

    protected List getAllCyclesForCountryAndPeriod(String firstPeriod, String firstCountry) throws DatabaseException {
        return ownerStatusCountryDAO.getCyclesForSelection(firstPeriod,firstCountry);
    }

    protected List getAllCountriesInCycleTable() throws DatabaseException {
        return ownerStatusReportDAO.getCountriesForCycle();
    }

    public List getAllPeriodsInSystem() throws DatabaseException {
        return ownerStatusReportDAO.getPeriods();
    }


    public void buildCycleListOnSelection(UCCHelper helper) throws IOException, DatabaseException {
        String period = helper.getRequestParameterValue("p");
        String country = helper.getRequestParameterValue("cid");
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        List cycles = getAllCyclesForCountryAndPeriod(period,country);
        setSelectedPeriodAndCountryInSession(helper, period, country);
        forwardOwnerCycleReportInfo(helper, periods, countries, cycles);
    }

    private void setSelectedPeriodAndCountryInSession(UCCHelper helper, String period, String country) {
        helper.setSessionParameter("selectedPeriod",period);
        helper.setSessionParameter("selectedCountry",country);
    }

    public void buildSubCycleListOnSelection(UCCHelper helper) throws DatabaseException, IOException {
        String period = helper.getRequestParameterValue("p");
        String country = helper.getRequestParameterValue("cid");
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        List cycles = getAllCyclesForCountryAndPeriod(period,country);
        String cycle = (String) cycles.get(0);
        List subcycles = getAllSubCyclesForCycle(cycle);
        setParamsForSubCyclePage(helper, periods, countries, cycles, period, country, cycle, subcycles);
    }

    private void setParamsForSubCyclePage(UCCHelper helper, List periods, List countries, List cycles, String period, String country, String cycle, List subcycles) throws IOException {
        setPeriodAndCountryInSession(helper,periods,countries);
        helper.setSessionParameter("statusCycles",cycles);
        setSelectedPeriodAndCountryInSession(helper,period,country);
        helper.setSessionParameter("selectedCycle",cycle);
        forwardForSubCycles(helper,subcycles);
    }

    public void buildSubCyclesBasedOnCycle(UCCHelper helper) throws IOException, DatabaseException {
        String period = helper.getRequestParameterValue("p");
        String country = helper.getRequestParameterValue("cid");
        String cycle = helper.getRequestParameterValue("c");
        List periods = getAllPeriodsInSystem();
        List countries = getAllCountriesInCycleTable();
        List cycles = getAllCyclesForCountryAndPeriod(period,country);
        List subcycles = getAllSubCyclesForCycle(cycle);
        setParamsForSubCyclePage(helper,periods,countries,cycles,period,country,cycle,subcycles);
    }
}
