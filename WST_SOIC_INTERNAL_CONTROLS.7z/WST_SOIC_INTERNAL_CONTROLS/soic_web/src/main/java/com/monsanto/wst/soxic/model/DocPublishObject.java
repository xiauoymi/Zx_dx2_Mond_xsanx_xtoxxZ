package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 26, 2005
 * Time: 11:26:48 AM
 * To change this template use File | Settings | File Templates.
 */

public class DocPublishObject {

    private String activity_id;
    private String req_type;
    private boolean approved;
    private String cobj_id;
    private String doc_text;
    private String approvedStr;
    private String priority;
    private int overflow;

    public String getActivity_id() {
        return activity_id;
    }

    public void setActivity_id(String activity_id) {
        this.activity_id = activity_id;
    }

    public String getReq_type() {
        return req_type;
    }

    public void setReq_type(String req_type) {
        this.req_type = req_type;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public String getCobj_id() {
        return cobj_id;
    }

    public void setCobj_id(String cobj_id) {
        this.cobj_id = cobj_id;
    }

    public String getDoc_text() {
        return doc_text;
    }

    public void setDoc_text(String doc_text) {
        this.doc_text = doc_text;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public int getOverflow_id() {
       return this.overflow;
    }

    public void setOverflow_Id (int overflow){
        this.overflow = overflow;
    }
}
