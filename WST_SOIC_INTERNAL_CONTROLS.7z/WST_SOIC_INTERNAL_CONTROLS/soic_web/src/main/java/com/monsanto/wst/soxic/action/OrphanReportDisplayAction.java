package com.monsanto.wst.soxic.action;

import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.monsanto.wst.soxic.form.OrphanReportForm;
import com.monsanto.wst.soxic.facade.reports.OrphanReportFacade;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 9, 2006
 * Time: 1:15:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrphanReportDisplayAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws IOException, Exception {

        OrphanReportForm orphanReportForm = (OrphanReportForm)form;
        OrphanReportFacade orphanReportFacade = new OrphanReportFacade();
        ActionMessages messages = new ActionMessages();

        List unAssignedCycles = orphanReportFacade.getCyclesNotAssigned(orphanReportForm.getSelperiod());
        List unAssignedSubCycles = orphanReportFacade.getSubCyclesNotAssigned(orphanReportForm.getSelperiod());
        List unAssignedActivity = orphanReportFacade.getActivitiesNotAssigned(orphanReportForm.getSelperiod());

        if (unAssignedCycles.size()==0 && unAssignedSubCycles.size()==0 && unAssignedActivity.size()==0){
            allAssignedInSystem(messages, request);
        }
        else{
            setListsIntoForm(orphanReportForm, unAssignedCycles, unAssignedSubCycles, unAssignedActivity);
        }

        return mapping.findForward("displayOrphans");
    }

    private void setListsIntoForm(OrphanReportForm orphanReportForm, List unAssignedCycles, List unAssignedSubCycles, List unAssignedActivity) {
        if (unAssignedCycles.size()>0){
            orphanReportForm.setAllCycles(unAssignedCycles);
        }
        if (unAssignedSubCycles.size()>0){
            orphanReportForm.setAllSubcycles(unAssignedSubCycles);
        }
        if (unAssignedActivity.size()>0){
            orphanReportForm.setAllActivities(unAssignedActivity);
        }
    }

    private void allAssignedInSystem(ActionMessages messages, HttpServletRequest request) {
        messages.add(ActionMessages.GLOBAL_MESSAGE,new ActionMessage(SoxicConstants.ALL_UNASSIGNED));
        saveMessages(request,messages);
    }


}
