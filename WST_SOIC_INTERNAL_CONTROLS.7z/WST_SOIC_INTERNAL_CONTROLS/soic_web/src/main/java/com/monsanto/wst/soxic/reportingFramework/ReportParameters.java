package com.monsanto.wst.soxic.reportingFramework;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.*;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:19:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportParameters {
   private Enumeration parameterNames;
    private Map stringParameters;
    private Map stringArrayParameters;
    private List exportParamters = new ArrayList();

    public List getExportParamters() {
        return exportParamters;
    }

    public ReportParameters() {
        stringParameters = new HashMap();
        stringParameters.put("AUDIT_ID","1141");
    }

    public ReportParameters(UCCHelper uccHelper) throws IOException {

        parameterNames= uccHelper.getParameterNames();
        stringParameters = new HashMap();
        stringArrayParameters = new HashMap();
        while(parameterNames.hasMoreElements()){
            String key = (String) parameterNames.nextElement();
            stringParameters.put(key,uccHelper.getRequestParameterValue(key));
        }
        Owner owner = (Owner) uccHelper.getRequestAttributeValue(SoxicConstants.OWNER);
        stringParameters.put(SoxicConstants.OWNER,owner);
        Iterator iterator = uccHelper.getSessionParameterNames();
        while(iterator.hasNext()){
            String sessionParameter = (String) iterator.next();
            Object sessionObject = uccHelper.getSessionParameter(sessionParameter);
            stringParameters.put(sessionParameter,sessionObject);
        }
    }

    public ReportParameters(UCCHelper uccHelper,List exportList) throws IOException {

        parameterNames= uccHelper.getParameterNames();
        stringParameters = new HashMap();
        stringArrayParameters = new HashMap();
        while(parameterNames.hasMoreElements()){
            String key = (String) parameterNames.nextElement();
            stringParameters.put(key,uccHelper.getRequestParameterValue(key));
        }
        Owner owner = (Owner) uccHelper.getRequestAttributeValue(SoxicConstants.OWNER);
        stringParameters.put(SoxicConstants.OWNER,owner);
        this.exportParamters=exportList;
        Owner tempOwner=(Owner) uccHelper.getSessionParameter(SoxicConstants.OWNER);

        Iterator iterator = uccHelper.getSessionParameterNames();
        while(iterator.hasNext()){
            String sessionParameter = (String) iterator.next();
            Object sessionObject = uccHelper.getSessionParameter(sessionParameter);
            stringParameters.put(sessionParameter,sessionObject);
        }

    }

    public Object getReportParameter(String reportParameter){
        return stringParameters.get(reportParameter);
    }

    public String[] getReportParameters(String reportParameter){
        return (String[]) stringArrayParameters.get(reportParameter);
    }

    public void setExportParamters(List exportParamters) {
        this.exportParamters = exportParamters;
    }

    public void addStringParameter(String paramName, String paramValue){
        if (stringParameters==null){
            stringParameters = new HashMap();
        }
        stringParameters.put(paramName,paramValue);        
    }
}
