package com.monsanto.wst.soxic.Servlet;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;

import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 9:48:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class PropertyFileUtil {
    public static String getSystemProperty(String cstrPropertiesFileName,String propertyRequested)throws WrappingException{
        String property = "";
        Logger.traceEntry();

        /*  Get the data from the indicated properties file.  */
        ResourceBundle bundle = ResourceBundle.getBundle(cstrPropertiesFileName);
        property = getToken(bundle,propertyRequested);
        Logger.traceExit();
        return property;
    }

    public static String getProperty(String cstrPropertiesFileName,String propertyName)throws WrappingException{
        String propertyValue = "";
        Logger.traceEntry();

        /*  Get the data from the indicated properties file.  */
        ResourceBundle bundle = ResourceBundle.getBundle(cstrPropertiesFileName);
        propertyValue = bundle.getString(propertyName);

        Logger.traceExit();
        return propertyValue;
    }

    private static String getToken (ResourceBundle props, String cstrKey) throws WrappingException {
        Logger.traceEntry();

        String cstrValue = null;
        try {
            String cstrPrefix;
            cstrPrefix = EnvironmentHelper.getPropertyPrefix();
            Logger.log(new LoggableInfo("Envrionment :"+cstrPrefix));
            cstrValue = props.getString(cstrPrefix + cstrKey);
        }
        catch (EnvironmentHelperException ehe) {
            Logger.log(new LoggableError(ehe));
            throw new WrappingException(ehe);
        }
        return Logger.traceExit(cstrValue);
    }    
}
