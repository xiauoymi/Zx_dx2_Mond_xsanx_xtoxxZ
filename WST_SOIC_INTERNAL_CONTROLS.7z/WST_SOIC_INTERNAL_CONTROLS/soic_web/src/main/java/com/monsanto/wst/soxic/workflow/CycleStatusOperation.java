/*
 * Created on Mar 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.persistance.EmailHeaderDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.exception.BadDataException;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CycleStatusOperation {
    public static void main(String args[]) throws Exception{
        CycleStatusOperation cycleObjectiveOperations = new CycleStatusOperation();
        cycleObjectiveOperations.sendStartEmail();
    }

    public void sendStartEmail()throws Exception{

                EmailHeaderDAO emailHeaderDAO=new EmailHeaderDAO();

        Map headerMap = emailHeaderDAO.selectHeader();

        String customString = (String) headerMap.get(SoxicConstants.CYCLE_EMAIL_HEADER);

        List cycleList = getStartCycleList();

        Map ownerMap = processStartCycleListForToday(cycleList);

        Iterator iterator = ownerMap.values().iterator();

        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            SarboxMailComponent.sendStartWorkFlowEmail(SoxicConstants.CYCLE,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString(), customString);
        }

    }

    /**
     *
     * Send over due email
     * @throws Exception
     */
    public void sendOverDueEmail()throws Exception{

        List cycleList = getOverDueCycleList();

        EmailWrapper emailWrapper = new EmailWrapper();

        Map ownerMap = processStartCycleList(cycleList);

        Iterator iterator = ownerMap.values().iterator();

        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            emailWrapper.setEmailAddress(ownerWrapper.getEmailid());
            SarboxMailComponent.workFlowEmail(SarboxMailComponent.WORKFLOW_PAST_DUE_CURRENT_LEVEL,SoxicConstants.CYCLE,emailWrapper);
        }

    }

    public Map processStartCycleList(List cycleList)throws Exception{

        Iterator iterator = cycleList.iterator();
        UtilDAO utilDAO = new UtilDAO();
        Map cycleOwnerMap = new HashMap();

        while(iterator.hasNext()){

            Cycle cycle = (Cycle)iterator.next();
            if(!cycleOwnerMap.containsKey(cycle.getOwnerId())){
                OwnerWrapper ownerWrapper = utilDAO.getCycleStartOwnerWrapper(cycle.getOwnerId());
                cycleOwnerMap.put(cycle.getOwnerId(),ownerWrapper);
            }

        }

        return cycleOwnerMap;

    }

    public Map processStartCycleListForToday(List cycleList)throws Exception{

        Iterator iterator = cycleList.iterator();
        UtilDAO utilDAO = new UtilDAO();
        Map cycleOwnerMap = new HashMap();

        while(iterator.hasNext()){

            Cycle cycle = (Cycle)iterator.next();
            if(!cycleOwnerMap.containsKey(cycle.getOwnerId())){
                OwnerWrapper ownerWrapper = utilDAO.getCycleStartOwnerWrapperStartDateToday(cycle.getOwnerId());
                cycleOwnerMap.put(cycle.getOwnerId(),ownerWrapper);
            }

        }

        return cycleOwnerMap;

    }

    /**
     * @return
     * @throws Exception
     */
    public List getStartCycleList()throws Exception{

        List cycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getControlObjectiveList = null;

        try {
            con = getConnection();

            getControlObjectiveList = con.prepareStatement("SELECT * FROM OWNER_CYCLE OC WHERE OC.START_DATE=? AND OC.STATUS <> 'G_COMPLETE'");

            getControlObjectiveList.setDate(1,new java.sql.Date(System.currentTimeMillis()));

            ResultSet rs = getControlObjectiveList.executeQuery();

            while(rs.next()){
                populateOwnerCycleList(rs,cycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public List getOverDueCycleList()throws Exception{

        List cycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getControlObjectiveList = null;

        try {
            con = getConnection();

            getControlObjectiveList = con.prepareStatement("SELECT * FROM OWNER_CYCLE OC WHERE OC.DUE_DATE<? AND OC.STATUS <> 'G_COMPLETE'");

            getControlObjectiveList.setDate(1,new java.sql.Date(System.currentTimeMillis()));

            ResultSet rs = getControlObjectiveList.executeQuery();

            while(rs.next()){
                populateOwnerCycleList(rs,cycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    /**
     * @throws Exception
     */
    public void updateOwnerCycleStatus() throws Exception{
        List cycleList = getOwnerCycleStatusList();
        processOwnerCycleStatus(cycleList);
        updateOwnerStatus(cycleList);
        email(cycleList);
    }

    /**
     * @throws Exception
     */
    public void updateCycleStatus() throws Exception{
        List cycleList = getCycleList();
        updateStatus(cycleList);
    }

    /**
     * @return
     * @throws Exception
     */
    public List getCycleList()throws Exception{

        List cycleList = new ArrayList();
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement getSubCycleList = null;
        try {
            con = getConnection();
            getSubCycleList = con.prepareStatement("SELECT * FROM SUB_CYCLE");
            rs = getSubCycleList.executeQuery();

            while(rs.next()){
                populateCycleList(rs,cycleList,con);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(con,rs,getSubCycleList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public List getOwnerCycleList()throws Exception{

        List cycleList = new ArrayList();

        Connection con = null;

        PreparedStatement getCycleList = null;

        try {
            con = getConnection();

            getCycleList = con.prepareStatement("SELECT * FROM OWNER_CYCLE");

            ResultSet rs = getCycleList.executeQuery();

            while(rs.next()){
                populateOwnerCycleList(rs,cycleList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

        /**
     * @return
     * @throws Exception
     */
    public List getOwnerCycleStatusList()throws Exception{
        List cycleList = new ArrayList();
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement getCycleList = null;

        try {
            con = getConnection();
            getCycleList = con.prepareStatement("SELECT * FROM OWNER_CYCLE OC,OWNER O,SUB_CYCLE SC WHERE O.OWNER_ID=OC.OWNER_ID AND OC.CYCLE_ID=SC.CYCLE_ID");
            rs = getCycleList.executeQuery();
            while(rs.next()){
                populateOwnerCycleStatusList(rs,cycleList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
               closeResources(con,rs,getCycleList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cycleList;
    }

    /**
     * @return
     * @throws Exception
     */
    public Connection getConnection() throws Exception {
        return SoxicConnectionFactory.getSoxicConnection();
    }

    /**
     * @param rs
     * @param cyclelist
     * @param con
     * @throws Exception
     */
    public void populateCycleList(ResultSet rs, List cyclelist, Connection con)throws Exception{
        String status="";
        Cycle cycle = new Cycle();
        cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
        cycle.setStatus(rs.getString(Cycle.STATUS));
        status = getCycleStatus(cycle.getCycleId(),con);
        if(!cycle.getStatus().equalsIgnoreCase(status)){
            cycle.setShow(true);
            cycle.setStatus(status);
        }
        cyclelist.add(cycle);
    }

    /**
     *
     * @param rs
     * @param cyclelist
     * @throws Exception
     */
    public void populateOwnerCycleList(ResultSet rs,List cyclelist)throws Exception{
        Cycle cycle = new Cycle();

        cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
        cycle.setDueDate(rs.getDate(Cycle.DUE_DATE));
        cycle.setStatus(rs.getString(Cycle.STATUS));
        cycle.setOwnerId(rs.getString(Cycle.OWNERID));
        cyclelist.add(cycle);
    }

    public void populateOwnerCycleStatusList(ResultSet rs,List cyclelist)throws Exception{
        Cycle cycle = new Cycle();
        cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
        cycle.setDueDate(rs.getDate(Cycle.DUE_DATE));
        cycle.setStatus(rs.getString(Cycle.STATUS));
        cycle.setOwnerId(rs.getString(Cycle.OWNERID));
        cycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
        cycle.setDueDateString(""+rs.getDate("DUE_DATE"));
        cycle.setCycleOwnerEmailString(rs.getString("EMAIL"));
        cyclelist.add(cycle);
    }

    /**
     *
     * @param cycleList
     */
    public void processCycleStatus(List cycleList){

        Iterator cycleListIterator = cycleList.iterator();
        Status newStatus;

        while(cycleListIterator.hasNext()){

            Cycle cycle = (Cycle)cycleListIterator.next();

            Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

            Long redValue = new Long(SoxicUtil.getRedPeriod());

            Date yellowDate = new Date(System.currentTimeMillis()
                    + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

            Date redDate = new Date(System.currentTimeMillis()
                    + (redValue.longValue() * 24 * 60 * 60 * 1000));

            Date date = new Date(cycle.getDueDate());

            Date currentDate = new Date(System.currentTimeMillis());

            //Date fifteenDate = new Date(System.currentTimeMillis()+1296000000);

            //Date thirtyDate = new Date(System.currentTimeMillis()+1296000000+1296000000);
            if(date!=null && !cycle.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){

                boolean valueone = date.before(yellowDate);

                boolean valuetwo = date.before(yellowDate);

                if(date.before(yellowDate) && toModify(cycle.getStatus(),"R_")){


                    cycle.setStatus("R_"+getStatusToAppend(cycle.getStatus()));
                    cycle.setShow(true);
                }else{
                    if(date.before(yellowDate) && date.after(yellowDate) && toModify(cycle.getStatus(),"Y_")){
                        cycle.setStatus("Y_"+getStatusToAppend(cycle.getStatus()));
                        cycle.setShow(true);
                    }

                    if(date.after(yellowDate) && toModify(cycle.getStatus(),"G_")){

                        //cycle.setStatus("G_"+getStatusToAppend(cycle.getStatus()));
                        cycle.setStatus(SoxicConstants.GREEN_COMPLETE);
                        cycle.setShow(true);
                    }
                }
            }
        }
    }

    /**
     *
     * @param cycleList
     */
    public void processOwnerCycleStatus(List cycleList){

        Iterator cycleListIterator = cycleList.iterator();

        while(cycleListIterator.hasNext()){

            Cycle cycle = (Cycle)cycleListIterator.next();



            if(cycle.getDueDate()!=null && cycle.getDueDate().length()>0 && !cycle.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){

                java.util.Date date = new Date(cycle.getDueDate());

                Date currentDate = new Date(System.currentTimeMillis());

                //Date fifteenDate = new Date(System.currentTimeMillis()+1296000000);

                //Date thirtyDate = new Date(System.currentTimeMillis()+1296000000+1296000000);

                Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

                Long redValue = new Long(SoxicUtil.getRedPeriod());

                Date yellowDate = new Date(System.currentTimeMillis()
                        + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

                Date redDate = new Date(System.currentTimeMillis()
                        + (redValue.longValue() * 24 * 60 * 60 * 1000));

                boolean valueone = date.before(redDate);

                boolean valuetwo = date.before(yellowDate);

                    if(date.before(redDate) && (toModify(cycle.getStatus(),"R_"))){


                        cycle.setStatus("R_"+getStatusToAppend(cycle.getStatus()));
                        cycle.setShow(true);
                    }else{
                        if(date.before(yellowDate) && date.after(redDate) && toModify(cycle.getStatus(),"Y_")){
                            cycle.setStatus("Y_"+getStatusToAppend(cycle.getStatus()));
                            cycle.setShow(true);
                        }

                        if(date.after(yellowDate) && toModify(cycle.getStatus(),"G_")){

                            cycle.setStatus("G_"+getStatusToAppend(cycle.getStatus()));
                            //cycle.setStatus(SoxicConstants.GREEN_COMPLETE);
                            cycle.setShow(true);
                        }
                    }
                }

        }
    }

    /**
     *
     * @param cyleList
     * @throws Exception
     */
    public void updateStatus(List cyleList)throws Exception{
        Iterator cyleListIterator = cyleList.iterator();
        Connection conn = null; 
        try{
        conn = getConnection();
        while(cyleListIterator.hasNext()){
            Cycle cycle = (Cycle)cyleListIterator.next();
            if(cycle.isShow()){
                updateCycle(cycle,conn);
            }
        }
        }catch(Exception e){
          e.printStackTrace();
        }
        finally{
          try{
             closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources : CycleStatusOperation.updateStatus()");
          }
        }
    }

    /**
     *
     * @param cyleList
     * @throws Exception
     */
    public void updateOwnerStatus(List cyleList)throws Exception{
        Iterator cyleListIterator = cyleList.iterator();
        Connection conn = null;
        try{
          conn = getConnection();
          while(cyleListIterator.hasNext()){
            Cycle cycle = (Cycle)cyleListIterator.next();
            if(cycle.isShow()){
              updateOwnerCycle(cycle,conn);
            }
          }
        }catch(Exception e){
          e.printStackTrace();
        }finally{
          try{
             closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources : CycleStatusOperation.updateOwnerStatus()");
          }
        }
    }

    /**
     *
     * @param cycle
     * @param con
     * @throws Exception
     */
    public void updateCycle(Cycle cycle, Connection con)throws Exception{
        PreparedStatement updateCycle = null;
        try {
            updateCycle = con.prepareStatement("UPDATE CYCLE C SET C.STATUS=? WHERE C.CYCLE_ID=?");
            updateCycle.setString(1,cycle.getStatus());
            updateCycle.setString(2,cycle.getCycleId());
            updateCycle.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(null,null,updateCycle);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

  private void closeResources(Connection conn, ResultSet rs, PreparedStatement statement) throws SQLException {
    if(rs != null) rs.close();
    if(statement != null) statement.close();
    if(conn != null) conn.close();
  }

  /**
     * 
     * @param cycle
     * @param con
   * @throws Exception
     */
    public void updateOwnerCycle(Cycle cycle, Connection con)throws Exception{
        PreparedStatement updateCycleStatement = null;
        try {
            updateCycleStatement = con.prepareStatement("UPDATE OWNER_CYCLE OC SET OC.STATUS=? WHERE OC.OWNER_ID=? AND OC.CYCLE_ID=?");
            updateCycleStatement.setString(1,cycle.getStatus());
            updateCycleStatement.setString(2,cycle.getOwnerId());
            updateCycleStatement.setString(3,cycle.getCycleId());
            updateCycleStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
            closeResources(null,null,updateCycleStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param currentStatus
     * @return
     */
    public String getStatusToAppend(String currentStatus){
        if(currentStatus.indexOf("_")>0){
            return currentStatus.substring(currentStatus.indexOf("_")+1,currentStatus.length());
        }
        return currentStatus;
    }

    /**
     * @param currentStatus
     * @param currentString
     * @return
     */
    public boolean toModify(String currentStatus,String currentString){

        if(currentStatus.indexOf(currentString)<0){
            return true;
        }
        return false;
    }


    /**
     *
     * @param cycleId
     * @param con
     * @return
     * @throws Exception
     */
    public String getCycleStatus(String cycleId, Connection con)throws Exception{
        PreparedStatement cycleStatysStatement = null;
        String status=null;
        ResultSet rs = null;
        try {
            cycleStatysStatement = con.prepareStatement("SELECT OC.STATUS FROM OWNER_CYCLE OC,LOOKUP L WHERE OC.CYCLE_ID=? AND L.TYPE='STATUS' AND L.NAME=OC.STATUS ORDER BY L.VALUE");
            cycleStatysStatement.setString(1,cycleId);
            rs = cycleStatysStatement.executeQuery();
            while(rs.next()){
                status = rs.getString("STATUS");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(null,rs,cycleStatysStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return status;
    }

    public void email(List cycleList)throws Exception{

        UtilDAO utilDAO = new UtilDAO();
        Iterator cycleListIterator = cycleList.iterator();

        Map cycleOwnerMap = new HashMap();

        while(cycleListIterator.hasNext()){

            Cycle cycle = (Cycle)cycleListIterator.next();

            if(cycle.isShow()){
                if(cycleOwnerMap.containsKey(cycle.getOwnerId())){
                    OwnerWrapper ownerWrapper = (OwnerWrapper) cycleOwnerMap.get(cycle.getOwnerId());
                    if(!ownerWrapper.getDueDate().contains(cycle.getDueDateString())){
                        String dueDateString = ownerWrapper.getDateString()+","+cycle.getDueDate();
                        ownerWrapper.setDateString(dueDateString);
                        ownerWrapper.addDueDateToList(cycle.getDueDateString());
                    }

                    if(!ownerWrapper.getSubCycleList().contains(cycle.getSubCycleId())){
                        String subCycleString = ownerWrapper.getSubCycleString()+","+cycle.getSubCycleId();
                        ownerWrapper.setSubCycleString(subCycleString);
                        ownerWrapper.addSubToList(cycle.getSubCycleId());
                    }
                }else{
                    OwnerWrapper ownerWrapper = new OwnerWrapper();
                    ownerWrapper.setEmailid(cycle.getCycleOwnerEmailString());
                    ownerWrapper.setOwnerid(cycle.getOwnerId());
                    ownerWrapper.setSubCycleString(cycle.getSubCycleId());
                    ownerWrapper.setDateString(cycle.getDueDateString());
                    ownerWrapper.addSubToList(cycle.getSubCycleId());
                    ownerWrapper.addDueDateToList(cycle.getDueDateString());
                    cycleOwnerMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
                }
            }
        }
        sendEmail(cycleOwnerMap);
    }

    public void sendEmail(Map ownerMap){
        try{
            Iterator ownerActivityIterator = ownerMap.values().iterator();

            while(ownerActivityIterator.hasNext()){
                OwnerWrapper ownerWrapper =(OwnerWrapper)ownerActivityIterator.next();
                SarboxMailComponent.sendStatusChangeWorkFlowEmail(SoxicConstants.CYCLE,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString());
            }
        }catch(Exception e){

        }
    }

	//----New Code

	public void updateOverAllCycleStatus()throws Exception{
    List overAllCycleList = cycleList();
    Iterator iterator = overAllCycleList.iterator();
    Cycle cycle = null;
    Connection conn = null;
    try{
      conn = getConnection();
      while (iterator.hasNext()) {
        cycle = (Cycle) iterator.next();
        String status = getOwnerCycleStatus(cycle.getCycleId(),conn);
        if (status != null || cycle.getStatus() != null) {
          if (!status.equalsIgnoreCase(cycle.getStatus())) {
            updateOverAllCycleStatus(cycle.getCycleId(), status,conn);
          }
        }
      }
    }catch(Exception e){
     e.printStackTrace();
    }finally{
      try{
      closeResources(conn,null,null);
      }catch(SQLException sqlEx){
        throw new Exception("Unable to close resources : CycleStatusOperation.updateOverAllCycleStatus()");
      }
    }
	}

	public List cycleList()throws Exception{
		List cycleList = new ArrayList();

		Connection con = null;

		PreparedStatement preparedStatement = null;

		try {
			con = getConnection();

			preparedStatement = con.prepareStatement("SELECT * FROM CYCLE C,CYCLE_STATE CS WHERE C.CYCLE_ID =CS.CYCLE_ID AND CS.STATE='CERTIFICATION'");

			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()){
				populateOverAllCycleList(rs,cycleList);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cycleList;
	}

	public void populateOverAllCycleList(ResultSet rs,List cycleList)throws Exception{
		Cycle cycle = new Cycle();
		cycle.setCycleId(rs.getString(Cycle.CYCLE_ID));
		cycle.setStatus(rs.getString(Cycle.STATUS));
		cycleList.add(cycle);
	}

	public String getOwnerCycleStatus(String cycleId, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
    ResultSet rs = null;
		try {
			preparedStatement = con.prepareStatement("SELECT STATUS FROM OWNER_CYCLE WHERE CYCLE_ID=? ORDER BY STATUS DESC");
			preparedStatement.setString(1,cycleId);
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				return rs.getString("STATUS");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(null,rs,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	public void updateOverAllCycleStatus(String cycleId, String status, Connection con)throws Exception{
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = con.prepareStatement("UPDATE CYCLE C SET C.STATUS=? WHERE C.CYCLE_ID=?");
			preparedStatement.setString(1,status);
			preparedStatement.setString(2,cycleId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closeResources(null,null,preparedStatement);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}

