/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/

package com.monsanto.wst.soxic.action;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.Vector;

import org.apache.log4j.Category;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

import com.monsanto.wst.soxic.form.RowObject;



/**
 * Export2Excel is a helper class to /excelExport action.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class Export2Excel {
	
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());

    String filename = "";
    
    
    Vector columnVector = new Vector();	
	RowObject rowObject = new RowObject();	
	String countryId;	
	String worldArea;	
	Vector subCycleOwners = new Vector();	
	Vector cycleOwners = new Vector();
	
	String subCycleOwnerList;	
	String cycleOwnerList;
	
	String subCycleDesc;
	String cycleDesc;

    String gap_Description;

    // Cell Styles
    private HSSFCellStyle cs = null;
    private HSSFCellStyle cs1 = null;
    private HSSFCellStyle cs2 = null;
    private HSSFCellStyle cs3 = null;
    private HSSFCellStyle cs4 = null;
    private HSSFCellStyle cs5 = null;
    private HSSFCellStyle cs6 = null;

    public String getCycleId() {
        return cycleId;
    }

    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }

    String cycleId;

	/**
	 * @return Returns the bos.
	 */
	public BufferedOutputStream getBos() {
		return bos;
	}
	/**
	 * @param bos The bos to set.
	 */
	public void setBos(BufferedOutputStream bos) {
		this.bos = bos;
	}
	BufferedOutputStream bos;
	
	
	/**
	 * @return Returns the cycleDesc.
	 */
	public String getCycleDesc() {
		return cycleDesc;
	}
	/**
	 * @param cycleDesc The cycleDesc to set.
	 */
	public void setCycleDesc(String cycleDesc) {
		this.cycleDesc = cycleDesc;
	}
	/**
	 * @return Returns the cycleOwnerList.
	 */
	public String getCycleOwnerList() {
		return cycleOwnerList;
	}
	/**
	 * @param cycleOwnerList The cycleOwnerList to set.
	 */
	public void setCycleOwnerList(String cycleOwnerList) {
		this.cycleOwnerList = cycleOwnerList;
	}
	/**
	 * @return Returns the subCycleDesc.
	 */
	public String getSubCycleDesc() {
		return subCycleDesc;
	}
	/**
	 * @param subCycleDesc The subCycleDesc to set.
	 */
	public void setSubCycleDesc(String subCycleDesc) {
		this.subCycleDesc = subCycleDesc;
	}
	/**
	 * @return Returns the subCycleOwnerList.
	 */
	public String getSubCycleOwnerList() {
		return subCycleOwnerList;
	}
	/**
	 * @param subCycleOwnerList The subCycleOwnerList to set.
	 */
	public void setSubCycleOwnerList(String subCycleOwnerList) {
		this.subCycleOwnerList = subCycleOwnerList;
	}
	/**
	 * @return Returns the columnVector.
	 */
	public Vector getColumnVector() {
		return columnVector;
	}
	/**
	 * @param columnVector The columnVector to set.
	 */
	public void setColumnVector(Vector columnVector) {
		this.columnVector = columnVector;
	}
	/**
	 * @return Returns the countryId.
	 */
	public String getCountryId() {
		return countryId;
	}
	/**
	 * @param countryId The countryId to set.
	 */
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	/**
	 * @return Returns the cycleOwners.
	 */
	public Vector getCycleOwners() {
		return cycleOwners;
	}
	/**
	 * @param cycleOwners The cycleOwners to set.
	 */
	public void setCycleOwners(Vector cycleOwners) {
		this.cycleOwners = cycleOwners;
	}
	/**
	 * @return Returns the subCycleOwners.
	 */
	public Vector getSubCycleOwners() {
		return subCycleOwners;
	}
	/**
	 * @param subCycleOwners The subCycleOwners to set.
	 */
	public void setSubCycleOwners(Vector subCycleOwners) {
		this.subCycleOwners = subCycleOwners;
	}
	/**
	 * @return Returns the worldArea.
	 */
	public String getWorldArea() {
		return worldArea;
	}
	/**
	 * @param worldArea The worldArea to set.
	 */
	public void setWorldArea(String worldArea) {
		this.worldArea = worldArea;
	}

    /**
     * @return  Returns the Gap Description
     */
    public String getGap_Description() {
        return gap_Description;
    }

    /**
     * @param gap_Description is set
     */
    public void setGap_Description(String gap_Description) {
        this.gap_Description = gap_Description;
    }

	//**Constructor...
	public Export2Excel(String filename){
		
		this.filename = filename;
		
	}

    private HSSFSheet        s;
    private int rowCounter = 0;

    private void initCellStyles(HSSFWorkbook wb) {

        if(this.cs != null && this.cs2 != null && this.cs3 != null
                && this.cs4 != null && this.cs5 != null && this.cs6 != null) {
            return;
        }

        HSSFFont         f      = wb.createFont();
        f.setFontName("Tahoma");
        f.setFontHeightInPoints((short)8);

        cs     = wb.createCellStyle();
        cs.setWrapText(true);
        cs.setFont(f);
        cs.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cs.setBorderRight(HSSFCellStyle.BORDER_THIN);
        cs.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cs.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cs.setBottomBorderColor((short)0);
        //cs.setAlignment(cs.ALIGN_CENTER);
        cs.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


        //**Font-Style3.. for data
        cs3     = wb.createCellStyle();
        cs3.setWrapText(true);
        cs3.setFont(f);
        cs3.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cs3.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cs3.setBorderRight(HSSFCellStyle.BORDER_THIN);
        cs3.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cs3.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cs3.setBottomBorderColor((short)0);
        cs3.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);

        //**Font-Style4.. for data
        HSSFFont         f4      = wb.createFont();
        f4.setFontName("Arial");
        f4.setFontHeightInPoints((short)9);

        cs4     = wb.createCellStyle();
        cs4.setWrapText(true);
        cs4.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cs4.setBorderRight(HSSFCellStyle.BORDER_THIN);
        cs4.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cs4.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cs4.setBottomBorderColor((short)0);
        cs4.setFont(f4);
        //cs4.setAlignment(cs.ALIGN_CENTER);
        cs4.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


        //**Font-Style5.. for data
        HSSFFont         f5      = wb.createFont();
        f5.setFontName("Arial");
        f5.setFontHeightInPoints((short)10);

        cs5     = wb.createCellStyle();
        cs5.setWrapText(true);
        cs5.setFont(f5);
        //cs4.setAlignment(cs.ALIGN_CENTER);
        cs5.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


        //**Font-Style2.. for Headings...
        HSSFFont         f2      = wb.createFont();
        f2.setFontName("Tahoma");
        f2.setFontHeightInPoints((short)8);
        f2.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

        cs2     = wb.createCellStyle();
        cs2.setFillPattern(( short ) 1);
        cs2.setFillForegroundColor(( short )HSSFColor.GREY_25_PERCENT.index);
        cs2.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cs2.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
        cs2.setWrapText(true);
        cs2.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cs2.setBorderRight(HSSFCellStyle.BORDER_THIN);
        cs2.setBottomBorderColor((short)0);
        cs2.setFont(f2);


        //**Font-Style6.. for Headings...
        cs6     = wb.createCellStyle();
        cs6.setFillPattern(( short ) 1);
        cs6.setFillForegroundColor(( short )HSSFColor.GREY_25_PERCENT.index);
        cs6.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
        cs6.setWrapText(true);
        cs6.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cs6.setBorderRight(HSSFCellStyle.BORDER_THIN);
        cs6.setBottomBorderColor((short)0);
        cs6.setRotation((short)90);
        cs6.setFont(f2);
    }

	public void export(HSSFWorkbook wb, boolean isNewCycle){
		
		try{


	        HSSFRow          r      = null;
	        HSSFCell         c      = null;

            initCellStyles(wb);

            if(isNewCycle) {
                rowCounter = 0;
                String sheetName = this.cycleId;
                if(this.cycleId.length() > 30)
                    sheetName = this.cycleId.substring(0, 30);
                s = wb.createSheet(sheetName);

                //**Set all the Column Widths...
                s.setColumnWidth(( short ) (3),
                        ( short ) ((50 * 3.075) / (( double ) 1 / 20)));

                s.setColumnWidth(( short ) (4),
                        ( short ) ((50 * 4.30) / (( double ) 1 / 20)));

                //**default settingd for the 3nr and 4th row

                s.setColumnWidth(( short ) (7),
                        ( short ) ((50 * 8.775) / (( double ) 1 / 20)));

                s.setColumnWidth(( short ) (8),
                        ( short ) ((50 * 4.30) / (( double ) 1 / 20)));

                s.setColumnWidth(( short ) (9),
                        ( short ) ((50 * 2.15) / (( double ) 1 / 20)));


                //**Labels...5th row
                r = s.createRow(rowCounter++);
                r.setHeightInPoints(70.50f);

                c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)2, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)3, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("ID [Cycle -> Sub-cycle");

                c = r.createCell((short)4, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Control Objective [Description]");

                c = r.createCell((short)5, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("Control Objective Category  [O, F, C] (2) ");

                c = r.createCell((short)6, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("Control Objective Code [D, C, A, V, R]  (3)");

                c = r.createCell((short)7, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Control Activity Description");

                c = r.createCell((short)8, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Primary");

                c = r.createCell((short)9, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("USERID");

                c = r.createCell((short)10, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("LOCATION");

                c = r.createCell((short)11, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Priority");

                c = r.createCell((short)12, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Comments");

                c = r.createCell((short)13, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Response");

                c = r.createCell((short)14, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("GAP");

                r = s.createRow(rowCounter++);

                c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)2, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("");

                c = r.createCell((short)3, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs6);
                c.setCellValue("-> Control Objective -> Control activity] (1)");

                for (short cellnum = 4; cellnum < 15; cellnum++) {
                    c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
                    c.setCellValue("");
                    c.setCellStyle(cs2);

                    if(cellnum == 8){
                        c.setCellValue("Risk [Description]");
                    }
                }

                r = s.createRow(rowCounter);
                c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Country");

                c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Cycle");

                c = r.createCell((short)2, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("Sub-cycle");


                for (short cellnum = 3; cellnum < 15; cellnum++) {
                    c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
                    c.setCellStyle(cs2);
                    c.setCellValue("");
                }

                //**6th row
                r = s.createRow(--rowCounter);
                r.setHeightInPoints(37.50f);

                //**Activity Data from Column Vector...
                rowCounter++; rowCounter++;

            } // end of if
	        
	        for ( int i = 0; i < columnVector.size(); i++, rowCounter++)
	        {
	        	rowObject = (RowObject)columnVector.get(i);
	        	
	            r = s.createRow(rowCounter);
	        
	            for (short cellnum = 0; cellnum < 15; cellnum++)
	            {
	                c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);

                    if(cellnum == 0){
	                	c.setCellStyle(cs);
	                	c.setCellValue(countryId);
	                } else
                    if(cellnum == 1){
	                	c.setCellStyle(cs);
	                	c.setCellValue(cycleDesc);
	                } else
                    if(cellnum == 2){
	                	c.setCellStyle(cs);
	                	c.setCellValue(subCycleDesc);
	                } else
	                if(cellnum == 3){
	                	c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol1());
	                } else
	                if(cellnum == 4){
	                	c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol2());
	                } else
	                if(cellnum == 5){
	                	c.setCellStyle(cs3);
	                	c.setCellValue(rowObject.getCol3());
	                	
	                } else
	                if(cellnum == 6){
	                	c.setCellStyle(cs3);
	                	c.setCellValue(rowObject.getCol4());
	                	
	                } else
	                if(cellnum == 7){
	                	c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol5());
	                } else
	                if(cellnum == 8){
	                	c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol6());
	                } else
	                if(cellnum == 9){
	                	c.setCellStyle(cs4);
	                	c.setCellValue(rowObject.getCol7());
	                	
	                } else
	                if(cellnum == 10){
	                	c.setCellStyle(cs4);
	                	c.setCellValue(rowObject.getCol8());
	                } else
	                if(cellnum == 11){
	                	c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol9());
	                } else
                    if(cellnum == 12 || cellnum == 13){
	                	c.setCellStyle(cs);
	                	c.setCellValue("");
	                } else
                    if(cellnum == 14){
                        c.setCellStyle(cs);
	                	c.setCellValue(rowObject.getCol12());
                    }

	            }
	        }

	        logger.info("-> Done exporting.");
			
		}
		catch(Exception ex){
			logger.error(ex.getMessage());
            ex.printStackTrace();
		}
		
	}
	
	public static void main(String args[]){
		Export2Excel export2Excel = new Export2Excel("ExcelReport.xls");
		export2Excel.export();
	}
	

    public void export(){

        try{
            logger.info("-> Exporting to Excel File...");

            FileOutputStream out    = new FileOutputStream(filename);

            HSSFWorkbook     wb     = new HSSFWorkbook();
            HSSFSheet        s      = wb.createSheet();

            HSSFRow          r      = null;
            HSSFCell         c      = null;

            //**Font-Style1.. for data
            HSSFFont         f      = wb.createFont();
            f.setFontName("Tahoma");
            f.setFontHeightInPoints((short)8);

            HSSFCellStyle    cs     = wb.createCellStyle();
            cs.setWrapText(true);
            cs.setFont(f);
            cs.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            cs.setBorderRight(HSSFCellStyle.BORDER_THIN);
            cs.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            cs.setBorderTop(HSSFCellStyle.BORDER_THIN);
            cs.setBottomBorderColor((short)0);
            //cs.setAlignment(cs.ALIGN_CENTER);
            cs.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


            //**Font-Style3.. for data
            HSSFCellStyle    cs3     = wb.createCellStyle();
            cs3.setWrapText(true);
            cs3.setFont(f);
            cs3.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            cs3.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            cs3.setBorderRight(HSSFCellStyle.BORDER_THIN);
            cs3.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            cs3.setBorderTop(HSSFCellStyle.BORDER_THIN);
            cs3.setBottomBorderColor((short)0);
            cs3.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);

            //**Font-Style4.. for data
            HSSFFont         f4      = wb.createFont();
            f4.setFontName("Arial");
            f4.setFontHeightInPoints((short)9);

            HSSFCellStyle    cs4     = wb.createCellStyle();
            cs4.setWrapText(true);
            cs4.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            cs4.setBorderRight(HSSFCellStyle.BORDER_THIN);
            cs4.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            cs4.setBorderTop(HSSFCellStyle.BORDER_THIN);
            cs4.setBottomBorderColor((short)0);
            cs4.setFont(f4);
            //cs4.setAlignment(cs.ALIGN_CENTER);
            cs4.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


            //**Font-Style5.. for data
            HSSFFont         f5      = wb.createFont();
            f5.setFontName("Arial");
            f5.setFontHeightInPoints((short)10);

            HSSFCellStyle    cs5     = wb.createCellStyle();
            cs5.setWrapText(true);
            cs5.setFont(f5);
            //cs4.setAlignment(cs.ALIGN_CENTER);
            cs5.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);


            //**Font-Style2.. for Headings...
            HSSFFont         f2      = wb.createFont();
            f2.setFontName("Tahoma");
            f2.setFontHeightInPoints((short)8);
            f2.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

            HSSFCellStyle    cs2     = wb.createCellStyle();
            cs2.setFillPattern(( short ) 1);
            cs2.setFillForegroundColor(( short )HSSFColor.GREY_25_PERCENT.index);
            cs2.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            cs2.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
            cs2.setWrapText(true);
            cs2.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            cs2.setBorderRight(HSSFCellStyle.BORDER_THIN);
            cs2.setBottomBorderColor((short)0);
            cs2.setFont(f2);


            //**Font-Style6.. for Headings...
            HSSFCellStyle    cs6     = wb.createCellStyle();
            cs6.setFillPattern(( short ) 1);
            cs6.setFillForegroundColor(( short )HSSFColor.GREY_25_PERCENT.index);
            cs6.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
            cs6.setWrapText(true);
            cs6.setBorderLeft(HSSFCellStyle.BORDER_THIN);
            cs6.setBorderRight(HSSFCellStyle.BORDER_THIN);
            cs6.setBottomBorderColor((short)0);
            cs6.setRotation((short)90);
            cs6.setFont(f2);



            //**Set all the Column Widths...
            s.setColumnWidth(( short ) (0),
                    ( short ) ((50 * 3.075) / (( double ) 1 / 20)));

            s.setColumnWidth(( short ) (1),
                    ( short ) ((50 * 4.30) / (( double ) 1 / 20)));

            //**default settingd for the 3nr and 4th row

            s.setColumnWidth(( short ) (4),
                    ( short ) ((50 * 8.775) / (( double ) 1 / 20)));

            s.setColumnWidth(( short ) (5),
                    ( short ) ((50 * 4.30) / (( double ) 1 / 20)));

            s.setColumnWidth(( short ) (6),
                    ( short ) ((50 * 2.15) / (( double ) 1 / 20)));




            //**Others default...end of setting column widths.

            short rownum = 0;

            //**Header Info...

            //**Cycle Owners...
            r = s.createRow(0);
            r.setHeightInPoints(12.75f);

            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(cycleOwnerList);

            c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue("Cycle Owner");

//	        for (short cellnum = 4; cellnum < cycleOwners.size() + 4; cellnum++)
//	        {
//	            c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
//	            c.setCellStyle(cs5);
//	            c.setCellValue(cycleOwners.get(cellnum - 4).toString());
//
//	        }

            c = r.createCell((short)4, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(cycleDesc);



            //**Sub Cycle Owners...
            r = s.createRow(1);
            r.setHeightInPoints(12.75f);

            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(subCycleOwnerList);

            c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue("Sub-cycle Owner");


//	        for (short cellnum = 4; cellnum < subCycleOwners.size() + 4; cellnum++)
//	        {
//	            c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
//	            c.setCellStyle(cs5);
//	            c.setCellValue(subCycleOwners.get(cellnum - 4).toString());
//
//	        }

            c = r.createCell((short)4, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(subCycleDesc);


            //**World Area...
            r = s.createRow(2);
            r.setHeightInPoints(12.75f);

            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(worldArea);

            c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue("World Area");


            //**Country...
            r = s.createRow(3);
            r.setHeightInPoints(12.75f);

            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue(countryId);

            c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs5);
            c.setCellValue("Country");



            //**Labels...5th row
            r = s.createRow(4);
            r.setHeightInPoints(70.50f);

            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs6);
            c.setCellValue("ID [Cycle -> Sub-cycle");

            c = r.createCell((short)1, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Control Objective [Description]");

            c = r.createCell((short)2, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs6);
            c.setCellValue("Control Objective Category  [O, F, C] (2) ");

            c = r.createCell((short)3, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs6);
            c.setCellValue("Control Objective Code [D, C, A, V, R]  (3)");

            c = r.createCell((short)4, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Control Activity Description");

            c = r.createCell((short)5, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Primary");

            c = r.createCell((short)6, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("USERID");

            c = r.createCell((short)7, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("LOCATION");

            c = r.createCell((short)8, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Priority");

            c = r.createCell((short)9, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Comments");

            c = r.createCell((short)10, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("Response");

            c = r.createCell((short)11, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs2);
            c.setCellValue("GAP");

            r = s.createRow(5);
            c = r.createCell((short)0, HSSFCell.CELL_TYPE_STRING);
            c.setCellStyle(cs6);
            c.setCellValue("-> Control Objective -> Control activity] (1)");

            for (short cellnum = 1; cellnum < 12; cellnum++)
            {
                c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
                c.setCellValue("");

                c.setCellStyle(cs2);

                if(cellnum == 5){
                    c.setCellValue("Risk [Description]");
                }
            }

            r = s.createRow(6);
            for (short cellnum = 0; cellnum < 12; cellnum++)
            {
                c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);
                c.setCellStyle(cs2);
                c.setCellValue("");
            }


            //**6th row
            r = s.createRow(5);
            r.setHeightInPoints(37.50f);


            //**Activity Data from Column Vector...
            for ( rownum = 7; rownum < columnVector.size() + 7; rownum++)
            {
                rowObject = (RowObject)columnVector.get(rownum - 7);

                r = s.createRow(rownum);

                for (short cellnum = 0; cellnum < 12; cellnum++)
                {
                    c = r.createCell(cellnum, HSSFCell.CELL_TYPE_STRING);

                    if(cellnum == 0){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol1());
                    }
                    if(cellnum == 1){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol2());
                    }

                    if(cellnum == 2){
                        c.setCellStyle(cs3);
                        c.setCellValue(rowObject.getCol3());

                    }

                    if(cellnum == 3){
                        c.setCellStyle(cs3);
                        c.setCellValue(rowObject.getCol4());

                    }

                    if(cellnum == 4){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol5());


                    }
                    if(cellnum == 5){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol6());

                    }
                    if(cellnum == 6){
                        c.setCellStyle(cs4);
                        c.setCellValue(rowObject.getCol7());

                    }
                    if(cellnum == 7){
                        c.setCellStyle(cs4);
                        c.setCellValue(rowObject.getCol8());
                    }
                    if(cellnum == 8){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol9());
                    }
                    if(cellnum == 9 || cellnum == 10){
                        c.setCellStyle(cs);
                        c.setCellValue("");
                    }
                    if(cellnum == 11){
                        c.setCellStyle(cs);
                        c.setCellValue(rowObject.getCol12());
                    }

                }
            }


            //wb.write(out);

            wb.write(bos);

//	        bos.flush();
//	        bos.close();
//
//	        out.close();
//
            logger.info("-> Done exporting.");

        }
        catch(Exception ex){
            logger.error(ex.getMessage());
        }

    }

	
}

