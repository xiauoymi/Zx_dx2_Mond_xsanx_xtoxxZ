package com.monsanto.wst.soxic.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.ControlObjective;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/**
 * MyEclipse Struts Creation date: 02-16-2005
 * 
 * XDoclet definition:
 * 
 * @struts:action validate="true"
 */
public class DisplayDeficiencyAction extends Action {

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		forward = mapping.findForward("success");

		ControlObjectiveForm controlObjectiveFrom = (ControlObjectiveForm) form;

		int changedLevel = controlObjectiveFrom.getLevel();

		changedLevel = changedLevel - 1;

		String id = getControlObjectiveId(changedLevel,
				(List) controlObjectiveFrom.getControlObjectiveList());

		controlObjectiveFrom.setControlObjectiveId(id);

		controlObjectiveFrom.setDeficiency(getDeficiencyList(changedLevel,
				(List) controlObjectiveFrom.getControlObjectiveList()));

		return forward;
	}

	public String getControlObjectiveId(int level, List controlObjectiveList) {

		String controlObjectiveId = null;

		ControlObjective controlObjective = (ControlObjective) controlObjectiveList
				.get(level);

		return controlObjective.getControlObjectiveId();

	}

	public List getDeficiencyList(int level, List controlObjectiveList) {

		String controlObjectiveId = null;

		ControlObjective controlObjective = (ControlObjective) controlObjectiveList
				.get(level);

		return controlObjective.getDeficiencyList();

	}

}