/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DeficiencyOperations {
	
	private String environment="";
	
	private String envVariable="";
	
	/**
	 * @return Returns the envVariable.
	 */
	public String getEnvVariable() {
		return envVariable;
	}
	/**
	 * @param envVariable The envVariable to set.
	 */
	public void setEnvVariable(String envVariable) {
		this.envVariable = envVariable;
	}
	public static void main(String args[]) throws Exception{
		
		DeficiencyOperations deficiencyOperations = new DeficiencyOperations();
		
		deficiencyOperations.setEnvironment(args[0]);
		deficiencyOperations.setEnvVariable(args[1]);
		
		deficiencyOperations.setCycleDeficiency();
		deficiencyOperations.setSubCycleDeficiency();
		deficiencyOperations.setControlObjectiveDeficiency();
	}

	public void setCycleDeficiency()throws Exception{
		
		List cycleList = returnCycles();
		
		Iterator cycleListIterator = cycleList.iterator();
		
		while(cycleListIterator.hasNext()){
			
			String cycleId = (String)cycleListIterator.next();
			
			StringTokenizer stringTokenizer = new StringTokenizer(cycleId,".");
			
			String period = stringTokenizer.nextToken();
			
			String countryId = stringTokenizer.nextToken();
			
			String cycleIdentifier = stringTokenizer.nextToken(); 
			
			if(isCycleDeficiencyPresent(period,countryId,cycleIdentifier)){
				updateCycleDeficiency(cycleId,"Y");
			}else{
				updateCycleDeficiency(cycleId,"N");
			}
		}
	}
	
	public void setSubCycleDeficiency()throws Exception{
		
		List subCycleList = returnSubcycles();
		
		Iterator subCycleListIterator = subCycleList.iterator();
		
		while(subCycleListIterator.hasNext()){
			
			String subCycleId = (String)subCycleListIterator.next();
			
			StringTokenizer stringTokenizer = new StringTokenizer(subCycleId,".");
			
			String period = stringTokenizer.nextToken();
			
			String countryId = stringTokenizer.nextToken();
			
			String cycleIdentifier = stringTokenizer.nextToken(); 
			
			String subcycleIdentifier = stringTokenizer.nextToken();
			
			if(isSubCycleDeficiencyPresent(period,countryId,subcycleIdentifier,cycleIdentifier)){
				updateSubCycleDeficiency(subCycleId,"Y");
			}else{
				updateSubCycleDeficiency(subCycleId,"N");
			}
		}
	}
	
	public void setControlObjectiveDeficiency()throws Exception{
		
		List controlObjectiveList = returnControlObjectives();
		
		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();
		
		while(controlObjectiveListIterator.hasNext()){
			
			String controlObjectiveId = (String)controlObjectiveListIterator.next();
			
			StringTokenizer stringTokenizer = new StringTokenizer(controlObjectiveId,".");
			
			String period = stringTokenizer.nextToken();
			
			String countryId = stringTokenizer.nextToken();
			
			String cycleIdentifier = stringTokenizer.nextToken(); 
			
			String subcycleIdentifier = stringTokenizer.nextToken();
			
			String controlObjectiveIdentifier = stringTokenizer.nextToken();
			
			if(isControlObjectiveDeficiencyPresent(period,countryId,controlObjectiveIdentifier,subcycleIdentifier,cycleIdentifier)){
				updateControlObjectiveDeficiency(controlObjectiveId,"Y");
			}else{
				updateControlObjectiveDeficiency(controlObjectiveId,"N");
			}
		}
	}
	
	public List returnSubcycles()throws Exception{
		
		Connection con = null;
		
		List subCycleList = new ArrayList();

		PreparedStatement selectAllSubCycles = null;
	
		try {
			con = getConnection();

			selectAllSubCycles = con.prepareStatement("SELECT SUB_CYCLE_ID FROM SUB_CYCLE");
			
			ResultSet rs = selectAllSubCycles.executeQuery();
			
			while(rs.next()){
				subCycleList.add(rs.getString("SUB_CYCLE_ID"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return subCycleList;
	}
	
	public List returnCycles()throws Exception{
		
		Connection con = null;
		
		List cycleList = new ArrayList();

		PreparedStatement selectAllCycles = null;
	
		try {
			con = getConnection();

			selectAllCycles = con.prepareStatement("SELECT CYCLE_ID FROM CYCLE");
			
			ResultSet rs = selectAllCycles.executeQuery();
			
			while(rs.next()){
				cycleList.add(rs.getString("CYCLE_ID"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return cycleList;
	}	
	
	public boolean isSubCycleDeficiencyPresent(String periodId,String countryId,String subCycleId,String cycleId)throws Exception{
		
		Connection con = null;
		
		int size=0;

		PreparedStatement sizeOfDeficiency = null;
	
		try {
			con = getConnection();

			sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.PERIOD_ID IN (SELECT LSUB.VALUE FROM LOOKUP LSUB WHERE LSUB.TYPE='DEF_REF_PERIOD') AND DR.COUNTRY_ID=L.VALUE AND DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"."+subCycleId+"%'");
			
			sizeOfDeficiency.setString(1,countryId);
			
			ResultSet rs = sizeOfDeficiency.executeQuery();
			
			while(rs.next()){
				size = rs.getInt("DEFSIZE");
			}
			
			if(size>0){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

		return false;
	}
	
	public boolean isCycleDeficiencyPresent(String periodId,String countryId,String cycleId)throws Exception{
		
		Connection con = null;
		
		int size=0;

		PreparedStatement sizeOfDeficiency = null;
	
		try {
			con = getConnection();

			//sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO,DEF_REF DR WHERE C.CYCLE_ID=? AND C.CYCLE_ID=SC.CYCLE_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND DR.OBJ_COMPOSITE_ID=CO.CTRL_OBJ_ID");
			
			sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.COUNTRY_ID=L.VALUE AND DR.PERIOD_ID IN (SELECT LSUB.VALUE FROM LOOKUP LSUB WHERE LSUB.TYPE='DEF_REF_PERIOD') AND DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"%'");
			
			//sizeOfDeficiency.setString(1,periodId);
			
			sizeOfDeficiency.setString(1,countryId);
			
			ResultSet rs = sizeOfDeficiency.executeQuery();
			
			while(rs.next()){
				size = rs.getInt("DEFSIZE");
			}
			
			if(size>0){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

		return false;
	}
	
	public void updateSubCycleDeficiency(String subCycleId,String value)throws Exception{

		Connection con = null;

		PreparedStatement updateSubCycleDef = null;
	
		try {
			con = getConnection();

			updateSubCycleDef = con.prepareStatement("UPDATE SUB_CYCLE SC SET SC.PREV_DEF=? WHERE SC.SUB_CYCLE_ID=?");
			
			updateSubCycleDef.setString(1,value);
			
			updateSubCycleDef.setString(2,subCycleId);
			
			updateSubCycleDef.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateCycleDeficiency(String cycleId,String value)throws Exception{

		Connection con = null;

		PreparedStatement updateCycleDef = null;
	
		try {
			con = getConnection();

			updateCycleDef = con.prepareStatement("UPDATE CYCLE C SET C.PREV_DEF=? WHERE C.CYCLE_ID=?");
			
			updateCycleDef.setString(1,value);
			
			updateCycleDef.setString(2,cycleId);
			
			updateCycleDef.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	
	
	public List returnControlObjectives()throws Exception{
		
		Connection con = null;
		
		List controlObjectiveList = new ArrayList();

		PreparedStatement selectAllControlObjectives = null;
	
		try {
			con = getConnection();

			selectAllControlObjectives = con.prepareStatement("SELECT CTRL_OBJ_ID FROM CTRL_OBJ");
			
			ResultSet rs = selectAllControlObjectives.executeQuery();
			
			while(rs.next()){
				controlObjectiveList.add(rs.getString("CTRL_OBJ_ID"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return controlObjectiveList;
	}
	
	public boolean isControlObjectiveDeficiencyPresent(String periodId,String countryId,String controlObjectiveid,String subcycleid,String cycleId)throws Exception{
		
		Connection con = null;
		
		int size=0;

		PreparedStatement sizeOfDeficiency = null;
	
		try {
			con = getConnection();

			sizeOfDeficiency = con.prepareStatement("SELECT COUNT(*) AS DEFSIZE FROM DEF_REF DR,LOOKUP L WHERE L.TYPE='COUNTRYID' AND L.NAME=? AND DR.COUNTRY_ID=L.VALUE AND DR.PERIOD_ID IN (SELECT LSUB.VALUE FROM LOOKUP LSUB WHERE LSUB.TYPE='DEF_REF_PERIOD') AND DR.OBJ_COMPOSITE_ID LIKE "+"'%"+cycleId+"."+subcycleid+"."+controlObjectiveid+"%'");
			
			sizeOfDeficiency.setString(1,countryId);
			
			ResultSet rs = sizeOfDeficiency.executeQuery();
			
			while(rs.next()){
				size = rs.getInt("DEFSIZE");
			}
			
			if(size>0){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

		return false;
	}
	
	public void updateControlObjectiveDeficiency(String controlObjectiveId,String value)throws Exception{

		Connection con = null;

		PreparedStatement updateControlObjectiveDef = null;
	
		try {
			con = getConnection();

			updateControlObjectiveDef = con.prepareStatement("UPDATE CTRL_OBJ CO SET CO.PREV_DEF=? WHERE CO.CTRL_OBJ_ID=?");
			
			updateControlObjectiveDef.setString(1,value);
			
			updateControlObjectiveDef.setString(2,controlObjectiveId);
			
			updateControlObjectiveDef.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	

//	public Connection getConnection() throws Exception {
//		Context initContext = new InitialContext();
//		Context envContext = (Context) initContext.lookup("java:/comp/env");
//		DataSource ds = (DataSource) envContext.lookup("jdbc/soxicdb");
//		Connection conn = ds.getConnection();
//		return conn;
//	}	
	
	/**
	 * @return
	 * @throws Exception
	 */
	public Connection getConnection() throws Exception {
		Connection conn=null;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		//**For connecting to DEV Database...
		//System.setProperty("DMONCRYPTJV","C:\\WSTTemp");
		System.setProperty("DMONCRYPTJV",envVariable);
		//String environment="development";
		BufferedReader brIn = null;
		String hexKey = null;
		String keyFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "KeyValue.hex";
		String cipherFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "CipherValue.hex";
		try
		{
			brIn = new BufferedReader(new FileReader(keyFile));
			hexKey = brIn.readLine();
		}
		catch (FileNotFoundException ex)
		{
			throw new EncryptorException("EncryptionUtils::GetDecryptedStringFromExternalStorage - Invalid key file name.");
		}
		
		if(environment.equalsIgnoreCase("development")){
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			conn = DriverManager.getConnection (SoxicUtil.getOracleDevServerConnectionString(), SoxicUtil.getOracleDevServerUserName(), decryptedPassword);
		}

		if(environment.equalsIgnoreCase("test")){
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			//**For connecting to Test Database...
			conn = DriverManager.getConnection (SoxicUtil.getOracleTestServerConnectionString(), SoxicUtil.getOracleTestServerUserName(), decryptedPassword);
		}
		
		if(environment.equalsIgnoreCase("production")){
			
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			//**For connecting to Test Database...
			conn = DriverManager.getConnection (SoxicUtil.getOracleProductionServerConnectionString(),SoxicUtil.getOracleProductionServerUserName(), decryptedPassword);
		}

		//conn = DriverManager.getConnection ("jdbc:oracle:thin:@tst01.monsanto.com:1521:comgent","sarbox_et","sarbox_et_123");
		
		//**For connecting to DEV Database...
		//conn = DriverManager.getConnection (SoxicUtil.getOracleDevServerConnectionString(), SoxicUtil.getOracleDevServerUserName(), SoxicUtil.getOracleDevServerPwd());
		
		//**For connecting to Test Database...
		//conn = DriverManager.getConnection (SoxicUtil.getOracleTestServerConnectionString(), SoxicUtil.getOracleTestServerUserName(), SoxicUtil.getOracleTestServerPwd());
		return conn;
	}			
	/**
	 * @return Returns the environment.
	 */
	public String getEnvironment() {
		return environment;
	}
	/**
	 * @param environment The environment to set.
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
}

