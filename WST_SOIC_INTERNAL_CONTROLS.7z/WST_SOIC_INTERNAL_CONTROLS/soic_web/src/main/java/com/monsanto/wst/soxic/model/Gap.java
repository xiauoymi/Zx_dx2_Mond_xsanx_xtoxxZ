/*
 * Created on Feb 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Gap {
	
	String controlObjectiveId;
	
	List descriptionList= new ArrayList();
	
	String associatedId;
	
	String subCycleId;
	
	List subCycleGapList = new ArrayList();
	
	String cycleId;
	
	List cycleGapList = new ArrayList();
	
	
	/**
	 * @return Returns the associatedId.
	 */
	public String getAssociatedId() {
		return associatedId;
	}
	/**
	 * @param associatedId The associatedId to set.
	 */
	public void setAssociatedId(String associatedId) {
		this.associatedId = associatedId;
	}


	/**
	 * @return Returns the cycleGapList.
	 */
	public List getCycleGapList() {
		return cycleGapList;
	}
	/**
	 * @param cycleGapList The cycleGapList to set.
	 */
	public void setCycleGapList(List cycleGapList) {
		this.cycleGapList = cycleGapList;
	}
	/**
	 * @return Returns the cycleId.
	 */
	public String getCycleId() {
		return cycleId;
	}
	/**
	 * @param cycleId The cycleId to set.
	 */
	public void setCycleId(String cycleId) {
		this.cycleId = cycleId;
	}
	/**
	 * @return Returns the subCycleGapList.
	 */
	public List getSubCycleGapList() {
		return subCycleGapList;
	}
	/**
	 * @param subCycleGapList The subCycleGapList to set.
	 */
	public void setSubCycleGapList(List subCycleGapList) {
		this.subCycleGapList = subCycleGapList;
	}
	/**
	 * @return Returns the subCycleId.
	 */
	public String getSubCycleId() {
		return subCycleId;
	}
	/**
	 * @param subCycleId The subCycleId to set.
	 */
	public void setSubCycleId(String subCycleId) {
		this.subCycleId = subCycleId;
	}
	/**
	 * @return Returns the controlObjectiveId.
	 */
	public String getControlObjectiveId() {
		return controlObjectiveId;
	}
	/**
	 * @param controlObjectiveId The controlObjectiveId to set.
	 */
	public void setControlObjectiveId(String controlObjectiveId) {
		this.controlObjectiveId = controlObjectiveId;
	}
	/**
	 * @return Returns the descriptionList.
	 */
	public List getDescriptionList() {
		return descriptionList;
	}
	/**
	 * @param descriptionList The descriptionList to set.
	 */
	public void setDescriptionList(List descriptionList) {
		this.descriptionList = descriptionList;
	}
	
	public void addGap(String gap,String ownerid){
		
		OwnerGap ownerGap = new OwnerGap();
		
		ownerGap.setGap(gap);
		
		ownerGap.setOwnerid(ownerid);
		
		descriptionList.add(ownerGap);
	}
}
