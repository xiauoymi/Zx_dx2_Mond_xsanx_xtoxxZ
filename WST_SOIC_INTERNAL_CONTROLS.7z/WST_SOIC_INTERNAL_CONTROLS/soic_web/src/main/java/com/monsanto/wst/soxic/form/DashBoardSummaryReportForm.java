/*
 * Created on Jun 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.List;

import org.apache.struts.action.ActionForm;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DashBoardSummaryReportForm extends ActionForm{
	
	List countrySummaryList;
	
	List cycleList;
	
	String selectedPeriod;
	
	
	
	

	/**
	 * @return Returns the selectedPeriod.
	 */
	public String getSelectedPeriod() {
		return selectedPeriod;
	}
	/**
	 * @param selectedPeriod The selectedPeriod to set.
	 */
	public void setSelectedPeriod(String selectedPeriod) {
		this.selectedPeriod = selectedPeriod;
	}
	/**
	 * @return Returns the cycleList.
	 */
	public List getCycleList() {
		return cycleList;
	}
	/**
	 * @param cycleList The cycleList to set.
	 */
	public void setCycleList(List cycleList) {
		this.cycleList = cycleList;
	}
	/**
	 * @return Returns the countrySummaryList.
	 */
	public List getCountrySummaryList() {
		return countrySummaryList;
	}
	/**
	 * @param countrySummaryList The countrySummaryList to set.
	 */
	public void setCountrySummaryList(List countrySummaryList) {
		this.countrySummaryList = countrySummaryList;
	}
}
