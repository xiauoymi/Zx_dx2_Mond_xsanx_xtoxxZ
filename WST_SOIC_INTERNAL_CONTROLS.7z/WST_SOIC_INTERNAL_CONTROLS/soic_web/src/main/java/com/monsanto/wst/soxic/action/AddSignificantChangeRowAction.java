package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.form.SignificantChangeForm;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 9, 2006
 * Time: 4:29:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddSignificantChangeRowAction extends Action {

    String addForward = "newAdd";
    String updateForward = "updateAdd";

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        SignificantChangeForm significantChangeForm = (SignificantChangeForm)request.getSession().getAttribute("sigChangeForm");
        List signChangesList = significantChangeForm.getSignificantChanges();
        String type = request.getParameter("type");
        processExistingRowAndAddNewRowToList(signChangesList, significantChangeForm);
        request.setAttribute("sigChangeForm",significantChangeForm);
        String forward = forwardBasedOnPage(type);
        return mapping.findForward(forward);
    }

    public void processExistingRowAndAddNewRowToList(List signChangesList, SignificantChangeForm significantChangeForm) {
        int size = signChangesList.size();
        SignificantChangeModel significantChangeModel = (SignificantChangeModel)signChangesList.get(size-1);
        String sid = getLastIndexAndIncrement(significantChangeModel);
        createNewSigModelRow(sid, significantChangeModel, signChangesList);
        significantChangeForm.setSignificantChanges(signChangesList);
    }

    public String forwardBasedOnPage(String type) {
        String fwd = "";
        if (type.equalsIgnoreCase("NEW")){
            fwd = addForward;
        }else
        if (type.equalsIgnoreCase("UPDATE")){
            fwd = updateForward;
        }
        return fwd;
    }

    public void createNewSigModelRow(String sid, SignificantChangeModel significantChangeModel, List signChangesList) {
        SignificantChangeModel sigModel = new SignificantChangeModel(sid,"","","","","","");
        sigModel.setSigPeriods(significantChangeModel.getSigPeriods());
        sigModel.setSigTypes(significantChangeModel.getSigTypes());
        sigModel.setAddButton(true);
        signChangesList.add(sigModel);
    }

    public String getLastIndexAndIncrement(SignificantChangeModel significantChangeModel) {
        String id = significantChangeModel.getSeqindex();
        int value = Integer.parseInt(id);
        value++;
        return String.valueOf(value);
    }


}
