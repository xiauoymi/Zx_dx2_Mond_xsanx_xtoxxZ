/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.form;

import java.util.Vector;

import org.apache.struts.action.ActionForm;

/**
 * This is the form bean for /export action.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class ExportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	Vector columnVector = new Vector();	
	RowObject rowObject = new RowObject();	
	String countryId;	
	String worldArea;	
	Vector subCycleOwners = new Vector();	
	Vector cycleOwners = new Vector();

	/**
	 * @return Returns the columnVector.
	 */
	public Vector getColumnVector() {
		return columnVector;
	}
	/**
	 * @param columnVector The columnVector to set.
	 */
	public void setColumnVector(Vector columnVector) {
		this.columnVector = columnVector;
	}
	/**
	 * @return Returns the countryId.
	 */
	public String getCountryId() {
		return countryId;
	}
	/**
	 * @param countryId The countryId to set.
	 */
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	/**
	 * @return Returns the cycleOwners.
	 */
	public Vector getCycleOwners() {
		return cycleOwners;
	}
	/**
	 * @param cycleOwners The cycleOwners to set.
	 */
	public void setCycleOwners(Vector cycleOwners) {
		this.cycleOwners = cycleOwners;
	}
	
	/**
	 * @return Returns the subCycleOwners.
	 */
	public Vector getSubCycleOwners() {
		return subCycleOwners;
	}
	/**
	 * @param subCycleOwners The subCycleOwners to set.
	 */
	public void setSubCycleOwners(Vector subCycleOwners) {
		this.subCycleOwners = subCycleOwners;
	}
	/**
	 * @return Returns the worldArea.
	 */
	public String getWorldArea() {
		return worldArea;
	}
	/**
	 * @param worldArea The worldArea to set.
	 */
	public void setWorldArea(String worldArea) {
		this.worldArea = worldArea;
	}

	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

}