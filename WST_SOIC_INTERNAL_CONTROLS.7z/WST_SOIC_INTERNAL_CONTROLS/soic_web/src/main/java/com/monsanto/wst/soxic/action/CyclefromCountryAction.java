package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.SubCycleDeleteForm;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.exception.NullAndArrayIndexException;
import com.monsanto.wst.soxic.facade.SubCycleMaintainFacade;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 21, 2005
 * Time: 10:18:59 AM
 *
 * This class contains 2 methods. The 1st method selects the cycles based on the
 * country passed in. The 2nd method selects the subcycles corresponding to the
 * first cycle. The country selected is placed into the session so that it can
 * be requested anywhere within the scope. If the cycle, country or subcycle list
 * is empty, a NullAndArrayIndexException is thrown.
 */

public class CyclefromCountryAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        SubCycleDeleteForm subcycledeleteform = (SubCycleDeleteForm)form;
        String countryid = subcycledeleteform.getSelectedCountry();
        subcycledeleteform.setSelectedCountry(countryid);
        SubCycleMaintainFacade subCycleMaintainFacade = new SubCycleMaintainFacade();

        subCycleMaintainFacade.cyclesFromCountry(subcycledeleteform,countryid);
        subCycleMaintainFacade.initialSubcylesSelection(subcycledeleteform);

        return mapping.findForward("cyclelist");
    }
}
