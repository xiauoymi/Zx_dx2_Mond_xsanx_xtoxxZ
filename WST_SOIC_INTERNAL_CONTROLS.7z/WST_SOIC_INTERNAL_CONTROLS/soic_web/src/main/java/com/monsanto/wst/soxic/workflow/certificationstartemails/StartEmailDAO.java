package com.monsanto.wst.soxic.workflow.certificationstartemails;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 27, 2006
 * Time: 5:30:24 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract  class StartEmailDAO {
    public abstract List getStartCurrentLevelList()throws Exception;
}
