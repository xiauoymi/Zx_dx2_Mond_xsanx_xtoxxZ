/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.SoxicBaseModel;

/**
 * @author SPOLAVA
 * OracleAbstractDAO class implements the DAO class. 
 * 
 * <br>Any class that needs to implement the persistant(CRUD)methods can extend this class.
 *  
 * <br>This class has generic methods like create, retreive, update and delete which can be used by 
 * any class that uses this class as the base class. These methods are used to 
 * create, retreive, update and delete data rows from and into the database.
 *   
 * <br>Specific methods like buildSelectQuery and so on are made abstract so that
 * the class that extends OracleAbstractDAO can define their own.
 * 
 * <br> OracleAbstractDAO inturn is extended by all the DAO Classes like OracleSubCycleDAO, 
 * OracleControlObjectiveDAO, OracleActivityDAO and so on. 
 * 
 */
public abstract class OracleAbstractDAO implements DAO {
    
    /**
	 * This method creates a collection of records.
	 * @param baseModels-is the collection of base models that needs to be created. 
	 * @throws DatabaseException.
	 */
	public void create(Collection baseModels) throws DatabaseException {
	
	}

	/**
	 * This method retrives a record if the search criteria matches any
	 * of the records in the database.
	 * @param fields-Map of the search criteria by which records will be retrieved.
	 * @return collection of records if there are any matches
	 */
	public Collection retrieveByCriteria(Map fields) throws DatabaseException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		
		Collection resultList = new ArrayList();

		String query = buildSelectQuery(fields);

		try {
			connection = SoxicConnectionFactory.getSoxicConnection();
			preparedStatement = connection.prepareStatement(query);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				resultList.add(populateModel(resultset));
			}
		} 
		catch (SQLException e) {
			throw new DatabaseException(e.getMessage());
		} 
		catch (Exception e) {
			throw new DatabaseException(e.getMessage());
		} 
		finally {
			try {
				if (resultset != null)
					resultset.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				throw new DatabaseException("OracleDAO - Unable to close database connection : "
						+ e.toString());
			}
		}
		return resultList;
	}
	
	public abstract void update(Collection soxicBaseModels) throws DatabaseException, Exception;
	
//	/**
//	 * This method updates a collection of records.
//	 * @param baseModels-collection of records that need to be updated
//	 * @throws DatabaseException. 
//	 */
//	public void update(Collection baseModels) throws DatabaseException {
//		
//	}
//
//	/**
//	 * This method updates a collection of records
//	 * @param baseModel
//	 * @param fields
//	 * @throws DatabaseException. 
//	 * @return the number of rows updated
//	 */
//	public int update(SoxicBaseModel baseModel, Map fields) throws Exception {
//	
//	}
//	
//	/**
//	 * This method delete a collection of records
//	 * @param baseModel-collection of records that needs to be deleted.
//	 * @throws DatabaseException. 
//	 */
//	public void delete(Collection baseModels) throws DatabaseException {
//		
//
//	}
	
	
	/**
	 * This abstract method buildselectQuery for retrieving data from model .
	 * @throws Exception. 
	 */
	protected abstract String buildSelectQuery(Map fields);
	
	//protected abstract String buildUpdateQuery(SoxicBaseModel baseModel);
	
	/**
	 * This abstract method buildInsertQuery based on resultset.
	 * @throws SqlException,Exception . 
	 */
	protected abstract SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception;

//	/**
//	 * This abstract method buildUpdateQuery for update 1.
//	 * @throws Exception . 
//	 */	
//	protected abstract String buildUpdateQuery(SoxicBaseModel model) throws Exception;
//	
//	/**
//	 * This abstract method buildUpdateQuery for update 2 based on model and map fields.
//	 * @throws Exception . 
//	 */	
//	protected abstract String buildUpdateQuery(SoxicBaseModel model, Map fields) throws Exception;
	
	

}
