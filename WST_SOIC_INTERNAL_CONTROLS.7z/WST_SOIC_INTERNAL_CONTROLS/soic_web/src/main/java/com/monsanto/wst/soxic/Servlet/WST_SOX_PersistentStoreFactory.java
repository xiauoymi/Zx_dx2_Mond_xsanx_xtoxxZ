package com.monsanto.wst.soxic.Servlet;

import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.dbdataservices.PersistentStoreOracleType4;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType4;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 9:47:17 AM
 * To change this template use File | Settings | File Templates.
 */
public class WST_SOX_PersistentStoreFactory {

    private static PersistentStore RetVal;

        /**
     * Returns a Persistent Store.
     *
     * @param cstrResourceBundleName The name of the resource bundle that points
     *                               to the correct database.
     * @return A PersistentStore object.
     * @throws com.monsanto.dataservices.WrappingException
     */
    public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
        Logger.traceEntry();

        String encryptedPassword = PasswordEncryptionUtil.getEncryptedPassword(cstrResourceBundleName);
//            encryptedPassword="sarbox_et_123";
        String userName = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"UserName");
        String sid = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"DataSource");
        String server = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"Server");
        //PersistentStore RetVal = new PersistentStoreOracleCachedType2(cstrResourceBundleName);
//        PersistentStore RetVal = new PersistentStoreOracleType4(userName,encryptedPassword,sid,1521,server);
        return getStoreInstance(userName, encryptedPassword, sid, server);
    }

    public static PersistentStore getStore() throws WrappingException {
        Logger.traceEntry();
        String cstrResourceBundleName="com.monsanto.wst.soxic.Servlet.WST_SOX";
        String encryptedPassword = PasswordEncryptionUtil.getEncryptedPassword(cstrResourceBundleName);
//        encryptedPassword="sarbox_et";
        String userName = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"UserName");
        String sid = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"DataSource");
        String server = PropertyFileUtil.getSystemProperty(cstrResourceBundleName,"Server");
        //PersistentStore RetVal = new PersistentStoreOracleCachedType2(cstrResourceBundleName);
//        PersistentStore RetVal = new PersistentStoreOracleType4(userName,encryptedPassword,sid,1521,server);
//        return (PersistentStore) Logger.traceExit(RetVal);
        return getStoreInstance(userName, encryptedPassword, sid, server);
    }

    private static PersistentStore getStoreInstance(String userName, String encryptedPassword, String sid, String server) throws WrappingException {
//        if (RetVal == null) {
//            RetVal = new PersistentStoreOracleCachedType2(userName,encryptedPassword,sid,0,10);
//        }  
        if (RetVal == null) {
            RetVal = new PersistentStoreOracleCachedType4(userName,encryptedPassword,sid,1521,server,0,10);
        }
        return (PersistentStore) Logger.traceExit(RetVal);
    }
}
