package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 11, 2005
 * Time: 2:18:03 PM
 */

public class InvalidCertificationStateException extends Exception{
    public InvalidCertificationStateException(){
        super();
    }

    public InvalidCertificationStateException(Exception e){
        super(e);
    }
}
