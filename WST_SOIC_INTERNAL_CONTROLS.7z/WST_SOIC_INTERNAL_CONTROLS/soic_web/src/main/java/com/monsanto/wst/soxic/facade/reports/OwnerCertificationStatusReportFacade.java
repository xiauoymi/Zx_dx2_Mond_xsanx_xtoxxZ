package com.monsanto.wst.soxic.facade.reports;

import com.monsanto.wst.soxic.model.OwnerCertStatusDAO;
import com.monsanto.wst.soxic.form.OwnerCertificationStatusReportForm;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 9:55:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerCertificationStatusReportFacade {

    OwnerCertStatusDAO ownerCertStatusDAO = new OwnerCertStatusDAO();

    public List getCyclesForOwner(String ownerid, String periodId) throws Exception {
        return getAllCyclesForSelectedOwner(ownerid,periodId);
    }

    protected List getAllCyclesForSelectedOwner(String ownerid, String periodId) throws Exception {
        return ownerCertStatusDAO.getCycleList(ownerid,periodId);
    }

    public List getSubCyclesForOwner(String ownerid, String periodId) throws Exception {
        return getAllSubCyclesForSelectedOwner(ownerid,periodId);
    }

    protected List getAllSubCyclesForSelectedOwner(String ownerid, String periodId) throws Exception {
        return ownerCertStatusDAO.getSubcycleList(ownerid,periodId);
    }

    public List getActivitiesForOwner(String ownerid, String periodId) throws Exception {
        return getAllActivitiesForSelectedOwner(ownerid,periodId);
    }

    protected List getAllActivitiesForSelectedOwner(String ownerid, String periodId) throws Exception {
        return ownerCertStatusDAO.getActivityList(ownerid,periodId);
    }

    public void setAssignmentsIntoCorrespondingLists(List owner_cycles, OwnerCertificationStatusReportForm ownerCertificationStatusReportForm, List owner_subcycles, List owner_activities) {
        if (owner_cycles!=null && owner_cycles.size()>0){
            ownerCertificationStatusReportForm.setCycles(owner_cycles);
        }
        if (owner_subcycles!=null && owner_subcycles.size()>0){
            ownerCertificationStatusReportForm.setSub_cycles(owner_subcycles);
        }
        if (owner_activities!=null && owner_activities.size()>0){
            ownerCertificationStatusReportForm.setActivities(owner_activities);
        }
    }

}
