package com.monsanto.wst.soxic.audit.dao;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 16, 2009
 * Time: 11:18:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommentLineSplitterThree implements CommentLineSplitter {
  public String[] getEachCommentAsAString(String issueChunk, String type) {
    return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
  }

  public List buildXML(String[] data, StringBuffer issuesBuffer, String originTitle, StringBuffer errorBuffer) throws Exception {
    return new ArrayList();  //To change body of implemented methods use File | Settings | File Templates.
  }
}
