/*
 * Created on Mar 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.AdminNewsForm;
import com.monsanto.wst.soxic.model.AdminNews;
import com.monsanto.wst.soxic.model.NewsItem;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminNewsUpdateAction extends Action {
    
    public ActionForward execute(ActionMapping mapping, 
			 ActionForm form,
			 HttpServletRequest request, 
			 HttpServletResponse response) {

        AdminNewsForm newsForm = (AdminNewsForm)form;
        
        try {
            updateData(newsForm);
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return mapping.findForward("success");
    }
    
    private void updateData(AdminNewsForm form) throws DatabaseException{
        
       NewsItem news = new NewsItem();
       news.setId(form.getId());
       news.setBody(form.getBody());
       news.setAssignedRoles(Arrays.asList(form.getAssignedRoles()));
       
       AdminNews.update(news);
       
       
    }
}
