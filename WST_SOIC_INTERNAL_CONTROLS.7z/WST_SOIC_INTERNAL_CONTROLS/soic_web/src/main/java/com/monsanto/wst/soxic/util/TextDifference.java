package com.monsanto.wst.soxic.util;

import com.monsanto.wst.textutil.textdiff.FormattedResult;
import com.monsanto.wst.textutil.textdiff.DifferenceAnnotator;


/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 21, 2008
 * Time: 10:56:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class TextDifference {
    private FormattedResult result;

    public String highlightTextDifferences(String oldText, String newText) {
        DifferenceAnnotator diff = new DifferenceAnnotator();
        FormattedResult result = diff.annotate(oldText, newText);
        String before = result.getBefore();
        if (before.equals(newText))
            return "No change in text requested.";
        else
            return result.getBefore();
    }

    public FormattedResult getResult() {
        return result;
    }

    public void setResult(FormattedResult result) {
        this.result = result;
    }
}
