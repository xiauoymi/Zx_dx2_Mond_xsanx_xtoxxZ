package com.monsanto.wst.soxic.action;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.soxic.audit.util.FileUtil;
import com.monsanto.wst.soxic.form.ExportAuditForm;
import com.monsanto.wst.soxic.facade.ExportAuditFacade;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.FileInputStream;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Oct 17, 2008
 * Time: 3:29:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportAuditAction extends DispatchAction {
  private ExportAuditFacade facade;

  public ExportAuditAction(ExportAuditFacade facade) {
    this.facade = facade;
  }

  public ExportAuditAction() {
    facade = new ExportAuditFacade();
  }

  public ActionForward doExport(ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response) throws Exception {
    String period = ((ExportAuditForm) form).getPeriod();
    String forward = "";
    if (!StringUtils.isNullOrEmpty(period)) {
      String result = prepareSubCycleXml(period);
      if ("ImportSuccess".equalsIgnoreCase(result)) {
        request.setAttribute("ERROR_MESSAGE", "Sub-cycles imported successfully for the quarter :" + period);
        request.setAttribute("FILE_LOC", FileUtil.getFileLocation());
        forward = "success";
      } else if ("NoSubCycles".equalsIgnoreCase(result)) {
        request.setAttribute("ERROR_MESSAGE", "No Sub Cycles present, for the period :" + period);
        forward = "failure";
      } else {
        request.setAttribute("ERROR_MESSAGE", result);
        forward = "failure";
      }
    }
    return mapping.findForward(forward);
  }

  private String prepareSubCycleXml(String period) throws Exception {
    facade = new ExportAuditFacade();
    return facade.prepareSubCycleString(period.trim().toUpperCase());
  }

  public ActionForward writeResponse(ActionMapping mapping,
                                     ActionForm form,
                                     HttpServletRequest request,
                                     HttpServletResponse response) throws Exception {
    ServletOutputStream out = response.getOutputStream();

    response.setHeader("Content-disposition", "attachment; filename=AuditExport.xml");
    response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
    response.setHeader("Expires", "0");
    response.setContentType("text/xml");
    BufferedInputStream input = new BufferedInputStream(new FileInputStream(FileUtil.getFileLocation()));
    int ch;
    while ((ch = input.read()) != -1) {
      out.write((char) ch);
    }
    input.close();
    out.flush();
    out.close();
    return mapping.findForward("ImportSuccess");
  }
}
