package com.monsanto.wst.soxic.audit;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 1:21:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@Table(schema = "SARBOX_ET", name = "CYCLE")
public class CycleObj implements Serializable{

  @Id
  @Column(name="CYCLE_ID")
  private String cycleId;

  @Column(name = "CYCLE_CODE")
  private String cycleCode;

  @Column(name = "WORLD_AREA_ID")
  private String worldAreaId;

  @Column(name = "COUNTRY_ID")
  private String countryId;

  @Column(name = "PERIOD_ID")
  private String periodId;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "OVERFLOW_ID",nullable = true)
  private Integer overFlowId;

  @Column(name = "STATUS")
  private String status;

  @Column(name = "POTENTIAL_GAP")
  private String gap;

  @Column(name = "PREV_DEF")
  private String deficiency;

  @OneToMany(mappedBy = "cycle", targetEntity = SubCycleObj.class, fetch = FetchType.LAZY)
  private List<SubCycleObj> subCycles = new ArrayList<SubCycleObj>();

  @OneToMany(mappedBy = "cycleId",targetEntity = OwnerCycleObj.class,fetch = FetchType.LAZY)
  private List<OwnerCycleObj> owner = new ArrayList<OwnerCycleObj>();

  
  public List<OwnerCycleObj> getOwner() {
    return owner;
  }

  public void setOwner(List<OwnerCycleObj> owner) {
    this.owner = owner;
  }

  @OneToOne
  @JoinColumn(name = "CYCLE_ID")
  private CycleStateObj cycleState;

  public String getCycleId() {
    return cycleId;
  }

  public void setCycleId(String cycleId) {
    this.cycleId = cycleId;
  }


  public String getCycleCode() {
    return cycleCode;
  }

  public void setCycleCode(String cycleCode) {
    this.cycleCode = cycleCode;
  }


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public String getDeficiency() {
    return deficiency;
  }

  public void setDeficiency(String deficiency) {
    this.deficiency = deficiency;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }



 

  public String getPeriodId() {
    return periodId;
  }

  public void setPeriodId(String periodId) {
    this.periodId = periodId;
  }


  public String getWorldAreaId() {
    return worldAreaId;
  }

  public void setWorldAreaId(String worldAreaId) {
    this.worldAreaId = worldAreaId;
  }


  public String getCountryId() {
    return countryId;
  }

  public void setCountryId(String countryId) {
    this.countryId = countryId;
  }


  public Integer getOverFlowId() {
    return overFlowId;
  }

  public void setOverFlowId(Integer overFlowId) {
    this.overFlowId = overFlowId;
  }
   

  public List<SubCycleObj> getSubCycles() {
    return subCycles;
  }

  public void setSubCycles(List<SubCycleObj> subCycles) {
    this.subCycles = subCycles;
  }


  public CycleStateObj getCycleState() {
    return cycleState;
  }

  public void setCycleState(CycleStateObj cycleState) {
    this.cycleState = cycleState;
  }
}
