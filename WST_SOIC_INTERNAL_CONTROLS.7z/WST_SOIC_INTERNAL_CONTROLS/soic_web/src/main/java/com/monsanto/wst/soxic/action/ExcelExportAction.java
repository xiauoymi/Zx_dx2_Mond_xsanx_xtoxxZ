/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/

package com.monsanto.wst.soxic.action;

import java.io.BufferedOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ReportForm;

/**
 * This is the action that exports to the excel file.
 * Export2Excel is a helper class to this.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class ExcelExportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)throws Exception {
		
		ActionErrors errors = new ActionErrors();
		ReportForm reportForm = (ReportForm) form;
		
	
		if (!errors.isEmpty()) {
	        saveErrors(request, errors);
	        reportForm.setFileName("");
	        return mapping.findForward("faliure");
	     }
		
		
		//**Exporting the report to an Excel Style Sheet*
		
//		String autoFilename = reportForm.getPeriodID() + "." +
//							  reportForm.getCountryId() + "." +
//							  reportForm.getSubCycleID() + "." +
//							  reportForm.getSubCycleDesc();
		
		String autoFilename = reportForm.getSubCycleID() + "." +
							  reportForm.getSubCycleDesc();

		
		//autoFilename = "Export";
		
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-disposition", "filename=" +autoFilename+".xls");
		
		ServletOutputStream sos = response.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(sos);
		
		
		Export2Excel export2Excel = new Export2Excel(autoFilename+1);
		
		export2Excel.setBos(bos);
		export2Excel.setColumnVector(reportForm.getColumnVector());
		export2Excel.setCountryId(reportForm.getCountryId());
		export2Excel.setCycleOwners(reportForm.getCycleOwners());
		export2Excel.setSubCycleOwners(reportForm.getSubCycleOwners());
		export2Excel.setWorldArea(reportForm.getWorldArea());		
		export2Excel.setCycleDesc(reportForm.getCycleDesc());
		export2Excel.setSubCycleDesc(reportForm.getSubCycleDesc());
		export2Excel.setCycleOwnerList(reportForm.getCycleOwnerList());
		export2Excel.setSubCycleOwnerList(reportForm.getSubCycleOwnerList());
        export2Excel.setGap_Description(reportForm.getGap_description());


		export2Excel.export();
		
		//*****************************************************************************
		
		logger.info("-> Excel file created in " + autoFilename);
		
		//response.setContentType("application/vnd.ms-excel");
		
		reportForm.setFileName("");
		
		
		

		bos = export2Excel.getBos();
		
		bos.flush();
		bos.close();
		sos.close();

		
		return mapping.findForward("success");
	}

}