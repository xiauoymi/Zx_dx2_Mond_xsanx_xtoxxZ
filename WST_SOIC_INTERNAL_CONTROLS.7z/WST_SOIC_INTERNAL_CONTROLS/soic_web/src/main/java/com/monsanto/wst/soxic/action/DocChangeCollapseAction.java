package com.monsanto.wst.soxic.action;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.ControlObjective;

import java.util.Map;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 25, 2005
 * Time: 10:46:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocChangeCollapseAction extends Action{
    	/**
	 * Method execute
	 *
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {

		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) form;

		Map map = request.getParameterMap();
		ControlObjective co = null;
		int changedLevel = controlObjectiveForm.getLevel();
		changedLevel = changedLevel - 1;
		ArrayList controllist = (ArrayList) controlObjectiveForm
				.getControlObjectiveList();
		for (int i = 0; i < controllist.size(); i++) {
			if (changedLevel == i) {
				co = (ControlObjective) controllist.get(i);
				String expcol = controlObjectiveForm.getExpcol();
				if (expcol.equalsIgnoreCase("true")) {

					co.setExpanded(true);
				} else {
					co.setExpanded(false);
				}
			}
		}
		ActionForward forward = new ActionForward();
		forward = mapping.findForward("success");
		return forward;
	}
}
