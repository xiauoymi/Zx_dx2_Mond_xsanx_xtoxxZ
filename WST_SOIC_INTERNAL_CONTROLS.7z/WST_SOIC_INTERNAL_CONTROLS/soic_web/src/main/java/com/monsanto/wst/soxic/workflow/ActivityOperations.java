/*
* Created on Mar 2, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.EmailWrapper;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.persistance.EmailHeaderDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.exception.BadDataException;
import com.monsanto.Util.StringUtils;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivityOperations {


    public static void main(String args[]) throws Exception{
        ActivityOperations activityOperations = new ActivityOperations();
    }

    /**
     * Sends email to activity owners and then to sub-cycle owners for activity owner's who are past due.
     * @throws Exception
     */
    public void sendOverDueNotificationEmail()throws Exception{

        EmailWrapper emailWrapper = new EmailWrapper();

        List dueDateList = new ArrayList();

        List ownerList = new ArrayList();

        List activityList = getOverDueActivityList();

        //Map ownerMap = processStartActivityList(activityList);
        Map ownerMap = processOverDueActivityList(activityList);

        Iterator iterator = ownerMap.values().iterator();

        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)iterator.next();
            emailWrapper.setEmailAddress(ownerWrapper.getEmailid());
            SarboxMailComponent.workFlowEmail(SarboxMailComponent.WORKFLOW_PAST_DUE_CURRENT_LEVEL,SoxicConstants.ACTIVITY,emailWrapper);
            dueDateList.add(ownerWrapper.getDateString());
            ownerList.add(ownerWrapper.getOwnerName());
        }
        UtilDAO utilDAO = new UtilDAO();
        Map ownerSubCycleMap = utilDAO.getOverDueUpperLevelOwnerWrapper(SoxicConstants.ACTIVITY);

        Iterator ownerSubCycleIterator = ownerSubCycleMap.values().iterator();

        while(ownerSubCycleIterator.hasNext()){
            OwnerWrapper ownerWrapper =(OwnerWrapper)ownerSubCycleIterator.next();
            emailWrapper.setEmailAddress(ownerWrapper.getEmailid());
            List activityOwnerPastDueList = utilDAO.getOverDueOwnersPerSubCycleOwner(ownerWrapper.getOwnerid());
            List justOwnerList = getOwnerList(activityOwnerPastDueList);
            emailWrapper.setOwnerList(justOwnerList);
            SarboxMailComponent.workFlowEmail(SarboxMailComponent.WORKFLOW_PAST_DUE_UPPER_LEVEL,SoxicConstants.ACTIVITY,emailWrapper);
        }

    }

    public List getOwnerList(List ownerWrapperList){
        List tempList = new ArrayList();
        Iterator iterator = ownerWrapperList.iterator();
        while(iterator.hasNext()){
            OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
            tempList.add(ownerWrapper.getOwnerName());
        }
        return tempList;
    }

    public Map processStartActivityList(List activityList)throws Exception{
        Iterator iterator = activityList.iterator();
        Map activityOwnerMap = new HashMap();
        while(iterator.hasNext()){
            Activity activity = (Activity)iterator.next();
            if(!activityOwnerMap.containsKey(activity.getOwner_id())){
                OwnerWrapper ownerWrapper = getActivityDetailsForOwnerStartDateToday(activity);
                activityOwnerMap.put(activity.getOwner_id(),ownerWrapper);
            }
        }
        return activityOwnerMap;

    }

    protected OwnerWrapper getActivityDetailsForOwnerStartDateToday(Activity activity) throws Exception {
        UtilDAO utilDAO = new UtilDAO();
        OwnerWrapper ownerWrapper = utilDAO.getActivityDetailsForOwnerWhoseStartDateIsToday(activity.getOwner_id());
        return ownerWrapper;
    }

    public Map processOverDueActivityList(List activityList)throws Exception{

        Iterator iterator = activityList.iterator();
        UtilDAO utilDAO = new UtilDAO();
        Map activityOwnerMap = new HashMap();

        while(iterator.hasNext()){

            Activity activity = (Activity)iterator.next();
            if(!activityOwnerMap.containsKey(activity.getOwner_id())){
               OwnerWrapper ownerWrapper = utilDAO.getActivityStartOwnerWrapper(activity.getOwner_id());
                //OwnerWrapper ownerWrapper = utilDAO.getActivityDetailsForOwnerWhoseStartDateIsToday(activity.getOwner_id());
                activityOwnerMap.put(activity.getOwner_id(),ownerWrapper);
            }

        }

        return activityOwnerMap;

    }

    public void updateActivityStatus() throws Exception{

        List activityList = getEmailOwnerActivityList();

        processActivityStatus(activityList);

        updateStatus(activityList);

        email(activityList);

    }

    public List getActivityList()throws Exception{

        List activityList = new ArrayList();

        Connection con = null;

        PreparedStatement updateActivityStatus = null;

        try {
            con = getConnection();

            updateActivityStatus = con.prepareStatement("SELECT * FROM OWNER_ACTIVITY");

            ResultSet rs = updateActivityStatus.executeQuery();

            while(rs.next()){
                populateActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public List getEmailOwnerActivityList()throws Exception{

        List activityList = new ArrayList();


        PreparedStatement updateActivityStatus = null;

        Connection con = getConnection();
        try {
           updateActivityStatus = con.prepareStatement
                            ("SELECT OA.ACTIVITY_ID,OA.OWNER_ID,OA.STATUS,OA.START_DATE,OA.DUE_DATE,OA.COMPLETE_DATE,OA.MOD_DATE,OA.MOD_USER,O.EMAIL FROM " +
                            "OWNER_ACTIVITY OA,OWNER O, ACTIVITY A, CTRL_OBJ CO, SUB_CYCLE SC, CYCLE C, CYCLE_STATE CS " +
                            "WHERE OA.OWNER_ID=O.OWNER_ID " +
                            "AND OA.ACTIVITY_ID = A.ACTIVITY_ID " +
                            "AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
                            "AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
                            "AND SC.CYCLE_ID = C.CYCLE_ID " +
                            "AND C.CYCLE_ID = CS.CYCLE_ID " +
                            "AND CS.STATE = '"+SoxicConstants.CERTIFICATION_STATE+"'");

            ResultSet rs = updateActivityStatus.executeQuery();

            while(rs.next()){
                populateOwnerActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
//            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    private void populateOwnerActivityList(ResultSet rs, List activityList)throws Exception {
         Activity activity = new Activity();
        activity.setActivity_id(rs.getString("ACTIVITY_ID"));
        activity.setOwner_id(rs.getString("OWNER_ID"));
        activity.setStatus(rs.getString("STATUS"));
        activity.setStart_date(rs.getDate("START_DATE"));
        activity.setDue_date(rs.getDate("DUE_DATE"));
        activity.setComplete_date(rs.getDate("COMPLETE_DATE"));
        activity.setMod_date(rs.getDate("MOD_DATE"));
        activity.setMod_user(rs.getString("MOD_USER"));
        activity.setOwnerEmailId(rs.getString("EMAIL"));
        activity.setSubCycleId(activity.getActivity_id());
        activityList.add(activity);
    }

    protected List getStartActivityList()throws Exception{

        List activityList = new ArrayList();

        Connection con = null;

        PreparedStatement updateActivityStatus = null;

        try {
            con = getConnection();

            updateActivityStatus = con.prepareStatement("SELECT * FROM OWNER_ACTIVITY OA WHERE OA.START_DATE=?");

            updateActivityStatus.setDate(1,new Date(System.currentTimeMillis()));

            ResultSet rs = updateActivityStatus.executeQuery();

            while(rs.next()){
                populateActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public List getOverDueActivityList()throws Exception{

        List activityList = new ArrayList();

        Connection con = null;

        PreparedStatement preparedStatement = null;

        try {
            con = getConnection();

            preparedStatement = con.prepareStatement("SELECT * FROM OWNER_ACTIVITY OA WHERE OA.DUE_DATE<? AND OA.STATUS <> 'G_COMPLETE'");

            preparedStatement.setDate(1,new Date(System.currentTimeMillis()));

            ResultSet rs = preparedStatement.executeQuery();

            while(rs.next()){
                populateActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public Connection getConnection() throws Exception {
        return SoxicConnectionFactory.getSoxicConnection();
    }

    public void populateActivityList(ResultSet rs,List activitylist)throws Exception{
        Activity activity = new Activity();
        activity.setActivity_id(rs.getString("ACTIVITY_ID"));
        activity.setOwner_id(rs.getString("OWNER_ID"));
        activity.setStatus(rs.getString("STATUS"));
        activity.setStart_date(rs.getDate("START_DATE"));
        activity.setDue_date(rs.getDate("DUE_DATE"));
        activity.setComplete_date(rs.getDate("COMPLETE_DATE"));
        activity.setMod_date(rs.getDate("MOD_DATE"));
        activity.setMod_user(rs.getString("MOD_USER"));
        activitylist.add(activity);

    }

    public void processActivityStatus(List activityList){

        Iterator activityListIterator = activityList.iterator();

        while(activityListIterator.hasNext()){

            Activity activity = (Activity)activityListIterator.next();

            Date currentDate = new Date(System.currentTimeMillis());

            Long yellowValue = new Long(SoxicUtil.getYellowPeriod());

            Long redValue = new Long(SoxicUtil.getRedPeriod());

            Date yellowDate = new Date(System.currentTimeMillis()
                    + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

            Date redDate = new Date(System.currentTimeMillis()
                    + (redValue.longValue() * 24 * 60 * 60 * 1000));

            Date date = activity.getDue_date();

            if(date!=null && !activity.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
                boolean valueone = date.before(redDate);

                boolean valuetwo = date.before(yellowDate);

                if(date.before(redDate) && toModify(activity.getStatus(),"R_")){
                    activity.setStatus("R_"+getStatusToAppend(activity.getStatus()));
                    activity.setToupdate(true);
                }else{
                    if(date.before(yellowDate) && date.after(redDate) && toModify(activity.getStatus(),"Y_")){
                        activity.setStatus("Y_"+getStatusToAppend(activity.getStatus()));
                        activity.setToupdate(true);
                    }

                    if(date.after(yellowDate) && toModify(activity.getStatus(),"G_")){
                        activity.setStatus("G_"+getStatusToAppend(activity.getStatus()));
                        //activity.setStatus(SoxicConstants.GREEN_COMPLETE);
                        activity.setToupdate(true);
                    }
                }
            }
        }
    }

    public void updateStatus(List activityList)throws Exception{
        Iterator activityListIterator = activityList.iterator();
        Connection conn = null;
        try{
          conn = getConnection();
          while(activityListIterator.hasNext()){
            Activity activity = (Activity)activityListIterator.next();
            if(activity.isToupdate()){
              updateActivity(activity,conn);
            }
          }
        }catch(Exception e){
           e.printStackTrace();
        }finally{
          try{
            closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources :ActivityOperations.updateStatus()");
          }
        }
    }

    public void updateActivity(Activity activity, Connection con)throws Exception{
        PreparedStatement updateActivity = null;
        try {
            updateActivity = con.prepareStatement("UPDATE OWNER_ACTIVITY OA SET OA.STATUS=? WHERE OA.OWNER_ID=? AND OA.ACTIVITY_ID=?");
            updateActivity.setString(1,activity.getStatus());
            updateActivity.setString(2,activity.getOwner_id());
            updateActivity.setString(3,activity.getActivity_id());
            updateActivity.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {

            try {
               closeResources(null,null,updateActivity);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void email(List activityList)throws Exception{

        UtilDAO utilDAO = new UtilDAO();
        Iterator activityListIterator = activityList.iterator();

        Map activityOwnerMap = new HashMap();

        while(activityListIterator.hasNext()){

            Activity activity = (Activity)activityListIterator.next();

            if(activity.isToupdate()){
                if(activityOwnerMap.containsKey(activity.getOwner_id())){
                    OwnerWrapper ownerWrapper = (OwnerWrapper) activityOwnerMap.get(activity.getOwner_id());
                    ownerWrapper.setOwnerid(activity.getOwner_id());
                    ownerWrapper.setEmailid(activity.getOwnerEmailId());
                    if(!ownerWrapper.getSubCycleList().contains(activity.getSubCycleId())){
                        String subcycleid = ownerWrapper.getSubCycleString()+","+activity.getSubCycleId();
                        ownerWrapper.setSubCycleString(subcycleid);
                        ownerWrapper.addSubToList(activity.getSubCycleId());
                    }

                    if(!ownerWrapper.getDueDate().contains(""+activity.getDue_date())){
                        String duedate = ownerWrapper.getDateString()+","+activity.getDue_date();
                        ownerWrapper.setDateString(duedate);
                        ownerWrapper.addDueDateToList(""+activity.getDue_date());
                    }

                    activityOwnerMap.put(activity.getOwner_id(),ownerWrapper);
                }else{
                     OwnerWrapper ownerWrapper  = new OwnerWrapper();
                    ownerWrapper.setOwnerid(activity.getOwner_id());
                    ownerWrapper.setEmailid(activity.getOwnerEmailId());
                    String subcycleid = activity.getSubCycleId();
                    String duedate = ""+activity.getDue_date();
                    ownerWrapper.setSubCycleString(subcycleid);
                    ownerWrapper.addSubToList(subcycleid);
                    ownerWrapper.setDateString(duedate);
                    ownerWrapper.addDueDateToList(duedate);
                    //activityOwnerMap.put(activity.getOwner_id(),utilDAO.getEmailAddress(activity.getOwner_id()));
                    //activityOwnerMap.put(activity.getOwner_id(),utilDAO.getStatusChangeOwnerWrapper(activity.getOwner_id()));
                    activityOwnerMap.put(activity.getOwner_id(),ownerWrapper);
                }
            }
        }
        sendEmail(activityOwnerMap);
    }

    public void sendEmail(Map ownerMap){
        try{
            Iterator ownerActivityIterator = ownerMap.values().iterator();

            while(ownerActivityIterator.hasNext()){
                OwnerWrapper ownerWrapper =(OwnerWrapper)ownerActivityIterator.next();
                SarboxMailComponent.sendStatusChangeWorkFlowEmail(SoxicConstants.ACTIVITY,ownerWrapper.getEmailid(),ownerWrapper.getSubCycleString(),ownerWrapper.getDateString());
            }
        }catch(Exception e){

        }
//		try{
//			if(emailMap.size()>0){
//				SarboxMailComponent.sendStatusChangeWorkFlowEmail(SoxicConstants.ACTIVITY,);
//			}
//
//		}catch(Exception e){
//
//		}
    }

    public String getStatusToAppend(String currentStatus){
        if(currentStatus.indexOf("_")>0){
            return currentStatus.substring(currentStatus.indexOf("_")+1,currentStatus.length());
        }
        return currentStatus;
    }

    public boolean toModify(String currentStatus,String currentString){
        if(currentStatus.indexOf(currentString)<0){
            return true;
        }
        return false;
    }

    //----New Code

    public void updateOverAllActivityStatus()throws Exception{
        List overAllActivityList = activityList();
        Iterator iterator = overAllActivityList.iterator();
        Activity activity = null;
        Connection conn = null;
        try{
          conn = getConnection();
          while(iterator.hasNext()){
            activity = (Activity)iterator.next();
            String status = getOwnerActivityStatus(activity.getActivity_id(),conn);
            String actStatus = activity.getStatus();
            if(StringUtils.isNullOrEmpty(actStatus)){
              actStatus = status;
              updateOverAllActivityStatus(activity.getActivity_id(),actStatus,conn);
            }
            if(status!=null && actStatus!=null){
              if(!status.equalsIgnoreCase(actStatus)){
                updateOverAllActivityStatus(activity.getActivity_id(),status,conn);
              }
            }
          }
        }catch(Exception e){
         e.printStackTrace();
        }finally{
          try{
            closeResources(conn,null,null);
          }catch(SQLException sqlEx){
            throw new Exception("Unable to close resources : ActivityOperations.updateOverAllActivityStatus()");
          }
        }
    }

    public List activityList()throws Exception{
        List activityList = new ArrayList();

        Connection con = null;

        PreparedStatement updateActivityStatus = null;

        try {
            con = getConnection();

            updateActivityStatus = con.prepareStatement("SELECT * FROM ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE_STATE CS WHERE A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND SC.CYCLE_ID =CS.CYCLE_ID AND CS.STATE='CERTIFICATION'");

            ResultSet rs = updateActivityStatus.executeQuery();

            while(rs.next()){
                populateOverAllActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    public void populateOverAllActivityList(ResultSet rs,List activityList)throws Exception{
        Activity activity = new Activity();
        activity.setActivity_id(rs.getString("ACTIVITY_ID"));
        activity.setStatus(rs.getString("STATUS"));
        activity.setMod_date(rs.getDate("MOD_DATE"));
        activity.setMod_user(rs.getString("MOD_USER"));
        activityList.add(activity);
    }

    public String getOwnerActivityStatus(String activityId, Connection con)throws Exception{
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            preparedStatement = con.prepareStatement("SELECT STATUS FROM OWNER_ACTIVITY WHERE ACTIVITY_ID=? ORDER BY STATUS DESC");
            preparedStatement.setString(1,activityId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                return rs.getString("STATUS");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
              closeResources(null,rs,preparedStatement);  
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return "";
    }
  
  private void closeResources(Connection conn, ResultSet rs, PreparedStatement preparedStatement) throws SQLException{
    if(rs != null) rs.close();
    if(preparedStatement != null) preparedStatement.close();
    if(conn != null) conn.close();
  }

  public void updateOverAllActivityStatus(String activityId, String status, Connection con)throws Exception{
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = con.prepareStatement("UPDATE ACTIVITY A SET A.STATUS=? WHERE A.ACTIVITY_ID=?");
            preparedStatement.setString(1,status);
            preparedStatement.setString(2,activityId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                closeResources(null,null,preparedStatement);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
