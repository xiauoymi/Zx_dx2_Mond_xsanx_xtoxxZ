package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.List;
import java.sql.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 26, 2005
 * Time: 10:42:43 AM
 * To change this template use File | Settings | File Templates.
 */

public class DocChangeForm extends ActionForm{

    private List cyclemaintainobjectlist;

    private List docpublishobjectlist;

    private List country;
    private String selectedCountry;

    private String temp;

    private String sdate;
    private String edate;

    public String getSdate() {
        return sdate;
    }

    public void setSdate(String sdate) {
        this.sdate = sdate;
    }

    public String getEdate() {
        return edate;
    }

    public void setEdate(String edate) {
        this.edate = edate;
    }


    public List getCyclemaintainobjectlist() {
        return cyclemaintainobjectlist;
    }

    public void setCyclemaintainobjectlist(List cyclemaintainobjectlist) {
        this.cyclemaintainobjectlist = cyclemaintainobjectlist;
    }

    public List getCountry() {
        return country;
    }

    public void setCountry(List country) {
        this.country = country;
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public List getDocpublishobjectlist() {
        return docpublishobjectlist;
    }

    public void setDocpublishobjectlist(List docpublishobjectlist) {
        this.docpublishobjectlist = docpublishobjectlist;
    }


}
