/*
 * Created on May 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.OwnerResponse;
import com.monsanto.wst.soxic.model.Question;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class OwnerResponseDAO {

    public static final String RESPONSE_ID = "RESPONSE_ID";

    public static final String STATUS = "STATUS";

    /**
     * Retrieve the owner response based on the column
     *
     * @param ownerResponse
     * @param column
     * @throws Exception
     */
    public void retrieve(OwnerResponse ownerResponse, String column)
            throws Exception {
        if (column.equalsIgnoreCase(RESPONSE_ID)) {
            retrieveResponseId(ownerResponse);
        }
        if (column.equalsIgnoreCase(STATUS)) {
            retrieveStatus(ownerResponse);
        }
    }

    /**
     * Insert a response into the table
     *
     * @param ownerResponse
     * @param changeStatus
     * @throws Exception
     */
    public void insert(OwnerResponse ownerResponse, boolean changeStatus)
            throws Exception {

        Connection con = null;
        PreparedStatement insertAnswer = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            if (changeStatus) {
                insertAnswer = con
                        .prepareStatement("INSERT INTO OWNER_RESPONSE(OWNER_ID,QUESTION_ID,ASSOCIATED_TYPE,ASSOCIATED_ID,RESPONSE,STATUS,MOD_DATE,MOD_USER)"
                                + "VALUES(?,?,'A',?,?,?,?,?)");
                insertAnswer.setString(1, ownerResponse.getOwnerid());
                insertAnswer.setInt(2, ownerResponse.getQuestionid());
                insertAnswer.setString(3, ownerResponse.getAssociatedId());
                insertAnswer.setString(4, ownerResponse.getResponse());
                insertAnswer.setString(5, ownerResponse.getStatus());
                insertAnswer.setDate(6, new Date(System.currentTimeMillis()));
                insertAnswer.setString(7, ownerResponse.getOwnerid());
            } else {
                insertAnswer = con
                        .prepareStatement("INSERT INTO OWNER_RESPONSE(OWNER_ID,QUESTION_ID,ASSOCIATED_TYPE,ASSOCIATED_ID,RESPONSE,STATUS,MOD_DATE,MOD_USER)"
                                + "VALUES(?,?,'A',?,?,?,?,?)");
                insertAnswer.setString(1, ownerResponse.getOwnerid());
                insertAnswer.setInt(2, ownerResponse.getQuestionid());
                insertAnswer.setString(3, ownerResponse.getAssociatedId());
                insertAnswer.setString(4, ownerResponse.getResponse());
                insertAnswer.setString(5, ownerResponse.getStatus());
                insertAnswer.setDate(6, new Date(System.currentTimeMillis()));
                insertAnswer.setString(7, ownerResponse.getOwnerid());
            }

            ResultSet rs = insertAnswer.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closePreparedStatement(insertAnswer);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Updates the owner response
     *
     * @param ownerResponse
     * @param changeStatus
     * @throws Exception
     */
    public void update(OwnerResponse ownerResponse, boolean changeStatus)
            throws Exception {
        Connection con = null;
        PreparedStatement updateAnswer = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            if (changeStatus) {
                updateAnswer = con
                        .prepareStatement("UPDATE OWNER_RESPONSE ORS SET ORS.RESPONSE=? , ORS.STATUS=? WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND ORS.QUESTION_ID=? AND ORS.ASSOCIATED_TYPE='A'");
                updateAnswer.setString(1, ownerResponse.getResponse());
                updateAnswer.setString(2, ownerResponse.getStatus());
                updateAnswer.setString(3, ownerResponse.getOwnerid());
                updateAnswer.setString(4, ownerResponse.getAssociatedId());
                updateAnswer.setInt(5, ownerResponse.getQuestionid());

            } else {

                //Just the save mode
                updateAnswer = con
                        .prepareStatement("UPDATE OWNER_RESPONSE ORS SET ORS.RESPONSE=? WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND ORS.QUESTION_ID=? AND ORS.ASSOCIATED_TYPE='A'");
                updateAnswer.setString(1, ownerResponse.getResponse());
                //updateAnswer.setString(2, status);
                updateAnswer.setString(2, ownerResponse.getOwnerid());
                updateAnswer.setString(3, ownerResponse.getAssociatedId());
                updateAnswer.setInt(4, ownerResponse.getQuestionid());
            }

            int result = updateAnswer.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closePreparedStatement(updateAnswer);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * retrieves the status for the owner response and update ownerresponse
     * object (retrieves status for question , owner, id)
     *
     * @param ownerResponse
     * @throws Exception
     */
    private void retrieveStatus(OwnerResponse ownerResponse) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultset = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT ORS.STATUS FROM OWNER_RESPONSE ORS WHERE ORS.QUESTION_ID=? AND ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=?");
            preparedStatement.setInt(1, ownerResponse.getQuestionid());
            preparedStatement.setString(2, ownerResponse.getOwnerid());
            preparedStatement.setString(3, ownerResponse.getAssociatedId());
            resultset = preparedStatement.executeQuery();
            while (resultset.next()) {
                ownerResponse.setStatus(resultset.getString("STATUS"));
            }
        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                SoxicConnectionFactory.closeResultSet(resultset);
                SoxicConnectionFactory
                        .closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Retrieves the response id for a question , owner, id
     *
     * @param ownerResponse
     * @throws Exception
     */
    private void retrieveResponseId(OwnerResponse ownerResponse)
            throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultset = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT ORS.RESPONSE_ID FROM OWNER_RESPONSE ORS WHERE ORS.QUESTION_ID=? AND ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=?");
            preparedStatement.setInt(1, ownerResponse.getQuestionid());
            preparedStatement.setString(2, ownerResponse.getOwnerid());
            preparedStatement.setString(3, ownerResponse.getAssociatedId());
            resultset = preparedStatement.executeQuery();
            while (resultset.next()) {
                ownerResponse.setResponseid(""
                        + resultset.getInt("RESPONSE_ID"));
            }
        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                SoxicConnectionFactory.closeResultSet(resultset);
                SoxicConnectionFactory
                        .closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Check to see if response is present for a question, id, owner. If present
     * update with response id and return true else return false.
     *
     * @param ownerResponse
     * @return true if response is present else false
     * @throws Exception
     */
    public boolean checkIfAnswerPresent(OwnerResponse ownerResponse)
            throws Exception {
        boolean returnValue = false;

        Connection con = null;
        PreparedStatement checkAnswer = null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();

            checkAnswer = con
                    .prepareStatement("SELECT ORS.RESPONSE_ID FROM OWNER_RESPONSE ORS WHERE ORS.OWNER_ID=? AND ORS.ASSOCIATED_ID=? AND ORS.ASSOCIATED_TYPE='A' AND QUESTION_ID=?");
            checkAnswer.setString(1, ownerResponse.getOwnerid());
            checkAnswer.setString(2, ownerResponse.getAssociatedId());
            checkAnswer.setInt(3, ownerResponse.getQuestionid());

            rs = checkAnswer.executeQuery();
            while (rs.next()) {
                ownerResponse.setResponseid(rs.getString("RESPONSE_ID"));
                returnValue = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(checkAnswer);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return returnValue;
    }

    /**
     *Sets the answers for the all the activities in the list of control
     * objecetives for a particular owner.
     * @param ownerid
     * @param controlObjectiveList
     * @throws Exception
     */
    public void setAnswers(String ownerid, List controlObjectiveList)
            throws Exception {
        Connection connection = null;
        PreparedStatement retrieveAnswerList = null;
        ResultSet resultset = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            retrieveAnswerList = connection
                    .prepareStatement("SELECT * FROM OWNER_RESPONSE ORS WHERE ORS.OWNER_ID=?");

            retrieveAnswerList.setString(1, ownerid);

            resultset = retrieveAnswerList.executeQuery();
            while (resultset.next()) {
                String response = resultset.getString("RESPONSE");
                String questionId = resultset.getString("QUESTION_ID");
                String activityId = resultset.getString("ASSOCIATED_ID");
                String questionStatus = resultset.getString("STATUS");
                if (response != null) {
                    setAnwer(response, questionId, activityId,
                            controlObjectiveList, questionStatus);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                if (resultset != null)
                    resultset.close();
                if (retrieveAnswerList != null)
                    retrieveAnswerList.close();
                if (connection != null && !connection.isClosed())
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Sets the response to the question and activity in the control objective
     * list
     *
     * @param response
     * @param questionId
     * @param activityId
     * @param controlObjectiveList
     * @param questionStatus
     */
    public void setAnwer(String response, String questionId, String activityId,
                         List controlObjectiveList, String questionStatus) {

        Iterator controlObjectiveIterator = controlObjectiveList.iterator();

        while (controlObjectiveIterator.hasNext()) {

            ControlObjective controlObjective = (ControlObjective) controlObjectiveIterator
                    .next();

            Map activityMap = controlObjective.getAssignedActivityMap();

            if (activityMap != null) {
                Iterator activityIterator = activityMap.keySet().iterator();

                while (activityIterator.hasNext()) {

                    Object key = activityIterator.next();

                    Activity activity = (Activity) activityMap.get(key);

                    if (activity.getActivityId().equalsIgnoreCase(activityId)) {

                        Map questionMap = controlObjective.getQuestionMap();

                        Iterator questionIter = questionMap.keySet().iterator();

                        while (questionIter.hasNext()) {

                            Object questionkey = questionIter.next();

                            Question ques = (Question) questionMap
                                    .get(questionkey);

                            if (ques.getQuestionId().equalsIgnoreCase(
                                    questionId)) {

                                ques.setType(response);

                                if (ques.getStatus()==null){
                                    ques.setStatus(questionStatus);
                                }
                                if (ques.getStatus().equalsIgnoreCase(SoxicConstants.COMPLETE) && ques.getStatus()!=questionStatus){
                                    ques.setStatus(questionStatus);
                                }
                            }

                        }
                    }
                }
            }

        }

    }
}