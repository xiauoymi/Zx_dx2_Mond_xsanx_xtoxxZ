/*
 * Created on Mar 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.persistance.OracleAdminOwnerDAO;
import com.monsanto.wst.soxic.persistance.OwnerDAO;
import com.monsanto.wst.soxic.persistance.SignficantChangeDAO;
import com.monsanto.wst.soxic.persistance.UpdateSigChangeDAO;
import com.monsanto.wst.soxic.shared.overflow.OverFlowUtilDAO;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminOwner {
 
    
    public List getCycles(String oldUser, String newUser) throws DatabaseException, Exception {
        
       List oldUserCycles = OracleAdminOwnerDAO.getCycles(oldUser);
       
       if(!oldUserCycles.isEmpty()){
           
           List newUserCycles = OracleAdminOwnerDAO.getCycles(newUser);
           
           if(!newUserCycles.isEmpty()){
              oldUserCycles.removeAll(newUserCycles);
           }   
       }
       return oldUserCycles;
    }
    
    public List getCycles(String user) throws DatabaseException, Exception {
        
        return  OracleAdminOwnerDAO.getCycles(user);
       
     }
    
    public List getSubCycles(String oldUser, String newUser) throws DatabaseException, Exception {
      
      List oldUserSubCycles = OracleAdminOwnerDAO.getSubCycles(oldUser);
      
      if(!oldUserSubCycles.isEmpty()){
          List newUserSubCycles = OracleAdminOwnerDAO.getSubCycles(newUser);
          
          if(!newUserSubCycles.isEmpty()){
              
              oldUserSubCycles.removeAll(newUserSubCycles);
          }   
      }
      
      return oldUserSubCycles;
      
  }
    
    public List getSubCycles(String user) throws DatabaseException, Exception {
        
        return OracleAdminOwnerDAO.getSubCycles(user);
    }
  
  public List getActivities(String oldUser, String newUser) throws DatabaseException, Exception {
      
      List oldUserActivities = OracleAdminOwnerDAO.getActivities(oldUser);
      
      if(!oldUserActivities.isEmpty()){
          List newUserActivities = OracleAdminOwnerDAO.getActivities(newUser);
          
          if(!newUserActivities.isEmpty()){
             
              oldUserActivities.removeAll(newUserActivities);
          }   
      }
      
      return oldUserActivities;
      
  }
  
  public List getActivities(String user) throws DatabaseException, Exception {
      
      return OracleAdminOwnerDAO.getActivities(user);
            
  }
  
  public List getPreviewChanges(List cycles, List subCycles, List activities, String existingUser) throws DatabaseException, Exception{

      List previewChanges = new ArrayList();

      previewChanges.addAll(OracleAdminOwnerDAO.getCyclePreviewChanges(cycles, existingUser));
      previewChanges.addAll(OracleAdminOwnerDAO.getSubCyclePreviewChanges(subCycles, existingUser));
      previewChanges.addAll(OracleAdminOwnerDAO.getActivityPreviewChanges(activities, existingUser));

      return previewChanges;

  }

  public List getPreviewChangesNewUser(List cycles, List subCycles, List activities) throws DatabaseException, Exception{

      List previewChanges = new ArrayList();

      previewChanges.addAll(OracleAdminOwnerDAO.getCyclePreviewChanges(cycles));
      previewChanges.addAll(OracleAdminOwnerDAO.getSubCyclePreviewChanges(subCycles));
      previewChanges.addAll(OracleAdminOwnerDAO.getActivityPreviewChanges(activities));

      return previewChanges;

  }

  public void copyOwner(List changes,String user,String location) throws DatabaseException, Exception {
        OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
  	    ensureOwnerIntegrity(user,location);
        oracleAdminOwnerDAO.copyOwner(changes);
  }
  
  public void changeOwner(List changes, String user,String location) throws DatabaseException, Exception {
    OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
    SignficantChangeDAO significantDAO = new SignficantChangeDAO();
  	ensureOwnerIntegrity(user,location);

    if (changes != null && !changes.isEmpty()) {  
        AdminOwnerEntity entity = null;
        Iterator itr = changes.iterator();
        while (itr.hasNext()) {
            entity =  (AdminOwnerEntity) itr.next();

            if(significantDAO.cycleWithSignificantChanges(entity)) {
                Cycle cycle = oracleAdminOwnerDAO.getOwnerCycle(entity);
                oracleAdminOwnerDAO.setOwnerCycle(cycle, user, entity);
                significantDAO.updateSignificantChanges(entity, user);
                oracleAdminOwnerDAO.deleteOwnerCycle(cycle, entity);
            }

            oracleAdminOwnerDAO.changeOwner(entity, user);
        }
    }
  }
  
  public void deleteOwner(List changes) throws DatabaseException, Exception {
      OracleAdminOwnerDAO oracleAdminOwnerDAO = new OracleAdminOwnerDAO();
      SignficantChangeDAO significantDAO = new SignficantChangeDAO();
      UpdateSigChangeDAO updateSigChangeDAO = new UpdateSigChangeDAO();
      OverFlowUtilDAO flowUtilDAO = new OverFlowUtilDAO();

      if (changes != null && !changes.isEmpty()) {
        Iterator itr = changes.iterator();
         while (itr.hasNext()) {
            AdminOwnerEntity entity = (AdminOwnerEntity) itr.next();
            if(significantDAO.cycleWithSignificantChanges(entity))  {

                List significantChanges = updateSigChangeDAO.getExistingSignificantChanges(entity.getCycleId(), entity.getOwnerId());
                Iterator it = significantChanges.iterator();
                while(it.hasNext()) {
                    SignificantChangeModel significantChange = (SignificantChangeModel)it.next();
                    flowUtilDAO.deleteOverFlow(significantChange);
                }
               updateSigChangeDAO.deleteOldSigChangeEntriesForSigId(entity.getCycleId(), entity.getOwnerId());
            }
            oracleAdminOwnerDAO.deleteOwner(entity);

         }
      }
      
  }
  
  private void ensureOwnerIntegrity(String user,String location)throws Exception{
    OwnerDAO ownerDAO = new OwnerDAO();
    if(!ownerDAO.isPresent(user)){
    	Owner owner = Owner.getNewOwner(user);
    	owner.setLocation(location);
    	ownerDAO.insertOwner(owner);
  	
    }
  }
  
}
  