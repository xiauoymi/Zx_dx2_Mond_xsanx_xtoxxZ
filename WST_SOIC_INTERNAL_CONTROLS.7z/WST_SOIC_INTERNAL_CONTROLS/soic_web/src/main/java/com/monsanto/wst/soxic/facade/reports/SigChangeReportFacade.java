package com.monsanto.wst.soxic.facade.reports;

import com.monsanto.wst.soxic.persistance.SigReportDAO;
import com.monsanto.ServletFramework.UCCHelper;

import java.util.*;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 9:08:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class SigChangeReportFacade {

    SigReportDAO sigReportDAO = new SigReportDAO();
    List errorList = new ArrayList();
    private static final String NO_SIGNIFICANT_CHANGES_HAVE_BEEN_ENTERED = "No Significant Changes Have Been Entered";

    public List getPeriodSetForSignifcantChanges() {
        Set periods = sigReportDAO.getPeriods();
        List periodList = new ArrayList(periods);
        Collections.sort(periodList);
        return periodList;
    }

    public List getCountriesForSignificantChanges(String period) {
        Set countrySet = sigReportDAO.getCountriesBasedOnPeriod(period);
        List countries = new ArrayList(countrySet);
        countries.add("");
        Collections.sort(countries);
        return countries;
    }

    public void buildReportOptions(UCCHelper helper) throws IOException {
        List periods = getPeriodSetForSignifcantChanges();
        if (periods==null || periods.size()==0){
            helper.setRequestAttributeValue("errorList",NO_SIGNIFICANT_CHANGES_HAVE_BEEN_ENTERED);
        }
        else{
            List countryList = getCountriesForSignificantChanges((String)periods.get(0));
            helper.setSessionParameter("periodList",periods);
            helper.setSessionParameter("countryList",countryList);
        }
        helper.forward("jsp/sigChangeOptions.jsp");
    }

    public void buildReportOptionsWithPeriod(UCCHelper helper) throws IOException {
        String period = helper.getRequestParameterValue("p");
        List countryList = getCountriesForSignificantChanges(period);
        helper.setSessionParameter("countryList",countryList);
        helper.setSessionParameter("selPeriod",period);
        helper.forward("jsp/sigChangeOptions.jsp");
    }
}
