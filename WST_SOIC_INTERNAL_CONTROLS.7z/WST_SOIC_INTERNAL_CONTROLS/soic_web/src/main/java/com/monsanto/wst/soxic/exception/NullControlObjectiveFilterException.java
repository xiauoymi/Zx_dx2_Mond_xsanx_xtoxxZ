package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 9:57:13 AM
 */

public class NullControlObjectiveFilterException extends Exception {
	public NullControlObjectiveFilterException(){
		super();
	}

	public NullControlObjectiveFilterException(Exception e){
		super(e);
	}
}