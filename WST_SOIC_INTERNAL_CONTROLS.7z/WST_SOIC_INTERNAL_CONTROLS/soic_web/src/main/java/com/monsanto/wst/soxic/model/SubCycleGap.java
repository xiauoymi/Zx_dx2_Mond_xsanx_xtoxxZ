/*
 * Created on Mar 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycleGap {

	private String subCycleId;
	
	private String ownerId;
	
	private List gapList = new ArrayList();
	
	private List activityGap = new ArrayList();	
	/**
	 * @return Returns the activityGap.
	 */
	public List getActivityGap() {
		return activityGap;
	}
	/**
	 * @param activityGap The activityGap to set.
	 */
	public void setActivityGap(List activityGap) {
		this.activityGap = activityGap;
	}
	/**
	 * @return Returns the gapList.
	 */
	public List getGapList() {
		return gapList;
	}
	/**
	 * @param gapList The gapList to set.
	 */
	public void setGapList(List gapList) {
		this.gapList = gapList;
	}
	/**
	 * @return Returns the ownerId.
	 */
	public String getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId The ownerId to set.
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	/**
	 * @return Returns the subCycleId.
	 */
	public String getSubCycleId() {
		return subCycleId;
	}
	/**
	 * @param subCycleId The subCycleId to set.
	 */
	public void setSubCycleId(String subCycleId) {
		this.subCycleId = subCycleId;
	}
	
	public void addGap(String gapString){
		gapList.add(gapString);
	}
	
	public void addActivityGap(String id,String level,String gapString,String ownerId,String subCycleid){
		
		OwnerGap ownerGap = new OwnerGap();
		ownerGap.setGap(gapString);
		ownerGap.setOwnerid(ownerId);
		ownerGap.setActivityId(id);
		activityGap.add(ownerGap);
		
	}

}
