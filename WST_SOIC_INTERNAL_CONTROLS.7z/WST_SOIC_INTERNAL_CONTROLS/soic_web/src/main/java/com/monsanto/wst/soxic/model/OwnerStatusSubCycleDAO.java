package com.monsanto.wst.soxic.model;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 3, 2006
 * Time: 10:23:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusSubCycleDAO {

    private static String allActivitiesQuery = "SELECT A.ACTIVITY_ID " +
            "FROM ACTIVITY A, SUB_CYCLE SC, CTRL_OBJ CO, CYCLE C " +
            "WHERE A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
            "AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
            "AND SC.CYCLE_ID = C.CYCLE_ID " +
            "AND SC.SUB_CYCLE_ID = ?";

    private static String activityOwnerStatus = "SELECT O.NAME, OA.STATUS, O.LOCATION" +
            "  FROM ACTIVITY A, " +
            "       OWNER_ACTIVITY OA, " +
            "       CTRL_OBJ CO, " +
            "       SUB_CYCLE SC, " +
            "       CYCLE C, " +
            "       OWNER O " +
            " WHERE O.OWNER_ID = OA.OWNER_ID " +
            "   AND OA.ACTIVITY_ID = A.ACTIVITY_ID " +
            "   AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
            "   AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
            "   AND SC.CYCLE_ID = C.CYCLE_ID " +
            "   AND A.ACTIVITY_ID = ?";

    private PersistentStoreConnection createPersistentStore() throws WrappingException {
        PersistentStore persistentStore = WST_SOX_PersistentStoreFactory.getStore();
        PersistentStore.registerInstance(persistentStore);
        PersistentStoreConnection psConnection = persistentStore.connect();
        return psConnection;
    }

    private void closePersistentConnection(PersistentStoreStatement persistentStoreStatement, PersistentStoreConnection psConnection) throws DatabaseException {
        if(persistentStoreStatement != null){
            try {
                persistentStoreStatement.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
        if(psConnection != null){
            try {
                psConnection.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
    }

    public List getAllActivities(String subcycleid) throws DatabaseException {
        List activityList = new ArrayList();
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement(allActivitiesQuery);
            persistentStoreStatement.setParam(1,subcycleid);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                setActivityIntoList(persistentStoreResultSetFwdIterator, activityList);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(activityList);
        return activityList;
    }

    private void setActivityIntoList(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator, List activityList) throws WrappingException {
        String activity = persistentStoreResultSetFwdIterator.getString("ACTIVITY_ID");
        activityList.add(activity);
    }

    public List setActivityOwnersForSelectedActivity(String activityId) throws DatabaseException {
        List ownerInfo = new ArrayList();
        ReportOwners reportOwners = null;
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement(activityOwnerStatus);
            persistentStoreStatement.setParam(1,activityId);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                String owner = persistentStoreResultSetFwdIterator.getString("NAME");
                String location = persistentStoreResultSetFwdIterator.getString("LOCATION");
                String status = persistentStoreResultSetFwdIterator.getString("STATUS");
                if (status.equalsIgnoreCase(SoxicConstants.COMPLETE)){
                    status = "COMPLETE";
                }
                else status = "-";
                reportOwners = new ReportOwners(owner,location,status);
                ownerInfo.add(reportOwners);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(ownerInfo);
        return ownerInfo;
    }
}
