package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.action.StatusHelper;
import com.monsanto.wst.soxic.exception.CostInvalidException;
import com.monsanto.wst.soxic.exception.SigChangeListException;
import com.monsanto.wst.soxic.form.SignificantChangeForm;
import com.monsanto.wst.soxic.model.CycleStatusDAO;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import com.monsanto.wst.soxic.model.StatusDAO;
import com.monsanto.wst.soxic.persistance.SignficantChangeDAO;
import com.monsanto.wst.soxic.persistance.UpdateSigChangeDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import javax.servlet.http.HttpServletRequest;
import java.sql.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 8, 2006
 * Time: 4:07:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class SignificantChangeFacade {

    SignficantChangeDAO signficantChangeDAO = new SignficantChangeDAO();
    UpdateSigChangeDAO updateSigChangeDAO = new UpdateSigChangeDAO();
    StatusHelper statusHelper = new StatusHelper();
    StatusDAO statusDAO = new StatusDAO();

    public List getSignificantChanges(String cycleId, String ownerid) {
        return signChangesForOwnerAndCycle(cycleId,ownerid);
    }

    protected List signChangesForOwnerAndCycle(String cycleId, String ownerid) {
        return updateSigChangeDAO.getExistingSignificantChanges(cycleId, ownerid);
    }

    public List getBusinessTypes() {
        return getAllBusinessTypes(SoxicConstants.SIGNIFICANT_CHANGE_BUSINESS);
    }

    protected List getAllBusinessTypes(String significantChangeBusiness) {
        return signficantChangeDAO.returnDynamicBusinessOrPeriod(significantChangeBusiness);
    }

    public List getFuturePeriods() {
        return getFuturePeriodsFromLookup(SoxicConstants.SIGNIFICANT_CHANGE_PERIOD);
    }

    protected List getFuturePeriodsFromLookup(String significantChangePeriod) {
        return signficantChangeDAO.returnDynamicBusinessOrPeriod(significantChangePeriod);
    }

    public String getCurrentPeriod(String cycleId, String ownerid) {
        return getPeriodForSelectedOwnerAndCycle(cycleId,ownerid);
    }

    protected String getPeriodForSelectedOwnerAndCycle(String cycleId, String ownerid) {
        return signficantChangeDAO.returnCurrentPeriod(cycleId,ownerid);
    }


    public double checkIfValueIsCorrect(String number) throws CostInvalidException {
        double d = 0.0;
        try {
            d = Double.parseDouble(number);
        } catch (Exception e) {
            if (e instanceof NumberFormatException){
                throw new CostInvalidException();
            }
        }
        return d;
    }

    public void processAndValidateSigChanges(SignificantChangeForm significantChangeForm) throws SigChangeListException {
        List sigChangeIt = significantChangeForm.getSignificantChanges();
        Iterator sit = sigChangeIt.iterator();
        while (sit.hasNext()){
            SignificantChangeModel significantChangeModel = (SignificantChangeModel)sit.next();
            if (significantChangeModel.getSelectedType().equalsIgnoreCase("") || significantChangeModel.getSelectedPeriod().equalsIgnoreCase("") || significantChangeModel.getDescription().equalsIgnoreCase("")){
                throw new SigChangeListException();
            }
        }
    }

    public void updateDBWithSignificantChanges(SignificantChangeForm significantChangeForm, String type) {
        String cycleId = significantChangeForm.getCycleId();
        String ownerId = significantChangeForm.getOwnerId();
        List sigCycles = significantChangeForm.getSignificantChanges();
        createSigChangeEntries(cycleId, ownerId, sigCycles, type);
    }

    public void createSigChangeEntries(String cycleId, String ownerId, List sigCycles, String type) {
        signficantChangeDAO.createSigChangesForOwnerAndCycle(cycleId,ownerId,sigCycles,type);
    }

    public String getAutoSequenceSigChangeId() {
        return signficantChangeDAO.createSigChangeSequence();
    }

    public void updateNoReportingSigChange(SignificantChangeModel significantChangeModel, String cycleId, String ownerId, String type) {
        signficantChangeDAO.createSignificantChangeRowForNoReporting(significantChangeModel,cycleId,ownerId,type);
    }

    public String getSignificantSeqID(String cycleId, String ownerid) {
        return signficantChangeDAO.checkSequenceIDForOwnerAndCycle(cycleId,ownerid);
    }

    public void deleteOldSignificantChangeEntries(String cycleId, String ownerId) {
        updateSigChangeDAO.deleteOldSigChangeEntriesForSigId(cycleId,ownerId);
    }

    public void updateNoReportingInformation(SignificantChangeForm significantChangeForm, String type) {
        String sigSeqid = getAutoSequenceSigChangeId();
        SignificantChangeModel significantChangeModel = new SignificantChangeModel(sigSeqid, SoxicConstants.NONE,SoxicConstants.NONE,"","","","I have nothing to report at this time");
        updateNoReportingSigChange(significantChangeModel,significantChangeForm.getCycleId(),significantChangeForm.getOwnerId(),type);
    }

    public void setResetNoReportingOption(String noReporting, SignificantChangeForm significantChangeForm) {
        if (noReporting==null){
            significantChangeForm.setNoReporting(false);
        }
        else{
            significantChangeForm.setNoReporting(true);
        }
    }

    public void setFinalStatusForCycle(SignificantChangeForm significantChangeForm, HttpServletRequest request) throws Exception {
        String sigChangeStatus = CycleStatusDAO.getSigChangeStatus(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId());
        Date cycleCompletedDate = CycleStatusDAO.getCompletedDateForCycleAndOwner(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId());
        if ((cycleCompletedDate!=null) && (sigChangeStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE))){
            checkIfBothQuestionsAreAnswered(significantChangeForm, request);
        }
        else{
            setIncompleteStatusBasedOnDate(significantChangeForm);
        }
    }

    private void checkIfBothQuestionsAreAnswered(SignificantChangeForm significantChangeForm, HttpServletRequest request) throws Exception {
        List responses = CycleStatusDAO.getResponsesForCycleAndOwner(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId());
        if (responses!=null && responses.size()==2){
            setStatusToCompletion(significantChangeForm, request);
        }
        String cycOwnerStatus = statusDAO.getOwnerOverAllStatus(SoxicConstants.CYCLE,significantChangeForm.getOwnerId());
        if (cycOwnerStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
            request.setAttribute("test","test");
        }

    }

    private void setIncompleteStatusBasedOnDate(SignificantChangeForm significantChangeForm) throws Exception {
        Date dueDate = CycleStatusDAO.getDueDateForCycleAndOwner(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId());
        String incompleteStatus = (SoxicUtil.returnStatusPreceedingStr(dueDate)+ "INPROC");
        statusHelper.setOwnerCycleStatus(significantChangeForm.getOwnerId(),significantChangeForm.getCycleId(),incompleteStatus);
        statusHelper.setCycleStatus(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId(),incompleteStatus);
    }

    private void setStatusToCompletion(SignificantChangeForm significantChangeForm, HttpServletRequest request) throws Exception {
        statusHelper.setOwnerCycleStatus(significantChangeForm.getOwnerId(),significantChangeForm.getCycleId(), SoxicConstants.GREEN_COMPLETE);
        statusHelper.setCycleStatus(significantChangeForm.getCycleId(),significantChangeForm.getOwnerId(),SoxicConstants.GREEN_COMPLETE);
    }
}
