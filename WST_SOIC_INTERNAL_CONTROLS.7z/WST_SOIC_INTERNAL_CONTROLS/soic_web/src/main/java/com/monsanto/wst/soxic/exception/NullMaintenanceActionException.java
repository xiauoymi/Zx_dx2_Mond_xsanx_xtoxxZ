package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 10:10:40 AM
 */

public class NullMaintenanceActionException extends Exception {
	public NullMaintenanceActionException(){
		super();
	}

	public NullMaintenanceActionException(Exception e){
		super(e);
	}
}