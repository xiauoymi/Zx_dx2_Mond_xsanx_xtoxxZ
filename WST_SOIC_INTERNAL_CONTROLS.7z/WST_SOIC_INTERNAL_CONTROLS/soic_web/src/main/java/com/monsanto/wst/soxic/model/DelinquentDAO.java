/*
 * Created on May 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DelinquentDAO {

	/**
	 * returns a list of delinquent for the particular level
	 * @param level
	 * @param currentPeriod
     * @return list of delinquents
	 * @throws Exception
	 */
	public List getDelinquents(String level, String currentPeriod) throws Exception{
		UserDelinquents userDelinquents;
		List delinquentList = new ArrayList();
		
		Connection connection = null;
		PreparedStatement getDelinquents=null;
		ResultSet resultSet=null;

		try {

			connection = SoxicConnectionFactory.getSoxicConnection();

			getDelinquents = connection
					.prepareStatement(getDelinquentsQuery(level, currentPeriod));

			resultSet = getDelinquents.executeQuery();
			
			while(resultSet.next()){
				
				userDelinquents = new UserDelinquents();
				
				if(resultSet.getString("DUE_DATE")!=null){
					java.util.Date tempdate = resultSet.getDate("DUE_DATE");

					String temp = DateFormat.getDateInstance(DateFormat.MEDIUM).format(tempdate);
					
					userDelinquents.setDueDate(temp);
				}		
				
				userDelinquents.setName(resultSet.getString("NAME"));
				
				userDelinquents.setUpperIdentifier(resultSet.getString("IDENTI"));
				
				userDelinquents.setUserid(resultSet.getString("OWNER_ID"));
				
				delinquentList.add(userDelinquents);
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(resultSet);
				SoxicConnectionFactory.closePreparedStatement(getDelinquents);
				SoxicConnectionFactory.closeSoxicConnection(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return delinquentList;
	}
	
	/**
	 * Returns the retrieve query for the owner level
	 * 
	 * @param level
	 * @param currentPeriod
     * @return Query
	 */
	private String getDelinquentsQuery(String level, String currentPeriod) {

		String query = "";

		if (level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {

			query = "SELECT DISTINCT O.NAME,O.OWNER_ID,SC.CYCLE_ID AS IDENTI,OSC.DUE_DATE FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,OWNER O WHERE OSC.STATUS!='G_COMPLETE' AND OSC.OWNER_ID=O.OWNER_ID AND SC.SUB_CYCLE_ID=OSC.SUB_CYCLE_ID AND SC.SUB_CYCLE_ID LIKE '%"+currentPeriod +"%' ORDER BY SC.CYCLE_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.CYCLE)) {

			query = "SELECT DISTINCT O.OWNER_ID,O.NAME,OC.CYCLE_ID AS IDENTI,OC.DUE_DATE FROM OWNER_CYCLE OC,OWNER O WHERE OC.STATUS!='G_COMPLETE' AND OC.OWNER_ID=O.OWNER_ID AND OC.CYCLE_ID LIKE '%"+currentPeriod +"%' ORDER BY OC.CYCLE_ID";
		}

		if (level.equalsIgnoreCase(SoxicConstants.ACTIVITY)) {

			query = "SELECT DISTINCT O.NAME,O.OWNER_ID,OA.DUE_DATE,CO.SUB_CYCLE_ID AS IDENTI FROM OWNER_ACTIVITY OA,OWNER O,ACTIVITY A,CTRL_OBJ CO WHERE OA.STATUS!='G_COMPLETE' AND O.OWNER_ID = OA.OWNER_ID AND A.ACTIVITY_ID=OA.ACTIVITY_ID AND CO.CTRL_OBJ_ID=A.CTRL_OBJ_ID AND A.ACTIVITY_ID LIKE '%"+currentPeriod +"%' ORDER BY CO.SUB_CYCLE_ID";
		}
		return query;
	}
}
