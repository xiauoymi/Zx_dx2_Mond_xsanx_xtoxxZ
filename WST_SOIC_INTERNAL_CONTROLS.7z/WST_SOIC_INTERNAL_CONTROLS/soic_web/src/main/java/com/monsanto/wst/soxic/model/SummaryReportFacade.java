/*
 * Created on Jun 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import com.monsanto.wst.soxic.form.DashBoardSummaryReportForm;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SummaryReportFacade {

	public void setCountryListSummary(DashBoardSummaryReportForm boardSummaryReportForm)throws Exception{
		
		List countrySummaryList = new ArrayList();
		
		UtilDAO utilDAO = new UtilDAO();
		
		List cycleList = utilDAO.getCycleList(boardSummaryReportForm.getSelectedPeriod());
		
		List countryList = utilDAO.getCountries(boardSummaryReportForm.getSelectedPeriod());
		
		Iterator iterator = countryList.iterator();
		
		boolean changeColor = false;
		
		while(iterator.hasNext()){
			String country = (String)iterator.next();
			
			CountrySummary countrySummary = new CountrySummary();
			
			countrySummary.setPeriod(boardSummaryReportForm.getSelectedPeriod());
			
			countrySummary.setCountryName(country);
			
			utilDAO.setNumberOfControlObjectives(countrySummary);
			
			utilDAO.setNumberOfActivities(countrySummary);
			
			HashSet hashSet = utilDAO.setNumberOfActivityOwners(countrySummary);
			
			hashSet = utilDAO.setNumberOfSubCycleOwners(countrySummary,hashSet);
			
			hashSet = utilDAO.setNumberOfCycleOwners(countrySummary,hashSet);
			
			countrySummary.setNumberOfOwners(hashSet.size());
			
			countrySummaryList.add(countrySummary);
			
			utilDAO.setOverAllPercentageCompletion(countrySummary,cycleList);
			
			if(changeColor){
				countrySummary.setColor("#FFFF76");
				changeColor = false;
			}else{
				countrySummary.setColor("#FFFFFF");
				changeColor = true;
			}
			
			
			
		}
		
		 boardSummaryReportForm.setCountrySummaryList(countrySummaryList);
		 
		 boardSummaryReportForm.setCycleList(cycleList);
	}
}
