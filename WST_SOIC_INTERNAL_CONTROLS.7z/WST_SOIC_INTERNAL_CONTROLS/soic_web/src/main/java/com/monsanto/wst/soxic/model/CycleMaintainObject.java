package com.monsanto.wst.soxic.model;

import java.sql.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 26, 2005
 * Time: 4:27:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class CycleMaintainObject {

    private String cycle;
    private String state;
    private String status;
    private String begin_date;
    private String end_date;
    private boolean locked;
    private boolean docrelease;
    private boolean published;

    public String getBegin_date() {
        return begin_date;
    }

    public void setBegin_date(String begin_date) {
        this.begin_date = begin_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getCycle() {
        return cycle;
    }

    public void setCycle(String cycle) {
        this.cycle = cycle;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public boolean isDocrelease() {
        return docrelease;
    }

    public void setDocrelease(boolean docrelease) {
        this.docrelease = docrelease;
    }

    public boolean isPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toString() {
        StringBuffer st = new StringBuffer();
        st.append("Cycle " +cycle+"\n");
        st.append("State " +state+"\n");
        st.append("Status " +status+"\n");
        st.append("Begin_Date " +begin_date+"\n");
        st.append("End_Date " +end_date+"\n");
        st.append("Locked " +locked+"\n");
        st.append("Released " +docrelease+"\n");
        st.append("Published " +published+"\n");

        return st.toString();    //To change body of overridden methods use File | Settings | File Templates.
    }


}
