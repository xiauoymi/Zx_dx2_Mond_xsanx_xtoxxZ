package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 1, 2005
 * Time: 3:06:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class BadDataException extends Exception {
	public BadDataException(){
		super();
	}

	public BadDataException(Exception e){
		super(e);
	}
}
