package com.monsanto.wst.soxic.audit;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 12:18:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@Table(schema = "SARBOX_ET",name = "CTRL_OBJ")
public class ControlObjectiveObj implements Serializable{

  @Id
  @Column(name = "CTRL_OBJ_ID")
  private String controlObjectiveId;

  @Column(name = "CTRL_OBJ_CODE")
  private String controlObjectiveCode;

  @Column(name = "SUB_CYCLE_ID",insertable = false,updatable = false)
  private String subCycleId;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "OVERFLOW_ID")
  private Integer overFlowId;

  @Column(name = "RISK")
  private String risk;

  @Column(name = "STATUS")
  private String status;

  @Column(name = "POTENTIAL_GAP")
  private String gap;

  @Column(name = "PREV_DEF")
  private String prevDef;

  @Column(name = "MOD_DATE")
  private String modDate;

  @Column(name = "MOD_USER")
  private String modUser;

  @ManyToOne
  @JoinColumn(name = "SUB_CYCLE_ID")
  private SubCycleObj subCycle;

 @OneToMany(mappedBy = "controlObjective",targetEntity = ActivityObj.class,fetch = FetchType.LAZY)
 private List<ActivityObj> activities = new ArrayList<ActivityObj>();

  public String getControlObjectiveId() {
    return controlObjectiveId;
  }

  public void setControlObjectiveId(String controlObjectiveId) {
    this.controlObjectiveId = controlObjectiveId;
  }

  public String getControlObjectiveCode() {
    return controlObjectiveCode;
  }

  public void setControlObjectiveCode(String controlObjectiveCode) {
    this.controlObjectiveCode = controlObjectiveCode;
  }

  public String getSubCycleId() {
    return subCycleId;
  }

  public void setSubCycleId(String subCycleId) {
    this.subCycleId = subCycleId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Integer getOverFlowId() {
    return overFlowId;
  }

  public void setOverFlowId(Integer overFlowId) {
    this.overFlowId = overFlowId;
  }

  public String getRisk() {
    return risk;
  }

  public void setRisk(String risk) {
    this.risk = risk;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }

  public String getPrevDef() {
    return prevDef;
  }

  public void setPrevDef(String prevDef) {
    this.prevDef = prevDef;
  }

  public String getModDate() {
    return modDate;
  }

  public void setModDate(String modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }


//  public SubCycle getSubCycle() {
//    return subCycle;
//  }
//
//  public void setSubCycle(SubCycle subCycle) {
//    this.subCycle = subCycle;
//  }
//
//  public List<Activity> getActivities() {
//    return activities;
//  }
//
//  public void setActivities(List<Activity> activities) {
//    this.activities = activities;
//  }

  public SubCycleObj getSubCycle() {
    return subCycle;
  }

  public void setSubCycle(SubCycleObj subCycle) {
    this.subCycle = subCycle;
  }

  public List<ActivityObj> getActivities() {
    return activities;
  }

  public void setActivities(List<ActivityObj> activities) {
    this.activities = activities;
  }
}
