/*
 DocChangesReportForm was created on Jan 23, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.form;

import com.monsanto.wst.soxic.model.DocChangesReportDetailBean;
import org.apache.struts.action.ActionForm;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: DocChangesReportForm.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: emgoode $    	 On:	$Date: 2007-06-08 15:03:24 $
 *
 * @author emgoode
 * @version $Revision: 1.1 $
 */
public class DocChangesReportForm extends ActionForm {

    private ArrayList periodList;
    private String selectedPeriod;
    private ArrayList countryList = new ArrayList();
    private String selectedCountry;
    private ArrayList cycleList = new ArrayList();
    private ArrayList reportList;
    private DocChangesReportDetailBean detailBean;

    private ArrayList typeList = new ArrayList();
    private String selectedType;

    public ArrayList getCountryList() {
        return countryList;
    }

    public void setCountryList(ArrayList countryList) {
        countryList.add(0,"");
        this.countryList = countryList;
    }

    public ArrayList getCycleList() {
        return cycleList;
    }

    public void setCycleList(ArrayList cycleList) {
        //  Need to add a blank cycle to the list
        cycleList.add(0,"");

        this.cycleList = cycleList;
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public String getSelectedCycle() {
        return selectedCycle;
    }

    public void setSelectedCycle(String selectedCycle) {
        this.selectedCycle = selectedCycle;
    }

    private String selectedCycle;

    public ArrayList getReportList() {
        return reportList;
    }

    public String getSelectedPeriod() {
        return selectedPeriod;
    }

    public void setSelectedPeriod(String selectedPeriod) {
        this.selectedPeriod = selectedPeriod;
    }

    public ArrayList getPeriodList() {
        return periodList;
    }

    public void setPeriodList(ArrayList periodsInSystem) {
        periodList = periodsInSystem;
    }

    public void setReportList(ArrayList docChangesList) {
        this.reportList = docChangesList;
    }

    public void setDetailBean(DocChangesReportDetailBean docChangeDetails) {
        this.detailBean = docChangeDetails;
    }

    public DocChangesReportDetailBean getDetailBean() {
        return detailBean;
    }

    public void setTypeList(ArrayList types) {
        this.typeList = types;
    }

    public ArrayList getTypeList() {
        return typeList;
    }

    public String getSelectedType() {
        return selectedType;
    }

    public void setSelectedType(String selectedType) {
        this.selectedType = selectedType;
    }
}
