package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Oct 20, 2008
 * Time: 10:55:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportAuditForm extends ActionForm {

  private String period;

  public ExportAuditForm() {
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }
}
