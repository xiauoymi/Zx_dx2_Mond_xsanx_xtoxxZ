/*
 * Created on Feb 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.form.SubCycleViewForm;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.StatusDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicPathUtil;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//public class UpdateSubCycleViewAction extends LookupDispatchAction{
// 
//    /* (non-Javadoc)
//     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
//     */
//    protected Map getKeyMethodMap() {
//        Map map = new HashMap();
//        map.put("button.save",   "submit");
//        map.put("button.submit", "submit");
//        return map;
//    }
//    
//    public ActionForward save(ActionMapping mapping,
//            ActionForm form,
//            HttpServletRequest request,
//            HttpServletResponse response)
//            throws IOException, ServletException {
//       
//        return mapping.findForward("success");
//    }
//    
//    public ActionForward submit(ActionMapping mapping,
//            ActionForm form,
//            HttpServletRequest request,
//            HttpServletResponse response)
//            throws IOException, ServletException {
//        
//               
//        Owner owner = (Owner) request.getSession().getAttribute("owner");
//        
//        SubCycleViewForm subCycleViewForm = (SubCycleViewForm)form;
//        
//        Map map = request.getParameterMap();
//        subCycleViewForm.setLinkOnSubmit("PBO.02");
//        
//        if(owner != null)
//            try {
//                owner.updateSubCycleQuestions();
//            } catch (DatabaseException e) {
//                e.printStackTrace();
//            } catch (Exception e) {
//               
//                e.printStackTrace();
//            }
//        
//        return mapping.findForward("success");
//    }
//
//
//
//
//}

public class UpdateSubCycleViewAction extends Action{
	 
	    /* (non-Javadoc)
	     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
	     */
//	    protected Map getKeyMethodMap() {
//	        Map map = new HashMap();
//	        map.put("button.save",   "submit");
//	        map.put("button.submit", "submit");
//	        return map;
//	    }
	    public ActionForward execute(ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)throws IOException, ServletException{
	    	if(SoxicPathUtil.returnForward(request).equalsIgnoreCase("save")){
	    		return save(mapping,form,request,response);
	    	}
	    	return submit(mapping,form,request,response);
	    }
	    
	    public ActionForward save(ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws IOException, ServletException {
	    	
	        Owner owner = (Owner) request.getSession().getAttribute("owner");
	       try{
	       		owner.updateSubCycleQuestions(SoxicConstants.SAVEOPERATION);
	       }catch(Exception e){
	       	
	       }
	        return mapping.findForward("success");
	    }
	    
	    public ActionForward submit(ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws IOException, ServletException {
	        
	               
	        Owner owner = (Owner) request.getSession().getAttribute("owner");
	        
	        SubCycleViewForm subCycleViewForm = (SubCycleViewForm)form;
	        
	        String subCycleId = SoxicPathUtil.getKey(request, "submit");
	        
	        Map map = request.getParameterMap();
	        subCycleViewForm.setLinkOnSubmit(subCycleId);
	        
	        if(owner != null)
	            try {
	                owner.updateSubCycleQuestions(SoxicConstants.SUBMITOPERATION);
	                StatusHelper statusHelper = new StatusHelper();
	                statusHelper.setSubCycleStatus(subCycleId,owner.getOwnerId(),subCycleViewForm.getSubCycles());
	                SarboxMailComponent.sendEmail(SoxicConstants.SUBCYCLE,subCycleId);
	                StatusDAO statusDAO = new StatusDAO();
	                if(statusDAO.getOwnerOverAllStatus(SoxicConstants.SUBCYCLE,owner.getOwnerId()).equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
	                	request.setAttribute("test","test");
	                }
	            } catch (DatabaseException e) {
	                e.printStackTrace();
	            } catch (Exception e) {
	               
	                e.printStackTrace();
	            }
	        
	        return mapping.findForward("success");
	    }




	}
