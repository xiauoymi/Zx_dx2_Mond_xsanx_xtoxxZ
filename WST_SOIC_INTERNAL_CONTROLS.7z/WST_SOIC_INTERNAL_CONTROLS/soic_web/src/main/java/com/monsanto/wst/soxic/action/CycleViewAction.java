/*
 * Created on Feb 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.CycleViewForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CycleViewAction extends Action {

    /**
     * Method execute
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response) throws Exception{


        CycleViewForm cycleViewForm = (CycleViewForm)form;
        Owner owner = (Owner) request.getSession().getAttribute("owner");

//        if(cycleViewForm.getShowCycle() == null && cycleViewForm.getShowSubCycle() == null ){
//        	owner.cycleTab();
//        }

        cycleViewForm.setPeriodCycleAssociation(owner.getPeriodCycleIds());

        if(cycleViewForm.getPeriod() != null){
            cycleViewForm.setCycles(owner.getCycles(cycleViewForm.getPeriod()));
        }
        else{
            cycleViewForm.setCycles(owner.getCycles(cycleViewForm.getDefaultPeriod()));
        }


        if(cycleViewForm.getShowCycle() != null && cycleViewForm.getShowCycle().length() > 1 ){

            cycleViewForm.setCycleToShow(cycleViewForm.getShowCycle());
            cycleViewForm.setShowCycle("");
        }

        if(cycleViewForm.getShowSubCycle() != null && cycleViewForm.getShowSubCycle().length() > 1){
            cycleViewForm.setSubCycleToShow(cycleViewForm.getShowSubCycle());
            cycleViewForm.setShowSubCycle("");
        }
        cycleViewForm.setLink();
        cycleViewForm.setStatus(request,owner.getOwnerId());
        cycleViewForm.setSigChangeStatus(owner.getOwnerId());
        cycleViewForm.setHeaderAndFooter(SoxicConstants.CYCLE);

        return mapping.findForward("success");

    }

}
