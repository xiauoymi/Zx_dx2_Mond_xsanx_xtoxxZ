/*
ImportExcel2DB was create on 02/07/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/

package com.monsanto.wst.soxic.importProject;

/**
 * This class reads Excel files and puts it into Java Class before importing 
 * into the Oracle DB.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.soxic.exception.*;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import org.apache.log4j.Category;
import org.apache.poi.hssf.record.Record;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.sql.*;
import java.sql.Date;
import java.util.*;


public class ImportExcel2DB {
	
	
	
	//**Questions: Level_types...
	//***********************************************************************************
	String activityLevelTypeCode = "ACT";
	String subCycleLevelTypeCode = "SC";
	String cycleLevelTypeCode = "C";
	
	Vector activityQuestionId = new Vector();
	Vector subCycleQuestionId = new Vector();
	Vector cycleQuestionId = new Vector();
	
	ResultSet rs2;

	//***********************************************************************************
	
	private String filename = null;
	//private static String folderName = "ExcelFiles";
	//private static String folderName = "//finch/wst/$Team/Private/IntranetPractice/SOXIC/Templates/FY05Launch";
	
    // private POIFSFileSystem     fs           = null;
    private InputStream    stream       = null;
    private Record[]       records      = null;
    protected HSSFWorkbook hssfworkbook = null;
    protected HSSFWorkbook wb = null;
    protected HSSFSheet sheet = null;
  
    //**For storing excel header info (cycle owner, coutry, world area etc..)
    public ExcelHeaderBean headerBean = new ExcelHeaderBean();
    
    //**For storing the rowset...
    Vector ExcelRow = new Vector();
    Vector ExcelRowSet = new Vector();
    
    Vector cycleOwners = new Vector();
	Vector subCycleOwners = new Vector();
    
    //**Todays Date...
    Date date = new Date(System.currentTimeMillis());
    
    //**Database Objects...
    Connection con;
    
    //**Prepared Statements...(for 8 tables)
    PreparedStatement insertCycle;
    PreparedStatement insertOwnerCycle;
    
    PreparedStatement insertSubCycle;
    PreparedStatement insertOwnerSubCycle;
    
    PreparedStatement insertControlObj;
    
    PreparedStatement insertOwner;
    PreparedStatement insertActivity;
    PreparedStatement insertOwnerActivity;

    PreparedStatement insertControlObjectiveCode;

    PreparedStatement insertCycleState;

    //** Update loc for cycle/subcycle owners.
    PreparedStatement getLocation;
    PreparedStatement updateLocation;
    
    //**Integrating Questions in Import...
    //***********************************************************************************
    PreparedStatement getQuestionId;
    
    PreparedStatement insertQuestionActivity;
    PreparedStatement insertQuestionSubCycle;
    PreparedStatement insertQuestionCycle;
    //***********************************************************************************
    
    //**Large-Text-Handling
    PreparedStatement insertTextOverflow;
    PreparedStatement insertActivityOverflowId;
    PreparedStatement insertCtrlObjOverflowId;
    PreparedStatement getOverflowTableSize;
    
    //**Log4j logger
    static Category logger = Category.getInstance(ImportExcel2DB.class.getName());
    
    //**Row info
    int rowSkipped = 0;
    int totalRows = 0;
	
    
	/**
     * Constructor - creates an HSSFStream from an InputStream.  The HSSFStream
     * reads in the records allowing modification.
     *
     *
     * @param filename
     *
     * @exception IOException
     *
     */

//    public ImportExcel2DB(FormFile ff,String environment,String envVariable) throws IOException
    public ImportExcel2DB(String filename,InputStream inputStream,String envVariable) throws IOException
    {
            	//**Connecting to the Oracle DB...
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//**For connecting to DEV Database...
			System.setProperty("DMONCRYPTJV",envVariable);
			BufferedReader brIn = null;
			String hexKey = null;
			String keyFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "KeyValue.hex";
			String cipherFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "CipherValue.hex";
			try
			{
				brIn = new BufferedReader(new FileReader(keyFile));
				hexKey = brIn.readLine();
			}
			catch (FileNotFoundException ex)
			{
				throw new EncryptorException("EncryptionUtils::GetDecryptedStringFromExternalStorage - Invalid key file name.");
			}

      con = SoxicConnectionFactory.getSoxicConnection();

//			if(environment.equalsIgnoreCase("development")){
//				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
//				con = DriverManager.getConnection (SoxicUtil.getOracleDevServerConnectionString(), SoxicUtil.getOracleDevServerUserName(), decryptedPassword);
//			}
//
//			if(environment.equalsIgnoreCase("test")){
//				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
//				//**For connecting to Test Database...
//				con = DriverManager.getConnection (SoxicUtil.getOracleTestServerConnectionString(), SoxicUtil.getOracleTestServerUserName(), decryptedPassword);
//			}
//
//			if(environment.equalsIgnoreCase("production")){
//
//				String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
//				//**For connecting to Test Database...
//				con = DriverManager.getConnection (SoxicUtil.getOracleProductionServerConnectionString(),SoxicUtil.getOracleProductionServerUserName(), decryptedPassword);
//			}

			//**Code that creates Prepared statements for import...
			//**Table1
//			insertOwner = con.prepareStatement("INSERT INTO OWNER (OWNER_ID, NAME, LOCATION, EMAIL, LAST_LOGIN, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)");
			
			//**Table2...(modified)
//			insertCycle = con.prepareStatement("INSERT INTO CYCLE "
//                    +"(CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
//
//            //**Table 2a... (added)
//            insertCycleState = con.prepareStatement("INSERT INTO CYCLE_STATE (CYCLE_ID, PERIOD_ID, STATE, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)");
//
//			//**Table3
//			insertOwnerCycle = con.prepareStatement("INSERT INTO OWNER_CYCLE "
//                    +"(OWNER_ID, CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?)");
//
//			//**Table4...(modified)
//			insertSubCycle = con.prepareStatement("INSERT INTO SUB_CYCLE "
//                    +"(SUB_CYCLE_ID, SUB_CYCLE_CODE, CYCLE_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?, ?, ?)");
//
//			//**Table5
//			insertOwnerSubCycle = con.prepareStatement("INSERT INTO OWNER_SUB_CYCLE "
//                    +"(OWNER_ID, SUB_CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?)");
//
//			//**Table6
//			insertControlObj = con.prepareStatement("INSERT INTO CTRL_OBJ "
//                    +"(CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//
//			//**Table7
//			insertActivity = con.prepareStatement("INSERT INTO ACTIVITY "
//			                       +"(ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
//			                       + "VALUES (?, ?, ?, ?, ?, ?, ?)");
//
//			//**Table8
//			insertOwnerActivity = con.prepareStatement("INSERT INTO OWNER_ACTIVITY "
//                    +"(OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?, ?)");
//
//            insertControlObjectiveCode = con.prepareStatement("INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID,TYPE,CODE) VALUES(?,?,?)");
//
//			//**Query for adding Location info for Cycle/SubCycle Owners as Users...
//			getLocation = con.prepareStatement
//				("SELECT LOCATION " +
//					"FROM OWNER " +
//					"WHERE OWNER_ID = ?");
//
//			updateLocation = con.prepareStatement
//				("UPDATE OWNER " +
//						"SET LOCATION = ?  " +
//						"WHERE OWNER_ID = ?");
//
//
//			//**Queries for integrating Questions...
//			//***********************************************************************************
////			getQuestionId = con.prepareStatement
////									("SELECT QUESTION_ID " +
////										"FROM QUESTION " +
////										"WHERE LEVEL_TYPE = ?");
//
//			insertQuestionActivity = con.prepareStatement("INSERT INTO QUESTION_ACTIVITY "
//                    +"(QUESTION_ID, ACTIVITY_ID, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?)");
//
//			insertQuestionSubCycle = con.prepareStatement("INSERT INTO QUESTION_SUB_CYCLE "
//                    +"(QUESTION_ID, SUB_CYCLE_ID, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?)");
//
//			insertQuestionCycle = con.prepareStatement("INSERT INTO QUESTION_CYCLE "
//                    +"(QUESTION_ID, CYCLE_ID, MOD_DATE, MOD_USER) "
//                    + "VALUES (?, ?, ?, ?)");
//			//***********************************************************************************
//
//			//**Large-Text-Handling
//			insertTextOverflow = con.prepareStatement
//					("INSERT INTO TEXT_OVERFLOW "
//                    +"(OVERFLOW_ID, SEQUENCE, TEXT_CHUNK) "
//                    + "VALUES (?, ?, ?)");
//
//			insertActivityOverflowId = con.prepareStatement
//					("UPDATE ACTIVITY " +
//							"SET " +
//								"OVERFLOW_ID = ? " +
//							"WHERE " +
//								"ACTIVITY_ID = ?");
//
//			insertCtrlObjOverflowId = con.prepareStatement
//					("UPDATE CTRL_OBJ " +
//							"SET " +
//								"OVERFLOW_ID = ? " +
//							"WHERE " +
//								"CTRL_OBJ_ID = ?");
//
//			getOverflowTableSize = con.prepareStatement
//				("SELECT COUNT(*) TABLESIZE FROM TEXT_OVERFLOW");
			
			
			
			//con.close();
			 	
		 	logger.info("-> Connected to DB.");
		}
		catch(Exception ex){
		    logger.fatal("Exception connecting to DB."+ ex.getMessage());
		}
		
		
//    	int startOfFileName = ImportExcel2DB.folderName.length();
//
//   	this.filename = filename.substring(startOfFileName+1);

        this.filename = filename;

//        POIFSFileSystem fs =
//            new POIFSFileSystem(new FileInputStream(ff.getFileName()));

                POIFSFileSystem fs = new POIFSFileSystem(inputStream);

//        POIFSFileSystem fs =
//            new POIFSFileSystem(new DataInputStream(ff.getInputStream()));

        hssfworkbook  = new HSSFWorkbook(fs);
        
        
        
        // records = RecordFactory.createRecords(stream);
    }
    
    
	
//	/**
//	 * @return Returns the folderName.
//	 */
//	public static String getFolderName() {
//		return folderName;
//	}
//	/**
//	 * @param folderName The folderName to set.
//	 */
//	public static void setFolderName(String folderName) {
//		ImportExcel2DB.folderName = folderName;
//	}
	
	
	/**
	 * @return Returns the hssfworkbook.
	 */
	public HSSFWorkbook getHssfworkbook() {
		return hssfworkbook;
	}
	/**
	 * @param hssfworkbook The hssfworkbook to set.
	 */
	public void setHssfworkbook(HSSFWorkbook hssfworkbook) {
		this.hssfworkbook = hssfworkbook;
	}
	/**
	 * @return Returns the sheet.
	 */
	public HSSFSheet getSheet() {
		return sheet;
	}
	/**
	 * @param sheet The sheet to set.
	 */
	public void setSheet(HSSFSheet sheet) {
		this.sheet = sheet;
	}
	/**
	 * @return Returns the wb.
	 */
	public HSSFWorkbook getWb() {
		return wb;
	}
	/**
	 * @param wb The wb to set.
	 */
	public void setWb(HSSFWorkbook wb) {
		this.wb = wb;
	}
	
	
	/**
	 * @return Returns the excelRowSet.
	 */
	public Vector getExcelRowSet() {
		return ExcelRowSet;
	}
	
	
	/**
	 * @return Returns the headerBean.
	 */
	public ExcelHeaderBean getHeaderBean() {
		return headerBean;
	}
	/**
	 * @param headerBean The headerBean to set.
	 */
	public void setHeaderBean(ExcelHeaderBean headerBean) {
		this.headerBean = headerBean;
	}
	/**
	 * @param excelRowSet The excelRowSet to set.
	 */
	public void setExcelRowSet(Vector excelRowSet) {
		ExcelRowSet = excelRowSet;
	}
    /** 
     * Method importFile()
     * Reads the Excel file and saves the header and rowset information
     * in java objects.
     * 
     *
     * 
     */
    
    public ExcelHeaderBean importFile() throws Exception{
    	
        logger.info("-> Reading file " + filename + "...");
//      try
//        {
            //**Getting the header information into the ExcelHeaderBean...
            Iterator rowIt = sheet.rowIterator();
            int totalRows = sheet.getLastRowNum();

            for (int rowno = 0; rowno < totalRows + 1; rowno++)
            //while(rowIt.hasNext())
            {
            	HSSFRow row = sheet.getRow(rowno);
//            	HSSFRow row = (HSSFRow)rowIt.next();
//            	//sheet.removeRow(row);

            	//Iterator cellIt = row.cellIterator();
            	
            	int totalColumns = row.getLastCellNum();
            	//JOptionPane.showMessageDialog(null, "" + totalColumns);
            	
            	for(int cellno = 0; cellno < 9; cellno++)
            	//while(cellIt.hasNext())
            	{
            		//**Get the cell value...
            		HSSFCell cell = row.getCell((short)cellno);

            		//cell.setEncoding(HSSFCell.ENCODING_UTF_16 ) ;
            		//HSSFCell cell = (HSSFCell)cellIt.next();
            		
            		String stringval = "";
            	
            		//**Null Cell (probably a blank/untouched or erronious cell)...
            		if(cell == null){
            			stringval = "";
            			//ExcelRow.add(cellno, "");
                		if(rowno >= 7){
                			ExcelRow.add(cellno, stringval);
                		}            			
            			continue;
            		}
            		
            		if(cell.getCellType() == 0)//numeric type const
            		{
            			double numericval = cell.getNumericCellValue();
            			stringval = numericval + "";
            		}
            		else 
            		{
            			if(cell.getCellType() == 1)//string type const
            			{
            				stringval = cell.getStringCellValue();
            			}
            			else 
            				if(cell.getCellType() == 3)//blank type const
            				{            		
            					stringval = "";
            				}
            				else{ //**all other types like formula, error etc.. handled.
            					stringval = "";
            				}
            					
            		}
            		
            		//**Set Cycle Owner...
            		if(rowno == 0 && cellno == 0){ //**Cell A1
            			headerBean.setCycleOwner(stringval);
            			
            			if(headerBean.getCycleOwner() != null && !headerBean.getCycleOwner().equals("")){
            				StringTokenizer cycOwntk = new StringTokenizer(headerBean.getCycleOwner(), ",");
            		    
            				int tkc = 0;
            				while(cycOwntk.hasMoreTokens()){
            				    cycleOwners.add(tkc, cycOwntk.nextToken().trim());
            				    tkc++;
            				}
            			}
            		}
            		
            		//**Set Sub Cycle Owner...
            		if(rowno == 1 && cellno == 0){ //**Cell A2
            			headerBean.setSubCycleOwner(stringval);
            			
            			if(headerBean.getSubCycleOwner() != null && !headerBean.getSubCycleOwner().equals("")){
            				StringTokenizer subOwntk = new StringTokenizer(headerBean.getSubCycleOwner(), ",");
            		    
            				int tkc = 0;
            				while(subOwntk.hasMoreTokens()){
            				    subCycleOwners.add(tkc, subOwntk.nextToken().trim());
            				    tkc++;
            				}
            			}
            		}
            		
            		//**Set Cycle Desc...
            		if(rowno == 0 && cellno == 4){ //**Cell E1
            			headerBean.setCycleDesc(stringval);
            		}
            		
            		//**Set Sub Cycle Desc...
            		if(rowno == 1 && cellno == 4){ //**Cell E2
            			headerBean.setSubCycleDesc(stringval);
            		}
            		
            		//**Set World Area...
            		if(rowno == 2 && cellno == 0){ //**Cell A3
            			headerBean.setWorldArea(stringval);
            		}
            		
            		//**Set Country...
            		if(rowno == 3 && cellno == 0){ //**Cell A4
            			headerBean.setCountry(stringval);
            		}
            		
            		
            		
            		//**Populating the Row...
            		if(rowno >= 7){
            			ExcelRow.add(cellno, stringval);
            		}
            		            		
            	}//end while cells
            	
            	
            	
            	//**Populating the RowSet...
        		if(rowno >= 7){
        			ExcelRowSet.add(rowno - 7, ExcelRow);
        		}
        		
        		
        		ExcelRow = new Vector();        		
            	
            }//end while row
                       
            logger.info("-> Done Reading the file.");
            
            logger.info("-> Check Well formedness");

            isFileWellFormed();

            logger.info("-> Begin Importing to the Database...");
            
            
            //****DB Insert...
            
            //**Get all Question Ids...depending on codes...{ACT, SC, C}
            //***********************************************************************************

            Connection con = SoxicConnectionFactory.getSoxicConnection();
            getQuestionId = con.prepareStatement
									("SELECT QUESTION_ID " +
										"FROM QUESTION " +
										"WHERE LEVEL_TYPE = ?");

            insertOwner = con.prepareStatement("INSERT INTO OWNER (OWNER_ID, NAME, LOCATION, EMAIL, LAST_LOGIN, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)");

            insertCycle = con.prepareStatement("INSERT INTO CYCLE "
                    +"(CYCLE_ID, CYCLE_CODE, WORLD_AREA_ID, COUNTRY_ID, PERIOD_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            //**Table 2a... (added)
            insertCycleState = con.prepareStatement("INSERT INTO CYCLE_STATE (CYCLE_ID, PERIOD_ID, STATE, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)");

			//**Table3
			insertOwnerCycle = con.prepareStatement("INSERT INTO OWNER_CYCLE "
                    +"(OWNER_ID, CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

			//**Table4...(modified)
			insertSubCycle = con.prepareStatement("INSERT INTO SUB_CYCLE "
                    +"(SUB_CYCLE_ID, SUB_CYCLE_CODE, CYCLE_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)");

			//**Table5
			insertOwnerSubCycle = con.prepareStatement("INSERT INTO OWNER_SUB_CYCLE "
                    +"(OWNER_ID, SUB_CYCLE_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

			//**Table6
			insertControlObj = con.prepareStatement("INSERT INTO CTRL_OBJ "
                    +"(CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

//			//**Table7
//			insertActivity = con.prepareStatement("INSERT INTO ACTIVITY "
//			                       +"(ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) "
//			                       + "VALUES (?, ?, ?, ?, ?, ?, ?)");

            //**Table7
			insertActivity = con.prepareStatement("INSERT INTO ACTIVITY "
			                       +"(ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, PRIORITY, MOD_DATE, MOD_USER) "
			                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

			//**Table8
			insertOwnerActivity = con.prepareStatement("INSERT INTO OWNER_ACTIVITY "
                    +"(OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?, ?)");

            insertControlObjectiveCode = con.prepareStatement("INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID,TYPE,CODE) VALUES(?,?,?)");

			//**Query for adding Location info for Cycle/SubCycle Owners as Users...
			getLocation = con.prepareStatement
				("SELECT LOCATION " +
					"FROM OWNER " +
					"WHERE OWNER_ID = ?");

			updateLocation = con.prepareStatement
				("UPDATE OWNER " +
						"SET LOCATION = ?  " +
						"WHERE OWNER_ID = ?");


			//**Queries for integrating Questions...
			//***********************************************************************************
//			getQuestionId = con.prepareStatement
//									("SELECT QUESTION_ID " +
//										"FROM QUESTION " +
//										"WHERE LEVEL_TYPE = ?");

			insertQuestionActivity = con.prepareStatement("INSERT INTO QUESTION_ACTIVITY "
                    +"(QUESTION_ID, ACTIVITY_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");

			insertQuestionSubCycle = con.prepareStatement("INSERT INTO QUESTION_SUB_CYCLE "
                    +"(QUESTION_ID, SUB_CYCLE_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");

			insertQuestionCycle = con.prepareStatement("INSERT INTO QUESTION_CYCLE "
                    +"(QUESTION_ID, CYCLE_ID, MOD_DATE, MOD_USER) "
                    + "VALUES (?, ?, ?, ?)");
			//***********************************************************************************

			//**Large-Text-Handling
			insertTextOverflow = con.prepareStatement
					("INSERT INTO TEXT_OVERFLOW "
                    +"(OVERFLOW_ID, SEQUENCE, TEXT_CHUNK) "
                    + "VALUES (?, ?, ?)");

			insertActivityOverflowId = con.prepareStatement
					("UPDATE ACTIVITY " +
							"SET " +
								"OVERFLOW_ID = ? " +
							"WHERE " +
								"ACTIVITY_ID = ?");

			insertCtrlObjOverflowId = con.prepareStatement
					("UPDATE CTRL_OBJ " +
							"SET " +
								"OVERFLOW_ID = ? " +
							"WHERE " +
								"CTRL_OBJ_ID = ?");

			getOverflowTableSize = con.prepareStatement
				("SELECT COUNT(*) TABLESIZE FROM TEXT_OVERFLOW");

            getQuestionId.setString(1, activityLevelTypeCode);
            rs2 = getQuestionId.executeQuery();
            
            while(rs2.next()){
            	activityQuestionId.add(rs2.getString("QUESTION_ID"));
            }
            
            //**Similaryly for subCycle
            getQuestionId.setString(1, subCycleLevelTypeCode);
            rs2 = getQuestionId.executeQuery();
            
            while(rs2.next()){
            	subCycleQuestionId.add(rs2.getString("QUESTION_ID"));
            }

            //**Similaryly for Cycle
            getQuestionId.setString(1, cycleLevelTypeCode);
            rs2 = getQuestionId.executeQuery();
            
            while(rs2.next()){
            	cycleQuestionId.add(rs2.getString("QUESTION_ID"));
            }

            //***********************************************************************************
 
    		System.setProperty("xmlservice.peoplepicker.server","w3.ent.monsanto.com");
    		System.setProperty("xmlservice.peoplepicker.vdir","/ccca/pps");
    		System.setProperty("xmlservice.peoplepicker.endpoint","PeoplePicker.rem");
    		PeopleService svc = new PeopleService();
    		
    		//PersonInfo[] p = svc.GetPeople(lastName, firstName, phone, mailStop, userId, site, mailZone);

            //**Add Cycle Owner to this table...    	    
            for(int cycnt =  0; cycnt < cycleOwners.size(); cycnt++){	
            	try{	
            		//PersonInfo[] cycOwner = svc.GetPeople("", "", "", "", cycleOwners.get(cycnt).toString().trim(), "", "");
            		PersonInfo cycOwner = returnPeople(cycleOwners.get(cycnt).toString().trim());
            		if(cycOwner==null){
            			throw new InvalidUserException();
            		}
            		insertOwner.setString(1, cycleOwners.get(cycnt).toString().trim()); 				   //n/w id
            		//insertOwner.setString(2, cycleOwners.get(cycnt).toString().trim()); 				   //name
            		insertOwner.setString(2, cycOwner.getFirstName()+" "+cycOwner.getLastName()); 				   //name
            		insertOwner.setString(3, "?");		  				         							//loc
            		//insertOwner.setString(4, cycleOwners.get(cycnt).toString().trim() + "@monsanto.com");   //email
            		insertOwner.setString(4, cycOwner.getEmail() + "@monsanto.com");
    
            		insertOwner.setDate(5, date);											           			//login_date
            		
            		insertOwner.setDate(6, date);											           			//mod_date
            		insertOwner.setString(7, "rdesai2"); 									          			 //mod_user
            
            		insertOwner.executeUpdate();
            	}
            	catch(InvalidUserException e){
            		logger.error("Invalid User " + cycleOwners.get(cycnt).toString().trim());
            	}
            	catch(SQLException e){
            		if(e.getErrorCode() == 1){
            			//***Duplicate value being added...expected error
            			logger.warn("Duplicate Entry while adding Cycle Owner: " + e.getMessage());
            		}
            		else{
            			logger.warn("Critical Unknown Error: " + e.getMessage());
            		}
            			
            	}
        	}
            
            //**Add SubCycle Owner to this table...
            for(int sccnt =  0; sccnt < subCycleOwners.size(); sccnt++){
            	try{	
            		//PersonInfo[] subCycOwner = svc.GetPeople("", "", "", "", subCycleOwners.get(sccnt).toString().trim(), "", "");
            		PersonInfo subCycOwner = returnPeople(subCycleOwners.get(sccnt).toString().trim());
            		if(subCycOwner==null){
            			throw new InvalidUserException();
            		}
            		insertOwner.setString(1, subCycleOwners.get(sccnt).toString().trim()); 				   	//n/w id
            		//insertOwner.setString(2, subCycleOwners.get(sccnt).toString().trim()); 				   //name
            		insertOwner.setString(2, subCycOwner.getFirstName()+" "+subCycOwner.getLastName()); 				   //name
            		insertOwner.setString(3, "?");		           											//loc
            		//insertOwner.setString(4, subCycleOwners.get(sccnt).toString().trim() + "@monsanto.com");//email
            		insertOwner.setString(4, subCycOwner.getEmail() + "@monsanto.com");//email
            
            		insertOwner.setDate(5, date);											           			//login_date
            		
            		insertOwner.setDate(6, date);											           			 //mod_date
            		insertOwner.setString(7, "rdesai2"); 									          			 //mod_user
            
            		insertOwner.executeUpdate();
            	}
            	catch(InvalidUserException e){
            		logger.error("Invalid User " + subCycleOwners.get(sccnt).toString().trim());
            	}
            	catch(SQLException e){
            		if(e.getErrorCode() == 1){
            			//***Duplicate value being added...expected error
            			logger.warn("Duplicate Entry while adding SC Owner: " + e.getMessage());
            		}
            		else{
            			logger.warn("Critical Unknown Error: " + e.getMessage());
            		}
            	}
            }	
            
            totalRows = ExcelRowSet.size();
            
            //**For each row, in the rowset...
            for(int rowno = 0; rowno < ExcelRowSet.size(); rowno++){
            	
            	ExcelRow = (Vector)ExcelRowSet.get(rowno);
            	
            	//**PeriodID..
            	String periodID = "";
            	
            	String countryIDFromFilename = "";
            	
            	//**Reset Codes...
            	String activityCode = "";
            	String activityID = "";
            	
            	String controlObjCode = "";
    			String controlObjID = "";
            	
            	String cycleCode = "";
            	String cycleID = "";
            	
    			String subCycleCode = "";
    			String subCycleID = "";
    			
    			//**Reset Control Objective...
    			
    			//******Implementing the Large-Desc-Handling repair work....
    			//**Stores chunk of 2k characters...
    			Vector ctrlObjDescChunk = new Vector();
    			String controlObjDesc = "";
    			
    			String controlObjCat = "";
    			String templateCode = "";

                String priority = "";

    			//**Reset Activity...
    			
    			//******Implementing the Large-Desc-Handling repair work....
    			//**Stores chunk of 2k characters...
    			Vector activityDescChunk = new Vector();
    			String activityDesc = "";
    			
    			//**Reset Risk...
    			String controlObjRisk = "";
    			
    			//**Reset Userid and Location...
    			Vector ownerID = new Vector();
    			Vector location = new Vector();
    			
    			
    			
    			
            	
            	//**For exactly 8 cells...
            	for(int cellno = 0; cellno < 9; cellno++){
            		
            		//**Extract the (first cell)codes...(Required Attribute)
            		if(cellno == 0){
            		    
            		    //**Skip the row, if activity id is not present...
            		    if(ExcelRow.size() >= 1){
            		        activityID = (String)ExcelRow.get(cellno);
            		    }
            		    else{
            		        logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
            		        rowSkipped++;
            		        break;
            		    }
            			
            			//**Double check...(for empty string)
            			if(activityID == null || activityID.equals("")){
            			    logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
            		        rowSkipped++;
            			    break;
            			}
            			
            			//**Remove spaces...
            			activityID = activityID.trim();
            			
            			//**Get the CycleCode from the filename...
            			StringTokenizer filest = new StringTokenizer(filename, ".");
            			
            			//**we need first 3 tokens...
            			for(int i = 0; i < 3; i++){
            					if(i == 0){
            					    periodID = filest.nextToken();
            					}
            					if(i == 1){
            						countryIDFromFilename = filest.nextToken();
            					}
            					if(i == 2){            					   
            					    cycleCode = filest.nextToken();
            					    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;

            					}
                                headerBean.setCycleID(cycleID);
            					logger.debug("CycleCode = " + cycleCode);
            			}
            			
            			StringTokenizer st = new StringTokenizer(activityID, ".");            			
            			
//            			//**There will be exactly 3 tokens formed...
//            			for(int i = 0; i < 3; i++){
//            				if(i==0){
//            					String tempcode = st.nextToken();            					
//            					subCycleCode = tempcode.substring(cycleCode.length() , tempcode.length());            					
//            					subCycleID = cycleID + "." + subCycleCode;
//            					
//            					logger.debug("SubCycleCode = " + subCycleCode);
//            				}
//            				if(i==1){
//            					controlObjCode = st.nextToken();
//            					controlObjID = subCycleID + "." + controlObjCode;
//            					logger.debug("ControlObjectiveCode = " + controlObjCode);
//            				}
//            				if(i==2){
//            					activityCode = st.nextToken();
//            					activityID = controlObjID + "." + activityCode;
//            				    
//            					logger.debug("ActivityCode = " + activityCode);
//            				}
//            			}
        				//**There will be exactly 3 tokens formed...now exactly 4 tokens...
            			for(int i = 0; i < 4; i++){
            				if(i==0){
            					String tempcode = st.nextToken();            					
            					logger.info(tempcode);
            					//subCycleCode = tempcode.substring(cycleCode.length() , tempcode.length());            					
            					//subCycleID = cycleID + "." + subCycleCode;
            					
            					//logger.debug("SubCycleCode = " + subCycleCode);
            				}
            				if(i==1){
            					String tempcode = st.nextToken();            					
            					logger.info(tempcode);
            					subCycleCode = tempcode;            					
            					subCycleID = cycleID + "." + tempcode;
            					
            					logger.debug("SubCycleCode = " + subCycleCode);
            				}
            				if(i==2){
            					controlObjCode = st.nextToken();
            					controlObjID = subCycleID + "." + controlObjCode;
            					logger.debug("ControlObjectiveCode = " + controlObjCode);
            				}
            				if(i==3){
            					activityCode = st.nextToken();
            					activityID = controlObjID + "." + activityCode;
            				    
            					logger.debug("ActivityCode = " + activityCode);
            				}
            			}
            			
            		}//end if cell 0
            		
            		//**Cell 1: Control Objective Description... 
            		if(cellno == 1){
            		    
            		    controlObjDesc = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 2){
            				controlObjDesc = (String)ExcelRow.get(cellno);
            				//controlObjDesc = controlObjDesc.replace('',"'".charAt(0));
            		    }
            		    	
        		    		//**Check for size, partition it and put it into Vector...
        		    		if(controlObjDesc.length() <= 2000){
        		    			if(controlObjDesc != null){	
        		    				ctrlObjDescChunk.add(controlObjDesc);
        		    			}
        		    			else{
        		    				ctrlObjDescChunk.add("");
        		    			}
        		    		}
        		    		else{
        		    			for(int chCnt = 0; chCnt < controlObjDesc.length(); chCnt = chCnt + 2000){	
        		    				if(chCnt + 2000 <= controlObjDesc.length()){
        		    					ctrlObjDescChunk.add(controlObjDesc.substring(chCnt, chCnt + 2000));
        		    				}
        		    				else{
        		    					ctrlObjDescChunk.add(controlObjDesc.substring(chCnt, controlObjDesc.length()));
        		    				}
        		    			}	
        		    		}
            		}
            		
            		//**Cell 2: Control Objective Category... 
            		if(cellno == 2){
            		    
            		    controlObjCat = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 3)
            				controlObjCat = (String)ExcelRow.get(cellno);
            		}
            		
            		
            		//**Cell 3: Template Code... 
            		if(cellno == 3){
            		    
            		    templateCode = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 4)
            				templateCode = (String)ExcelRow.get(cellno);
            		}
            		
            		
            		//**Cell 4: Activity Desc... 
            		if(cellno == 4){
            		    
            		    activityDesc = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 5){
            				activityDesc = ((String)ExcelRow.get(cellno)).replace('','\'');


            					// Get charset
            					Charset charset = Charset.forName("UTF-8");
            					
	            					CharsetDecoder decoder = charset.newDecoder();
	            					CharsetEncoder encoder = charset.newEncoder();
	            	    
	            					try {
	            						// Convert a string to ISO-LATIN-1 bytes in a ByteBuffer
	            						// The new ByteBuffer is ready to be read.
	            						ByteBuffer bbuf = encoder.encode(CharBuffer.wrap(activityDesc));     						
	            	    
	            						// Convert ISO-LATIN-1 bytes in a ByteBuffer to a character ByteBuffer and then to a string.
	            						// The new ByteBuffer is ready to be read.
	            						CharBuffer cbuf = decoder.decode(bbuf);
	            						
	            						String s = cbuf.toString();
	            						
	            						char chara[] = s.toCharArray();
	            						int indexOf = s.indexOf('�');
	            						
	            						for(int cs=0;cs<chara.length;cs++){
	            							if(chara[cs]=='�'){
	            								chara[cs]='\'';
	            							}
	            						}
	            		
	            						activityDesc = new String(chara);
	            						
	            					} catch (CharacterCodingException e) {
	            						logger.error("Unknown Exception"+e.getMessage());
	            					}//end of try catch
               		    }
            		    	
            		    	//**Check for size, partition it and put it into Vector...
            		    	if(activityDesc.length() <= 2000){
            		    		if(activityDesc != null){
            		    			activityDescChunk.add(activityDesc);
            		    		}
            		    		else{
            		    			activityDescChunk.add("");
            		    		}
            		    	}
            		    	else{
            		    		for(int chCnt = 0; chCnt < activityDesc.length(); chCnt = chCnt + 2000){	
            		    			if(chCnt + 2000 <= activityDesc.length()){
            		    				activityDescChunk.add(activityDesc.substring(chCnt, chCnt + 2000));
            		    			}
            		    			else{
            		    				activityDescChunk.add(activityDesc.substring(chCnt, activityDesc.length()));
            		    			}
            		    		}	
            		    	}
            		    	
            		}
            		
            		//**Cell 5: Risk... 
            		if(cellno == 5){
            		    
            		    controlObjRisk = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 6)
            		        controlObjRisk = (String)ExcelRow.get(cellno);
            		    
            		}
            		
            		//**Cell 6: ownerID...(*Required Attribute*) 
            		if(cellno == 6){
            			
            		    String ownerStr = "";
            		    
            		    //**Skip row, if enough elements not found...
            		    if(ExcelRow.size() >= 7)
            		    {
            		        //**Multiple userids...
            		        ownerStr = (String)ExcelRow.get(cellno);
            		    }
            		    else{
            		        logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -NetworkID of Owner missing, Row Skipped");
            		        rowSkipped++;
            		        break;
            		    }    
            		        
            		    //**Double check...(for empty string)
                		if(ownerStr == null || ownerStr.equals("")){
                		    logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -NetworkID of Owner missing, Row Skipped");
            		        rowSkipped++;
                		    break;
                		}
            		        
            		    StringTokenizer usertk = new StringTokenizer(ownerStr, ",");
            		    
            		    int tkc = 0;
            		    while(usertk.hasMoreTokens()){
            		        ownerID.add(tkc, usertk.nextToken());
            		        tkc++;
            		    }
            		    
            		    
            		}
            		
            		//**Cell 7: location... 
            		if(cellno == 7){
            		    
            		    String locStr = "";
            		    
            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 8)
            		    {    
            		        //**Multiple locations...
            		        locStr = (String)ExcelRow.get(cellno);
            		    
            		        StringTokenizer loctk = new StringTokenizer(locStr, ",");
            		    
            		        int tkc = 0;
            		        while(loctk.hasMoreTokens()){
            		            location.add(tkc, loctk.nextToken());
            		            tkc++;
            		        }
            		        
            		    }//end if
            		    
            		}


                   //**Cell 8: Priority Code...
            		if(cellno == 8){

            		    priority = "";

            		    //**Enter empty string, if enough elements not found...
            		    if(ExcelRow.size() >= 9)
            				priority = (String)ExcelRow.get(cellno);
            		}

            	}//end cell no
            	
            	
            	//**Enter the row into the Database...(for each row do...)
            	//(use prep stmt created in constr + transaction mgmt)
            	
            	try{ 
            	    
            	    //**Begin Transaction
            	    
            	    //con.setAutoCommit(false);
            	    
            	    //**Task1: Adding Multiple Owners...
            	                	    
    	            //**Add Activity Owners...
            	    for(int tkCnt = 0; tkCnt < ownerID.size(); tkCnt++){
            	        if(location.size() > tkCnt){
            	        	try{
            	        		//PersonInfo[] actOwner = svc.GetPeople("", "", "", "", ownerID.get(tkCnt).toString().trim(), "", "");
            	        		PersonInfo actOwner = returnPeople(ownerID.get(tkCnt).toString().trim());
            	        		if(actOwner==null){
            	        			throw new InvalidUserException();
            	        		}
            	        		insertOwner.setString(1, ownerID.get(tkCnt).toString().trim()); 				   //n/w id
            	        		//insertOwner.setString(2, ownerID.get(tkCnt).toString().trim()); 				   //name
            	        		insertOwner.setString(2, actOwner.getFirstName()+" "+actOwner.getLastName()); 				   //name
            	        		insertOwner.setString(3, location.get(tkCnt).toString().trim());		           //loc
            	        		//insertOwner.setString(4, ownerID.get(tkCnt).toString().trim() + "@monsanto.com");  //email
            	        		insertOwner.setString(4, actOwner.getEmail() + "@monsanto.com");  //email
            	        		
            	        		insertOwner.setDate(5, date);											           			//login_date
            	        		
            	        		insertOwner.setDate(6, date);											           //mod_date
            	        		insertOwner.setString(7, "rdesai2"); 									           //mod_user
            	            
            	        		insertOwner.executeUpdate();
            	        	}
            	        	catch(InvalidUserException e){
            	        		logger.error("Invalid User " + ownerID.get(tkCnt).toString() + "->" + location.get(tkCnt).toString());
            	        	}
            	        	catch(SQLException e){
            	        		if(e.getErrorCode() == 1){
            	        			//***Duplicate value being added...expected error            	       
            	        			
            	        			//**Add Location info if the Owner was added as Cycle/SubCycle Owner...
            	        			getLocation.setString(1, ownerID.get(tkCnt).toString().trim());
            	        			
            	        			ResultSet rsLoc = getLocation.executeQuery();
            	        			
            	        			while(rsLoc.next()){
            	        				String loc = rsLoc.getString("Location");
            	        				
            	        				if(loc.equals("?")){
            	        					updateLocation.setString(1, location.get(tkCnt).toString().trim());
            	        					updateLocation.setString(2, ownerID.get(tkCnt).toString().trim());
            	        					
            	        					updateLocation.executeUpdate();
            	        					
            	        					logger.error("Not an error, Location Info for Cycle/SubCycle Owner updated: " + ownerID.get(tkCnt).toString() + "->" + location.get(tkCnt).toString());
            	        				}
            	        				else{
            	        					logger.warn("Duplicate Entry while adding Owner: " + e.getMessage());
            	        				}
            	        			}
            	        			
            	        		}
            	        		else{
            	        			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
            	        		}
            	        	}
            	        }
            	        else{
            	        	logger.error("Error in Excel StyleSheet: Multiple Activity-Owners and not enough Locations -> Filename: " + filename + " Row No: " + (rowno + 1 + 7));
            	        }
            	        
            	        
            	    }//end for (all tokens)
            	    
    	   
    	    	
    	    
            	    
            	    //**Task2: Insert Cycle...            	               	   
            	    try{
            	        insertCycle.setString(1, cycleID.toString().trim()); 				   //cycleid
        	            insertCycle.setString(2, cycleCode.toString().trim()); 				   //cyclecode
        	            insertCycle.setString(3, headerBean.getWorldArea().toString().trim()); //world area
        	            insertCycle.setString(4, headerBean.getCountry().toString().trim());   //country
        	            insertCycle.setString(5, periodID);
        	            insertCycle.setString(6, headerBean.getCycleDesc().toString().trim());   //cycle desc
        	            
        	            insertCycle.setString(7, SoxicConstants.GREEN_IMPORTED);						//status
        	            
        	            insertCycle.setDate(8, date);											//mod_date
        	            insertCycle.setString(9, "rdesai2"); 									//mod_user
        	    
        	            insertCycle.executeUpdate();
            	    }
            	    catch(SQLException e){
            	    	if(e.getErrorCode() == 1){
                			//***Duplicate value being added...expected error
                			logger.warn("Duplicate Entry while adding Cycle: " + e.getMessage());
                		}
                		else if(activityID != null && !activityID.equals("")){
                			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                		}            	    
            	    }


                    //**Task2a: Insert into Cycle_State...
            	    try{
            	        insertCycleState.setString(1, cycleID.toString().trim()); 				   //cycleid
        	            insertCycleState.setString(2, periodID); 				   //periodId
        	            insertCycleState.setString(3, SoxicConstants.CYCLE_STATE);  //status
                        insertCycleState.setDate(4, date);											           			//mod_date
            		    insertCycleState.setString(5, "rdesai2");

                        insertCycleState.executeUpdate();
            	    }
            	    catch(SQLException e){
            	    	if(e.getErrorCode() == 1){
                			//***Duplicate value being added...expected error
                			logger.warn("Duplicate Entry while adding into Cycle_State: " + e.getMessage());
                		}
                        else if(activityID != null && !activityID.equals("")){
                			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                		}
                    }


                   //**Task 2b: Insert into Question_Cycle for the given cycleId
            	    //******************************************************************************************
            	    for(int cCnt = 0; cCnt < cycleQuestionId.size(); cCnt++){            	    
            	        try{
            	            insertQuestionCycle.setInt(1, Integer.parseInt(cycleQuestionId.get(cCnt).toString().trim())); 	//cyclequesid
            	            insertQuestionCycle.setString(2, cycleID.toString().trim()); 					//cycleid
            	            
            	            insertQuestionCycle.setDate(3, date);											//mod_date
            	            insertQuestionCycle.setString(4, "rdesai2"); 									//mod_user
        	    
            	            insertQuestionCycle.executeUpdate();        	           
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Ques-Cycle: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}                	
            	        }            	    
            	    }            	    
            	    //******************************************************************************************
            	    
            	    
            	    //**Task3: Insert CycleOwner(s)...            	               	               	    
            	    for(int tkCnt = 0; tkCnt < cycleOwners.size(); tkCnt++){
            	        
            	    
            	        try{
            	            insertOwnerCycle.setString(1, cycleOwners.get(tkCnt).toString().trim()); 	//cycleownerid
            	            insertOwnerCycle.setString(2, cycleID.toString().trim()); 						//cycleid
            	            insertOwnerCycle.setString(3, SoxicConstants.GREEN_IMPORTED); 									//status
            	                	         
            	            insertOwnerCycle.setDate(4, date);												//mod_date
            	            insertOwnerCycle.setString(5, "rdesai2"); 										//mod_user
        	    
            	            insertOwnerCycle.executeUpdate();
        	            
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Cycle Owner OR " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}
                	
            	        }
            	       
            	    }
            	    
            	    
            	    
            	    //**Task4: Insert SubCycle...            	               	   
            	    try{
            	        insertSubCycle.setString(1, subCycleID.toString().trim()); 			//sub cycle id
        	            insertSubCycle.setString(2, subCycleCode.toString().trim()); 		//sub cycle code
        	            insertSubCycle.setString(3, cycleID.toString().trim()); 			//cycle id
        	            insertSubCycle.setString(4, headerBean.getSubCycleDesc().toString().trim()); //sub cycle desc
        	            
        	            insertSubCycle.setString(5, SoxicConstants.GREEN_IMPORTED);						//status
        	            
        	            insertSubCycle.setDate(6, date);									//mod_date
        	            insertSubCycle.setString(7, "rdesai2"); 							//mod_user
    	    
        	            insertSubCycle.executeUpdate();
            	    }
            	    catch(SQLException e){
            	    	if(e.getErrorCode() == 1){
                			//***Duplicate value being added...expected error
                			logger.warn("Duplicate Entry while adding SC: " + e.getMessage());
                		}
                		else if(activityID != null && !activityID.equals("")){
                			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                		}
            	    
            	    }
            	    
            	    //**Task 4b: Insert into Question_Sub_Cycle for the given subCycleId
            	    //******************************************************************************************
            	    for(int scCnt = 0; scCnt < subCycleQuestionId.size(); scCnt++){            	    
            	        try{
            	            insertQuestionSubCycle.setInt(1, Integer.parseInt(subCycleQuestionId.get(scCnt).toString().trim())); 	//subcyclequesid
            	            insertQuestionSubCycle.setString(2, subCycleID.toString().trim()); 						//subcycleid
            	            
            	            insertQuestionSubCycle.setDate(3, date);												//mod_date
            	            insertQuestionSubCycle.setString(4, "rdesai2"); 										//mod_user
        	    
            	            insertQuestionSubCycle.executeUpdate();        	           
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Ques-SC " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}  
            	        }            	    
            	    }            	    
            	    //******************************************************************************************
            	    
            	    
            	    
            	    //**Task5: Insert SubCycleOwner(s)...            	               	   
            	    for(int tkCnt = 0; tkCnt < subCycleOwners.size(); tkCnt++){
            	    
            	        try{
            	            insertOwnerSubCycle.setString(1, subCycleOwners.get(tkCnt).toString().trim()); 	//subcycleownerid
            	            insertOwnerSubCycle.setString(2, subCycleID.toString().trim()); 						//subcycleid
            	            insertOwnerSubCycle.setString(3, SoxicConstants.GREEN_IMPORTED); 									//status
            	                	         
            	            insertOwnerSubCycle.setDate(4, date);												//mod_date
            	            insertOwnerSubCycle.setString(5, "rdesai2"); 										//mod_user
        	    
            	            insertOwnerSubCycle.executeUpdate();
        	            
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding SCO: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}
                	
            	        }
            	      
            	    } 
            	    
            	    //**Task 6.1
            	    int overflowID2 = 0;  
            	    int sequenceID2 = 0;
            	    if(ctrlObjDescChunk.size() > 1){
            	    	//**Task 6.1: Insert CO-OverFlowText...
            	    	
            	    	//Generate overflow-id ([size + 1] of the Table):
            	    	try{
            	    		ResultSet rs1 = getOverflowTableSize.executeQuery();            	    	
            	    		while(rs1.next()){
            	    			overflowID2 = rs1.getInt("TABLESIZE") + 1;
            	    		}
            	    	}
            	    	catch(SQLException e){
            	    		if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while getting chunks-table size (CO): " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}  
            	    	}
            	    	//Insert other chunks of the vector:
            	    	sequenceID2 = overflowID2;
            	    	for(int idx = 1; idx < ctrlObjDescChunk.size(); idx++){
            	    		try{
            	    			insertTextOverflow.setInt(1, overflowID2);									//OverFlow-id
            	    			insertTextOverflow.setInt(2, sequenceID2);									//sequence-id
            	    			insertTextOverflow.setString(3, ctrlObjDescChunk.get(idx).toString());		//Text-Chunk
            	    		
            	    			insertTextOverflow.executeUpdate();
            	    		}
            	    		catch(SQLException e){
            	    			if(e.getErrorCode() == 1){
                        			//***Duplicate value being added...expected error
                        			logger.warn("Duplicate Entry while adding chunks (CO): " + e.getMessage());
                        		}
                        		else if(activityID != null && !activityID.equals("")){
                        			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                        		}  
            	    		}
            	    		sequenceID2++;
            	    	}
            	    }
            	    
            	    //**Task6: Insert ControlObjective...            	               	   
            	    try{
            	        insertControlObj.setString(1, controlObjID.toString().trim()); 		//controlObjid
        	            insertControlObj.setString(2, controlObjCode.toString().trim()); 	//controlObjcode
        	            insertControlObj.setString(3, subCycleID.toString().trim()); 		//subcycleID
        	            insertControlObj.setString(4, ctrlObjDescChunk.get(0).toString().trim());   	//controlObjDesc
        	            //insertControlObj.setString(5, controlObjCat.toString().trim());  	//controlObjCategory
        	            //insertControlObj.setString(6, templateCode.toString().trim());		//templateCode
        	            insertControlObj.setString(5, controlObjRisk.toString().trim()); 	//Risk
        	            
        	            insertControlObj.setString(6, SoxicConstants.GREEN_IMPORTED);						//status
        	            
        	            insertControlObj.setDate(7, date);									//mod_date
        	            insertControlObj.setString(8, "rdesai2"); 							//mod_user
        	    
        	            insertControlObj.executeUpdate();
            	    }
            	    catch(SQLException e){
            	    	if(e.getErrorCode() == 1){
                			//***Duplicate value being added...expected error
                			logger.warn("Duplicate Entry while adding CO: " + e.getMessage());
                		}
                		else if(activityID != null && !activityID.equals("")){
                			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                		}
            	    }
            	    
            	    
            	    //**Task 6.2
            	    if(ctrlObjDescChunk.size() > 1){
            	    	//**Task 6.2: Insert CO-OverFlowIds...
            	    	
            	    	//take the co-id from above and insert the generated over-flow-id from Task-6.1
            	    	
            	    	try{
            	    		insertCtrlObjOverflowId.setInt(1, overflowID2);								//overflow-id
            	    		insertCtrlObjOverflowId.setString(2, controlObjID.toString().trim()); 		//where -> co-id
            	    	
            	    		insertCtrlObjOverflowId.executeUpdate();
            	    	}
            	    	catch(SQLException e){
            	    		if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Question-Activity (co): " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}  
            	    	}
            	    }
            	    
            	    
            	    //**Task 7.1
            	    int overflowID = 0;  
            	    int sequenceID = 0;
            	    if(activityDescChunk.size() > 1){
            	    	//**Task 7.1: Insert Activity-OverFlowText...
            	    	
            	    	//Generate overflow-id ([size + 1] of the Table):
            	    	try{
            	    		ResultSet rs1 = getOverflowTableSize.executeQuery();            	    	
            	    		while(rs1.next()){
            	    			overflowID = rs1.getInt("TABLESIZE") + 1;
            	    		}
            	    	}
            	    	catch(SQLException e){
            	    		if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while getting chunks-table size: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}  
            	    	}
            	    	//Insert other chunks of the vector:
            	    	sequenceID = overflowID;
            	    	for(int idx = 1; idx < activityDescChunk.size(); idx++){
            	    		try{
            	    			insertTextOverflow.setInt(1, overflowID);									//OverFlow-id
            	    			insertTextOverflow.setInt(2, sequenceID);									//sequence-id
            	    			insertTextOverflow.setString(3, activityDescChunk.get(idx).toString());		//Text-Chunk
            	    		
            	    			insertTextOverflow.executeUpdate();
            	    		}
            	    		catch(SQLException e){
            	    			if(e.getErrorCode() == 1){
                        			//***Duplicate value being added...expected error
                        			logger.warn("Duplicate Entry while adding chunks: " + e.getMessage());
                        		}
                        		else if(activityID != null && !activityID.equals("")){
                        			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                        		}  
            	    		}
            	    		sequenceID++;
            	    	}
            	    }
			
            	    
            	    //**Task7: Insert Acitvity...            	               	   
            	    try{
            	        insertActivity.setString(1, activityID.toString().trim()); 		//activityid
        	            insertActivity.setString(2, activityCode.toString().trim()); 	//activitycode
        	            insertActivity.setString(3, controlObjID.toString().trim()); 	//controlObjID
        	            insertActivity.setString(4, activityDescChunk.get(0).toString().trim());   	//activityDesc (Chunk#1)
                        //insertActivity.setString(5, controlObjCat.toString().trim());
                        //insertActivity.setString(6, templateCode.toString().trim());

        	            insertActivity.setString(5, SoxicConstants.GREEN_IMPORTED);						//status
        	            insertActivity.setString(6, priority);	
        	            insertActivity.setDate(7, date);								//mod_date
        	            insertActivity.setString(8, "rdesai2"); 						//mod_user
        	    
        	            insertActivity.executeUpdate();
            	    }
            	    catch(SQLException e){
            	    	if(e.getErrorCode() == 1){
                			//***Duplicate value being added...expected error
                			logger.warn("Duplicate Entry while adding chunk-id: " + e.getMessage());
                			logger.error("Duplicate Activity :"+ filename + " Row No: " + (rowno + 1 + 7));
                		}
                		else if(activityID != null && !activityID.equals("")){
                			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                		}
            	    }
            	    
            	    //**Task 7.2
            	    if(activityDescChunk.size() > 1){
            	    	//**Task 7.2: Insert Activity-OverFlowIds...
            	    	
            	    	//take the activity-id from above and insert the generated over-flow-id from Task-7.1
            	    	
            	    	try{
            	    		insertActivityOverflowId.setInt(1, overflowID);								//overflow-id
            	    		insertActivityOverflowId.setString(2, activityID.toString().trim()); 		//where -> activityid
            	    	
            	    		insertActivityOverflowId.executeUpdate();
            	    	}
            	    	catch(SQLException e){
            	    		if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Question-Activity: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}  
            	    	}
            	    }
            	    
                insertControlObjectiveCode(activityID.toString().trim(),templateCode.toString().trim());
                insertControlObjectiveCategory(activityID.toString().trim(),controlObjCat.toString().trim());

            	    //**Task 7b: Insert into Question_Activity for the given activityId
            	    //******************************************************************************************
            	    for(int aCnt = 0; aCnt < activityQuestionId.size(); aCnt++){            	    
            	        try{
            	            insertQuestionActivity.setInt(1, Integer.parseInt(activityQuestionId.get(aCnt).toString().trim())); 	//activityquesid
            	            insertQuestionActivity.setString(2, activityID.toString().trim()); 						//activityID
            	            
            	            insertQuestionActivity.setDate(3, date);												//mod_date
            	            insertQuestionActivity.setString(4, "rdesai2"); 										//mod_user
        	    
            	            insertQuestionActivity.executeUpdate();        	           
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Question-Activity: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}            	            
            	        }            	    
            	    }            	    
            	    //******************************************************************************************
            	    
            	    
            	    //**Task8: Insert AcitvityOwner...            	               	   
            	    for(int tkCnt = 0; tkCnt < ownerID.size(); tkCnt++){
            	        
            	        try{
            	            insertOwnerActivity.setString(1, ownerID.get(tkCnt).toString().trim()); 	//ownerid
            	            insertOwnerActivity.setString(2, activityID.toString().trim()); 			//activityid
            	            insertOwnerActivity.setString(3, SoxicConstants.GREEN_IMPORTED); 								//status
            	                	         
            	            insertOwnerActivity.setDate(4, date);										//mod_date
            	            insertOwnerActivity.setString(5, "rdesai2"); 								//mod_user
        	    
            	            insertOwnerActivity.executeUpdate();
        	            
            	        }
            	        catch(SQLException e){
            	        	if(e.getErrorCode() == 1){
                    			//***Duplicate value being added...expected error
                    			logger.warn("Duplicate Entry while adding Ativity Owner: " + e.getMessage());
                    		}
                    		else if(activityID != null && !activityID.equals("")){
                    			logger.error("Critical Unknown Error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + e.getMessage());
                    		}
                	    
                	    }
            	       
            	    }//end for..
            	    
 
            	    
            	    
            	    
            	    
            	    //**Commit Transaction
            	    //con.commit();
            	    
            	}
            	catch(Exception ex){
            	    
            	    //**Rollback Transaction
            	    //con.rollback();
            	    
            	    logger.error("Some Critical Database error -> Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" Msg : " + ex.getMessage());
            	}
            	
            	
            }//end row no
            
            //**Close the connection...
            con.close();
            SoxicConnectionFactory.closeSoxicConnection(con);

            logger.info("-> Successful Import !!!");
            logger.info("Number of Rows added: " + (totalRows - rowSkipped));
            if(rowSkipped == 0){
                logger.info("Rows Added: " + (totalRows - rowSkipped) +", Rows Skipped: " + (rowSkipped) + "\n");
                Date outputDate = new Date(System.currentTimeMillis());
                (System.out).println("Success "+outputDate+" :"+filename+" imported Successfully");
            }
            else{
                logger.error("Rows Added: " + (totalRows - rowSkipped) +", Rows Skipped: " + (rowSkipped) + "\n");
            }
            
//        }
//        catch (Exception e)
//        {
//
//             if(e instanceof SubCycleAlreadyPresent){
//                logger.error("File Error :"+filename+" :"+e.getMessage());
//                throw new SubCycleAlreadyPresent();
//            }
//            else {
//                logger.error("File Error :"+filename+" :"+e.getMessage());
//                throw new FileImportException();
//          }
//
//        }

        return headerBean;
    }

    public void insertControlObjectiveCode(String activityId,String controlObjectiveCodeString){
        List templateCodeList =  new ArrayList();
        StringTokenizer st = new StringTokenizer(controlObjectiveCodeString,",");

        while(st.hasMoreTokens()) {
            templateCodeList.add(st.nextToken().trim());
        }

        Iterator iterator = templateCodeList.iterator();

        while(iterator.hasNext()){
            try{
                insertControlObjectiveCode.setString(1,activityId);
                insertControlObjectiveCode.setString(2,SoxicConstants.CODE);
                insertControlObjectiveCode.setString(3,(String)iterator.next());
                insertControlObjectiveCode.executeUpdate() ;
            }catch(SQLException sqle){
                if(sqle.getErrorCode() == 1){
                    //***Duplicate value being added...expected error
                    logger.error("Unknown template Code: " + sqle.getMessage());
                }
            }
        }

    }

    public void insertControlObjectiveCategory(String activityId,String controlObjectiveCategoryString){
        List templateCategoryList =  new ArrayList();
        StringTokenizer st = new StringTokenizer(controlObjectiveCategoryString,",");

        while(st.hasMoreTokens()) {
            templateCategoryList.add(st.nextToken().trim());
        }

        Iterator iterator = templateCategoryList.iterator();

        while(iterator.hasNext()){
            try{
                insertControlObjectiveCode.setString(1,activityId);
                insertControlObjectiveCode.setString(2,SoxicConstants.CATEGORY);
                insertControlObjectiveCode.setString(3,(String)iterator.next());
                insertControlObjectiveCode.executeUpdate() ;
            }catch(SQLException sqle){
                if(sqle.getErrorCode() == 1){
                    //***Duplicate value being added...expected error
                    logger.error("Unknown template Category: " + sqle.getMessage());
                }
            }
        }

    }

    /**
     * This method returns false if the cycle id and subcycle id passed in do not match the 
     * respective parts in activityid
     * @param cycleId
     * @param subCycleId
     * @param activityId
     * @return
     */
    public static boolean isActivityInRightPlace(String cycleId,String subCycleId,String activityId){
    	
    	StringTokenizer stringTokenizer = new StringTokenizer(activityId,".");
    	String activityCycleId = stringTokenizer.nextToken()+"."+stringTokenizer.nextToken()+"."+stringTokenizer.nextToken();
    	String activitySubCycleId = stringTokenizer.nextToken();
    	if(activityCycleId.equalsIgnoreCase(cycleId) && activitySubCycleId.equalsIgnoreCase(subCycleId)){
    		return true;
    	}
    	return false;
    	
    }
    
    public void isFileWellFormed()throws Exception, InCorrectCountryException, InCorrectCycleDescription, SubCycleAlreadyPresent, FileImportException{
    	
    	//Step 1 Check if country is correct or not.
    	isCountryCorrect();
    	
    	//Step 2 Check for Cycle Description (If cycle is present in the database
    	// check against that for the description)
    	isCycleDesriptionCorrect();
    	//Step 3 Check if sub-cycle is already present in the system
    	isSubCyclePresent();
    	//Step 4 Check if activity is already present in the system
    	
    	//Step 5 Check if all the activities present are activities of the current cycle and subcycle
    	isActivityInRightPlace();
    }
    
    public void isCycleDesriptionCorrect()throws Exception{
		StringTokenizer filest = new StringTokenizer(filename, ".");
		
		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){            					   
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){            					   
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}
		
    	String cycleDescription = headerBean.getCycleDesc();
    	try{
            Connection con = SoxicConnectionFactory.getSoxicConnection();
	    	PreparedStatement ps = con.prepareStatement("SELECT C.DESCRIPTION FROM CYCLE C WHERE C.CYCLE_ID=?");
	    	ps.setString(1,cycleID);
	    	ResultSet rs = ps.executeQuery();
	    	
	    	while(rs.next()){
	    		String description = rs.getString("DESCRIPTION");
	    		if(!description.trim().equalsIgnoreCase(cycleDescription.trim())){
            throw new InCorrectCycleDescription(new Exception("In Correct Cycle Description"));
	    		}
	    	}
            SoxicConnectionFactory.closeSoxicConnection(con);
    	}catch(SQLException ex){
    		logger.error("Database Error");
    	}
    }


    public void isSubCyclePresent()throws Exception{
		StringTokenizer filest = new StringTokenizer(filename, ".");
		
		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){            					   
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){            					   
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}
	   	try{
            Connection con = SoxicConnectionFactory.getSoxicConnection();
	    	PreparedStatement ps = con.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC WHERE SC.SUB_CYCLE_ID=?");
	    	ps.setString(1,cycleID+"."+subCycleID);
	    	ResultSet rs = ps.executeQuery();
	    	
	    	while(rs.next()){
                throw new SubCycleAlreadyPresent(new Exception("Subcycle already present"));

	    	}
               SoxicConnectionFactory.closeSoxicConnection(con);
    	}catch(SQLException ex){
    		logger.error("Database Error");
    	}	
		
    }
    
    public void isCountryCorrect()throws InCorrectCountryException{
    	
		StringTokenizer filest = new StringTokenizer(filename, ".");
		
		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){            					   
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){            					   
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}
		
    	String cellCountryName = headerBean.getCountry();
    	
    	String countryCode = SoxicUtil.getCountryCode(countryIDFromFilename);
    	if(!countryCode.trim().equalsIgnoreCase(cellCountryName.trim())){
            throw new InCorrectCountryException("Incorrect country specified in the template");
    	}
    }
    
    public PersonInfo returnPeople(String userid)throws Exception{
    	
   		PeopleService svc = new PeopleService();
    	PersonInfo[] person = svc.GetPeople("", "", "", "", userid, "", "");
    	
    	if(person==null){
    		throw new InvalidUserException();
    	}
    	
    	for(int i=0;i<person.length;i++){
    		PersonInfo personInfo = person[i];
    		if(personInfo.getUserId().equalsIgnoreCase(userid)){
    			return personInfo;
    		}
    	}
    	return null;
    	
    }
    
    
    public void isActivityInRightPlace() throws ActivityInWrongTemplate{
    	
		StringTokenizer filest = new StringTokenizer(filename, ".");
		
		String periodID="";
		String countryIDFromFilename="";
		String cycleCode="";
		String cycleID="";
		String subCycleID="";
		String subCycleCode="";
		//**we need first 3 tokens...
		for(int i = 0; i < 4; i++){
				if(i == 0){
				    periodID = filest.nextToken();
				}
				if(i == 1){
					countryIDFromFilename = filest.nextToken();
				}
				if(i == 2){            					   
				    cycleCode = filest.nextToken();
				    cycleID = periodID + "." + countryIDFromFilename + "." + cycleCode;
				}
				if(i == 3){            					   
					subCycleCode = filest.nextToken();
					StringTokenizer subst = new StringTokenizer(subCycleCode," ");
					subCycleID = subst.nextToken();
				}
				logger.debug("CycleCode = " + cycleCode);
		}
		
        for(int rowno = 0; rowno < ExcelRowSet.size(); rowno++){
        	
        	ExcelRow = (Vector)ExcelRowSet.get(rowno);
        	     	
        	//**Reset Codes...
        	String activityID = "";
           	String activityCycleId = "";
			String activitySubCycleId = "";
			
       	
        	//**For exactly 8 cells...
        	for(int cellno = 0; cellno < 8; cellno++){
        		
        		//**Extract the (first cell)codes...(Required Attribute)
        		if(cellno == 0){
        		    
        		    //**Skip the row, if activity id is not present...
        		    if(ExcelRow.size() >= 1){
        		        activityID = (String)ExcelRow.get(cellno);
        		        activityID = activityID.trim();
        		    }
        		    else{
        		        logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
        		        rowSkipped++;
        		        break;
        		    }
        			
        			//**Double check...(for empty string)
        			if(activityID == null || activityID.equals("")){
        			    logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" -ActivityID missing, Row Skipped");
        		        rowSkipped++;
        			    break;
        			}
        		}
        		
        	   	StringTokenizer stringTokenizer = new StringTokenizer(activityID,".");
            	activityCycleId = stringTokenizer.nextToken();
            	activitySubCycleId = stringTokenizer.nextToken();

            	if(!activityCycleId.equalsIgnoreCase(cycleCode) || !activitySubCycleId.equalsIgnoreCase(subCycleID)){
            		logger.error("Filename: " + filename + " Row No: " + (rowno + 1 + 7) +" File skipped");
                throw new ActivityInWrongTemplate(new Exception("Activity in Wrong File"));
            	}

          }
        }

    }


	public static void main(String[] args) {
		try{
			ImportExcel2DB importExcel;

			//**Reading all from a given Folder...[ExcelFiles\...filename.xls]
			logger.error("Argument passed :"+args[0]);
			logger.error("Argument passed :"+args[1]);
	     //   File directory = new File(ImportExcel2DB.folderName);
			//logger.warn("Current File path :"+args[0]);
			//File directory = new File(args[0]);
	    //    File [] files = directory.listFiles();
		//	if(files == null || files.length == 0){
		//		logger.warn("Please put all the excel files to be imported in the folder 'ExcelFiles' directly under the project.");
		//	}
		//	else{
		//		for (int i = 0; i < files.length; i++) {

		//			logger.debug("File-name found !!!");

					//**Call Constructor with diff filenames...
		//			importExcel = new ImportExcel2DB(filename,args[0],args[1]);
		//			importExcel.wb = importExcel.hssfworkbook;

		//			importExcel.sheet= importExcel.wb.getSheetAt(0);
		//			importExcel.importFile();
		//		}
		//	}

		}
		catch(Exception ex){
			ex.printStackTrace();
		}


	}


}

