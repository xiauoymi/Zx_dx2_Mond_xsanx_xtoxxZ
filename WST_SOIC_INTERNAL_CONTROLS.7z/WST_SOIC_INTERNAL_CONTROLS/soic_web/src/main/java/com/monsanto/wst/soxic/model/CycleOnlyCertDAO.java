package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.facade.CycleOnlyConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 30, 2006
 * Time: 4:10:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class CycleOnlyCertDAO {

    private static final String getCycleOnlyPeriodStatus = "SELECT CYCLE_ONLY_PERIOD FROM PERIOD WHERE PERIOD_ID = ?";

    private static final String getCycleStateForCycleId = "SELECT STATE FROM CYCLE_STATE WHERE CYCLE_ID = ?";
       

    public boolean checkForPeriodStatus(String period) {
        boolean value = false;
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getCycleOnlyPeriodStatus);
			    preparedStatement.setString(1,period);

                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    String cycle_only = rs.getString("CYCLE_ONLY_PERIOD");
                    if (cycle_only.equalsIgnoreCase("Y")){
                        value = true;
                    }
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    }
            catch (Exception e) {
				e.printStackTrace();
			}
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return value;
    }

    public boolean checkForCycleState(String cycleId) {
        boolean value = false;
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getCycleStateForCycleId);
			    preparedStatement.setString(1,cycleId);

                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    String cycle_only = rs.getString("STATE");
                    if (cycle_only.equalsIgnoreCase(SoxicConstants.CERTIFICATION_STATE) || cycle_only.equalsIgnoreCase(SoxicConstants.PRE_CERTIFICATION_STATE)){
                        value = true;
                    }
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    }
            catch (Exception e) {
				e.printStackTrace();
			}
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return value;
    }

    public void updateStatusBasedOnType(String query) {
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(query);
                int n = preparedStatement.executeUpdate();

            } catch (SQLException e) {
			    e.printStackTrace();
		    }
            catch (Exception e) {
				e.printStackTrace();
			}
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }

    public List getQuestionList(String sysType) {
        Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
        List questionList = new ArrayList();

        try {
			    con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement("SELECT QUESTION_ID FROM QUESTION WHERE LEVEL_TYPE = ?");
                if (sysType.equalsIgnoreCase(CycleOnlyConstants.ACT)){
                    preparedStatement.setString(1,CycleOnlyConstants.QUEST_ACT);
                }
                if (sysType.equalsIgnoreCase(CycleOnlyConstants.SUBCYCLE)){
                    preparedStatement.setString(1,CycleOnlyConstants.QUEST_SC);
                }
                rs= preparedStatement.executeQuery();
                while (rs.next()){
                    questionList.add(rs.getString("QUESTION_ID"));
                }

            } catch (SQLException e) {
			    e.printStackTrace();
		    }
            catch (Exception e) {
				e.printStackTrace();
			}
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        return questionList;
    }

}
