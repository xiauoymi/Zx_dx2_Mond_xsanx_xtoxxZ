package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;

import java.util.Collection;
import java.util.Map;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 3, 2005
 * Time: 4:39:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class OracleOwnerChangeRequestResponseDAO extends OracleAbstractDAO{
        public void update(Collection soxicBaseModels) throws DatabaseException, Exception{};


    protected  String buildSelectQuery(Map fields){
        return "";
    }

    protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception{
        return null;
    }

    public int create(SoxicBaseModel soxicBaseModel)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)soxicBaseModel;
            preparedStatement = connection
                    .prepareStatement(ownerChangeRequestResponse.getQuery("INSERT"));
            ownerChangeRequestResponse.setParameters(preparedStatement,"INSERT");
                            preparedStatement.setString(1,ownerChangeRequestResponse.getResponseId());
                preparedStatement.setString(2,ownerChangeRequestResponse.getResponseType());
                preparedStatement.setString(3,ownerChangeRequestResponse.getOwnerId());
                //preparedStatement.setDate(4,new Date(System.currentTimeMillis()));
                preparedStatement.setTimestamp(4,new Timestamp(System.currentTimeMillis()));
                preparedStatement.setString(5,ownerChangeRequestResponse.getApproved());
                preparedStatement.setString(6,ownerChangeRequestResponse.getNotes());
                preparedStatement.setDate(7,new Date(System.currentTimeMillis()));
                preparedStatement.setString(8,ownerChangeRequestResponse.getOwnerId());
            result = preparedStatement.executeUpdate();


        }catch(SQLException e){
           e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return result;
    }

    public void select(SoxicBaseModel model,String queryType)throws Exception{
        OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)model;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try{
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OCREQ_ID,RESP_TYPE,OWNER_ID,RESP_DATE,APPROVED,NOTES FROM OCREQ_RESPONSE WHERE OCREQ_ID=?");
            preparedStatement.setString(1,ownerChangeRequestResponse.getResponseId());
        }catch(SQLException e){
          e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }

    public int updateModel(SoxicBaseModel model)throws Exception{
        OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)model;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;
        try{
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE OCREQ_RESPONSE SET APPROVED=? , NOTES=?, RESP_DATE=? WHERE OCREQ_ID=? AND RESP_TYPE=?");
            preparedStatement.setString(1,ownerChangeRequestResponse.getApproved());
            preparedStatement.setString(2,ownerChangeRequestResponse.getNotes());
            preparedStatement.setTimestamp(3,new Timestamp(System.currentTimeMillis()));
            preparedStatement.setString(4,ownerChangeRequestResponse.getResponseId());
            preparedStatement.setString(5,ownerChangeRequestResponse.getResponseType());
            result = preparedStatement.executeUpdate();
        }catch(SQLException e){
          e.printStackTrace();
        }finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				SoxicConnectionFactory.closeResultSet(rs);
				SoxicConnectionFactory.closePreparedStatement(preparedStatement);
				SoxicConnectionFactory.closeSoxicConnection(connection);
				//connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        return result;
    }
}
