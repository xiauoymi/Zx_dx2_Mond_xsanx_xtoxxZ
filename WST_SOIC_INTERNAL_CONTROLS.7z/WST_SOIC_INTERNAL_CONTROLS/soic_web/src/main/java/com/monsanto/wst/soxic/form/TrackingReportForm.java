//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/** 
 * MyEclipse Struts
 * Creation date: 03-22-2005
 * 
 * XDoclet definition:
 * @struts:form name="trackingReportForm"
 */
public class TrackingReportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	
	//Table1
	private Vector cycleTrackingVector = new Vector();
	
	private Vector cycleCodes = new Vector();
	
	private String todaysDate;
	
	//**Table2
	private Vector worldAreaVector = new Vector();
	
	private String periodID = "FY05";
	
	private int totalNALAN;
	
	private int totalInternational;
	
	private int totalMonsanto;
	
	private String countryID;
	
	
	// --------------------------------------------------------- Methods
	
	
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		
		if(periodID == null || periodID.equals("")){
			errors.add("periodID4", new ActionError("errors.activityReport.periodID.null"));
			
		}
		
		return errors;
	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}
	
	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}
	
	
	/**
	 * @return Returns the cycleCodes.
	 */
	public Vector getCycleCodes() {
		return cycleCodes;
	}
	/**
	 * @param cycleCodes The cycleCodes to set.
	 */
	public void setCycleCodes(Vector cycleCodes) {
		this.cycleCodes = cycleCodes;
	}
	/**
	 * @return Returns the cycleTackingVector.
	 */
	public Vector getCycleTrackingVector() {
		return cycleTrackingVector;
	}
	/**
	 * @param cycleTackingVector The cycleTackingVector to set.
	 */
	public void setCycleTrackingVector(Vector cycleTrackingVector) {
		this.cycleTrackingVector = cycleTrackingVector;
	}
	/**
	 * @return Returns the totalInternational.
	 */
	public int getTotalInternational() {
		return totalInternational;
	}
	/**
	 * @param totalInternational The totalInternational to set.
	 */
	public void setTotalInternational(int totalInternational) {
		this.totalInternational = totalInternational;
	}
	/**
	 * @return Returns the totalMonsanto.
	 */
	public int getTotalMonsanto() {
		return (totalNALAN + totalInternational);
	}
	/**
	 * @param totalMonsanto The totalMonsanto to set.
	 */
	public void setTotalMonsanto(int totalMonsanto) {
		this.totalMonsanto = totalMonsanto;
	}
	/**
	 * @return Returns the totalNALAN.
	 */
	public int getTotalNALAN() {
		return totalNALAN;
	}
	/**
	 * @param totalNALAN The totalNALAN to set.
	 */
	public void setTotalNALAN(int totalNALAN) {
		this.totalNALAN = totalNALAN;
	}
	/**
	 * @return Returns the worldAreaVector.
	 */
	public Vector getWorldAreaVector() {
		return worldAreaVector;
	}
	/**
	 * @param worldAreaVector The worldAreaVector to set.
	 */
	public void setWorldAreaVector(Vector worldAreaVector) {
		this.worldAreaVector = worldAreaVector;
	}
	/**
	 * @return Returns the todaysDate.
	 */
	public String getTodaysDate() {
		return todaysDate;
	}
	/**
	 * @param todaysDate The todaysDate to set.
	 */
	public void setTodaysDate(String todaysDate) {
		this.todaysDate = todaysDate;
	}	
	/**
	 * @return Returns the countryID.
	 */
	public String getCountryID() {
		return countryID;
	}
	/**
	 * @param countryID The countryID to set.
	 */
	public void setCountryID(String countryID) {
		this.countryID = countryID;
	}
}