package com.monsanto.wst.soxic.controllers.reportingframework;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.wst.soxic.reportingFramework.*;
import com.monsanto.wst.soxic.exception.DatabaseException;

import java.io.IOException;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 2:06:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        String selectedReport = (String) helper.getRequestParameterValue(SoxReportConstants.FRAMEWORK_REPORTID);
        ReportProperties reportProperties=null;
        Document outputDocument=null;
        AbstractReport testReportOne = null;
//        ReportParameters reportParameters = new ReportParameters(helper);
        ReportParameters reportParameters = (ReportParameters) helper.getSessionParameter(SoxReportConstants.REPORT_PARAMETERS);
        try {
            reportProperties = new ReportProperties(selectedReport);
            reportProperties.parseXmlFile();
            String reportClassString = reportProperties.getReportClass();
            Class reportClass = Class.forName(reportClassString.toString());
            Object reportClassInstance = reportClass.newInstance();
            testReportOne = (AbstractReport) reportClassInstance;
            outputDocument = testReportOne.buildReportXML(reportParameters, reportProperties);
            DOMUtil.outputXML(outputDocument);
        } catch (IllegalAccessException e) {
            Logger.log(new LoggableError("Error exporting, Stack Trace..."));
            Logger.log(new LoggableError(e));
        } catch (DatabaseException e) {
            Logger.log(new LoggableError("Error exporting, Stack Trace..."));
            Logger.log(new LoggableError(e));
        } catch (XmlException e) {
            Logger.log(new LoggableError("Error exporting, Stack Trace..."));
            Logger.log(new LoggableError(e));
        } catch (InstantiationException e) {
            Logger.log(new LoggableError("Error exporting, Stack Trace..."));
            Logger.log(new LoggableError(e));
        } catch (ClassNotFoundException e) {
            Logger.log(new LoggableError("Error exporting, Stack Trace..."));
            Logger.log(new LoggableError(e));
        }
//        String exportType = (String) reportParameters.getReportParameter(IAReportConstants.EXPORT_TYPE);
        String exportType = (String) helper.getRequestParameterValue(SoxReportConstants.EXPORT_TYPE);
        if(exportType.equalsIgnoreCase("WORD")){
            String exportFileName = testReportOne.returnExportFileNameKey();
            if(exportFileName != null && exportFileName.length() > 0){
                exportFileName = reportProperties.getExportFileName() + "_" + exportFileName + ".doc";
            }
            else{
                exportFileName = reportProperties.getExportFileName() + ".doc";
            }
//            helper.writeToWord(outputDocument,reportProperties.getExportXSL(exportType), exportFileName);
            helper.writeToWord(outputDocument,reportProperties.getExportXSL(exportType));
        }
        if(exportType.equalsIgnoreCase("EXCEL")){
            String exportFileName = testReportOne.returnExportFileNameKey();
            if(exportFileName != null && exportFileName.length() > 0){
                exportFileName = reportProperties.getExportFileName() + "_" + exportFileName + ".xls";
            }
            else{
                exportFileName = reportProperties.getExportFileName() + ".xls";
            }
//            helper.writeToExcel(outputDocument,reportProperties.getExportXSL(exportType), exportFileName);
            helper.writeToExcel(outputDocument,reportProperties.getExportXSL(exportType));
        }
    }
}
