package com.monsanto.wst.soxic.reportingFramework;

import org.xml.sax.SAXException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:22:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class XmlException extends Exception {
    public XmlException(Exception e) {
        super(e);
    }
}
