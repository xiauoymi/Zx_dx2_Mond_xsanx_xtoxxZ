/*
 * Created on May 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.exception;

/**
 * @author vrbethi
 */
public class InCorrectCountryException extends Exception {
	public InCorrectCountryException(){
		super();
	}
	
	public InCorrectCountryException(Exception e){
		super(e);
	}

  public InCorrectCountryException(String message) {
    super(message);
  }
}
