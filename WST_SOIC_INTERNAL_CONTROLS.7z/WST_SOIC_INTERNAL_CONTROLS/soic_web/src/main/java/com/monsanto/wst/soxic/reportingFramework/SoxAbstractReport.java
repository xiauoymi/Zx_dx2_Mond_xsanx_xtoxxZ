package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.tags.Navigation;
import com.monsanto.wst.soxic.util.NavConstants;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.XMLUtil.DOMUtil;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.List;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 1:36:40 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class SoxAbstractReport extends AbstractReport{

    public static final String EXPORT_TYPE = "exporttype";

    public Document buildReportXML(ReportParameters reportParameters, ReportProperties reportProperties) throws DatabaseException {
        DocumentBuilder builder = null;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        Document outputDocument = builder.newDocument();
        Element reportElement =DOMUtil.addChildElement(outputDocument,SoxReportConstants.REPORT_TAG);
        DOMUtil.addChildElement(reportElement,SoxReportConstants.REPORT_NAME,reportProperties.getReportName());
        Element rootOutputElement = DOMUtil.addChildElement(reportElement,SoxReportConstants.REPORT_DATA);
        buildIAuditReportXML(rootOutputElement, reportParameters);
        addExportPart(reportParameters, reportElement, outputDocument, reportProperties);
        DOMUtil.outputXML(outputDocument);
        return outputDocument;
    }

    public Document buildFilterXML(ReportParameters reportParameters, ReportProperties reportProperties) throws DatabaseException {
        DocumentBuilder builder = null;
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        Document outputDocument = builder.newDocument();
        Element reportElement =DOMUtil.addChildElement(outputDocument,SoxReportConstants.REPORT_OPTIONS_TAG);
        DOMUtil.addChildElement(reportElement,SoxReportConstants.REPORT_NAME,(String) reportParameters.getReportParameter("report"));
        DOMUtil.addChildElement(reportElement,SoxReportConstants.SECURE_NAV,getSecureNav(reportParameters));
        Element rootOutputElement = DOMUtil.addChildElement(reportElement,SoxReportConstants.REPORT_OPTIONS_DATA);
        buildFilterXML(rootOutputElement);
        DOMUtil.outputXML(outputDocument);
        return outputDocument;
    }

    private void exportTag(Element element, ReportParameters reportParameters, ReportProperties reportProperties) {
        Element exportListOutputElement = DOMUtil.addChildElement(element,SoxReportConstants.EXPORT_OPTIONS);
        List exportParameterList = reportProperties.getExportList();
        Iterator iterator = exportParameterList.iterator();
        while(iterator.hasNext()){
            Export export=(Export) iterator.next();
            if(export.getType().equalsIgnoreCase(SoxReportConstants.EXPORT_TYPE_WORD)){
                Element exportOutputElement = DOMUtil.addChildElement(exportListOutputElement,SoxReportConstants.EXPORT);
                DOMUtil.addChildElement(exportOutputElement,EXPORT_TYPE,export.getType());
                String fileName = reportProperties.getExportFileName() + "_"+returnExportFileNameKey()+".doc";
                DOMUtil.addChildElement(exportOutputElement,SoxReportConstants.REPORT_ACTION_FILENAME,"export/"+fileName);
                DOMUtil.addChildElement(exportOutputElement,SoxReportConstants.REPORT_PARAMTER,(String) reportParameters.getReportParameter(SoxReportConstants.FRAMEWORK_REPORTID));
                DOMUtil.addChildElement(exportOutputElement,SoxReportConstants.WORDING,"Export To Word");
            }
            if(export.getType().equalsIgnoreCase(SoxReportConstants.EXPORT_TYPE_EXCEL)){
                String fileName = reportProperties.getExportFileName() + "_"+returnExportFileNameKey()+".xls";
                Element exportOutputElement1 = DOMUtil.addChildElement(exportListOutputElement,SoxReportConstants.EXPORT);
                DOMUtil.addChildElement(exportOutputElement1,EXPORT_TYPE,export.getType());
                DOMUtil.addChildElement(exportOutputElement1,SoxReportConstants.REPORT_ACTION_FILENAME,"export/"+fileName);
                DOMUtil.addChildElement(exportOutputElement1,SoxReportConstants.REPORT_PARAMTER,(String) reportParameters.getReportParameter(SoxReportConstants.FRAMEWORK_REPORTID));
                DOMUtil.addChildElement(exportOutputElement1,SoxReportConstants.WORDING,"Export To Excel");
            }
        }
    }

    private void addExportPart(ReportParameters reportParameters, Element element, Document outputDocument, ReportProperties reportProperties) {
        String exptype=(String) reportParameters.getReportParameter(SoxReportConstants.EXPORT_TYPE);
        if(exptype==null){
            exportTag(element, reportParameters, reportProperties);
            SoxDOMUtil.addCDATAChildElement(element,SoxReportConstants.SECURE_NAV,getSecureNav(reportParameters));

        }else{

        }
    }

    private String getSecureNav(ReportParameters reportParameters){
        Owner owner = (Owner)reportParameters.getReportParameter(SoxicConstants.OWNER);
        Navigation navigation = new Navigation("",NavConstants.PAGE_REPORTS,SoxicConstants.CONTEXT_PATH,owner);
        return navigation.buildNavHTMLString();
//        return "";
    }

    public abstract void buildFilterXML(Element rootOutputElement) throws DatabaseException;

    protected abstract void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException;
}
