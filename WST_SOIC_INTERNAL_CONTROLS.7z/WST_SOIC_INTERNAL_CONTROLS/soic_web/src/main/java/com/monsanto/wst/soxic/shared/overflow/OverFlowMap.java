package com.monsanto.wst.soxic.shared.overflow;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 14, 2005
 * Time: 10:49:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class OverFlowMap {
    private Map hashMap;

    public OverFlowMap() {
        this.hashMap = new HashMap();
    }

    public void add(String overFlowId, String seqId, String seqText, String firstTwoThousandCharacters){
        OverFlow overFlow = null;
        if(hashMap.get(overFlowId) == null){
            if(overFlowId!=null && !overFlowId.equalsIgnoreCase("0")){
                overFlow = new OverFlow(overFlowId,firstTwoThousandCharacters);
                overFlow.addToSequenceMap(seqId,seqText);
                hashMap.put(overFlowId,overFlow);
            }

        }else{
            overFlow = (OverFlow) hashMap.get(overFlowId);
            overFlow.addToSequenceMap(seqId, seqText);
        }
    }

    public String getCompleteString(String overflowId) {
        OverFlow overFlow = (OverFlow) hashMap.get(overflowId);
        if(overFlow!=null){
            return overFlow.buildOriginalString();
        }
        return null;
    }
}
