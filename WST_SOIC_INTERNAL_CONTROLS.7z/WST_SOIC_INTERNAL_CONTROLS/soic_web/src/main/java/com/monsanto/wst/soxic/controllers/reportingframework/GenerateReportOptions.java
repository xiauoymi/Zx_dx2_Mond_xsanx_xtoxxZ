package com.monsanto.wst.soxic.controllers.reportingframework;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.soxic.reportingFramework.AbstractReport;
import com.monsanto.wst.soxic.reportingFramework.ReportXmlParser;
import com.monsanto.wst.soxic.reportingFramework.ReportProperties;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;

import java.io.IOException;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:17:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenerateReportOptions implements UseCaseController{
    public void run(UCCHelper helper) throws IOException {
        ReportProperties reportProperties=null;
        String selectedReport = helper.getRequestParameterValue("report");
        try {
            helper.setRequestAttributeValue("report", selectedReport);
            reportProperties = new ReportProperties(selectedReport);
            reportProperties.parseXmlFile();
            String filterClassString = reportProperties.getFilterClass();
            Class filterClass= Class.forName(filterClassString.toString());
            Object filterClassInstance = filterClass.newInstance();
            AbstractReport testReportOne = (AbstractReport) filterClassInstance;
            Document outputDocument = testReportOne.buildFilterXML(new ReportParameters(helper), reportProperties);
            DOMUtil.outputXML(outputDocument);
            helper.applyStylesheet(outputDocument,reportProperties.getFilterXSL());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
