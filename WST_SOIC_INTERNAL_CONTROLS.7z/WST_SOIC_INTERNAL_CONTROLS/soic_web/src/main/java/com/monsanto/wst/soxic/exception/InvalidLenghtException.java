package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 10, 2006
 * Time: 3:30:17 PM
 */
public class InvalidLenghtException extends Exception {

    public InvalidLenghtException() {
        super();
    }

    public InvalidLenghtException(Exception e){
		super(e);
	}
}
