package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.SoxicBaseModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 3, 2005
 * Time: 10:20:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class OracleOwnerChangeRequestDAO extends OracleAbstractDAO{
    public void update(Collection soxicBaseModels) throws DatabaseException, Exception{};


    protected  String buildSelectQuery(Map fields){
        return "";
    }

    protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception{
        return null;
    }

    public int create(SoxicBaseModel soxicBaseModel)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            OwnerChangeRequest ownerChangeRequest = (OwnerChangeRequest)soxicBaseModel;
            preparedStatement = connection
                    .prepareStatement(ownerChangeRequest.getQuery("INSERT"));
            ownerChangeRequest.setParameters(preparedStatement,"INSERT");
            result = preparedStatement.executeUpdate();


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public SoxicBaseModel select(SoxicBaseModel soxicBaseModel,String selectType)throws Exception{

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            OwnerChangeRequest ownerChangeRequest = (OwnerChangeRequest)soxicBaseModel;
            preparedStatement = connection
                    .prepareStatement(ownerChangeRequest.getQuery(selectType));
            ownerChangeRequest.setParameters(preparedStatement,selectType);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                ownerChangeRequest.populateModel(rs);
            }


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return soxicBaseModel;
    }

    public int updateModel(SoxicBaseModel soxicBaseModel)throws Exception{
        OwnerChangeRequest ownerChangeRequest=(OwnerChangeRequest)soxicBaseModel;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;
        try{
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE OWNER_CHANGE_REQUEST SET REQ_TEXT=?,OVERFLOW_ID=?,PRIORITY=? WHERE OCREQ_ID=?");
            preparedStatement.setString(1,ownerChangeRequest.getRequestText());
            preparedStatement.setInt(2,ownerChangeRequest.getOverFlowId());
            preparedStatement.setString(3,ownerChangeRequest.getPriority());
            preparedStatement.setString(4,ownerChangeRequest.getOwnerChangeRequestId());
            result = preparedStatement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public int updateWithNewIdForIA(String newId,String ocreqId)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;
        try{
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE OWNER_CHANGE_REQUEST SET TARGET_ID=? WHERE OCREQ_ID=?");
            preparedStatement.setString(1,newId);
            preparedStatement.setString(2,ocreqId);
            result = preparedStatement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public List selectActivitiesForWhichDocumentChangeRequested(String ownerId,String subCycleId){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        List activityList = new ArrayList();


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OCR.TARGET_ID FROM OWNER_CHANGE_REQUEST OCR,ACTIVITY A,CTRL_OBJ CO,SUB_CYCLE SC WHERE OCR.OWNER_ID=? AND A.ACTIVITY_ID=OCR.TARGET_ID AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID AND SC.SUB_CYCLE_ID =? AND (OCR.REQ_TYPE='MODIFY' OR OCR.REQ_TYPE='DELETE')");
            preparedStatement.setString(1,ownerId);
            preparedStatement.setString(2,subCycleId);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                activityList.add(rs.getString("TARGET_ID"));
            }

        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return activityList;
    }

    public int insertOverFlowText(Vector chunk){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;
        int maxId=-1;



        try {
            maxId =selectMaxOverFlowId();
//            maxId =maxId+1;
            int seq = maxId;
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO TEXT_OVERFLOW (OVERFLOW_ID,SEQUENCE,TEXT_CHUNK) VALUES(?,?,?)");
            for(int i=1;i<chunk.size();i++){
                preparedStatement.setInt(1,maxId);
                preparedStatement.setInt(2,seq);
                preparedStatement.setString(3,(String)chunk.get(i));
                preparedStatement.addBatch();
                seq++;
            }

            int i[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
        return maxId;
    }

    public int selectMaxOverFlowId(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            //preparedStatement = connection.prepareStatement("SELECT MAX(OVERFLOW_ID) AS IDENTE FROM TEXT_OVERFLOW");
            preparedStatement = connection.prepareStatement("select overflow_id_sequence.nextval as SEQUENCE from dual");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
//               return rs.getInt("IDENTE");
                return rs.getInt (1);
            }


        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return -1;
    }
}
