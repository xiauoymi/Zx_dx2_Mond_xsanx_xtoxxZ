/*
 * Created on Jun 30, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerFile {
	
	public static void main(String args[]) throws Exception{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String sub_cycle_name = "GCC";
		
		String period ="FY05";
		
		String country="BRA";
		
		//UtilDAO utilDAO = new UtilDAO();
		
		//utilDAO.getCycleList(period);
		
		String activityFileName = "C://export//"+country+"_ACTIVITY_"+sub_cycle_name+".txt";
		String activityOwnerFileName = "C://export//"+country+"_ACTIVITY_OWNER_"+sub_cycle_name+".txt";
		String subCycleFileName = "C://export//"+country+"_SUBCYCLE_"+sub_cycle_name+".txt";
		String cycleFileName = "C://export//"+country+"_CYCLE_"+sub_cycle_name+".txt";
		
		String environment = args[0];
		String envVariable = args[1];
		
		Connection con=null;
		
		RandomAccessFile randomAccessFile = new RandomAccessFile(activityFileName,"rw");
		
		RandomAccessFile activityOwnerAccessFile= new RandomAccessFile(activityOwnerFileName,"rw");
		
		RandomAccessFile subCycleAccessFile= new RandomAccessFile(subCycleFileName,"rw");
		
		RandomAccessFile cycleOwnerAccessFile= new RandomAccessFile(cycleFileName,"rw");
		
		System.setProperty("DMONCRYPTJV",envVariable);
		BufferedReader brIn = null;
		String hexKey = null;
		String keyFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "KeyValue.hex";
		String cipherFile = System.getProperty("DMONCRYPTJV") + "/" + "soic" + "/" + "CipherValue.hex";
		try
		{
			brIn = new BufferedReader(new FileReader(keyFile));
			hexKey = brIn.readLine();
		}
		catch (FileNotFoundException ex)
		{
			throw new EncryptorException("EncryptionUtils::GetDecryptedStringFromExternalStorage - Invalid key file name.");
		}
		
		if(environment.equalsIgnoreCase("development")){
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			con = DriverManager.getConnection (SoxicUtil.getOracleDevServerConnectionString(), SoxicUtil.getOracleDevServerUserName(), decryptedPassword);
		}

		if(environment.equalsIgnoreCase("test")){
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			//**For connecting to Test Database...
			con = DriverManager.getConnection (SoxicUtil.getOracleTestServerConnectionString(), SoxicUtil.getOracleTestServerUserName(), decryptedPassword);
		}
		
		if(environment.equalsIgnoreCase("production")){
			
			String decryptedPassword = EncryptionUtils.GetDecryptedStringFromFile( cipherFile,hexKey );
			//**For connecting to Test Database...
			con = DriverManager.getConnection (SoxicUtil.getOracleProductionServerConnectionString(),SoxicUtil.getOracleProductionServerUserName(), decryptedPassword);
		}
		PreparedStatement preparedStatement=null;
		ResultSet rs=null,rs1=null,rs2=null,rs3=null;
		preparedStatement = con.prepareStatement("select DISTINCT OA.ACTIVITY_ID,o.NAME from owner_activity oa,owner o where oa.ACTIVITY_ID like '%FY05."+country+"."+sub_cycle_name+"%' AND oa.OWNER_ID=o.OWNER_ID  ORDER BY OA.ACTIVITY_ID");
		
		rs = preparedStatement.executeQuery();
		
		while(rs.next()){
			String activity = rs.getString("ACTIVITY_ID");
			String name = rs.getString("NAME");
			randomAccessFile.writeBytes(activity+"         "+name+System.getProperty("line.separator"));
		}
		randomAccessFile.close();
		
		preparedStatement = con.prepareStatement("select distinct o.NAME from owner_activity oa,owner o where oa.ACTIVITY_ID like '%FY05."+country+"."+sub_cycle_name+"%' and oa.OWNER_ID=o.OWNER_ID");
		
		rs1= preparedStatement.executeQuery();
		
		while(rs1.next()){
			String name = rs1.getString("NAME");
			activityOwnerAccessFile.writeBytes(name+System.getProperty("line.separator"));
		}
		activityOwnerAccessFile.close();
		
		preparedStatement = con.prepareStatement("select DISTINCT osc.SUB_CYCLE_ID,o.NAME from owner_sub_cycle osc,owner o where osc.SUB_CYCLE_ID like '%FY05."+country+"."+sub_cycle_name+"%' and osc.OWNER_ID=o.OWNER_ID  ORDER BY osc.SUB_CYCLE_ID");
		
		rs2= preparedStatement.executeQuery();
		
		while(rs2.next()){
			String subcycle = rs2.getString("SUB_CYCLE_ID");
			String name = rs2.getString("NAME");
			subCycleAccessFile.writeBytes(subcycle+"         "+name+System.getProperty("line.separator"));
		}
		subCycleAccessFile.close();
		
		preparedStatement = con.prepareStatement("select DISTINCT oc.CYCLE_ID,o.NAME from owner_cycle oc,owner o where oc.CYCLE_ID like '%FY05."+country+"."+sub_cycle_name+"%' and oc.OWNER_ID=o.OWNER_ID  ORDER BY oc.CYCLE_ID");
		
		rs3= preparedStatement.executeQuery();
		
		while(rs3.next()){
			String cycle = rs3.getString("CYCLE_ID");
			String name = rs3.getString("NAME");
			cycleOwnerAccessFile.writeBytes(cycle+"         "+name+System.getProperty("line.separator"));
		}
		cycleOwnerAccessFile.close();	
		
		try{
		if(con!=null && !con.isClosed()){
			con.close();
		}
		}catch(Exception e){
		
		}
		
	}

}
;