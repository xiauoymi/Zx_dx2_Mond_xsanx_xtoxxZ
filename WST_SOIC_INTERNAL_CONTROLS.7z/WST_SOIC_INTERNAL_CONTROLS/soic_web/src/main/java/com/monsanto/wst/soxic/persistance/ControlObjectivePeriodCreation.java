package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.ControlObjectiveNew;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.NewPeriodCreationException;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 24, 2005
 * Time: 4:37:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class ControlObjectivePeriodCreation {

   public static void main(String args[])throws Exception{
       ControlObjectivePeriodCreation controlObjectivePeriodCreation = new ControlObjectivePeriodCreation();
        long startTime,endTime,dif;
        startTime = System.currentTimeMillis();
       Connection connection=null;
        List subCycles = controlObjectivePeriodCreation.createControlObjective("FY05.","RAM01", connection);
        controlObjectivePeriodCreation.insertNewControlObjective(subCycles, connection);
        endTime = System.currentTimeMillis();
        dif = endTime-startTime;
   }

   public List createControlObjective(String sourcePeriodId, String targetPeriodId, Connection connection)throws Exception{
        List controlObjectiveList = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        ControlObjectiveNew controlObjectiveNew=null;
        // String query = "SELECT CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION, RISK FROM CTRL_OBJ WHERE CTRL_OBJ_ID='"+criteria.get(ControlObjectiveNew.CTRL_OBJ_ID)+"'";
        try {
            preparedStatement = connection.prepareStatement("SELECT CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION,OVERFLOW_ID, RISK FROM CTRL_OBJ WHERE CTRL_OBJ_ID LIKE '%"+sourcePeriodId+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                controlObjectiveNew = populateCurrentModel(rs);
                processControlObjective(controlObjectiveNew,targetPeriodId);
                controlObjectiveList.add(controlObjectiveNew);
            }
            //insertNewControlObjective(controlObjectiveNew,targetSubCycleId);

        } catch (SQLException e) {
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return controlObjectiveList;
    }


    protected ControlObjectiveNew populateCurrentModel(ResultSet rs) throws DatabaseException, Exception {

        ControlObjectiveNew controlObjective = new ControlObjectiveNew();

        try {

            controlObjective.setControlObjectiveId(rs.getString(ControlObjectiveNew.CTRL_OBJ_ID));
            controlObjective.setControlObjectiveCode(rs.getString(ControlObjectiveNew.CTRL_OBJ_CODE));
            controlObjective.setDescription(rs.getString(ControlObjectiveNew.DESCRIPTION));
            controlObjective.setOverFlowId(rs.getInt(ControlObjectiveNew.OVERFLOW_ID));
            //controlObjective.setStatus(rs.getString(ControlObjectiveNew.STATUS));
            controlObjective.setRisk(rs.getString(ControlObjectiveNew.RISK));
            //controlObjective.setGap(rs.getString(ControlObjectiveNew.POTENTIAL_GAP));
            //controlObjective.setDeficiency(rs.getString(ControlObjectiveNew.PREV_DEF));

            //controlObjective.setActivities(getActivities(controlObjective.getControlObjectiveId()));

        } catch (SQLException e) {
            throw new DatabaseException("error while populating ControlObjectiveNew from ResultSet:" + e.toString());

        }

        return controlObjective;
    }

    public void insertNewControlObjective(List controlObjectiveList, Connection connection)throws Exception{
        //Connection connection = null;
        PreparedStatement preparedStatement=null;

        String query = "INSERT INTO CTRL_OBJ (CTRL_OBJ_ID, CTRL_OBJ_CODE, SUB_CYCLE_ID, DESCRIPTION,OVERFLOW_ID, RISK, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";

        try {
            //connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);

            Iterator iterator = controlObjectiveList.iterator();
            while(iterator.hasNext()){
                ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew)iterator.next();
            preparedStatement.setString(1,controlObjectiveNew.getControlObjectiveId());
            preparedStatement.setString(2,controlObjectiveNew.getControlObjectiveCode());
            preparedStatement.setString(3,controlObjectiveNew.getSubCycleId());
            preparedStatement.setString(4,controlObjectiveNew.getDescription());
            preparedStatement.setInt(5,controlObjectiveNew.getOverFlowId());

            preparedStatement.setString(6,controlObjectiveNew.getRisk());
            preparedStatement.setString(7,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(8,new Date(System.currentTimeMillis()));
            preparedStatement.setString(9,"ADMIN");
                preparedStatement.addBatch();

            }



            int result[] = preparedStatement.executeBatch();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
            throw new NewPeriodCreationException(e);
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
//                if (connection != null)
//                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void processControlObjective(ControlObjectiveNew controlObjectiveNew,String targetPeriodId){
       StringTokenizer st = new StringTokenizer(controlObjectiveNew.getControlObjectiveId(),".");

        String currentPeriod = st.nextToken();
        String countryId = st.nextToken();
        String cycleId = st.nextToken();
        String subCycleId = st.nextToken();
        String controlObjectiveId = st.nextToken();
        //String targetCycleId = targetPeriodId+"."+countryId+"."+cycleId;
        String targetSubCycleId = targetPeriodId+"."+countryId+"."+cycleId+"."+subCycleId;
        String targetControlObjectiveId = targetPeriodId+"."+countryId+"."+cycleId+"."+subCycleId+"."+controlObjectiveId;
        controlObjectiveNew.setSubCycleId(targetSubCycleId);
        controlObjectiveNew.setControlObjectiveId(targetControlObjectiveId);
    }
}
