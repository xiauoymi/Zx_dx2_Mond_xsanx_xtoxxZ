package com.monsanto.wst.soxic.reports;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.SigChangeReportModel;
import com.monsanto.wst.soxic.persistance.SigReportDAO;
import com.monsanto.wst.soxic.reportingFramework.ReportParameters;
import com.monsanto.wst.soxic.reportingFramework.SoxAbstractReport;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.w3c.dom.Element;

import java.util.Iterator;
import java.util.List;
import java.util.Collections;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 1:46:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class SignificantChangeReport extends SoxAbstractReport {

    SigReportDAO sigReportDAO = new SigReportDAO();
    String fileName = "";

    protected void buildIAuditReportXML(Element reportDataElement, ReportParameters reportParameters) throws DatabaseException {
        String period = (String) reportParameters.getReportParameter("periodId");
        String country = (String) reportParameters.getReportParameter("country");
        buildReportBasedOnSelection(country, period, reportDataElement);

    }

    public void buildReportBasedOnSelection(String country, String period, Element reportDataElement) {
        String sigChangeQuery;
        if (country.equalsIgnoreCase("")){
            sigChangeQuery = buildQueryWithoutCountry(period);
            fileName = period;
        }
        else{
            sigChangeQuery = buildQueryWithBothParams(period,country);
            fileName = period+country;
        }
        buildReportWithSigChangeList(sigChangeQuery, reportDataElement, period);
    }

    private void buildReportWithSigChangeList(String sigChangeQuery, Element reportDataElement, String period) {
        List significantChanges = buildSignificantChangesFromQuery(sigChangeQuery);
        Collections.sort(significantChanges);
        buildXMLReportStructure(reportDataElement, period, significantChanges);
    }

    public List buildSignificantChangesFromQuery(String sigChangeQuery) {
        return sigReportDAO.buildSignificantChangesFromQuery(sigChangeQuery);
    }

    public void buildXMLReportStructure(Element reportDataElement, String period, List significantChanges) {
        Element significantReportElement = DOMUtil.addChildElement(reportDataElement,"significantReport");
        DOMUtil.addChildElement(significantReportElement,"period",period);
        Iterator sigIt = significantChanges.iterator();
        Element sigChangeList = DOMUtil.addChildElement(significantReportElement,"sigChangeList");
        while (sigIt.hasNext()){
            buildReportRows(sigChangeList, sigIt);
        }
    }

    private void buildReportRows(Element sigChangeList, Iterator sigIt) {
        Element sigChangeElement = DOMUtil.addChildElement(sigChangeList,"sigChange");
        SigChangeReportModel sigChangeReportModel = (SigChangeReportModel)sigIt.next();
        DOMUtil.addChildElement(sigChangeElement,"name",sigChangeReportModel.getCountry());
        DOMUtil.addChildElement(sigChangeElement,"cycle",sigChangeReportModel.getCycleId());
        DOMUtil.addChildElement(sigChangeElement,"busType",sigChangeReportModel.getSelectedType());
        DOMUtil.addChildElement(sigChangeElement,"eventTiming",sigChangeReportModel.getSelectedPeriod());
        DOMUtil.addChildElement(sigChangeElement,"estimate",sigChangeReportModel.getAmount());
        DOMUtil.addChildElement(sigChangeElement,"contact",sigChangeReportModel.getKeyContact());
        DOMUtil.addChildElement(sigChangeElement,"subcycle",sigChangeReportModel.getSubcycles());
        DOMUtil.addChildElement(sigChangeElement,"description",sigChangeReportModel.getDescription());
    }

    private String buildQueryWithBothParams(String period, String country) {
        return "SELECT SC.SEQUENCE, C.COUNTRY_ID, C.CYCLE_ID, SC.BUSINESS_TYPE, SC.PERIOD_IMPACTED, " +
                "SC.COST, SC.KEY_CONTACT, SC.SUB_CYCLE_IMPACTED, SC.DESCRIPTION, SC.OVERFLOW_ID, " +
                "TOF.SEQUENCE AS SEQID, TOF.TEXT_CHUNK " +
                "FROM SIGNIFICANT_CHANGE SC, CYCLE C, TEXT_OVERFLOW TOF " +
                "WHERE C.CYCLE_ID = SC.CYCLE_ID " +
                "AND SC.OVERFLOW_ID = TOF.OVERFLOW_ID(+) " +
                "AND SC.STATUS = '"+ SoxicConstants.COMPLETE +"' " +
                "AND C.PERIOD_ID = '"+period+"'" +
                "AND C.COUNTRY_ID = '"+country+"'";
    }

    private String buildQueryWithoutCountry(String period) {
        return "SELECT SC.SEQUENCE, C.COUNTRY_ID, C.CYCLE_ID, SC.BUSINESS_TYPE, SC.PERIOD_IMPACTED, " +
                "SC.COST, SC.KEY_CONTACT, SC.SUB_CYCLE_IMPACTED, SC.DESCRIPTION, SC.OVERFLOW_ID, " +
                "TOF.SEQUENCE AS SEQID, TOF.TEXT_CHUNK " +
                "FROM SIGNIFICANT_CHANGE SC, CYCLE C, TEXT_OVERFLOW TOF " +
                "WHERE C.CYCLE_ID = SC.CYCLE_ID " +
                "AND SC.OVERFLOW_ID = TOF.OVERFLOW_ID(+) " +
                "AND SC.STATUS = '"+SoxicConstants.COMPLETE+"' " +
                "AND C.PERIOD_ID = '"+period+"'";
    }

    public void buildFilterXML(Element rootOutputElement) throws DatabaseException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public String returnExportFileNameKey() {
        return fileName;
    }
}
