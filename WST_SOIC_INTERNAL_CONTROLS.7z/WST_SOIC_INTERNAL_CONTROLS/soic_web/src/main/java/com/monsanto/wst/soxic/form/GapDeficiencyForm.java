package com.monsanto.wst.soxic.form;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.model.Activity;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/** 
 * MyEclipse Struts
 * Creation date: 02-09-2005
 * 
 * XDoclet definition:
 * @struts:form name="gapDeficiencyForm"
 */
public class GapDeficiencyForm extends ActionForm {

	/**
	 * @return Returns the toClear.
	 */
	public boolean isToClear() {
		return toClear;
	}
	/**
	 * @param toClear The toClear to set.
	 */
	public void setToClear(boolean toClear) {
		this.toClear = toClear;
	}
    private String type;
    
    private String action;
    
    private String comment;
    
    private List activityList;
    
    private String testText;
    
    private String[] activitySelected;
    
    private List addedActivityList = new ArrayList();
    
    private List questionList;
    
    //private Map addedActivityMap = new HashMap();
    
    private String editActivity;
    
    private String controlObjectiveId;
    
    private String toReturn;
    
    private boolean toClear = false;
    
    private boolean toDisplayAction=true;
    
    private boolean activityFlag=false;
    
    private String question;
    
    private String questionId;
    
    

	/**
	 * @return Returns the question.
	 */
	public String getQuestion() {
		return question;
	}
	/**
	 * @param question The question to set.
	 */
	public void setQuestion(String question) {
		this.question = question;
	}
	/**
	 * @return Returns the activityFlag.
	 */
	public boolean isActivityFlag() {
		return activityFlag;
	}
	/**
	 * @param activityFlag The activityFlag to set.
	 */
	public void setActivityFlag(boolean activityFlag) {
		this.activityFlag = activityFlag;
	}
	/**
	 * @return Returns the toDisplayAction.
	 */
	public boolean isToDisplayAction() {
		return toDisplayAction;
	}
	/**
	 * @param toDisplayAction The toDisplayAction to set.
	 */
	public void setToDisplayAction(boolean toDisplayAction) {
		this.toDisplayAction = toDisplayAction;
	}
	/**
	 * @return Returns the toReturn.
	 */
	public String getToReturn() {
		return toReturn;
	}
	/**
	 * @param toReturn The toReturn to set.
	 */
	public void setToReturn(String toReturn) {
		this.toReturn = toReturn;
	}
	/**
	 * @return Returns the editActivity.
	 */
	public String getEditActivity() {
		return editActivity;
	}
	/**
	 * @param editActivity The editActivity to set.
	 */
	public void setEditActivity(String editActivity) {
		this.editActivity = editActivity;
	}
//	/**
//	 * @return Returns the addedActivityMap.
//	 */
//	public Map getAddedActivityMap() {
//		return addedActivityMap;
//	}
//	/**
//	 * @param addedActivityMap The addedActivityMap to set.
//	 */
//	public void setAddedActivityMap(Map addedActivityMap) {
//		this.addedActivityMap = addedActivityMap;
//	}
	/**
	 * @return Returns the questionList.
	 */
	public List getQuestionList() {
		return questionList;
	}
	/**
	 * @param questionList The questionList to set.
	 */
	public void setQuestionList(List questionList) {
		this.questionList = questionList;
	}
	/**
	 * @return Returns the addedActivityList.
	 */
	public List getAddedActivityList() {
		return addedActivityList;
	}
	/**
	 * @param addedActivityList The addedActivityList to set.
	 */
	public void setAddedActivityList(List addedActivityList) {
		this.addedActivityList = addedActivityList;
	}
	/**
	 * @return Returns the activitySelected.
	 */
	public String[] getActivitySelected() {
		return activitySelected;
	}
	/**
	 * @param activitySelected The activitySelected to set.
	 */
	public void setActivitySelected(String[] activitySelected) {
		this.activitySelected = activitySelected;
	}
	/**
	 * @return Returns the testText.
	 */
	public String getTestText() {
		return testText;
	}
	/**
	 * @param testText The testText to set.
	 */
	public void setTestText(String testText) {
		this.testText = testText;
	}
	/**
	 * @return Returns the activityList.
	 */
	public List getActivityList() {
		return activityList;
	}
	/**
	 * @param activityList The activityList to set.
	 */
	public void setActivityList(List activityList) {
		this.activityList = activityList;
	}
	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/**
	 * @return Returns the action.
	 */
	public String getAction() {
//		/return action;
		return "none";
	}
	/**
	 * @param action The action to set.
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return Returns the type.
	 */
	public String getType() {
		//return type;
		return "gap";
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	public void addActivity(Activity activity){
		addedActivityList.add(activity);
	}
	
	public ActionErrors validate(ActionMapping mapping,HttpServletRequest request){
		
		ActionErrors errors = new ActionErrors();
		
		if(request.getParameter("activitySelected")==null){
			activitySelected = null;
		}
		
		if(request.getServletPath().equalsIgnoreCase("/gapDeficiencySubmitAction.do") && comment!=null && comment.length()>0 && (activitySelected==null || activitySelected.length==0)){
			if(doValidate(request.getParameterMap())){
				request.setAttribute("selecterror","selecterror");
				errors.add("activitySelected",new ActionError("error.empty"));
			}

		}
		
		return errors;
		
	}
	
	/**
	 * @param parameterMap
	 * @return
	 */
	public boolean doValidate(Map parameterMap) {

		boolean validate = false;
		String action = null;

		String[] valueArr = null;

		Iterator iter = parameterMap.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = parameterMap.get(key);

			valueArr = (String[]) value;

			if (((String) key).equalsIgnoreCase("edit")) {

				return false;
			}

			if (((String) key).equalsIgnoreCase("remove")) {

				return false;
			}

			if (((String) key).equalsIgnoreCase("done")) {

				return true;
			}

			if (((String) key).equalsIgnoreCase("add")) {

				return true;
			}

			if (((String) key).equalsIgnoreCase("edit_this")) {

				return false;
			}
		}

		//return valueArr[0];
		return validate;

	}

	/**
	 * @return Returns the controlObjectiveId.
	 */
	public String getControlObjectiveId() {
		return controlObjectiveId;
	}
	/**
	 * @param controlObjectiveId The controlObjectiveId to set.
	 */
	public void setControlObjectiveId(String controlObjectiveId) {
		this.controlObjectiveId = controlObjectiveId;
	}
	
	public void clear(){
		if(activityList!=null){
			activityList.clear();
		}
		activitySelected=null;
		if(addedActivityList!=null){
			addedActivityList.clear();
		}
		comment="";
		toClear=true;
		
	}
	
	public void clearOtherQuestions(){
		Iterator iterator = getAddedActivityList().iterator();
		while(iterator.hasNext()){
			Activity activity = (Activity)iterator.next();
			
			if(!activity.getQuestionId().equalsIgnoreCase(questionId)){
				iterator.remove();
			}
		}
	}
	
	

	/**
	 * @return Returns the questionId.
	 */
	public String getQuestionId() {
		return questionId;
	}
	/**
	 * @param questionId The questionId to set.
	 */
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
}