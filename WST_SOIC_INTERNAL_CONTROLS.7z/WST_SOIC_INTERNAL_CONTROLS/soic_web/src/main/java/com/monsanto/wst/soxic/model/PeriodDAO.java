package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.persistance.OracleAbstractDAO;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 14, 2005
 * Time: 4:38:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeriodDAO extends OracleAbstractDAO {

    public List getPeriods()throws Exception{
        List periodList = new ArrayList();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;


        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT PERIOD_ID FROM PERIOD");
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                periodList.add(rs.getString("PERIOD_ID"));
            }



        }catch(SQLException e){

        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return periodList;
    }

    public void create(Collection baseModels) throws DatabaseException {

    }

    public int create(SoxicBaseModel soxicBaseModel)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        int result=-1;

        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            Period period = (Period)soxicBaseModel;
            preparedStatement = connection
                    .prepareStatement(period.getQuery());
            period.setParameters(preparedStatement);
            result = preparedStatement.executeUpdate();


        }catch(SQLException e){
            e.printStackTrace();
        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    public void setState(SoxicBaseModel soxicBaseModel)throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;
        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT STATE FROM CYCLE_STATE WHERE CYCLE_ID LIKE '%"+soxicBaseModel.getId()+"%'");
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                soxicBaseModel.setState(rs.getString("STATE"));
            }

        }catch(SQLException e){

        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void update(Collection soxicBaseModels) throws DatabaseException, Exception{};


    protected  String buildSelectQuery(Map fields){
        return "";
    }

    protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception{
        return null;
    }

    public Collection retrieveAllCyclesForPeriods(String periodId)throws Exception{
        List cyclePeriods = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs=null;


        try {

            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection
                    .prepareStatement("SELECT CYCLE_ID FROM CYCLE_STATE WHERE PERIOD_ID=?");
            preparedStatement.setString(1,periodId);
            rs = preparedStatement.executeQuery();

            while(rs.next()){
                cyclePeriods.add(rs.getString("CYCLE_ID"));
            }



        }catch(SQLException e){

        }finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cyclePeriods;
    }

    public boolean isAnyPeriodInDocumnetChange(){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT STATE FROM CYCLE_STATE WHERE STATE=?");
            preparedStatement.setString(1,SoxicConstants.DOCCHANGE_STATE);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                return true;
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
        return false;
    }

    public void deleteCycleState(Period period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "DELETE CYCLE_STATE WHERE CYCLE_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,period.getCycle_id());
            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

    public void deletePeriod(Period period){
        Connection connection = null;
        PreparedStatement preparedStatement=null;


        String query = "DELETE PERIOD WHERE PERIOD_ID=?";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,period.getPeriod_id());
            int result = preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
//                throw new DatabaseException("OracleDAO - Unable to close database connection : "
//                        + e.toString());
            }
        }
    }

}
