//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.Answer;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.ControlObjectiveDAO;
import com.monsanto.wst.soxic.model.Question;
import com.monsanto.wst.soxic.model.Status;
import com.monsanto.wst.soxic.model.SubCycle;
import com.monsanto.wst.soxic.util.SoxicPathUtil;
import com.monsanto.wst.soxic.util.SoxicUtil;

/**
 * MyEclipse Struts Creation date: 01-18-2005
 * 
 * XDoclet definition:
 * 
 * @struts:form name="controlObjectiveForm"
 */
public class ControlObjectiveForm extends ActionForm {

	/**
	 * risk for the control objective
	 */
	private SubCycle subcycle;

	/**
	 * risk for the control objective
	 */
	private Collection subcycleList;

    /**
	 * cycle List
	 */
    private Collection cycleList;

    private String currentCycle;

	/**
	 * risk for the control objective
	 */
	private Collection controlObjectiveList;

	/**
	 * risk for the control objective
	 */
	private Answer answer;

	/**
	 * risk for the control objective
	 */
	private String expcol;

	/**
	 * risk for the control objective
	 */
	int level;

	/**
	 * risk for the control objective
	 */
	private String subcycleid;

	/**
	 * risk for the control objective
	 */
	private Collection subCycleList;

	/**
	 * risk for the control objective
	 */
	private Collection subCycleId = new ArrayList();

	/**
	 * risk for the control objective
	 */
	private String cycleSelected;

	/**
	 * List of deficiencies for the selected control Objective
	 */
	private List deficiency;

	/**
	 * List of gaps for the selected control Objective
	 */
	private List gap;

	/**
	 * Control Objective Selected
	 */
	private String controlObjectiveId;

	/**
	 * risk for the control objective
	 */
	private String currentControlObjective;

	/**
	 * lock is set to true if the sub cycle owner has a complete status
	 */
	private boolean lockSubmit;

	/**
	 * Sub cycle that is selected
	 */
	private String currentSubCycle;

    private Collection subCyclesCurrentCycle;

    private String subCycleSelected;

    private String documentChangeId;



	/**
	 * @return Returns the currentSubCycle.
	 */
	public String getCurrentSubCycle() {
		return currentSubCycle;
	}
	/**
	 * @param currentSubCycle The currentSubCycle to set.
	 */
	public void setCurrentSubCycle(String currentSubCycle) {
		this.currentSubCycle = currentSubCycle;
	}
	/**
	 * @return Returns the subCycleId.
	 */
	public Collection getSubCycleId() {
		return subCycleId;
	}

	/**
	 * @param subCycleId
	 *            The subCycleId to set.
	 */
	public void setSubCycleId(Collection subCycleId) {
		this.subCycleId.clear();
		Iterator subCycleIterator = subCycleList.iterator();

		while (subCycleIterator.hasNext()) {

			SubCycle subCycle = (SubCycle) subCycleIterator.next();

			String toDisplay = subCycle.getSubCycleId() + "  "
					+ subCycle.getDescription();

			subCycleId.add(toDisplay);
		}
	}

	/**
	 * @return Returns the lockSubmit.
	 */
	public boolean isLockSubmit() {
		return lockSubmit;
	}

	/**
	 * @param lockSubmit
	 *            The lockSubmit to set.
	 */
	public void setLockSubmit(boolean lockSubmit) {
		this.lockSubmit = lockSubmit;
	}

	/**
	 * @return Returns the currentControlObjective.
	 */
	public String getCurrentControlObjective() {
		return currentControlObjective;
	}

	/**
	 * @param currentControlObjective
	 *            The currentControlObjective to set.
	 */
	public void setCurrentControlObjective(String currentControlObjective) {
		this.currentControlObjective = currentControlObjective;
	}

	/**
	 * @return Returns the gap.
	 */
	public List getGap() {
		return gap;
	}

	/**
	 * @param gap
	 *            The gap to set.
	 */
	public void setGap(List gap) {
		this.gap = gap;
	}

	private String fileName;

	/**
	 * @return Returns the fileName.
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            The fileName to set.
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return Returns the deficiency.
	 */
	public List getDeficiency() {
		return deficiency;
	}

	/**
	 * @param deficiency
	 *            The deficiency to set.
	 */
	public void setDeficiency(List deficiency) {
		this.deficiency = deficiency;
	}

	/**
	 * @return Returns the cycleSelected.
	 */
	public String getCycleSelected() {
		return cycleSelected;
	}

	/**
	 * @param cycleSelected
	 *            The cycleSelected to set.
	 */
	public void setCycleSelected(String cycleSelected) {
		this.cycleSelected = cycleSelected;
	}

	/**
	 * @return Returns the subcycleid.
	 */
	public String getSubcycleid() {
		return subcycleid;
	}

	/**
	 * @param subcycleid
	 *            The subcycleid to set.
	 */
	public void setSubcycleid(String subcycleid) {
		this.subcycleid = subcycleid;
	}

	/**
	 * @return Returns the level.
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            The level to set.
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * @return Returns the expcol.
	 */
	public String getExpcol() {
		return expcol;
	}

	/**
	 * @param expcol
	 *            The expcol to set.
	 */
	public void setExpcol(String expcol) {
		this.expcol = expcol;
	}

	/**
	 * @return Returns the answer.
	 */
	public Answer getAnswer() {
		return answer;
	}

	/**
	 * @param answer
	 *            The answer to set.
	 */
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}

	/**
	 * @return Returns the controlObjectiveList.
	 */
	public Collection getControlObjectiveList() {
		return controlObjectiveList;
	}

	/**
	 * @param controlObjectiveList
	 *            The controlObjectiveList to set.
	 */
	public void setControlObjectiveList(Collection controlObjectiveList) {
		this.controlObjectiveList = controlObjectiveList;

		removeControlObjective();
		removeRemainingActIfPresentInAssigned();
		setData();
		setLink();
	}

	/**
	 * @return Returns the subcycleList.
	 */
	public Collection getSubcycleList() {
		return subcycleList;
	}

	/**
	 * @param subcycleList
	 *            The subcycleList to set.
	 */
	public void setSubcycleList(Collection subcycleList) {
		this.subcycleList = subcycleList;
	}

	/**
	 * @return Returns the subcycle.
	 */
	public SubCycle getSubcycle() {
		return subcycle;
	}

	/**
	 * @param subcycle
	 *            The subcycle to set.
	 */
	public void setSubcycle(SubCycle subcycle) {
		this.subcycle = subcycle;
	}

	/**
	 * @return Returns the subCycleList.
	 */
	public Collection getSubCycleList() {
		return subCycleList;
	}

	/**
	 * @param subCycleList
	 *            The subCycleList to set.
	 */
	public void setSubCycleList(Collection subCycleList) {

		subCycleId.clear();

		this.subCycleList = subCycleList;

		Iterator subCycleIterator = subCycleList.iterator();

		while (subCycleIterator.hasNext()) {

			SubCycle subCycle = (SubCycle) subCycleIterator.next();

			String toDisplay = subCycle.getSubCycleId() + "  "
					+ subCycle.getDescription();

			subCycleId.add(toDisplay);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping,
	 *      javax.servlet.http.HttpServletRequest)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping,
	 *      javax.servlet.http.HttpServletRequest)
	 */
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		String path = request.getServletPath();

		if (!path.equalsIgnoreCase("/activityControlObjectiveDisplayAction.do")) {

			if (SoxicPathUtil.returnForward(request) != null) {

				if ((SoxicPathUtil.returnForward(request))
						.equalsIgnoreCase("submit")) {

					if (isAnswerEmpty(request)) {

						errors.add("age", new ActionError(
								"errors.required.answer"));

					}

				}
			}
		}

		return errors;

	}

	/**
	 * on submit if a particular question is not answer true is returned
	 * 
	 * @param request
	 * @return
	 */
	/**
	 * @param request
	 * @return
	 */
	public boolean isAnswerEmpty(HttpServletRequest request) {

		String controlObjectiveId = SoxicPathUtil.getKey(request, "submit");

		setCurrentControlObjective(controlObjectiveId);

		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {

				Map questionMap = controlObjective.getQuestionMap();

				Iterator questionIter = questionMap.keySet().iterator();

				while (questionIter.hasNext()) {

					Object key = questionIter.next();

					//Question ques = (Question) questionIter.next();
					Question ques = (Question) questionMap.get(key);

					if (ques.getType() == null) {

						return true;
					}

				}
			}
		}

		return false;
	}

	/**
	 * @return Returns the controlObjectiveId.
	 */
	public String getControlObjectiveId() {
		return controlObjectiveId;
	}

	/**
	 * @param controlObjectiveId
	 *            The controlObjectiveId to set.
	 */
	public void setControlObjectiveId(String controlObjectiveId) {
		this.controlObjectiveId = controlObjectiveId;
	}

	/**
	 * Sets the counter for the questions,activities
	 */
	public void setData() {

		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			int questionCounter = 0;
			int activityCounter = 0;
			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			Iterator questionIterator = controlObjective.getQuestionMap()
					.values().iterator();

			while (questionIterator.hasNext()) {

				questionCounter++;
				Question question = (Question) questionIterator.next();
				question.setCounter(questionCounter);
			}

			Iterator activityIterator = controlObjective
					.getAssignedActivityMap().values().iterator();

			while (activityIterator.hasNext()) {

				activityCounter++;
				Activity activity = (Activity) activityIterator.next();
				activity.setCounter(activityCounter);
			}

			if (controlObjective.getRemainingActivityMap() != null) {
				Iterator remainingActivityIterator = controlObjective
						.getRemainingActivityMap().values().iterator();

				while (activityIterator.hasNext()) {

					activityCounter++;
					Activity activity = (Activity) remainingActivityIterator
							.next();
					activity.setCounter(activityCounter);
				}
			}

		}
	}

	/**
	 * Sets the control objective status
	 * 
	 * @param controlObjectiveId
	 * @param ownerid
	 * @throws Exception
	 */
	public void setStatusForControlObjective(String controlObjectiveId,
			String ownerid) throws Exception {
		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {
				String stat = ControlObjectiveDAO.getStatusForControlObjective(
						controlObjectiveId, ownerid);
				Status status = new Status(stat);

				controlObjective.setStatus(status);
			}
		}
	}

	/**
	 * Gets the sub-cycle id at index passed in
	 * 
	 * @param index
	 * @return
	 */
	public String getSubCycleId(int index) {
		SubCycle subCycle = (SubCycle) ((List) subCycleList).get(index);
		return subCycle.getSubCycleId();
	}

	/**
	 * Removes the control objective if there are no assigned acitivities
	 */
	public void removeControlObjective() {

		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getAssignedActivityMap() == null) {

				iterator.remove();
			}

		}
	}

	/**
	 * if an acitivity is assigned to a person it is removed if also present in
	 * remaining activity
	 */
	public void removeRemainingActIfPresentInAssigned() {

		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getAssignedActivityMap() != null) {

				Iterator activityIterator = controlObjective
						.getAssignedActivityMap().values().iterator();
				while (activityIterator.hasNext()) {
					Activity activity = (Activity) activityIterator.next();
					removeActivity(activity.getActivityId(), controlObjective
							.getRemainingActivityMap());
				}
			}

		}
	}

	/**
	 * removes the activity with the identifier string from the remaining
	 * activity
	 * 
	 * @param identifier
	 * @param remainingActivityMap
	 */
	public void removeActivity(String identifier, Map remainingActivityMap) {
		if (remainingActivityMap != null && identifier != null) {
			Iterator iterator = remainingActivityMap.values().iterator();
			while (iterator.hasNext()) {
				Activity activity = (Activity) iterator.next();
				if (activity.getActivityId().equalsIgnoreCase(identifier)) {
					iterator.remove();
				}
			}
		}

	}

	private void setLink() {

		Question question = null;

		String link = "";

		Iterator controlObjectiveListIterator = controlObjectiveList.iterator();

		while (controlObjectiveListIterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) controlObjectiveListIterator
					.next();

			Map questionMap = controlObjective.getQuestionMap();

			Iterator questionIterator = questionMap.keySet().iterator();

			while (questionIterator.hasNext()) {

				Object key = questionIterator.next();

				question = (Question) questionMap.get(key);

				String answer = question.getType();

				String actAnsType = question.getActualAnsType();

				if (question.getType() != null
						&& question.getType().equalsIgnoreCase("no")) {

					question.setDisplayLink(true);

					link = controlObjective.getControlObjectiveId() + SoxicUtil.getSeperator()
							+ question.getQuestionId() + SoxicUtil.getSeperator() + "A";

					question.setLink(link);
				}
			}
		}
	}

    public Collection getCycleList() {
        return cycleList;
    }

    public void setCycleList(Collection cycleList) {
        this.cycleList = cycleList;
    }

    public String getCurrentCycle() {
        return currentCycle;
    }

    public void setCurrentCycle(String currentCycle) {
        this.currentCycle = currentCycle;
    }

    public Collection getSubCyclesCurrentCycle() {
        return subCyclesCurrentCycle;
    }

    public void setSubCyclesCurrentCycle(Collection subCyclesCurrentCycle) {
        this.subCyclesCurrentCycle = subCyclesCurrentCycle;
    }

    public String getSubCycleSelected() {
        return subCycleSelected;
    }

    public void setSubCycleSelected(String subCycleSelected) {
        this.subCycleSelected = subCycleSelected;
    }

    public String getDocumentChangeId() {
        return documentChangeId;
    }

    public void setDocumentChangeId(String documentChangeId) {
        this.documentChangeId = documentChangeId;
    }

}