/*
 * Created on Jun 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.DashBoardSummaryReportForm;
import com.monsanto.wst.soxic.model.SummaryReportFacade;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DashBoardSummaryReportAction extends Action{
	
	   public ActionForward execute(ActionMapping mapping, 
			 ActionForm form,
			 HttpServletRequest request, 
			 HttpServletResponse response) throws Exception{
	   	
	   DashBoardSummaryReportForm dashBoardSummaryReportForm = (DashBoardSummaryReportForm)form;
	   
	   SummaryReportFacade summaryReportFacade = new SummaryReportFacade();
	   
	  // dashBoardSummaryReportForm.setCountrySummaryList(summaryReportFacade.getCountryListSummary());
	   summaryReportFacade.setCountryListSummary(dashBoardSummaryReportForm);
	   
	   request.setAttribute("cyclesize",""+dashBoardSummaryReportForm.getCycleList().size());
	   
       return mapping.findForward("success");
   }

}
