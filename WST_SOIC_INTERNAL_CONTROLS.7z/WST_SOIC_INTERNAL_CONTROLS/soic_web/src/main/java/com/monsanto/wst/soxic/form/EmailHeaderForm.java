package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 20, 2006
 * Time: 1:27:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmailHeaderForm extends ActionForm{

    private String activityEmailHeader;
    private String subCycleEmailHeader;
    private String cycleEmailHeader;

    public String getActivityEmailHeader() {
        return activityEmailHeader;
    }

    public void setActivityEmailHeader(String activityEmailHeader) {
        this.activityEmailHeader = activityEmailHeader;
    }

    public String getSubCycleEmailHeader() {
        return subCycleEmailHeader;
    }

    public void setSubCycleEmailHeader(String subCycleEmailHeader) {
        this.subCycleEmailHeader = subCycleEmailHeader;
    }

    public String getCycleEmailHeader() {
        return cycleEmailHeader;
    }

    public void setCycleEmailHeader(String cycleEmailHeader) {
        this.cycleEmailHeader = cycleEmailHeader;
    }
}
