/*
 * Created on Apr 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.plugin;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;

import com.monsanto.wst.soxic.workflow.StatusService;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StatusScheduler implements PlugIn {

	/* (non-Javadoc)
	 * @see org.apache.struts.action.PlugIn#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.apache.struts.action.PlugIn#init(org.apache.struts.action.ActionServlet, org.apache.struts.config.ModuleConfig)
	 */
	public void init(ActionServlet arg0, ModuleConfig arg1)
			throws ServletException {
		// TODO Auto-generated method stub
		Timer timer= new Timer();
		Calendar cal  = Calendar.getInstance();
		Date startDate = new Date();
//		startDate.setMonth(4);
//		startDate.setYear(2005);
//		startDate.setDate(12);
//		startDate.setHours(14);
//		startDate.setMinutes(36);
		Long period = new Long(60*60*1000);
//		cal.set(Calendar.HOUR_OF_DAY,9);
//		cal.set(Calendar.MINUTE,45);
//		cal.set(Calendar.SECOND,10);
		timer.schedule(new StatusService(),cal.getTime(),period.longValue());

	}

}
