/*
 * Created on Mar 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.struts.action.ActionForm;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RiskForm extends ActionForm{
	
	private List riskList = new ArrayList();
	
	
	/**
	 * @return Returns the riskList.
	 */
	public List getRiskList() {
		return riskList;
	}
	/**
	 * @param riskList The riskList to set.
	 */
	public void setRiskList(List riskList) {
		this.riskList = riskList;
	}
	
	public String getLevel(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
			
			if(key.equalsIgnoreCase("controlObjectiveId")){
				
				return SoxicConstants.CONTROLOBJECTIVE;
				
			}
			
			if(key.equalsIgnoreCase("subCycleId")){
				
				return SoxicConstants.SUBCYCLE;
				
			}	
			
			if(key.equalsIgnoreCase("cycleId")){
				
				return SoxicConstants.CYCLE;
				
			}	
			
			if(key.equalsIgnoreCase("activityId")){
				
				return SoxicConstants.ACTIVITY;
				
			}				
		
		}
		
		return key;
		
	}
	
	public String getKey(Map levelMap){
		
		String key="";
		
		Iterator iterator  = levelMap.keySet().iterator();
		
		while(iterator.hasNext()){
					
			key = (String)iterator.next();
		
		}
		
		return key;		
	}	
}
