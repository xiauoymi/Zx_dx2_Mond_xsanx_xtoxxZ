package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 3, 2006
 * Time: 1:34:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class Export {
    private String type;
    private String xslPath;
    private String exportFileName;

    public Export(String type, String xslPath, String exportFileName){
        this.type = type;
        this.xslPath = xslPath;
        this.exportFileName = exportFileName;
    }

    public Export(Node node){
        NodeList childNodes = node.getChildNodes();
        for(int i=0;i<childNodes.getLength();i++){
            Node currentNode = childNodes.item(i);

            if(currentNode.getNodeName().equalsIgnoreCase("type")){
                type=DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("exportxsl")){
                xslPath=DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase("exportFileName")){
                exportFileName = DOMUtil.getTextValue(currentNode);
            }
        }
    }

    public String getType() {
        return type;
    }

    public String getXslPath() {
        return xslPath;
    }

    public String getExportFileName() {
        return exportFileName;
    }    
}
