/*
 * Created on Mar 1, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.LookupDispatchAction;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.exception.InvalidUserException;
import com.monsanto.wst.soxic.form.OwnerCopyChangeForm;
import com.monsanto.wst.soxic.model.AdminOwner;
import com.monsanto.wst.soxic.model.AdminOwnerEntity;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerCopyChangeAction extends LookupDispatchAction{
    
    /* (non-Javadoc)
     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
     */
    protected Map getKeyMethodMap() {
        Map map = new HashMap();
        map.put("button.preview",   "preview");
        map.put("button.save",      "save");
        return map;
    }
    
    public ActionForward preview(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        
        OwnerCopyChangeForm adminOwnerForm = (OwnerCopyChangeForm) form;
        AdminOwner adminOwner = new AdminOwner();
        
        try {
            adminOwnerForm.setChanges(adminOwner.getPreviewChanges(convertArrayToList(adminOwnerForm.getSelectedCycles()),
                                                                   convertArrayToList(adminOwnerForm.getSelectedSubCycles()), 
                                                                   convertArrayToList(adminOwnerForm.getSelectedActivities()),
                                                                   adminOwnerForm.getExistingUser()));
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
  
        return mapping.findForward("success");
    }
    
    public ActionForward save(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
    throws IOException, ServletException, InvalidUserException {
        
        OwnerCopyChangeForm adminOwnerForm = (OwnerCopyChangeForm) form;
        AdminOwner adminOwner = new AdminOwner();
        
        //generateAdminOwnerData(adminOwnerForm);
        
        try {
            if(adminOwnerForm.getSelectedOperation().equals("Copy")){
                
                adminOwner.copyOwner(setOwnerInChangesToCopy(adminOwnerForm.getChanges(), adminOwnerForm.getNewUser()),adminOwnerForm.getNewUser(),adminOwnerForm.getNewUserLocation());
                
                
            }
            else if(adminOwnerForm.getSelectedOperation().equals("Change")){
                adminOwner.changeOwner(adminOwnerForm.getChanges(),adminOwnerForm.getNewUser(),adminOwnerForm.getNewUserLocation());
            }
            
        } catch (DatabaseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            if(e instanceof InvalidUserException){
            	throw new InvalidUserException();
            }
        }
        
        adminOwnerForm.setChanges(new ArrayList());
        return mapping.findForward("copyChange");
        
    }
    
        
    private List convertArrayToList(String[] array){
        
        List list = new ArrayList();
        
        for(int i=0; i < array.length; i++){
            list.add(array[i]);
        }
        
        return list;
    }
    
    private List setOwnerInChangesToCopy(List changes, String newUser){
        
        Iterator itr = changes.iterator();
        
        while(itr.hasNext()){
            
            ((AdminOwnerEntity) itr.next()).setOwnerId(newUser);
        }
        
        return changes;
    }
}