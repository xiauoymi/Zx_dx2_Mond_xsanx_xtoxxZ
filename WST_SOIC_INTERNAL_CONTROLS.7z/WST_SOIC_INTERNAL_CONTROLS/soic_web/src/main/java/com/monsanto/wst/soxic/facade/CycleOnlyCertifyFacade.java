package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.model.CycleOnlyCertDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 1, 2006
 * Time: 11:09:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class CycleOnlyCertifyFacade {

    CycleOnlyCertDAO cycleOnlyCertDAO = new CycleOnlyCertDAO();
    Date currentDate = new Date(System.currentTimeMillis());
    SimpleDateFormat sdf = new SimpleDateFormat(CycleOnlyConstants.DATE_FORMAT);

    public boolean checkCycleExistenceInList(Vector periodList, String period) {
        boolean value = false;
        if (periodList.contains(period)){
            value = true;
        }else {
            if (checkIfPeriodIsCycleOnlyPeriod(period)){
                periodList.add(period);
                value = true;
            }
        }
        return value;
    }

    public boolean checkIfPeriodIsCycleOnlyPeriod(String period) {
        if (cycleOnlyCertDAO.checkForPeriodStatus(period)){
            return true;
        }
        else return false;
    }

    public void createSubCycleOwnerResponses(String cycleid) {
        String subcycleOwnerQuery = "INSERT INTO OWNER_RESPONSE( " +
                "SELECT OWNER_RESPONSE_SEQ.NEXTVAL,OSC.OWNER_ID,QSC.QUESTION_ID,'"+CycleOnlyConstants.SUBCYCLE_ASSOC_TYPE+"',OSC.SUB_CYCLE_ID,'"+CycleOnlyConstants.YES_RESPONSE+"','"+SoxicConstants.COMPLETE+"',to_date('"+sdf.format(currentDate)+"', 'MM/DD/YYYY'),'"+CycleOnlyConstants.CYCLE_ONLY_RESPONSE+"' " +
                "FROM QUESTION_SUB_CYCLE QSC,OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE C " +
                "WHERE QSC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID " +
                "AND OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
                "AND SC.CYCLE_ID = C.CYCLE_ID " +
                "AND C.CYCLE_ID = '"+cycleid+"')";
        updateDBTablesWithNewStatus(subcycleOwnerQuery);
    }

    public void createActivityOwnerResponses(String cycleid) {
        String activityOwnerQuery = "INSERT INTO OWNER_RESPONSE( " +
                "SELECT OWNER_RESPONSE_SEQ.NEXTVAL,OA.OWNER_ID,QA.QUESTION_ID,'"+CycleOnlyConstants.ACT_ASSOC_TYPE+"',QA.ACTIVITY_ID,'"+CycleOnlyConstants.YES_RESPONSE+"','"+SoxicConstants.COMPLETE+"',to_date('"+sdf.format(currentDate)+"', 'MM/DD/YYYY'),'"+CycleOnlyConstants.CYCLE_ONLY_RESPONSE+"' " +
                "FROM QUESTION_ACTIVITY QA, OWNER_ACTIVITY OA,CTRL_OBJ CO,SUB_CYCLE SC,CYCLE C,ACTIVITY A " +
                "WHERE QA.ACTIVITY_ID = OA.ACTIVITY_ID " +
                "AND OA.ACTIVITY_ID = A.ACTIVITY_ID " +
                "AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID " +
                "AND CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
                "AND SC.CYCLE_ID = C.CYCLE_ID " +
                "AND C.CYCLE_ID = '"+cycleid+"')";
        updateDBTablesWithNewStatus(activityOwnerQuery);
    }

    public void updateStatus(String cycleid, String type) {
        String query = "";
        if (type.equalsIgnoreCase(CycleOnlyConstants.ACT)){
            query = "UPDATE ACTIVITY SET STATUS = '"+SoxicConstants.COMPLETE+"' WHERE ACTIVITY_ID LIKE '%"+cycleid+"%'";
        }
        if (type.equalsIgnoreCase(CycleOnlyConstants.OWN_ACT)){
            query = "UPDATE OWNER_ACTIVITY SET STATUS = '"+SoxicConstants.COMPLETE+"' WHERE ACTIVITY_ID LIKE '%"+cycleid+"%'";
        }
        if (type.equalsIgnoreCase(CycleOnlyConstants.OWN_SUB)){
            query = "UPDATE OWNER_SUB_CYCLE SET STATUS = '"+SoxicConstants.COMPLETE+"' WHERE SUB_CYCLE_ID LIKE '%"+cycleid+"%'";
        }
        if (type.equalsIgnoreCase(CycleOnlyConstants.SUBCYCLE)){
            query = "UPDATE SUB_CYCLE SET STATUS = '"+SoxicConstants.COMPLETE+"' WHERE SUB_CYCLE_ID LIKE '%"+cycleid+"%'";
        }
        if (type.equalsIgnoreCase(CycleOnlyConstants.CTRL_OBJ)){
            query = "UPDATE CTRL_OBJ SET STATUS = '"+SoxicConstants.COMPLETE+"' WHERE CTRL_OBJ_ID LIKE '%"+cycleid+"%'";
        }
        updateDBTablesWithNewStatus(query);
    }

    public void updateDates(String cycleid, String type) {
        String query = "";
        Date startDate = new Date(System.currentTimeMillis());

        Date dueDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Date completeDate = new Date(System.currentTimeMillis() + 2 * 24 * 60 * 60 * 1000);

        if (type.equalsIgnoreCase(CycleOnlyConstants.OWN_ACT)){
            query = "UPDATE OWNER_ACTIVITY SET START_DATE = to_date('" + sdf.format(startDate) + "', 'MM/dd/yyyy') , DUE_DATE = to_date('" + sdf.format(dueDate) + "', 'MM/dd/yyyy'), COMPLETE_DATE = to_date('"+ sdf.format(completeDate) + "', 'MM/dd/yyyy') WHERE ACTIVITY_ID LIKE '%"+cycleid+"%'";
        }
        if (type.equalsIgnoreCase(CycleOnlyConstants.OWN_SUB)){
            query = "UPDATE OWNER_SUB_CYCLE SET START_DATE = to_date('"+ sdf.format(startDate) +"', 'MM/dd/yyyy') , DUE_DATE =  to_date('" + sdf.format(dueDate) + "', 'MM/dd/yyyy'),COMPLETE_DATE = to_date('"+ sdf.format(completeDate) + "', 'MM/dd/yyyy') WHERE SUB_CYCLE_ID LIKE '%"+cycleid+"%'";
        }
        updateDBTablesWithNewStatus(query);
    }

    protected void updateDBTablesWithNewStatus(String query) {
        cycleOnlyCertDAO.updateStatusBasedOnType(query);
    }

    public void processPreCertificationForCycleOnlyPeriod(CycleOnlyCertifyFacade cycleOnlyCertifyFacade, String cycleid, CycleManageFacade cycleManageFacade) throws Exception {
        cycleOnlyCertifyFacade.updateStatus(cycleid,CycleOnlyConstants.OWN_ACT);
        cycleOnlyCertifyFacade.updateStatus(cycleid,CycleOnlyConstants.ACT);
        cycleOnlyCertifyFacade.updateStatus(cycleid,CycleOnlyConstants.OWN_SUB);
        cycleOnlyCertifyFacade.updateStatus(cycleid,CycleOnlyConstants.SUBCYCLE);
        cycleOnlyCertifyFacade.updateStatus(cycleid,CycleOnlyConstants.CTRL_OBJ);
        cycleOnlyCertifyFacade.updateDates(cycleid,CycleOnlyConstants.OWN_ACT);
        cycleOnlyCertifyFacade.updateDates(cycleid,CycleOnlyConstants.OWN_SUB);
        cycleOnlyCertifyFacade.createActivityOwnerResponses(cycleid);
        cycleOnlyCertifyFacade.createSubCycleOwnerResponses(cycleid);

    }

    public void processCycleOnlyPublish(CycleOnlyCertifyFacade cycleOnlyCertifyFacade, String cycleid, CycleManageFacade cycleManageFacade) throws Exception {
        cycleOnlyCertifyFacade.processPreCertificationForCycleOnlyPeriod(cycleOnlyCertifyFacade, cycleid, cycleManageFacade);
        //cycleManageFacade.putIntoPreCertifyState(cycleid);
    }
}
