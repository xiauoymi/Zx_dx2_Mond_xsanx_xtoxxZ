package com.monsanto.wst.soxic.tags;

import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.NavConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 4, 2006
 * Time: 11:11:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class Navigation {
    private String name = "";
    private String page = "";
    private String contextpath = "";
    private Owner owner = null;

    public Navigation(String name, String page, String contextpath, Owner owner) {
        this.name = name;
        this.page = page;
        this.contextpath = contextpath;
        this.owner = owner;
    }

    public Navigation(SecureNav secureNav) {
        this.name = secureNav.getName();
        this.page = secureNav.getPage();
        this.contextpath = secureNav.getContextpath();
        this.owner = secureNav.getOwner();
    }

    public String buildNavHTMLString() {
        StringBuffer tagContent = new StringBuffer();

        tagContent.append(buildNavTableStart());
        tagContent.append(buildNavActivity());
        tagContent.append(buildNavSubCycle());
        tagContent.append(buildNavCycle());
        tagContent.append(buildNavDocChange());
        tagContent.append(buildNavReports());
        tagContent.append(buildNavAdmin());
        tagContent.append(buildNavFAQ());
        tagContent.append(buildNavTableEnd());

        return tagContent.toString();
    }

    private String buildNavTableStart() {
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append("<!-- NAVIGATION STARTS -->\n");
        htmlBuffer.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"site_nav\">\n");
        htmlBuffer.append("<tr>\n");

        return htmlBuffer.toString();
    }

    private String buildNavActivity() {
        String htmlString = "";

        if(owner.isActivityCertification()) {
            if(owner.getActivitySubCycleAssociation() != null && owner.getActivitySubCycleAssociation().size() > 0) {
                htmlString = "<td><a href=\"" + contextpath + "/activityControlObjectiveDisplayAction.do\" ><img src=\"" + getTabActivityImage() + "\" width=\"136\" height=\"20\" alt=\"\" border=\"0\"></a></td>\n";
            }
        }

        return htmlString;
    }

    private String getTabActivityImage() {
        if(NavConstants.PAGE_ACTIVITY.equals(page)) {
            return contextpath + "/images/buttons/con_objectives_on.gif";
        }
        else {
            return contextpath + "/images/buttons/con_objectives.gif";
        }
    }

    private String buildNavSubCycle() {
        String htmlString = "";

        if(owner.getSubCycles() != null && owner.getSubCycles().size() > 0) {
            htmlString = "<td><a href=\"" + contextpath + "/populateSubCycleAction.do\" ><img src=\"" + getTabSubCycleImage() + "\" width=\"89\" height=\"20\" alt=\"\" border=\"0\" /></a></td>\n";
    	}

        return htmlString;
    }

    private String getTabSubCycleImage() {
        if(NavConstants.PAGE_SUB_CYCLE.equals(page)) {
            return contextpath + "/images/buttons/sub-cycles_on.gif";
        }
        else {
            return contextpath + "/images/buttons/sub-cycles.gif";
        }
    }

    private String buildNavCycle() {
        String htmlString = "";

        if(owner.getCycles() != null && owner.getCycles().size() > 0) {
            htmlString = "<td><a href=\"" + contextpath + "/populateCycleAction.do\" ><img src=\"" + getTabCycleImage() + "\" width=\"62\" height=\"20\" alt=\"\" border=\"0\" /></a></td>\n";
        }

        return htmlString;
    }

    private String getTabCycleImage() {
        if(NavConstants.PAGE_CYCLE.equals(page)) {
            return contextpath + "/images/buttons/cycles_on.gif";
        }
        else {
            return contextpath + "/images/buttons/cycles.gif";
        }
    }

    private String buildNavReports() {
        String htmlString = "";

        if(owner.isViewReports()) {
            htmlString = "<td><a href=\"" + contextpath + "/reportList.do\" ><img src=\"" + getTabReportsImage() + "\" width=\"75\" height=\"20\" alt=\"\" border=\"0\" /></a></td>\n";
        }

        return htmlString;
    }

    private String getTabReportsImage() {
        if(NavConstants.PAGE_REPORTS.equals(page)) {
            return contextpath + "/images/buttons/reports_on.gif";
        }
        else {
            return contextpath + "/images/buttons/reports.gif";
        }
    }

    private String buildNavAdmin() {
        String htmlString = "";

        if((owner.isAdmin()) || (owner.isIA() ||(owner.isShowMaintainenceForCycleOrSubCycle())) ) {
            htmlString = "<td><a href=\"" + contextpath + "/admin.do\"><img src=\"" + getTabAdminImage() + "\" width=\"111\" height=\"20\" alt=\"\" border=\"0\"/></a></td>\n";
        }

        return htmlString;
    }

    private String getTabAdminImage() {
        if(NavConstants.PAGE_ADMIN.equals(page)) {
            return contextpath + "/images/buttons/maintenance_on.gif";
        }
        else {
            return contextpath + "/images/buttons/Maintenance.gif";
        }
    }

    private String buildNavFAQ() {
        String htmlString = "";

        htmlString = "<td><a href=\"" + contextpath + "/fAQDisplayAction.do\"><img src=\"" + getTabFAQImage() + "\" width=\"58\" height=\"20\" alt=\"\" border=\"0\"/></a></td>\n";

        return htmlString;
    }
    private String getTabFAQImage() {
        if(NavConstants.PAGE_FAQ.equals(page)) {
            return contextpath + "/images/buttons/faqs_on.gif";
        }
        else {
            return contextpath + "/images/buttons/faqs.gif";
        }
    }
        private String buildNavDocChange() {
        String htmlString = "";

        if(owner.isDocumentChangeTab()) {
            htmlString = "<td><a id=\"docChangeMenu\" href=\"" + contextpath + "/doc_changemenu.do\"><img src=\"" + getTabDocChangeImage() + "\" width=\"99\" height=\"20\" alt=\"\" border=\"0\"/></a></td>\n";
        }

        return htmlString;
    }

    private String getTabDocChangeImage() {
        if(NavConstants.PAGE_DOC_CHANGE.equals(page)) {
            return contextpath + "/images/buttons/doc_changes_on.gif";
        }
        else {
            return contextpath + "/images/buttons/doc_changes.gif";
        }
    }

    private String buildNavTableEnd() {
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append("<td class=\"pusher\"></td>\n");
        htmlBuffer.append("</tr>\n");
        htmlBuffer.append("<tr>\n");
        htmlBuffer.append("<td colspan=\"7\" class=\"nav_base1\"></td>\n");
        htmlBuffer.append("</tr>\n");
        htmlBuffer.append("<tr>\n");
        htmlBuffer.append("<td colspan=\"7\" class=\"nav_base2\"></td>\n");
        htmlBuffer.append("</tr>\n");
        htmlBuffer.append("</table>\n");
        htmlBuffer.append("<!-- NAVIGATION ENDS -->\n");

        return htmlBuffer.toString();
    }
}
