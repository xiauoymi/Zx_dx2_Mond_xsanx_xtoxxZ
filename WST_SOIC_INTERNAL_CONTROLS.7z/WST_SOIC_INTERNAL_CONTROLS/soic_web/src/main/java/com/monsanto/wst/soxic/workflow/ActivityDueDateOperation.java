/*
 * Created on Mar 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.workflow;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivityDueDateOperation {

	//List activityList = new ArrayList();
	
	public static void main(String args[]) throws Exception{
		ActivityDueDateOperation activityOperations = new ActivityDueDateOperation();
		activityOperations.updateDueDate();
	}
	
	public void updateDueDate() throws Exception{
		List activityList = getActivityList();
		setDueDate(activityList);
	}
	
	public List getActivityList()throws Exception{
		
		List activityList = new ArrayList();
		
		Connection con = null;

		PreparedStatement updateActivityStatus = null;
	
		try {
			con = getConnection();

			updateActivityStatus = con.prepareStatement("SELECT * FROM OWNER_ACTIVITY");
			
			ResultSet rs = updateActivityStatus.executeQuery();
			
			while(rs.next()){
				populateActivityList(rs,activityList);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return activityList;
	}
	
	public Connection getConnection() throws Exception {
		//Context initContext = new InitialContext();
//		Context envContext = (Context) initContext.lookup("java:/comp/env");
//		DataSource ds = (DataSource) envContext.lookup("jdbc/soxicdb");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@tst01.monsanto.com:1521:comgent","sarbox_et","sarbox_et_123");
		//Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@stddba01.monsanto.com:1521:comgend","sarbox_et","sarbox_et");
		//ds.getConnection();
		return conn;
	}	
	
	public void populateActivityList(ResultSet rs,List activitylist)throws Exception{
		Activity activity = new Activity();
		activity.setActivity_id(rs.getString("ACTIVITY_ID"));
		activity.setOwner_id(rs.getString("OWNER_ID"));
		activity.setStatus(rs.getString("STATUS"));
		activity.setStart_date(rs.getDate("START_DATE"));
		activity.setDue_date(rs.getDate("DUE_DATE"));
		activity.setComplete_date(rs.getDate("COMPLETE_DATE"));
		activity.setMod_date(rs.getDate("MOD_DATE"));
		activity.setMod_user(rs.getString("MOD_USER"));
		activitylist.add(activity);
		
	}
	
	public void processActivityStatus(List activityList){
		
		Iterator activityListIterator = activityList.iterator();
		
		while(activityListIterator.hasNext()){
			
			Activity activity = (Activity)activityListIterator.next();
			
			Date date = activity.getDue_date();
			
			Date currentDate = new Date(System.currentTimeMillis());
			
			Date fifteenDate = new Date(System.currentTimeMillis()+1296000000);
			
			Date thirtyDate = new Date(System.currentTimeMillis()+1296000000+1296000000);
			
			boolean valueone = date.before(fifteenDate);
			
			boolean valuetwo = date.before(thirtyDate);

			if(date.before(fifteenDate) && toModify(activity.getStatus(),"R")){
				activity.setStatus("R_"+getStatusToAppend(activity.getStatus()));
				activity.setToupdate(true);
			}else{
				if(date.before(thirtyDate) && date.after(fifteenDate) && toModify(activity.getStatus(),"Y")){
					activity.setStatus("Y_"+getStatusToAppend(activity.getStatus()));
					activity.setToupdate(true);
				}
				
				if(date.after(thirtyDate) && toModify(activity.getStatus(),"G")){
					activity.setStatus("G_"+getStatusToAppend(activity.getStatus()));
					activity.setToupdate(true);
				}				
			}
		}
	}
	
	public void updateStatus(List activityList)throws Exception{
		Iterator activityListIterator = activityList.iterator();
		
		while(activityListIterator.hasNext()){
			
			Activity activity = (Activity)activityListIterator.next();
			
			if(activity.isToupdate()){
				updateActivity(activity);
			}
			
			
		}
	}
	
	public void updateActivity(Activity activity)throws Exception{
		Connection con = null;

		PreparedStatement updateActivity = null;
		
		//List activityList = new ArrayList();
		

		try {
			con = getConnection();

			updateActivity = con.prepareStatement("UPDATE OWNER_ACTIVITY OA SET OA.STATUS=? WHERE OA.OWNER_ID=? AND OA.ACTIVITY_ID=?");
			
			updateActivity.setString(1,activity.getStatus());
			
			updateActivity.setString(2,activity.getOwner_id());
			
			updateActivity.setString(3,activity.getActivity_id());
			
			updateActivity.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public String getStatusToAppend(String currentStatus){
		if(currentStatus.indexOf("_")>0){
			return currentStatus.substring(currentStatus.indexOf("_")+1,currentStatus.length());
		}
		return currentStatus;
	}
	
	public boolean toModify(String currentStatus,String currentString){
		
		if(currentStatus.indexOf(currentString)<0){
			return true;
		}
		return false;
	}
	
	public void setDueDate(List activityList) throws Exception{
		
		Iterator activityIterator = activityList.iterator();
		
		while( activityIterator.hasNext()){
			
			Activity activity = (Activity)activityIterator.next();
			
			updateDate(activity);
			
		}
		
	}
	
	public void updateDate(Activity activity)throws Exception{
		Connection con = null;

		PreparedStatement updateActivity = null;
		
		//List activityList = new ArrayList();
		

		try {
			con = getConnection();

			updateActivity = con.prepareStatement("UPDATE OWNER_ACTIVITY OA SET OA.DUE_DATE=? WHERE OA.OWNER_ID=? AND OA.ACTIVITY_ID=?");
			
			Date toset = new Date(System.currentTimeMillis()+1296000000+1296000000+1296000000);
			
			updateActivity.setDate(1,toset);
			
			//updateActivity.setString(1,activity.getStatus());
			
			updateActivity.setString(2,activity.getOwner_id());
			
			updateActivity.setString(3,activity.getActivity_id());
			
			updateActivity.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}	
	
	public void updateS(Activity activity)throws Exception{
		Connection con = null;

		PreparedStatement updateActivity = null;
		
		try {
			con = getConnection();

			updateActivity = con.prepareStatement("UPDATE OWNER_ACTIVITY OA SET OA.STATUS=? WHERE OA.OWNER_ID=? AND OA.ACTIVITY_ID=?");
			
			Date toset = new Date(System.currentTimeMillis()+1296000000+1296000000+1296000000);
			
			updateActivity.setString(1,"IMPORTED");
						
			updateActivity.setString(2,activity.getOwner_id());
			
			updateActivity.setString(3,activity.getActivity_id());
			
			updateActivity.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}		

}
