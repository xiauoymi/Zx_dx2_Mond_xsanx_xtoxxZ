//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.action.InternationalDataObject;
import com.monsanto.wst.soxic.action.TotalDataObject;

/** 
 * MyEclipse Struts
 * Creation date: 03-15-2005
 * 
 * XDoclet definition:
 * @struts:form name="cycleReportForm"
 */
public class CycleReportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	private String periodID;
	
	private Vector worldAreaVector = new Vector();
	
	private InternationalDataObject intlData = new InternationalDataObject();
	
	private TotalDataObject totalData = new TotalDataObject();
	
	private Vector periodList = new Vector();
	
	private int totalNALAN;
	
	private int totalInternational;
	
	private int totalMonsanto;
	
	
	//	 --------------------------------------------------------- Methods

	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		
		if(periodID == null || periodID.equals("")){
			errors.add("periodID3", new ActionError("errors.activityReport.periodID.null"));
			
		}
		
		return errors;
	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}
	
	/**
	 * @return Returns the intlData.
	 */
	public InternationalDataObject getIntlData() {
		return intlData;
	}
	/**
	 * @param intlData The intlData to set.
	 */
	public void setIntlData(InternationalDataObject intlData) {
		this.intlData = intlData;
	}
	/**
	 * @return Returns the totalData.
	 */
	public TotalDataObject getTotalData() {
		return totalData;
	}
	/**
	 * @param totalData The totalData to set.
	 */
	public void setTotalData(TotalDataObject totalData) {
		this.totalData = totalData;
	}
	/**
	 * @param totalMonsanto The totalMonsanto to set.
	 */
	public void setTotalMonsanto(int totalMonsanto) {
		this.totalMonsanto = totalMonsanto;
	}
	

	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}
	
	
	
	/**
	 * @return Returns the worldAreaVector.
	 */
	public Vector getWorldAreaVector() {
		return worldAreaVector;
	}
	/**
	 * @param worldAreaVector The worldAreaVector to set.
	 */
	public void setWorldAreaVector(Vector worldAreaVector) {
		this.worldAreaVector = worldAreaVector;
	}
	
	
	/**
	 * @return Returns the periodList.
	 */
	public Vector getPeriodList() {
		return periodList;
	}
	/**
	 * @param periodList The periodList to set.
	 */
	public void setPeriodList(Vector periodList) {
		this.periodList = periodList;
	}
	/**
	 * @return Returns the totalInternational.
	 */
	public int getTotalInternational() {
		return totalInternational;
	}
	/**
	 * @param totalInternational The totalInternational to set.
	 */
	public void setTotalInternational(int totalInternational) {
		this.totalInternational = totalInternational;
	}
	/**
	 * @return Returns the totalNALAN.
	 */
	public int getTotalNALAN() {
		return totalNALAN;
	}
	/**
	 * @param totalNALAN The totalNALAN to set.
	 */
	public void setTotalNALAN(int totalNALAN) {
		this.totalNALAN = totalNALAN;
	}
	/**
	 * @return Returns the totalMonsanto.
	 */
	public int getTotalMonsanto() {
		return (totalNALAN + totalInternational);
	}
}