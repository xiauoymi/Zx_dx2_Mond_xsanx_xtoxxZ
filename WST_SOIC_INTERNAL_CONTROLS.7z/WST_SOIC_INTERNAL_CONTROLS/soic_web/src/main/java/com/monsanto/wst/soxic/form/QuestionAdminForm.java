package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 3:21:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuestionAdminForm extends ActionForm {

    private String activityHeader;
    private String activityFooter;
    private String subcycleHeader;
    private String subcycleFooter;
    private String cycleHeader;
    private String cycleFooter;

    public String getActivityHeader() {
        return activityHeader;
    }

    public void setActivityHeader(String activityHeader) {
        this.activityHeader = activityHeader;
    }

    public String getActivityFooter() {
        return activityFooter;
    }

    public void setActivityFooter(String activityFooter) {
        this.activityFooter = activityFooter;
    }

    public String getSubcycleHeader() {
        return subcycleHeader;
    }

    public void setSubcycleHeader(String subcycleHeader) {
        this.subcycleHeader = subcycleHeader;
    }

    public String getSubcycleFooter() {
        return subcycleFooter;
    }

    public void setSubcycleFooter(String subcycleFooter) {
        this.subcycleFooter = subcycleFooter;
    }

    public String getCycleHeader() {
        return cycleHeader;
    }

    public void setCycleHeader(String cycleHeader) {
        this.cycleHeader = cycleHeader;
    }

    public String getCycleFooter() {
        return cycleFooter;
    }

    public void setCycleFooter(String cycleFooter) {
        this.cycleFooter = cycleFooter;
    }
}
