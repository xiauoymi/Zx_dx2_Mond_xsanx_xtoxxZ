/*
 * Created on Mar 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RiskDAO {

	/**
	 * Returns the risk for a particular identifier for a particular level
	 * @param idIn
	 * @param level
	 * @return list of risk strings
	 * @throws Exception
	 */
	public static List getRiskList(String idIn,String level) throws Exception{
		
		List riskList = new ArrayList();

		Connection con = null;
		PreparedStatement getRisk = null;
		ResultSet rs=null;
		
		String risk="";
		try {
			con = SoxicConnectionFactory.getSoxicConnection();
			getRisk = con.prepareStatement(getRiskQuery(level));		
			getRisk.setString(1, idIn);
			rs = getRisk.executeQuery();
			
			while (rs.next()) {
				
				risk = rs.getString("RISK");
				if(risk!=null){
					riskList.add(risk);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//enclose this in a finally block to make
			//sure the connection is closed
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return riskList;
	}
	
//	public static Connection getConnection() throws Exception {
//		Context initContext = new InitialContext();
//		Context envContext = (Context) initContext.lookup("java:/comp/env");
//		DataSource ds = (DataSource) envContext.lookup("jdbc/soxicdb");
//		Connection conn = ds.getConnection();
//		return conn;
//	}	
	
	public static String getRiskQuery(String level){

		String query = "";

		if(level.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
			
			query = "SELECT DISTINCT CO.RISK FROM SUB_CYCLE SC,CTRL_OBJ CO WHERE SC.SUB_CYCLE_ID=? AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID";
		}
		
		if(level.equalsIgnoreCase(SoxicConstants.CYCLE)){
			
			query = "SELECT DISTINCT CO.RISK FROM CYCLE C,SUB_CYCLE SC,CTRL_OBJ CO WHERE C.CYCLE_ID=? AND SC.CYCLE_ID=C.CYCLE_ID AND SC.SUB_CYCLE_ID=CO.SUB_CYCLE_ID";
		}
		
		if(level.equalsIgnoreCase(SoxicConstants.CONTROLOBJECTIVE)){
			
			query = "SELECT DISTINCT CO.RISK FROM CTRL_OBJ CO WHERE CO.CTRL_OBJ_ID=?";
		}
	
		return query;
	}
}
