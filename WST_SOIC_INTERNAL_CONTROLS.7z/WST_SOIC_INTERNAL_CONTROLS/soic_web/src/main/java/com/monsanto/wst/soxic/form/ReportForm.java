/*
ExcelExportAction was create on 02/04/2005 using Monsanto resources and is the sole
property of Monsanto.  Any duplication of the code and/or logic is a direct
infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.form;

import java.util.Vector;

import org.apache.struts.action.ActionForm;


/**
 * This is the form bean for /report action.
 * 
 * @author Rasesh Desai (rasesh.desai@monsanto.com)
 * (|| Om Ganeshay Namah: ||)
 * @version 1.0
 */
public class ReportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	String folderName = "";
	String fileName = "";
	
	Vector columnVector = new Vector();
	
	RowObject rowObject = new RowObject();
	
	String countryId;
	
	String worldArea;
	
	Vector subCycleOwners = new Vector();
	
	Vector cycleOwners = new Vector();
	
	String subCycleOwnerList = "";	
	String cycleOwnerList = "";
	
	String subCycleDesc;
	String cycleDesc;
	
	String periodID;
	
	String subCycleID;

    String gap_description;




	/**
	 * @return Returns the subCycleID.
	 */
	public String getSubCycleID() {
		return subCycleID;
	}
	/**
	 * @param subCycleID The subCycleID to set.
	 */
	public void setSubCycleID(String subCycleID) {
		this.subCycleID = subCycleID;
	}
	/**
	 * @return Returns the cycleDesc.
	 */
	public String getCycleDesc() {
		return cycleDesc;
	}
	/**
	 * @param cycleDesc The cycleDesc to set.
	 */
	public void setCycleDesc(String cycleDesc) {
		this.cycleDesc = cycleDesc;
	}
	/**
	 * @return Returns the subCycleDesc.
	 */
	public String getSubCycleDesc() {
		return subCycleDesc;
	}
	/**
	 * @param subCycleDesc The subCycleDesc to set.
	 */
	public void setSubCycleDesc(String subCycleDesc) {
		this.subCycleDesc = subCycleDesc;
	}
	/**
	 * @return Returns the cycleOwnerList.
	 */
	public String getCycleOwnerList() {
		return cycleOwnerList;
	}
	/**
	 * @param cycleOwnerList The cycleOwnerList to set.
	 */
	public void setCycleOwnerList(String cycleOwnerList) {
		this.cycleOwnerList = cycleOwnerList;
	}
	/**
	 * @return Returns the subCycleOwnerList.
	 */
	public String getSubCycleOwnerList() {
		return subCycleOwnerList;
	}
	/**
	 * @param subCycleOwnerList The subCycleOwnerList to set.
	 */
	public void setSubCycleOwnerList(String subCycleOwnerList) {
		this.subCycleOwnerList = subCycleOwnerList;
	}
	/**
	 * @return Returns the fileName.
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName The fileName to set.
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return Returns the folderName.
	 */
	public String getFolderName() {
		return folderName;
	}
	/**
	 * @param folderName The folderName to set.
	 */
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	/**
	 * @return Returns the rowObject.
	 */
	public RowObject getRowObject() {
		return rowObject;
	}
	/**
	 * @param rowObject The rowObject to set.
	 */
	public void setRowObject(RowObject rowObject) {
		this.rowObject = rowObject;
	}
	
	
	// --------------------------------------------------------- Methods
//	public String getIndexCol1(int index){
//		return (String)col1.get(index).toString();
//	}
//	
//	public void modifyCol1(int index, String val){
//		col1.set(index, val);
//	}
//	
//	public String getIndexCol2(int index){
//		return (String)col2.get(index).toString();
//	}
//	
//	public void modifyCol2(int index, String val){
//		col2.set(index, val);
//	}

	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

//	
	/**
	 * @return Returns the columnVector.
	 */
	public Vector getColumnVector() {
		return columnVector;
	}
	/**
	 * @param columnVector The columnVector to set.
	 */
	public void setColumnVector(Vector columnVector) {
		this.columnVector = columnVector;
	}
	/**
	 * @return Returns the countryId.
	 */
	public String getCountryId() {
		return countryId;
	}
	/**
	 * @param countryId The countryId to set.
	 */
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	/**
	 * @return Returns the cycleOwners.
	 */
	public Vector getCycleOwners() {
		return cycleOwners;
	}
	/**
	 * @param cycleOwners The cycleOwners to set.
	 */
	public void setCycleOwners(Vector cycOwners) {
		this.cycleOwners = cycOwners;
		
		for(int i = 0; i < cycOwners.size(); i++){
			if(i == 0){
				cycleOwnerList = cycOwners.get(i).toString();
			}
			else{
				cycleOwnerList = cycleOwnerList + ", " + cycOwners.get(i);
			}
		}
	}
	/**
	 * @return Returns the subCycleOwners.
	 */
	public Vector getSubCycleOwners() {
		return subCycleOwners;
	}
	/**
	 * @param subCycleOwners The subCycleOwners to set.
	 */
	public void setSubCycleOwners(Vector subCycOwners) {
		this.subCycleOwners = subCycleOwners;
		
		for(int i = 0; i < subCycOwners.size(); i++){
			if(i == 0){
				subCycleOwnerList = subCycOwners.get(i).toString();
			}
			else{
				subCycleOwnerList = subCycleOwnerList + ", " + subCycOwners.get(i);
			}
		}
	}
	/**
	 * @return Returns the worldArea.
	 */
	public String getWorldArea() {
		return worldArea;
	}
	/**
	 * @param worldArea The worldArea to set.
	 */
	public void setWorldArea(String worldArea) {
		this.worldArea = worldArea;
	}
	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}

    /**
     * @return returns the Gap Description
     */
    public String getGap_description() {
        return gap_description;
    }

    /**
     * @param gap_description is Set
     */
    public void setGap_description(String gap_description) {
        this.gap_description = gap_description;
    }
}