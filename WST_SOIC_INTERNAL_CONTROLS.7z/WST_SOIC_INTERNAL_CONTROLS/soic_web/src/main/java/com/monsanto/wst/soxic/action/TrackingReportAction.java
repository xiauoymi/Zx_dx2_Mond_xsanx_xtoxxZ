//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.TrackingReportForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

/** 
 * MyEclipse Struts
 * Creation date: 03-22-2005
 * 
 * XDoclet definition:
 * @struts:action path="/trackingReport" name="trackingReportForm" scope="request"
 */
public class TrackingReportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
    
    Date todaysDate = new Date(System.currentTimeMillis());
    
    String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    
    String currPeriod;
    
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		TrackingReportForm trackingReportForm = (TrackingReportForm) form;
		
		Vector worldAreaVector = new Vector();
		
		String currentPeriodID = trackingReportForm.getPeriodID();
		
		String userSelectedCountry = trackingReportForm.getCountryID();
		
		int totalNALAN = 0;		
		int totalInternational = 0;
		
		
		Vector cycleCodes = new Vector();
		Vector cycleTrackingVector = new Vector();
		Connection con=null;
		
		
		//**Connecting to the Oracle DB...
		//**Table2-Info
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			con = SoxicConnectionFactory.getSoxicConnection();
		 	
		 	logger.info("Connected to DB from /cycle-Report-action.");
		 	
		 	PreparedStatement getWorldArea;
			PreparedStatement getCountry;
			PreparedStatement getTotalActivities;
			PreparedStatement getTotalActivitiesComplete;
			
			getWorldArea = con.prepareStatement
				("SELECT DISTINCT WORLD_AREA_ID " +
					"FROM CYCLE ORDER BY WORLD_AREA_ID DESC");
			
			getCountry = con.prepareStatement
				("SELECT DISTINCT COUNTRY_ID " +
					"FROM CYCLE  " +
					"WHERE  WORLD_AREA_ID = ? ORDER BY COUNTRY_ID DESC");
			
			getTotalActivities = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_ACTIVITIES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"C.CYCLE_ID = SC.CYCLE_ID AND " +
						"SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND " +
						"CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND " +
						"C.COUNTRY_ID = ? AND " +
						"C.PERIOD_ID = ?");
			
			getTotalActivitiesComplete = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_ACTIVITIES_COMPLETE " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"C.CYCLE_ID = SC.CYCLE_ID AND " +
						"SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND " +
						"CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND " +
						"A.STATUS = ? AND " +
						"C.COUNTRY_ID = ? AND " +
						"C.PERIOD_ID = ?");
			
			ResultSet rsWorldArea;
			
			rsWorldArea = getWorldArea.executeQuery();
			
			//**#nested:root
			while(rsWorldArea.next()){
				
				WorldAreaObject worldObj = new WorldAreaObject();
				
				String currWorldID = rsWorldArea.getString("WORLD_AREA_ID").trim();
				worldObj.setWorldAreaName(currWorldID);
				
				Vector countryVector = new Vector();
				
				// #nested-level#2
				ResultSet rsCountry;
				
				getCountry.setString(1, currWorldID);
				
				rsCountry = getCountry.executeQuery();
				
				while(rsCountry.next()){
					CountryObject countryObj = new CountryObject();
					
					String currCountryID = rsCountry.getString("COUNTRY_ID");
					
					//country-name
					countryObj.setCountryName(currCountryID);
					
					//total-activities
					ResultSet rsTotalAct;
					
					getTotalActivities.setString(1, currCountryID);
					getTotalActivities.setString(2, currentPeriodID);
					
					rsTotalAct = getTotalActivities.executeQuery();
					
					int totalAct = 0;
					while(rsTotalAct.next()){
						totalAct = rsTotalAct.getInt("TOTAL_ACTIVITIES");
					}
					
					worldObj.addToTotalActivities(totalAct);
					
					if(currWorldID.equalsIgnoreCase("NALAN")){
						totalNALAN += totalAct;
					}
					else{
						totalInternational += totalAct;
					}
					
					countryObj.setTotalActivities(totalAct);
					
					//activity-percent-complete
					ResultSet rsCompleteAct;
					
					getTotalActivitiesComplete.setString(1, SoxicConstants.COMPLETE.toUpperCase());
					getTotalActivitiesComplete.setString(2, currCountryID);
					getTotalActivitiesComplete.setString(3, currentPeriodID);
					
					rsCompleteAct = getTotalActivitiesComplete.executeQuery();
					
					int totalComplete = 0;
					while(rsCompleteAct.next()){
						totalComplete = rsCompleteAct.getInt("TOTAL_ACTIVITIES_COMPLETE");
					}
					
					try{
						countryObj.setActivityPercentageComplete( (totalComplete * 100)/totalAct );
					}
					catch(ArithmeticException ax){
						//**Possiblity of Divide-by-zero exception...
						countryObj.setActivityPercentageComplete(0);
					}
					
					countryVector.add(countryObj);
				}
				
				
				worldObj.setCountryVector(countryVector);
				worldAreaVector.add(worldObj);
				
				logger.info("Done populating info for one reqd world-area fields for tracking-report.");
				
				 
			}
			
//			**Table1-Info
			PreparedStatement getCycles;
			PreparedStatement getCyclesCompleted;
			PreparedStatement getCyclesDueDate;
			
			PreparedStatement getAllSubCycles;
			PreparedStatement getCompleteSubCycles;
			PreparedStatement getSubCyclesDueDate;
			
			PreparedStatement getAllActivities;
			PreparedStatement getCompleteActivities;
			PreparedStatement getActivitiesDueDate;
			
			
			getCycles = con.prepareStatement
				("SELECT " +
						"CYCLE_ID, CYCLE_CODE " +
					"FROM " +
						"CYCLE " +
					"WHERE " +
						"COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"PERIOD_ID = ?");
			
			getCyclesCompleted  = con.prepareStatement
				("SELECT " +
						"COUNT(*) CYCLES_COMPLETE " +
					"FROM " +
						"CYCLE C " +
					"WHERE " +
						"STATUS = ? AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			
			getCyclesDueDate = con.prepareStatement
				("SELECT " +
						"OC.DUE_DATE CYCLE_DUE_DATE " +
					"FROM " +
						"CYCLE C, OWNER_CYCLE OC " +
					"WHERE " +
						"C.CYCLE_ID = OC.CYCLE_ID AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
				
			getAllSubCycles = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_SUB_CYCLES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC " +
					"WHERE " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			
			getCompleteSubCycles = con.prepareStatement
				("SELECT " +
						"COUNT(*) COMPLETE_SUB_CYCLES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC " +
					"WHERE " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"SC.STATUS = ? AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			
			getSubCyclesDueDate = con.prepareStatement
				("SELECT " +
						"MAX(OS.DUE_DATE) SUB_CYCLE_DUE_DATE " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, OWNER_SUB_CYCLE OS " +
					"WHERE " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"SC.SUB_CYCLE_ID = OS.SUB_CYCLE_ID AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
				
			getAllActivities = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_ACTIVITIES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
						"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			
			getCompleteActivities = con.prepareStatement
				("SELECT " +
						"COUNT(*) COMPLETE_ACTIVITIES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
						"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"A.STATUS = ? AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			
			getActivitiesDueDate = con.prepareStatement
				("SELECT " +
						"MAX(OA.DUE_DATE) ACTIVITY_DUE_DATE " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, OWNER_ACTIVITY OA, ACTIVITY A, CTRL_OBJ CO " +
					"WHERE " +
						"A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
						"CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
						"SC.CYCLE_ID = C.CYCLE_ID AND " +
						"A.ACTIVITY_ID = OA.ACTIVITY_ID AND " +
						"C.COUNTRY_ID = '"+userSelectedCountry+"' AND " +
						"C.PERIOD_ID = ? AND " +
						"C.CYCLE_CODE = ?");
			 
			//String COMPLETE = SoxicConstants.COMPLETE;
			currPeriod = trackingReportForm.getPeriodID();
			
			ResultSet rsCycles;			
			getCycles.setString(1, currPeriod);			
			rsCycles = getCycles.executeQuery();
			
			while(rsCycles.next()){				
				cycleCodes.add(rsCycles.getString("CYCLE_CODE"));				
			}
			
			rsCycles = getCycles.executeQuery();
			
			//nested#1
			while(rsCycles.next()){				
				
				CycleTrackingObject cycleTrackObj = new CycleTrackingObject();
				
				String currCycle = rsCycles.getString("CYCLE_CODE");
				
				//logger.info("Break point...");
				
				//***Cycles...				
				int totalCycles = 1;
				
				int completeCycles = 0;
				
				ResultSet rsCompleteCycles;
				
				getCyclesCompleted.setString(1, SoxicConstants.COMPLETE);
				getCyclesCompleted.setString(2, currPeriod);
				getCyclesCompleted.setString(3, currCycle);
				
				rsCompleteCycles = getCyclesCompleted.executeQuery();
				
				while(rsCompleteCycles.next()){
					completeCycles = rsCompleteCycles.getInt("CYCLES_COMPLETE");
				}
				
				if(totalCycles == completeCycles){
					cycleTrackObj.setCycleComplete(true);
				}	
				else{
					cycleTrackObj.setCycleComplete(false);
					
					Date cycleDueDate = new Date(System.currentTimeMillis());
					
					ResultSet rsCycleDueDate;
					
					getCyclesDueDate.setString(1, currPeriod);
					getCyclesDueDate.setString(2, currCycle);
					
					rsCycleDueDate = getCyclesDueDate.executeQuery();
					
					int rsSize = 0;
					while(rsCycleDueDate.next()){
						cycleDueDate = rsCycleDueDate.getDate("CYCLE_DUE_DATE");
						rsSize++;
					}
					
					String cycleColor = "Green";
					
					if(rsSize == 0 || cycleDueDate == null){						
						cycleTrackObj.setCycleDate("?");
						cycleColor = "White";
					}
					else{
						//**Todays Date is greater...
						if(todaysDate.before(cycleDueDate)){
//							cycleColor = compareDates(cycleDueDate, todaysDate);
                            cycleColor = "White";
							cycleTrackObj.setCycleDate(cycleDueDate.getDate() + "-" + months[cycleDueDate.getMonth()]);
						}
						
						if(todaysDate.after(cycleDueDate)){
//							cycleTrackObj.setCycleDate("X");
                            cycleTrackObj.setCycleDate(cycleDueDate.getDate() + "-" + months[cycleDueDate.getMonth()]);
//							cycleColor = "Purple";
                            cycleColor = "Red";
						}
						
						if(todaysDate.toString().equals(cycleDueDate.toString())){
							//**dude-date is today
							cycleTrackObj.setCycleDate(cycleDueDate.getDate() + "-" + months[cycleDueDate.getMonth()]);
//							cycleColor = "Red";
						}
					}
					
					cycleTrackObj.setCycleColor(cycleColor);
					
				}
				
				
				
				//***Sub-Cycles...
				int totalSubCycles = 0;
				
				ResultSet rsAllSubCycles;
				
				getAllSubCycles.setString(1, currPeriod);
				getAllSubCycles.setString(2, currCycle);
				
				rsAllSubCycles = getAllSubCycles.executeQuery();
				
				while(rsAllSubCycles.next()){
					totalSubCycles = rsAllSubCycles.getInt("TOTAL_SUB_CYCLES");
				}
				
				
				int completeSubCycles = 0;
				
				ResultSet rsCompleteSubCycles;
				
				getCompleteSubCycles.setString(1, SoxicConstants.COMPLETE);
				getCompleteSubCycles.setString(2, currPeriod);
				getCompleteSubCycles.setString(3, currCycle);
				
				rsCompleteSubCycles = getCompleteSubCycles.executeQuery();
				
				while(rsCompleteSubCycles.next()){
					completeSubCycles = rsCompleteSubCycles.getInt("COMPLETE_SUB_CYCLES");
				}
				
				if(totalSubCycles == completeSubCycles){
					cycleTrackObj.setSubCycleComplete(true);
				}	
				else{
					cycleTrackObj.setSubCycleComplete(false);
					
					Date subCycleDueDate = new Date(System.currentTimeMillis());
					
					ResultSet rsSubCycleDueDate;
					
					getSubCyclesDueDate.setString(1, currPeriod);
					getSubCyclesDueDate.setString(2, currCycle);
					
					rsSubCycleDueDate = getSubCyclesDueDate.executeQuery();
					
					int rsSize = 0;
					while(rsSubCycleDueDate.next()){
						subCycleDueDate = rsSubCycleDueDate.getDate("SUB_CYCLE_DUE_DATE");
						rsSize++;
					}
					
					String subCycleColor = "Green";
					
					if(rsSize == 0 || subCycleDueDate == null){						
						cycleTrackObj.setSubCycleDate("?");
						subCycleColor = "White";
					}
					else{
						
						//**Todays Date is greater...
						if(todaysDate.before(subCycleDueDate)){
//							subCycleColor = compareDates(subCycleDueDate, todaysDate);
                            subCycleColor = "White";
							cycleTrackObj.setSubCycleDate(subCycleDueDate.getDate() + "-" + months[subCycleDueDate.getMonth()]);
						}
						
						if(todaysDate.after(subCycleDueDate)){
//							cycleTrackObj.setSubCycleDate("X");
//							subCycleColor = "Purple";
                            subCycleColor = "Red";
                            cycleTrackObj.setSubCycleDate(subCycleDueDate.getDate() + "-" + months[subCycleDueDate.getMonth()]);
						}
						
						if(todaysDate.toString().equals(subCycleDueDate.toString())){
							
							//**dude-date is today
							cycleTrackObj.setSubCycleDate(subCycleDueDate.getDate() + "-" + months[subCycleDueDate.getMonth()]);
//							subCycleColor = "Red";
						}
					}
					
					cycleTrackObj.setSubCycleColor(subCycleColor);
					
				}
				
				
				//***activities...
				int totalActivities = 0;
				
				ResultSet rsAllActivities;
				
				getAllActivities.setString(1, currPeriod);
				getAllActivities.setString(2, currCycle);
				
				rsAllActivities = getAllActivities.executeQuery();
				
				while(rsAllActivities.next()){
					totalActivities = rsAllActivities.getInt("TOTAL_ACTIVITIES");
				}
				
				
				int completeActivities = 0;
				
				ResultSet rsCompleteActivities;
				
				getCompleteActivities.setString(1, SoxicConstants.COMPLETE);
				getCompleteActivities.setString(2, currPeriod);
				getCompleteActivities.setString(3, currCycle);
				
				rsCompleteActivities = getCompleteActivities.executeQuery();
				
				while(rsCompleteActivities.next()){
					completeActivities = rsCompleteActivities.getInt("COMPLETE_ACTIVITIES");
				}
				
				if(totalActivities == completeActivities){
					cycleTrackObj.setActivityComplete(true);
				}	
				else{
					cycleTrackObj.setActivityComplete(false);
					
					Date activityDueDate = new Date(System.currentTimeMillis());
					
					ResultSet rsActivityDueDate;
					
					getActivitiesDueDate.setString(1, currPeriod);
					getActivitiesDueDate.setString(2, currCycle);
					
					rsActivityDueDate = getActivitiesDueDate.executeQuery();
					
					int rsSize = 0;
					while(rsActivityDueDate.next()){
						activityDueDate = rsActivityDueDate.getDate("ACTIVITY_DUE_DATE");
						rsSize++;
					}
					
					String activityColor = "Green";
					
					if(rsSize == 0 || activityDueDate == null){						
						cycleTrackObj.setActivityDate("?");
						activityColor = "White";
					}
					else{
						
						//**Todays Date is greater...
						if(todaysDate.before(activityDueDate)){
                            activityColor = "White";
//							activityColor = compareDates(activityDueDate, todaysDate);
							cycleTrackObj.setActivityDate(activityDueDate.getDate() + "-" + months[activityDueDate.getMonth()]);
						}
						
						if(todaysDate.after(activityDueDate)){
//							cycleTrackObj.setActivityDate("X");
                            cycleTrackObj.setActivityDate(activityDueDate.getDate() + "-" + months[activityDueDate.getMonth()]);
//							activityColor = "Purple";
                            activityColor = "Red";
						}
						
						if(todaysDate.toString().equals(activityDueDate.toString())){
							
							//**dude-date is today
							cycleTrackObj.setActivityDate(activityDueDate.getDate() + "-" + months[activityDueDate.getMonth()]);
//							activityColor = "Red";
						}
					}
					
					cycleTrackObj.setActivityColor(activityColor);
					
					
				}
				
				
				
				cycleTrackingVector.add(cycleTrackObj);
			}
			
		}
		catch(Exception ex){
			logger.fatal("Database error from tracking action " + ex.getMessage());
		}
		finally{
			try{
				if(con!= null && !con.isClosed()){
					con.close();
				}
			}catch(Exception e){
				
			}
		}
		
		trackingReportForm.setCycleCodes(cycleCodes);
		trackingReportForm.setCycleTrackingVector(cycleTrackingVector);
		trackingReportForm.setTodaysDate(todaysDate.getDate() + "-" + months[todaysDate.getMonth()] + "-" + currPeriod.substring(currPeriod.length()-2, currPeriod.length()));
		
		trackingReportForm.setTotalNALAN(totalNALAN);
		trackingReportForm.setTotalInternational(totalInternational);
		
		trackingReportForm.setWorldAreaVector(worldAreaVector);
		
		return mapping.findForward("success");
	}
	
	
	/**
	 * Function that compares the dates and returns the color...
	 * 
	 * Red: <= 15 days
	 * Yellow <= 1 month
	 * Green > 1 month
	 * 
	 * 
	 * @param todaysDate
	 * @param dueDate
	 * @return
	 */
	
	public String compareDates(Date dueDate, Date todayDate){
		
		String cycleColor = "";
		
		String colorCode = SoxicUtil.returnStatusPreceedingStr(dueDate);
		
		if(colorCode.equals("G_"))
			cycleColor = "Green";
		
		if(colorCode.equals("Y_"))
			cycleColor = "Yellow";
		
		if(colorCode.equals("R_"))
			cycleColor = "Red";
		
		return cycleColor;
	}
	
	

}