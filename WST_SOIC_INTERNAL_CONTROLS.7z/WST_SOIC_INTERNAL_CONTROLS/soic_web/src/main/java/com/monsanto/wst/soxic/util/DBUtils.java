package com.monsanto.wst.soxic.util;

import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.Util.Exceptions.WrappingException;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 1, 2006
 * Time: 1:21:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class DBUtils {

    public static void closeConnection(ResultSet rs, PreparedStatement preparedStatement, Connection con) {
        try {
            SoxicConnectionFactory.closeResultSet(rs);
            SoxicConnectionFactory.closePreparedStatement(preparedStatement);
            SoxicConnectionFactory.commit(con);
            SoxicConnectionFactory.closeSoxicConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  public static PersistentStoreConnection createPersistentStore() throws WrappingException {
    PersistentStore persistentStore = WST_SOX_PersistentStoreFactory.getStore();
    PersistentStore.registerInstance(persistentStore);
    return persistentStore.connect();
  }

    public static void closeConnections(PersistentStoreStatement persistentStoreStatement, PersistentStoreConnection psConnection) {
        if(psConnection!=null){
            try {
                psConnection.close();
            } catch (WrappingException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }
}
