//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ReportListForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/** 
 * MyEclipse Struts
 * Creation date: 02-24-2005
 * 
 * XDoclet definition:
 * @struts:action path="/reportList" name="reportListForm" input="/jsp/reportList.jsp" scope="request" validate="true"
 */
public class ReportListAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());

    
	// --------------------------------------------------------- Methods

	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		
		ReportListForm reportListForm = (ReportListForm) form;
		
		String ownerId = "";
	    Vector ownerRole = new Vector();
        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);

	    ReportListingObject reportObj = new ReportListingObject();
	    
	    ResultSet rs;
		
		Vector ReportList = new Vector();
	    
		Vector viewableReportIds = new Vector();
		
		ownerId = ((Owner)request.getSession().getAttribute("owner")).getOwnerId();
        
		logger.info("/reportList.do called...");
		Connection con=null;
		
		
		//**Connecting to the Oracle DB...
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			 con = SoxicConnectionFactory.getSoxicConnection();
			
		 	logger.info("Connected to DB from /reportList.");
			
			//**Prepared Statements...
			PreparedStatement getOwnerRole;
			PreparedStatement getViewableReports;
			PreparedStatement getReportList;
			PreparedStatement getViewedByAllReportList;
			
			getOwnerRole = con.prepareStatement
				("SELECT ROLE_ID " +
					"FROM OWNER_ROLE " +
					"WHERE OWNER_ID = ?");
			
			getViewableReports = con.prepareStatement
			("SELECT " +
					"RR.REPORT_ID " +
				"FROM " +
					"REPORT_ROLE RR, REPORT R " +
				"WHERE " +
					"RR.ROLE_ID = ? AND " +
					"R.REPORT_ID = RR.REPORT_ID AND " +
					"R.ACTIVE = 'Y' ORDER BY REPORT_ID");
			
			getViewedByAllReportList = con.prepareStatement
			("SELECT " +
					"RR.REPORT_ID " +
				"FROM " +
						"REPORT_ROLE RR, REPORT R " +
				"WHERE " +
					"R.REPORT_ID = RR.REPORT_ID AND " +
					"R.ACTIVE = 'Y' AND " +
					"RR.ROLE_ID = 'All' ORDER BY RR.REPORT_ID");
			
			getReportList = con.prepareStatement
			("SELECT " +
					"NAME, DESCRIPTION, LOCATION, TYPE " +
				"FROM REPORT " +
				"WHERE REPORT_ID = ?");
			
			
			getOwnerRole.setString(1, ownerId);
			rs = getOwnerRole.executeQuery();
			
			
			while(rs.next()){
				ownerRole.add(rs.getString("ROLE_ID"));
			}
			
			for(int i = 0; i < ownerRole.size(); i++){
				getViewableReports.setString(1, ownerRole.get(i).toString());
				rs = getViewableReports.executeQuery();
			
			
				while(rs.next()){
					viewableReportIds.add(rs.getString("REPORT_ID").toString());
				}
			}
			
			
			//**Add those reports-ids that can be viewed-by-all...
			rs = getViewedByAllReportList.executeQuery();
						
			while(rs.next()){
				//**Add only if not added through the role description...
				if(!viewableReportIds.contains(rs.getString("REPORT_ID").toString())){
					viewableReportIds.add(rs.getString("REPORT_ID"));
				}
			}
			
			
			for(int cnt = 0; cnt < viewableReportIds.size(); cnt++){
				
				getReportList.setString(1, viewableReportIds.get(cnt).toString());
				rs = getReportList.executeQuery();
			
			
				while(rs.next()){
					//**Add to reportListObject
                    String repname = rs.getString("NAME");
//                    if (repname.equalsIgnoreCase(SoxicConstants.ALR)|| repname.equalsIgnoreCase(SoxicConstants.SLR)
//                    || repname.equalsIgnoreCase(SoxicConstants.CLR) || repname.equalsIgnoreCase(SoxicConstants.TR)
//                    || repname.equalsIgnoreCase(SoxicConstants.DR) || repname.equalsIgnoreCase(SoxicConstants.ADR)
//                    || repname.equalsIgnoreCase(SoxicConstants.SDR)){
//                        if
//                    }
					reportObj.setReportName(rs.getString("NAME"));
					reportObj.setReportDescription(rs.getString("DESCRIPTION"));
					reportObj.setReportLocation(rs.getString("LOCATION"));
                    reportObj.setReportType(rs.getString("TYPE"));
				}
				
				//**Add to reportListVector
				ReportList.add(reportObj);
				
				reportObj = new ReportListingObject();
			}	
			
			
		}
		catch(Exception ex){
			logger.fatal("Database connection from ReportList action " + ex.getMessage());
		}
		finally{
			try{
				if(con!=null && !con.isClosed()){
					con.close();
				}
			}catch(Exception e){
				
			}
		}
		reportListForm.setReportList(ReportList);
		
		
		return mapping.findForward("success");
	}

}