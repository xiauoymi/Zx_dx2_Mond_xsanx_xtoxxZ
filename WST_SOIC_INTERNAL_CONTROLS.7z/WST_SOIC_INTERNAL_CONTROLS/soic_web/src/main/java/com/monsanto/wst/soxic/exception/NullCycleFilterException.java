package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: tlgrif
 * Date: Aug 18, 2005
 * Time: 10:03:38 AM
 */

public class NullCycleFilterException extends Exception {
	public NullCycleFilterException(){
		super();
	}

	public NullCycleFilterException(Exception e){
		super(e);
	}
}