package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFacade;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.facade.QuestionAdminFacade;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 3:24:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuestionAdminDisplayAction extends Action {

    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response) {

        QuestionAdminForm questionAdminForm = (QuestionAdminForm)form;
        QuestionAdminFacade questionAdminFacade = new QuestionAdminFacade();

        questionAdminFacade.displayQuestions(questionAdminForm);

        return mapping.findForward("success");
    }


}
