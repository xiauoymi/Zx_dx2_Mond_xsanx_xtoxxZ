/*
 * Created on May 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.AdminDelinquentForm;
import com.monsanto.wst.soxic.form.ReportOptionsForm;
import com.monsanto.wst.soxic.model.DelinquentFacade;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class AdminDelinquentAction extends Action {
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		AdminDelinquentForm adminDelinquentForm = (AdminDelinquentForm)form;
		DelinquentFacade delinquentFacade = new DelinquentFacade();
//        ReportOptionsForm reportOptionsForm = (ReportOptionsForm) request.getSession().getAttribute("reportOptionsForm");
		adminDelinquentForm.setAllDelinquents(delinquentFacade.getDelinquents(adminDelinquentForm.getPeriodSelected()));
		return mapping.findForward("success");
	}
}