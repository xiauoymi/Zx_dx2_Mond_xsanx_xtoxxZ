/*
* Created on Mar 14, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.persistance;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.MiscUtils;
import com.monsanto.wst.soxic.util.DBUtils;
import com.monsanto.wst.soxic.facade.CycleOnlyConstants;

/**
 * @author SPOLAVA
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleAdminOwnerDAO {

    CycleOnlyAdminOwner cycleOnlyAdminOwner = new CycleOnlyAdminOwner();

//    CycleOnlyCertDAO cycleOnlyCertDAO = new CycleOnlyCertDAO();
//    private static final String OWNER_ACTIVITY = "ACTIVITY";
//    private static final String OWNER_SUBCYCLE = "SUBCYCLE";
//    private static final String ADMIN_ENTITY_DASH = "----";
//    Date currentDate = new Date(System.currentTimeMillis());
//    SimpleDateFormat sdf = new SimpleDateFormat(CycleOnlyConstants.DATE_FORMAT);

    public boolean isCycleOwner(Owner owner, List stateList) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT CS.CYCLE_ID FROM OWNER_CYCLE OC,CYCLE_STATE CS WHERE OC.OWNER_ID=? AND CS.CYCLE_ID=OC.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1, owner.getOwnerId());
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                return true;
            }

        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return false;
    }

    public boolean isSubCycleOwner(Owner owner, List stateList) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS WHERE OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=SC.SUB_CYCLE_ID AND SC.CYCLE_ID=CS.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1, owner.getOwnerId());
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                return true;
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return false;
    }

    public boolean isActivityOwner(Owner owner, List stateList) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM OWNER_CYCLE OC,CYCLE_STATE CS WHERE OC.OWNER_ID=? AND CS.CYCLE_ID=OC.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1, owner.getOwnerId());
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                return true;
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return false;
    }

    /**
     * @param userType       Type of user who logs in (Can be Admin ,Cycle or Sub cycle owner)
     * @param ownerId        Id of the person who logged in
     * @param levelToApplyTo
     * @param stateList
     * @return
     */
    public List getListToShow(String userType, String ownerId, String levelToApplyTo, List stateList, String strSelectedAction, String strItemOwnerId) {
        List modelList = new ArrayList();

        //if there is an itemOwner, must then only choose items owned by that owner
        if (strItemOwnerId != null) {

            if (userType.equalsIgnoreCase(SoxicConstants.ADMIN)) {
                //Select all sub cycles owned by strItemOwnerId
                addSubCyclesOwnedBySpecificOwnerForAdmin(stateList, modelList, ownerId, strItemOwnerId);
            }
            if (userType.equalsIgnoreCase(SoxicConstants.CYCLE)) {
                //Select all sub cycles for which person is a cycle owner and that are owned by strItemOwnerId
                addSubCyclesOwnedBySpecificOwnerForCycleOwners(stateList, modelList, ownerId, strItemOwnerId);

            }
            if (userType.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
                //Select all sub cycles for which person is a sub cycle owner and that are owned by strItemOwnerId
                addSubCyclesOwnedBySpecificOwnerForSubCycleOwners(stateList, modelList, ownerId, strItemOwnerId);
            }

        } else {

            if (userType.equalsIgnoreCase(SoxicConstants.ADMIN)) {
                //Select all sub cycles
                addSubCyclesForAdmin(stateList, modelList, ownerId);
//            //Select all cycles in period specified
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.CYCLE)){
//
//            }
//            //Select all sub cycles in period specified
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
//
//            }
//            //Select all activities in period specified
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
//
//            }
            }
            if (userType.equalsIgnoreCase(SoxicConstants.CYCLE)) {
                addSubCyclesForCycleOwners(stateList, modelList, ownerId);
                //Select all sub cycles for which person is a cycle owner
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.SUBCYCLE)){
//
//            }
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
//
//            }

            }
            if (userType.equalsIgnoreCase(SoxicConstants.SUBCYCLE)) {
                addSubCyclesForSubCycleOwners(stateList, modelList, ownerId);
                //Select all sub cycles for which person is a sub cycle owner
//            if(levelToApplyTo.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
//
//            }
            }
        }
        return modelList;

    }

    public void addSubCyclesForCycleOwners(List stateList, List subCycleList, String ownerid) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC,CYCLE_STATE CS,OWNER_CYCLE OC WHERE SC.CYCLE_ID =CS.CYCLE_ID AND OC.CYCLE_ID=SC.CYCLE_ID AND OC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1, ownerid);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }

    public void addSubCyclesOwnedBySpecificOwnerForCycleOwners(List stateList, List subCycleList, String ownerid, String strItemOwnerId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            String strsql = "select co.sub_cycle_id from " +
                    " ACTIVITY ACT, CTRL_OBJ CO, OWNER_ACTIVITY OA, CYCLE_STATE CS, SUB_CYCLE SC, OWNER_CYCLE OC  " +
                    " where" +
                    " SC.CYCLE_ID=CS.CYCLE_ID AND" +
                    " CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND" +
                    " ACT.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND" +
                    " OA.ACTIVITY_ID = ACT.ACTIVITY_ID AND" +
                    " OC.CYCLE_ID = SC.CYCLE_ID AND" +
                    " OA.owner_id=? AND " +
                    " OC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")";


            preparedStatement = connection.prepareStatement(strsql);
            preparedStatement.setString(1, strItemOwnerId);
            preparedStatement.setString(2, ownerid);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }

    public void addSubCyclesForAdmin(List stateList, List subCycleList, String ownerid) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC,CYCLE_STATE CS WHERE SC.CYCLE_ID =CS.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }

    public void addSubCyclesOwnedBySpecificOwnerForAdmin(List stateList, List subCycleList, String ownerid, String strItemOwnerId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            String strsql = "select co.sub_cycle_id from " +
                    "ACTIVITY ACT, CTRL_OBJ CO, OWNER_ACTIVITY OA, CYCLE_STATE CS, SUB_CYCLE SC " +
                    "where " +
                    "SC.CYCLE_ID=CS.CYCLE_ID AND " +
                    "CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
                    "ACT.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
                    "OA.ACTIVITY_ID = ACT.ACTIVITY_ID AND " +
                    "OA.owner_id=? AND (" + getStatePartOfQuery(stateList) + ")";

            preparedStatement = connection.prepareStatement(strsql);
            preparedStatement.setString(1, strItemOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }

    public void addSubCyclesForSubCycleOwners(List stateList, List subCycleList, String ownerid) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT SC.SUB_CYCLE_ID FROM SUB_CYCLE SC,CYCLE_STATE CS,OWNER_SUB_CYCLE OSC WHERE SC.CYCLE_ID =CS.CYCLE_ID AND OSC.OWNER_ID=? AND OSC.SUB_CYCLE_ID=SC.SUB_CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1, ownerid);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }


    public void addSubCyclesOwnedBySpecificOwnerForSubCycleOwners(List stateList, List subCycleList, String ownerid, String strItemOwnerId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();


            String strsql = "select co.sub_cycle_id from " +
                    "ACTIVITY ACT, CTRL_OBJ CO, OWNER_ACTIVITY OA, CYCLE_STATE CS, SUB_CYCLE SC, OWNER_SUB_CYCLE OSC " +
                    "where " +
                    "SC.CYCLE_ID=CS.CYCLE_ID AND " +
                    "CO.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
                    "OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND " +
                    "ACT.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
                    "OA.ACTIVITY_ID = ACT.ACTIVITY_ID AND " +
                    "OA.owner_id=? AND " +
                    "OSC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")";

            preparedStatement = connection.prepareStatement(strsql);
            preparedStatement.setString(1, strItemOwnerId);
            preparedStatement.setString(2, ownerid);

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycleList.add(rs.getString("SUB_CYCLE_ID"));
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
    }

    public List getControlObjectivesForMaintainence(String mode, String subCycleId, String oldOwner, String newOwner) {
        List controlObjectiveList = new ArrayList();
        if (mode.equalsIgnoreCase(SoxicConstants.ADD_OWNER)) {
            setControlObjectivesForAddMode(subCycleId, controlObjectiveList, newOwner);
        }
        return controlObjectiveList;
    }

    private void setControlObjectivesForAddMode(String subCycleId, List controlObjectiveList, String newOwner) {
        try {
            OracleSubCycleDAO subCycleDAO = (OracleSubCycleDAO) AbstractDAOFactory.getFactory().getSubCycleDAO();
            List controlObjectiveModelList = (List) subCycleDAO.getControlObjectives(subCycleId);
            Iterator iterator = controlObjectiveModelList.iterator();
            while (iterator.hasNext()) {
                ControlObjectiveNew controlObjectiveNew = (ControlObjectiveNew) iterator.next();
                controlObjectiveList.add(controlObjectiveNew.getControlObjectiveId());
            }
        } catch (Exception e) {

        }
    }

    protected void setControlObjectivesForRemoveMode(String subCycleId, List controlObjectiveList, String oldOwner) {

    }

    private void setControlObjectivesForCopyMode(String subCycleId, List controlObjectiveList, String oldOwner, String newOwner) {

    }

    private void setControlObjectivesForChangeMode(String subCycleId, List controlObjectiveList, String oldOwner, String newOwner) {

    }

    public static List getCycles(String user) throws DatabaseException, Exception {

        List cycles = new ArrayList();

        if (user != null && !user.equals("")) {
            String query = "SELECT CYCLE_ID FROM OWNER_CYCLE WHERE OWNER_ID='" + user + "'";
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = connection.prepareStatement(query);


                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    cycles.add(resultSet.getString("CYCLE_ID"));
                }

            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return cycles;

    }

    public static List getSubCycles(String user) throws DatabaseException, Exception {

        List subCycles = new ArrayList();

        if (user != null && !user.equals("")) {
            String query = "SELECT SUB_CYCLE_ID FROM OWNER_SUB_CYCLE WHERE OWNER_ID='" + user + "'";
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = connection.prepareStatement(query);


                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    subCycles.add(resultSet.getString("SUB_CYCLE_ID"));
                }

            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return subCycles;

    }

    public static List getActivities(String user) throws DatabaseException, Exception {

        List activities = new ArrayList();

        if (user != null && !user.equals("")) {
            String query = "SELECT ACTIVITY_ID FROM OWNER_ACTIVITY WHERE OWNER_ID='" + user + "' order by ACTIVITY_ID";
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = connection.prepareStatement(query);


                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    activities.add(resultSet.getString("ACTIVITY_ID"));
                }

            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return activities;

    }

    public static List getCyclePreviewChanges(List cycles, String user) throws DatabaseException, Exception {
        List cycleChanges = new ArrayList();

        if (cycles != null && !cycles.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = cycles.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String cycleId = (String) itr.next();

                    String query = "SELECT OWNER_ID, CYCLE_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_CYCLE WHERE CYCLE_ID = '" + cycleId + "' AND OWNER_ID = '" + user + "'";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("CYCLE");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setCycleId(resultSet.getString("CYCLE_ID"));
                        adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        cycleChanges.add(adminOwnerEntity);
                    }


                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return cycleChanges;
    }

    public static List getCyclePreviewChanges(List cycles) throws DatabaseException, Exception {
        List cycleChanges = new ArrayList();

        if (cycles != null && !cycles.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = cycles.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String cycleId = (String) itr.next();

                    String query = "SELECT OWNER_ID, CYCLE_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_CYCLE WHERE CYCLE_ID = '" + cycleId + "'";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("CYCLE");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setCycleId(resultSet.getString("CYCLE_ID"));
                        adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        cycleChanges.add(adminOwnerEntity);
                    }


                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return cycleChanges;
    }

    public static List getSubCyclePreviewChanges(List subCycles, String user) throws DatabaseException, Exception {
        List subCycleChanges = new ArrayList();

        if (subCycles != null && !subCycles.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = subCycles.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String subCycleId = (String) itr.next();

                    String query = "SELECT OWNER_ID, SUB_CYCLE_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID = '" + subCycleId + "' AND OWNER_ID = '" + user + "'";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("SUBCYCLE");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setSubCycleId(resultSet.getString("SUB_CYCLE_ID"));
                        adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        subCycleChanges.add(adminOwnerEntity);
                    }
                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return subCycleChanges;
    }

    public static List getSubCyclePreviewChanges(List subCycles) throws DatabaseException, Exception {
        List subCycleChanges = new ArrayList();

        if (subCycles != null && !subCycles.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = subCycles.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String subCycleId = (String) itr.next();

                    String query = "SELECT OWNER_ID, SUB_CYCLE_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_SUB_CYCLE WHERE SUB_CYCLE_ID = '" + subCycleId + "'";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("SUBCYCLE");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setSubCycleId(resultSet.getString("SUB_CYCLE_ID"));
                        adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        subCycleChanges.add(adminOwnerEntity);
                    }
                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return subCycleChanges;
    }

    public static List getActivityPreviewChanges(List activities, String user) throws DatabaseException, Exception {
        List activityChanges = new ArrayList();

        if (activities != null && !activities.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = activities.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String activityId = (String) itr.next();

                    String query = "SELECT OWNER_ID, ACTIVITY_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_ACTIVITY WHERE ACTIVITY_ID = '" + activityId + "' AND OWNER_ID = '" + user + "' order by ACTIVITY_ID";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("ACTIVITY");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setActivityId(resultSet.getString("ACTIVITY_ID"));
                        //adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStatus(SoxicConstants.GREEN_IMPORTED);
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        activityChanges.add(adminOwnerEntity);
                    }


                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return activityChanges;
    }

    public static List getActivityPreviewChanges(List activities) throws DatabaseException, Exception {
        List activityChanges = new ArrayList();

        if (activities != null && !activities.isEmpty()) {

            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            Iterator itr = activities.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String activityId = (String) itr.next();

                    String query = "SELECT OWNER_ID, ACTIVITY_ID, STATUS, START_DATE, DUE_DATE, COMPLETE_DATE," +
                            "MOD_DATE, MOD_USER  FROM OWNER_ACTIVITY WHERE ACTIVITY_ID = '" + activityId + "' order by ACTIVITY_ID";

                    preparedStatement = connection.prepareStatement(query);


                    resultSet = preparedStatement.executeQuery();
                    AdminOwnerEntity adminOwnerEntity = null;

                    while (resultSet.next()) {

                        adminOwnerEntity = new AdminOwnerEntity();
                        adminOwnerEntity.setType("ACTIVITY");
                        adminOwnerEntity.setOwnerId(resultSet.getString("OWNER_ID"));
                        adminOwnerEntity.setActivityId(resultSet.getString("ACTIVITY_ID"));
                        //adminOwnerEntity.setStatus(resultSet.getString("STATUS"));
                        adminOwnerEntity.setStatus(SoxicConstants.GREEN_IMPORTED);
                        adminOwnerEntity.setStartDate(resultSet.getDate("START_DATE"));
                        adminOwnerEntity.setDueDate(resultSet.getDate("DUE_DATE"));
                        adminOwnerEntity.setCompleteDate(resultSet.getDate("COMPLETE_DATE"));
                        adminOwnerEntity.setModDate(resultSet.getDate("MOD_DATE"));
                        adminOwnerEntity.setModUser(resultSet.getString("MOD_USER"));
                    }

                    if (adminOwnerEntity != null) {
                        activityChanges.add(adminOwnerEntity);
                    }


                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                    if (preparedStatement != null)
                        preparedStatement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
        }

        return activityChanges;
    }

    public void copyOwner(List changes) throws DatabaseException, Exception {

        if (changes != null && !changes.isEmpty()) {

            Connection connection = null;
            Statement statement = null;

            Iterator itr = changes.iterator();

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                while (itr.hasNext()) {

                    String query = buildCopyQuery((AdminOwnerEntity) itr.next());

                    statement = connection.createStatement();


                    statement.executeQuery(query);
                }
            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (statement != null)
                        statement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }

        }

    }

    public void deleteOwnerCycle(Cycle cycle, AdminOwnerEntity entity) throws Exception{
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet rs = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            String query = "delete from owner_cycle " +
                    " where cycle_id = ? and owner_id = ? ";
            statement = connection.prepareStatement(query);
            statement.setString(1,cycle.getCycleId());
            statement.setString(2,entity.getOwnerId());

            System.out.println("query:" + query);
            System.out.println("cycleId:" + cycle.getCycleId() + " ownerId: " + entity.getOwnerId());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }
    }

    public void setOwnerCycle(Cycle cycle, String user, AdminOwnerEntity entity) throws Exception{
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet rs = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            String query = "insert into owner_cycle " +
                    " (CYCLE_ID,OWNER_ID,STATUS,START_DATE,DUE_DATE,COMPLETE_DATE,POTENTIAL_GAP,MOD_DATE,MOD_USER,SIGNIFICANT_CHANGE_ID) " +
                    " values (?,?,?,?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(query);
            statement.setString(1,cycle.getCycleId());
            statement.setString(2,user);
            statement.setString(3,cycle.getStatus());
            statement.setDate(4, cycle.getStartDate() != null ? new Date(cycle.getStartDate().getTime()) : null);
            statement.setDate(5, cycle.getDueDateAsDate() != null ? new Date(cycle.getDueDateAsDate().getTime()) : null);
            statement.setDate(6, cycle.getCompletionDate() != null ? new Date(cycle.getCompletionDate().getTime()) : null);
            statement.setString(7, cycle.getGap());
            statement.setDate(8,entity.getModDate());
            statement.setString(9, entity.getModUser());
            statement.setString(10,cycle.getSignificantStatus());

            System.out.println("query:" + query);
            System.out.println("cycleId: " + cycle.getCycleId() + " user: " + user + " modUser: " + entity.getModUser());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }        
    }

    public Cycle getOwnerCycle(AdminOwnerEntity entity) throws Exception{
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet rs = null;
        Cycle cycle = null;

        try {
            if (entity.getType().equals("CYCLE")) {
                connection = SoxicConnectionFactory.getSoxicConnection();

                String query = "select * from owner_cycle " +
                        " where owner_id = ? and cycle_id = ?";
                statement = connection.prepareStatement(query);
                statement.setString(1,entity.getOwnerId());
                statement.setString(2,entity.getCycleId());
                rs = statement.executeQuery();
                if(rs.next()) {
                    cycle = new Cycle();
                    cycle.setCycleId(rs.getString("CYCLE_ID"));
                    cycle.setOwnerId(rs.getString("OWNER_ID"));
                    cycle.setStatus(rs.getString("STATUS"));
                    cycle.setStartDate(rs.getDate("START_DATE"));
                    cycle.setDueDate(rs.getDate("DUE_DATE"));
                    cycle.setCompletionDate(rs.getDate("COMPLETE_DATE"));
                    cycle.setGap(rs.getString("POTENTIAL_GAP"));
        //          rs.getString("MOD_DATE");
        //          rs.getString("MOD_USER");
                    cycle.setSignificantStatus(rs.getString("SIGNIFICANT_CHANGE_ID"));

                }
            }

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }
        return cycle;
    }

    public void changeOwner(AdminOwnerEntity entity, String user) throws DatabaseException, Exception {

            Connection connection = null;
            Statement statement = null;

            try {
                connection = SoxicConnectionFactory.getSoxicConnection();

                String query = buildUpdateQuery(entity , user);
                statement = connection.createStatement();
                statement.executeQuery(query);

            } catch (SQLException e) {
                throw new DatabaseException(e.getMessage());
            } catch (Exception e) {
                throw new DatabaseException(e.getMessage());
            } finally {
                try {
                    if (statement != null)
                        statement.close();
                    if (connection != null)
                        connection.close();
                } catch (SQLException e) {
                    throw new DatabaseException("OracleDAO - Unable to close database connection : "
                            + e.toString());
                }
            }
    }

    
    public void deleteOwner(AdminOwnerEntity entity) throws DatabaseException, Exception {
        Connection connection = null;
        Statement statement = null;

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            String query = buildDeleteQuery(entity);
            statement = connection.createStatement();
            statement.executeQuery(query);

        } catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                        + e.toString());
            }
        }
    }
  
    private String buildCopyQuery(AdminOwnerEntity entity) {

        String period = "";

        StringBuffer query = new StringBuffer();

        query.append("INSERT into ");

        query.append(getTableName(entity) + "(");

        query.append("OWNER_ID, ");
        query.append(getIdType(entity) + ", ");
        query.append("STATUS ,");

        if (entity.getStartDate() != null) {
            query.append("START_DATE ,");
        }

        if (entity.getDueDate() != null) {
            query.append("DUE_DATE ,");
        }

        if (entity.getCompleteDate() != null) {
            query.append("COMPLETE_DATE ,");
        }

        if (entity.getModDate() != null) {
            query.append("MOD_DATE ,");
        }
        query.append("MOD_USER )");

        query.append(" VALUES (");

        query.append("'" + entity.getOwnerId() + "', ");
        query.append("'" + getId(entity) + "', ");
        //query.append("'" + entity.getStatus()        + "', ");

        String ownerStatus = cycleOnlyAdminOwner.setCorrectStatusWhenUpdatingOwner(entity, period);
        query.append("'" + ownerStatus + "', ");


        if (entity.getStartDate() != null) {
            query.append("to_date ('"
                    + new SimpleDateFormat("MM/dd/yyyy").format(entity.getStartDate())
                    + "', 'MM/dd/yyyy'), ");
        }

        if (entity.getDueDate() != null) {
            query.append("to_date ('"
                    + new SimpleDateFormat("MM/dd/yyyy").format(entity.getDueDate())
                    + "', 'MM/dd/yyyy'), ");
        }

        if (entity.getCompleteDate() != null) {
//             query.append("to_date ('"
//    					+ new SimpleDateFormat("MM/dd/yyyy").format(entity.getCompleteDate())
//    					+ "', 'MM/dd/yyyy'), ");
            query.append("'', ");
        }

        if (entity.getModDate() != null) {
            query.append("to_date ('"
                    + new SimpleDateFormat("MM/dd/yyyy").format(entity.getModDate())
                    + "', 'MM/dd/yyyy'), ");
        }

        query.append("'" + entity.getModUser() + "' )");



        createOwnerResponsesBasedOnType(entity, period, entity.getOwnerId(), CycleOnlyConstants.COPY_OWNER);        

        return query.toString();

    }

    private String buildUpdateQuery(AdminOwnerEntity entity, String user) {

        String period = "";

        StringBuffer query = new StringBuffer();

        query.append("UPDATE ");
        query.append(getTableName(entity));
        query.append(" SET ");
        query.append(" OWNER_ID ='" + user + "'");
        query.append(" WHERE ");

        query.append(" OWNER_ID = '" + entity.getOwnerId() + "'");
        query.append(" AND " + getIdType(entity) + "='" + getId(entity) + "'");

        

        createOwnerResponsesBasedOnType(entity, period, user, CycleOnlyConstants.CHANGE_OWNER);

        return query.toString();

    }

    private void createOwnerResponsesBasedOnType(AdminOwnerEntity entity, String period, String user, String ownerAction) {
        cycleOnlyAdminOwner.insertOwnerResponseEntriesIfRequired(entity, period, user, ownerAction);
    }


    private static String buildDeleteQuery(AdminOwnerEntity entity) {

        StringBuffer query = new StringBuffer();

        query.append("DELETE  FROM ");
        query.append(getTableName(entity));

        query.append(" WHERE ");

        query.append(" OWNER_ID = '" + entity.getOwnerId() + "'");
        query.append(" AND " + getIdType(entity) + "='" + getId(entity) + "'");



        return query.toString();

    }


    private static String getTableName(AdminOwnerEntity entity) {

        String tableName = "";
        if (entity.getType().equals("CYCLE"))
            tableName = "OWNER_CYCLE";
        else if (entity.getType().equals("SUBCYCLE"))
            tableName = "OWNER_SUB_CYCLE";
        else if (entity.getType().equals("ACTIVITY"))
            tableName = "OWNER_ACTIVITY";

        return tableName;
    }

    private static String getIdType(AdminOwnerEntity entity) {

        String idType = "";
        if (entity.getType().equals("CYCLE"))
            idType = "CYCLE_ID";
        else if (entity.getType().equals("SUBCYCLE"))
            idType = "SUB_CYCLE_ID";
        else if (entity.getType().equals("ACTIVITY"))
            idType = "ACTIVITY_ID";

        return idType;
    }

    private static String getId(AdminOwnerEntity entity) {

        String id = "";
        if (entity.getType().equals("CYCLE"))
            id = entity.getCycleId();
        else if (entity.getType().equals("SUBCYCLE"))
            id = entity.getSubCycleId();
        else if (entity.getType().equals("ACTIVITY"))
            id = entity.getActivityId();

        return id;
    }

    private String getStatePartOfQuery(List stateList) {
        String query = "";
        Iterator iterator = stateList.iterator();

        while (iterator.hasNext()) {
            if (query.length() == 0) {
                query = query + " CS.STATE='" + iterator.next() + "'";
            } else {
                query = query + " OR CS.STATE='" + iterator.next() + "'";
            }

        }
        return query;
    }

    public List getCyclesInPeriodforAdmin(List stateList) {
        List cycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        Cycle cycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC,CYCLE_STATE CS WHERE OC.CYCLE_ID=CS.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            // preparedStatement.setString(1,o);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cycle = new Cycle();
                cycle.setCycleId(rs.getString("CYCLE_ID"));
                cycle.setOwnerId(rs.getString("OWNER_ID"));
                cycleList.add(cycle);
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return cycleList;

    }





    public List getCyclesInPeriodforCycleOwner(List stateList, String strCycleOwnerId) {
        List cycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        Cycle cycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC,CYCLE_STATE CS WHERE OC.CYCLE_ID=CS.CYCLE_ID AND OC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1,strCycleOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cycle = new Cycle();
                cycle.setCycleId(rs.getString("CYCLE_ID"));
                cycle.setOwnerId(rs.getString("OWNER_ID"));
                cycleList.add(cycle);
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return cycleList;

    }


    public List getCyclesInPeriodforCycleOwnerBySpecificOwner(List stateList, String strCycleOwnerId, String strSpecificOwnerId) {
        List cycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        Cycle cycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC,CYCLE_STATE CS WHERE OC.CYCLE_ID=CS.CYCLE_ID AND OC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1,strCycleOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cycle = new Cycle();
                cycle.setCycleId(rs.getString("CYCLE_ID"));
                cycle.setOwnerId(rs.getString("OWNER_ID"));
                cycleList.add(cycle);
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return cycleList;

    }



    public List getCyclesInPeriodforSubCycleOwner(List stateList, String strCycleOwnerId) {
        List cycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        Cycle cycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OC.CYCLE_ID,OC.OWNER_ID FROM OWNER_CYCLE OC,CYCLE_STATE CS, OWNER_SUB_CYCLE OSC, SUB_CYCLE SC WHERE OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND SC.CYCLE_ID = OC.CYCLE_ID AND OC.CYCLE_ID=CS.CYCLE_ID AND OSC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1,strCycleOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                cycle = new Cycle();
                cycle.setCycleId(rs.getString("CYCLE_ID"));
                cycle.setOwnerId(rs.getString("OWNER_ID"));
                cycleList.add(cycle);
            }


        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return cycleList;

    }

    public List getSubCyclesInPeriodforAdmin(List stateList) {
        List subCycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        SubCycle subCycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS WHERE OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND SC.CYCLE_ID =  CS.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycle = new SubCycle();
                subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
                subCycle.setOwnerId(rs.getString("OWNER_ID"));
                subCycleList.add(subCycle);
            }

        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return subCycleList;

    }


    public List getSubCyclesInPeriodforSubCycleOwner(List stateList, String strSubCycleOwnerId) {
        List subCycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        SubCycle subCycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS WHERE OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND SC.CYCLE_ID =  CS.CYCLE_ID AND OSC.OWNER_ID=? AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1,strSubCycleOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycle = new SubCycle();
                subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
                subCycle.setOwnerId(rs.getString("OWNER_ID"));
                subCycleList.add(subCycle);
            }

        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return subCycleList;

    }

    public List getSubCyclesInPeriodforCycleOwner(List stateList, String strCycleOwnerId) {
        List subCycleList = new ArrayList();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        SubCycle subCycle = null;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();

            preparedStatement = connection.prepareStatement("SELECT OSC.SUB_CYCLE_ID,OSC.OWNER_ID FROM OWNER_SUB_CYCLE OSC,SUB_CYCLE SC,CYCLE_STATE CS, OWNER_CYCLE OC WHERE OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID AND OC.CYCLE_ID = SC.CYCLE_ID AND OC.OWNER_ID =? AND SC.CYCLE_ID =  CS.CYCLE_ID AND (" + getStatePartOfQuery(stateList) + ")");
            preparedStatement.setString(1,strCycleOwnerId);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                subCycle = new SubCycle();
                subCycle.setSubCycleId(rs.getString("SUB_CYCLE_ID"));
                subCycle.setOwnerId(rs.getString("OWNER_ID"));
                subCycleList.add(subCycle);
            }

        } catch (SQLException e) {
            //throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // throw new DatabaseException(e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                //                throw new DatabaseException("OracleDAO - Unable to close database connection : "
                //                        + e.toString());
            }
        }
        return subCycleList;

    }

}
