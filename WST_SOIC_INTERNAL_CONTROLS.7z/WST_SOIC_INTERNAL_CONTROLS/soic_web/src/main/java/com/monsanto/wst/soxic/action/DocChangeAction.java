package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.CycleManageFacade;
import com.monsanto.wst.soxic.form.DocChangeForm;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jul 26, 2005
 * Time: 10:50:24 AM
 *
 * This class contains methods to retrieve the country List, and another
 * method to populate the CycleMaintainObjectList with the first cycle.  
 */

public class DocChangeAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception {

        DocChangeForm dochangeform = (DocChangeForm)form;
        dochangeform.setSelectedCountry(null);
        CycleManageFacade cycleManageFacade = new CycleManageFacade();

        cycleManageFacade.getCountryforCycles(dochangeform);

                List countries = dochangeform.getCountry();
                String countrysel = String.valueOf(countries.get(0));

                cycleManageFacade.createCycleMaintainObjectList(dochangeform,countrysel);

        return mapping.findForward("dochangecountrylist");
    }
}

