//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/** 
 * MyEclipse Struts
 * Creation date: 03-11-2005
 * 
 * XDoclet definition:
 * @struts:form name="activityReportForm"
 */
public class ActivityReportForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	private String cyclesSelected[];

	private String countriesSelected[];
	
	private Vector cyclesList = new Vector();
	
	private Vector countriesList = new Vector();
	
	private String periodID; 
	
	private Vector cycleIDs = new Vector();
	
	private Vector cycleVector = new Vector();
	
	// --------------------------------------------------------- Methods
	
	
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		
		if(periodID == null || periodID.equals("")){
			errors.add("periodID2", new ActionError("errors.activityReport.periodID.null"));
			
			return errors;
		}
		
		if(countriesSelected == null || countriesSelected.length == 0){
			errors.add("countriesSelected2", new ActionError("errors.activityReport.countriesSelected.null"));
			
			return errors;
		}
		
		if(cyclesSelected == null || cyclesSelected.length == 0){
			errors.add("cyclesSelected2", new ActionError("errors.activityReport.cyclesSelected.null"));
			
		}
		
		
		
		return errors;
	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

	/**
	 * @return Returns the countriesSelected.
	 */
	public String[] getCountriesSelected() {
		return countriesSelected;
	}
	/**
	 * @param countriesSelected The countriesSelected to set.
	 */
	public void setCountriesSelected(String[] countriesSelected) {
		this.countriesSelected = countriesSelected;
	}
	/**
	 * @return Returns the cyclesSelected.
	 */
	public String[] getCyclesSelected() {
		return cyclesSelected;
	}
	/**
	 * @param cyclesSelected The cyclesSelected to set.
	 */
	public void setCyclesSelected(String[] cyclesSelected) {
		this.cyclesSelected = cyclesSelected;
	}
	
	/**
	 * @return Returns the countriesList.
	 */
	public Vector getCountriesList() {
		return countriesList;
	}
	/**
	 * @param countriesList The countriesList to set.
	 */
	public void setCountriesList(Vector countriesList) {
		this.countriesList = countriesList;
	}
	/**
	 * @return Returns the cyclesList.
	 */
	public Vector getCyclesList() {
		return cyclesList;
	}
	/**
	 * @param cyclesList The cyclesList to set.
	 */
	public void setCyclesList(Vector cyclesList) {
		this.cyclesList = cyclesList;
	}
	
	
	/**
	 * @return Returns the periodID.
	 */
	public String getPeriodID() {
		return periodID;
	}
	/**
	 * @param periodID The periodID to set.
	 */
	public void setPeriodID(String periodID) {
		this.periodID = periodID;
	}
	
	
	/**
	 * @return Returns the cycleIDs.
	 */
	public Vector getCycleIDs() {
		return cycleIDs;
	}
	/**
	 * @param cycleIDs The cycleIDs to set.
	 */
	public void setCycleIDs(Vector cycleIDs) {
		this.cycleIDs = cycleIDs;
	}
	
	
	/**
	 * @return Returns the cycleVector.
	 */
	public Vector getCycleVector() {
		return cycleVector;
	}
	/**
	 * @param cycleVector The cycleVector to set.
	 */
	public void setCycleVector(Vector cycleVector) {
		this.cycleVector = cycleVector;
	}
}