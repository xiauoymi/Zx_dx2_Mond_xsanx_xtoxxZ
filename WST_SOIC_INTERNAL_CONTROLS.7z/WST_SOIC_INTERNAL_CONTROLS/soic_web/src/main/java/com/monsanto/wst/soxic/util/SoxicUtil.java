/*
* Created on Jan 28, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.ResourceBundle;

/**
 * @author SPOLAVA
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class SoxicUtil {

    public static final String NBSP = "&nbsp;";

    /**
     * This method trims the inputted string. After trimming, if the inputed
     * string is empty, it returns "&nbsp". If the inputted string is not empty,
     * it returns the inputted string
     *
     *
     * @return String inputted String - If the inputted string is not empty
     *         "&nbsp" - If the inputted string is empty
     */

    public static String emptyToNbsp(String in) {
        if (in != null && in.trim().length() > 0)
            return in;
        return SoxicUtil.NBSP;
    }

    /**
     * This method trims the inputted string. After trimming, if the inputed
     * string is empty, it returns true. If the inputted string is not empty, it
     * returns false
     *
     *
     * @return boolean true - If the inputted string is empty false - If the
     *         inputted string is not empty
     */

    public static boolean isEmpty(String string) {

        if (string != null && string.trim().length() > 0)
            return false;
        return true;

    }

    public static String nullToEmpty(String str) {
        return nullToDefault(str, "");
    }

    /**
     * If the inputed string is not null, it returns the inputted string If the
     * string is null, it returns the inputted default Value
     *
     *
     * @return String inputted String - If the inputted string is not empty
     *         inputted default Value - If the inputted string is empty
     */
    public static String nullToDefault(String str, String defaultValue) {
        if (str == null) {
            return defaultValue;
        }
        return str;
    }

    /**
     * This method takes a string as input, character to be replaced in the
     * inputted string and a string to replace the character. If the inputed
     * string has the character to be replaced, this method replaces the
     * character with the string to replace. If the inputted string doesn't have
     * any character to be replaced, it just returns the inputted string,
     * without doing any modifications.
     *
     *
     * @return String - Inputted string, with all characters to be replaced,
     *         replaced with string to replace
     *
     */

    public static String replaceAll(String input, char toReplace,
                                    String replaceWith) {

        if (input == null || input.indexOf(toReplace) < 0)
            return input;

        int inputLength = input.length();
        StringBuffer result = new StringBuffer(input.length() * 2);

        for (int i = 0; i < inputLength; i++) {

            if (input.charAt(i) == toReplace) {
                result = result.append(replaceWith);
            } else
                result = result.append(input.charAt(i));
        }
        return result.toString();

    }

    public static String replaceQuotes(String input) {
        return replaceAll(input, '\'', "''");
    }

    public static boolean containsSingleQuotes(String input) {
        return (input.indexOf("'") >= 0);
    }

    /**
     * This method takes a due date as String argument. Based on the due date
     * The string that has to preceed the status is returned
     *
     *
     * @return String - "R_" ,"Y_" ,"G_"
     */
    public static String returnStatusPreceedingStr(String date) {

        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

        Date dueDate = null;

        try {
            dueDate = df.parse(date);
        } catch (ParseException ex) {

        }

        return returnStatusPreceedingStr(dueDate);
        //		Date currentDate = new Date(System.currentTimeMillis());
        //
        //		Long yellowValue = new Long(SoxicUtil.getRedPeriod());
        //
        //		Long redValue = new Long(SoxicUtil.getYellowPeriod());
        //
        //		Date yellowDate = new Date(System.currentTimeMillis()
        //				+ (yellowValue.longValue() * 24 * 60 * 60 * 1000));
        //
        //		Date redDate = new Date(System.currentTimeMillis()
        //				+ (redValue.longValue() * 24 * 60 * 60 * 1000));
        //
        //		boolean valueone = dueDate.before(yellowDate);
        //
        //		boolean valuetwo = dueDate.before(redDate);
        //
        //		if (dueDate.before(yellowDate)) {
        //			return "R_";
        //		} else {
        //			if (dueDate.before(redDate) && dueDate.after(yellowDate)) {
        //				return "Y_";
        //			}
        //
        //			if (dueDate.after(redDate)) {
        //				return "G_";
        //			}
        //		}
        //		return "G_";

    }

    /**
     * This method takes a due date as Date argument. Based on the due date The
     * string that has to preceed the status is returned
     *
     *
     * @return String - "R_" ,"Y_" ,"G_"
     */
    public static String returnStatusPreceedingStr(Date dueDate) {

        Date currentDate = new Date(System.currentTimeMillis());

        Long yellowValue = new Long(SoxicUtil.getRedPeriod());

        Long redValue = new Long(SoxicUtil.getYellowPeriod());

        Date yellowDate = new Date(System.currentTimeMillis()
                + (yellowValue.longValue() * 24 * 60 * 60 * 1000));

        Date redDate = new Date(System.currentTimeMillis()
                + (redValue.longValue() * 24 * 60 * 60 * 1000));

        boolean valueone = dueDate.before(yellowDate);

        boolean valuetwo = dueDate.before(redDate);

        if (dueDate.before(yellowDate)) {
            return "R_";
        } else {
            if (dueDate.before(redDate) && dueDate.after(yellowDate)) {
                return "Y_";
            }

            if (dueDate.after(redDate)) {
                return "G_";
            }
        }
        return "G_";

    }

    /**
     * This method returns the site owner's name
     *
     *
     * @return String - days as a String
     */
    public static String getSiteOwnerName() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("siteowner.name");
    }

    /**
     * This method returns the site owner's e-mail address
     *
     *
     * @return String - days as a String
     */
    public static String getSiteOwnerEMail() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("siteowner.email");
    }

    public static String getSiteOwnerPhone() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("siteowner.phone");
    }

    public static String getSiteInternalControlName() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("site.internal.control.name");
    }

    public static String getSiteInternalControlEmail() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("site.internal.control.email");
    }

    public static String getSiteInternalControlPhone() {
        ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
        return resources.getString("site.internal.control.phone");
    }

  /**
   * This method returns the build number
   * @return
   */
    public static String getBuildNumber() {
      ResourceBundle resources = ResourceBundle.getBundle(SoxicConstants.SOXIC_APP_RES_FILE);
      return resources.getString("sox.buildNumber");
    }
    /**
     * This method returns the number of days for yellow status
     *
     *
     * @return String - days as a String
     */
    public static String getYellowPeriod() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.YELLOWPERIOD);
    }

    /**
     * This method returns the number of days for red status
     *
     *
     * @return String - days as a String
     */
    public static String getRedPeriod() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.REDPERIOD);
    }

    /**
     * This method returns the smtp server name from property file
     *
     *
     * @return String - days as a String
     */
    public static String getSmtpServerName() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.SMTPSERVER);
    }

    /**
     * This method returns the connection string to Oracle DB from test server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleTestServerConnectionString() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources
                .getString(SoxicConstants.ORACLE_TEST_SERVER_CONNECTION);
    }

    /**
     * This method returns the connection string to Oracle DB from test server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleProductionServerConnectionString() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources
                .getString(SoxicConstants.ORACLE_PRODUCTION_SERVER_CONNECTION);
    }

    /**
     * This method returns the username to Oracle DB from test server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleTestServerUserName() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_TEST_USERNAME);
    }

    /**
     * This method returns the username to Oracle DB from production server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleProductionServerUserName() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_PRODUCTION_USERNAME);
    }

    /**
     * This method returns the pwd to Oracle DB from test server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleTestServerPwd() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_TEST_PWD);
    }

    /**
     * This method returns the connection string to Oracle DB from dev server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleDevServerConnectionString() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources
                .getString(SoxicConstants.ORACLE_DEV_SERVER_CONNECTION);
    }
    /**
     * This method returns the connection string to Oracle DB for unit testing.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleUnitTestServerConnectionString() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources
                .getString(SoxicConstants.ORACLE_UNIT_SERVER_CONNECTION);
    }

    /**
     * This method returns the username to Oracle DB from dev server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleDevServerUserName() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_DEV_USERNAME);
    }
    /**
     * This method returns the username to Oracle DB for Unit Testing.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleUnitTestServerUserName() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_UNIT_TEST_USERNAME);
    }

    /**
     * This method returns the pwd to Oracle DB from dev server.
     *
     *
     * @return String - days as a String
     */
    public static String getOracleDevServerPwd() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString(SoxicConstants.ORACLE_DEV_PWD);
    }

    /**
     * This method returns the number of days for red status
     *
     *
     * @return String - days as a String
     */
    public static boolean isPasswordEncrypted() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        boolean isPwdEncrypted = new Boolean(myResources
                .getString(SoxicConstants.PASSWORDENC)).booleanValue();
        return isPwdEncrypted;
    }

    /**
     * This method returns the number of days for red status
     *
     *
     * @return String - days as a String
     */
    public static boolean toSendEmail() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        boolean toSend = new Boolean(myResources
                .getString(SoxicConstants.SENDEMAIL)).booleanValue();
        return toSend;
    }

    /**
     * This method returns query with the name passed in
     *
     *
     * @return String - days as a String
     */
    public static String getQuery(String name) {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPQUERYFILE);
        return myResources.getString(name);
    }

    /**
     * This method returns security variable based on deployment
     *
     *
     * @return String - days as a String
     */
    public static String getSecurityApplicationFolder() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localdev")) {
            return myResources.getString(SoxicConstants.SECFOLLOCALDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localtest")) {
            return myResources.getString(SoxicConstants.SECFOLLOCALTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverdev")) {
            return myResources.getString(SoxicConstants.SECFOLSEVDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "servertest")) {
            return myResources.getString(SoxicConstants.SECFOLSEVTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverprod")) {
            return myResources.getString(SoxicConstants.SECFOLSEVPROD);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localprod")) {
            return myResources.getString(SoxicConstants.SECFOLLOCALPROD);
        }

        return myResources.getString(SoxicConstants.SECFOLLOCALDEV);
    }

    /**
     * This method returns Enviroment variable based on deployment
     *
     *
     * @return String - days as a String
     */
    public static String getEnvironmentVariable() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localdev")) {
            return myResources.getString(SoxicConstants.SECENVLOCALDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localtest")) {
            return myResources.getString(SoxicConstants.SECENVLOCALTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverdev")) {
            return myResources.getString(SoxicConstants.SECENVSEVDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "servertest")) {
            return myResources.getString(SoxicConstants.SECENVSEVTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverprod")) {
            return myResources.getString(SoxicConstants.SECENVSEVPROD);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localprod")) {
            return myResources.getString(SoxicConstants.SECENVLOCALPROD);
        }
        return "";
    }

    /**
     * Method returns the display status based on status passed in
     *
     * @param currentStatus
     * @return "INPROCESS" or "IMPORTED" or "NOT STARTED" or "NOT KNOWN" or
     *         "COMPLETE"
     */
    public static String getDisplayStatus(String currentStatus) {
        if (currentStatus.equalsIgnoreCase(SoxicConstants.YELLOW_INPROCESS)
                || currentStatus.equalsIgnoreCase(SoxicConstants.RED_INPROCESS)
                || currentStatus
                .equalsIgnoreCase(SoxicConstants.GREEN_INPROCESS)) {
            return "INPROCESS";
        }
        if (currentStatus.equalsIgnoreCase(SoxicConstants.YELLOW_IMPORTED)
                || currentStatus.equalsIgnoreCase(SoxicConstants.RED_IMPORTED)
                || currentStatus
                .equalsIgnoreCase(SoxicConstants.GREEN_IMPORTED)
                || currentStatus.equalsIgnoreCase(SoxicConstants.IMPORTED)) {
            return "NOT STARTED";
        }
        if (currentStatus.equalsIgnoreCase(SoxicConstants.YELLOW_NOTSTARTED)
                || currentStatus
                .equalsIgnoreCase(SoxicConstants.RED_NOTSTARTED)
                || currentStatus
                .equalsIgnoreCase(SoxicConstants.GREEN_NOTSTARTED)) {
            return "NOT STARTED";
        }
        if (currentStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)) {
            return "COMPLETE";
        }
        return "NOT KNOWN";
    }

    /**
     * This method returns security variable based on deployment
     *
     *
     * @return String - days as a String
     */
    public static String getHomeLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localdev")) {
            return myResources.getString(SoxicConstants.HOMELINKLOCALDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localtest")) {
            return myResources.getString(SoxicConstants.HOMELINKLOCALTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverdev")) {
            return myResources.getString(SoxicConstants.HOMELINKSEVDEV);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "servertest")) {
            return myResources.getString(SoxicConstants.HOMELINKSEVTEST);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverprod")) {
            return myResources.getString(SoxicConstants.HOMELINKSEVPROD);
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localprod")) {
            return myResources.getString(SoxicConstants.HOMELINKSEVPROD);
        }

        return myResources.getString(SoxicConstants.SECFOLLOCALDEV);
    }

    /**
     * This method returns security variable based on deployment
     *
     *
     * @return String - days as a String
     */
    public static String getImageLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localdev")) {
            return myResources.getString("site.image.link.dev.local");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localtest")) {
            return myResources.getString("site.image.link.test.local");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverdev")) {
            return myResources.getString("site.image.link.dev.server");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "servertest")) {
            return myResources.getString("site.image.link.test.server");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverprod")) {
            return myResources.getString("site.image.link.prod.server");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localprod")) {
            return myResources.getString("site.image.link.prod.local");
        }

        return myResources.getString(SoxicConstants.SECFOLLOCALDEV);
    }

    public static boolean isStatusComplete(String statusString) {
        if (statusString.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)) {
            return true;
        }
        return false;

    }

    public static String getFromEmailAddress() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("fromaddress");
    }

    public static String getSeperator() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        String sep = myResources.getString("seperator");
        return myResources.getString("seperator");
    }

    public static String getSaveIndicator() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        String saveIndicator = myResources.getString("showsave");
        return saveIndicator;
    }

    public static String getCountryCode(String countryId) {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        String countryCode = myResources.getString(countryId);
        return countryCode;
    }

    public static String getActivityHelpVideoLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("help.video.link.activity");
    }

    public static String getSubCycleHelpVideoLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("help.video.link.subcycle");
    }

    public static String getCycleHelpVideoLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("help.video.link.cycle");
    }

    public static String getGapHelpVideoLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("help.video.link.gap");
    }

    public static String getSecurityHelpDocumentLink() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "localdev")) {
            return myResources.getString("security.help.document.link.local");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverdev")) {
            return myResources.getString("security.help.document.link.dev");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "servertest")) {
            return myResources.getString("security.help.document.link.test");
        }
        if (myResources.getString("environment.deploy").equalsIgnoreCase(
                "serverprod")) {
            return myResources.getString("security.help.document.link.prod");
        }

        return "";
    }

    public static boolean isUnitTest() {
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        boolean unitTest = new Boolean(myResources
                .getString("unittesting")).booleanValue();
        return unitTest;
    }

    public static String getPastDueSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("pastdue.email.subject");
    }

    public static String getAddOwnerSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("addowner.subject");
    }

    public static String getRemoveOwnerSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("removeowner.subject");
    }

    public static String getCertificationStartSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("certification.start.email.subject");
    }

    public static String getCertificationChangeStatusSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("certification.changestatus.email.subject");
    }

    public static String getCertificationCompletionSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("certification.completion.email.subject");
    }

    public static String getDocChangeStartSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("dochange.released.email.subject");
    }

    public static String getDocChangeClosureSubject(){
        ResourceBundle myResources = ResourceBundle
                .getBundle(SoxicConstants.SOXICPROPERTYFILE);
        return myResources.getString("dochange.closed.email.subject");
    }

    public static Date getDayBeforeToday() {
        //To change body of created methods use File | Settings | File Templates.
       Date yesterday = new Date(System.currentTimeMillis()-24*60*60*1000);
       return yesterday;
    }

    public static boolean isYesterday(Date yesterday){
        Date today = new Date(System.currentTimeMillis());
        if((today.getDate()-1==yesterday.getDate()) && (today.getMonth()== yesterday.getMonth()) && (today.getYear()==yesterday.getYear())){
            return true;
        }
        return false;

    }

    public static long getTimeDifference(long endTime, long startTime) {
        long dif;
        dif = endTime-startTime;
        return dif;
    }


}