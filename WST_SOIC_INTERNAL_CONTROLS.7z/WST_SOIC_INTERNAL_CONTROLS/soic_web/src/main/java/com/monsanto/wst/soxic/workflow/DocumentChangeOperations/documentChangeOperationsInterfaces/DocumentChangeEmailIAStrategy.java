package com.monsanto.wst.soxic.workflow.DocumentChangeOperations.documentChangeOperationsInterfaces;

import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.workflow.DocumentChangeOperations.DocumentChangeRequestResponseListInt;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 4:38:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeEmailIAStrategy implements DocumentChangeEmailStrategy{

    public void processRequestResponseObjects(DocumentChangeRequestResponseListInt documentChangeRequestResponseListInt){

        Iterator iterator =documentChangeRequestResponseListInt.getDocumentChangeRequestResponseList().iterator();
        List tempList = new ArrayList();

        while(iterator.hasNext()){
            OwnerChangeRequestResponse ownerChangeRequestResponse = (OwnerChangeRequestResponse)iterator.next();
            if(SoxicUtil.isYesterday(ownerChangeRequestResponse.getResponseDate()) && (ownerChangeRequestResponse.getResponseType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE)) &&  (ownerChangeRequestResponse.getApproved().equalsIgnoreCase(OwnerChangeRequestResponse.APPROVE_RESPONSE))){
                tempList.add(ownerChangeRequestResponse);
            }
        }
        documentChangeRequestResponseListInt.setDocumentChangeRequestResponseList(tempList);

    }

    public void processEmails(DocumentChangeRequestResponseListInt documentChangeRequestResponseListInt){
        int count=0;
        if(documentChangeRequestResponseListInt.getDocumentChangeRequestResponseList().size()>0){
            try{
                UtilDAO utilDAO = new UtilDAO();
                List iAOwnerWrapperList = utilDAO.getIAOwnerWrapper();
                Iterator iterator = iAOwnerWrapperList.iterator();
                while(iterator.hasNext()){
                    OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
                    SarboxMailComponent.workFlowEmail(SarboxMailComponent.WF_DOC_CHANGE_IA_APPROVAL_REQUEST,"",ownerWrapper);
                    count++;
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        documentChangeRequestResponseListInt.setNumberOfEmailsSent(count);
    }

    private void sendIARequestApprovalEmail(OwnerChangeRequest ownerChangeRequest){
        try{
            UtilDAO utilDAO = new UtilDAO();
            List iAOwnerWrapperList = utilDAO.getIAOwnerWrapper();
            Iterator iterator = iAOwnerWrapperList.iterator();
            while(iterator.hasNext()){
                OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
                SarboxMailComponent.workFlowEmail(SarboxMailComponent.WF_DOC_CHANGE_IA_APPROVAL_REQUEST,"",ownerWrapper);
            }
        }catch(Exception e){

        }
    }

}
