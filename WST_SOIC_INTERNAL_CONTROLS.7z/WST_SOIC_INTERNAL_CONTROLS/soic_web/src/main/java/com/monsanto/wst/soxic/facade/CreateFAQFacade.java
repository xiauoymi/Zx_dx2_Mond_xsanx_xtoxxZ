package com.monsanto.wst.soxic.facade;

import com.monsanto.wst.soxic.form.FAQForm;
import com.monsanto.wst.soxic.exception.FaqSubmitException;
import com.monsanto.wst.soxic.persistance.FaqDAO;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 12, 2006
 * Time: 10:13:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateFAQFacade {

    FaqDAO faqDAO = new FaqDAO();

    public void process(FAQForm faqForm) throws FaqSubmitException {
        if (faqForm.getQuestion()!=null && (faqForm.getAnswer()==null || faqForm.getAnswer().equalsIgnoreCase(""))){
            throw new FaqSubmitException("Answer cannot be empty for a Question");
        }
        else{
            createNewFaq(faqForm);
        }
    }

    protected void createNewFaq(FAQForm faqForm) {
        faqDAO.createNewFaq(faqForm);
    }
}
