package com.monsanto.wst.soxic.model.headerFooter;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 27, 2006
 * Time: 11:24:13 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class HeaderFooterFacade {

    public abstract String getHeader();
    public abstract String getFooter();

}
