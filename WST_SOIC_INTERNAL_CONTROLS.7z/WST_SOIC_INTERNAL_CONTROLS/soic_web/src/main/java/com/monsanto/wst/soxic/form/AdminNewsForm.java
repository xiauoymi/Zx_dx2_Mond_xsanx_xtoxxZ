/*
 * Created on Mar 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminNewsForm extends ActionForm{
    
    private List news;
    private String[] roles;
        
    private String    selectedNewsId;
    private boolean   newsSelected;
    private String[]  assignedRoles = {};
    private String    id;
    private String    title;
    private String    body;
   
    /**
     * @return Returns the assignedRoles.
     */
    public String[] getAssignedRoles() {
        
        return assignedRoles;
    }
    /**
     * @param assignedRoles The assignedRoles to set.
     */
    public void setAssignedRoles(String[] assignedRoles){
        
        this.assignedRoles = assignedRoles;
    }
    /**
     * @return Returns the news.
     */
    public List getNews() {
        return news;
    }
    /**
     * @param news The news to set.
     */
    public void setNews(List news) {
        this.news = news;
    }
    /**
     * @return Returns the roles.
     */
    public String[] getRoles() {
        return roles;
    }
    /**
     * @param roles The roles to set.
     */
    public void setRoles(String[] roles) {
        this.roles = roles;
    }
   
    
    /**
     * @return Returns the selectedNewsId.
     */
    public String getSelectedNewsId() {
        return selectedNewsId;
    }
    /**
     * @param selectedNewsId The selectedNewsId to set.
     */
    public void setSelectedNewsId(String selectedNewsId) {
        this.selectedNewsId = selectedNewsId;
    }
    
    /**
     * @return Returns the newsSelected.
     */
    public boolean isNewsSelected() {
        return newsSelected;
    }
    /**
     * @param newsSelected The newsSelected to set.
     */
    public void setNewsSelected(boolean newsSelected) {
        this.newsSelected = newsSelected;
    }
    /**
     * @return Returns the body.
     */
    public String getBody() {
        return body;
    }
    /**
     * @param body The body to set.
     */
    public void setBody(String body) {
        this.body = body;
    }
    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    public void reset(ActionMapping mapping, HttpServletRequest request){
        
        
        if(assignedRoles != null){

            assignedRoles = new String[0];
        }
        
           
    }
    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(String id) {
        this.id = id;
    }
}
