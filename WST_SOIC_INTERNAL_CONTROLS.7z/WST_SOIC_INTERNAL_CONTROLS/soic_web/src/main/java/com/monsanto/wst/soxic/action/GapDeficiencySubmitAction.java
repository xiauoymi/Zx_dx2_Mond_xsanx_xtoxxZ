package com.monsanto.wst.soxic.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.form.CycleViewForm;
import com.monsanto.wst.soxic.form.GapDeficiencyForm;
import com.monsanto.wst.soxic.form.SubCycleViewForm;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.*;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.persistance.OwnerResponseDAO;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/**
 * MyEclipse Struts Creation date: 02-09-2005
 * 
 * XDoclet definition:
 * 
 * @struts:action validate="true"
 */
public class GapDeficiencySubmitAction extends Action {

	// --------------------------------------------------------- Instance
	// Variables

	// --------------------------------------------------------- Methods

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		String action = getActionType(request.getParameterMap());

		if (action.equalsIgnoreCase("type")) {
			return type(mapping, form, request, response);
		}

		if (action.equalsIgnoreCase("edit")) {
			return edit(mapping, form, request, response);
		}

		if (action.equalsIgnoreCase("edit_comment")) {
			return editComment(mapping, form, request, response);
		}

		if (action.equalsIgnoreCase("remove")) {
			return remove(mapping, form, request, response);
		}

		if (action.equalsIgnoreCase("done")) {

			return done(mapping, form, request, response);
		}

		if (action.equalsIgnoreCase("add")) {

			return add(mapping, form, request, response);

		}

		forward = mapping.findForward("success");

		return forward;
	}

	/**
	 * When the user hits the edit button. Populate the text area with the
	 * comment he wants to edit Set the edit button to display
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward edit(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

		String activityId = getActivityToEdit(request.getParameterMap());

		String act[] = { activityId };

		gapDeficiencyFrom.setComment(getCommentToEdit(activityId,
				gapDeficiencyFrom.getAddedActivityList()));

		String acitid = act[0].substring(0, act[0].indexOf(SoxicUtil
				.getSeperator()));

		act[0] = acitid;

		gapDeficiencyFrom.setActivitySelected(act);

		gapDeficiencyFrom.setEditActivity(activityId);

		request.setAttribute("editcomment", "true");

		forward = mapping.findForward("success");

		return forward;
	}

	/**
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward editComment(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

		String act_to_edit = gapDeficiencyFrom.getEditActivity();

		editComment(gapDeficiencyFrom.getAddedActivityList(), act_to_edit,
				gapDeficiencyFrom.getComment());

		forward = mapping.findForward("success");
		return forward;
	}

	/**
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward done(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ActionForward forward = new ActionForward();
		
		 StatusDAO statusDAO = new StatusDAO();

		GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

		Owner owner = (Owner) request.getSession().getAttribute(
				SoxicConstants.OWNER);

		if (gapDeficiencyFrom.getAddedActivityList().size() == 0
				&& gapDeficiencyFrom.getActivitySelected() != null
				&& gapDeficiencyFrom.getActivitySelected().length > 0) {
			add(mapping, form, request, response);
		}
		GapHelper helper = new GapHelper();

		helper.addGap(gapDeficiencyFrom.getToReturn(), gapDeficiencyFrom
				.getAddedActivityList(), owner.getOwnerId());

		StatusHelper statusHelper = new StatusHelper();

		statusHelper.setStatus(request, gapDeficiencyFrom
				.getControlObjectiveId(), gapDeficiencyFrom
				.getAddedActivityList(), gapDeficiencyFrom.getToReturn(), owner
				.getOwnerId());
		if (gapDeficiencyFrom.getToReturn().equalsIgnoreCase("A")) {

			ControlObjectiveDAO.setGapForLevels(gapDeficiencyFrom
					.getControlObjectiveId(), SoxicConstants.CONTROLOBJECTIVE);
			if (setAllActivitiesComplete(gapDeficiencyFrom
					.getAddedActivityList(), gapDeficiencyFrom
					.getActivityList(), owner.getOwnerId(),
					SoxicConstants.GREEN_COMPLETE)) {
				//StatusDAO statusDAO = new StatusDAO();
				String status = statusDAO.getStatus(
						SoxicConstants.CONTROLOBJECTIVE, gapDeficiencyFrom
								.getControlObjectiveId());
				statusDAO.updateStatus(SoxicConstants.CONTROLOBJECTIVE, owner
						.getOwnerId(), gapDeficiencyFrom
						.getControlObjectiveId(), status);
			}
			ActivityDAO activityDAO = new ActivityDAO();
			if(activityDAO.ownerActivitiesComplete(owner.getOwnerId())){
				request.setAttribute("test","test");
			}

            updateQuestionStatusAfterEnteringGap(request, owner);

            forward = mapping.findForward("submit");
        }
		if (gapDeficiencyFrom.getToReturn().equalsIgnoreCase("S")) {

			SarboxMailComponent.sendEmail(SoxicConstants.SUBCYCLE,
					gapDeficiencyFrom.getControlObjectiveId());
           
            if(statusDAO.getOwnerOverAllStatus(SoxicConstants.SUBCYCLE,owner.getOwnerId()).equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
            	request.setAttribute("test","test");
            }

            SubCycleViewForm subcycleform = (SubCycleViewForm) request.getSession().getAttribute("subCycleViewForm");
            updateQuestionStatusAfterEnteringGap(subcycleform, statusDAO, owner);            
            forward = mapping.findForward("subcyle");

		}

		if (gapDeficiencyFrom.getToReturn().equalsIgnoreCase("AS")) {

			forward = mapping.findForward("subcyle");
		}

		if (gapDeficiencyFrom.getToReturn().equalsIgnoreCase("CS")) {

			forward = mapping.findForward("cycle");
		}

		if (gapDeficiencyFrom.getToReturn().equalsIgnoreCase("C")) {
            String sigChangeStatus = CycleStatusDAO.getSigChangeStatus(gapDeficiencyFrom.getControlObjectiveId(),owner.getOwnerId());
            String cycOwnerStatus = statusDAO.getOwnerOverAllStatus(SoxicConstants.CYCLE,owner.getOwnerId());
            if(sigChangeStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) && cycOwnerStatus.equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE)){
            	request.setAttribute("test","test");
            }
			forward = mapping.findForward("cycle");
		}

		return forward;
	}

    private void updateQuestionStatusAfterEnteringGap(SubCycleViewForm subcycleform, StatusDAO statusDAO, Owner owner) throws Exception {
        Iterator sit = subcycleform.getSubCycles().iterator();
        while(sit.hasNext()){
            SubCycle subCycle = (SubCycle)sit.next();
            Iterator questionIterator = subCycle.getQuestions().iterator();
            while (questionIterator.hasNext()) {
                QuestionNew questionNew = (QuestionNew) questionIterator.next();
                String questionId = questionNew.getQuestionId();
                String associatedId = questionNew.getAssociatedId();
                String newStatus = statusDAO.getStatusAfterEnteringSubCycleGap(questionId,associatedId,owner.getOwnerId());
                questionNew.setStatus(newStatus);
            }
        }
    }

    private void updateQuestionStatusAfterEnteringGap(HttpServletRequest request, Owner owner) throws Exception {
        ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) request
            .getSession().getAttribute("controlObjectiveForm");
        String ownerid = owner.getOwnerId();
        List controlObjList = (List) controlObjectiveForm.getControlObjectiveList();
        clearGapStatusToUpdate(controlObjList);
        OwnerResponseDAO ownerResponseDAO = new OwnerResponseDAO();
        ownerResponseDAO.setAnswers(ownerid,controlObjList);
    }

    private void clearGapStatusToUpdate(List controlObjList) {
        Iterator controlIterator = controlObjList.iterator();
        while(controlIterator.hasNext()){
            ControlObjective co = (ControlObjective) controlIterator.next();
            Map questionMap = co.getQuestionMap();
            Iterator questIterator = questionMap.keySet().iterator();
            while(questIterator.hasNext()){
                Object questionkey = questIterator.next();
                Question ques = (Question) questionMap.get(questionkey);
                ques.setStatus(null);
            }
        }
    }

    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public ActionForward add(ActionMapping mapping, ActionForm form,
                             HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        ActionForward forward = new ActionForward();

        GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

        String selected[] = gapDeficiencyFrom.getActivitySelected();

        if(gapDeficiencyFrom.getToReturn().equalsIgnoreCase("AS") || gapDeficiencyFrom.getToReturn().equalsIgnoreCase("CS")){
            gapDeficiencyFrom.setAddedActivityList(setAddedActivitySubLevel(
                    gapDeficiencyFrom.getActivityList(), selected,
                    gapDeficiencyFrom.getComment(),
                    gapDeficiencyFrom.getType(), gapDeficiencyFrom
                            .getAddedActivityList(), gapDeficiencyFrom
                            .getAction(), gapDeficiencyFrom));
            forward = mapping.findForward("success");
            return forward;
        }

        if (gapDeficiencyFrom.getActivitySelected() != null) {
            gapDeficiencyFrom.setAddedActivityList(setAddedActivity(
                    gapDeficiencyFrom.getActivityList(), selected,
                    gapDeficiencyFrom.getComment(),
                    gapDeficiencyFrom.getType(), gapDeficiencyFrom
                            .getAddedActivityList(), gapDeficiencyFrom
                            .getAction(), gapDeficiencyFrom));
        }

        forward = mapping.findForward("success");
        return forward;
    }

	/**
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward type(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

		String gap = request.getParameter("type");
		if (request.getParameter("type").equalsIgnoreCase("gap")) {
			gapDeficiencyFrom.setToDisplayAction(false);
		} else {
			gapDeficiencyFrom.setToDisplayAction(true);
		}

		forward = mapping.findForward("success");
		return forward;
	}

	/**
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward remove(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = new ActionForward();

		GapDeficiencyForm gapDeficiencyFrom = (GapDeficiencyForm) form;

		//	String selected[] = gapDeficiencyFrom.getActivitySelected();
		List removalList = new ArrayList();
		remove(gapDeficiencyFrom.getAddedActivityList(), request
				.getParameterMap(), removalList);

		//		if (gapDeficiencyFrom.getActivitySelected() != null) {
		//			gapDeficiencyFrom.setAddedActivityList(setAddedActivity(
		//					gapDeficiencyFrom.getActivityList(), selected,
		//					gapDeficiencyFrom.getComment(),
		//					gapDeficiencyFrom.getType(), gapDeficiencyFrom
		//							.getAddedActivityList(), gapDeficiencyFrom
		//							.getAction(), gapDeficiencyFrom));
		//		}

		forward = mapping.findForward("success");
		return forward;
	}

	/**
	 * 
	 * @param activityList
	 *            Original activity list
	 * @param selectedIn
	 *            list contains selected activities
	 * @param comment
	 *            comment to be added
	 * @param type
	 *            type of action
	 * @param addedActivityList
	 *            list to be added to
	 * @return
	 */
	public List setAddedActivity(List activityList, String selectedIn[],
			String comment, String type, List addedActivityList, String action,
			GapDeficiencyForm form) {

		Iterator activityListIterator = activityList.iterator();

		for (int i = 0; i < selectedIn.length; i++) {

			Activity activity = getActivityToAdd(selectedIn[i], activityList,
					addedActivityList);
			form.clearOtherQuestions();
			//			if (form.isToClear()) {
			//				activity.clear();
			//				form.setToClear(false);
			//
			//			}
			//			;

			activity.setComment(comment);

			activity.setType(type);

			ResponseGap responseGap = new ResponseGap();

			responseGap.setComment(comment);

			responseGap.setType(type);

			responseGap.setAction(action);

			responseGap.setResponseGapId(activity.getActivityId()
					+ SoxicUtil.getSeperator() + type);

			activity.addResponseGap(responseGap);

			if (!isActivityPresent(addedActivityList, activity.getActivityId())) {
				addedActivityList.add(activity);
			}

		}

		return addedActivityList;

	}
	
	/**
	 * 
	 * @param activityList
	 *            Original activity list
	 * @param selectedIn
	 *            list contains selected activities
	 * @param comment
	 *            comment to be added
	 * @param type
	 *            type of action
	 * @param addedActivityList
	 *            list to be added to
	 * @return
	 */
	public List setAddedActivitySubLevel(List activityList, String selectedIn[],
			String comment, String type, List addedActivityList, String action,
			GapDeficiencyForm form) {

		Iterator activityListIterator = activityList.iterator();

		for (int i = 0; i < selectedIn.length; i++) {

			Activity activity = getActivityToAdd(selectedIn[i], activityList,
					addedActivityList);
			
			if(form.getToReturn().equalsIgnoreCase("AS")){
				activity.setQuestionId("1");
			}else{
				activity.setQuestionId("3");
			}
			

			activity.setComment(comment);

			activity.setType(type);

			ResponseGap responseGap = new ResponseGap();

			responseGap.setComment(comment);

			responseGap.setType(type);

			responseGap.setAction(action);

			responseGap.setResponseGapId(activity.getActivityId()
					+ SoxicUtil.getSeperator() + type);

			activity.addResponseGap(responseGap);

			if (!isActivityPresent(addedActivityList, activity.getActivityId())) {
				addedActivityList.add(activity);
			}

		}

		return addedActivityList;

	}

	/**
	 * 
	 * @param activityList
	 *            Original activity list
	 * @param selectedIn
	 *            list contains selected activities
	 * @param comment
	 *            comment to be added
	 * @param type
	 *            type of action
	 * @param addedActivityList
	 *            list to be added to
	 * @return
	 */
	public Map setAddedActivityMap(List activityList, String selectedIn[],
			String comment, String type, List addedActivityList,
			Map addedActivityMap) {

		Iterator activityListIterator = activityList.iterator();

		while (activityListIterator.hasNext()) {

			Activity activity = (Activity) activityListIterator.next();

			for (int i = 0; i < selectedIn.length; i++) {

				if (selectedIn[i].equalsIgnoreCase(activity.getActivityId())) {

					activity.setComment(comment);

					activity.setType(type);

					ResponseGap responseGap = new ResponseGap();

					responseGap.setComment(comment);

					responseGap.setType(type);

					responseGap.setResponseGapId(activity.getActivityId()
							+ SoxicUtil.getSeperator() + type);

					activity.addResponseGap(responseGap);

					addedActivityList.add(activity);

					addedActivityMap.put(activity.getActivityId(), activity);

				}
			}

		}

		return addedActivityMap;

	}

	/**
	 * @param parameterMap
	 * @return
	 */
	public String getActionType(Map parameterMap) {

		String action = null;

		String[] valueArr = null;

		Iterator iter = parameterMap.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = parameterMap.get(key);

			valueArr = (String[]) value;

			if (((String) key).equalsIgnoreCase("edit")) {

				return "edit";
			}

			if (((String) key).equalsIgnoreCase("remove")) {

				return "remove";
			}

			if (((String) key).equalsIgnoreCase("done")) {

				return "done";
			}

			if (((String) key).equalsIgnoreCase("add")) {

				return "add";
			}

			if (((String) key).equalsIgnoreCase("edit_this")) {

				return "edit_comment";
			}
		}

		//return valueArr[0];
		return "type";

	}

	/**
	 * @param selectedList
	 * @param parameterMap
	 */
	public void remove(List selectedList, Map parameterMap, List removalList)
			throws Exception {

		//String activityId = activityToRemove(parameterMap);
		String activityToken = activityToRemove(parameterMap);

		StringTokenizer st = new StringTokenizer(activityToken, SoxicUtil
				.getSeperator());

		String activityId = st.nextToken();
		Iterator iterator = selectedList.iterator();

		while (iterator.hasNext()) {

			Activity activity = (Activity) iterator.next();

			if (activity.getActivityId().equalsIgnoreCase(activityId)) {

				ResponseGap responseGap = activity
						.removeResponseGap(activityToken);
				if (responseGap != null) {

					//ControlObjectiveDAO.removeGap(responseGap.getResponseId(),responseGap.getSequenceId());
					GapDAO gapDAO = new GapDAO();
					gapDAO.removeGap(responseGap.getResponseId(), responseGap
							.getSequenceId());
                    CycleStatusDAO.updateOwnerResponseStatusWithIncompleteGapResponse(responseGap.getResponseId());
                }

				if (activity.getResponseGapList().size() == 0) {
					iterator.remove();
				}

			}
		}

	}

	/**
	 * @param parameterMap
	 * @return
	 */
	public String activityToRemove(Map parameterMap) {

		String action = null;

		String[] valueArr = null;

		String toRemove = null;

		StringTokenizer st;

		Iterator iter = parameterMap.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = parameterMap.get(key);

			valueArr = (String[]) value;

			if (((String) key).equalsIgnoreCase("remove")) {

				toRemove = valueArr[0];

				//st = new StringTokenizer(toRemove,"-");

			}
		}
		return toRemove;
	}

	//	/**
	//	 * @param activityList
	//	 * @param ownerid
	//	 * @throws Exception
	//	 */
	//	public void insert(List activityList, String ownerid) throws Exception {
	//
	//		int responseid = 0;
	//
	//		Iterator activityIterator = activityList.iterator();
	//
	//		while (activityIterator.hasNext()) {
	//
	//			Activity activity = (Activity) activityIterator.next();
	//
	//			List responseGapList = activity.getResponseGapList();
	//
	//			Iterator responseIterator = responseGapList.iterator();
	//
	//			while (responseIterator.hasNext()) {
	//
	//				ResponseGap responseGap = (ResponseGap) responseIterator.next();
	//
	//				if (responseGap.getSequenceId() < 0) {
	//					responseid = ControlObjectiveDAO.insertGap(ownerid,
	//							activity.getActivityId(), activity.getQuestionId(),
	//							responseGap.getType(), responseGap.getComment(),
	//							responseGap.getAction());
	//
	//					ControlObjectiveDAO.setGapForLevels(activity
	//							.getActivityId(), SoxicConstants.ACTIVITY);
	//					ControlObjectiveDAO.updateOwnerResponseStatus(responseid,
	//							SoxicConstants.GREEN_COMPLETE);
	//					if (ControlObjectiveDAO.isActivityComplete(ownerid,
	//							activity.getActivityId())) {
	//						ControlObjectiveDAO.updateActivityStatus(ownerid,
	//								activity.getActivityId(),
	//								SoxicConstants.GREEN_COMPLETE, true);
	//					}
	//				} else {
	//					ControlObjectiveDAO.updateGap(responseGap.getResponseId(),
	//							responseGap.getSequenceId(), responseGap.getType(),
	//							responseGap.getComment(), responseGap.getAction());
	//				}
	//
	//			}
	//
	//		}
	//	}

	//	TODO
	//	public void setAllActivitiesToComplete(List activityList,
	//			List selectedActivities, String ownerid) throws Exception {
	//
	//		int responseid = 0;
	//
	//		Iterator activityIterator = activityList.iterator();
	//
	//		while (activityIterator.hasNext()) {
	//
	//			Activity activity = (Activity) activityIterator.next();
	//
	//			if (!isActivityPresent(activity.getActivityId(), selectedActivities)) {
	//				responseid = ControlObjectiveDAO.getResponseId(ownerid,
	//						activity.getActivityId(), activity.getQuestionId());
	//
	//				ControlObjectiveDAO.updateOwnerResponseStatus(responseid,
	//						SoxicConstants.GREEN_COMPLETE);
	//
	//				if (ControlObjectiveDAO.isActivityComplete(ownerid, activity
	//						.getActivityId())) {
	//					ControlObjectiveDAO.updateActivityStatus(ownerid, activity
	//							.getActivityId(), SoxicConstants.GREEN_COMPLETE,
	//							true);
	//				}
	//
	//			}
	//
	//		}
	//
	//	}

	public boolean setAllActivitiesComplete(List addedList, List originalList,
			String ownerId, String status) throws Exception {

		boolean activityStatusChanged = false;
		Iterator activityIterator = addedList.iterator();

		boolean sendMail = true;

		while (activityIterator.hasNext()) {
			Activity activity = (Activity) activityIterator.next();

			if (activity.getResponseGapList() != null
					&& activity.getResponseGapList().size() > 0) {

				StatusHelper statusHelper2 = new StatusHelper();

				statusHelper2.setOtherActivityStatus(originalList, ownerId,
						status);
				if (sendMail) {
					if (SarboxMailComponent.sendEmail(SoxicConstants.ACTIVITY,
							activity.getActivityId())) {
						sendMail = false;
					}

				}
				activityStatusChanged = true;
			}
		}
		return activityStatusChanged;
	}

	public boolean isActivityPresent(String activityId, List selectedActivities) {

		boolean present = false;

		Iterator activityIterator = selectedActivities.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			if (activity.getActivityId().equalsIgnoreCase(activityId)) {
				return true;
			}
		}

		return present;

	}

	/**
	 * @param parameterMap
	 * @return
	 */
	public String getActivityToEdit(Map parameterMap) {
		String action = null;

		String[] valueArr = null;

		String toRemove = null;

		Iterator iter = parameterMap.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = parameterMap.get(key);

			valueArr = (String[]) value;

			if (((String) key).equalsIgnoreCase("edit")) {

				toRemove = valueArr[0];

			}
		}
		return toRemove;
	}

	/**
	 * @param activityId
	 * @param activityList
	 * @return
	 */
	public String getCommentToEdit(String activityId, List activityList) {

		Iterator iterator = activityList.iterator();

		while (iterator.hasNext()) {

			Activity activity = (Activity) iterator.next();

			StringTokenizer st = new StringTokenizer(activityId, SoxicUtil
					.getSeperator());

			if (activity.getActivityId().equalsIgnoreCase(st.nextToken())) {

				return activity.getResponseGapComment(activityId);
			}
		}

		return null;
	}

	/**
	 * @param activityId
	 * @param activityList
	 * @param addedActivity
	 * @return
	 */
	public Activity getActivityToAdd(String activityId, List activityList,
			List addedActivity) {

		Iterator addedActivityIterator = addedActivity.iterator();

		while (addedActivityIterator.hasNext()) {

			Activity activity = (Activity) addedActivityIterator.next();

			if (activityId.equalsIgnoreCase(activity.getActivityId())) {

				return activity;
			}

		}

		Iterator activityIterator = activityList.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			if (activityId.equalsIgnoreCase(activity.getActivityId())) {

				return activity;
			}

		}

		return null;

	}

	/**
	 * @param activityList
	 * @param activityId
	 * @return
	 */
	public boolean isActivityPresent(List activityList, String activityId) {

		Iterator activityIterator = activityList.iterator();

		while (activityIterator.hasNext()) {

			Activity activity = (Activity) activityIterator.next();

			if (activityId.equalsIgnoreCase(activity.getActivityId())) {

				return true;
			}

		}

		return false;

	}

	/**
	 * @param selectedActivityList
	 * @param activityId
	 * @param comment
	 */
	public void editComment(List selectedActivityList, String activityId,
			String comment) {

		Iterator iterator = selectedActivityList.iterator();

		while (iterator.hasNext()) {

			Activity activity = (Activity) iterator.next();

			StringTokenizer st = new StringTokenizer(activityId, SoxicUtil
					.getSeperator());

			if (activity.getActivityId().equalsIgnoreCase(st.nextToken())) {

				activity.editResponseGapComment(activityId, comment);
			}
		}

	}

	/**
	 * @param request
	 * @param controlObjectiveId
	 * @throws Exception
	 */
	public void setGapPresentToTrue(HttpServletRequest request,
			GapDeficiencyForm form) throws Exception {

		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) request
				.getSession().getAttribute("controlObjectiveForm");

		Collection controlObjectiveList = controlObjectiveForm
				.getControlObjectiveList();

		Iterator controlListIterator = controlObjectiveList.iterator();

		while (controlListIterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) controlListIterator
					.next();

			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					form.getControlObjectiveId())) {
				Iterator activityIterator = form.getAddedActivityList()
						.iterator();

				while (activityIterator.hasNext()) {
					Activity activity = (Activity) activityIterator.next();

					if (activity.getResponseGapList() != null
							&& activity.getResponseGapList().size() > 0) {
						controlObjective.addToGapList("new gap");
						controlObjectiveForm.setStatusForControlObjective(form
								.getControlObjectiveId(), ((Owner) request
								.getSession().getAttribute("owner"))
								.getOwnerId());

						String status = ControlObjectiveDAO
								.getControlObjectiveStatus(form
										.getControlObjectiveId());
						//						ControlObjectiveDAO.updateControlObjectiveStatus(
						//								form.getControlObjectiveId(), status);
					}
				}

			}
		}
	}

	/**
	 * @param request
	 * @param subCycleId
	 */
	public void setGapPresentToTrueForSubcycle(HttpServletRequest request,
			String subCycleId, String status) {

		SubCycleViewForm subCycleViewForm = (SubCycleViewForm) request
				.getSession().getAttribute("subCycleViewForm");

		Collection subCycleList = subCycleViewForm.getSubCycles();

		Iterator subCycleListIterator = subCycleList.iterator();

		while (subCycleListIterator.hasNext()) {

			SubCycle subcycle = (SubCycle) subCycleListIterator.next();

			if (subcycle.getSubCycleId().equalsIgnoreCase(subCycleId)) {
				subcycle.setGap("Y");
				subcycle.setStatus(status);
			}
		}
	}

	/**
	 * @param request
	 * @param subCycleId
	 */
	public void setGapPresentToTrueForCycle(HttpServletRequest request,
			String subCycleId, String status) {

		CycleViewForm cycleViewForm = (CycleViewForm) request.getSession()
				.getAttribute("cycleViewForm");

		Collection cycleList = cycleViewForm.getCycles();

		Iterator cycleListIterator = cycleList.iterator();

		while (cycleListIterator.hasNext()) {

			Cycle cycle = (Cycle) cycleListIterator.next();

			if (cycle.getCycleId().equalsIgnoreCase(subCycleId)) {
				cycle.setGap("Y");
				cycle.setStatus(status);
			}
		}
	}

}