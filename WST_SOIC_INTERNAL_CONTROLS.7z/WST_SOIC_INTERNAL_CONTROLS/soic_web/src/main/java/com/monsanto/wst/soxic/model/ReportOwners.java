package com.monsanto.wst.soxic.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 21, 2005
 * Time: 10:17:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportOwners implements Comparable{

    private String owner_name;
    private String location;
    private String status;

    public ReportOwners(String owner_name, String location, String status) {
        this.owner_name = owner_name;
        this.location = location;
        this.status = status;
    }

    public String getOwner_name() {
        return owner_name;
    }

    public String getLocation() {
        return location;
    }

    public String getStatus() {
        return status;
    }

    public ReportOwners() {
    }

    public int compareTo(Object o) {
        if(o instanceof ReportOwners)  {
            return owner_name.compareTo(((ReportOwners)o).getOwner_name());
        }
        return owner_name.compareTo(((ReportOwners)o).getOwner_name());
    }
}
