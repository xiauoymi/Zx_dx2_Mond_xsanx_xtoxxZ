package com.monsanto.wst.soxic.workflow.gapoperations;

import com.monsanto.wst.soxic.model.Answer;

import java.util.List;
import java.util.Iterator;
import java.io.RandomAccessFile;
import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 22, 2005
 * Time: 2:45:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class GapEntityType {

    public static final String ACTIVITY_ENTITY = "ACTIVITY_ENTITY";
    public static final String CTRL_OBJ_ENTITY = "CTRL_OBJ_ENTITY";
    public static final String SUB_CYCLE_ENTITY = "SUB_CYCLE_ENTITY";
    public static final String CYCLE_ENTITY = "CYCLE_ENTITY";


    GapDAO  gapDAO = null;
    GapEntity gapEntity = null;


    public GapEntityType(String entityType, String environment, String folder) {
        if(entityType.equalsIgnoreCase(ACTIVITY_ENTITY)){
            gapDAO = new ActivityGapDAO(environment,folder);
            gapEntity = new ActivityGap();
        }
        if(entityType.equalsIgnoreCase(CTRL_OBJ_ENTITY)){
            gapDAO = new CtrlObjGapDAO(environment,folder);
            gapEntity = new CtrlObjGap();
        }
        if(entityType.equalsIgnoreCase(SUB_CYCLE_ENTITY)){
            gapDAO = new SubCycleGapDAO(environment,folder);
            gapEntity = new SubCycleGap();
        }
        if(entityType.equalsIgnoreCase(CYCLE_ENTITY)){
            gapDAO = new CycleGapDAO(environment,folder);
            gapEntity = new  CycleGap();
        }
    }

    public void processNoGapYesAnswer(){
        List entityList = gapDAO.selectNoGapYesAnswer();
        writeNoGapYesAnswerToFile(entityList);
        gapDAO.updateNoGapYesAnswer(entityList);
    }

    public void processNoGapNoAnswer(){
        List entityList = gapDAO.selectNoGapNoAnswer();
        writeNoGapNoAnswerToFile(entityList);
        gapDAO.updateNoGapNoAnswer(entityList);
    }

    public void writeNoGapNoAnswerToFile(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\NoGapNoAnswer.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();

                randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId()+" "+gapEntity.getQuestionId());
                randomAccessFile.writeChars("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeNoGapYesAnswerToFile(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\NoGapYesAnswer.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();

                randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId()+" "+gapEntity.getQuestionId());
                randomAccessFile.writeChars("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void processOwnerEntityList(){
        List entityList = gapDAO.selectOwnerEntity();
        Iterator iterator = entityList.iterator();

        while(iterator.hasNext()){
            GapEntity gapEntity = (GapEntity)iterator.next();
            List answerList = gapDAO.getResponseList(gapEntity);
            processResponsesForEntityOwner(answerList,gapEntity);
        }

        writeOwnerEntityYesAnswerNoGapToFile(entityList);
        writeOwnerEntityNoAnswerNoGapToFile(entityList);
        writeOwnerEntityNoAnswerYesGapButOneQuestionToFile(entityList);

        gapDAO.updateNoGapYesAnswer(entityList);
    }

    public void processOwnerEntityListSetGapToYesForGaps(){
        List entityList = gapDAO.selectOwnerEntityWithGaps();
        writeOwnerEntityUpdateGapToYes(entityList);

        gapDAO.updateOwnerEntity(entityList);
    }

   public void processEntitySetGapsToYesForGaps(){
        List entityList = gapDAO.selectEntity();

        Iterator iterator = entityList.iterator();

        while(iterator.hasNext()){
            GapEntity gapEntity = (GapEntity)iterator.next();

            List listOfPotentialGaps =gapDAO.selectAllGapsPerEntity(gapEntity);
            if(listOfPotentialGaps.contains("Y")){

                gapEntity.setDoUpdate(true);
                gapEntity.setWriteToUpdateEntityGapYesForGaps(true);
                gapEntity.setPotentialGap("Y");
            }

        }
//        writeToUpdateEntityNo(entityList);
//        writeToUpdateEntityYes(entityList);
        writeToUpdateEntityYesGapsForGaps(entityList);
       gapDAO.updateEntitySetYesGapsForGaps(entityList);
    }

    private void processResponsesForEntityOwner(List answerList,GapEntity gapEntity) {
        if(containsNoAndNoGap(answerList)){
            if(gapEntity.getPotentialGap().equalsIgnoreCase("Y")){
                if(!containsGap(answerList)){
                    gapEntity.setDoUpdate(true);
                    gapEntity.setPotentialGap("");
                    gapEntity.setWriteToNoAnswerNoGap(true);
                }else{
                   gapEntity.setDoUpdate(false);
                    //gapEntity.setPotentialGap("");
                    //gapEntity.setWriteToNoAnswerNoGap(true);
                    gapEntity.setWriteToNoAnswerYesGapButOnlyOneQuestion(true);
                }
            }
            return;
        }

        if(!containsNo(answerList)){
            //if(containsYesAndNoGap(answerList) && !containsGap(answerList)){
            if(!containsGap(answerList)){
                if(gapEntity.getPotentialGap().equalsIgnoreCase("Y")){
                    gapEntity.setDoUpdate(true);
                    gapEntity.setPotentialGap("");
                    gapEntity.setWriteToYesAnswerNoGap(true);
                }
                return;
            }
        }

//        if(containsNoAndYesGap(answerList)){
//            if(gapEntity.getPotentialGap().equalsIgnoreCase("")){
//                gapEntity.setDoUpdate(true);
//                gapEntity.setPotentialGap("Y");
//            }
//            return;
//        }
//
//        if(containsYesAndYesGap(answerList)){
//            if(gapEntity.getPotentialGap().equalsIgnoreCase("")){
//                gapEntity.setDoUpdate(true);
//                gapEntity.setPotentialGap("Y");
//            }
//            return;
//        }



    }

    private boolean containsYesAndNoGap(List answerList) {
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("YES")){
                if(response.getDescription().length()==0){
                    value= true;
                }
            }

        }
        return value;
    }

    private boolean containsGap(List answerList) {
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();

                if(response.getDescription().length()>0){
                    value= true;
                }


        }
        return value;
    }

    private boolean containsYesAndYesGap(List answerList) {
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("YES")){
                if(response.getDescription().length()>0){
                    value= true;
                }
            }

        }
        return value;
    }

    public boolean containsNoAndNoGap(List answerList){
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("NO")){
                if(response.getDescription().length()==0){
                    value= true;
                }
            }

        }
        return value;
    }

    public boolean containsNo(List answerList){
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("NO")){
                value = true;
            }

        }
        return value;
    }

    public boolean containsYes(List answerList){
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("YES")){
                value = true;
            }

        }
        return value;
    }

    public boolean containsNoAndYesGap(List answerList){
        Iterator answerIterator = answerList.iterator();
        Response response=null;
        boolean value = false;
        while(answerIterator.hasNext()){
            response = (Response)answerIterator.next();
            if(response.getResponse()!=null && response.getResponse().equalsIgnoreCase("NO")){
                if(response.getDescription().length()>0){
                    value= true;
                }
            }

        }
        return value;
    }

    public void processEntity(){
        List entityList = gapDAO.selectEntity();

        Iterator iterator = entityList.iterator();

        while(iterator.hasNext()){
            GapEntity gapEntity = (GapEntity)iterator.next();

            List listOfPotentialGaps =gapDAO.selectAllGapsPerEntity(gapEntity);
            if(listOfPotentialGaps.contains("Y")){
                if(!gapEntity.getPotentialGap().equalsIgnoreCase("Y")){
                    gapEntity.setPotentialGap("Y");
                    gapEntity.setDoUpdate(true);
                    gapEntity.setWriteToUpdateEntityGapYes(true);
                }
            }else{
                 if(!gapEntity.getPotentialGap().equalsIgnoreCase("")){
                    gapEntity.setPotentialGap("");
                    gapEntity.setDoUpdate(true);
                     gapEntity.setWriteToUpdateEntityGapNo(true);
                }
            }

        }
        writeToUpdateEntityNo(entityList);
        writeToUpdateEntityYes(entityList);
        gapDAO.updateEntity(entityList);
    }

    public void writeOwnerEntityYesAnswerNoGapToFile(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\OwnerEntityYesAnsNoGap.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isDoUpdate() && gapEntity.isWriteToYesAnswerNoGap()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeOwnerEntityNoAnswerNoGapToFile(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\OwnerEntityNoAnsNoGap.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isDoUpdate() && gapEntity.isWriteToNoAnswerNoGap()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeOwnerEntityNoAnswerYesGapButOneQuestionToFile(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\OwnerEntityNoAnsYesGapButOneQuestion.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isWriteToNoAnswerYesGapButOnlyOneQuestion()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeOwnerEntityUpdateGapToYes(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\OwnerEntityUpdateGapToYes.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isWriteToUpdateOwnerEntityGapYes()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier()+" "+gapEntity.getOwnerId());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeToUpdateEntityYes(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\UpdateEntity.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isWriteToUpdateEntityGapYes()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeToUpdateEntityNo(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\UpdateEntity.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isWriteToUpdateEntityGapNo()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void writeToUpdateEntityYesGapsForGaps(List entityList){
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("c:\\ErrorOutput\\UpdateEntityYesForYesGapsThu.dat","rw");
            randomAccessFile.seek(randomAccessFile.length());
            Iterator iterator = entityList.iterator();
            while(iterator.hasNext()){
                GapEntity gapEntity = (GapEntity)iterator.next();
                if(gapEntity.isWriteToUpdateEntityGapYesForGaps()){
                    randomAccessFile.writeBytes(""+gapEntity.getIdentifier());
                    randomAccessFile.writeChars("\n");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
