/*
 * Created on May 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;


/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerResponseHistory {
	
	private String responseHistoryId;
	private String responseId;
	private String response;
	private String ownerid;
	
	

	/**
	 * @return Returns the ownerid.
	 */
	public String getOwnerid() {
		return ownerid;
	}
	/**
	 * @param ownerid The ownerid to set.
	 */
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	/**
	 * @return Returns the response.
	 */
	public String getResponse() {
		return response;
	}
	/**
	 * @param response The response to set.
	 */
	public void setResponse(String response) {
		this.response = response;
	}
	/**
	 * @return Returns the responseHistoryId.
	 */
	public String getResponseHistoryId() {
		return responseHistoryId;
	}
	/**
	 * @param responseHistoryId The responseHistoryId to set.
	 */
	public void setResponseHistoryId(String responseHistoryId) {
		this.responseHistoryId = responseHistoryId;
	}
	/**
	 * @return Returns the responseId.
	 */
	public String getResponseId() {
		return responseId;
	}
	/**
	 * @param responseId The responseId to set.
	 */
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}
	
	 public String toString(){
	     
	     StringBuffer buffer = new StringBuffer();
	     buffer.append('\n'+ "Owner Response History :"         + '\n');
	     buffer.append("PeriodId    :"+ responseHistoryId    + '\n');
	     buffer.append("CycleId     :"+ responseId    + '\n');
	     buffer.append("Description :"+ response + '\n');
	     buffer.append("DueDate     :"+ ownerid     + '\n');
	     return buffer.toString();
	     
	 }	
}
