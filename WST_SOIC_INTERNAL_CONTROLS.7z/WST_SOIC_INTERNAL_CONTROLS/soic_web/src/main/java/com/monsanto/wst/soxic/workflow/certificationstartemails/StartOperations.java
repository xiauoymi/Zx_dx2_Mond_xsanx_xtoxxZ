package com.monsanto.wst.soxic.workflow.certificationstartemails;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.persistance.EmailHeaderDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.Map;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 27, 2006
 * Time: 4:52:32 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class StartOperations {

    StartEmailDAO startEmailDAO;

    protected StartOperations(String level) {
        if(level.equalsIgnoreCase(SoxicConstants.ACTIVITY)){
            this.startEmailDAO = new ActivityStartDAO();
        }
    }

    /**
     * Sends email to activity owners and then to sub-cycle owners
     * @throws Exception
     */
    public void sendStartEmail()throws Exception{
        List currentLevelStartList = getStartCurrentLevelList();
        String customString = getEmailHeader();
        emailCurrentLevel(currentLevelStartList, customString);
        emailUpperLevel();
    }



    protected String getEmailHeader() throws DatabaseException {
        EmailHeaderDAO emailHeaderDAO=new EmailHeaderDAO();
        Map headerMap = emailHeaderDAO.selectHeader();
        String customString = (String) headerMap.get(getHeaderLevel());
        return customString;
    }

    protected abstract String getHeaderLevel();

    protected List getStartCurrentLevelList()throws Exception{
        return startEmailDAO.getStartCurrentLevelList();
    }
    protected abstract void emailCurrentLevel(List activityList,String customString) throws Exception;
    protected abstract void emailUpperLevel() throws Exception;

}
