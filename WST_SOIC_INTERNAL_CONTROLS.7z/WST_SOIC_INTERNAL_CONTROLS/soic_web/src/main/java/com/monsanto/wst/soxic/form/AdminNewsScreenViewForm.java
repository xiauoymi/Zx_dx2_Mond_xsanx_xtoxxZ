//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.form;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.action.AdminReportObject;
import com.monsanto.wst.soxic.action.ExportAction;

/** 
 * MyEclipse Struts
 * Creation date: 04-01-2005
 * 
 * XDoclet definition:
 * @struts:form name="adminNewsScreenViewForm"
 */
public class AdminNewsScreenViewForm extends ActionForm {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	private Vector adminNewsVector = new Vector();
	
	private Vector allRoles = new Vector();
	
	private String[] rolesSelected;
	
	
	private boolean displayTable2 = true;
	
	private AdminReportObject editNewsObj = new AdminReportObject();
	
	// --------------------------------------------------------- Methods

	
	
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}

	/**
	 * @return Returns the logger.
	 */
	public static Category getLogger() {
		return logger;
	}
	/**
	 * @param logger The logger to set.
	 */
	public static void setLogger(Category logger) {
		AdminNewsScreenViewForm.logger = logger;
	}
	/**
	 * @return Returns the adminNewsVector.
	 */
	public Vector getAdminNewsVector() {
		return adminNewsVector;
	}
	/**
	 * @param adminNewsVector The adminNewsVector to set.
	 */
	public void setAdminNewsVector(Vector adminNewsVector) {
		this.adminNewsVector = adminNewsVector;
	}
	/**
	 * @return Returns the allRoles.
	 */
	public Vector getAllRoles() {
		return allRoles;
	}
	/**
	 * @param allRoles The allRoles to set.
	 */
	public void setAllRoles(Vector allRoles) {
		this.allRoles = allRoles;
	}
	/**
	 * @return Returns the displayTable2.
	 */
	public boolean isDisplayTable2() {
		return displayTable2;
	}
	/**
	 * @param displayTable2 The displayTable2 to set.
	 */
	public void setDisplayTable2(boolean displayTable2) {
		this.displayTable2 = displayTable2;
	}
	
	/**
	 * @return Returns the editNewsObj.
	 */
	public AdminReportObject getEditNewsObj() {
		return editNewsObj;
	}
	/**
	 * @param editNewsObj The editNewsObj to set.
	 */
	public void setEditNewsObj(AdminReportObject editNewsObj) {
		this.editNewsObj = editNewsObj;
	}
	/**
	 * @return Returns the rolesSelected.
	 */
	public String[] getRolesSelected() {
		return rolesSelected;
	}
	/**
	 * @param rolesSelected The rolesSelected to set.
	 */
	public void setRolesSelected(String[] rolesSelected) {
		this.rolesSelected = rolesSelected;
	}
}