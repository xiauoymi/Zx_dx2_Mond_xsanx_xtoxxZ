package com.monsanto.wst.soxic.model;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 20, 2005
 * Time: 12:11:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusReportDAO {

    private PersistentStoreConnection createPersistentStore() throws WrappingException {
        PersistentStore persistentStore = WST_SOX_PersistentStoreFactory.getStore();
        PersistentStore.registerInstance(persistentStore);
        PersistentStoreConnection psConnection = persistentStore.connect();
        return psConnection;
    }

    public List getPeriods() throws DatabaseException {
        List periodSet = new ArrayList();
        Set period = new HashSet();
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement("SELECT PERIOD_ID FROM CYCLE");
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                setAllPeriods(persistentStoreResultSetFwdIterator, period);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        periodSet = addSetValuesIntoList(period, periodSet);
        Collections.sort(periodSet);
        return periodSet;
    }

    private List addSetValuesIntoList(Set setValues, List listValues) {
        Iterator it = setValues.iterator();
        while(it.hasNext()){
            String id = (String) it.next();
            listValues.add(id);
        }
        return listValues;
    }

    private void closePersistentConnection(PersistentStoreStatement persistentStoreStatement, PersistentStoreConnection psConnection) throws DatabaseException {
        if(persistentStoreStatement != null){
            try {
                persistentStoreStatement.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
        if(psConnection != null){
            try {
                psConnection.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
    }

    private void setAllPeriods(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator, Set period) throws WrappingException {
        String periodId = persistentStoreResultSetFwdIterator.getString("PERIOD_ID");
        period.add(periodId);
    }

    public List getCountriesForCycle() throws DatabaseException {
        List countries = new ArrayList();
        Set countList = new HashSet();
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement("SELECT VALUE FROM LOOKUP WHERE TYPE ='COUNTRYID'");
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                setAllCountries(persistentStoreResultSetFwdIterator, countList);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        countries = addSetValuesIntoList(countList,countries);
        Collections.sort(countries);
        return countries;
    }

    private void setAllCountries(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator, Set countries) throws WrappingException {
        String countryId = persistentStoreResultSetFwdIterator.getString("VALUE");
        countries.add(countryId);
    }

}
