package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.SignificantChangeFacade;
import com.monsanto.wst.soxic.form.SignificantChangeForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import com.monsanto.wst.soxic.util.SoxicConstants;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 8, 2006
 * Time: 3:02:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class SigChangeDisplayAction extends Action {

    String newChanges = "createSigChanges";
    String updateChanges = "updateSigChanges";
    String forwardString = "";
    List allPeriods = new ArrayList();
    List businessTypes = new ArrayList();
    int id = 0;
    List sigChangesForOwner;

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception{

        SignificantChangeForm significantChangeForm = (SignificantChangeForm)form;
        SignificantChangeFacade significantChangeFacade = new SignificantChangeFacade();

        Owner owner = (Owner) request.getSession().getAttribute("owner");
        String cycleId = request.getParameter("cycleId");
        String ownerid = owner.getOwnerId();

        setCycleOwnerAndChanges(significantChangeForm, cycleId, ownerid);
        process(significantChangeFacade, cycleId, ownerid, significantChangeForm);
        request.getSession().setAttribute("sigChangeForm",significantChangeForm);

        return mapping.findForward(forwardString);
    }

    public void process(SignificantChangeFacade significantChangeFacade, String cycleId, String ownerid, SignificantChangeForm significantChangeForm) {
        String significantSeqId = significantChangeFacade.getSignificantSeqID(cycleId,ownerid);
        getAllBusinessTypes(significantChangeFacade);
        getAllPeriods(significantChangeFacade);
        Collections.sort(allPeriods);
        proceedBasedOnExistingList(significantSeqId, significantChangeForm, significantChangeFacade, cycleId, ownerid);
    }

    public void setCycleOwnerAndChanges(SignificantChangeForm significantChangeForm, String cycleId, String ownerid) {
        significantChangeForm.setCycleId(cycleId);
        significantChangeForm.setOwnerId(ownerid);
        significantChangeForm.setSignificantChanges(null);
    }

    private void proceedBasedOnExistingList(String significantId, SignificantChangeForm significantChangeForm, SignificantChangeFacade significantChangeFacade, String cycleId, String ownerid) {
        if (significantId==null){
            buildNewSigChangeRowAndDisplay(significantChangeForm);
        }
        else{
            buildUpdatedSigChangesAndDisplay(significantChangeForm, significantChangeFacade, cycleId, ownerid);
        }
    }

    private void buildUpdatedSigChangesAndDisplay(SignificantChangeForm significantChangeForm, SignificantChangeFacade significantChangeFacade, String cycleId, String ownerid) {
        sigChangesForOwner = new ArrayList();
        sigChangesForOwner = significantChangeFacade.getSignificantChanges(cycleId,ownerid);
        Iterator it = sigChangesForOwner.iterator();
        setExtraParamsInSignChangeList(it);
        setFirstMinusButtonInvisible();
        setNoChangeReportingCheckBox(significantChangeForm);
        significantChangeForm.setSignificantChanges(sigChangesForOwner);
        forwardString = updateChanges;
    }

    private void setNoChangeReportingCheckBox(SignificantChangeForm significantChangeForm) {
        if ((((SignificantChangeModel)sigChangesForOwner.get(0)).getSelectedType()).equalsIgnoreCase(SoxicConstants.NONE)){
            significantChangeForm.setNoReporting(true);
        }
    }

    private void setFirstMinusButtonInvisible() {
        ((SignificantChangeModel)sigChangesForOwner.get(0)).setAddButton(false);
    }

    private void setExtraParamsInSignChangeList(Iterator it) {
        while(it.hasNext()){
            SignificantChangeModel significantChangeModel = (SignificantChangeModel)it.next();
            significantChangeModel.setSigTypes(businessTypes);
            significantChangeModel.setSigPeriods(allPeriods);
            significantChangeModel.setAddButton(true);
        }
    }

    private void buildNewSigChangeRowAndDisplay(SignificantChangeForm significantChangeForm) {
        sigChangesForOwner = new ArrayList();
        createInitialSigChangeEntries();
        significantChangeForm.setSignificantChanges(sigChangesForOwner);
        significantChangeForm.setNoReporting(false);
        forwardString = newChanges;
    }

    private void createInitialSigChangeEntries() {
        SignificantChangeModel significantChangeModel;
        significantChangeModel = new SignificantChangeModel(String.valueOf(id),"",(String)allPeriods.get(0),"","","","");
        createTypePeriodAndSaveToList(significantChangeModel);
    }

    private void createTypePeriodAndSaveToList(SignificantChangeModel significantChangeModel) {
        significantChangeModel.setSigTypes(businessTypes);
        significantChangeModel.setSigPeriods(allPeriods);
        sigChangesForOwner.add(significantChangeModel);
    }

    private void getAllPeriods(SignificantChangeFacade significantChangeFacade) {
        allPeriods = significantChangeFacade.getFuturePeriods();
    }

    private void getAllBusinessTypes(SignificantChangeFacade significantChangeFacade) {
        businessTypes = significantChangeFacade.getBusinessTypes();
    }

}
