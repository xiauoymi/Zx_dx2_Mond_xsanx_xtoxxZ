package com.monsanto.wst.soxic.model;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.soxic.Servlet.WST_SOX_PersistentStoreFactory;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 22, 2005
 * Time: 11:12:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusCycleDAO {

    private PersistentStoreConnection createPersistentStore() throws WrappingException {
        PersistentStore persistentStore = WST_SOX_PersistentStoreFactory.getStore();
        PersistentStore.registerInstance(persistentStore);
        PersistentStoreConnection psConnection = persistentStore.connect();
        return psConnection;
    }

    private void closePersistentConnection(PersistentStoreStatement persistentStoreStatement, PersistentStoreConnection psConnection) throws DatabaseException {
        if(persistentStoreStatement != null){
            try {
                persistentStoreStatement.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
        if(psConnection != null){
            try {
                psConnection.close();
            } catch (WrappingException e) {
                e.printStackTrace();
                throw new DatabaseException(e);
            }
        }
    }

    public List getSubCycles(String cycelid) throws DatabaseException {
        List subcycles = new ArrayList();
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement
                    ("SELECT SC.SUB_CYCLE_ID " +
                    "FROM SUB_CYCLE SC, CYCLE C " +
                    "WHERE SC.CYCLE_ID = C.CYCLE_ID " +
                    "AND C.CYCLE_ID = ?");
            persistentStoreStatement.setParam(1,cycelid);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                setSubCycleIntoList(persistentStoreResultSetFwdIterator, subcycles);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(subcycles);
        return subcycles;
    }

    private void setSubCycleIntoList(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator, List subcycles) throws WrappingException {
        String subcycleid = persistentStoreResultSetFwdIterator.getString("SUB_CYCLE_ID");
        subcycles.add(subcycleid);
    }

    public List setByCycleReportInformation(String subcycleid) throws DatabaseException {
        List ownerInfo = new ArrayList();
        ReportOwners reportOwners = null;
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = createPersistentStore();
            persistentStoreStatement =  psConnection.prepareStatement
                    ("SELECT SC.SUB_CYCLE_ID,OSC.OWNER_ID,O.NAME,O.LOCATION,OSC.STATUS " +
                    "FROM SUB_CYCLE SC,CYCLE C,OWNER_SUB_CYCLE OSC,OWNER O " +
                    "WHERE OSC.OWNER_ID = O.OWNER_ID " +
                    "AND OSC.SUB_CYCLE_ID = SC.SUB_CYCLE_ID " +
                    "AND SC.CYCLE_ID = C.CYCLE_ID " +
                    "AND SC.SUB_CYCLE_ID = ? ");
            persistentStoreStatement.setParam(1,subcycleid);
            PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();

            PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet.getForwardIterator();
            while(persistentStoreResultSetFwdIterator.next()){
                String owner = persistentStoreResultSetFwdIterator.getString("NAME");
                String location = persistentStoreResultSetFwdIterator.getString("LOCATION");
                String status = persistentStoreResultSetFwdIterator.getString("STATUS");
                if (status.equalsIgnoreCase(SoxicConstants.COMPLETE)){
                    status = "COMPLETE";
                }
                else status = "-";
                reportOwners = new ReportOwners(owner,location,status);
                ownerInfo.add(reportOwners);
            }
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            e.printStackTrace();
        }
        finally{
            closePersistentConnection(persistentStoreStatement, psConnection);
        }
        Collections.sort(ownerInfo);
        return ownerInfo;
    }
}
