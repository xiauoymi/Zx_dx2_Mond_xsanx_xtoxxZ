/*
 * Created on Jun 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.tags;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.model.UtilDAO;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DashBoard extends SimpleTagSupport {
	
	private String level="";
	
	private String period="";
	
	
	
	/**
	 * @return Returns the period.
	 */
	public String getPeriod() {
		return period;
	}
	/**
	 * @param period The period to set.
	 */
	public void setPeriod(String period) {
		this.period = period;
	}
	/**
	 * @return Returns the level.
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level The level to set.
	 */
	public void setLevel(String level) {
		this.level = level;
	}
    public void doTag() throws JspException, IOException {

        DateFormat df = DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM, DateFormat.MEDIUM);

        // now write out the formatted date to the page
        
       
        
        UtilDAO utilDAO = new UtilDAO();
        
        try{
        	List countryList = utilDAO.getCountries(period);
        	List percentageComplete = null;
        	List dueDateList =null;
        	
        	if(level.equalsIgnoreCase("Activity"))
        	{
               	percentageComplete = utilDAO.getPercentageCompletion(SoxicConstants.ACTIVITY,countryList,getPeriod());
            	dueDateList = utilDAO.getDueDate(SoxicConstants.ACTIVITY,countryList,period);
        	}
        	
        	if(level.equalsIgnoreCase("Subcycle")){
              	percentageComplete = utilDAO.getPercentageCompletion(SoxicConstants.SUBCYCLE,countryList,getPeriod());
            	dueDateList = utilDAO.getDueDate(SoxicConstants.SUBCYCLE,countryList,period);
        	}
        	
        	if(level.equalsIgnoreCase("Cycle")){
              	percentageComplete = utilDAO.getPercentageCompletion(SoxicConstants.CYCLE,countryList,getPeriod());
            	dueDateList = utilDAO.getDueDate(SoxicConstants.CYCLE,countryList,period);      		
        	}
 
	        getJspContext().getOut().write(df.format(new Date()));
	        if(isStarted(percentageComplete)){
	        	getJspContext().getOut().write("<script language=JavaScript>");
	        
	        	getJspContext().getOut().write("var bg = new Graph("+countryList.size()+");");
	        
	        	getJspContext().getOut().write("bg.parent = document.getElementById('here');");
	        	if(level.equalsIgnoreCase("Activity"))
	        	{
	        		getJspContext().getOut().write("bg.title = 'Activity Level Report';");
	        	}
	        	if(level.equalsIgnoreCase("Subcycle"))
	        	{
	        		getJspContext().getOut().write("bg.title = 'Sub Cycle Level Report';");
	        	}
	        	if(level.equalsIgnoreCase("Cycle"))
	        	{
	        		getJspContext().getOut().write("bg.title = 'Cycle Level Report';");
	        	}
	        	getJspContext().getOut().write("bg.xCaption = 'Countries';");
	        	getJspContext().getOut().write("bg.yCaption = 'Certification Percent Complete';");
	        
	        
		        for(int i=0;i<countryList.size();i++){
		        	String str = "bg.xValues["+i+"] = ["+percentageComplete.get(i)+",'"+countryList.get(i)+"<p> <h3>"+dueDateList.get(i)+"</h3>'];";
		        	if(((String)percentageComplete.get(i)).equalsIgnoreCase("0")){
		        	 getJspContext().getOut().write("bg.xValues["+i+"] = [0,'"+countryList.get(i)+"<p> <h3>"+dueDateList.get(i)+"</h3>'];");
		        	}else{
		        		getJspContext().getOut().write("bg.xValues["+i+"] = ["+percentageComplete.get(i)+",'"+countryList.get(i)+"<p> <h3>"+dueDateList.get(i)+"</h3>'];");
		        	}
		        }
	      
	       
		        	//	        getJspContext().getOut().write("bg.xValues[1] = [15,'Can <p> <h3>5/8</h3>'];");
		        	//	        getJspContext().getOut().write("bg.xValues[2] = [20,'Mex <p> <h3>5/8</h3>'];");
		        	//	        getJspContext().getOut().write("bg.xValues[3] = [25,'E/A  <p> <h3>5/8</h3>'];");
		        	//	        getJspContext().getOut().write("bg.xValues[4] = [26,'FRA <p> <h3>5/8</h3>'];");
		        getJspContext().getOut().write("bg.draw();");
		        getJspContext().getOut().write("</script>");
	        }else{
	        	getJspContext().getOut().write("<center><h1>No Data to Display</h1></center>");
	        }
        }catch(Exception ex){
        	ex.printStackTrace();
        }
        
      }
    
    private boolean isStarted(List percentageCompletion){
    	
    	Iterator iterator = percentageCompletion.iterator();
    	
    	while(iterator.hasNext()){
    		String completion = (String)iterator.next();
    		
    		if(!completion.equalsIgnoreCase("0")){
    			return true;
    		}
    	}
    	
    	return false;
    	
    }

}




