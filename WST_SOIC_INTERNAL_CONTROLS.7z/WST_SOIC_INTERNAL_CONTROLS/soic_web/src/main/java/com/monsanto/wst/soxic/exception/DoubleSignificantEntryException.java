package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 14, 2006
 * Time: 4:30:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class DoubleSignificantEntryException extends Exception {

    public DoubleSignificantEntryException() {
        super();
    }

    public DoubleSignificantEntryException(Exception e) {
        super(e);
    }
}
