//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.soxic.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.CycleReportForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

/** 
 * MyEclipse Struts
 * Creation date: 03-15-2005
 * 
 * XDoclet definition:
 * @struts:action path="/cycleReport" name="cycleReportForm" scope="request" validate="true"
 */
public class CycleReportAction extends Action {

	// --------------------------------------------------------- Instance Variables
	//**Log4j logger
    static Category logger = Category.getInstance(ExportAction.class.getName());
	
	// --------------------------------------------------------- Methods
	
	
	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		CycleReportForm cycleReportForm = (CycleReportForm) form;
		
		Vector periodIDs = new Vector();		
		String currentPeriodID = cycleReportForm.getPeriodID();
		
		int totalNALAN = 0;
		
		int totalInternational = 0;
		
		Vector worldAreaVector = new Vector();
		
		InternationalDataObject intlData = new InternationalDataObject();
		TotalDataObject totalData = new TotalDataObject();
		
		//**Connecting to the Oracle DB...
		try{
//			Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	DataSource ds = (DataSource)envContext.lookup("jdbc/soxicdb");
//		 	Connection con = ds.getConnection();
			Connection con = SoxicConnectionFactory.getSoxicConnection();
		 	
		 	logger.info("Connected to DB from /cycle-Report-action.");
		 	
		 	PreparedStatement getPeriodIDs;
			PreparedStatement getWorldArea;
			PreparedStatement getCountry;
			PreparedStatement getTotalActivities;
			PreparedStatement getTotalActivitiesComplete;
			PreparedStatement getEstCompletionDate;
			PreparedStatement getTotalDefRef;
			PreparedStatement getOpenDefRef;
			
			getPeriodIDs = con.prepareStatement
				("SELECT DISTINCT PERIOD_ID " +
					"FROM CYCLE ORDER BY PERIOD_ID");
			
			getWorldArea = con.prepareStatement
				("SELECT DISTINCT WORLD_AREA_ID " +
					"FROM CYCLE ORDER BY WORLD_AREA_ID DESC");
			
			getCountry = con.prepareStatement
				("SELECT DISTINCT COUNTRY_ID " +
					"FROM CYCLE  " +
					"WHERE  WORLD_AREA_ID = ? ORDER BY COUNTRY_ID DESC");
			
			getTotalActivities = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_ACTIVITIES " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"C.CYCLE_ID = SC.CYCLE_ID AND " +
						"SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND " +
						"CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND " +
						"C.COUNTRY_ID = ? AND " +
						"C.PERIOD_ID = ?");
			
			getTotalActivitiesComplete = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_ACTIVITIES_COMPLETE " +
					"FROM " +
						"CYCLE C, SUB_CYCLE SC, CTRL_OBJ CO, ACTIVITY A " +
					"WHERE " +
						"C.CYCLE_ID = SC.CYCLE_ID AND " +
						"SC.SUB_CYCLE_ID = CO.SUB_CYCLE_ID AND " +
						"CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID AND " +
						"A.STATUS = ? AND " +
						"C.COUNTRY_ID = ? AND " +
						"C.PERIOD_ID = ?");
			
			getEstCompletionDate = con.prepareStatement
				("SELECT " +
					 "MAX(EST_COMPLETION_DATE) EST_COMPLETION_DATE " +
					"FROM " +
						"DEF_REF " +
					"WHERE " +
						"COUNTRY_ID = ? AND " +
						"PERIOD_ID = ? AND " +
						"WORLD_AREA_ID = ?");
			
			getTotalDefRef = con.prepareStatement
				("SELECT " +
						"COUNT(*) TOTAL_DEF_REF " +
					"FROM " +
						"DEF_REF " +
					"WHERE " +
						"COUNTRY_ID = ? AND " +
						"PERIOD_ID = ? AND " +
						"TYPE = 'SIGNIFICANT'");
			
			
			getOpenDefRef = con.prepareStatement
				("SELECT " +
					 "COUNT(AUDIT_REPORT_DATE) OPEN_DEF_REF " +
				 "FROM " +
				 	"DEF_REF " +
				 "WHERE " +
				 	"COUNTRY_ID = ? AND " +
				 	"PERIOD_ID = ? AND " +
				 	"TYPE = 'SIGNIFICANT'");
			
		 	
		 	ResultSet rsPeriodId;
		 	
			rsPeriodId = getPeriodIDs.executeQuery();
			
			while(rsPeriodId.next()){
				
				//**Select all the period same or before the current-period-selected...
				if(rsPeriodId.getString("PERIOD_ID").equals(currentPeriodID)){
					periodIDs.add(rsPeriodId.getString("PERIOD_ID"));
					break;
				}
				else{
					periodIDs.add(rsPeriodId.getString("PERIOD_ID"));
				}
			}
			
			//**Total-Calc
			
			int[] totalMonsanto = new int[periodIDs.size()];
			int[] openMonsanto = new int[periodIDs.size()];
			
			int[] totalIntl = new int[periodIDs.size()];
			int[] openIntl = new int[periodIDs.size()];
			
			ResultSet rsWorldArea;
			
			rsWorldArea = getWorldArea.executeQuery();
			
			//**#nested:root
			while(rsWorldArea.next()){
				
				int[] totalWorld = new int[periodIDs.size()];
				int[] openWorld = new int[periodIDs.size()];
				
				WorldAreaObject worldObj = new WorldAreaObject();
				
				String currWorldID = rsWorldArea.getString("WORLD_AREA_ID").trim();
				worldObj.setWorldAreaName(currWorldID);
				
				Vector countryVector = new Vector();
				
				// #nested-level#2
				ResultSet rsCountry;
				
				getCountry.setString(1, currWorldID);
				
				rsCountry = getCountry.executeQuery();
				
				while(rsCountry.next()){
					CountryObject countryObj = new CountryObject();
					
					String currCountryID = rsCountry.getString("COUNTRY_ID");
					
					//country-name
					countryObj.setCountryName(currCountryID);
					
					//total-activities
					ResultSet rsTotalAct;
					
					getTotalActivities.setString(1, currCountryID);
					getTotalActivities.setString(2, currentPeriodID);
					
					rsTotalAct = getTotalActivities.executeQuery();
					
					int totalAct = 0;
					while(rsTotalAct.next()){
						totalAct = rsTotalAct.getInt("TOTAL_ACTIVITIES");
					}
					
					worldObj.addToTotalActivities(totalAct);
					
					if(currWorldID.equalsIgnoreCase("NALAN")){
						totalNALAN += totalAct;
					}
					else{
						totalInternational += totalAct;
					}
					
					countryObj.setTotalActivities(totalAct);
					
					//activity-percent-complete
					ResultSet rsCompleteAct;
					
					getTotalActivitiesComplete.setString(1, SoxicConstants.COMPLETE.toUpperCase());
					getTotalActivitiesComplete.setString(2, currCountryID);
					getTotalActivitiesComplete.setString(3, currentPeriodID);
					
					rsCompleteAct = getTotalActivitiesComplete.executeQuery();
					
					int totalComplete = 0;
					while(rsCompleteAct.next()){
						totalComplete = rsCompleteAct.getInt("TOTAL_ACTIVITIES_COMPLETE");
					}
					
					try{
						countryObj.setActivityPercentageComplete( (totalComplete * 100)/totalAct );
					}
					catch(ArithmeticException ax){
						//**Possiblity of Divide-by-zero exception...
						countryObj.setActivityPercentageComplete(0);
					}
					
					//est-complete-date					
					ResultSet rsEstDate;
					
					getEstCompletionDate.setString(1, currCountryID);
					getEstCompletionDate.setString(2, currentPeriodID);
					getEstCompletionDate.setString(3, currWorldID);
					
					rsEstDate = getEstCompletionDate.executeQuery();
					
					while(rsEstDate.next()){
						countryObj.setEstimatedCompletionDate(rsEstDate.getDate("EST_COMPLETION_DATE"));
					}
					
					//period-vector
					Vector periodVector = new Vector();
					
					Vector intlPeriodVector = new Vector();					
					Vector totalPeriodVector = new Vector();
					Vector worldPeriodVector = new Vector();
					
					for(int idx = 0; idx < periodIDs.size(); idx++){
						
						PeriodObject periodObj = new PeriodObject();
						
						PeriodObject intlPeriodObj = new PeriodObject();
						PeriodObject worldPeriodObj = new PeriodObject();
						PeriodObject totalPeriodObj = new PeriodObject();
						
						//period-id
						periodObj.setPeriodID(periodIDs.get(idx).toString());
						
						//total-def-ref
						ResultSet rsTotalDefRef;
						
						getTotalDefRef.setString(1, currCountryID);
						getTotalDefRef.setString(2, periodIDs.get(idx).toString());
						
						rsTotalDefRef = getTotalDefRef.executeQuery();
						
						int totalDefRef = 0;
						while(rsTotalDefRef.next()){
							totalDefRef = rsTotalDefRef.getInt("TOTAL_DEF_REF");
						}
						periodObj.setTotalDefRef(totalDefRef);
						
						//totalPeriodObj.incTotalDefRef(totalDefRef);						
						totalMonsanto[idx] += totalDefRef;
						totalPeriodObj.setTotalDefRef(totalMonsanto[idx]);
						
						//worldPeriodObj.incTotalDefRef(totalDefRef);
						totalWorld[idx] += totalDefRef;
						worldPeriodObj.setTotalDefRef(totalWorld[idx]);
						
						
						if(!currWorldID.equalsIgnoreCase("NALAN")){
							//intlPeriodObj.incTotalDefRef(totalDefRef);
							totalIntl[idx] += totalDefRef;
						}
						intlPeriodObj.setTotalDefRef(totalIntl[idx]);
						
						//open-def-ref
						ResultSet rsOpenDefRef;
						
						getOpenDefRef.setString(1, currCountryID);
						getOpenDefRef.setString(2, periodIDs.get(idx).toString());
						
						rsOpenDefRef = getOpenDefRef.executeQuery();
						
						int openDefRef = 0;
						while(rsOpenDefRef.next()){
							openDefRef = rsOpenDefRef.getInt("OPEN_DEF_REF");
						}
						periodObj.setOpenDefRef(openDefRef);
						
						//totalPeriodObj.incOpenDefRef(openDefRef);						
						openMonsanto[idx] += openDefRef;
						totalPeriodObj.setOpenDefRef(openMonsanto[idx]);
						
						//worldPeriodObj.incOpenDefRef(openDefRef);
						openWorld[idx] += openDefRef;
						worldPeriodObj.setOpenDefRef(openWorld[idx]);
						
						if(!currWorldID.equalsIgnoreCase("NALAN")){
							//intlPeriodObj.incOpenDefRef(openDefRef);
							openIntl[idx] += openDefRef;
							
						}
						intlPeriodObj.setOpenDefRef(openIntl[idx]);
						
						
						intlPeriodVector.add(idx, intlPeriodObj);
						totalPeriodVector.add(idx, totalPeriodObj);						
						worldPeriodVector.add(idx, worldPeriodObj);
						
						periodVector.add(idx, periodObj);
					}
					
					intlData.setPeriodVector(intlPeriodVector);
					totalData.setPeriodVector(totalPeriodVector);
					worldObj.setWorldPeriodVector(worldPeriodVector);
					
					countryObj.setPeriodVector(periodVector);
					countryVector.add(countryObj);
				}
				
				
				
				
				worldObj.setCountryVector(countryVector);
				worldAreaVector.add(worldObj);
				
				logger.info("Done populating info for one world-area.");
			}
			
		}
		catch(Exception ex){
			logger.fatal("Database connection from cycle action " + ex.getMessage());
		}
		
		//**Testing...
		cycleReportForm.setPeriodList(periodIDs);
		
		
		cycleReportForm.setTotalNALAN(totalNALAN);
		cycleReportForm.setTotalInternational(totalInternational);
		
		cycleReportForm.setIntlData(intlData);
		cycleReportForm.setTotalData(totalData);
		
		cycleReportForm.setWorldAreaVector(worldAreaVector);
		
		return mapping.findForward("success");
		
	}

}