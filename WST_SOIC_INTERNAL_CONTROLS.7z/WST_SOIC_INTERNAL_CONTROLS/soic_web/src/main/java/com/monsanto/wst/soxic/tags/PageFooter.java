package com.monsanto.wst.soxic.tags;

import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.NewsItem;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
import java.util.List;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vlarter
 * Date: Aug 15, 2005
 * Time: 2:50:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class PageFooter extends SimpleTagSupport {
    private String name = "";
    private String contextpath = "";
    private Owner owner = null;

    public void doTag() throws JspException, IOException {
        getJspContext().getOut().write(buildNavHTMLString());
    }

    private String buildNavHTMLString() {
        StringBuffer tagContent = new StringBuffer();

        tagContent.append(buildUserCenterAndNews());
        tagContent.append(buildFooter());

        return tagContent.toString();
    }

    private String buildUserCenterAndNews() {
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append(buildUCNewsStart());
        htmlBuffer.append(buildUserCenter());
        htmlBuffer.append(buildNews());
        htmlBuffer.append(buildUCNewsEnd());

        return htmlBuffer.toString();
    }

    private String buildUCNewsStart() {
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append("<!-- User Center & News Starts -->\n");
        htmlBuffer.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
        htmlBuffer.append("<tr>\n");
        htmlBuffer.append("<td><img src=\"" + contextpath + "/images/user_center_hdr.gif\" width=\"221\" height=\"18\" alt=\"\" border=\"0\"></td>\n");
        htmlBuffer.append("<td class=\"user_rule\" nowrap></td>\n");
        htmlBuffer.append("<td><img src=\"" + contextpath + "/images/latest_news_hdr.gif\" width=\"125\" height=\"18\" alt=\"\" border=\"0\"></td>\n");
        htmlBuffer.append("<td class=\"date\">\n");
        htmlBuffer.append("<b>Today:&nbsp;</b> <script language=\"javascript\">\n");
        htmlBuffer.append("todaysDate = new Date(); dayarray = new\n");
        htmlBuffer.append("Array(\"Sunday\", \"Monday\", \"Tuesday\", \"Wednesday\", \"Thursday\", \"Friday\", \"Saturday\");\n");
        htmlBuffer.append("montharray = new Array(\"January\", \"February\", \"March\", \"April\", \"May\", \"June\", \"July\", \"August\", \"September\", \"October\", \"November\", \"December\");\n");
        htmlBuffer.append("document.write(dayarray[todaysDate.getDay()] + \", \" + montharray[todaysDate.getMonth()] + \" \" + todaysDate.getDate() + \", \");\n");
        htmlBuffer.append("if(todaysDate.getYear() <1000){ document.write(todaysDate.getYear() + 1900); };\n");
        htmlBuffer.append("else { document.write(todaysDate.getYear());\n}\n");
        htmlBuffer.append("</script></td>\n");
        htmlBuffer.append("</tr>\n<tr>\n");

        return htmlBuffer.toString();
    }

    private String buildUserCenter() {
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append("<td class=\"user_center\">\n");
        htmlBuffer.append(owner.getName() + "<br />");
        htmlBuffer.append("<b>User Role:</b> " + owner.getRole() + "<br />");
        htmlBuffer.append("<b>Last Login:</b> " + owner.getLastLogin() + "<br />");
        htmlBuffer.append("</td>\n");
        htmlBuffer.append("<td class=\"user_rule\" nowrap></td>\n");

        return htmlBuffer.toString();
    }

    private String buildNews() {
        StringBuffer htmlBuffer = new StringBuffer();
        List newsList = owner.getNewsList();

        htmlBuffer.append("<td colspan=\"2\" class=\"latest_news\">\n");
        Iterator iterNews = newsList.iterator();

        while(iterNews.hasNext()) {
            NewsItem newsItem = (NewsItem) iterNews.next();
            htmlBuffer.append("<table>");
            htmlBuffer.append("<tr><td><u><b>" + newsItem.getTitle() + ":</b></u></td></tr>");
            htmlBuffer.append("<tr><td><font color=\"red\">" + newsItem.getBody() + "</font></td></tr>");
            htmlBuffer.append("</table>");
        }

        htmlBuffer.append("\n");
        htmlBuffer.append("</td>\n");

        return htmlBuffer.toString();
    }

    private String buildUCNewsEnd() {
        return "</tr>\n</table>\n<!-- User Center & News Ends -->\n";
    }

    private String buildFooter() {
        String siteOwnerName = SoxicUtil.getSiteOwnerName();
        String buildNumber = SoxicUtil.getBuildNumber();
        String siteOwnerEMail = SoxicUtil.getSiteOwnerEMail();
        StringBuffer htmlBuffer = new StringBuffer();

        htmlBuffer.append("<!-- Footer Starts -->\n");
        htmlBuffer.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"footer\">\n");
        htmlBuffer.append("<tr\n>");
        htmlBuffer.append("<td class=\"last_mod\">Last Modified: <SCRIPT LANGUAGE=\"JavaScript\" TYPE=\"text/javascript\">");
        htmlBuffer.append("document.write(document.lastModified);</SCRIPT></td>\n");
        htmlBuffer.append("<td class=\"site_contact\"><b>Site Owner: </b><a href=\"" + siteOwnerEMail + "\" class=\"ftr_link\">" + siteOwnerName + "</a></td>\n");
      htmlBuffer.append("<td class=\"site_contact\"><b>Build Number: </b>" + buildNumber + "</td>\n");
        htmlBuffer.append("</tr>\n</table>\n<!-- Footer Ends -->\n");

        return htmlBuffer.toString();
    }

   public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContextpath() {
        return contextpath;
    }

    public void setContextpath(String contextpath) {
        this.contextpath = contextpath;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }
}
