/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerDeleteForm extends ActionForm{
    
    private String user;
       
	private List   changes;
	
	
	private String[] cycles;
	private String[] subCycles;
	private String[] activities;
	
	private String[] selectedCycles = {};
	private String[] selectedSubCycles = {};
	private String[] selectedActivities = {};
	
	
    /**
     * @return Returns the cycles.
     */
    public String[] getCycles() {
        return cycles;
    }
    /**
     * @param cycles The cycles to set.
     */
    public void setCycles(String[] cycles) {
        this.cycles = cycles;
    }
  
    
    /**
     * @return Returns the selectedActivities.
     */
    public String[] getSelectedActivities() {
        return selectedActivities;
    }
    /**
     * @param selectedActivities The selectedActivities to set.
     */
    public void setSelectedActivities(String[] selectedActivities) {
        this.selectedActivities = selectedActivities;
    }
    /**
     * @return Returns the selectedCycles.
     */
    public String[] getSelectedCycles() {
        return selectedCycles;
    }
    /**
     * @param selectedCycles The selectedCycles to set.
     */
    public void setSelectedCycles(String[] selectedCycles) {
        this.selectedCycles = selectedCycles;
    }
   
    /**
     * @return Returns the selectedSubCycles.
     */
    public String[] getSelectedSubCycles() {
        return selectedSubCycles;
    }
    /**
     * @param selectedSubCycles The selectedSubCycles to set.
     */
    public void setSelectedSubCycles(String[] selectedSubCycles) {
        this.selectedSubCycles = selectedSubCycles;
    }
    /**
     * @return Returns the subCycles.
     */
    public String[] getSubCycles() {
        return subCycles;
    }
    /**
     * @param subCycles The subCycles to set.
     */
    public void setSubCycles(String[] subCycles) {
        this.subCycles = subCycles;
    }
   
    /**
     * @return Returns the activities.
     */
    public String[] getActivities() {
        return activities;
    }
    /**
     * @param activities The activities to set.
     */
    public void setActivities(String[] activities) {
        this.activities = activities;
    }
    /**
     * @return Returns the changes.
     */
    public List getChanges() {
        return changes;
    }
    /**
     * @param changes The changes to set.
     */
    public void setChanges(List changes) {
        
        this.changes = changes;
                
    }
    
    
    public void reset(ActionMapping mapping, HttpServletRequest request){
        
        
        if(selectedCycles != null){

            selectedCycles = new String[0];
        }
        
        if(selectedSubCycles != null){

            selectedSubCycles = new String[0];
        }
        
        if(selectedActivities != null){

            selectedActivities = new String[0];
        }
           
    }
    /**
     * @return Returns the user.
     */
    public String getUser() {
        return user;
    }
    /**
     * @param user The user to set.
     */
    public void setUser(String user) {
        this.user = user;
    }
}
