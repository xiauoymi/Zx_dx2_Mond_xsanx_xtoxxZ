/*
 * Created on Mar 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.NewsItem;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleAdminNewsDAO {
    
    public static List getAllNews() throws DatabaseException{
        
        List allNews = new ArrayList();
        
        
        String query = "SELECT NEWS_ID, SUBJECT, BODY FROM NEWS ";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        NewsItem item = null;
	
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
		
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                item = new NewsItem();
                item.setId(resultSet.getString("NEWS_ID"));
                item.setTitle(resultSet.getString("SUBJECT"));
                item.setBody(resultSet.getString("BODY"));
                item.setAssignedRoles(getAssignedRoles(resultSet.getString("NEWS_ID")));
                
                allNews.add(item);
               
            }
            
           		
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
     
        
       return allNews;
        
    }
    
    public static NewsItem  getNews(String newsId) throws DatabaseException{
        
        NewsItem news = new NewsItem();
        
        String query = "SELECT NEWS_ID, SUBJECT, BODY FROM NEWS WHERE NEWS_ID='"+ newsId + "'";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        NewsItem item = null;
	
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
		
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                news.setId(resultSet.getString("NEWS_ID"));
                news.setTitle(resultSet.getString("SUBJECT"));
                news.setBody(resultSet.getString("BODY"));
                news.setAssignedRoles(getAssignedRoles(resultSet.getString("NEWS_ID")));
                              
            }
            
           		
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
     
        
       return news;
        
    }
    private static void getRoles(Map allNews)throws DatabaseException{
        
        if(allNews != null && !allNews.isEmpty()){
            
            Iterator itr = allNews.values().iterator();
            while(itr.hasNext()){
                NewsItem item = (NewsItem)itr.next();
                
                item.setAssignedRoles(getAssignedRoles(item.getId()));
            }
        }
    }
    
    private static List getAssignedRoles(String newsId) throws DatabaseException{
        
        List roles = new ArrayList();
              
        String query = "SELECT ROLE_ID FROM NEWS_ROLE WHERE NEWS_ID='"+ newsId +"'";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        NewsItem item = null;
	
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
		
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                roles.add(resultSet.getString("ROLE_ID"));
            }
            
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
     
        
       return roles;
        
    }
    
    public static List getAllRoles() throws DatabaseException{
        
        List roles = new ArrayList();
              
        String query = "SELECT ROLE_ID FROM ROLE";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        NewsItem item = null;
	
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
		
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                roles.add(resultSet.getString("ROLE_ID"));
            }
            
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
     
        
       return roles;
        
    }
    
    public static void update(NewsItem news) throws DatabaseException{
        
        List roles = new ArrayList();
              
        String query = "UPDATE NEWS SET BODY = '"+ news.getBody() +"' WHERE NEWS_ID = '"+ news.getId() +"'";
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try {
            
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();
            
            resultSet = statement.executeQuery(query);
            
            updateRoles(news, statement);
            
                       
        } 
        catch (SQLException e) {
           
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
           
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
         
    }

    private static void updateRoles(NewsItem news, Statement statement) throws DatabaseException{
        
        deleteRoles(news.getId(), statement);
                
        try {
            Iterator itr = news.getAssignedRoles().iterator();
            
            while(itr.hasNext()){
                
                String role = itr.next().toString();
                String query = "INSERT INTO NEWS_ROLE ( NEWS_ID, ROLE_ID ) VALUES ('"+ news.getId() + "', '"+ role +"')";
                statement.executeQuery(query);
            }
            
            
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
        
        
    }
    
    public static void delete(String newsId) throws DatabaseException{
        
        List roles = new ArrayList();
              
        String query = "DELETE FROM  NEWS WHERE NEWS_ID  = '"+ newsId +"'";
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try {
            
            connection = SoxicConnectionFactory.getSoxicConnection();
            statement = connection.createStatement();
            
            statement.executeQuery(query);
            
           deleteRoles(newsId, statement);
            
                       
        } 
        catch (SQLException e) {
           
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
           
            throw new DatabaseException(e.getMessage());
        } 
        finally {
            try {
                if (resultSet != null)
                    resultSet.close();
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                throw new DatabaseException("OracleDAO - Unable to close database connection : "
					+ e.toString());
            }
        }
         
    }

    
    private static void deleteRoles(String id, Statement statement) throws DatabaseException{
        
        
        String query = "DELETE FROM NEWS_ROLE WHERE NEWS_ID='"+id + "'";
        
        try {
            statement.executeQuery(query);
               
            
        } 
        catch (SQLException e) {
            throw new DatabaseException(e.getMessage());
        } 
        catch (Exception e) {
            throw new DatabaseException(e.getMessage());
        } 
             
    }
}
