/*
 DocChangesReportFacade was created on Jan 23, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.facade.reports;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.DocChangesReportDAO;
import com.monsanto.wst.soxic.model.OwnerStatusReportDAO;
import com.monsanto.wst.soxic.model.DocChangesReportDetailBean;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: DocChangesReportFacade.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-03-19 14:53:12 $
 *
 * @author emgoode
 * @version $Revision: 1.2 $
 */
public class DocChangesReportFacade {

    OwnerStatusReportDAO ownerStatusReportDAO = new OwnerStatusReportDAO();
    DocChangesReportDAO docChangesReportDao = new DocChangesReportDAO();

    private Connection getConnection() throws Exception {
        return SoxicConnectionFactory.getSoxicConnection();
    }

    public ArrayList getPeriodsInSystem() throws DatabaseException {
        return (ArrayList) ownerStatusReportDAO.getPeriods();
    }

    public ArrayList getCountriesInSystem() throws DatabaseException {
        return (ArrayList) ownerStatusReportDAO.getCountriesForCycle();
    }

    public ArrayList getDocChangesList(Connection connection, HashMap params) throws SQLException {
        return docChangesReportDao.getDocChangesBySearchParams(connection, params);
    }

    public ArrayList getCyclesInSystem(Connection connection) throws SQLException, WrappingException {
        return docChangesReportDao.getCyclesInSystem(connection);
    }

    public DocChangesReportDetailBean getDocChangeDetails(Connection connection, HashMap params) throws Exception {
        return docChangesReportDao.getDocChangeDetailsByRequestId(connection, params);
    }
}