package com.monsanto.wst.soxic.ownerStatusReports;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.soxic.model.OwnerStatus;
import com.monsanto.wst.soxic.model.ReportOwners;
import org.w3c.dom.Element;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Dec 22, 2005
 * Time: 9:06:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerStatusXMLBuilder {

    public void createXMLReport(Element rootElement,List reportInfo, String reportType) {
        Element rootOutputElement= DOMUtil.addChildElement(rootElement,"reportType");
        DOMUtil.setAttribute(rootOutputElement,"id",reportType);
        Iterator cycleIt = reportInfo.iterator();
        buildReportRoot(cycleIt,rootOutputElement);
    }

    private void buildReportRoot(Iterator cycleIt, Element rootOutputElement) {
        while(cycleIt.hasNext()){
            Element typeElement = DOMUtil.addChildElement(rootOutputElement,"type");
            OwnerStatus ownerStatus = (OwnerStatus)cycleIt.next();
            String cycleid = ownerStatus.getId();
            DOMUtil.addChildElement(typeElement,"typeid",cycleid);
            List ownerList = ownerStatus.getOwners();
            Iterator ownerIt = ownerList.iterator();
            buildOwnerInformation(ownerIt,typeElement);
        }
    }

    private void buildOwnerInformation(Iterator ownerIt, Element typeElement) {
        while(ownerIt.hasNext()){
            Element typeInfoElement = DOMUtil.addChildElement(typeElement,"typeinfo");
            typeElement.appendChild(typeInfoElement);
            ReportOwners reportOwners = (ReportOwners)ownerIt.next();
            String ownername = reportOwners.getOwner_name();
            String location = reportOwners.getLocation();
            String status = reportOwners.getStatus();
            DOMUtil.addChildElement(typeInfoElement,"owner",ownername);
            DOMUtil.addChildElement(typeInfoElement,"location",location);
            DOMUtil.addChildElement(typeInfoElement,"status",status);
        }
    }




}
