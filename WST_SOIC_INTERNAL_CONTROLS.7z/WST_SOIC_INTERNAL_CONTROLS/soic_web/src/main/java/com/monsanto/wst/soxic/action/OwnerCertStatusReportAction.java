package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.OwnerCertificationStatusReportForm;
import com.monsanto.wst.soxic.facade.reports.OwnerCertificationStatusReportFacade;
import com.monsanto.wst.soxic.facade.reports.OwnerStatusReportFacade;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jan 5, 2006
 * Time: 9:51:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerCertStatusReportAction extends Action{

    public ActionForward execute(ActionMapping mapping,
            					 ActionForm form,
            					 HttpServletRequest request,
            					 HttpServletResponse response) throws Exception{

        OwnerCertificationStatusReportForm ownerCertificationStatusReportForm = (OwnerCertificationStatusReportForm)form;
        OwnerStatusReportFacade ownerStatusReportFacade = new OwnerStatusReportFacade();

        ownerCertificationStatusReportForm.setAllPeriods(ownerStatusReportFacade.getAllPeriodsInSystem());

        return mapping.findForward("setPeriodsForOwnerCertStatus");
    }

}
