/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.sql.Date;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActivityTemplate {
	
	String ownerName;
	
	Date startDate;
	
	Date endDate;
	
	int gapsReported;

    String certificationStatus;



	/**
	 * @return Returns the endDate.
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate The endDate to set.
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return Returns the gapsReported.
	 */
	public int getGapsReported() {
		return gapsReported;
	}
	/**
	 * @param gapsReported The gapsReported to set.
	 */
	public void setGapsReported(int gapsReported) {
		this.gapsReported = gapsReported;
	}
	/**
	 * @return Returns the ownerName.
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName The ownerName to set.
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return Returns the startDate.
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate The startDate to set.
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

    public String getCertificationStatus() {
        return certificationStatus;
    }

    public void setCertificationStatus(String certificationStatus) {
        this.certificationStatus = certificationStatus;
    }
}
