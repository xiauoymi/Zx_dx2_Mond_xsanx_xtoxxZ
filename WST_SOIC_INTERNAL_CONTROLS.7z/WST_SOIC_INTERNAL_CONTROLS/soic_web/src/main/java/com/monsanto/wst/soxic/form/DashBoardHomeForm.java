package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 1, 2006
 * Time: 3:44:55 PM
 * To change this template use File | Settings | File Templates.
 */

public class DashBoardHomeForm extends ActionForm {

    private List cycles;
    private List subcycles;
    private List activities;

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public List getSubcycles() {
        return subcycles;
    }

    public void setSubcycles(List subcycles) {
        this.subcycles = subcycles;
    }

    public List getActivities() {
        return activities;
    }

    public void setActivities(List activities) {
        this.activities = activities;
    }
}
