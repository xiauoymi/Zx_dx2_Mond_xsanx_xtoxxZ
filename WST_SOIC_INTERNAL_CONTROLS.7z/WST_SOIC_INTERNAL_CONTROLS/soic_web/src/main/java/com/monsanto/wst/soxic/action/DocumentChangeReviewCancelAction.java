package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 23, 2005
 * Time: 9:37:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeReviewCancelAction extends Action{
    public ActionForward execute(ActionMapping mapping,
			 ActionForm form,
			 HttpServletRequest request,
			 HttpServletResponse response) throws Exception{
        String path = request.getParameter("path");
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;
        request.setAttribute("processedActivity",documentChangeReviewForm.getIdentifier());
        if(path.equalsIgnoreCase(SoxicConstants.DOC_CHANGE_MODE_NEW)){
            return mapping.findForward("new");
        }else{
           return mapping.findForward("review"); 
        }

    }
}
