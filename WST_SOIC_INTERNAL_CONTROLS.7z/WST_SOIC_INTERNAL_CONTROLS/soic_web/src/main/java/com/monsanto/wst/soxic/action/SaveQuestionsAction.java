package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.facade.QuestionAdminFacade;
import com.monsanto.wst.soxic.exception.InvalidLenghtException;
import com.monsanto.wst.soxic.exception.EmptyDataException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:43:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaveQuestionsAction extends Action {

    public ActionForward execute(
        ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response) throws InvalidLenghtException, EmptyDataException {

        QuestionAdminForm questionAdminForm = (QuestionAdminForm)form;
        QuestionAdminFacade questionAdminFacade = new QuestionAdminFacade();

        process(questionAdminFacade, questionAdminForm);

        return mapping.findForward("success");
    }

    public void process(QuestionAdminFacade questionAdminFacade, QuestionAdminForm questionAdminForm) throws InvalidLenghtException, EmptyDataException {
        try {
            questionAdminFacade.processQuestions(questionAdminForm);
        } catch (InvalidLenghtException e) {
            questionAdminFacade.displayQuestions(questionAdminForm);
            throw new InvalidLenghtException();
        } catch (EmptyDataException e) {
            questionAdminFacade.displayQuestions(questionAdminForm);
            throw new EmptyDataException();
        }

        questionAdminFacade.saveUpdatedQuestions(questionAdminForm);
    }

}
