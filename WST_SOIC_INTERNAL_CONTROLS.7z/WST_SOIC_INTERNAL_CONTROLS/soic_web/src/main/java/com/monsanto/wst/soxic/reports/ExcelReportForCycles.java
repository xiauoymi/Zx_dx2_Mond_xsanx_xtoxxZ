package com.monsanto.wst.soxic.reports;

import com.monsanto.wst.soxic.action.Export2Excel;
import com.monsanto.wst.soxic.form.ReportForm;
import com.monsanto.wst.soxic.form.RowObject;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: JBECERR
 * Date: 27/05/2011
 * Time: 10:06:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelReportForCycles {

    private BufferedOutputStream bos;
    private HSSFWorkbook wb;
    private Export2Excel export2Excel;

    private void populateForm (ReportForm reportForm) {
        String sub_cycle_id = reportForm.getSubCycleID();
        Vector columnData = new Vector();
        String coId = "";
        Connection con=null;

        try{
            con = SoxicConnectionFactory.getSoxicConnection();

            //**Prepared Statements...
            PreparedStatement getSubCycleActivities;
            PreparedStatement getCountryWorld;
            PreparedStatement getSubCycleOwner;
            PreparedStatement getCycleOwner;
            PreparedStatement getSubCycleDesc;
            PreparedStatement getActivityCodes;
            PreparedStatement getGapDescription;
            PreparedStatement getOwners;
            PreparedStatement getLocations;

            //****************CHUNKING********************************************************************
            PreparedStatement getActivityDescChunk;
            PreparedStatement getCODescChunk;

            getActivityDescChunk = con.prepareStatement
                ("SELECT " +
                        "T.TEXT_CHUNK " +
                    "FROM " +
                        "ACTIVITY A, TEXT_OVERFLOW T " +
                    "WHERE " +
                        "A.ACTIVITY_ID = ? AND " +
                        "T.OVERFLOW_ID = A.OVERFLOW_ID " +
                    "ORDER BY T.SEQUENCE");

            getCODescChunk = con.prepareStatement
                ("SELECT " +
                        "T.TEXT_CHUNK " +
                    "FROM " +
                        "CTRL_OBJ C, TEXT_OVERFLOW T " +
                    "WHERE " +
                        "C.CTRL_OBJ_ID = ? AND " +
                        "T.OVERFLOW_ID = C.OVERFLOW_ID    ORDER BY T.SEQUENCE");

             getSubCycleActivities = con.prepareStatement
                ("SELECT " +
                        "A.ACTIVITY_ID, A.PRIORITY, CO.DESCRIPTION DESC1, " +
                        "A.DESCRIPTION DESC2, CO.RISK, O.OWNER_ID, O.LOCATION, CO.CTRL_OBJ_ID " +
                 "FROM " +
                         "CTRL_OBJ CO, ACTIVITY A, OWNER O, OWNER_ACTIVITY OA " +
                 "WHERE " +
                         "CO.SUB_CYCLE_ID = ? AND A.CTRL_OBJ_ID = CO.CTRL_OBJ_ID AND " +
                         "A.ACTIVITY_ID = OA.ACTIVITY_ID AND O.OWNER_ID = OA.OWNER_ID ORDER BY A.ACTIVITY_ID");


            /**
             * @author rgeorge
             * get the activity codes & control objective codes based on activity_id
             * & subcycle_id
             */
            getActivityCodes = con.prepareStatement
                    ("SELECT COC.TYPE, COC.CODE " +
                    "  FROM ACTIVITY A, CTRL_OBJ CO, CTRL_OBJ_CODES COC " +
                    " WHERE CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                    "   AND A.ACTIVITY_ID = COC.ACTIVITY_ID " +
                    "   AND CO.SUB_CYCLE_ID = ? AND COC.ACTIVITY_ID = ?");

            getCountryWorld = con.prepareStatement
                    ("SELECT " +
                            "CY.COUNTRY_ID, CY.WORLD_AREA_ID, CY.DESCRIPTION, CY.PERIOD_ID " +
                     "FROM " +
                         "CYCLE CY, SUB_CYCLE SC " +
                     "WHERE " +
                         "SC.SUB_CYCLE_ID = ? AND " +
                         "SC.CYCLE_ID = CY.CYCLE_ID");


            getSubCycleOwner = con.prepareStatement
                 ("SELECT DISTINCT " +
                         "O.OWNER_ID " +
                 "FROM " +
                     "OWNER O, SUB_CYCLE SC, OWNER_SUB_CYCLE OSC " +
                 "WHERE " +
                     "SC.SUB_CYCLE_ID = ? AND " +
                     "SC.SUB_CYCLE_ID = OSC.SUB_CYCLE_ID AND " +
                     "OSC.OWNER_ID = O.OWNER_ID");

            getCycleOwner = con.prepareStatement
                  ("SELECT DISTINCT " +
                          "O.OWNER_ID " +
                  "FROM " +
                      "OWNER O, SUB_CYCLE SC, OWNER_CYCLE OC, CYCLE C " +
                  "WHERE " +
                      "SC.SUB_CYCLE_ID = ? AND " +
                      "SC.CYCLE_ID = C.CYCLE_ID AND " +
                      "C.CYCLE_ID = OC.CYCLE_ID AND " +
                      "OC.OWNER_ID = O.OWNER_ID");


            getSubCycleDesc = con.prepareStatement("SELECT " +
                        "SC.DESCRIPTION " +
                    "FROM " +
                        "SUB_CYCLE SC " +
                    "WHERE " +
                        "SC.SUB_CYCLE_ID = ?");


            /**
             * @author rgeorge
             * query to select the gaps depending on the activity_id
             */
            getGapDescription = con.prepareStatement
                    ("SELECT OWR.ASSOCIATED_ID, G.DESCRIPTION " +
                    "FROM OWNER_RESPONSE OWR, GAP_DC_LOE G, ACTIVITY A, CTRL_OBJ CO " +
                    "WHERE OWR.RESPONSE_ID = G.RESPONSE_ID " +
                    "AND A.ACTIVITY_ID = OWR.ASSOCIATED_ID " +
                    "AND CO.CTRL_OBJ_ID = A.CTRL_OBJ_ID " +
                    "AND CO.SUB_CYCLE_ID = ? " +
                    "AND A.ACTIVITY_ID = ?");


            getSubCycleActivities.setString(1, sub_cycle_id);
            ResultSet rs = getSubCycleActivities.executeQuery();

            //**For not displaying same CODesc/risk for same CoID
            String tempcoId = "";

            String actId = "";
            String tempActId = "";
            String lastActId = "";
            String catstring = "";
            String codestring = "";
            String gapdesc = "";
            String ownerids = "";
            String locations = "";

            RowObject row1;
            RowObject row2;

            while (rs.next()) {

                RowObject rowObject = new RowObject();

                tempActId = rs.getString("ACTIVITY_ID");

                tempcoId = rs.getString("CTRL_OBJ_ID");

                rowObject.setCol1(rs.getString("ACTIVITY_ID") + "");

                if(rs.getString("PRIORITY") != null){
                    rowObject.setCol9(rs.getString("PRIORITY"));
                }
                else{
                    rowObject.setCol9("");
                }

                if(rs.getString("DESC1") != null){
                        //rowObject.setCol2( rs.getString("DESC1") + "");

                        String completeCODesc = "";
                        completeCODesc = rs.getString("DESC1") + "";

                        //*************************************CHUNKING*********************************************
                        try{
                            getCODescChunk.setString(1, rs.getString("CTRL_OBJ_ID").toString());
                            ResultSet rsCOChunk = getCODescChunk.executeQuery();

                            while(rsCOChunk.next()){
                                completeCODesc += rsCOChunk.getString("TEXT_CHUNK");
                            }
                        }
                        catch(Exception sqle){
                            sqle.printStackTrace();
                        }
                        //******************************************************************************************

                        rowObject.setCol2(completeCODesc);
                }

                getActivityCodes.setString(1, sub_cycle_id);
                getActivityCodes.setString(2, tempActId);
                ResultSet rs1 = getActivityCodes.executeQuery();

                while (rs1.next()){
                    if((rs1.getString("TYPE") != null) && (rs1.getString("TYPE").equalsIgnoreCase("CATEGORY"))){
                        if(catstring.length()==0) {
                            catstring = catstring + rs1.getString("CODE");
                        } else{
                                catstring = catstring + "," + rs1.getString("CODE");
                        }
                    }
                    else if((rs1.getString("TYPE") != null) && (rs1.getString("TYPE").equalsIgnoreCase("CODE"))){
                        if(codestring.length()==0) {
                            codestring = codestring + rs1.getString("CODE");
                        } else{
                                codestring = codestring + "," + rs1.getString("CODE");
                        }
                    }
                }

                rowObject.setCol3(catstring);
                catstring = "";
                rowObject.setCol4(codestring);
                codestring = "";

                if(rs.getString("DESC2") != null){

                    String completeActivityDesc = "";
                    completeActivityDesc = rs.getString("DESC2") + "";

                    //*************************************CHUNKING*********************************************
                    try{
                        getActivityDescChunk.setString(1, rs.getString("ACTIVITY_ID").toString());
                        ResultSet rsActivityChunk = getActivityDescChunk.executeQuery();

                        while(rsActivityChunk.next()){
                            completeActivityDesc += rsActivityChunk.getString("TEXT_CHUNK");
                        }
                    }
                    catch(Exception sqle){
                        sqle.printStackTrace();
                    }
                    //******************************************************************************************

                    rowObject.setCol5(completeActivityDesc);
                }
                else{
                    rowObject.setCol5("");
                }


                    if(rs.getString("RISK")!=null){
                        rowObject.setCol6( rs.getString("RISK") + "");
                        coId = tempcoId;
                    }else{
                         rowObject.setCol6("");
                        coId = tempcoId;
                    }


                if(rs.getString("OWNER_ID") != null){
                    rowObject.setCol7(rs.getString("OWNER_ID"));
                }
                else{
                    rowObject.setCol7(rs.getString(""));
                }


                if(rs.getString("LOCATION") != null){
                    rowObject.setCol8(rs.getString("LOCATION"));
                }
                else{
                    rowObject.setCol8("");
                }

                getGapDescription.setString(1, sub_cycle_id);
                getGapDescription.setString(2, tempActId);
                ResultSet rsg = getGapDescription.executeQuery();

                while (rsg.next()){
                    if (rsg.getString("DESCRIPTION")!= null){
                        if(gapdesc.length()==0) {
                            gapdesc = gapdesc + rsg.getString("DESCRIPTION");
                            } else{
                                gapdesc = gapdesc + "," + rsg.getString("DESCRIPTION");
                            }
                        rowObject.setCol12(gapdesc);
                    }

                }
                gapdesc = "";

                columnData.add(rowObject);

                //**check for dup ActId with multiple users...
                if(tempActId.equals(actId)){
                    //**Modify user/loc of current one and Remove prev one...
                    row1 = (RowObject)columnData.get(columnData.size() - 2);
                    row2 = (RowObject)columnData.get(columnData.size() -1 );

                    row2.setCol7(row1.getCol7() + ",\u0020" + row2.getCol7());
                    row2.setCol8(row1.getCol8() + ",\u0020" + row2.getCol8());

                    columnData.removeElementAt(columnData.size() - 2);

                }

                actId = tempActId;

            }

            String countryId = "";
            String worldArea = "";

            Vector subcycleOwner = new Vector();
            Vector cycleOwner = new Vector();

            //**Country, World Area...
            getCountryWorld.setString(1, sub_cycle_id);
            rs = getCountryWorld.executeQuery();


            String cycleDesc = "";
            String periodID = "";
            while(rs.next()){
                countryId = rs.getString("COUNTRY_ID");
                worldArea = rs.getString("WORLD_AREA_ID");
                cycleDesc = rs.getString("DESCRIPTION");
                periodID = rs.getString("PERIOD_ID");
            }

            //**Sub Cycle Owners...
            getSubCycleOwner.setString(1, sub_cycle_id);
            rs = getSubCycleOwner.executeQuery();

            while(rs.next()){
                subcycleOwner.add(rs.getString("OWNER_ID"));
            }

            //**Cycle Owners...
            getCycleOwner.setString(1, sub_cycle_id);
            rs = getCycleOwner.executeQuery();

            while(rs.next()){
                cycleOwner.add(rs.getString("OWNER_ID"));
            }


            //**Cycle Owners...
            getSubCycleDesc.setString(1, sub_cycle_id);
            rs = getSubCycleDesc.executeQuery();

            String subCycleDesc = "";
            while(rs.next()){
                subCycleDesc = rs.getString("DESCRIPTION");
            }


            // generate the excel file
            reportForm.setColumnVector(columnData);
            reportForm.setPeriodID(periodID);
            reportForm.setCycleDesc(cycleDesc);
            reportForm.setSubCycleDesc(subCycleDesc);
            reportForm.setCountryId(countryId);
            reportForm.setWorldArea(worldArea);
            reportForm.setSubCycleOwners(subcycleOwner);
            reportForm.setCycleOwners(cycleOwner);

        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            try{
                if(con!=null && !con.isClosed()){
                    con.close();
                }
            }catch(Exception e){

            }
        }

    } // end of populateForm method


    private void exportReport(ReportForm reportForm, boolean isNewCycle, String cycleId) throws Exception{

        export2Excel.setCycleId(cycleId);
        export2Excel.setColumnVector(reportForm.getColumnVector());
        export2Excel.setCountryId(reportForm.getCountryId());
        export2Excel.setCycleOwners(reportForm.getCycleOwners());
        export2Excel.setSubCycleOwners(reportForm.getSubCycleOwners());
        export2Excel.setWorldArea(reportForm.getWorldArea());
        export2Excel.setCycleDesc(reportForm.getCycleDesc());
        export2Excel.setSubCycleDesc(reportForm.getSubCycleDesc());
        export2Excel.setCycleOwnerList(reportForm.getCycleOwnerList());
        export2Excel.setSubCycleOwnerList(reportForm.getSubCycleOwnerList());
        export2Excel.setGap_Description(reportForm.getGap_description());
        export2Excel.export(wb, isNewCycle);
        export2Excel.getBos().flush();

    }

    private Collection<String> getSubCycles(String cycleId) throws Exception {
        Connection con=null;
        Vector result = new Vector();
        try{
            con = SoxicConnectionFactory.getSoxicConnection();

            PreparedStatement getSubCycles;

            getSubCycles = con.prepareStatement("select sub_cycle_id from sub_cycle where cycle_id = ? order by sub_cycle_id");
            getSubCycles.setString(1,cycleId);

            ResultSet rs = getSubCycles.executeQuery();
            while(rs.next()) {
                result.add(rs.getString("sub_cycle_id"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try{
                if(con!=null && !con.isClosed()){
                    con.close();
                }
            }catch(Exception e){

            }
        }
        return  result;
    }

    private Collection getCycles(String periodId) throws Exception {
        Connection con=null;
        Vector result = new Vector();
        try{
            con = SoxicConnectionFactory.getSoxicConnection();

            PreparedStatement getCycles;

            getCycles = con.prepareStatement("select cycle_id from cycle where period_id = ? ");
            getCycles.setString(1,periodId);

            ResultSet rs = getCycles.executeQuery();
            while(rs.next()) {
               result.add(rs.getString("cycle_id"));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try{
                if(con!=null && !con.isClosed()){
                    con.close();
                }
            }catch(Exception e){

            }
        }
        return result;
    }

    public void processPeriod(String periodId) throws Exception {
        bos = new BufferedOutputStream(new FileOutputStream(periodId+".xls"));
        wb = new HSSFWorkbook();
        export2Excel = new Export2Excel(periodId+".xls");
        
        export2Excel.setBos(this.bos);

        // Commented to test a single cycle
        Collection<String> cycles = getCycles(periodId);
//        Vector<String> cycles = new Vector();
//        cycles.add("FY08-Q2.ARG.EXP");
//        cycles.add("FY08-Q2.MEX.BU");

        Iterator<String> itCycles = cycles.iterator();
        boolean newCycle = false;
        while(itCycles.hasNext()) {
            String cycleId = itCycles.next();
            newCycle = true;
            Collection<String> subCycles = getSubCycles(cycleId);
            Iterator<String> itSubCycles = subCycles.iterator();
            while(itSubCycles.hasNext()) {
                String subCycleId = itSubCycles.next();

                ReportForm reportForm = new ReportForm();
                reportForm.setSubCycleID(subCycleId);
                populateForm(reportForm);
                exportReport(reportForm,  newCycle, cycleId);
                newCycle = false;
            }
        }
        wb.write(export2Excel.getBos());
        export2Excel.getBos().flush();
        export2Excel.getBos().close();
    } // end of processPeriod method


    public static void main(String args[]) throws Exception{

        if(args.length != 1) {
            System.out.println("Usage: ExcelReportForCycles [periodId]");
        } else {
            System.out.println("Processiong periodId: " + args[0]);
            ExcelReportForCycles report = new ExcelReportForCycles();
            report.processPeriod(args[0]);
            System.out.println("Finished...");
        }

    } // end of main method


} // end of class
