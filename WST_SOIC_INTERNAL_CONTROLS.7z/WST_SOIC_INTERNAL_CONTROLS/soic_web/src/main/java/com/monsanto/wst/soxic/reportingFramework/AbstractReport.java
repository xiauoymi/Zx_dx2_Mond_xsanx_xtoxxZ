package com.monsanto.wst.soxic.reportingFramework;

import org.w3c.dom.Document;
import com.monsanto.wst.soxic.exception.DatabaseException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 7, 2005
 * Time: 10:18:25 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract  class AbstractReport {

//    public abstract Document buildReportXML(ReportParameters reportParameters) throws DatabaseException;
//
//    public abstract Document buildFilterXML() throws DatabaseException;

    public abstract Document buildReportXML(ReportParameters reportParameters, ReportProperties reportProperties) throws DatabaseException;

    public abstract Document buildFilterXML(ReportParameters reportParameters, ReportProperties reportProperties) throws DatabaseException;

    public abstract String returnExportFileNameKey();
}
