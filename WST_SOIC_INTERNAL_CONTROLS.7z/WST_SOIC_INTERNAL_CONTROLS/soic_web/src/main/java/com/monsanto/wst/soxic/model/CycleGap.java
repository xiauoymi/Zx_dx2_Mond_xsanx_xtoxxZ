/*
 * Created on Mar 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CycleGap {
	
	private String cycleId;
	
	private String ownerId;
	
	private List gapList = new ArrayList();
	
	private List subCycleGapList = new ArrayList();	
	
	/**
	 * @return Returns the cycleId.
	 */
	public String getCycleId() {
		return cycleId;
	}
	/**
	 * @param cycleId The cycleId to set.
	 */
	public void setCycleId(String cycleId) {
		this.cycleId = cycleId;
	}
	/**
	 * @return Returns the gapList.
	 */
	public List getGapList() {
		return gapList;
	}
	/**
	 * @param gapList The gapList to set.
	 */
	public void setGapList(List gapList) {
		this.gapList = gapList;
	}
	/**
	 * @return Returns the ownerId.
	 */
	public String getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId The ownerId to set.
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	
	/**
	 * @return Returns the subCycleGapList.
	 */
	public List getSubCycleGapList() {
		return subCycleGapList;
	}
	/**
	 * @param subCycleGapList The subCycleGapList to set.
	 */
	public void setSubCycleGapList(List subCycleGapList) {
		this.subCycleGapList = subCycleGapList;
	}
	public void addGap(String gapString){
		gapList.add(gapString);
	}
	
	public void addSubCycleGap(String id,String level,String gapString,String ownerId,String subCycleid){
		
		Iterator subCycleIterator = subCycleGapList.iterator();
		
		if(level.equalsIgnoreCase("S")){
			
			while(subCycleIterator.hasNext()){
				
				SubCycleGap subCycleGapObj = (SubCycleGap)subCycleIterator.next();
				
				if(subCycleGapObj.getSubCycleId().equalsIgnoreCase(id)){
					subCycleGapObj.addGap(gapString);
					return;
				}
			}
			
			SubCycleGap subCycleGap = new SubCycleGap();
			subCycleGap.setSubCycleId(id);
			subCycleGap.addGap(gapString);
			
		}
		
		if(level.equalsIgnoreCase("A")){
			
			while(subCycleIterator.hasNext()){
				
				SubCycleGap subCycleGap = (SubCycleGap)subCycleIterator.next();
				
				if(subCycleGap.getSubCycleId().equalsIgnoreCase(subCycleid)){
					subCycleGap.addActivityGap(id,level,gapString,ownerId,subCycleid);
					return;
				}
			}
			
			SubCycleGap subCycleGap = new SubCycleGap();
			subCycleGap.setSubCycleId(subCycleid);
			subCycleGap.addActivityGap(id,level,gapString,ownerId,subCycleid);
			subCycleGapList.add(subCycleGap);
		}		
		
	}

}
