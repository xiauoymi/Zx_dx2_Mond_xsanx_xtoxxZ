package com.monsanto.wst.soxic.model.headerFooter;

import com.monsanto.wst.soxic.form.QuestionAdminForm;
import com.monsanto.wst.soxic.model.HeaderFooterDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 28, 2006
 * Time: 11:15:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class SubCycleHeadFootSet extends HeadFootSet{

    public void setHeaderAndFooter(QuestionAdminForm questionAdminForm, HeaderFooterFacade headerFooterFacade) {
        questionAdminForm.setSubcycleHeader(headerFooterFacade.getHeader());
        questionAdminForm.setSubcycleFooter(headerFooterFacade.getFooter());
    }

    public void updateHeaderIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getSubcycleHeader(), SoxicConstants.SUBCYCLE_QUESTION_HEADER,SoxicConstants.QUESTION_HEADER);
    }

    public void updateFooterIntoDB(QuestionAdminForm questionAdminForm) {
        HeaderFooterDAO.updateMessage(questionAdminForm.getSubcycleFooter(), SoxicConstants.SUBCYCLE_QUESTION_FOOTER,SoxicConstants.QUESTION_FOOTER);
    }
}
