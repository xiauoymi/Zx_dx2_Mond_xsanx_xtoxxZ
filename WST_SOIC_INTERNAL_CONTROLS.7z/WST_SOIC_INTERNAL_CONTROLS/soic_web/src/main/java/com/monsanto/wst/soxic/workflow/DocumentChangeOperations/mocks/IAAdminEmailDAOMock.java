package com.monsanto.wst.soxic.workflow.DocumentChangeOperations.mocks;

import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;
import com.monsanto.wst.soxic.util.SoxicConstants;

import java.util.List;
import java.util.ArrayList;
import java.sql.Date;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 1, 2005
 * Time: 3:40:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class IAAdminEmailDAOMock implements IAAdminEmailDAOInt {

    public List select(){
        List requestList = new ArrayList();
        OwnerChangeRequestResponse ownerChangeRequestResponse = null;

        ownerChangeRequestResponse = new OwnerChangeRequestResponse();
        Date date = new Date(System.currentTimeMillis());
        ownerChangeRequestResponse.setResponseDate(date);
        ownerChangeRequestResponse.setApproved("Y");
        ownerChangeRequestResponse.setResponseType(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE);
        requestList.add(ownerChangeRequestResponse);

        OwnerChangeRequestResponse ownerChangeRequestResponseOne = new OwnerChangeRequestResponse();
        date = new Date(System.currentTimeMillis());
        ownerChangeRequestResponseOne.setResponseDate(date);
        ownerChangeRequestResponseOne.setApproved("N");
        ownerChangeRequestResponseOne.setResponseType(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE);
        requestList.add(ownerChangeRequestResponseOne);

        OwnerChangeRequestResponse ownerChangeRequestResponseTwo = new OwnerChangeRequestResponse();
        date = new Date(System.currentTimeMillis()-24*40*57*1000);
        ownerChangeRequestResponseTwo.setResponseDate(date);
        ownerChangeRequestResponseTwo.setApproved("Y");
        ownerChangeRequestResponseTwo.setResponseType(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE);
        requestList.add(ownerChangeRequestResponseTwo);

        OwnerChangeRequestResponse ownerChangeRequestResponseThres = new OwnerChangeRequestResponse();
        date = new Date(System.currentTimeMillis()-24*60*59*1000);
        ownerChangeRequestResponseThres.setResponseDate(date);
        ownerChangeRequestResponseThres.setApproved("Y");
        ownerChangeRequestResponseThres.setResponseType(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE);
        requestList.add(ownerChangeRequestResponseThres);

        OwnerChangeRequestResponse ownerChangeRequestResponseFour = new OwnerChangeRequestResponse();
        date = new Date(System.currentTimeMillis()-24*60*59*1000);
        ownerChangeRequestResponseFour.setResponseDate(date);
        ownerChangeRequestResponseFour.setApproved("N");
        ownerChangeRequestResponseFour.setResponseType(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE);
        requestList.add(ownerChangeRequestResponseFour);

        OwnerChangeRequestResponse ownerChangeRequestResponseFive = new OwnerChangeRequestResponse();
        date = new Date(System.currentTimeMillis()-24*60*59*1000);
        ownerChangeRequestResponseFive.setResponseDate(date);
        ownerChangeRequestResponseFive.setApproved("Y");
        ownerChangeRequestResponseFive.setResponseType(SoxicConstants.DOC_CHANGE_ROLE_IA);
        requestList.add(ownerChangeRequestResponseFive);

        return requestList;
    }
}
