/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlObjectiveNew extends SoxicBaseModel implements Comparable{
    
//  following feilds represents the Column Names of  CTRL_OBJ table in the DB.
    
    public static final String CTRL_OBJ_ID     = "CTRL_OBJ_ID";
    public static final String NEW_CTRL_OBJ_ID = "NEW_CTRL_OBJ_ID";
    public static final String CTRL_OBJ_CODE   = "CTRL_OBJ_CODE";
    public static final String DESCRIPTION     = "DESCRIPTION";
    public static final String OVERFLOW_ID     = "OVERFLOW_ID";

    public static final String STATUS          = "STATUS";
    public static final String POTENTIAL_GAP   = "POTENTIAL_GAP";
    public static final String PREV_DEF        = "PREV_DEF";
    public static final String RISK            = "RISK";
    
    
    private String controlObjectiveId;
    private String controlObjectiveCode;
    private String description;
    private String status;
    private String gap;
    private String deficiency;
    private String risk;
    private String subCycleId;
    private int overFlowId;

    private Collection activities;
    
    private boolean show = false;
    
 
    /**
     * @return Returns the controlObjectiveId.
     */
    public String getControlObjectiveId() {
        return controlObjectiveId;
    }
    /**
     * @param controlObjectiveId The controlObjectiveId to set.
     */
    public void setControlObjectiveId(String ctrlObjId) {
        this.controlObjectiveId = ctrlObjId;
    }

    public String getControlObjectiveCode() {
        return controlObjectiveCode;
    }

    public void setControlObjectiveCode(String controlObjectiveCode) {
        this.controlObjectiveCode = controlObjectiveCode;
    }

    /**
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
    	this.status = status;
        
//        if(status != null && (status.equals("INPROGRESS")|| status.equals("NOT_STARTED") || status.equals("COMPLETE")))
//            this.status = status;
//        else
//            this.status="";
    }
    /**
     * @return Returns the show.
     */
    public boolean isShow() {
        return show;
    }
    /**
     * @param show The show to set.
     */
    public void setShow(boolean show) {
        this.show = show;
    }
    /**
     * @return Returns the activities.
     */
    public Collection getActivities() {
        return activities;
    }
    /**
     * @param activities The activities to set.
     */
    public void setActivities(Collection activities) {
    	Collections.sort((List)activities);
        this.activities = activities;
    }
    /**
     * @return Returns the deficiency.
     */
    public String getDeficiency() {
        return deficiency;
    }
    /**
     * @param deficiency The deficiency to set.
     */
    public void setDeficiency(String defeciency) {
        
        if(defeciency != null && (defeciency.equals("Y")|| defeciency.equals("N")))
            this.deficiency = defeciency;
        else
            this.deficiency="";
    }
    /**
     * @return Returns the gap.
     */
    public String getGap() {
        return gap;
    }
    /**
     * @param gap The gap to set.
     */
    public void setGap(String gap) {
        
        if(gap != null && (gap.equals("Y")|| gap.equals("N")))
           this.gap = gap;
        else
            this.gap="N";
    }
    /**
     * @return Returns the risk.
     */
    public String getRisk() {
        return risk;
    }
    /**
     * @param risk The risk to set.
     */
    public void setRisk(String risk) {
        this.risk = risk;
    }
  
    public int compareTo(Object o){
    	int value = ((ControlObjectiveNew)o).controlObjectiveId.compareTo(controlObjectiveId);
    	return -value;
    }
    
    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "ControlObjective Info :"             + '\n');
        buffer.append("ControlObjectiveId :"+ controlObjectiveId  + '\n');
        buffer.append("Description        :"+ description         + '\n');
        buffer.append("Status             :"+ status              +'\n');
        buffer.append("Gap                :"+ gap                 + '\n');
        buffer.append("Deficiency         :"+ deficiency          + '\n');
        buffer.append("Risk               :"+ risk                +'\n');
        
        if(activities != null){
            
            buffer.append("Number of Control Objectives : "+ activities.size());
            Iterator itr = activities.iterator();
            
            while(itr.hasNext()){
 	             buffer.append(((ActivityNew)itr.next()).toString());
 	        }
        } 
        else{
            buffer.append("There are no Activities Assigned for this ControlObjective :"+ controlObjectiveId +'\n');
        }
       
        return buffer.toString();
    }

    public String getId(){
        return controlObjectiveId;
    }

    public String getOwnerId(){
        return "";
    }

    public String getSubCycleId() {
        return subCycleId;
    }

    public void setSubCycleId(String subCycleId) {
        this.subCycleId = subCycleId;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }
}
