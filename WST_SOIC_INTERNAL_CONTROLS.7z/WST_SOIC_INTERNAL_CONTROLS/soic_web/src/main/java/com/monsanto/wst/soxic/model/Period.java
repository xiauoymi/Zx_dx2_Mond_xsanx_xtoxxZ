package com.monsanto.wst.soxic.model;

import java.sql.Date;
import java.sql.PreparedStatement;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jul 21, 2005
 * Time: 5:15:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class Period extends SoxicBaseModel{
    public static final String PERIOD_ID             = "PERIOD_ID";
    public static final String  CYCLE_ID             = "CYCLE_ID";
    public static final String DESCRIPTION           = "DESCRIPTION";
    public static final String STATUS                = "STATUS";
    public static final String STATE                 = "STATE";
    public static final String SOURCE_PERIOD_ID      = "SOURCE_PERIOD_ID";
    public static final String BEGIN_DATE            = "BEGIN_DATE";
    public static final String END_DATE              = "END_DATE";
    public static final String MOD_USER              = "MOD_USER";
    public static final String PERIOD_TYPE           = "PERIOD";
    public static final String CYCLE_TYPE            = "CYCLE";


    private String period_id;
    private String cycle_id;
    private String description;
    private String status;
    private String state;
    private String cycleOnlyPeriod;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    private String source_period_id;
    private Date begin_date;
    private Date end_date;
    private String mod_user;
    private String queryType;

    public String getCycle_id() {
        return cycle_id;
    }

    public void setCycle_id(String cycle_id) {
        this.cycle_id = cycle_id;
    }

    public String getQueryType() {
        return queryType;
    }

    public void setQueryType(String queryType) {
        this.queryType = queryType;
    }

    public String getMod_user() {
        return mod_user;
    }

    public void setMod_user(String mod_user) {
        this.mod_user = mod_user;
    }


    public String getPeriod_id() {
        return period_id;
    }

    public void setPeriod_id(String period_id) {
        this.period_id = period_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSource_period_id() {
        return source_period_id;
    }

    public void setSource_period_id(String source_period_id) {
        this.source_period_id = source_period_id;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public Date getBegin_date() {
        return begin_date;
    }

    public void setBegin_date(Date begin_date) {
        this.begin_date = begin_date;
    }

    public String getCycleOnlyPeriod() {
        return cycleOnlyPeriod;
    }

    public void setCycleOnlyPeriod(String cycleOnlyPeriod) {
        this.cycleOnlyPeriod = cycleOnlyPeriod;
    }

    public void setParameters(PreparedStatement preparedStatement)throws Exception{
        if(queryType.equals("CYCLE")){
            preparedStatement.setString(1,getCycle_id());
            preparedStatement.setString(2,getPeriod_id());
            preparedStatement.setString(3,getState());
            preparedStatement.setDate(4,getBegin_date());
            preparedStatement.setDate(5,getEnd_date());
            preparedStatement.setDate(6,new Date(System.currentTimeMillis()));
            preparedStatement.setString(7,getMod_user());
        }
        if(queryType.equals("PERIOD")){
            preparedStatement.setString(1,getPeriod_id());
            preparedStatement.setString(2,getDescription());
            preparedStatement.setString(3,getStatus());
            preparedStatement.setString(4,getSource_period_id());
            preparedStatement.setDate(5,getBegin_date());
            preparedStatement.setDate(6,getEnd_date());
            preparedStatement.setDate(7,new Date(System.currentTimeMillis()));
            preparedStatement.setString(8,getMod_user());
            preparedStatement.setString(9, getCycleOnlyPeriod());
        }
    }

    public String getQuery(){
        if(queryType.equals("CYCLE")){
             return "INSERT INTO CYCLE_STATE (CYCLE_ID, PERIOD_ID, STATE, BEGIN_DATE, END_DATE, MOD_DATE, MOD_USER)VALUES (?, ?, ?, ?, ?, ?, ?)";
        }
        if(queryType.equals("PERIOD")){
            return "INSERT INTO PERIOD (PERIOD_ID, DESCRIPTION, STATUS, SOURCE_PERIOD_ID, BEGIN_DATE, END_DATE, MOD_DATE, MOD_USER, CYCLE_ONLY_PERIOD)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        }
        return "";
    }

    public String getId(){
        return getPeriod_id();
    }

    public String getOwnerId(){
        return "";
    }

}
