/*
 * Created on Mar 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SubCycleReportObject {
	
	private String cycleName;
	private boolean reportAvailable;
	private Vector listOfSubCycles = new Vector();
	
	

	/**
	 * @return Returns the cycleName.
	 */
	public String getCycleName() {
		return cycleName;
	}
	/**
	 * @param cycleName The cycleName to set.
	 */
	public void setCycleName(String cycleName) {
		this.cycleName = cycleName;
	}
	/**
	 * @return Returns the listOfSubCycles.
	 */
	public Vector getListOfSubCycles() {
		return listOfSubCycles;
	}
	/**
	 * @param listOfSubCycles The listOfSubCycles to set.
	 */
	public void setListOfSubCycles(Vector listOfSubCycles) {
		this.listOfSubCycles = listOfSubCycles;
	}
	/**
	 * @return Returns the reportAvailable.
	 */
	public boolean isReportAvailable() {
		return reportAvailable;
	}
	/**
	 * @param reportAvailable The reportAvailable to set.
	 */
	public void setReportAvailable(boolean reportAvailable) {
		this.reportAvailable = reportAvailable;
	}
}
