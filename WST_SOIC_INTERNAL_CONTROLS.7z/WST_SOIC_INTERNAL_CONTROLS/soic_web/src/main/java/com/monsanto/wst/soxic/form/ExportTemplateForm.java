package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 5, 2005
 * Time: 10:47:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportTemplateForm extends ActionForm{

    private List period;
    private String selectedPeriod;

    private List country;
    private String selectedCountry;

    private List cycles;
    private String selectedCycles;

    private List subcycle;

    private String scindex;

    public List getCountry() {
        return country;
    }

    public void setCountry(List country) {
        this.country = country;
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public String getSelectedCycles() {
        return selectedCycles;
    }

    public void setSelectedCycles(String selectedCycles) {
        this.selectedCycles = selectedCycles;
    }

    public List getSubcycle() {
        return subcycle;
    }

    public void setSubcycle(List subcycle) {
        this.subcycle = subcycle;
    }

    public String getScindex() {
        return scindex;
    }

    public void setScindex(String scindex) {
        this.scindex = scindex;
    }

    public List getPeriod() {
        return period;
    }

    public void setPeriod(List period) {
        this.period = period;
    }

    public String getSelectedPeriod() {
        return selectedPeriod;
    }

    public void setSelectedPeriod(String selectedPeriod) {
        this.selectedPeriod = selectedPeriod;
    }
}
