package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.exception.DoubleSignificantEntryException;
import com.monsanto.wst.soxic.exception.SigChangeListException;
import com.monsanto.wst.soxic.facade.SignificantChangeFacade;
import com.monsanto.wst.soxic.form.SignificantChangeForm;
import com.monsanto.wst.soxic.model.SignificantChangeModel;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 9, 2006
 * Time: 3:18:12 PM
 * To change this template use File | Settings | File Templates.
 */

public class SaveSignificantChangesAction extends Action implements NoReportingSigChangeInterface,SignificantChangeReportingInterface{

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception{

        String type = request.getParameter("type");
        String noReporting = request.getParameter("noReporting");
        SignificantChangeForm significantChangeForm = (SignificantChangeForm)form;
        SignificantChangeFacade significantChangeFacade = new SignificantChangeFacade();
        significantChangeFacade.setResetNoReportingOption(noReporting,significantChangeForm);

        validateEntriesMade(significantChangeForm, significantChangeFacade, type);
        significantChangeFacade.setFinalStatusForCycle(significantChangeForm,request);
        return mapping.findForward("saveSigChanges");
    }

    private void validateEntriesMade(SignificantChangeForm significantChangeForm, SignificantChangeFacade significantChangeFacade, String type) throws DoubleSignificantEntryException, SigChangeListException {
        if (significantChangeForm.isNoReporting() && significantChangeForm.getSignificantChanges().size()>1){
            throw new DoubleSignificantEntryException();
        }
        else
        if (significantChangeForm.isNoReporting() && significantChangeForm.getSignificantChanges().size()<=1){
            SignificantChangeModel sigModel = (SignificantChangeModel)significantChangeForm.getSignificantChanges().get(0);
            checkForSigChangeEntriesForNoReporting(sigModel, significantChangeFacade, significantChangeForm, type);
        }
        else{
            createSignificantChangeReporting(significantChangeForm, significantChangeFacade, type);
        }
    }

    private void checkForSigChangeEntriesForNoReporting(SignificantChangeModel sigModel, SignificantChangeFacade significantChangeFacade, SignificantChangeForm significantChangeForm, String type) throws DoubleSignificantEntryException {
        if (!sigModel.getSelectedType().equalsIgnoreCase("") || !sigModel.getSelectedPeriod().equalsIgnoreCase("") ) {
            throw new DoubleSignificantEntryException();
        }
        else{
            createNoReportingSignificantChange(significantChangeFacade, significantChangeForm, type);
        }
    }

    public void createSignificantChangeReporting(SignificantChangeForm significantChangeForm, SignificantChangeFacade significantChangeFacade, String type) throws SigChangeListException {
        try{
            significantChangeFacade.processAndValidateSigChanges(significantChangeForm);
        }
        catch(Exception e){
            if (e instanceof SigChangeListException){
                throw new SigChangeListException();
            }
        }
        significantChangeFacade.updateDBWithSignificantChanges(significantChangeForm,type);
    }

    public void createNoReportingSignificantChange(SignificantChangeFacade significantChangeFacade, SignificantChangeForm significantChangeForm, String type) {
        significantChangeFacade.updateNoReportingInformation(significantChangeForm, type);
    }


}
