package com.monsanto.wst.soxic.audit.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.soxic.audit.*;
import com.monsanto.wst.soxic.persistance.OracleDocumentChangeDAO;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 15, 2008
 * Time: 10:40:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class AuditExporter {

  private static OracleDocumentChangeDAO dao = new OracleDocumentChangeDAO();
  private static Map<String,String> priorityMap = new HashMap<String,String>();
  private static StringBuffer issuesBuffer;
  private static String xmlStart = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
        "<TmData Version=\"4\" Date=\"Mon Jul 13 14:23:08 2009\" Format=\"1\" Author=\"Sally Higgins\" Description=\"8.1.3.1231\">\n" +
        "<PROJECT ID=\"1\" Type=\"4\" Version=\"8.0\">\n" +
        "<INFO>\n" +
        "<NAME>LIBRARY - SOA</NAME>\n" +
        "<GUID>338B354D220041B4B292F1E60B08B451</GUID>\n" +
        "<CODE>01-1111</CODE>\n" +
        "<PARENT>SOA</PARENT>\n" +
        "<GROUP ID=\"67108874\">FIN/IT</GROUP>\n" +
        "<PHASE>4</PHASE>\n" +
        "<CREATOR>4</CREATOR>\n" +
        "<VERSION>8.0</VERSION>\n" +
        "<STATUS>2</STATUS>\n" +
        "<LAST_MODIFIED_DATE>2009-07-13</LAST_MODIFIED_DATE>\n" +
        "</INFO>";
  
  public static String beginExportXMLConstruction(List<SubCycleObj> subCycleList, Session session, String filePath) throws Exception{
    populatePriorityMap(priorityMap);
    FileUtil.deleteFileIfPresent(FileUtil.getFileLocation());
    StringBuffer auditXml = new StringBuffer();
    StringBuffer auditXmlStart = new StringBuffer();
    StringBuffer auditXmlEnd = new StringBuffer();
    auditXmlStart.append(getXmlStart());
//    FileUtil.writeToFile(auditXmlStart, filePath);
    FileUtil.writeToFile(auditXmlStart);
    buildAreasSection(auditXml, subCycleList);
    if(issuesBuffer != null && issuesBuffer.length() > 0){
      //Have to append Issues tags
      auditXmlEnd.append(issuesBuffer.toString());
    }
    auditXmlEnd.append("</PROJECT>\n" +
        "</TmData>");
//    FileUtil.writeToFile(auditXmlEnd, filePath);
      FileUtil.writeToFile(auditXmlEnd);

    return auditXml.toString();

  }

  private static String getXmlStart() {
     return xmlStart;
  }

  public static void setXmlStart(String xml){
    xmlStart = xml;
  }

  private static void populatePriorityMap(Map<String, String> priorityMap) {
    priorityMap.put("0","67108925");
    priorityMap.put("1","67108926");
    priorityMap.put("2","67108924");
  }

  private static void buildAreasSection(StringBuffer auditXml, List<SubCycleObj> subCycleList) throws Exception{
    for (SubCycleObj subCycle : subCycleList) {
      auditXml.append("\n\n");
      auditXml.append("<AREAS><FOLDER ID=\"-1207959551\">");
      auditXml.append("<TITLE>");
      if(subCycle.getOverFlowId() != null && subCycle.getOverFlowId().intValue() != 0){//Overflow exists
        subCycle.setDescription(dao.getCompleteDescription(subCycle.getOverFlowId().intValue(),subCycle.getDescription()));
      }
      auditXml.append(subCycle.getSubCycleId() +"-"+replaceOccurences(subCycle.getDescription()));
      auditXml.append("</TITLE>");
      auditXml.append("<CODE>");
      auditXml.append(subCycle.getSubCycleCode());
      auditXml.append("</CODE>");
      for (ControlObjectiveObj control : subCycle.getControlObjectives()) {
        buildAreaSection(auditXml, control);
      }
      auditXml.append("</FOLDER>\n" +
          "</AREAS>\n\n");
      FileUtil.writeToFile(auditXml);
      clearOwnerBuffer(auditXml);

    }
  }

  
  private static void buildAreaSection(StringBuffer auditXml, ControlObjectiveObj control) throws Exception {
    auditXml.append("\n");
    auditXml.append("<AREA ID=\"-1207959550\">");
    auditXml.append("<TITLE>");
    auditXml.append(control.getControlObjectiveId());
    auditXml.append("</TITLE>");
    auditXml.append("<CODE>");
    auditXml.append(control.getControlObjectiveCode());
    auditXml.append("</CODE>");
    builsProcedureSummarySection(auditXml, control);
    auditXml.append("</AREA>");
  }

 private static void builsProcedureSummarySection(StringBuffer auditXml, ControlObjectiveObj control) throws Exception {
    auditXml.append("\n");
    auditXml.append("<PROCEDURE_SUMMARY ID=\"-1207959547\">");
    auditXml.append("<TITLE>");
    auditXml.append(control.getControlObjectiveId());
    auditXml.append("</TITLE>");
    auditXml.append("<CODE>");
    auditXml.append(control.getControlObjectiveCode());
    auditXml.append("</CODE>");
    auditXml.append("<STATE ID=\"1\">In Progress</STATE>");
    auditXml.append("</PROCEDURE_SUMMARY>");
    for (ActivityObj activity : control.getActivities()) {
      buildStepSection(auditXml, activity, control);
    }
  }

  private static void buildStepSection(StringBuffer auditXml, ActivityObj activity, ControlObjectiveObj control) throws Exception{
    String priority = "";
    StringBuffer ownerBuffer = new StringBuffer();
    auditXml.append("<STEP ID=\"-1207959546\">");
    auditXml.append("<TITLE>");
    auditXml.append(replaceOccurences(activity.getActivityId()));
    auditXml.append("</TITLE>");
    //Place holder for enhancement.
    //This needs to be In Progress if the priority = 1 or the sub-cycle has a BU
    if (isFieldWorkType(control, activity.getPriority())) {
      auditXml.append("<TYPE ID=\"67108911\">Fieldwork</TYPE>");
    } else {
      auditXml.append("<TYPE ID=\"67108912\">Scoped Out</TYPE>");
    }
    //auditXml.append("<TYPE ID=\"67108911\">Fieldwork</TYPE>");
    auditXml.append("<STATE ID=\"1\">In Progress</STATE>");
    if(activity.getPriority() != null){
      priority = activity.getPriority().toString();
      auditXml.append("<USERCAT1 ID= "+"\""+priorityMap.get(priority)+"\">"+priority+"</USERCAT1>");
    }


    //Build <TEXTPLAN> sections
    if(activity.getOverFlowId() != null && activity.getOverFlowId().intValue() !=0){
      activity.setDescription(dao.getCompleteDescription(activity.getOverFlowId(),activity.getDescription()));
    }
    buildTextPlanSection(auditXml, activity.getDescription(), "1");

    if(control.getOverFlowId() != null && control.getOverFlowId().intValue() !=0){
      control.setDescription(dao.getCompleteDescription(control.getOverFlowId(),control.getDescription()));
    }
    buildTextPlanSection(auditXml, control.getDescription(), "2");
    buildTextPlanSection(auditXml, control.getRisk(), "3");
    
    //Method to Fetch The Activity Owners
    List<OwnerActivityObj> activityOwners = activity.getActivityOwners();
    populateActivityOwners(ownerBuffer, activityOwners);
    buildTextPlanSection(auditXml, ownerBuffer.toString(), "4");
    //Clear Owner Buffer
    clearOwnerBuffer(ownerBuffer);

    populateCycleInformation(auditXml, control, ownerBuffer);

    auditXml.append("</STEP>");
  }

  /**
   * If the Priority = 1 or if the sub-cycle contains BU [Business Unit], make it as field work
   * @param control
   * @param priority
   * @return
   */
  private static boolean isFieldWorkType(ControlObjectiveObj control, Integer priority) {
    if (isFirstPriority(priority) || isBusinessUnitSubCycle(control)) {
      return true;
    } 
    return false;
  }

  private static boolean isBusinessUnitSubCycle(ControlObjectiveObj control) {
    return control.getSubCycle().getSubCycleId().contains(".BU.");
  }

  private static boolean isFirstPriority(Integer priority) {
    return priority != null && "1".equalsIgnoreCase(priority.toString());
  }

  /**
   * Private method to populate Cycle Information [Cycle owners,Sub-Cycle Owners,World Area and Country]
   * @param auditXml
   * @param control
   * @param ownerBuffer
   * @throws Exception
   */
  private static void populateCycleInformation(StringBuffer auditXml, ControlObjectiveObj control, StringBuffer ownerBuffer) throws Exception {
    //Method to Fetch The cycle Owners
    ownerBuffer.append("Cycle Owners - ");
    List<OwnerCycleObj> cycleOwners = control.getSubCycle().getCycle().getOwner();
    populateCycleOwners(ownerBuffer, cycleOwners);
    if(ownerBuffer.lastIndexOf(",") != -1){
      ownerBuffer.deleteCharAt(ownerBuffer.lastIndexOf(","));
    }
    ownerBuffer.append("<BR>");

    ownerBuffer.append("Sub Cycle Owners - ");
    //Method to Fetch The Sub cycle Owners
    List<OwnerSubCycleObj> subCycleOwners = control.getSubCycle().getOwner();
    populateSubCycleOwners(ownerBuffer, subCycleOwners);
    if(ownerBuffer.lastIndexOf(",") != -1){
      ownerBuffer.deleteCharAt(ownerBuffer.lastIndexOf(","));
    }
    ownerBuffer.append("<BR>");
    ownerBuffer.append("World Area - "+control.getSubCycle().getCycle().getWorldAreaId());
    ownerBuffer.append("<BR>");
    ownerBuffer.append("Country - "+control.getSubCycle().getCycle().getCountryId());

    buildTextPlanSection(auditXml, ownerBuffer.toString(), "5");
  }

  private static void populateSubCycleOwners(StringBuffer ownerBuffer, List<OwnerSubCycleObj> subCycleOwners) {
    for(OwnerSubCycleObj owner : subCycleOwners){
        ownerBuffer.append(owner.getOwnerTest().getName()+",");
    }
  }

  private static void populateCycleOwners(StringBuffer ownerBuffer, List<OwnerCycleObj> cycleOwners) {
    for(OwnerCycleObj owner : cycleOwners){
        ownerBuffer.append(owner.getOwnerTest().getName()+",");
    }
  }

  /**
   * Private Method to Clear Owner Buffer
   * @param ownerBuffer
   */
  private static void clearOwnerBuffer(StringBuffer ownerBuffer) {
    ownerBuffer.delete(0,ownerBuffer.length());
  }

  /**
   * Method to populate Owners
   * @param ownerBuffer
   * @param activityOwners
   */
  private static void populateActivityOwners(StringBuffer ownerBuffer, List<OwnerActivityObj> activityOwners) {

    for (OwnerActivityObj owner : activityOwners) {
          ownerBuffer.append("<BR>"+owner.getOwner().getName() + ", " + owner.getOwner().getLocation());
    }
  }
  

  private static void buildTextPlanSection(StringBuffer auditXml, String description, String textplanNumber) {
    auditXml.append("\n");
    if (!StringUtils.isNullOrEmpty(description)) {
      description = replaceOccurences(description);
      auditXml.append("<TEXTPLAN" + textplanNumber + " Format=\"html\">");
      auditXml.append("&lt;HTML&gt;&lt;HEAD&gt;&lt;META http-equiv=Content-Type content=\"text/html; charset=UTF-8\"&gt;" +
          "&lt;STYLE type=\"text/css\"&gt; P { MARGIN: 0px } &lt;/STYLE&gt;&lt;/HEAD&gt;" +
          "&lt;BODY dir=ltr" +
          "style=\"FONT-SIZE: 10pt; COLOR: #000000; FONT-FAMILY: Tahoma\"&gt;" +
          "&lt;P&gt;");
      auditXml.append(description);
      auditXml.append("&lt;/P&gt;&lt;/BODY&gt;&lt;/HTML&gt;</TEXTPLAN" + textplanNumber + ">");

    }
  }

  private static String replaceOccurences(String description) {
      return PatternMatcher.findAndReplace(description);
  }


  public static List<String> checkForInvalidCycleState(List<SubCycleObj> subCycleList, Map<String, String> cycleStateMap) {
    List <String> invalidCycleList = new ArrayList<String>();
    CycleStateObj cycleState = null;
    for (SubCycleObj subCycle : subCycleList) {
      CycleObj cycle = subCycle.getCycle();
      cycleState = cycle.getCycleState();
      if (cycleState == null) {
        invalidCycleList.add("Cycle State is : NULL : for Cycle "+cycle.getCycleId());
      } else if (cycleStateMap.get(cycleState.getState()) == null) {
        invalidCycleList.add("Cycle State is : "+cycleState.getState()+" : for Cycle "+cycle.getCycleId());
      }
    }
    return invalidCycleList;
  }

  public static StringBuffer getIssuesBuffer() {
    return issuesBuffer;
  }

  public static void setIssuesBuffer(StringBuffer aIssuesBuffer) {
    issuesBuffer = aIssuesBuffer;
  }
}
