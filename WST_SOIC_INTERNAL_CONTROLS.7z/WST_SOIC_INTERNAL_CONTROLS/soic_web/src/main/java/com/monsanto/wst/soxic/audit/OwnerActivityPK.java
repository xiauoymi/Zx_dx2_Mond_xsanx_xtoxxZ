package com.monsanto.wst.soxic.audit;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 12:30:08 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class OwnerActivityPK implements Serializable{

  @ManyToOne
  @JoinColumn(name = "OWNER_ID")
  private OwnerObj owner;

  @ManyToOne
  @JoinColumn(name = "ACTIVITY_ID")
  private ActivityObj activity;

  public OwnerObj getOwner() {
    return owner;
  }

  public void setOwner(OwnerObj owner) {
    this.owner = owner;
  }

  public ActivityObj getActivity() {
    return activity;
  }

  public void setActivity(ActivityObj activity) {
    this.activity = activity;
  }

  public OwnerActivityPK() {
  }
}
