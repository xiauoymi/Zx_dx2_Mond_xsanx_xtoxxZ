package com.monsanto.wst.soxic.util;

/**
 * Created by IntelliJ IDEA.
 * User: vlarter
 * Date: Aug 12, 2005
 * Time: 12:10:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class NavConstants {

    // Page Navigation Instance Values
    public static final String PAGE_ACTIVITY = "PAGE_ACTIVITY";
    public static final String PAGE_SUB_CYCLE = "PAGE_SUB_CYCLE";
    public static final String PAGE_CYCLE = "PAGE_CYCLE";
    public static final String PAGE_REPORTS = "PAGE_REPORTS";       // Also applies to all report pages
    public static final String PAGE_ADMIN = "PAGE_ADMIN";           // Also applies to all sub-admin pages
    public static final String PAGE_FAQ = "PAGE_FAQ";
    public static final String PAGE_DOC_CHANGE = "PAGE_DOC_CHANGE";
    public static final String PAGE_OTHER = "PAGE_OTHER";           // Home, Contact Us
}
