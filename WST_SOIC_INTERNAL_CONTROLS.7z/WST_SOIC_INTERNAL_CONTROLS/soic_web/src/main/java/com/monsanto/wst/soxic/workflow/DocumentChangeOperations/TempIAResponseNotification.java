package com.monsanto.wst.soxic.workflow.DocumentChangeOperations;

import com.monsanto.wst.soxic.model.OwnerChangeRequestResponse;
import com.monsanto.wst.soxic.model.OwnerChangeRequest;
import com.monsanto.wst.soxic.model.UtilDAO;
import com.monsanto.wst.soxic.model.OwnerWrapper;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.Util.date.DateUtil;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Sep 2, 2005
 * Time: 10:08:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class TempIAResponseNotification {


    List initialList = new ArrayList();

    List responseList = new ArrayList();

    public static void main(String args[]){
        TempIAResponseNotification tempIAResponseNotification = new TempIAResponseNotification();
//        IAAdminEmailDAO iaAdminEmailDAO = new IAAdminEmailDAO();
//        tempIAResponseNotification.setInitialList(iaAdminEmailDAO.selectForIAResponseApproval());
//        tempIAResponseNotification.processRequestResponseObjects();
//        tempIAResponseNotification.sendIAApprovedEmail();


    }

    public void process(){
         IAAdminEmailDAO iaAdminEmailDAO = new IAAdminEmailDAO();
        setInitialList(iaAdminEmailDAO.selectForIAResponseApproval());
        processRequestResponseObjects();
        sendIAApprovedEmail();
    }


    public void processRequestResponseObjects(){

        Iterator iterator =initialList.iterator();
        List tempList = new ArrayList();

        while(iterator.hasNext()){
            OwnerChangeRequest ownerChangeRequestResponse = (OwnerChangeRequest)iterator.next();
            if(SoxicUtil.isYesterday(ownerChangeRequestResponse.getRespApprovedDate())){
                tempList.add(ownerChangeRequestResponse);
            }
        }
        responseList.addAll(tempList);

    }

    private void sendIAApprovedEmail(){
        List subCycleLevelOwnerWrapperList = new ArrayList();
        List activityLevelOwnerWrapperList = new ArrayList();
        try{
            UtilDAO utilDAO = new UtilDAO();
            Iterator aiterator = responseList.iterator();

            while(aiterator.hasNext()){
                OwnerChangeRequest ownerChangeRequest = (OwnerChangeRequest)aiterator.next();
                if(ownerChangeRequest.getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_LEVEL_ACTIVITY)){
                    subCycleLevelOwnerWrapperList.addAll(utilDAO.getUpperLevelOwnerWrapperList(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY,ownerChangeRequest.getTargetId()));
                    activityLevelOwnerWrapperList.addAll(utilDAO.getLevelOwnerWrapperList(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY,ownerChangeRequest.getTargetId()));
                }
                if(ownerChangeRequest.getSourceType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_LEVEL_SUB_CYCLE)){
                    //subCycleLevelOwnerWrapperList.addAll(utilDAO.getUpperLevelOwnerWrapperList(SoxicConstants.DOC_CHANGE_ROLE_ACTIVITY,ownerChangeRequest.getTargetId()));
                    activityLevelOwnerWrapperList.addAll(utilDAO.getLevelOwnerWrapperList(SoxicConstants.DOC_CHANGE_ROLE_SUB_CYCLE,ownerChangeRequest.getTargetId()));
                }
            }
            Map hashMap = new HashMap();

            Iterator subCycleIterator = subCycleLevelOwnerWrapperList.iterator();
            while(subCycleIterator.hasNext()){
                OwnerWrapper ownerWrapper = (OwnerWrapper)subCycleIterator.next();
                hashMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
            }


            Iterator activityIterator = activityLevelOwnerWrapperList.iterator();
            while(activityIterator.hasNext()){
                OwnerWrapper ownerWrapper = (OwnerWrapper)activityIterator.next();
                hashMap.put(ownerWrapper.getOwnerid(),ownerWrapper);
            }

            Iterator iterator= hashMap.values().iterator();
            while(iterator.hasNext()){
                OwnerWrapper ownerWrapper = (OwnerWrapper)iterator.next();
                SarboxMailComponent.workFlowEmail(SarboxMailComponent.WF_DOC_CHANGE_IA_APPROVAL_RESPONSE,"",ownerWrapper);
            }
        }catch(Exception e){

        }
    }

    public List getInitialList() {
        return initialList;
    }

    public void setInitialList(List initialList) {
        this.initialList = initialList;
    }

    public List getResponseList() {
        return responseList;
    }

    public void setResponseList(List responseList) {
        this.responseList = responseList;
    }
}
