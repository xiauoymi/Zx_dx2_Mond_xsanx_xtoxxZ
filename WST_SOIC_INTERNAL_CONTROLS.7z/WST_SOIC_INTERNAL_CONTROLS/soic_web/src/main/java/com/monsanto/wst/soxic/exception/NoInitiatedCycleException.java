package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2005
 * Time: 10:15:33 AM
 */

public class NoInitiatedCycleException extends Exception{
    public NoInitiatedCycleException(){
		super();
	}

	public NoInitiatedCycleException(Exception e){
		super(e);
	}
}
