package com.monsanto.wst.soxic.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.facade.DocumentChangeReviewFacade;
import com.monsanto.wst.soxic.facade.DocumentChangeRequestReviewFacade;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 5, 2005
 * Time: 11:36:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeRequestReviewDisplayAction extends Action{
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception{

        String action = request.getParameter("method");
        String change = request.getParameter("change");
        Owner owner = (Owner)request.getSession().getAttribute(SoxicConstants.OWNER);
        DocumentChangeRequestReviewFacade documentChangeRequestReviewFacade= new DocumentChangeRequestReviewFacade();
        if(action!=null){
            if(action.equalsIgnoreCase("display")){
                documentChangeRequestReviewFacade.prePopulateForm(form,owner);
                documentChangeRequestReviewFacade.populateForm(form,owner);
            }
            if(action.equalsIgnoreCase("redisplay")){
                documentChangeRequestReviewFacade.rePopulateForm(form,owner,(String)request.getAttribute("processedActivity"));
            }
            if(action.equalsIgnoreCase("Change")){
//                documentChangeRequestReviewFacade.populateForm(form,owner);
                if (!owner.isIA()){
                    documentChangeRequestReviewFacade.setViewAllDocChangesNonIA(form,owner);
                }else
                    documentChangeRequestReviewFacade.setViewAllDocChangesIA(form,owner);
            }
        }

        if(change!=null){
            if(change.equalsIgnoreCase("country")){
                documentChangeRequestReviewFacade.changeCountry(form);
                documentChangeRequestReviewFacade.populateForm(form,owner);
            }
            if(change.equalsIgnoreCase("sub_cycle")){
                documentChangeRequestReviewFacade.populateForm(form,owner);
            }
            if(change.equalsIgnoreCase("cycle")){
                 documentChangeRequestReviewFacade.changeCycle(form);
                 documentChangeRequestReviewFacade.populateForm(form,owner);
            }
        }


        return mapping.findForward("success");
    }
}
