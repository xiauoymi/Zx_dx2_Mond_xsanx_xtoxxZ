/*
 * Created on Jan 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author vrbethi
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlObjective implements Serializable {

	/**
	 * risk for the control objective
	 */
	private String risk;

	/**
	 * id for a control objective
	 */
	private String controlObjectiveId;

	/**
	 * is the control objective expanded or collapsed
	 */
	boolean expanded = false;

	/**
	 * description for the control objective
	 */
	private String controlObjectiveDescription;

	/**
	 * date for the control objective
	 */
	private String controlObjectiveDate;

	/**
	 * status for the control objective
	 */
	private String controlObjectiveStatus;

	/**
	 * deficiency for the control objective
	 */
	private String controlObjectiveDeficiency;

	/**
	 * gap for the control objective
	 */
	private String controlObjectiveGap;

	/**
	 * status object of the control objective
	 */
	private Status status;

	/**
	 * Map containing questions
	 */	
	private Map questionMap;

	/**
	 * Map containing remaining activities
	 */	
	private Map remainingActivityMap;

	/**
	 * Map containing assigned activities
	 */	
	private Map assignedActivityMap;

	/**
	 * List containing deficiencies
	 */	
	private List deficiencyList;

	/**
	 * Number of deficiencies present
	 */		
	private int deficiencyListSize;

	/**
	 * List containing gaps
	 */	
	private List gapList;

	/**
	 * Number of gaps present
	 */	
	private int gapListSize;

	/**
	 * true if status is modified
	 */	
	private boolean statusModified=false;

	/**
	 * Should be least date of all the assigned activities due date
	 */	
	private Date dueDate;
	
	private String previousDef;
	
	private String overFlowId;

    private String documentChangeId;

    private Date startDate;

    private String questionHeader;
    private String questionFooter;


    /**
	 * @return Returns the overFlowId.
	 */
	public String getOverFlowId() {
		return overFlowId;
	}
	/**
	 * @param overFlowId The overFlowId to set.
	 */
	public void setOverFlowId(String overFlowId) {
		this.overFlowId = overFlowId;
	}
	/**
	 * @return Returns the previousDef.
	 */
	public String getPreviousDef() {
		return previousDef;
	}
	/**
	 * @param previousDef The previousDef to set.
	 */
	public void setPreviousDef(String previousDef) {
		this.previousDef = previousDef;
	}
	/**
	 * @return Returns the dueDate.
	 */
	public Date getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate The dueDate to set.
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return Returns the statusModified.
	 */
	public boolean isStatusModified() {
		return statusModified;
	}
	/**
	 * @param statusModified The statusModified to set.
	 */
	public void setStatusModified(boolean statusModified) {
		this.statusModified = statusModified;
	}
	/**
	 * @return Returns the gapListSize.
	 */
	public int getGapListSize() {
		if(gapList!=null){
			Iterator iter = gapList.iterator();
			
			while(iter.hasNext()){
				if(iter.next()!=null){
					return 1;
				}else{
					return 0;
				}
			}
		}
		return 0;
	}
	/**
	 * @param gapListSize The gapListSize to set.
	 */
	public void setGapListSize(int gapListSize) {
		this.gapListSize = gapListSize;
	}
	/**
	 * @return Returns the gapList.
	 */
	public List getGapList() {
		return gapList;
	}
	/**
	 * @param gapList The gapList to set.
	 */
	public void setGapList(List gapList) {
		this.gapList = gapList;
	}
	
	public void addToGapList(String gap){
		
		if(gapList==null){
			gapList = new ArrayList();
		}
		gapList.add(gap);
	}
	/**
	 * @return Returns the deficiencyList.
	 */
	public List getDeficiencyList() {
		return deficiencyList;
	}
	/**
	 * @param deficiencyList The deficiencyList to set.
	 */
	public void setDeficiencyList(List deficiencyList) {
		this.deficiencyList = deficiencyList;
	}
	
	public void addDeficiencyToList(String deficiency){
		if(deficiencyList==null){
			deficiencyList = new ArrayList();
			
		}
		
		deficiencyList.add(deficiency);
	}
	
	public int getDeficiencyListSize(){
		
		if(deficiencyList!=null){
			Iterator iter = deficiencyList.iterator();
			
			while(iter.hasNext()){
				if(iter.next()!=null){
					return 1;
				}else{
					return 0;
				}
			}
		}
		return 0;
	}
	
	public void setDeficiencyListSize(){
		
	}

	/**
	 * @return Returns the controlObjectiveDate.
	 */
	public String getControlObjectiveDate() {
		return controlObjectiveDate;
	}

	/**
	 * @param controlObjectiveDate
	 *            The controlObjectiveDate to set.
	 */
	public void setControlObjectiveDate(String controlObjectiveDate) {
		this.controlObjectiveDate = controlObjectiveDate;
	}

	/**
	 * @return Returns the controlObjectiveDeficiency.
	 */
	public String getControlObjectiveDeficiency() {
		return controlObjectiveDeficiency;
	}

	/**
	 * @param controlObjectiveDeficiency
	 *            The controlObjectiveDeficiency to set.
	 */
	public void setControlObjectiveDeficiency(String controlObjectiveDeficiency) {
		this.controlObjectiveDeficiency = controlObjectiveDeficiency;
	}

	/**
	 * @return Returns the controlObjectiveDescription.
	 */
	public String getControlObjectiveDescription() {
		return controlObjectiveDescription;
	}

	/**
	 * @param controlObjectiveDescription
	 *            The controlObjectiveDescription to set.
	 */
	public void setControlObjectiveDescription(
			String controlObjectiveDescription) {
		this.controlObjectiveDescription = controlObjectiveDescription;
	}

	/**
	 * @return Returns the controlObjectiveGap.
	 */
	public String getControlObjectiveGap() {
		return controlObjectiveGap;
	}

	/**
	 * @param controlObjectiveGap
	 *            The controlObjectiveGap to set.
	 */
	public void setControlObjectiveGap(String controlObjectiveGap) {
		this.controlObjectiveGap = controlObjectiveGap;
	}

	/**
	 * @return Returns the controlObjectiveStatus.
	 */
	public String getControlObjectiveStatus() {
		return controlObjectiveStatus;
	}

	/**
	 * @param controlObjectiveStatus
	 *            The controlObjectiveStatus to set.
	 */
	public void setControlObjectiveStatus(String controlObjectiveStatus) {
		this.controlObjectiveStatus = controlObjectiveStatus;
	}

	/**
	 * @return Returns the expanded.
	 */
	public boolean isExpanded() {
		return expanded;
	}

	/**
	 * @param expanded
	 *            The expanded to set.
	 */
	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	/**
	 * @return Returns the controlObjectiveId.
	 */
	public String getControlObjectiveId() {
		return controlObjectiveId;
	}

	/**
	 * @param controlObjectiveId
	 *            The controlObjectiveId to set.
	 */
	public void setControlObjectiveId(String controlObjectiveId) {
		this.controlObjectiveId = controlObjectiveId;
	}

	/**
	 * @return Returns the status.
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            The status to set.
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * @return Returns the risk.
	 */
	public String getRisk() {
		return risk;
	}
	
	/**
	 * @param risk The risk to set.
	 */
	public void setRisk(String risk) {
		this.risk = risk;
	}
	
	/**
	 * @param question
	 */
	public void addQuestionToHash(Question question){
		if(questionMap==null){
			questionMap = new LinkedHashMap();
		}
		questionMap.put(question.getQuestionId(),question);
	}
	
	/**
	 * @return Returns the questionMap.
	 */
	public Map getQuestionMap() {
		return questionMap;
	}
	/**
	 * @param questionMap The questionMap to set.
	 */
	public void setQuestionMap(Map questionMap) {
		this.questionMap = questionMap;
	}
	/**
	 * @return Returns the assignedActivityMap.
	 */
	public Map getAssignedActivityMap() {
		return assignedActivityMap;
	}
	/**
	 * @param assignedActivityMap The assignedActivityMap to set.
	 */
	public void setAssignedActivityMap(Map assignedActivityMap) {
		this.assignedActivityMap = assignedActivityMap;
	}
	/**
	 * @return Returns the remainingActivityMap.
	 */
	public Map getRemainingActivityMap() {
		return remainingActivityMap;
	}
	/**
	 * @param remainingActivityMap The remainingActivityMap to set.
	 */
	public void setRemainingActivityMap(Map remainingActivityMap) {
		this.remainingActivityMap = remainingActivityMap;
	}
	
	/**
	 * @param activity
	 */
	public void addRemainingActivityToMap(Activity activity){
		if(remainingActivityMap==null){
			remainingActivityMap = new LinkedHashMap();
		}
		activity.setCounter(remainingActivityMap.size());
		remainingActivityMap.put(activity.getActivityId(),activity);
	}
	
	/**
	 * @param activity
	 */
	public void addAssignedActivityToMap(Activity activity){
		if(assignedActivityMap==null){
			 assignedActivityMap = new LinkedHashMap();
		}
		activity.setCounter(assignedActivityMap.size());
		Object o = assignedActivityMap.put(activity.getActivityId(),activity);
		
	}

    public String getDocumentChangeId() {
        return documentChangeId;
    }

    public void setDocumentChangeId(String documentChangeId) {
        this.documentChangeId = documentChangeId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString(){
        
        StringBuffer buffer = new StringBuffer();
        buffer.append('\n'+ "ControlObjective Info          :"    + '\n');
        buffer.append('\n'+ "Control Objective Id           :"    + controlObjectiveId+ '\n');
        buffer.append('\n'+ "Control Objective Descrtiption :"    + controlObjectiveDescription+ '\n');
        buffer.append('\n'+ "Control Objective Status       :"    + controlObjectiveStatus+ '\n');
        buffer.append('\n'+ "Control Objective Date         :"    + controlObjectiveDate+ '\n');
        buffer.append('\n'+ "Control Objective Date         :"    + dueDate+ '\n');
        return buffer.toString();
    }

    public String getQuestionHeader() {
        return questionHeader;
    }

    public void setQuestionHeader(String questionHeader) {
        this.questionHeader = questionHeader;
    }

    public String getQuestionFooter() {
        return questionFooter;
    }

    public void setQuestionFooter(String questionFooter) {
        this.questionFooter = questionFooter;
    }
}
