package com.monsanto.wst.soxic.form;

import org.apache.struts.action.ActionForm;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 5, 2005
 * Time: 11:37:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentChangeRequestReviewForm extends ActionForm{

    private String selectedCountry;
    private String selectedCycle;
    private String selectedSubCycle;

    private List cycles;
    private List countries;
    private List subCycles;

    private List requestReviewList;
    private Map  allOwnerReviews;

    private boolean viewAll;

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(String selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public String getSelectedCycle() {
        return selectedCycle;
    }

    public void setSelectedCycle(String selectedCycle) {
        this.selectedCycle = selectedCycle;
    }

    public String getSelectedSubCycle() {
        return selectedSubCycle;
    }

    public void setSelectedSubCycle(String selectedSubCycle) {
        this.selectedSubCycle = selectedSubCycle;
    }

    public List getCycles() {
        return cycles;
    }

    public void setCycles(List cycles) {
        this.cycles = cycles;
    }

    public void setCycles(Set cycles) {
        List list = new ArrayList();

        Iterator iterator = cycles.iterator();

        while(iterator.hasNext()){
           list.add((String)iterator.next());
        }
        Collections.sort(list);
        list.add("Select");
        this.cycles = list;
    }

    public List getCountries() {
        return countries;
    }

    public void setCountries(List countries) {
        this.countries = countries;
    }

    public void setCountries(Set countries) {
        List list = new ArrayList();

        Iterator iterator = countries.iterator();

        while(iterator.hasNext()){
           list.add((String)iterator.next());
        }  
        Collections.sort(list);
        list.add("Select");
        this.countries = list;
    }

    public List getSubCycles() {
        return subCycles;
    }

    public void setSubCycles(Set subCycles) {
        List list = new ArrayList();

        Iterator iterator = subCycles.iterator();

        while(iterator.hasNext()){
           list.add((String)iterator.next());
        }
        Collections.sort(list);
        list.add("Select");
        this.subCycles = list;
    }

    public void setSubCycles(List subCycles) {
        this.subCycles = subCycles;
    }

    public List getRequestReviewList() {
        return requestReviewList;
    }

    public void setRequestReviewList(List requestReviewList) {
        this.requestReviewList = requestReviewList;
    }

    public Map getAllOwnerReviews() {
        return allOwnerReviews;
    }

    public void setAllOwnerReviews(Map allOwnerReviews) {
        this.allOwnerReviews = allOwnerReviews;
    }

    public boolean isViewAll() {
        return viewAll;
    }

    public void setViewAll(boolean viewAll) {
        this.viewAll = viewAll;
    }
}
