/*
 * Created on Jan 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Answer implements Serializable {
	
	/**
	 * answer for a particular question
	 */	
	private String answer;

	/**
	 * @return Returns the answerYesNo.
	 */
	public String getAnswer() {
		return answer;
	}
	/**
	 * @param answerYesNo The answerYesNo to set.
	 */
	public void setAnswer(String answerYesNo) {
		this.answer = answerYesNo;
	}
}
