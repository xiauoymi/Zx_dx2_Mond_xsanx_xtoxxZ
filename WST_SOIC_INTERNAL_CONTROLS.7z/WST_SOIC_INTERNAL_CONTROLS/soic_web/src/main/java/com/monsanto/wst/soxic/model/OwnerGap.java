/*
 * Created on Mar 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

/**
 * @author vrbethi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class OwnerGap {
	
	String gap;
	
	String ownerid;
	
	String activityId;

	/**
	 * @return Returns the activityId.
	 */
	public String getActivityId() {
		return activityId;
	}
	/**
	 * @param activityId The activityId to set.
	 */
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	/**
	 * @return Returns the gap.
	 */
	public String getGap() {
		return gap;
	}
	/**
	 * @param gap The gap to set.
	 */
	public void setGap(String gap) {
		this.gap = gap;
	}
	/**
	 * @return Returns the ownerid.
	 */
	public String getOwnerid() {
		return ownerid;
	}
	/**
	 * @param ownerid The ownerid to set.
	 */
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
}
