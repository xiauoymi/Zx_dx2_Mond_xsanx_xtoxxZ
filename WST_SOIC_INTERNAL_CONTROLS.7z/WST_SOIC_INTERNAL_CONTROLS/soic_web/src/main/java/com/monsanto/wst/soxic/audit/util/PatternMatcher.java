package com.monsanto.wst.soxic.audit.util;


import org.apache.xerces.util.DOMUtil;

import java.net.URLDecoder;
import java.io.UnsupportedEncodingException;

import com.monsanto.wst.commonutils.xml.XMLUtilities;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Oct 7, 2008
 * Time: 2:58:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class PatternMatcher {
  public static String findAndReplace(String sourceString) {
    sourceString =  UnicodeUtil.escapeXML(sourceString);
    return sourceString;
  }
}
