package com.monsanto.wst.soxic.persistance;

import com.monsanto.wst.soxic.model.SignificantChangeModel;
import com.monsanto.wst.soxic.model.SignificantChangeProcessor;
import com.monsanto.wst.soxic.shared.overflow.OverFlowMap;
import com.monsanto.wst.soxic.util.DBUtils;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 14, 2006
 * Time: 11:23:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateSigChangeDAO {

    SignificantChangeProcessor significantChangeProcessor = new SignificantChangeProcessor();

    private static final String getExisitingSigChanges =
            "SELECT SC.SEQUENCE, SC.BUSINESS_TYPE, SC.PERIOD_IMPACTED, SC.COST, SC.KEY_CONTACT, " +
            "SC.SUB_CYCLE_IMPACTED, SC.DESCRIPTION, SC.STATUS, SC.OVERFLOW_ID, TOF.SEQUENCE AS SEQID, TOF.TEXT_CHUNK " +
            "FROM OWNER_CYCLE OC,SIGNIFICANT_CHANGE SC, TEXT_OVERFLOW TOF " +
            "WHERE OC.CYCLE_ID = SC.CYCLE_ID " +
            "AND OC.OWNER_ID = SC.OWNER_ID " +
            "AND SC.OVERFLOW_ID = TOF.OVERFLOW_ID(+) " +
            "AND OC.CYCLE_ID = ? " +
            "AND OC.OWNER_ID = ?";

    private static final String deleteExisitingSigChanges = "DELETE FROM SIGNIFICANT_CHANGE " +
            "WHERE CYCLE_ID = ? AND OWNER_ID = ?";


    public List getExistingSignificantChanges(String cycleId, String ownerid) {
        List sigChanges = new ArrayList();
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        SignificantChangeModel significantChangeModel;
        try {
                con = SoxicConnectionFactory.getSoxicConnection();
                preparedStatement = con.prepareStatement(getExisitingSigChanges);
                preparedStatement.setString(1,cycleId);
                preparedStatement.setString(2, ownerid);
                rs= preparedStatement.executeQuery();
                OverFlowMap overFlowMap = new OverFlowMap();
                while (rs.next()){
                    significantChangeModel = new SignificantChangeModel();
                    significantChangeModel.setSeqindex(rs.getString("SEQUENCE"));
                    significantChangeModel.setSelectedType(rs.getString("BUSINESS_TYPE"));
                    significantChangeModel.setSelectedPeriod(rs.getString("PERIOD_IMPACTED"));
                    significantChangeModel.setAmount(rs.getString("COST"));
                    significantChangeModel.setKeyContact(rs.getString("KEY_CONTACT"));
                    significantChangeModel.setSubcycles(rs.getString("SUB_CYCLE_IMPACTED"));
                    String desc =rs.getString("DESCRIPTION");
                    String oId = rs.getString("OVERFLOW_ID");
                    String oSeqId = rs.getString("SEQID");
                    String oSeqText = rs.getString("TEXT_CHUNK");
                    significantChangeModel.setOverFlowId(oId);
                    significantChangeModel.setOverSid(oSeqId);
                    significantChangeModel.setOverText(oSeqText);
                    significantChangeModel.setDescription(desc);
                    overFlowMap.add(oId,oSeqId,oSeqText,desc);
                    significantChangeModel.setOverFlowMap(overFlowMap);
                    sigChanges.add(significantChangeModel);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
           finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
        Map significantMap = significantChangeProcessor.processList(sigChanges);
        return (List)new ArrayList(significantMap.values());
    }

    public void deleteOldSigChangeEntriesForSigId(String cycleId, String ownerId) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement(deleteExisitingSigChanges);
            preparedStatement.setString(1, cycleId);
            preparedStatement.setString(2, ownerId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            e.printStackTrace();
        }
        finally {
            DBUtils.closeConnection(rs, preparedStatement, con);
        }
    }
}
