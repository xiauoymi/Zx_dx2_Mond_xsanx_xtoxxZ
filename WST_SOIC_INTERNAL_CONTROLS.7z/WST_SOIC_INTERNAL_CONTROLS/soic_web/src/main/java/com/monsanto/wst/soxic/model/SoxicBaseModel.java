/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.io.Serializable;

/**
 * @author SPOLAVA
 /**
 * This is the base class for all model classes used by this 
 * application. This class is used to filter the object access by DAOs. 
 * This classed incorporated to enforce DAOs to associate with only a 
 * specific set of objects, not any generic object. 
 */
public abstract class SoxicBaseModel implements Serializable{

    private String state;
    private String id;

    public boolean isNull(){
		return false;
	}

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public abstract String getId();

    public abstract String getOwnerId();
}
