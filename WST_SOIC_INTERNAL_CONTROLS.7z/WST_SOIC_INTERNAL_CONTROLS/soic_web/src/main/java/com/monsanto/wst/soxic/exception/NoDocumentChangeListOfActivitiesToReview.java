package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 10, 2005
 * Time: 4:01:34 PM
 */
public class NoDocumentChangeListOfActivitiesToReview extends Exception {
    public NoDocumentChangeListOfActivitiesToReview(){
        super();
    }

    public NoDocumentChangeListOfActivitiesToReview(Exception e){
        super(e);
    }
}
