package com.monsanto.wst.soxic.audit;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Nov 5, 2008
 * Time: 12:23:09 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "SARBOX_ET", name = "ACTIVITY")
public class ActivityObj implements Serializable{

  @Id
  @Column(name = "ACTIVITY_ID")
  private String activityId;

  @Column(name = "ACTIVITY_CODE")
  private String activityCode;

  @Column(name = "CTRL_OBJ_ID")
  private String controlObjectiveId;

  @Column(name = "DESCRIPTION",nullable = true)
  private String description;

  @Column(name = "OVERFLOW_ID",nullable = true)
  private Integer overFlowId;

  @Column(name = "STATUS",nullable = true)
  private String status;

  @Column(name = "POTENTIAL_GAP",nullable = true)
  private String gap;

  @Column(name = "PREV_DEF",nullable = true)
  private String prevDef;

  @Column(name = "MOD_DATE")
  private Date modDate;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "PRIORITY",nullable = true)
  private Integer priority;

  @ManyToOne
  @JoinColumn(name = "CTRL_OBJ_ID",insertable = false,updatable = false)
  private ControlObjectiveObj controlObjective;

  @OneToMany(mappedBy = "activityId",targetEntity = OwnerActivityObj.class,fetch = FetchType.LAZY)
  private List<OwnerActivityObj> activityOwners = new ArrayList<OwnerActivityObj>();


  public String getActivityId() {
    return activityId;
  }

  public void setActivityId(String activityId) {
    this.activityId = activityId;
  }

  public String getActivityCode() {
    return activityCode;
  }

  public void setActivityCode(String activityCode) {
    this.activityCode = activityCode;
  }

  public String getControlObjectiveId() {
    return controlObjectiveId;
  }

  public void setControlObjectiveId(String controlObjectiveId) {
    this.controlObjectiveId = controlObjectiveId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Integer getOverFlowId() {
    return overFlowId;
  }

  public void setOverFlowId(Integer overFlowId) {
    this.overFlowId = overFlowId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getGap() {
    return gap;
  }

  public void setGap(String gap) {
    this.gap = gap;
  }

  public String getPrevDef() {
    return prevDef;
  }

  public void setPrevDef(String prevDef) {
    this.prevDef = prevDef;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }


  public ControlObjectiveObj getControlObjective() {
    return controlObjective;
  }

  public void setControlObjective(ControlObjectiveObj controlObjective) {
    this.controlObjective = controlObjective;
  }

//  public List<OwnerActivity> getActivityOwners() {
//    return activityOwners;
//  }
//
//  public void setActivityOwners(List<OwnerActivity> activityOwners) {
//    this.activityOwners = activityOwners;
//  }

  public List<OwnerActivityObj> getActivityOwners() {
    return activityOwners;
  }

  public void setActivityOwners(List<OwnerActivityObj> activityOwners) {
    this.activityOwners = activityOwners;
  }
}
