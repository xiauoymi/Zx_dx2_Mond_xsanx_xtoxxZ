package com.monsanto.wst.soxic.workflow.certificationstartemails;

import com.monsanto.wst.soxic.workflow.Activity;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Feb 27, 2006
 * Time: 5:26:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityStartDAO extends StartEmailDAO {

    public List getStartCurrentLevelList()throws Exception{

        List activityList = new ArrayList();

        Connection con = null;

        PreparedStatement updateActivityStatus = null;

        try {
            con = getConnection();

            updateActivityStatus = con.prepareStatement("SELECT * FROM OWNER_ACTIVITY OA WHERE OA.START_DATE=?");

            updateActivityStatus.setDate(1,new java.sql.Date(System.currentTimeMillis()));

            ResultSet rs = updateActivityStatus.executeQuery();

            while(rs.next()){
                populateActivityList(rs,activityList);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return activityList;
    }

    private void populateActivityList(ResultSet rs,List activitylist)throws Exception{
        Activity activity = new Activity();
        activity.setActivity_id(rs.getString("ACTIVITY_ID"));
        activity.setOwner_id(rs.getString("OWNER_ID"));
        activity.setStatus(rs.getString("STATUS"));
        activity.setStart_date(rs.getDate("START_DATE"));
        activity.setDue_date(rs.getDate("DUE_DATE"));
        activity.setComplete_date(rs.getDate("COMPLETE_DATE"));
        activity.setMod_date(rs.getDate("MOD_DATE"));
        activity.setMod_user(rs.getString("MOD_USER"));
        activitylist.add(activity);
    }

    public Connection getConnection() throws Exception {
        return SoxicConnectionFactory.getSoxicConnection();
    }
}
