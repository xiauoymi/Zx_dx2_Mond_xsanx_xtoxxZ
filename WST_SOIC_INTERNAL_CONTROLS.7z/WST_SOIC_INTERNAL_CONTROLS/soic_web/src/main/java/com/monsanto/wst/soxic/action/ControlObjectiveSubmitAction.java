package com.monsanto.wst.soxic.action;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.javamail.SarboxMailComponent;
import com.monsanto.wst.soxic.model.Activity;
import com.monsanto.wst.soxic.model.ActivityDAO;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.ControlObjectiveDAO;
import com.monsanto.wst.soxic.model.ControlObjectiveFacade;
import com.monsanto.wst.soxic.model.Owner;
import com.monsanto.wst.soxic.model.OwnerResponse;
import com.monsanto.wst.soxic.model.OwnerResponseHistory;
import com.monsanto.wst.soxic.model.Question;
import com.monsanto.wst.soxic.model.StatusDAO;
import com.monsanto.wst.soxic.model.SubCycleDAO;
import com.monsanto.wst.soxic.persistance.OwnerResponseDAO;
import com.monsanto.wst.soxic.persistance.OwnerResponseHistoryDAO;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicPathUtil;
import com.monsanto.wst.soxic.util.SoxicUtil;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/**
 * MyEclipse Struts Creation date: 02-03-2005
 * 
 * XDoclet definition:
 * 
 * @struts:action validate="true"
 */
public class ControlObjectiveSubmitAction extends Action {

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) form;

		ActionForward forward = new ActionForward();

		//Get the owner from the session

		Owner owner = (Owner) request.getSession().getAttribute(
				SoxicConstants.OWNER);

		//Based on the user action do the specified task
		//if the user selected new cycle load the new cycle data stay on the
		// same page
		//if the user selected save or submit -- Save the data and move to the
		// next page

		String toDirect = SoxicPathUtil.returnForward(request);

		if (toDirect.equalsIgnoreCase("newcycle")) {

			//if new cycle is selected set the forward to the same page
			forward = mapping.findForward("subcycleselected");

			//Get the cycle selected
			Map map = request.getParameterMap();

			String selected = getCycledSelected(map);

			List newCntlList = getNewControlObjectiveList(owner,
					selected);

			List oldCntlList = (List) controlObjectiveForm
					.getControlObjectiveList();

			saveAnswers(oldCntlList, owner.getOwnerId(), false, false, "All");

			//Get all the answers associated with the Control objective objects
//			HashMap ansList = ControlObjectiveDAO.getAllAnswerListObjects(owner
//					.getOwnerId(), newCntlList);

			controlObjectiveForm.setControlObjectiveList(newCntlList);

			ControlObjectiveDAO.getGapMap(newCntlList);

			controlObjectiveForm.setLockSubmit(SubCycleDAO
					.isSubCycleLocked(selected));
			controlObjectiveForm.setCurrentSubCycle(selected);
			//Get the control objective list for a particular sub-cycle and set
			// it.
			//Save the old subcycle information in the session

			return forward;

		}

		if (toDirect.equalsIgnoreCase("save")) {
			String controlObjectiveId = SoxicPathUtil.getKey(request, "save");
			saveAnswers((List) controlObjectiveForm.getControlObjectiveList(),
					owner.getOwnerId(), false, false, controlObjectiveId);
			updateControlObjectiveStatus(controlObjectiveId, owner.getOwnerId());
			forward = mapping.findForward("save");
			return forward;
		}

		if (toDirect.equalsIgnoreCase("submit")) {
			String controlObjectiveId = SoxicPathUtil.getKey(request, "submit");
			saveAnswers((List) controlObjectiveForm.getControlObjectiveList(),
					owner.getOwnerId(), true, true, controlObjectiveId);

			updateActivityStatus(controlObjectiveId, owner.getOwnerId(),
					(List) controlObjectiveForm.getControlObjectiveList());
			updateControlObjectiveStatus(controlObjectiveId, owner.getOwnerId());
			controlObjectiveForm.setStatusForControlObjective(
					controlObjectiveId, owner.getOwnerId());
			ActivityDAO activityDAO = new ActivityDAO();
			if(activityDAO.ownerActivitiesComplete(owner.getOwnerId())){
				request.setAttribute("test","test");
			}
			

		}

		request.getSession().setAttribute(SoxicConstants.CONTROLOBJECTIVELIST,
				controlObjectiveForm.getControlObjectiveList());

		if (isCommentRequired((List) controlObjectiveForm
				.getControlObjectiveList(), controlObjectiveForm
				.getCurrentControlObjective())) {

			forward = mapping.findForward("save");
		} else {
			forward = mapping.findForward("save");
		}

		return forward;

	}

	/**
	 * @param request
	 * @return
	 */
	public String returnForward(HttpServletRequest request) {

		String forwardToReturn = null;
		Map map = request.getParameterMap();

		Iterator iter = map.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();

			Object value = map.get(key);

			String[] valueArr = (String[]) value;

			if (valueArr[0].equalsIgnoreCase("Save")) {

				return "save";
			}

			if (valueArr[0].equalsIgnoreCase("Submit")) {

				return "submit";
			}
		}

		return "newcycle";
	}

	/**
	 * @param map
	 * @return
	 */
	public String getCycledSelected(Map map) {

		Iterator iter = map.keySet().iterator();

		while (iter.hasNext()) {

			Object key = iter.next();
			if (key.equals("cycleSelected")) {
				Object value = map.get(key);
				String[] valueArr = (String[]) value;
				String cycle = valueArr[0];
				StringTokenizer st = new StringTokenizer(cycle);
				return st.nextToken();
			}

		}
		return null;
	}

	/**
	 * @param owner
	 * @param subcycleid
	 * @return
	 * @throws Exception
	 */
	public List getNewControlObjectiveList(Owner owner, String subcycleid)
			throws Exception {
        String ownerid= owner.getOwnerId();
		ControlObjectiveFacade controlObjectiveFacade = new ControlObjectiveFacade();
		List controlObjectiveList = controlObjectiveFacade
				.getControlObjectives(subcycleid,owner);
		//		List controlObjectiveList = ControlObjectiveDAO
		//				.getAllControlObjectives(subcycleid, ownerid);
		return controlObjectiveList;
	}

	/**
	 * @param controlObjectiveList
	 * @param ownerid
	 * @param changeStatus
	 * @param setLink
	 * @param controlObjectiveId
	 * @throws Exception
	 */
	public void saveAnswers(List controlObjectiveList, String ownerid,
			boolean changeStatus, boolean setLink, String controlObjectiveId)
			throws Exception {

		String controlObjectiveStatus = null;

		String status = null;

		String link = "";

		Iterator controlListIterator = controlObjectiveList.iterator();

		while (controlListIterator.hasNext()) {

			Question question;
			ControlObjective controlObjective = (ControlObjective) controlListIterator
					.next();
			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {

				Map questionMap = controlObjective.getQuestionMap();

				Iterator questionIterator = questionMap.keySet().iterator();

				while (questionIterator.hasNext()) {

					Object key = questionIterator.next();

					question = (Question) questionMap.get(key);

					String answer = question.getType();

					String actAnsType = question.getActualAnsType();

					if (question.getType() != null
							&& question.getType().equalsIgnoreCase("no")
							&& setLink) {

						question.setDisplayLink(true);

						link = controlObjective.getControlObjectiveId()
								+ SoxicUtil.getSeperator()
								+ question.getQuestionId()
								+ SoxicUtil.getSeperator() + "A";

						question.setLink(link);
					}

					if (question.getType() != null
							&& question.getType().equalsIgnoreCase("yes")) {
						question.setDisplayLink(false);
					}

					//Save an activity based on the actual answer type

					if (actAnsType.equalsIgnoreCase(SoxicConstants.ALL)) {

						saveAnswer(controlObjective.getAssignedActivityMap(),
								answer, changeStatus, question, ownerid);

						if (controlObjective.getRemainingActivityMap() != null) {

							saveAnswer(controlObjective
									.getRemainingActivityMap(), answer,
									changeStatus, question, ownerid);
						}
					}

					if (actAnsType
							.equalsIgnoreCase(SoxicConstants.ASSIGNEDACTIVITY)) {

						saveAnswer(controlObjective.getAssignedActivityMap(),
								answer, changeStatus, question, ownerid);

					}

					if (actAnsType
							.equalsIgnoreCase(SoxicConstants.REMAININGACTIVITY)) {

						if (controlObjective.getRemainingActivityMap() != null) {

							saveAnswer(controlObjective
									.getRemainingActivityMap(), answer,
									changeStatus, question, ownerid);
						}
					}
				}

			}//End of question

		}//Control objective while

        OwnerResponseDAO ownerResponseDAO = new OwnerResponseDAO();
        ownerResponseDAO.setAnswers(ownerid,controlObjectiveList);
    }

	/**
	 * @param controlObjectiveList
	 * @param currentControlObjective
	 * @return
	 */
	public boolean isCommentRequired(List controlObjectiveList,
			String currentControlObjective) {

		Iterator iterator = controlObjectiveList.iterator();

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					currentControlObjective)) {
				Map questionMap = controlObjective.getQuestionMap();

				Iterator questionIterator = questionMap.keySet().iterator();

				while (questionIterator.hasNext()) {

					Object questionKey = questionIterator.next();

					Object questionValue = questionMap.get(questionKey);

					Question question = (Question) questionValue;

					if (question.getType().equalsIgnoreCase("no")) {

						return true;

					}
				}
			}

		}
		return false;
	}

	/**
	 * @param activityMap
	 * @param answer
	 * @param changeStatus
	 * @param question
	 * @param ownerid
	 * @throws Exception
	 */
	public void saveAnswer(Map activityMap, String answer,
			boolean changeStatus, Question question, String ownerid)
			throws Exception {

		String status = null;
		OwnerResponseDAO ownerResponseDAO = new OwnerResponseDAO();
		OwnerResponse ownerResponse = null;
		Iterator activityIterator = activityMap.keySet().iterator();

		while (activityIterator.hasNext()) {

			ownerResponse = new OwnerResponse();

			Object activityKey = activityIterator.next();

			Activity activity = (Activity) activityMap.get(activityKey);

			ownerResponse.setAssociatedId(activity.getActivityId());
			ownerResponse.setAssociatedType("A");
			ownerResponse.setOwnerid(ownerid);
			ownerResponse.setResponse(answer);
			ownerResponse.setQuestionid(Integer.parseInt(question
					.getQuestionId()));
			
			ownerResponseDAO.retrieve(ownerResponse,OwnerResponseDAO.STATUS);
			
			if(ownerResponse.getStatus()==null || !ownerResponse.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) ){
				if (answer == null) {
					if (activity.getDueDate() != null) {
						status = SoxicUtil.returnStatusPreceedingStr(activity
								.getDueDate())
								+ "NOTSTART";
					} else {
						status = "";
					}

				} else {
					if (answer.equalsIgnoreCase("yes")) {
						status = SoxicConstants.GREEN_COMPLETE;
					} else {
						if (activity.getDueDate() != null) {
							status = SoxicUtil.returnStatusPreceedingStr(activity
									.getDueDate())
									+ "INPROC";
						} else {
							status = "";
						}
					}
				}			
				ownerResponse.setStatus(status);
			}


			if (ownerResponseDAO.checkIfAnswerPresent(ownerResponse)) {

				if (changeStatus) {

					ownerResponseDAO.update(ownerResponse, true);
				} else {
					ownerResponseDAO.update(ownerResponse, false);
				}

			} else {
				if (changeStatus) {

					ownerResponseDAO.insert(ownerResponse,true);

				} else {

					ownerResponseDAO.insert(ownerResponse,false);
				}
				ownerResponseDAO.retrieve(ownerResponse, OwnerResponseDAO.RESPONSE_ID);

			}
			OwnerResponseHistory ownerResponseHistory = new OwnerResponseHistory();
			ownerResponseHistory.setResponse(ownerResponse.getResponse());
			ownerResponseHistory.setOwnerid(ownerResponse.getOwnerid());
			ownerResponseHistory.setResponseId(ownerResponse.getResponseid());

			OwnerResponseHistoryDAO ownerResponseHistoryDAO = new OwnerResponseHistoryDAO();
			ownerResponseHistoryDAO.insert(ownerResponseHistory);

		}
	}

	/**
	 * @param controlObjectiveId
	 * @param ownerid
	 * @throws Exception
	 */
	public void updateControlObjectiveStatus(String controlObjectiveId,
			String ownerid) throws Exception {

		StatusDAO statusDAO = new StatusDAO();
		String status = statusDAO.getStatus(SoxicConstants.CONTROLOBJECTIVE,
				controlObjectiveId);
		//		String status = ControlObjectiveDAO
		//				.getControlObjectiveStatus(controlObjectiveId);
		statusDAO.updateStatus(SoxicConstants.CONTROLOBJECTIVE, ownerid,
				controlObjectiveId, status);
		//		ControlObjectiveDAO.updateControlObjectiveStatus(controlObjectiveId,
		//				status, ownerid);
	}

	/**
	 * @param controlObjectiveId
	 * @param ownerid
	 * @param controlObjectiveList
	 * @throws Exception
	 */
	public void updateActivityStatus(String controlObjectiveId, String ownerid,
			List controlObjectiveList) throws Exception {
		Iterator iterator = controlObjectiveList.iterator();

		boolean sendMail = false;

		while (iterator.hasNext()) {

			ControlObjective controlObjective = (ControlObjective) iterator
					.next();

			if (controlObjective.getControlObjectiveId().equalsIgnoreCase(
					controlObjectiveId)) {

				Map activityMap = controlObjective.getAssignedActivityMap();

				Iterator activityIterator = activityMap.keySet().iterator();

				while (activityIterator.hasNext()) {

					Object activityKey = activityIterator.next();

					Activity activity = (Activity) activityMap.get(activityKey);

					updateActivityStatusNew(ownerid, activity);

					StatusHelper statusHelper = new StatusHelper();

					statusHelper.setActivityStatus(activity, ownerid);

					GapHelper gapHelper = new GapHelper();

					if (!sendMail) {
						//						sendMail =
						// gapHelper.sendEmail(SoxicConstants.ACTIVITY,
						//								activity.getActivityId());
						SarboxMailComponent.sendEmail(SoxicConstants.ACTIVITY,
								activity.getActivityId());
					}

				}

			}
		}

	}

	/**
	 * @param ownerid
	 * @param activity
	 * @throws Exception
	 */
	public void updateActivityStatusNew(String ownerid, Activity activity)
			throws Exception {

		StatusDAO statusDAO = new StatusDAO();
		String status = statusDAO.getOwnerStatus(SoxicConstants.ACTIVITY,
				ownerid, activity.getActivityId());
		if (activity.getStatus() != null && status != null
				&& !status.equalsIgnoreCase(activity.getStatus())) {
			if (ControlObjectiveDAO.isActivityComplete(ownerid, activity
					.getActivityId())) {

				statusDAO.updateOwnerStatus(SoxicConstants.ACTIVITY, ownerid,
						activity.getActivityId(),
						SoxicConstants.GREEN_COMPLETE, true);
			} else {

				statusDAO.updateOwnerStatus(SoxicConstants.ACTIVITY, ownerid,
						activity.getActivityId(), status, true);
			}
		}

	}
}

