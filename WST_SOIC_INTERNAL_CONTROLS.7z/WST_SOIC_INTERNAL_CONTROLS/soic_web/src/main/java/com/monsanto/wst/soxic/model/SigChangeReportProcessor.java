package com.monsanto.wst.soxic.model;

import com.monsanto.wst.soxic.shared.overflow.OverFlowMap;

import java.util.Map;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 6, 2006
 * Time: 3:52:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class SigChangeReportProcessor {

    public Map processList(List sigChanges) {
        Iterator sigIt = sigChanges.iterator();
        OverFlowMap overFlowMap;
        Map sigChangeMap = new HashMap();

        while(sigIt.hasNext()){
            SigChangeReportModel sigChangeReportModel = (SigChangeReportModel) sigIt.next();
            if (sigChangeMap.containsKey(sigChangeReportModel.getSeqindex())){
                SigChangeReportModel sigModel = (SigChangeReportModel) sigChangeMap.get(sigChangeReportModel.getSeqindex());
                sigModel.getOverFlowMap().add(sigChangeReportModel.getOverFlowId(),sigChangeReportModel.getOverSid(),
                        sigChangeReportModel.getOverText(),sigChangeReportModel.getDescription());
            }
            else{
                SigChangeReportModel sigModel = new SigChangeReportModel(sigChangeReportModel.getSeqindex(),
                        sigChangeReportModel.getSelectedType(),
                        sigChangeReportModel.getSelectedPeriod(),sigChangeReportModel.getAmount(),
                        sigChangeReportModel.getKeyContact(),sigChangeReportModel.getSubcycles(),
                        sigChangeReportModel.getDescription(),
                        sigChangeReportModel.getCountry(),
                        sigChangeReportModel.getCycleId());
                overFlowMap = new OverFlowMap();
                overFlowMap.add(sigChangeReportModel.getOverFlowId(),sigChangeReportModel.getOverSid(),
                        sigChangeReportModel.getOverText(),sigChangeReportModel.getDescription());
                sigModel.setOverFlowMap(overFlowMap);
                sigChangeMap.put(sigChangeReportModel.getSeqindex(),sigModel);
            }
        }
        return sigChangeMap;
    }
}
