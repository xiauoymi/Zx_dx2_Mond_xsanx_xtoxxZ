/*
 DocChangesReportAction was created on Jan 23, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.soxic.action;

import com.monsanto.wst.soxic.facade.reports.DocChangesReportFacade;
import com.monsanto.wst.soxic.form.DocChangesReportForm;
import com.monsanto.wst.soxic.persistance.SoxicConnectionFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: DocChangesReportAction.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-01-16 21:16:24 $
 *
 * @author emgoode
 * @version $Revision: 1.2 $
 */
public class DocChangesReportAction extends Action {

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws IOException, Exception {

        ActionForward actionForward;
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            actionForward = list(request, form, mapping);
        }
        else if ("detail".equals(action)) {
            actionForward = detail(request, form, mapping);
        }
        else {
            actionForward = options(form,mapping);
        }

        return actionForward;
    }

    private ActionForward detail(HttpServletRequest request, ActionForm form, ActionMapping mapping) throws Exception {
        Connection connection = SoxicConnectionFactory.getSoxicConnection();
        DocChangesReportForm docChangesReportForm = (DocChangesReportForm) form;
        DocChangesReportFacade docChangesReportFacade = new DocChangesReportFacade();
        docChangesReportForm.setDetailBean(docChangesReportFacade.getDocChangeDetails(connection, getParams(request)));

        cleanup(connection);
        return mapping.findForward("displayDocChangesDetails");
    }

    private ActionForward list(HttpServletRequest request, ActionForm form, ActionMapping mapping) throws Exception {
        Connection connection = SoxicConnectionFactory.getSoxicConnection();
        DocChangesReportForm docChangesReportForm = (DocChangesReportForm) form;
        DocChangesReportFacade docChangesReportFacade = new DocChangesReportFacade();
        docChangesReportForm.setReportList(docChangesReportFacade.getDocChangesList(connection, getParams(request)));

        cleanup(connection);
        return mapping.findForward("displayDocChangesReportList");
    }

    private HashMap getParams(HttpServletRequest request) {
        HashMap retVal = new HashMap();

        retVal.put("PERIOD", request.getParameter("selectedPeriod") != null ? request.getParameter("selectedPeriod") : "");
        retVal.put("COUNTRY", request.getParameter("selectedCountry") != null ? request.getParameter("selectedCountry") : "");
        retVal.put("CYCLE", request.getParameter("selectedCycle") != null ? request.getParameter("selectedCycle") : "");
        retVal.put("ID", request.getParameter("id") != null ? request.getParameter("id") : "");
        retVal.put("TYPE", request.getParameter("selectedType") != null ? request.getParameter("selectedType") : "");

        return retVal;
    }

    private ActionForward options(ActionForm form, ActionMapping mapping) throws Exception {
        Connection connection = SoxicConnectionFactory.getSoxicConnection();
        DocChangesReportForm docChangesReportForm = (DocChangesReportForm) form;
        DocChangesReportFacade docChangesReportFacade = new DocChangesReportFacade();

        docChangesReportForm.setPeriodList(docChangesReportFacade.getPeriodsInSystem());
        docChangesReportForm.setCountryList(docChangesReportFacade.getCountriesInSystem());
        docChangesReportForm.setCycleList(docChangesReportFacade.getCyclesInSystem(connection));
        docChangesReportForm.setTypeList(getTypes());

        cleanup(connection);
        return mapping.findForward("displayDocChangesReportOptions");
    }

    private ArrayList getTypes() {
        ArrayList types = new ArrayList();
        types.add("");
        types.add("ADD");
        types.add("MODIFY");
        types.add("DELETE");

        return types;
    }

    private void cleanup(Connection connection) throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }

}