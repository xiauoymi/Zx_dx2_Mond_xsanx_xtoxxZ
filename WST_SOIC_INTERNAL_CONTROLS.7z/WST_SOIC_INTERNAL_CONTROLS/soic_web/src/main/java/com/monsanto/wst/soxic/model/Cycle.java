/*
 * Created on Jan 31, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Cycle extends SoxicBaseModel{
    
//  following feilds represents the Column Names of  Sub_Cycle, Owner_Sub_cycle table in the DB.
    
	 public static final String CYCLE_ID      = "CYCLE_ID";
     public static final String CYCLE_CODE    = "CYCLE_CODE";
	 public static final String DESCRIPTION   = "DESCRIPTION";
     public static final String OVERFLOW_ID   = "OVERFLOW_ID";
	 public static final String STATUS 		  = "STATUS";
	 public static final String OWNERID       = "OWNER_ID";
     public static final String QUESTION_ID   = "QUESTION_ID";

	 public static final String START_DATE 	  = "START_DATE";
	 public static final String DUE_DATE 	  = "DUE_DATE";
	
	 public static final String POTENTIAL_GAP = "POTENTIAL_GAP";
	 public static final String PREV_DEF      = "PREV_DEF";
 
 
 // We need this feild to fileter the data based on the CYCLE_ID on the SubCycleView.
	 public static final String PERIOD_ID     = "PERIOD_ID";
     public static final String WORLD_AREA_ID = "WORLD_AREA_ID";
     public static final String COUNTRY_ID = "COUNTRY_ID";

	 private String  		cycleId;
     private String         cycleCode;
     private String         subCycleId;
     private String         dueDateString;
     private String         cycleOwnerEmailString;

	 private String         ownerId;
	 private String  		description;
	 private String  		status;
	 private String  		deficiency ;
	 private String  		gap;
	 private Date 	 		dueDate;
//	 Cumulative risk's of all the SubCycles in the Cycle.
	 private String         risk;
      
	 private Collection 	subCycles;
	 private Collection 	questions; 
   	 private boolean 		show = false;
   	 private String 		periodId;
     private String         worldAreaId;
     private String         countryId;
     private String         questionId;
     private int            overFlowId;

    private Date            startDate;
    private java.sql.Date            endDate;
    private Date            completionDate;

  	private boolean submitLock = false;

    private String significantStatus;

    private String questionHeader;
    private String questionFooter;


     /**
	  * @return Returns the cycleId.
	  */
	 public String getCycleId() {
	     return cycleId;
	 }

	 public void setCycleId(String cycleId) {
	     this.cycleId = cycleId;
	 }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getWorldAreaId() {
        return worldAreaId;
    }

    public void setWorldAreaId(String worldAreaId) {
        this.worldAreaId = worldAreaId;
    }

    /**
	  * @return Returns the description.
	  */
	 public String getDescription() {
	     return description;
	 }
	 /**
	  * @param description The description to set.
	  */
	 public void setDescription(String description) {
	     this.description = description;
	 }

	 /**
	  * @return Returns the status.
	  */
	 public String getStatus() {
	     return status;
	 }
	 /**
	  * @param status The status to set.
	  */
	 public void setStatus(String status) {
	     
//	     if(status != null && (status.equals("INPROGRESS")|| status.equals("NOT_STARTED") || status.equals("COMPLETE")))
//	         this.status = status;
//	     else
//	     this.status="";
	     
	     this.status = status;
	 }
	 
	 /**
	  * @return Returns the deficiency.
	  */
	 public String getDeficiency() {
	     return deficiency;
	 }

	 public void setDeficiency(String defeciency) {
	     
	     if(defeciency != null && (defeciency.equals("Y")|| defeciency.equals("N")))
	         this.deficiency = defeciency;
	     else
	     this.deficiency="";
	 }
	 
	 /**
	  * @return Returns the gap.
	  */
	 public String getGap() {
	     
	     return gap;
	 }
	 /**
	  * @param gap The gap to set.
	  */
	 public void setGap(String gap) {
	     
	     if(gap != null && (gap.equals("Y")|| gap.equals("N")))
	        this.gap = gap;
	     else
	     this.gap="";
	 }
	 
	 /**
	  * @return Returns the dueDate.
	  */
	 public String getDueDate() {
	     if(dueDate != null)
	       return DateFormat.getDateInstance(DateFormat.MEDIUM).format(dueDate);
	     else
	       return "";
	 }

     public Date getDueDateAsDate() {
        return dueDate;	 
     }
	 /**
	  * @param dueDate The dueDate to set.
	  */
	 public void setDueDate(Date dueDate) {
	     
	     this.dueDate = dueDate;
	 }
	 
	 /**
	  * @return Returns the risk.
	  */
	 public String getRisk() {
	         
	     if(risk == null || risk ==""){
	         generateRisk();
	     }
	     
	     return risk;
	 }
	 
	 /**
	  * @param risk The risk to set.
	  */
	 public void setRisk(String risk) {
	     
	    this.risk = risk;
	         
	 }
	 /**
	  * utility method to generate risk.
	  */
	 private void generateRisk() {
	     
	     StringBuffer cumulativeRisk  = new StringBuffer();
	     Iterator     itr             = subCycles.iterator();
	     
	     while(itr.hasNext()){
	         cumulativeRisk.append(((SubCycle)itr.next()).getRisk());
	     }
	     
	     if(cumulativeRisk.toString() != ""){
	         risk = cumulativeRisk.toString();
	     }
	     
	 }
	 
	 /**
	  * @return Returns the controlObjectives.
	  */
	 public Collection getSubCycles() {
	     return subCycles;
	 }

	 public void setSubCycles(Collection subCycles) {
	     this.subCycles = subCycles;
	 }
	 
	 /**
	  * @return Returns the questions.
	  */
	 public Collection getQuestions() {
	     return questions;
	 }
	 /**
	  * @param questions The questions to set.
	  */
	 public void setQuestions(Collection questions) {
	     this.questions = questions;
	     setQuestionNumbers();
	 }
	 
	 /**
	  * @return Returns the show.
	  */
	 public boolean isShow() {
	     return show;
	 }

    public String getCycleCode() {
        return cycleCode;
    }

    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }


	 public void setShow(boolean expand) {
	     this.show = expand;
	 }
	 
	 /**
	  * @return Returns the periodId.
	  */
	 public String getPeriodId() {
	     return periodId;
	 }
	 /**
	  * @param periodId The periodId to set.
	  */
	 public void setPeriodId(String periodId) {
	     this.periodId = periodId;
	 }
	 
	/**
	 * @return Returns the ownerId.
	 */
	public String getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId The ownerId to set.
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	 public String toString(){
	     
	     StringBuffer buffer = new StringBuffer();
	     buffer.append('\n'+ "Cycle Info :"         + '\n');
	     buffer.append("PeriodId    :"+ periodId    + '\n');
	     buffer.append("CycleId     :"+ cycleId     + '\n');
	     buffer.append("Description :"+ description + '\n');
	     buffer.append("DueDate     :"+ dueDate     + '\n');
	     buffer.append("Status      :"+ getStatus() + '\n');
	     buffer.append("Gap         :"+ gap         + '\n');
	     buffer.append("Deficiency  :"+ deficiency  + '\n');
	     buffer.append("Risk        :"+ risk        + '\n');
	     
	     if(subCycles != null){
	         
	         buffer.append("Number of SubCycles  : "+ subCycles.size());
	         Iterator itr = subCycles.iterator();
	         
	         while(itr.hasNext()){
		             buffer.append(((SubCycle)itr.next()).toString());
		        }
	     } 
	     else{
	         buffer.append("There are no SubCycles Assigned for this Cycle :"+ cycleId +'\n');
	     }
	     
	     if(questions != null){
	         
	         buffer.append("Number of Questions(Cycle) : "+ questions.size());
	         Iterator itr = questions.iterator();
	         
	         while(itr.hasNext()){
		             buffer.append(((QuestionNew)itr.next()).toString());
		        }
	     } 
	     else{
	         buffer.append("There are no Questions Assigned to this Cycle :"+ cycleId +'\n');
	     }
	     
	     return buffer.toString();
	 }
	 
	 
     
	/**
	 * @return Returns the submitLock.
	 */
	public boolean isSubmitLock() {
		return submitLock;
	}
	/**
	 * @param submitLock The submitLock to set.
	 */
	public void setSubmitLock(boolean submitLock) {
		this.submitLock = submitLock;
	}

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

	public void setSubmitLock() {

        enableDisableButtonOnStartDate();

        Iterator subCyclesIterator = subCycles.iterator();
		
		while(subCyclesIterator.hasNext()){
			
			SubCycle subCycle = (SubCycle)subCyclesIterator.next();
			
			if(subCycle.getStatus()==null){
				submitLock=true;
			}
			
			if(subCycle.getStatus()!=null && !subCycle.getStatus().equalsIgnoreCase(SoxicConstants.GREEN_COMPLETE) && !submitLock){
				submitLock=true;
			}
			
		}		
	}

    private void enableDisableButtonOnStartDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date currentDate = new Date(System.currentTimeMillis());
        Date startdate = new Date(startDate.getTime());
        String cuDate = sdf.format(currentDate);
        String coDate = sdf.format(startdate);
        try {
            currentDate = sdf.parse(cuDate);
            startdate = sdf.parse(coDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (currentDate.before(startdate)){
            submitLock=true;
        }
    }

    private void setQuestionNumbers(){
        int counter = 1;
        Iterator iterator = questions.iterator();

        while(iterator.hasNext()){
            QuestionNew questionNew = (QuestionNew)iterator.next();
            questionNew.setQuestionNumber(counter);
            counter++;
        }
    }

    public String getId(){
        return cycleId;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public java.sql.Date getEndDate() {
        return endDate;
    }

    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public Date getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(Date completionDate) {
        this.completionDate = completionDate;
    }

    public String getSubCycleId() {
        return subCycleId;
    }

    public void setSubCycleId(String subCycleId) {
        this.subCycleId = subCycleId;
    }

    public String getDueDateString() {
        return dueDateString;
    }

    public void setDueDateString(String dueDateString) {
        this.dueDateString = dueDateString;
    }

    public String getCycleOwnerEmailString() {
        return cycleOwnerEmailString;
    }

    public void setCycleOwnerEmailString(String cycleOwnerEmailString) {
        this.cycleOwnerEmailString = cycleOwnerEmailString;
    }

    public String getSignificantStatus() {
        return significantStatus;
    }

    public void setSignificantStatus(String significantStatus) {
        this.significantStatus = significantStatus;
    }

    public String getQuestionHeader() {
        return questionHeader;
    }

    public void setQuestionHeader(String questionHeader) {
        this.questionHeader = questionHeader;
    }

    public String getQuestionFooter() {
        return questionFooter;
    }

    public void setQuestionFooter(String questionFooter) {
        this.questionFooter = questionFooter;
    }
}
