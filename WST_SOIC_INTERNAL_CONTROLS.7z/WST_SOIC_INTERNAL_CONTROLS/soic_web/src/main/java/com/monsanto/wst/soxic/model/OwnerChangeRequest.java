package com.monsanto.wst.soxic.model;

import org.apache.struts.action.ActionForm;
import com.monsanto.wst.soxic.form.DocumentChangeReviewForm;
import com.monsanto.wst.soxic.util.SoxicConstants;
import com.monsanto.wst.soxic.util.SoxicUtil;

import java.util.StringTokenizer;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 2, 2005
 * Time: 5:04:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class OwnerChangeRequest extends SoxicBaseModel{
    public static final String OWNER_CHANGE_REQUEST_ID="OCREQ_ID";
    public static final String SOURCE_TYPE="SOURCE_TYPE";
    public static final String SOURCE_PERIOD="SOURCE_PERIOD";
    public static final String TARGET_PERIOD="TARGET_PERIOD";
    public static final String OWNER_ID="OWNER_ID";
    public static final String SOURCE_ID="SOURCE_ID";
    public static final String TARGET_ID="TARGET_ID";
    public static final String COUNTRY_ID="COUNTRY_ID";
    public static final String CYCLE_CODE="CYCLE_CODE";
    public static final String SUB_CYCLE_CODE="SUB_CYCLE_CODE";
    public static final String CTRL_OBJ_CODE="CTRL_OBJ_CODE";
    public static final String STATUS="STATUS";
    public static final String REQ_TYPE="REQ_TYPE";
    public static final String REQ_TEXT="REQ_TEXT";
    public static final String OVERFLOW_ID="OVERFLOW_ID";
    public static final String REQUEST_DATE  = "REQUEST_DATE";

    public static final String SELECT_TYPE_OCREQ_ID = "OCREQ_ID";
    public static final String SELECT_TYPE_UPDATE_OCREQ_ID = "UPDATE_OCREQ_ID";

    public static final String PRIORITY = "PRIORITY";

    private String ownerChangeRequestId;
    private String sourceType;
    private String sourcePeriod;
    private String targetPeriod;
    private String ownerId;
    private String sourceId;
    private String targetId;
    private String cycleCode;
    private String subCycleCode;
    private String ctrlObjCode;
    private String status;
    private String requestType;
    private String requestText;
    private int overFlowId;
    private String countryId;
    private String requestDate;
    private String selectQuery;
    private Date respApprovedDate;
    private String priority;

    public String getOwnerChangeRequestId() {
        return ownerChangeRequestId;
    }

    public void setOwnerChangeRequestId(String ownerChangeRequestId) {
        this.ownerChangeRequestId = ownerChangeRequestId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSourcePeriod() {
        return sourcePeriod;
    }

    public void setSourcePeriod(String sourcePeriod) {
        this.sourcePeriod = sourcePeriod;
    }

    public String getTargetPeriod() {
        return targetPeriod;
    }

    public void setTargetPeriod(String targetPeriod) {
        this.targetPeriod = targetPeriod;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getCycleCode() {
        return cycleCode;
    }

    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }

    public String getSubCycleCode() {
        return subCycleCode;
    }

    public void setSubCycleCode(String subCycleCode) {
        this.subCycleCode = subCycleCode;
    }

    public String getCtrlObjCode() {
        return ctrlObjCode;
    }

    public void setCtrlObjCode(String ctrlObjCode) {
        this.ctrlObjCode = ctrlObjCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestText() {
        return requestText;
    }

    public void setRequestText(String requestText) {
        this.requestText = requestText;
    }

    public int getOverFlowId() {
        return overFlowId;
    }

    public void setOverFlowId(int overFlowId) {
        this.overFlowId = overFlowId;
    }

    public String getId(){
        return "";
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getSelectQuery() {
        return selectQuery;
    }

    public void setSelectQuery(String selectQuery) {
        this.selectQuery = selectQuery;
    }

    public void setParameters(ActionForm form,Owner owner){
        DocumentChangeReviewForm documentChangeReviewForm = (DocumentChangeReviewForm)form;
            setParametersAfterCheckingPriority(documentChangeReviewForm,owner);

//        setRequestType(documentChangeReviewForm.getRequest_type());
//
//        if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
//            setRequestText(documentChangeReviewForm.getNewActivityDescription());
//            setPriority(documentChangeReviewForm.getPriority());
//        }
//        if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
//            setRequestText(documentChangeReviewForm.getNewActivityDescription());
//            setPriority(documentChangeReviewForm.getPriority());
//        }
//        if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
//            setRequestText(documentChangeReviewForm.getReasonForRemoval());
//        }
//
//        //if(documentChangeReviewForm.getMode())
//
//        setSourceType(documentChangeReviewForm.getSource_type());
//        setSourceId(documentChangeReviewForm.getIdentifier());
//        setTargetId(documentChangeReviewForm.getIdentifier());
//        setIdentifiers();
//        setOwnerId(owner.getOwnerId());
//        initializeStatus();

    }

    private void setParametersAfterCheckingPriority(DocumentChangeReviewForm documentChangeReviewForm,Owner owner){
            setRequestType(documentChangeReviewForm.getRequest_type());

                if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_ADD)){
                    setRequestText(documentChangeReviewForm.getNewActivityDescription());
                    setPriority(documentChangeReviewForm.getPriority());
                }
                if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_MODIFY)){
                    setRequestText(documentChangeReviewForm.getNewActivityDescription());
                    setPriority(documentChangeReviewForm.getPriority());
                }
                if(getRequestType().equalsIgnoreCase(SoxicConstants.DOC_CHANGE_REQUEST_DELETE)){
                    setRequestText(documentChangeReviewForm.getReasonForRemoval());
                }

                //if(documentChangeReviewForm.getMode())

                setSourceType(documentChangeReviewForm.getSource_type());
                setSourceId(documentChangeReviewForm.getIdentifier());
                setTargetId(documentChangeReviewForm.getIdentifier());
                setIdentifiers();
                setOwnerId(owner.getOwnerId());
                initializeStatus();
    }

    public void setParameters(PreparedStatement pstmt,String queryType){
        try{
            if(queryType.equalsIgnoreCase("INSERT")){
                pstmt.setString(1,getSourceType());
                pstmt.setString(2,getSourcePeriod());
                pstmt.setString(3,getTargetPeriod());
                pstmt.setString(4,getOwnerId());
                pstmt.setString(5,getSourceId());
                pstmt.setString(6,getTargetId());
                pstmt.setString(7,getCycleCode());
                pstmt.setString(8,getSubCycleCode());
                pstmt.setString(9,getCtrlObjCode());
                pstmt.setString(10,getStatus());
                pstmt.setString(11,getPriority());
                pstmt.setString(12,getRequestType());
                pstmt.setString(13,getRequestText());
                pstmt.setInt(14,getOverFlowId());
                pstmt.setDate(15,new Date(System.currentTimeMillis()));
                pstmt.setDate(16,new Date(System.currentTimeMillis()));
                pstmt.setString(17,OWNER_ID);

            }
            if(queryType.equalsIgnoreCase(SELECT_TYPE_OCREQ_ID)){

                pstmt.setString(1,getOwnerId());
                pstmt.setString(2,getTargetId());

            }
        }catch(SQLException sqle){

        }

    }

    public void populateModel(ResultSet rs){
        try{
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumns = rsmd.getColumnCount();

            // Get the column names; column indices start from 1
            for (int i=1; i<numColumns+1; i++) {
                String columnName = rsmd.getColumnName(i);
                if(columnName.equalsIgnoreCase(OWNER_CHANGE_REQUEST_ID)){
                    setOwnerChangeRequestId(rs.getString(OWNER_CHANGE_REQUEST_ID));
                }
            }

        }catch(SQLException e){
            e.printStackTrace();
        }


    }

    private void setIdentifiers(){
        StringTokenizer st = new StringTokenizer(getTargetId(),".");
        setTargetPeriod(st.nextToken());
        String country = st.nextToken();
        setCountryId(country);
        setCycleCode(st.nextToken());
        setSubCycleCode(st.nextToken());
        setCtrlObjCode(st.nextToken());
    }

    public void initializeStatus(){
        setStatus(SoxicConstants.DOC_CHANGE_STATUS_REQUEST);
    }

    public void modifyStatus(){

    }

    public String getQuery(String type){
        if(type.equalsIgnoreCase("INSERT")){
            return "INSERT INTO OWNER_CHANGE_REQUEST ("+SOURCE_TYPE+ ","+SOURCE_PERIOD+ ","+TARGET_PERIOD+ ","+OWNER_ID+ ","+SOURCE_ID+ ","+TARGET_ID+ ","+CYCLE_CODE+ ","+SUB_CYCLE_CODE+ ","+CTRL_OBJ_CODE+ ","+STATUS+ ","+PRIORITY+ ","+REQ_TYPE+ ","+REQ_TEXT+ ","+OVERFLOW_ID+","+REQUEST_DATE+","+"MOD_DATE,MOD_USER) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }
        if(type.equalsIgnoreCase(SELECT_TYPE_OCREQ_ID)){
            return "SELECT OCREQ_ID FROM OWNER_CHANGE_REQUEST WHERE "+OWNER_ID+"=? AND "+TARGET_ID+"=?";
        }
//        if(){
//           return "SELECT OCREQ_ID FROM OWNER_CHANGE_REQUEST WHERE "+OWNER_ID+"=? AND "+TARGET_ID+"=?";
//        }
        return "";

    }

    public Date getRespApprovedDate() {
        return respApprovedDate;
    }

    public void setRespApprovedDate(Date respApprovedDate) {
        this.respApprovedDate = respApprovedDate;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }
}
