/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.mock;

import com.monsanto.wst.soxic.model.Activity;

/**
 * @author SPOLAVA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MockActivity extends Activity {
    
    public MockActivity(String subCycleId){
        setActivityId(subCycleId + "11111");
        //setOwner(new MockOwner("suresh"));
    }
    
    public static void main(String[] args) {
    }
}
