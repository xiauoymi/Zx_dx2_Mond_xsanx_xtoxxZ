package com.monsanto.wst.soxic.action;

import java.util.ArrayList;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.monsanto.wst.soxic.form.ControlObjectiveForm;
import com.monsanto.wst.soxic.model.ControlObjective;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFacade;
import com.monsanto.wst.soxic.model.headerFooter.CycleHeadFootFacade;
import com.monsanto.wst.soxic.model.headerFooter.ActivityHeadFootFacade;
import com.monsanto.wst.soxic.model.headerFooter.HeaderFooterFactory;
import com.monsanto.wst.soxic.util.SoxicConstants;

//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

/**
 * MyEclipse Struts Creation date: 02-03-2005
 * 
 * XDoclet definition:
 * 
 * @struts:action validate="true"
 */
public class ControlObjectiveCollapseAction extends Action {

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {

		ControlObjectiveForm controlObjectiveForm = (ControlObjectiveForm) form;
		
		Map map = request.getParameterMap();
		ControlObjective co = null;
		int changedLevel = controlObjectiveForm.getLevel();
		changedLevel = changedLevel - 1;
		ArrayList controllist = (ArrayList) controlObjectiveForm
				.getControlObjectiveList();
		for (int i = 0; i < controllist.size(); i++) {
			if (changedLevel == i) {
				co = (ControlObjective) controllist.get(i);
				String expcol = controlObjectiveForm.getExpcol();
				if (expcol.equalsIgnoreCase("true")) {

					co.setExpanded(true);
				} else {
					co.setExpanded(false);
				}
                setHeaderAndFooter(co, SoxicConstants.ACTIVITY);
                enableDisableSubmitButton(co, controlObjectiveForm);
            }
		}
		ActionForward forward = new ActionForward();
		forward = mapping.findForward("success");
		return forward;
	}

    private void setHeaderAndFooter(ControlObjective co, String level) {
        HeaderFooterFacade headerFooterFacade = HeaderFooterFactory.getFacade(level);
        co.setQuestionHeader(headerFooterFacade.getHeader());
        co.setQuestionFooter(headerFooterFacade.getFooter());
    }

    private void enableDisableSubmitButton(ControlObjective co, ControlObjectiveForm controlObjectiveForm) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date currentDate = new Date(System.currentTimeMillis());
        Date coStartDate = new Date(co.getStartDate().getTime());
        String cuDate = sdf.format(currentDate);
        String coDate = sdf.format(coStartDate);
        try {
            currentDate = sdf.parse(cuDate);
            coStartDate = sdf.parse(coDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (currentDate.before(coStartDate)){
            controlObjectiveForm.setLockSubmit(true);
        }
    }

}