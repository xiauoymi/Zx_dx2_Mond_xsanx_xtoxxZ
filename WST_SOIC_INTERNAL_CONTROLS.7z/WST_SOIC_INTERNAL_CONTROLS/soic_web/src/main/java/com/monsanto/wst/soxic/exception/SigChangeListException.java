package com.monsanto.wst.soxic.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Feb 14, 2006
 * Time: 10:35:53 AM
 */
public class SigChangeListException extends Exception {

    public SigChangeListException() {
        super();
    }

    public SigChangeListException(Exception e) {
        super(e);
    }
}
