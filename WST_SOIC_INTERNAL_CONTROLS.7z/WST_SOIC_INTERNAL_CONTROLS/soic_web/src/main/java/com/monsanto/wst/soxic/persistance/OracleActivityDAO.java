/*
* Created on Jan 31, 2005
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/
package com.monsanto.wst.soxic.persistance;

import java.sql.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.monsanto.wst.soxic.exception.DatabaseException;
import com.monsanto.wst.soxic.model.ActivityNew;
import com.monsanto.wst.soxic.model.SoxicBaseModel;
import com.monsanto.wst.soxic.util.SoxicUtil;
import com.monsanto.wst.soxic.util.SoxicConstants;

/**
 * @author SPOLAVA
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class OracleActivityDAO extends OracleAbstractDAO {


    protected String buildSelectQuery(Map criteria) {

        StringBuffer buf = new StringBuffer();

        buf.append("SELECT A.ACTIVITY_ID, OA.POTENTIAL_GAP, A.PREV_DEF, OA.OWNER_ID, OA.STATUS, OA.DUE_DATE, O.NAME ");
        buf.append("FROM ACTIVITY A, OWNER_ACTIVITY OA, OWNER O where A.ACTIVITY_ID = OA.ACTIVITY_ID AND O.OWNER_ID = OA.OWNER_ID AND ");
        buf.append(buildWhereCriteria(criteria));
        buf.append(" ORDER BY A.ACTIVITY_ID");

        return buf.toString();

    }


    /**
     * @param criteria
     * @return
     */
    private StringBuffer buildWhereCriteria(Map criteria) {

        Set keys = criteria.keySet();
        Iterator iter = keys.iterator();
        int count = 0;

        StringBuffer whereCriteria = new StringBuffer();

        while (iter.hasNext()) {

            String columnName = (String) iter.next();
            String value = SoxicUtil.replaceQuotes((String) criteria.get(columnName));

            if (!SoxicUtil.isEmpty(value)) {

                if (count > 0) {
                    whereCriteria.append(" AND ");
                }

                whereCriteria.append(getActivityCTRLOBJIDColumnName(columnName).trim() + " = '" + value.trim() + "'");

                count++;
            }
        }

        return whereCriteria;
    }

    private String getActivityCTRLOBJIDColumnName(String columnName) {

        return "A." + columnName;
    }


    protected SoxicBaseModel populateModel(ResultSet rs) throws DatabaseException, Exception {

        ActivityNew activity = new ActivityNew();
        try {
            activity.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activity.setStatus(rs.getString(ActivityNew.STATUS));
            activity.setGap(rs.getString(ActivityNew.POTENTIAL_GAP));
            activity.setDeficiency(rs.getString(ActivityNew.PREV_DEF));
            activity.setOwnerId(rs.getString(ActivityNew.OWNER_ID));
            activity.setOwnerName(rs.getString(ActivityNew.OWNER_NAME));
            activity.setDueDate(rs.getDate(ActivityNew.DUE_DATE));
            activity.setOwnerActivity(rs.getString(ActivityNew.ACTIVITY_ID) + SoxicUtil.getSeperator() + rs.getString(ActivityNew.OWNER_ID));

        } catch (SQLException e) {
            throw new DatabaseException("OracleActivityDao - Unable to populate the ActivityNew from the ResultSet :"
                    + e.toString());
        }


        return activity;
    }


    /* (non-Javadoc)
    * @see com.monsanto.wst.soxic.persistance.OracleAbstractDAO#update(java.util.Collection)
    */
    public void update(Collection soxicBaseModels) throws DatabaseException, Exception {
        // TODO Auto-generated method stub

    }

    public int create(SoxicBaseModel soxicBaseModel) {
        insertNewActivity((ActivityNew) soxicBaseModel);
        insertOwnerActivity((ActivityNew) soxicBaseModel);
        return -1;
    }

    public void createActivity(String sourceActivityId, String targetControlObjectiveId, String period) throws Exception {

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        ActivityNew activityNew = null;
        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT A.ACTIVITY_ID,A.ACTIVITY_CODE,A.DESCRIPTION FROM ACTIVITY A WHERE A.ACTIVITY_ID='" + sourceActivityId + "'");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                activityNew = populateCurrentModel(rs);
            }
            insertNewActivity(activityNew, targetControlObjectiveId);

            createOwnerActivity(sourceActivityId, targetControlObjectiveId + "." + activityNew.getActivityCode(), period);

            createQuestionActivity(sourceActivityId, targetControlObjectiveId + "." + activityNew.getActivityCode(), period);

            createControlCodeActivity(sourceActivityId, targetControlObjectiveId + "." + activityNew.getActivityCode(), period);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createOwnerActivity(String sourceActivityId, String targetActivityId, String period) throws Exception {

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        ActivityNew activityNew = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT OA.ACTIVITY_ID,OA.OWNER_ID FROM OWNER_ACTIVITY OA WHERE OA.ACTIVITY_ID='" + sourceActivityId + "'");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                activityNew = populateOwnerModel(rs);
                insertOwnerActivity(activityNew, targetActivityId, period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createQuestionActivity(String sourceActivityId, String targetActivityId, String period) throws Exception {

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        ActivityNew activityNew = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT QA.ACTIVITY_ID,QA.QUESTION_ID FROM QUESTION_ACTIVITY QA WHERE QA.ACTIVITY_ID='" + sourceActivityId + "'");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                activityNew = populateQuestionModel(rs);
                insertQuestionActivity(activityNew, targetActivityId, period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void createControlCodeActivity(String sourceActivityId, String targetActivityId, String period) throws Exception {

        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        ActivityNew activityNew = null;

        try {
            con = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = con.prepareStatement("SELECT COC.ACTIVITY_ID,COC.TYPE,COC.CODE FROM CTRL_OBJ_CODES COC WHERE COC.ACTIVITY_ID='" + sourceActivityId + "'");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                activityNew = populateControlCodeModel(rs);
                insertControlCodeActivity(activityNew, targetActivityId, period);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                //con.close();
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    private ActivityNew populateCurrentModel(ResultSet rs) throws DatabaseException, Exception {

        ActivityNew activity = new ActivityNew();
        try {
            activity.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activity.setActivityCode(rs.getString(ActivityNew.ACTIVITY_CODE));
            activity.setDescription(rs.getString(ActivityNew.DESCRIPTION));

            //activity.setStatus(rs.getString(ActivityNew.STATUS));
            //activity.setGap(rs.getString(ActivityNew.POTENTIAL_GAP));
            //activity.setDeficiency(rs.getString(ActivityNew.PREV_DEF));
            //activity.setOwnerId(rs.getString(ActivityNew.OWNER_ID));
            //activity.setOwnerName(rs.getString(ActivityNew.OWNER_NAME));
            //activity.setDueDate(rs.getDate(ActivityNew.DUE_DATE));
            //activity.setOwnerActivity(rs.getString(ActivityNew.ACTIVITY_ID)+SoxicUtil.getSeperator()+rs.getString(ActivityNew.OWNER_ID));

        } catch (SQLException e) {
            throw new DatabaseException("OracleActivityDao - Unable to populate the ActivityNew from the ResultSet :"
                    + e.toString());
        }


        return activity;
    }

    public ActivityNew populateOwnerModel(ResultSet rs) {
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setOwnerId(rs.getString(ActivityNew.OWNER_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    public ActivityNew populateQuestionModel(ResultSet rs) {
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setQuestionId(rs.getString(ActivityNew.QUESTION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    private ActivityNew populateControlCodeModel(ResultSet rs) {
        ActivityNew activityNew = new ActivityNew();

        try {

            activityNew.setActivityId(rs.getString(ActivityNew.ACTIVITY_ID));
            activityNew.setCodeType(rs.getString(ActivityNew.CTRL_CODE_TYPE));
            activityNew.setCode(rs.getString(ActivityNew.CTRL_CODE));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return activityNew;
    }

    protected void insertNewActivity(ActivityNew activityNew, String targetActivityId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String query = "INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);


            preparedStatement.setString(1, targetActivityId + "." + activityNew.getActivityCode());
            preparedStatement.setString(2, activityNew.getActivityCode());
            preparedStatement.setString(3, targetActivityId);
            preparedStatement.setString(4, activityNew.getDescription());
            preparedStatement.setString(5, "");
            preparedStatement.setDate(6, new Date(System.currentTimeMillis()));
            preparedStatement.setString(7, "ADMIN");


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    protected void insertNewActivity(ActivityNew activityNew) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String query = "INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_CODE, CTRL_OBJ_ID, DESCRIPTION,OVERFLOW_ID, STATUS, PRIORITY, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);


            preparedStatement.setString(1, activityNew.getActivityId());
            preparedStatement.setString(2, activityNew.getActivityCode());
            preparedStatement.setString(3, activityNew.getCtrlObjCode());
            preparedStatement.setString(4, activityNew.getDescription());
            preparedStatement.setInt(5,activityNew.getOverFlowId());
            preparedStatement.setString(6, SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setString(7,activityNew.getPriority());
            preparedStatement.setDate(8, new Date(System.currentTimeMillis()));
            preparedStatement.setString(9, "ADMIN");


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    public void insertOwnerActivity(ActivityNew activityNew) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;


        String query = "INSERT INTO OWNER_ACTIVITY (OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, activityNew.getOwnerId());
            preparedStatement.setString(2, activityNew.getActivityId());
            preparedStatement.setString(3, SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(4, new Date(System.currentTimeMillis()));
            preparedStatement.setString(5, "ADMIN");


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    public void insertOwnerActivity(ActivityNew activityNew, String newActivityId, String period) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;


        String query = "INSERT INTO OWNER_ACTIVITY (OWNER_ID, ACTIVITY_ID, STATUS, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, activityNew.getOwnerId());
            preparedStatement.setString(2, newActivityId);
            preparedStatement.setString(3, SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(4, new Date(System.currentTimeMillis()));
            preparedStatement.setString(5, "ADMIN");


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    public void insertQuestionActivity(ActivityNew activityNew, String newActivityId, String period) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;


        String query = "INSERT INTO QUESTION_ACTIVITY (QUESTION_ID, ACTIVITY_ID, MOD_DATE, MOD_USER) VALUES (?, ?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, activityNew.getQuestionId());
            preparedStatement.setString(2, newActivityId);
            //preparedStatement.setString(3,SoxicConstants.GREEN_IMPORTED);
            preparedStatement.setDate(3, new Date(System.currentTimeMillis()));
            preparedStatement.setString(4, "ADMIN");


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    private void insertControlCodeActivity(ActivityNew activityNew, String newActivityId, String period) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;


        String query = "INSERT INTO CTRL_OBJ_CODES (ACTIVITY_ID, TYPE, CODE) VALUES (?, ?, ?)";

        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, newActivityId);
            preparedStatement.setString(2, activityNew.getCodeType());
            preparedStatement.setString(3, activityNew.getCode());


            int result = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }
    }

    public int update(String oldactivityId, String newActivityId) throws Exception {
        updateOwnerActivity(oldactivityId, newActivityId);
        updateActivity(oldactivityId, newActivityId);
        return -1;
    }

    public int delete(String oldactivityId, String newActivityId) throws Exception {
        deleteOwnerActivity(oldactivityId, newActivityId);
        deleteActivity(oldactivityId, newActivityId);
        return -1;
    }

    private int updateActivity(String oldactivityId, String newActivityId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int result = -1;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE ACTIVITY SET ACTIVITY_ID=? WHERE ACTIVITY_ID=?");
            preparedStatement.setString(1, newActivityId);
            preparedStatement.setString(2, oldactivityId);
            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
                //connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public int updateOwnerActivity(String oldactivityId, String newActivityId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int result = -1;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE OWNER_ACTIVITY SET ACTIVITY_ID=? WHERE ACTIVITY_ID=?");
            preparedStatement.setString(1, newActivityId);
            preparedStatement.setString(2, oldactivityId);
            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    private int deleteActivity(String oldactivityId, String newActivityId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int result = -1;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID=?");
            // preparedStatement.setString(1,newActivityId);
            preparedStatement.setString(1, oldactivityId);
            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public int deleteOwnerActivity(String oldactivityId, String newActivityId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int result = -1;
        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM OWNER_ACTIVITY WHERE ACTIVITY_ID=?");
            preparedStatement.setString(1, oldactivityId);
            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //enclose this in a finally block to make
            //sure the connection is closed
            try {
                SoxicConnectionFactory.closeResultSet(rs);
                SoxicConnectionFactory.closePreparedStatement(preparedStatement);
                SoxicConnectionFactory.closeSoxicConnection(connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    public void updateOverFlowId(ActivityNew activityNew){
        Connection connection = null;
        PreparedStatement preparedStatement=null;
        ResultSet rs=null;


        try {
            connection = SoxicConnectionFactory.getSoxicConnection();
            preparedStatement = connection.prepareStatement("UPDATE ACTIVITY SET OVERFLOW_ID=? WHERE ACTIVITY_ID=?");
            preparedStatement.setInt(1,activityNew.getOverFlowId());
            preparedStatement.setString(2,activityNew.getActivityId());
            int result = preparedStatement.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(rs!=null){
                    rs.close();
                }
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
            }
        }

    }

}
