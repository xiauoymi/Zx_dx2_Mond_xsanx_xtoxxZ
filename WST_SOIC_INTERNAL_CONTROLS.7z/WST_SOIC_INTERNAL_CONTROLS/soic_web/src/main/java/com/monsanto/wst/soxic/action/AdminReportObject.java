/*
 * Created on Mar 30, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.soxic.action;

import java.util.Vector;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminReportObject {
	
	int orderNumber;
		
	int reportID;
	
	String reportName;
	
	String reportDesc;
	
	Vector reportRoles = new Vector();
	
	
	/**
	 * @return Returns the orderNumber.
	 */
	public int getOrderNumber() {
		return orderNumber;
	}
	/**
	 * @param orderNumber The orderNumber to set.
	 */
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	/**
	 * @return Returns the reportDesc.
	 */
	public String getReportDesc() {
		return reportDesc;
	}
	/**
	 * @param reportDesc The reportDesc to set.
	 */
	public void setReportDesc(String reportDesc) {
		this.reportDesc = reportDesc;
	}
	/**
	 * @return Returns the reportID.
	 */
	public int getReportID() {
		return reportID;
	}
	/**
	 * @param reportID The reportID to set.
	 */
	public void setReportID(int reportID) {
		this.reportID = reportID;
	}
	/**
	 * @return Returns the reportName.
	 */
	public String getReportName() {
		return reportName;
	}
	/**
	 * @param reportName The reportName to set.
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	/**
	 * @return Returns the reportRoles.
	 */
	public Vector getReportRoles() {
		return reportRoles;
	}
	/**
	 * @param reportRoles The reportRoles to set.
	 */
	public void setReportRoles(Vector reportRoles) {
		this.reportRoles = reportRoles;
	}
}
