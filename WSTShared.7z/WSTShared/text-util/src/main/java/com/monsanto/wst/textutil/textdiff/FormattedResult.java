package com.monsanto.wst.textutil.textdiff;
/*
 FormattedResult was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class FormattedResult {
  private final String before;
  private final String after;

  public FormattedResult(String singleValue) {
    this(singleValue, singleValue);
  }

  public FormattedResult(String before, String after) {
    this.before = before;
    this.after = after;
  }

  public String getBefore() {
    return before;
  }

  public String getAfter() {
    return after;
  }
}
