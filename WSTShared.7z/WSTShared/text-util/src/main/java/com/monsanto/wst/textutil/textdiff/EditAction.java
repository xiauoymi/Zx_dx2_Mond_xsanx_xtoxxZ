package com.monsanto.wst.textutil.textdiff;

import org.incava.util.diff.Difference;
/*
 EditAction was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class EditAction {
  public static final String DELETE_TEXT = "D";
  public static final String REPLACE_TEXT = "R";
  public static final String ADD_TEXT = "A";
  public static final String NOCHANGE_TEXT = "-";

  public static final EditAction REPLACE = new EditAction("R");
  public static final EditAction DELETE = new EditAction("D");
  public static final EditAction ADD = new EditAction("A");
  public static final EditAction NO_CHANGE = new EditAction("-");

  private final String text;

  private EditAction(String text) {
    this.text = text;
  }

  public String toString() {
    return text;
  }

  public static EditAction findAction(Difference diff) {
    boolean isAdd = getIsAddDifference(diff);
    boolean isRemove = getIsRemoveDifference(diff);

    if (isAdd) {
      if (isRemove) {
        return REPLACE;
      } else {
        return ADD;
      }
    } else {
      if (isRemove) {
        return DELETE;
      } else {
        return NO_CHANGE;
      }
    }
  }

  private static boolean getIsRemoveDifference(Difference diff) {
    return ((diff.getDeletedStart() != Difference.NONE) && (diff.getDeletedEnd() != Difference.NONE));
  }

  private static boolean getIsAddDifference(Difference diff) {
    return ((diff.getAddedStart() != Difference.NONE) && (diff.getAddedEnd() != Difference.NONE));
  }
}
