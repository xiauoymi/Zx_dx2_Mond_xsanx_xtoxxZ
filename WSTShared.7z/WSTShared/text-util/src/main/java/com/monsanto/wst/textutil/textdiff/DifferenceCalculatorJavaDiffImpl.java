package com.monsanto.wst.textutil.textdiff;

import org.incava.util.diff.Diff;
import org.incava.util.diff.Difference;

import java.util.List;
/*
 DifferenceCalculatorJavaDiffImpl was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class DifferenceCalculatorJavaDiffImpl implements DifferenceCalculator {
  public Difference[] getDifferences(List<String> beforeWords, List<String> afterWords) {
    Diff diff = new Diff(beforeWords, afterWords);
    List<Difference> diffOut = diff.diff();
    return diffOut.toArray(new Difference[diffOut.size()]);
  }
}
