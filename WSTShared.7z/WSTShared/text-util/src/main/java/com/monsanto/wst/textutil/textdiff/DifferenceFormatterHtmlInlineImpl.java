package com.monsanto.wst.textutil.textdiff;

import org.incava.util.diff.Difference;

import java.util.ArrayList;
import java.util.List;
/*
 DifferenceFormatterHtmlImpl was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * Formats the result for a single dispalyed result.  Deleted text should be remain but marked, add should be marked,
 * replace should be marked as add/delete combo
 *
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class DifferenceFormatterHtmlInlineImpl implements DifferenceFormatter {
  private static final String DELETE_CLASS = "diff_delete";
  private static final String ADD_CLASS = "diff_add";
  private static final String BEGIN_DELETE_SPAN = "<span class='" + DELETE_CLASS + "'>";
  private static final String BEGIN_ADD_SPAN = "<span class='" + ADD_CLASS + "'>";
  private static final String END_SPAN = "</span>";

  public FormattedResult format(List<String> beforeWords, List<String> afterWords, Difference[] differences) {
    List<String> result = formatDiffs(beforeWords, afterWords, differences);
    String resultString = listToString(result);
    return new FormattedResult(resultString);
  }

  private String listToString(List<String> result) {
    StringBuffer buf = new StringBuffer();
    for (String st : result) {
      buf.append(st);
    }
    return buf.toString();
  }

  private List<String> formatDiffs(List<String> beforeWords, List<String> afterWords, Difference[] differences) {
    List<String> result = new ArrayList<String>(beforeWords);
    for (Difference diff : differences) {
      EditAction action = EditAction.findAction(diff);
      if (action == EditAction.REPLACE) {
        prefixWord(result, BEGIN_DELETE_SPAN, diff.getDeletedStart());
        suffixWord(result, END_SPAN, diff.getDeletedEnd());
        String toBeAdded =
            BEGIN_ADD_SPAN + getStringPortion(afterWords, diff.getAddedStart(), diff.getAddedEnd()) + END_SPAN;
        suffixWord(result, toBeAdded, diff.getDeletedEnd());
      } else if (action == EditAction.ADD) {
        String toBeAdded =
            BEGIN_ADD_SPAN + getStringPortion(afterWords, diff.getAddedStart(), diff.getAddedEnd()) + END_SPAN;
        prefixWord(result, toBeAdded, diff.getDeletedStart());
      } else if (action == EditAction.DELETE) {
        prefixWord(result, BEGIN_DELETE_SPAN, diff.getDeletedStart());
        suffixWord(result, END_SPAN, diff.getDeletedEnd());
      }
    }

    return result;
  }

  private String getStringPortion(List<String> words, int start, int end) {
    return listToString(words.subList(start, end + 1));
  }

  private String getWord(List<String> result, int pos) {
    if (pos >= result.size()) {
      return "";
    } else {
      return result.get(pos);
    }
  }

  private void setWord(List<String> result, int pos, String st) {
    if (pos >= result.size()) {
      result.add(st);
    } else {
      result.set(pos, st);
    }
  }

  private void prefixWord(List<String> result, String prefix, int pos) {
    String st = getWord(result, pos);
    st = prefix + st;
    setWord(result, pos, st);
  }

  private void suffixWord(List<String> result, String suffix, int pos) {
    String st = result.get(pos);
    st += suffix;
    setWord(result, pos, st);
  }
}
