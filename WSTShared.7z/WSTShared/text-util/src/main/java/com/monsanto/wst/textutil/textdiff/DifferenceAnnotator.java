package com.monsanto.wst.textutil.textdiff;

import org.incava.util.diff.Difference;

import java.util.List;
/*
 DifferenceAnnotator was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * Determines the difference between two strings, and formats it for display You should have CSS similar to this used by
 * the page to format the diff's as needed .diff_add { background-color: #66FF66; font-weight:bold; } .diff_delete {
 * background-color: #FF6666; text-decoration:line-through; }
 *
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class DifferenceAnnotator {
  private final Tokenizer<String, String> tokenizer;
  private final DifferenceCalculator calc;
  private final DifferenceFormatter formatter;

  public DifferenceAnnotator() {
    this(new WordTokenizer(), new DifferenceCalculatorJavaDiffImpl(), new DifferenceFormatterHtmlInlineImpl());
  }

  public DifferenceAnnotator(Tokenizer<String, String> tokenizer, DifferenceCalculator calc,
                             DifferenceFormatter formatter) {
    this.tokenizer = tokenizer;
    this.calc = calc;
    this.formatter = formatter;
  }

  public FormattedResult annotate(String before, String after) {
    List<String> beforeTokens = tokenizer.tokenize(before);
    List<String> afterTokens = tokenizer.tokenize(after);
    Difference[] diff = calc.getDifferences(beforeTokens, afterTokens);
    return formatter.format(beforeTokens, afterTokens, diff);
  }
}
