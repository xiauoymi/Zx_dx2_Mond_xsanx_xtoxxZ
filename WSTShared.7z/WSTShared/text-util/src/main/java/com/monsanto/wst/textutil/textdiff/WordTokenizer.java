package com.monsanto.wst.textutil.textdiff;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
/*
 WordTokenizer was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class WordTokenizer implements Tokenizer<String, String> {
  private static final String DELIMITERS = " \t\r\n`~!@#$%^&*()-_=+[]\\{}|;':\",./<>?";

  public List<String> tokenize(String textString) {
    if (textString == null) {
      return Collections.emptyList();
    }

    final StringTokenizer tokenizer = new StringTokenizer(textString, DELIMITERS, true);

    List<String> words = new ArrayList<String>();
    String token = getToken(tokenizer);
    while (token != null) {
      words.add(token);
      token = getToken(tokenizer);
    }
    return words;
  }

  private String getToken(StringTokenizer tokenizer) {
    if (tokenizer.hasMoreTokens()) {
      return tokenizer.nextToken();
    } else {
      return null;
    }
  }

}
