package com.monsanto.wst.textutil;

import java.io.UnsupportedEncodingException;
import java.text.Normalizer;
/*
 TextUtil was created on Oct 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class TextUtil {

  public static String escapeXml(String xml) {
    if (xml == null) {
      return "";
    } else {
      return xml.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
    }
  }

  public static String decodeUsingUTF8(String value) {

    if (value != null && value.length() > 0) {
      try {
        byte[] latin1Bytes = value.getBytes("ISO-8859-1");
        return new String(latin1Bytes, "UTF-8");
      } catch (UnsupportedEncodingException e) {
        throw new RuntimeException(e);
      }
    }else{
      return null;
    }
  }

  public static boolean contains(String string, String subString) {
    return !(string == null || subString == null) &&
        removeAccents(string.toUpperCase()).contains(removeAccents(subString.toUpperCase()));
  }

  private static String removeAccents(String accent){
    String temp = Normalizer.normalize(accent, Normalizer.Form.NFD);
    return temp.replaceAll("[^\\p{ASCII}]", "");
  }
}
