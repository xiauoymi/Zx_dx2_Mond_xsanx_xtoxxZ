package com.monsanto.wst.textutil.textdiff;

import org.incava.util.diff.Difference;

import java.util.List;
/*
 DifferenceCalculator was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface DifferenceCalculator {
  Difference[] getDifferences(List<String> beforeWords, List<String> afterWords);
}
