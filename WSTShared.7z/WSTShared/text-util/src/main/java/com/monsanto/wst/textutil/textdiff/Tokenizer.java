package com.monsanto.wst.textutil.textdiff;

import java.util.List;/*
 Tokenizer was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface Tokenizer<T, S> {
  List<T> tokenize(S text);
}
