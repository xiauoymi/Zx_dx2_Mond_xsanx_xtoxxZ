package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;
import org.incava.util.diff.Difference;

/*
 EditAction_UT was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class EditAction_UT extends TestCase {
  public void testGetActionForDelete() throws Exception {
    EditAction delAction = EditAction.findAction(new Difference(0, 1, Difference.NONE, Difference.NONE));
    assertNotNull(delAction);
    assertEquals(EditAction.DELETE_TEXT, delAction.toString());
  }

  public void testGetActionForReplace() throws Exception {
    EditAction replaceAction = EditAction.findAction(new Difference(0, 1, 0, 1));
    assertNotNull(replaceAction);
    assertEquals(EditAction.REPLACE_TEXT, replaceAction.toString());
  }

  public void testGetActionForAdd() throws Exception {
    EditAction addAction = EditAction.findAction(new Difference(Difference.NONE, Difference.NONE, 0, 1));
    assertNotNull(addAction);
    assertEquals(EditAction.ADD_TEXT, addAction.toString());
  }

  public void testGetActionForNoChange() throws Exception {
    EditAction noChange = EditAction
        .findAction(new Difference(Difference.NONE, Difference.NONE, Difference.NONE, Difference.NONE));
    assertNotNull(noChange);
    assertEquals(EditAction.NOCHANGE_TEXT, noChange.toString());
  }

  public void testSameActionsAreSameObject() throws Exception {
    EditAction addAction1 = EditAction.findAction(new Difference(Difference.NONE, Difference.NONE, 22, 33));
    EditAction addAction2 = EditAction.findAction(new Difference(Difference.NONE, Difference.NONE, 0, 1));
    assertEquals(addAction1, addAction2);
    assertTrue(addAction1 == addAction2);
  }

  public void testDifferentActionsAreNotEqual() throws Exception {
    EditAction replaceAction = EditAction.findAction(new Difference(1, 2, 22, 33));
    EditAction addAction = EditAction.findAction(new Difference(Difference.NONE, Difference.NONE, 0, 1));
    assertFalse(replaceAction.equals(addAction));
    assertFalse(replaceAction == addAction);
  }
}