package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;
import org.incava.util.diff.Difference;

import java.util.ArrayList;
import java.util.List;

/*
 DifferenceAnnotator_UT was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DifferenceAnnotator_UT extends TestCase {

  public void testThreeStagesCalled() throws Exception {
    List<String> tokens = new ArrayList<String>();
    Difference[] diff = new Difference[0];
    FormattedResult expectedResult = new FormattedResult("foo", "bar");

    MockTokenizer tokenizer = new MockTokenizer(tokens);
    MockCalculator calc = new MockCalculator(diff);
    MockFormatter fmt = new MockFormatter(expectedResult);

    DifferenceAnnotator diffAnnotator = new DifferenceAnnotator(tokenizer, calc, fmt);
    assertFalse(tokenizer.wasTokenizeCalled());
    assertFalse(calc.wasCalculateCalled());
    assertFalse(fmt.wasFormatCalled());

    FormattedResult result = diffAnnotator.annotate("Some String", "Some Other String");

    assertTrue(tokenizer.wasTokenizeCalled());
    assertTrue(calc.wasCalculateCalled());
    assertTrue(fmt.wasFormatCalled());

    assertEquals(expectedResult.getBefore(), result.getBefore());
    assertEquals(expectedResult.getAfter(), result.getAfter());
  }

  public void testUseRealObject() throws Exception {
    DifferenceAnnotator diffAnnotator = new DifferenceAnnotator();
    assertNotNull(diffAnnotator);
    FormattedResult result = diffAnnotator.annotate("Before String", "After String");
    assertNotNull(result);
  }

  private static class MockTokenizer implements Tokenizer<String, String> {
    private final List<String> tokens;
    private boolean tokenizeCalled = false;

    public MockTokenizer(List<String> tokens) {
      this.tokens = tokens;
    }

    public List<String> tokenize(String text) {
      tokenizeCalled = true;
      return tokens;
    }

    public boolean wasTokenizeCalled() {
      return tokenizeCalled;
    }
  }

  private static class MockCalculator implements DifferenceCalculator {
    private boolean calculateCalled = false;
    private final Difference[] diff;

    public MockCalculator(Difference[] diff) {
      this.diff = diff;
    }

    public Difference[] getDifferences(List<String> beforeWords, List<String> afterWords) {
      calculateCalled = true;
      return diff;
    }

    public boolean wasCalculateCalled() {
      return calculateCalled;
    }
  }

  private static class MockFormatter implements DifferenceFormatter {
    private final FormattedResult result;
    private boolean formatCalled = false;

    public MockFormatter(FormattedResult result) {
      this.result = result;
    }

    public FormattedResult format(List<String> beforeWords, List<String> afterWords, Difference[] differences) {
      formatCalled = true;
      return result;
    }

    public boolean wasFormatCalled() {
      return formatCalled;
    }
  }
}