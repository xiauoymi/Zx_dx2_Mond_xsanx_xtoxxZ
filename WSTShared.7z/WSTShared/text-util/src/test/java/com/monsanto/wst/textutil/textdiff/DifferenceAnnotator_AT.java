package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;

/*
 DifferenceAnnotator_AT was created on Mar 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DifferenceAnnotator_AT extends TestCase {
  public static final String TEST_STRING_5 =
      "1.\tForecast contains Hypothetical products.  For example, in the �Branded� channel:\n" +
          "a.\tIn the Hybrid plan, will these products come from DFS, or will the planners wish to �add� to an existing Rev?\n" +
          "b.\tDiscussed with the Parent planners, how to add a hypothetical product to the plan.  We�re, currently, not able to accept an incremental Revision of a forecasted product within a Channel.  Alternative is to add the hypothetical product to an existing Channel forecast and to re-import the entire forecast.  If the user does not want to change an existing Channel forecast, then they might consider using a hypothetical channel ID, causing the product forecast to appear in the �other� column, distinct from the Channels.";
  public static final String TEST_STRING_6 =
      "1.\tForecast contains Hypothetical products.  For the �Branded� channel:\n" +
          "a.\tIn the Hybrid plan, will these products come from DFS, or will the planners wish to �add� to an existing Rev?\n" +
          "b.\tIn the Parent plan, will these products come from the Hybrid plan, or will the planners wish to �add� to an existing Rev?";


  public void testRemoveEveryOtherWord() throws Exception {
    final String testString1 = "Hello my name is Ken";
    final String testString2 = "Hello    Ken";
    DifferenceAnnotator diff = new DifferenceAnnotator();
    FormattedResult result = diff.annotate(testString1, testString2);
    String expectedResult = "Hello <span class='diff_delete'>my</span> <span class='diff_delete'>name</span> <span class='diff_delete'>is</span> Ken";
    assertEquals(expectedResult, result.getBefore());
  }

  public void testAddEveryOtherWord() throws Exception {
    final String testString1 = "Hello    Ken";
    final String testString2 = "Hello my name is Ken";
    DifferenceAnnotator diff = new DifferenceAnnotator();
    FormattedResult result = diff.annotate(testString1, testString2);
    String expectedResult = "Hello <span class='diff_add'>my</span> <span class='diff_add'>name</span> <span class='diff_add'>is</span> Ken";
    assertEquals(expectedResult, result.getBefore());
  }

  public void testLoremIpsumTest() throws Exception {
    final String TEST_STRING_1 = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum";
    final String TEST_STRING_2 = "Lorem ipsum, quia dolor sit, amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur? [33] At vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum";

    DifferenceAnnotator diff = new DifferenceAnnotator();
    FormattedResult result = diff.annotate(TEST_STRING_1, TEST_STRING_2);
    String expectedResult = "Lorem ipsum<span class='diff_add'>,</span> <span class='diff_add'>quia </span>dolor sit<span class='diff_add'>,</span> amet, consectetur<span class='diff_add'>,</span> <span class='diff_delete'>adipisicing</span><span class='diff_add'>adipisci</span> <span class='diff_delete'>elit</span><span class='diff_add'>velit</span>, sed <span class='diff_delete'>do</span><span class='diff_add'>quia</span> <span class='diff_delete'>eiusmod</span><span class='diff_add'>non</span> <span class='diff_delete'>tempor</span><span class='diff_add'>numquam</span> <span class='diff_delete'>incididunt</span><span class='diff_add'>eius</span> <span class='diff_add'>modi tempora incidunt, </span>ut labore et dolore <span class='diff_delete'>magna</span><span class='diff_add'>magnam</span> <span class='diff_delete'>aliqua</span><span class='diff_add'>aliquam quaerat voluptatem</span>. Ut enim ad <span class='diff_delete'>minim</span><span class='diff_add'>minima</span> veniam, quis <span class='diff_delete'>nostrud</span><span class='diff_add'>nostrum</span> <span class='diff_delete'>exercitation</span><span class='diff_add'>exercitationem</span> <span class='diff_delete'>ullamco</span><span class='diff_add'>ullam</span> <span class='diff_delete'>laboris</span><span class='diff_add'>corporis</span> <span class='diff_add'>suscipit laboriosam, </span>nisi ut <span class='diff_delete'>aliquip</span><span class='diff_add'>aliquid</span> ex ea <span class='diff_delete'>commodo</span><span class='diff_add'>commodi</span> <span class='diff_delete'>consequat.</span><span class='diff_add'>consequatur?</span> <span class='diff_delete'>Duis</span><span class='diff_add'>Quis</span> <span class='diff_delete'>aute</span><span class='diff_add'>autem</span> <span class='diff_delete'>irure</span><span class='diff_add'>vel</span> <span class='diff_delete'>dolor</span><span class='diff_add'>eum</span> <span class='diff_delete'>in</span><span class='diff_add'>iure</span> reprehenderit<span class='diff_add'>,</span> <span class='diff_add'>qui </span>in <span class='diff_add'>ea </span>voluptate velit esse<span class='diff_add'>,</span> <span class='diff_delete'>cillum</span><span class='diff_add'>quam</span> <span class='diff_delete'>dolore</span><span class='diff_add'>nihil</span> <span class='diff_delete'>eu</span><span class='diff_add'>molestiae</span> <span class='diff_add'>consequatur, vel illum, qui dolorem eum </span>fugiat<span class='diff_add'>,</span> <span class='diff_add'>quo voluptas </span>nulla pariatur<span class='diff_delete'>.</span><span class='diff_add'>?</span> <span class='diff_delete'>Excepteur</span><span class='diff_add'>[33]</span> <span class='diff_add'>At vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi </span>sint<span class='diff_add'>,</span> <span class='diff_delete'>occaecat</span><span class='diff_add'>obcaecati</span> <span class='diff_delete'>cupidatat</span><span class='diff_add'>cupiditate</span> non <span class='diff_delete'>proident</span><span class='diff_add'>provident</span>, <span class='diff_add'>similique </span>sunt in culpa<span class='diff_add'>,</span> qui officia deserunt <span class='diff_delete'>mollit</span><span class='diff_add'>mollitia</span> <span class='diff_delete'>anim</span><span class='diff_add'>animi,</span> id est laborum";
    assertEquals(expectedResult, result.getBefore());
  }

  public void testLincoln() throws Exception {
    final String TEST_STRING_1 =
        "Four score and seven years ago our fathers brought forth on this continent a new nation, conceived in Liberty, and dedicated to the proposition that all men are created equal.\n" +
            "\n" +
            "Now we are engaged in a great civil war, testing whether that nation, or any nation, so conceived and so dedicated, can long endure. We are met on a great battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.\n" +
            "\n" +
            "\n" +
            "But, in a larger sense, we can not dedicate�we can not consecrate�we can not hallow�this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us�that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion�that we here highly resolve that these dead shall not have died in vain�that this nation, under God, shall have a new birth of freedom�and that government of the people, by the people, for the people, shall not perish from the earth.";
    final String TEST_STRING_2 =
        "Eighty-seven years ago our fathers formed on this continent a new nation, conceived in Liberty, and dedicated to the belief that everyone is created equal.\n" +
            "\n" +
            "Now we are engaged in a civil war, testing whether we, or any nation, so conceived and so dedicated, can last. We are met on a battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.\n" +
            "\n" +
            "\n" +
            "But, in a larger sense, we can not dedicate�we can not consecrate�we can not hallow�this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us�that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion�that we here highly resolve that these dead shall not have died in vain�that this nation, under God, shall have a new birth of freedom�and that government of the people, by the people, for the people, shall not perish from the earth. - Abraham Lincoln";

    DifferenceAnnotator diff = new DifferenceAnnotator();
    FormattedResult result = diff.annotate(TEST_STRING_1, TEST_STRING_2);
    String expectedResult =
        "<span class='diff_delete'>Four score and </span><span class='diff_add'>Eighty-</span>seven years ago our fathers <span class='diff_delete'>brought</span><span class='diff_add'>formed</span> <span class='diff_delete'>forth </span>on this continent a new nation, conceived in Liberty, and dedicated to the <span class='diff_delete'>proposition</span><span class='diff_add'>belief</span> that <span class='diff_delete'>all</span><span class='diff_add'>everyone</span> <span class='diff_delete'>men</span><span class='diff_add'>is</span> <span class='diff_delete'>are </span>created equal.\n" +
            "\n" +
            "Now we are engaged in a <span class='diff_delete'>great </span>civil war, testing whether <span class='diff_delete'>that nation</span><span class='diff_add'>we</span>, or any nation, so conceived and so dedicated, can <span class='diff_delete'>long endure</span><span class='diff_add'>last</span>. We are met on a <span class='diff_delete'>great </span>battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.\n" +
            "\n" +
            "\n" +
            "But, in a larger sense, we can not dedicate�we can not consecrate�we can not hallow�this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us�that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion�that we here highly resolve that these dead shall not have died in vain�that this nation, under God, shall have a new birth of freedom�and that government of the people, by the people, for the people, shall not perish from the earth.<span class='diff_add'> - Abraham Lincoln</span>";
    assertEquals(expectedResult, result.getBefore());
  }

  public void testGenerateHTMLOutput() throws Exception {
    final String TEST_STRING_1 =
        "Four score and seven years ago our fathers brought forth on this continent a new nation, conceived in Liberty, and dedicated to the proposition that all men are created equal.\n" +
            "\n" +
            "Now we are engaged in a great civil war, testing whether that nation, or any nation, so conceived and so dedicated, can long endure. We are met on a great battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.\n" +
            "\n" +
            "\n" +
            "But, in a larger sense, we can not dedicate�we can not consecrate�we can not hallow�this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us�that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion�that we here highly resolve that these dead shall not have died in vain�that this nation, under God, shall have a new birth of freedom�and that government of the people, by the people, for the people, shall not perish from the earth.";
    final String TEST_STRING_2 =
        "Eighty-seven years ago our fathers formed on this continent a new nation, conceived in Liberty, and dedicated to the belief that everyone is created equal.\n" +
            "\n" +
            "Now we are engaged in a civil war, testing whether we, or any nation, so conceived and so dedicated, can last. We are met on a battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.\n" +
            "\n" +
            "\n" +
            "But, in a larger sense, we can not dedicate�we can not consecrate�we can not hallow�this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us�that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion�that we here highly resolve that these dead shall not have died in vain�that this nation, under God, shall have a new birth of freedom�and that government of the people, by the people, for the people, shall not perish from the earth. - Abraham Lincoln";

    System.out.println("<html><head><title>Text Diff Test</title>");
    System.out.println("<style type=\"text/css\">\n" +
        "  .diff_replace {\n" +
        "    background-color: #6666FF;\n" +
        "    font-weight:bold;\n" +
        "  }\n" +
        "\n" +
        "  .diff_add {\n" +
        "    background-color: #66FF66;\n" +
        "    font-weight:bold;\n" +
        "  }\n" +
        "\n" +
        "  .diff_delete {\n" +
        "    background-color: #FF6666;\n" +
        "    text-decoration:line-through;\n" +
        "  }\n" +
        "</style>");
    System.out.println("</head><body>");

    System.out.println("<h1>Original Strings</h1>");
    System.out.println(TEST_STRING_1);
    System.out.println("<p>");
    System.out.println(TEST_STRING_2);

    long startTime = System.currentTimeMillis();
    DifferenceAnnotator diff = new DifferenceAnnotator();
    FormattedResult result = diff.annotate(TEST_STRING_1, TEST_STRING_2);
    long endTime = System.currentTimeMillis();

    System.out.println("<p>");
    System.out.println("<h1>Formated Difference</h1>");
    System.out.println(result.getBefore());

    System.out.println("<p>");
    System.out.println("Elapsed Time: <b>" + (endTime - startTime) + " ms</b><p>");
    System.out.println("<hr>");

    System.out.println("</body></html>");
  }

}