package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;
import org.incava.util.diff.Difference;

import java.util.ArrayList;
import java.util.List;

/*
 DifferenceAnnotator_UT was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DifferenceFormatterHtmlInlineImpl_UT extends TestCase {
  //* Formats the result for a single dispalyed result.  Deleted text should be remain but marked, add should be marked, replace should be marked as add/delete combo

  public void testNoDiffDoesNotAlterFormat() throws Exception {
    DifferenceFormatter fmt = new DifferenceFormatterHtmlInlineImpl();
    List<String> beforeWords = new ArrayList<String>();
    beforeWords.add("Hello");
    beforeWords.add(",");
    beforeWords.add(" ");
    beforeWords.add("world");
    beforeWords.add(".");
    List<String> afterWords = new ArrayList<String>(beforeWords);
    String expectedResult = "Hello, world.";
    FormattedResult result = fmt.format(beforeWords, afterWords, new Difference[0]);
    assertNotNull(result);
    assertEquals(result.getBefore(), result.getAfter());
    assertEquals(expectedResult, result.getAfter());
  }

  public void testDeletesAreFormatted() throws Exception {
    DifferenceFormatter fmt = new DifferenceFormatterHtmlInlineImpl();
    List<String> beforeWords = new ArrayList<String>();
    beforeWords.add("Hello");
    beforeWords.add(",");
    beforeWords.add(" ");
    beforeWords.add("world");
    beforeWords.add(".");
    List<String> afterWords = new ArrayList<String>();
    afterWords.add("Hello");
    afterWords.add(",");
    afterWords.add(" ");
    afterWords.add("world");
    String expectedResult = "Hello, world<span class='diff_delete'>.</span>";
    Difference[] diff = new Difference[1];
    diff[0] = new Difference(4, 4, Difference.NONE, Difference.NONE);
    FormattedResult result = fmt.format(beforeWords, afterWords, diff);
    assertNotNull(result);
    assertEquals(result.getBefore(), result.getAfter());
    assertEquals(expectedResult, result.getAfter());
  }

  public void testAddsAreFormatted() throws Exception {
    DifferenceFormatter fmt = new DifferenceFormatterHtmlInlineImpl();
    List<String> beforeWords = new ArrayList<String>();
    beforeWords.add("Hello");
    beforeWords.add(",");
    beforeWords.add(" ");
    beforeWords.add("world");
    List<String> afterWords = new ArrayList<String>();
    afterWords.add("Hello");
    afterWords.add(",");
    afterWords.add(" ");
    afterWords.add("world");
    afterWords.add(".");
    String expectedResult = "Hello, world<span class='diff_add'>.</span>";
    Difference[] diff = new Difference[1];
    diff[0] = new Difference(4, Difference.NONE, 4, 4);
    FormattedResult result = fmt.format(beforeWords, afterWords, diff);
    assertNotNull(result);
    assertEquals(result.getBefore(), result.getAfter());
    assertEquals(expectedResult, result.getAfter());
  }

  public void testReplacesAreFormatted() throws Exception {
    DifferenceFormatter fmt = new DifferenceFormatterHtmlInlineImpl();
    List<String> beforeWords = new ArrayList<String>();
    beforeWords.add("Hello");
    beforeWords.add(",");
    beforeWords.add(" ");
    beforeWords.add("world");
    beforeWords.add(".");
    List<String> afterWords = new ArrayList<String>();
    afterWords.add("Hello");
    afterWords.add(",");
    afterWords.add(" ");
    afterWords.add("world");
    afterWords.add("!");
    String expectedResult = "Hello, world<span class='diff_delete'>.</span><span class='diff_add'>!</span>";
    Difference[] diff = new Difference[1];
    diff[0] = new Difference(4, 4, 4, 4);
    FormattedResult result = fmt.format(beforeWords, afterWords, diff);
    assertNotNull(result);
    assertEquals(result.getBefore(), result.getAfter());
    assertEquals(expectedResult, result.getAfter());
  }

  public void testMutipleActions() throws Exception {
    DifferenceFormatter fmt = new DifferenceFormatterHtmlInlineImpl();
    List<String> beforeWords = new ArrayList<String>();
    beforeWords.add("Hello");
    beforeWords.add(",");
    beforeWords.add(" ");
    beforeWords.add("world");
    beforeWords.add(".");
    List<String> afterWords = new ArrayList<String>();
    afterWords.add("Goodbye");
    afterWords.add(",");
    afterWords.add("test");
    afterWords.add(".");
    String expectedResult = "<span class='diff_delete'>Hello</span><span class='diff_add'>Goodbye</span>,<span class='diff_delete'> world</span><span class='diff_add'>test</span>.";
    Difference[] diff = new Difference[3];
    diff[0] = new Difference(0, 0, 0, 0);
    diff[1] = new Difference(2, 3, Difference.NONE, Difference.NONE);
    diff[2] = new Difference(4, Difference.NONE, 2, 2);
    FormattedResult result = fmt.format(beforeWords, afterWords, diff);
    assertNotNull(result);
    assertEquals(result.getBefore(), result.getAfter());
    assertEquals(expectedResult, result.getAfter());
  }

}