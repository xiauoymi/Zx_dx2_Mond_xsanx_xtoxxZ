package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;
import org.incava.util.diff.Difference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 DifferenceCalculatorJavaDiffImpl_UT was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DifferenceCalculatorJavaDiffImpl_UT extends TestCase {
  public void testEmptyStringsHaveNoDifference() throws Exception {
    DifferenceCalculator calc = new DifferenceCalculatorJavaDiffImpl();
    List<String> before = Collections.emptyList();
    List<String> after = Collections.emptyList();
    Difference[] diff = calc.getDifferences(before, after);
    assertNotNull(diff);
    assertEquals(0, diff.length);
  }

  public void testSameStringsHaveNoDifference() throws Exception {
    DifferenceCalculator calc = new DifferenceCalculatorJavaDiffImpl();
    List<String> before = new ArrayList<String>();
    before.add("Hello");
    before.add(",");
    before.add(" ");
    before.add("JUnit");

    List<String> after = new ArrayList<String>(before);
    Difference[] diff = calc.getDifferences(before, after);
    assertNotNull(diff);
    assertEquals(0, diff.length);
  }

  public void testStringWithEmptyStringIsAllDelete() throws Exception {
    DifferenceCalculator calc = new DifferenceCalculatorJavaDiffImpl();
    List<String> before = new ArrayList<String>();
    before.add("Hello");
    before.add(",");
    before.add(" ");
    before.add("JUnit");

    List<String> after = Collections.emptyList();
    Difference[] diff = calc.getDifferences(before, after);
    assertNotNull(diff);
    assertFalse(diff.length == 0);
    for (Difference diffItem : diff) {
      EditAction action = EditAction.findAction(diffItem);
      assertNotNull(action);
      assertEquals(EditAction.DELETE, action);
    }
  }

  public void testEmptyStringWithStringIsAllAdd() throws Exception {
    DifferenceCalculator calc = new DifferenceCalculatorJavaDiffImpl();
    List<String> before = Collections.emptyList();
    List<String> after = new ArrayList<String>();
    after.add("Hello");
    after.add(",");
    after.add(" ");
    after.add("JUnit");
    Difference[] diff = calc.getDifferences(before, after);
    assertNotNull(diff);
    assertFalse(diff.length == 0);
    for (Difference diffItem : diff) {
      EditAction action = EditAction.findAction(diffItem);
      assertNotNull(action);
      assertEquals(EditAction.ADD, action);
    }
  }

  public void testTwoDifferentWordsAreNotAllAddOrAllDelete() throws Exception {
    // note: we are NOT trying guarantee an OPTIMAL difference, only a CORRECT one
    // correct being defined as some set of steps that will convert the first string into the second
    // this test is a 'smoke test' of this, we are not re-testing the functionality of JavaDiff itself
    DifferenceCalculator calc = new DifferenceCalculatorJavaDiffImpl();
    List<String> before = new ArrayList<String>();
    before.add("Hello");
    before.add(",");
    List<String> after = new ArrayList<String>();
    after.add("JUnit");
    after.add("!");
    Difference[] diff = calc.getDifferences(before, after);
    assertNotNull(diff);
    boolean hasReplace = false;
    boolean hasAdd = false;
    boolean hasDelete = false;

    for (Difference diffItem : diff) {
      EditAction action = EditAction.findAction(diffItem);
      assertNotNull(action);
      if (action == EditAction.REPLACE) {
        hasReplace = true;
      } else if (action == EditAction.DELETE) {
        hasDelete = true;
      } else if (action == EditAction.ADD) {
        hasAdd = true;
      }
    }
    assertTrue("Must either have a replace diff, or have add and remove diffs",
        hasReplace || (hasDelete && hasAdd));
  }
}