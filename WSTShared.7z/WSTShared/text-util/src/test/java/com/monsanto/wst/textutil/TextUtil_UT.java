package com.monsanto.wst.textutil;

import junit.framework.TestCase;

/*
 TextUtil_UT was created on Oct 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class TextUtil_UT extends TestCase {

  public void testExcapeXml() throws Exception {
    String xml = TextUtil.escapeXml("H&R>P<");
    assertEquals("H&amp;R&gt;P&lt;", xml);
  }

  public void testExcapeXml_StringIsNull() throws Exception {
    String xml = TextUtil.escapeXml(null);
    assertEquals("", xml);
  }

  public void testRestoreSpecialCharacters_StringIsNull_ReturnsNull() throws Exception {
    String str = TextUtil.decodeUsingUTF8(null);
    assertNull(str);
  }

  public void testRestoreSpecialCharacters_StringIsEmpty_ReturnsNull() throws Exception {
    String str = TextUtil.decodeUsingUTF8("");
    assertNull(str);
  }

  public void testRestoreSpecialCharacters_Ascii_ReturnsAscii() throws Exception {
    String str = TextUtil.decodeUsingUTF8("abc");
    assertEquals("abc", str);
  }

  public void testRestoreSpecialCharacters_ReturnsAccentCharacter() throws Exception {
    String str = TextUtil.decodeUsingUTF8("ábc");
    assertEquals("�bc", str);
  }

  public void testContains_StringWithAceents() throws Exception {
    assertTrue(TextUtil.contains("�bc", "A"));
  }

  public void testContains_SubStringWithAceents() throws Exception {
    assertTrue(TextUtil.contains("Abc", "�"));
  }

  public void testContains_BothWithAceents() throws Exception {
    assertTrue(TextUtil.contains("�bc", "�"));
  }

  public void testContains_NoneWithAceents() throws Exception {
    assertTrue(TextUtil.contains("Abc", "A"));
  }

  public void testContains_StringIsNull() throws Exception {
    assertFalse(TextUtil.contains(null, "A"));
  }

  public void testContains_SubStringIsNull() throws Exception {
    assertFalse(TextUtil.contains("abc", null));
  }

  public void testContains_BothAreNull() throws Exception {
    assertFalse(TextUtil.contains(null, null));
  }
}