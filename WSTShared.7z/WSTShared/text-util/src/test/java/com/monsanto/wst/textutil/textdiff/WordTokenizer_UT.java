package com.monsanto.wst.textutil.textdiff;

import junit.framework.TestCase;

import java.util.List;

/*
 WordTokenizer_UT was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class WordTokenizer_UT extends TestCase {
  public void testEmptyStringIsTokenizerAsEmptyList() throws Exception {
    WordTokenizer tokenizer = new WordTokenizer();
    List<String> tokensForNull = tokenizer.tokenize(null);
    List<String> tokensForBlank = tokenizer.tokenize("");
    assertNotNull(tokensForNull);
    assertEquals(0, tokensForNull.size());
    assertNotNull(tokensForBlank);
    assertEquals(0, tokensForBlank.size());
  }

  public void testSingleWordTokenizedIntoSingleElementList() throws Exception {
    String testText = "Hello";
    WordTokenizer tokenizer = new WordTokenizer();
    List<String> tokens = tokenizer.tokenize(testText);
    assertNotNull(tokens);
    assertEquals(1, tokens.size());
    assertEquals(testText, tokens.get(0));
  }

  public void testStringOfWordsTokenizedIntoListSpaceBetween() throws Exception {
    String testWord1 = "Hello";
    String testWord2 = "World";
    String testText = testWord1 + ' ' + testWord2;
    WordTokenizer tokenizer = new WordTokenizer();
    List<String> tokens = tokenizer.tokenize(testText);
    assertNotNull(tokens);
    assertEquals(3, tokens.size());
    assertEquals(testWord1, tokens.get(0));
    assertEquals(" ", tokens.get(1));
    assertEquals(testWord2, tokens.get(2));
  }

  public void testStringOfWordsTokenizedIntoListDifferentDelimiters() throws Exception {
    String testWord1 = "Hello";
    String testWord2 = "World";
    String testText = testWord1 + ", " + testWord2 + '.';
    WordTokenizer tokenizer = new WordTokenizer();
    List<String> tokens = tokenizer.tokenize(testText);
    assertNotNull(tokens);
    assertEquals(5, tokens.size());
    assertEquals(testWord1, tokens.get(0));
    assertEquals(",", tokens.get(1));
    assertEquals(" ", tokens.get(2));
    assertEquals(testWord2, tokens.get(3));
    assertEquals(".", tokens.get(4));
  }
}