/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.Util.XMLRPC;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;

import java.util.Vector;
import java.util.Date;
import java.util.Hashtable;

import java.beans.PropertyDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.BeanInfo;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author SRKARNA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ValueConverter {

    private static Log log = LogFactory.getLog(ValueConverter.class);

	
	public static Object convertFromType(Object obj) 
						throws IllegalArgumentException, IllegalAccessException, 
								InvocationTargetException, IntrospectionException 
	{
		if (obj == null) 
		{
  			return null;
		}

		Class type = obj.getClass();
		if (type.equals(Integer.class)
							|| type.equals(Double.class)
							|| type.equals(Boolean.class)
							|| type.equals(String.class)
							|| type.equals(Date.class)) 
		{
  			return obj;
		}
		else if (type.isArray() && type.getComponentType().equals(byte.class)) 
		{
  			return obj;
		}
		else if (type.isArray()) 
		{
			int length = Array.getLength(obj);
			Vector res = new Vector();
			for (int i = 0; i < length; i++) 
			{
				res.add(convertFromType(Array.get(obj, i)));
			}
			return res;
		}
		else 
		{
			Hashtable res = new Hashtable();
			BeanInfo info = Introspector.getBeanInfo(type, Object.class);
			PropertyDescriptor[] props = info.getPropertyDescriptors();
			for (int i = 0; i < props.length; i++) 
			{
				String propName = props[i].getName();
				Object value = null;
				value = convertFromType(props[i].getReadMethod().invoke(obj, null));
				if (value != null) res.put(propName, value);
			}
  			return res;
		}
	}


	public static Object convertToType(Object object, Class type) 
							throws IllegalArgumentException, IllegalAccessException, 
									InvocationTargetException, IntrospectionException, 
										InstantiationException 
	{
		if (type.equals(int.class)
						|| type.equals(double.class)
						|| type.equals(boolean.class)
						|| type.equals(String.class)
						|| type.equals(Date.class)) 
		{
			return object;
		}
		else if (type.isArray() && type.getComponentType().equals(byte.class)) 
		{
			return object;
		}
		else if (type.isArray()) 
		{
  			int length = ((Vector) object).size();
  			Class compType = type.getComponentType();
  			Object res = Array.newInstance(compType, length);

  			for (int i = 0; i < length; i++) 
  			{
				Object value = ((Vector) object).get(i);
		        if (log.isDebugEnabled()) {
		            log.debug("ValueConverter::convertToType (type.isArray) - " + compType.toString() + " - value = " + value.toString());
		        }
				Array.set(res, i, convertToType(value, compType));
  			}

  			return res;
		}
		else 
		{
  			Object res = type.newInstance();
  			BeanInfo info = Introspector.getBeanInfo(type, Object.class);
  			PropertyDescriptor[] props = info.getPropertyDescriptors();
  			for (int i = 0; i < props.length; i++) 
  			{
     			String propName = props[i].getName();
     			if (((Hashtable) object).containsKey(propName)) 
     			{
        				Class propType = props[i].getPropertyType();
        		        if (log.isDebugEnabled()) {
        		            log.debug("ValueConverter::convertToType - " + propName + " " + propType.getClass().toString());
        		        }
        				props[i].getWriteMethod().invoke(res, new Object[] { convertToType(((Hashtable) object).get(propName), propType)});
     			}
  			}
  			return res;
		}
	}

}
