/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.Util.XMLRPC;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlrpc.XmlRpc;
import org.apache.xmlrpc.XmlRpcClient;
import org.apache.xmlrpc.XmlRpcException;

/**
 * @author SRKARNA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class XMLRPCInvocationHandler implements InvocationHandler 
{
	   private Class type;
	   private static Log log = LogFactory.getLog(XMLRPCInvocationHandler.class);
	  
	   public XMLRPCInvocationHandler(Class ifType) 
	   {
	      this.type = ifType;
	   }

	/* (non-Javadoc)
	 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
	 */
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {

		XmlRpc.setEncoding("UTF8");
		XmlRpcClient client = XMLRPCInvocationHandler.getEndPoint(); // Get a reference to the client

		Vector paras = null; // This will hold the list of parameters
		if (args != null)
		{
			paras = new Vector();
			for (int i = 0; i < args.length; i++) 
			{
				paras.add(ValueConverter.convertFromType(args[i]));
			}
		}
		else
		{
			paras = new Vector(); // The vector holding the parameters must not be null
		}
		Class retType = method.getReturnType();
		
	    // Object ret = client.execute(type.getName() + '.' + method.getName(), paras);
		Object xmlrpc_result = null;
		
		Object ret = null;
		try
		{
			xmlrpc_result = client.execute(method.getName(), paras);
			ret = ValueConverter.convertToType(xmlrpc_result, retType);
		}
		catch (XmlRpcException ex)
		{
			throw new Exception(ex.getMessage());
		}
		catch (ClassCastException ex)
		{
			// check if XML-RPC returned a null value
			// XML-RPC has a limitation on passing NULL values, 
			// instead, it returns an empty string
			// the following statement rethrows ClassCastException for anything else
			String nullResult = (String) ValueConverter.convertToType(xmlrpc_result, String.class);
			if (nullResult.length() > 0)
			{
				throw ex;
			}
		}
		
		return ret;
	}

	protected static XmlRpcClient getEndPoint() throws MalformedURLException 
	{
		String server = System.getProperty("xmlservice.peoplepicker.server"); // format: <serer-name>[:PORT]
		String vdir = System.getProperty("xmlservice.peoplepicker.vdir"); // format: /virtual-dir-name
		String endPoint = System.getProperty("xmlservice.peoplepicker.endpoint"); // PeoplePicker.rem
		
        if (log.isDebugEnabled()) {
            log.debug("Server=" + server + ", vdir=" + vdir + ", endPoint="+endPoint);
        }

		return new XmlRpcClient("http://" + server + vdir + "/" + endPoint);
	}

}
