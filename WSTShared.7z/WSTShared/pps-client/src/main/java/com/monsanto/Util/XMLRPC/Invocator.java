/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.Util.XMLRPC;

import java.lang.reflect.Proxy;

/**
 * @author SRKARNA
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Invocator {

	public static Object getProxy(Class ifType) {
		   if (!ifType.isInterface()) {
		      throw new AssertionError("Type must be an interface");
		   }
		   return Proxy.newProxyInstance(
		   				Invocator.class.getClassLoader(),
		      			new Class[]{ifType}, 
						new XMLRPCInvocationHandler(ifType));
		}

}
