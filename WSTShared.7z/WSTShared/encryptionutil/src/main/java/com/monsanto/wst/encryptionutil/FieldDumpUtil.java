package com.monsanto.wst.encryptionutil;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.databasepasswordencryption.Helper.Base64;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.wst.encryption.EncryptedValue;
import com.monsanto.wst.encryption.EncryptionManager;
import com.monsanto.wst.encryption.rsa.RSAEncryption;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class FieldDumpUtil implements EncryptionUtility {
    public String getName() {
         return "extract";
     }

    public String getSyntax() {
        return "privateKeySubDir publicKeyTableName dataTableName primaryKeyField dataFieldKeyId dataFieldEncryptedValue";
    }

    public String getExample() {
        return "encryptiontestdir ENCRYPTION_KEYS CREDIT_CARD ID KEY_ID ENCRYPTED_NUM";
    }

    public void execute(PersistentStoreConnection conn, String[] args) throws IllegalArgumentException {
        try {
            if (args.length != 6) {
                throw new IllegalArgumentException();
            }

            String subDir = args[0];
            String encryptionTableName = args[1];
            String dataTableName = args[2];
            String primaryKeyField = args[3];
            String dataFieldKeyId = args[4];
            String dataFieldEncrypted = args[5];

            EncryptionManager encryption = RSAEncryption.getEncryptionManager(conn, encryptionTableName, subDir);
            dumpValues(conn, encryption, dataTableName, primaryKeyField, dataFieldKeyId, dataFieldEncrypted);
        } catch (WrappingException e) {
            throw new RuntimeException(e);
        }
    }

    private void dumpValues(PersistentStoreConnection conn, EncryptionManager encryption, String dataTableName, String primarKeyField, String dataFieldKeyId, String dataFieldEncrypted) throws WrappingException {
        String querySql = "SELECT " + primarKeyField + "," + dataFieldKeyId + "," + dataFieldEncrypted + " FROM " + dataTableName + " WHERE " + primarKeyField + " IS NOT NULL";
        PersistentStoreResultSetFwdIterator results = conn.executeQuery(querySql).getForwardIterator();
        while (results.next()) {
            String primaryKeyValue = results.getString(1);
            long keyId = results.getLong(2);
            String encodedEncryptedData = results.getString(3);
            byte[] encryptedData = Base64.decode(encodedEncryptedData);
            EncryptedValue encryptedValue = new EncryptedValue(keyId, encryptedData);

            String decryptedValue = encryption.decrypt(encryptedValue);
            System.out.println(primaryKeyValue + ":" + decryptedValue);
        }
    }
}
