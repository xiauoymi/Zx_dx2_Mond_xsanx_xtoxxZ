package com.monsanto.wst.encryptionutil;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.Log4JLogging.Log4JConsoleLogDevice;
import com.monsanto.Log4JLogging.Log4JErrorLog;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreDBConnection;
import com.monsanto.wst.encryption.*;
import com.monsanto.wst.encryption.rsa.RSAKeyGenerator;
import com.monsanto.wst.encryption.rsa.RSAKeyIdGenerator;
import com.monsanto.wst.encryption.rsa.RSAKeyTranslatorImpl;
import com.monsanto.Util.Exceptions.WrappingException;

import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class RSAKeyGenerationUtil implements EncryptionUtility {
    // sql to purge old ones (optional) : delete from encryption_keys where active='N' and id not in (select key_id from credit_card where key_id is not null)
    // (would have to union credit_card, etc - all tables that might have keys specified

    public String getName() {
        return "keygen";
    }

    public String getSyntax() {
        return "privateKeySubDir publicKeyTableName";
    }

    public String getExample() {
        return "encryptiontestdir ENCRYPTION_KEYS";
    }

    public void execute(PersistentStoreConnection conn, String[] args) throws IllegalArgumentException {
        try {
            if (args.length != 2) {
                throw new IllegalArgumentException();
            }
            
            String subDir = args[0];
            String tableName = args[1];

            generateNewKey(conn, tableName, subDir);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private void generateNewKey(PersistentStoreConnection conn, String tableName, String subdir) throws NoSuchAlgorithmException {
        KeyGenerator keyGen = new RSAKeyGenerator();
        KeyTranslator keyTranslator = new RSAKeyTranslatorImpl();
        KeySource publicKeySource = new DatabaseKeySource(conn, tableName, keyTranslator);
        KeySource privateKeySource = new FileKeySource(keyTranslator, subdir);
        KeyPair keyPair = keyGen.generateKeys();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();
        long id = new RSAKeyIdGenerator().getId(publicKey);
        publicKeySource.store(id, publicKey);
        privateKeySource.store(id, privateKey);
    }
}
