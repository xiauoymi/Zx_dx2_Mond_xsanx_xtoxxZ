package com.monsanto.wst.encryptionutil;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.Log4JLogging.Log4JErrorLog;
import com.monsanto.Log4JLogging.Log4JConsoleLogDevice;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreDBConnection;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UtilMain {
    private static final EncryptionUtility[] utilities = {
            new DatabaseTranslationUtil(),
            new FieldDumpUtil(),
            new RSAKeyGenerationUtil()
    };

    public static void main(String[] args) throws Exception {
        EncryptionUtility util = getUtility(args);
        if (validateUtility(util, args)) {
            try {
                PersistentStoreConnection conn = getConnection(args);
                util.execute(conn, stripCommonArgs(args));
            } catch (IllegalArgumentException e) {
                printSyntaxErrorMessage(util);
            }
        }
    }

    private static PersistentStoreConnection getConnection(String[] args) throws LogRegistrationException, ClassNotFoundException, WrappingException {
        Logger.register(new Log4JErrorLog("encryptionutil", new Log4JConsoleLogDevice()));
        Class.forName("oracle.jdbc.driver.OracleDriver");

        String userName = args[1];
        String password = args[2];
//        String dataSource = "jdbc:oracle:oci:@" + args[3];
        String dataSource = "jdbc:oracle:thin:@" + args[3];
        System.out.println("dataSource = " + dataSource);

        return new PersistentStoreDBConnection(userName, password, dataSource);
    }

    private static String[] stripCommonArgs(String[] args) {
        String[] newArgs = new String[args.length - 4];
        System.arraycopy(args, 4, newArgs, 0, args.length - 4);
        return newArgs;
    }

    private static boolean validateUtility(EncryptionUtility util, String[] args) {
        if (util == null || args.length < 4) {
            System.err.println("Syntax: java -jar jarfile.jar UTILITY_NAME dbUser dbPass dbInstance options...");
            System.err.print("Where UTILITY_NAME is one of: " );
            boolean firstUtility = true;
            for (EncryptionUtility utility : utilities) {
                if (firstUtility) {
                    firstUtility = false;
                } else {
                    System.err.print(", ");
                }
                System.err.print(utility.getName());
            }
            System.err.println();
            return false;
        } else {
            return true;
        }

    }

    private static void printSyntaxErrorMessage(EncryptionUtility util) {
        System.err.println("Syntax: java -jar jarfile.jar " +  util.getName() + " dbUser dbPass dbInstance " + util.getSyntax());
        System.err.println("Example: java -jar jarfile.jar " +  util.getName() + " TTS XXXX COMGEND " + util.getExample());
    }

    private static EncryptionUtility getUtility(String[] args) {
        if (args.length == 0) {
            return null;
        }

        for (EncryptionUtility utility : utilities) {
            if (utility.getName().equalsIgnoreCase(args[0])) {
                return utility;
            }
        }

        return null;
    }
}
