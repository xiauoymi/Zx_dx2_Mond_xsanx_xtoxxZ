package com.monsanto.wst.encryptionutil;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.databasepasswordencryption.Helper.Base64;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.encryption.EncryptedValue;
import com.monsanto.wst.encryption.EncryptionManager;
import com.monsanto.wst.encryption.rsa.RSAEncryption;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DatabaseTranslationUtil implements EncryptionUtility {
    public String getName() {
         return "encrypt";
     }

    public String getSyntax() {
        return "privateKeySubDir publicKeyTableName dataTableName dataFieldOld dataFieldKeyId dataFieldEncryptedValue";
    }

    public String getExample() {
        return "encryptiontestdir ENCRYPTION_KEYS CREDIT_CARD NUM KEY_ID ENCRYPTED_NUM";
    }

    public void execute(PersistentStoreConnection conn, String[] args) throws IllegalArgumentException {
        try {
            if (args.length != 6) {
                throw new IllegalArgumentException();
            }

            String subDir = args[0];
            String encryptionTableName = args[1];
            String dataTableName = args[2];
            String dataFieldOld = args[3];
            String dataFieldKeyId = args[4];
            String dataFieldEncrypted = args[5];

            EncryptionManager encryption = RSAEncryption.getEncryptionManager(conn, encryptionTableName, subDir);
            translateTable(conn, encryption, dataTableName, dataFieldOld, dataFieldKeyId, dataFieldEncrypted);
        } catch (WrappingException e) {
            throw new RuntimeException(e);
        }
    }

    private void translateTable(PersistentStoreConnection conn, EncryptionManager encryption,
                                       String dataTableName,
                                       String dataFieldOld, String dataFieldKeyId, String dataFieldEncrypted) throws WrappingException {
        conn.beginTransaction();

        PersistentStoreStatement updateStmt = prepareUpdateStatement(conn, dataTableName, dataFieldOld, dataFieldKeyId, dataFieldEncrypted);

        String querySql = "SELECT ROWID," + dataFieldOld + " FROM " + dataTableName + " WHERE " + dataFieldOld + " IS NOT NULL FOR UPDATE";
        PersistentStoreResultSetFwdIterator results = conn.executeQuery(querySql).getForwardIterator();
        while (results.next()) {
            String rowId = results.getString(1);
            String oldValue = results.getString(2);
            EncryptedValue encryptedValue = encryption.encrypt(oldValue);

            updateStmt.setParam(1, encryptedValue.getKeyId());
            updateStmt.setParam(2, Base64.encode(encryptedValue.getCipherText()));
            updateStmt.setParam(3, rowId);
            updateStmt.executeUpdate();
        }

        conn.endTransaction();
    }

    private PersistentStoreStatement prepareUpdateStatement(PersistentStoreConnection conn, String dataTableName, String dataFieldOld, String dataFieldKeyId, String dataFieldEncrypted) throws WrappingException {
        String updateSql = "UPDATE " + dataTableName + " SET " +
                dataFieldOld + "=NULL," +
                dataFieldKeyId + "=?," +
                dataFieldEncrypted + "=?" +
                " WHERE ROWID = ?";
        return conn.prepareStatement(updateSql);
    }
}
