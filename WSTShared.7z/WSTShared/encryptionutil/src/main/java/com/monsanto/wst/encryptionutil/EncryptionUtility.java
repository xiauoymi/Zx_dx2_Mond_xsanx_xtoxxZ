package com.monsanto.wst.encryptionutil;

import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface EncryptionUtility {
    String getName();
    String getSyntax();
    String getExample();
    void execute(PersistentStoreConnection conn, String[] args) throws IllegalArgumentException;
}
