package com.monsanto.wst.emailtemplate.domain;

import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 1:23:03 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EmailHeaderInfo {
  private List toEmailAddresses = new ArrayList();
  private String fromEmailAddress;
  private String subject;
  private String contentType = "text/plain";
  private List ccEmailAddresses = new ArrayList();
  private List bccEmailAddresses = new ArrayList();
  private List attachments = new ArrayList();

  public EmailHeaderInfo(String toEmailAddress, String fromEmailAddress, String subject) {
    this.toEmailAddresses.add(toEmailAddress);
    this.fromEmailAddress = fromEmailAddress;
    this.subject = subject;
  }

  public List getToEmailAddresses() {
    return toEmailAddresses;
  }

  public void addToEmailAddress(String toEmailAddress) {
    toEmailAddresses.add(toEmailAddress);
  }

  public List getAttachments(){
    return attachments;
  }

  public void addAttachment(File attachment) throws FileNotFoundException {
    if(attachment.exists()){
      attachments.add(attachment);
    }
    else throw new FileNotFoundException("File "+attachment.getName()+" Could Not Be Found");
  }

  public String getFromEmailAddress() {
    return fromEmailAddress;
  }

  public String getSubject() {
    return subject;
  }

  public String getContentType() {
    return contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public List getCcEmailAddresses() {
    return ccEmailAddresses;
  }

  public void addCcEmailAddress(String ccEmailAddress) {
    ccEmailAddresses.add(ccEmailAddress);
  }

  public List getBccEmailAddresses() {
    return bccEmailAddresses;
  }

  public void addBccEmailAddress(String bccEmailAddress) {
    bccEmailAddresses.add(bccEmailAddress);
  }
}
