package com.monsanto.wst.emailtemplate.domain;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 2:39:26 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FactoryInitializationException extends RuntimeException {
  public FactoryInitializationException(String message, Throwable cause) {
    super(message, cause);
  }
}
