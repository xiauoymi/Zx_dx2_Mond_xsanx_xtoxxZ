package com.monsanto.wst.emailtemplate.domain;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 4:24:41 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailBuilder implements EmailBuilder {
  private EmailHeaderInfo headerInfo;
  private String body;
  private XMLUtilities xmlUtils;

  public MonsantoEmailBuilder(EmailHeaderInfo headerInfo, String body, XMLUtilities xmlUtils) {
    this.headerInfo = headerInfo;
    this.body = body;
    this.xmlUtils = xmlUtils;
  }

  public Document toXML() {
    try {
      Document emailDoc = xmlUtils.createDocument();
      Element rootElement = DOMUtil.addChildElement(emailDoc, "REQUEST");
      createXMLHeader(rootElement);
      createXMLBody(rootElement);
      createXMLAttachment(rootElement);
      return emailDoc;
    } catch (XMLParserException e) {
      throw new EmailBuilderException("Unable to convert email into XML document.", e);
    }
  }

  private void createXMLAttachment(Node node) {
    List attachments = headerInfo.getAttachments();
    if(attachments.size()>0){
      Element attachmentElement = DOMUtil.addChildElement(node, "ATTACHMENT");
      for(int i = 0; i < attachments.size(); i++){
        DOMUtil.addChildElement(attachmentElement, "FILENAME", ((File)attachments.get(i)).getAbsolutePath());
      }
    }
  }

  private void createXMLHeader(Node node) {
    Element header = DOMUtil.addChildElement(node, "HEADER");
    for (int i = 0; i < headerInfo.getToEmailAddresses().size(); i++) {
      String address = (String) headerInfo.getToEmailAddresses().get(i);
      DOMUtil.addChildElement(header, "TO", address);
    }
    for (int i = 0; i < headerInfo.getCcEmailAddresses().size(); i++) {
      String address = (String) headerInfo.getCcEmailAddresses().get(i);
      DOMUtil.addChildElement(header, "CC", address);
    }
    for (int i = 0; i < headerInfo.getBccEmailAddresses().size(); i++) {
      String address = (String) headerInfo.getBccEmailAddresses().get(i);
      DOMUtil.addChildElement(header, "BCC", address);
    }
    DOMUtil.addChildElement(header, "FROM", headerInfo.getFromEmailAddress());
    DOMUtil.addChildElement(header, "SUBJECT", headerInfo.getSubject());
  }

  private void createXMLBody(Node node) {
    Element bodyElement = DOMUtil.addChildElement(node, "BODY");
    DOMUtil.addChildElement(bodyElement, "CONTENT_TYPE", headerInfo.getContentType());
    DOMUtil.addChildElement(bodyElement, "LINE", body);
  }
}
