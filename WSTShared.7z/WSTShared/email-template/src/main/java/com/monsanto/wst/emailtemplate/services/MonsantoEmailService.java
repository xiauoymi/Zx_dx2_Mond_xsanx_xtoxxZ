package com.monsanto.wst.emailtemplate.services;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.domain.AbstractEmailBuilderFactory;
import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.emailtemplate.transport.AbstractEmailTransporterFactory;
import com.monsanto.wst.emailtemplate.transport.EmailTransporter;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 3:50:19 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailService implements EmailService {
  private AbstractEmailTransporterFactory transporterFactory;
  private AbstractEmailBuilderFactory emailBuilderFactory;
  private MessageTemplateFactory messageTemplateFactory;

  public MonsantoEmailService(MessageTemplateFactory messageTemplateFactory) {
    this.messageTemplateFactory = messageTemplateFactory;
    this.transporterFactory = AbstractEmailTransporterFactory.newInstance();
    this.emailBuilderFactory = AbstractEmailBuilderFactory.newInstance();
  }

  public void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping) {
    MessageTemplate template = this.messageTemplateFactory.getTemplateById(templateId);
    EmailBuilder emailBuilder = emailBuilderFactory.getEmailBuilder(headerInfo, template.getFormattedMessage(mapping));
    EmailTransporter transporter = transporterFactory.createEmailTransporter(emailBuilder);
    transporter.sendEmail();
  }
}
