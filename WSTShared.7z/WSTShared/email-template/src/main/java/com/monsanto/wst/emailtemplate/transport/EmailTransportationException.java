package com.monsanto.wst.emailtemplate.transport;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 5:34:30 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EmailTransportationException extends RuntimeException {
  public EmailTransportationException(String message, Throwable cause) {
    super(message, cause);
  }
}
