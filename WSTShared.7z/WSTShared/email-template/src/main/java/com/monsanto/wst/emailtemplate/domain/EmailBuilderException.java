package com.monsanto.wst.emailtemplate.domain;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 5:00:36 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EmailBuilderException extends RuntimeException {
  public EmailBuilderException(String message, Throwable cause) {
    super(message, cause);
  }
}
