package com.monsanto.wst.emailtemplate.services;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 5:11:54 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface EmailService {
  void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping);
}
