package com.monsanto.wst.emailtemplate.facade;

import com.monsanto.wst.commonutils.template.MessageTemplate;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 4:08:27 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface MessageTemplateFactory {
  MessageTemplate getTemplateById(String templateId);
}
