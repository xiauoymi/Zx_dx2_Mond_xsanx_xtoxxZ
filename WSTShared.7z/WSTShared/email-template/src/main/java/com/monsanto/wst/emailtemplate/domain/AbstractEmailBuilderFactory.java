package com.monsanto.wst.emailtemplate.domain;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 2:08:41 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractEmailBuilderFactory {
  private static Class CURRENT_IMPL;

  public abstract EmailBuilder getEmailBuilder(EmailHeaderInfo emailHeaderInfo, String body);

  public static AbstractEmailBuilderFactory newInstance() {
    if (CURRENT_IMPL != null) {
      try {
        return (AbstractEmailBuilderFactory) CURRENT_IMPL.newInstance();
      } catch (InstantiationException e) {
        throw new FactoryInitializationException("Unable to initialize AbstractEmailBuilderFactory.  This may be " +
          "because the factory implementation is abstract or an interface.", e);
      } catch (IllegalAccessException e) {
        throw new FactoryInitializationException("Unable to initialize AbstractEmailBuilderFactory.  This may be " +
          "because the factory implementation is private, package or protected.", e);
      }
    }
    return new MonsantoEmailBuilderFactory();
  }

  public static void setImplementation(String impl) {
    try {
      if (impl != null) {
      if (!AbstractEmailBuilderFactory.class.isAssignableFrom(Class.forName(impl))) {
        throw new IllegalArgumentException("The class at path: '" + impl + "' is not an implementation of " +
          "AbstractEmailBuilderFactory.");
      }
      CURRENT_IMPL = Class.forName(impl);
      } else {
        CURRENT_IMPL = null;
      }
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Unable to find AbstractEmailBuilderFactory implementation at path: '"
        + impl + "'.");
    }
  }
}
