package com.monsanto.wst.emailtemplate.transport;

import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailDocument;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 5:08:06 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailTransporter implements EmailTransporter {
  private MailDocument mailDocument;

  public MonsantoEmailTransporter(MailDocument mailDocument) {
    this.mailDocument = mailDocument;
  }

  public void sendEmail() {
    try {
      mailDocument.send();
    } catch (InvalidFormatException e) {
      throw new EmailTransportationException("Unable to send email.", e);
    }
  }
}
