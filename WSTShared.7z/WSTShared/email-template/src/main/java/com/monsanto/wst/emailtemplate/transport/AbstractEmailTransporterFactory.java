package com.monsanto.wst.emailtemplate.transport;

import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.FactoryInitializationException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:50:30 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractEmailTransporterFactory {
  private static Class CURRENT_IMPL;

  public abstract EmailTransporter createEmailTransporter(EmailBuilder emailBuilder);

  public static AbstractEmailTransporterFactory newInstance() {
    if (CURRENT_IMPL != null) {
      try {
        return (AbstractEmailTransporterFactory) CURRENT_IMPL.newInstance();
      } catch (InstantiationException e) {
        throw new FactoryInitializationException("Unable to initialize AbstractEmailTransporterFactory.  This may be " +
          "because the factory implementation is abstract or an interface.", e);
      } catch (IllegalAccessException e) {
        throw new FactoryInitializationException("Unable to initialize AbstractEmailTransporterFactory.  This may be " +
          "because the factory implementation is private, package or protected.", e);
      }
    }
    return new MonsantoEmailTransporterFactory();
  }

  public static void setImplementation(String impl) {
    try {
      if (impl != null) {
        if (!AbstractEmailTransporterFactory.class.isAssignableFrom(Class.forName(impl))) {
          throw new IllegalArgumentException("The class at path: '" + impl + "' is not an implementation of " +
            "AbstractEmailTransporterFactory.");
        }
        CURRENT_IMPL = Class.forName(impl);
      } else {
        CURRENT_IMPL = null;
      }
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Unable to find AbstractEmailTransporterFactory implementation at path: '"
        + impl + "'.");
    }
  }
}
