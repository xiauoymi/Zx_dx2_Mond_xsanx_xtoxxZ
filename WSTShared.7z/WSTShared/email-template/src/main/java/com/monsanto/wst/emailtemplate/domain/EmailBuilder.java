package com.monsanto.wst.emailtemplate.domain;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 5:14:59 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface EmailBuilder {
  Document toXML();
}
