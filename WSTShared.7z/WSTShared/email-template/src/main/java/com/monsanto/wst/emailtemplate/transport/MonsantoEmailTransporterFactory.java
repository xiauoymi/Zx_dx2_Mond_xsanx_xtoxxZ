package com.monsanto.wst.emailtemplate.transport;

import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailBuilderException;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.JavaMail.JavaMailMailDocument;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:08:04 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailTransporterFactory extends AbstractEmailTransporterFactory {
  public EmailTransporter createEmailTransporter(EmailBuilder emailBuilder) {
    try {
      MailDocument mailDocument = new JavaMailMailDocument(emailBuilder.toXML());
      return new MonsantoEmailTransporter(mailDocument);
    } catch (MessageParseException e) {
      throw new EmailBuilderException("Unable to build Mime Message.", e);
    }
  }
}
