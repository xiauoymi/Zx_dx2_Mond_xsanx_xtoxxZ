package com.monsanto.wst.emailtemplate.domain;

import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.resources.ResourceUtils;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 11:03:53 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailBuilderFactory extends AbstractEmailBuilderFactory {
  public EmailBuilder getEmailBuilder(EmailHeaderInfo emailHeaderInfo, String body) {
    return new MonsantoEmailBuilder(emailHeaderInfo, body, new XMLUtilities(new ResourceUtils()));
  }
}
