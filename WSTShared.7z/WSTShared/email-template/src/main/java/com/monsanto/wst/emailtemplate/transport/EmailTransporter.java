package com.monsanto.wst.emailtemplate.transport;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:10:22 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface EmailTransporter {
  void sendEmail();
}
