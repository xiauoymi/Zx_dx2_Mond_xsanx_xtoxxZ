package com.monsanto.wst.emailtemplate.transport.test;

import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.FactoryInitializationException;
import com.monsanto.wst.emailtemplate.domain.MonsantoEmailBuilderFactory;
import com.monsanto.wst.emailtemplate.transport.AbstractEmailTransporterFactory;
import com.monsanto.wst.emailtemplate.transport.EmailTransporter;
import com.monsanto.wst.emailtemplate.transport.MonsantoEmailTransporterFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:51:03 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractEmailTransporterFactory_AT extends TestCase {
  protected void tearDown() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(null);
  }

  public void testNewInstance() throws Exception {
    AbstractEmailTransporterFactory factory = AbstractEmailTransporterFactory.newInstance();
    assertNotNull(factory);
  }
  public void testNewInstanceReturnsCustomImplWhenCustomImplIsSet() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(MockEmailTransporterFactory.class.getName());
    AbstractEmailTransporterFactory factory = AbstractEmailTransporterFactory.newInstance();
    assertNotNull(factory);
    assertEquals(MockEmailTransporterFactory.class, factory.getClass());
  }

  public void testSetImplementationDoesNotExist() throws Exception {
    try {
      AbstractEmailTransporterFactory.setImplementation("does.not.exist");
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("Unable to find AbstractEmailTransporterFactory implementation at path: 'does.not.exist'.", e.getMessage());
    }
  }

  public void testSetImplementationNotAnAbstractEmailBuilderFactory() throws Exception {
    try {
      AbstractEmailTransporterFactory.setImplementation(MonsantoEmailBuilderFactory.class.getName());
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("The class at path: '" + MonsantoEmailBuilderFactory.class.getName() + "' is not an " +
        "implementation of AbstractEmailTransporterFactory.", e.getMessage());
    }
  }

  public void testNewInstanceAbstractCustomImpl() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(AbstractMockEmailTransporterFactory.class.getName());
    try {
      AbstractEmailTransporterFactory.newInstance();
      fail("This should have thrown an exception.");
    } catch (FactoryInitializationException e) {
      assertEquals("Unable to initialize AbstractEmailTransporterFactory.  This may be because the factory " +
        "implementation is abstract or an interface.", e.getMessage());
    }
  }

  public void testNewInstancePrivateCustomImpl() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(PrivateMockEmailTransporterFactory.class.getName());
    try {
      AbstractEmailTransporterFactory.newInstance();
      fail("This should have thrown an exception.");
    } catch (FactoryInitializationException e) {
      assertEquals("Unable to initialize AbstractEmailTransporterFactory.  This may be because the factory " +
        "implementation is private, package or protected.", e.getMessage());
    }
  }

  public void testSetImplementationResetWithNull() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(MockEmailTransporterFactory.class.getName());
    AbstractEmailTransporterFactory.setImplementation(null);
    AbstractEmailTransporterFactory factory = AbstractEmailTransporterFactory.newInstance();
    assertNotNull(factory);
    assertEquals(MonsantoEmailTransporterFactory.class, factory.getClass());
  }

  public static class MockEmailTransporterFactory extends AbstractEmailTransporterFactory {
    public EmailTransporter createEmailTransporter(EmailBuilder emailBuilder) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }

  public static abstract class AbstractMockEmailTransporterFactory extends AbstractEmailTransporterFactory {
  }

  private static class PrivateMockEmailTransporterFactory extends AbstractEmailTransporterFactory {
    public EmailTransporter createEmailTransporter(EmailBuilder emailBuilder) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }
}
