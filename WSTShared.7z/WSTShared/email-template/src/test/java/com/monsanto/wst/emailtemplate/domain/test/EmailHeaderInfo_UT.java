package com.monsanto.wst.emailtemplate.domain.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestResults;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestUtils;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 1:20:32 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EmailHeaderInfo_UT extends TestCase {
  private JavaBeanTestUtils testUtils;

  protected void setUp() throws Exception {
    this.testUtils = new JavaBeanTestUtils(new ObjectInspector());
  }

  public void testCreate() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo("receiver@monsanto.com", "sender@monsanto.com", "test");
    assertNotNull(header);
    assertTrue(header.getToEmailAddresses().contains("receiver@monsanto.com"));
    assertEquals("sender@monsanto.com", header.getFromEmailAddress());
    assertEquals("test", header.getSubject());
  }

  public void testSetterProperties() throws Exception {
    JavaBeanTestResults results = testUtils.testProperties(new EmailHeaderInfo(null, null, null));
    assertTrue(results.getCombinedResult());
    assertEquals(1, results.getNumResults());
  }

  public void testGetDefaultContentType() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    assertEquals("text/plain", header.getContentType());
  }

  public void testAddToEmailAddress() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    header.addToEmailAddress("test@monsanto.com");
    assertTrue(header.getToEmailAddresses().contains("test@monsanto.com"));
  }

  public void testAddCcEmailAddress() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    header.addCcEmailAddress("test@monsanto.com");
    assertTrue(header.getCcEmailAddresses().contains("test@monsanto.com"));
  }

  public void testAddBccEmailAddress() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    header.addBccEmailAddress("test@monsanto.com");
    assertTrue(header.getBccEmailAddresses().contains("test@monsanto.com"));
  }

  public void testAddAttachmentsThrowsExceptionWhenNoSuchFile() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    try{
      header.addAttachment(new File("noSuchFile.txt"));
      fail("Should throw FileNotFoundException");
    } catch (FileNotFoundException e){
    }
  }

  public void testAddAttachmentWithValidFile() throws Exception {
    EmailHeaderInfo header = new EmailHeaderInfo(null, null, null);
    header.addAttachment(new File("com/monsanto/wst/emailtemplate/domain/test/testAttachment.txt"));
    assertTrue(header.getAttachments().contains(new File("com/monsanto/wst/emailtemplate/domain/test/testAttachment.txt")));
  }
}
