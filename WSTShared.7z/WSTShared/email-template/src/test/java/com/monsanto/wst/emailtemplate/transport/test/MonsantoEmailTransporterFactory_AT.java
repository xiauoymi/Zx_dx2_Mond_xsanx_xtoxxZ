package com.monsanto.wst.emailtemplate.transport.test;

import junit.framework.TestCase;
import com.monsanto.wst.emailtemplate.transport.MonsantoEmailTransporterFactory;
import com.monsanto.wst.emailtemplate.transport.EmailTransporter;
import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailBuilderException;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:03:33 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailTransporterFactory_AT extends TestCase {
  public void testCreate() throws Exception {
    MonsantoEmailTransporterFactory factory = new MonsantoEmailTransporterFactory();
    assertNotNull(factory);
  }

  public void testCreateEmailTransporter() throws Exception {
    MonsantoEmailTransporterFactory factory = new MonsantoEmailTransporterFactory();
    EmailTransporter transporter = factory.createEmailTransporter(new MockEmailBuilder());
    assertNotNull(transporter);
  }

  public void testCreateEmailTransporterThrowsException() throws Exception {
    MonsantoEmailTransporterFactory factory = new MonsantoEmailTransporterFactory();
    try {
      factory.createEmailTransporter(new MockInvalidEmailBuilder());
      fail("This should have thrown an exception.");
    } catch (EmailBuilderException e) {
      assertEquals("Unable to build Mime Message.", e.getMessage());
    }
  }

  private class MockEmailBuilder implements EmailBuilder {
    public Document toXML() {
      try {
        return new XMLUtilities(new ResourceUtils()).createDocument("com/monsanto/wst/emailtemplate/transport/test/testEmail.xml");
      } catch (XMLParserException e) {
        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      }
      return null;
    }
  }

  private class MockInvalidEmailBuilder implements EmailBuilder {
    public Document toXML() {
      return null;
    }
  }
}
