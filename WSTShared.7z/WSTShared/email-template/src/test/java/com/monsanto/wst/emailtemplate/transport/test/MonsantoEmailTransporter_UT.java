package com.monsanto.wst.emailtemplate.transport.test;

import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailAttachmentIterator;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.wst.emailtemplate.transport.EmailTransportationException;
import com.monsanto.wst.emailtemplate.transport.MonsantoEmailTransporter;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 5:06:59 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailTransporter_UT extends TestCase {
  public void testCreate() throws Exception {
    MonsantoEmailTransporter transporter = new MonsantoEmailTransporter((MailDocument) null);
    assertNotNull(transporter);
  }

  public void testSendEmail() throws Exception {
    MockMailDocument mailDocument = new MockMailDocument();
    MonsantoEmailTransporter transporter = new MonsantoEmailTransporter(mailDocument);
    transporter.sendEmail();
    assertTrue(mailDocument.isEmailSent());
  }

  public void testSendEmailThrowsException() throws Exception {
    MockMailDocumentThrowsException mailDocument = new MockMailDocumentThrowsException();
    MonsantoEmailTransporter transporter = new MonsantoEmailTransporter(mailDocument);
    try {
      transporter.sendEmail();
      fail("This should have thrown an exception.");
    } catch (EmailTransportationException e) {
      assertEquals("Unable to send email.", e.getMessage());
    }
  }

  private class MockMailDocument implements MailDocument {
    private boolean wasSent = false;

    public MailAttachmentIterator getAttachmentIterator() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Date getRecievedDate() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document toXML() throws MessageParseException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void send() throws InvalidFormatException {
      this.wasSent = true;
    }

    public void setAttachmentSavePath(String path) {
      //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document getMessageBody() throws MessageParseException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isEmailSent() {
      return this.wasSent;
    }
  }

  private class MockMailDocumentThrowsException implements MailDocument {
    public MailAttachmentIterator getAttachmentIterator() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Date getRecievedDate() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document toXML() throws MessageParseException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void send() throws InvalidFormatException {
      throw new InvalidFormatException("");
    }

    public void setAttachmentSavePath(String path) {
      //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document getMessageBody() throws MessageParseException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }
}
