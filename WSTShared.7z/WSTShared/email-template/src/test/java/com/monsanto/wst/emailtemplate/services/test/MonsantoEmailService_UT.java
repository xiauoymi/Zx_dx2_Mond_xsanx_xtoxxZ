package com.monsanto.wst.emailtemplate.services.test;

import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.emailtemplate.services.MonsantoEmailService;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.emailtemplate.transport.AbstractEmailTransporterFactory;
import com.monsanto.wst.emailtemplate.transport.EmailTransporter;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 3:18:56 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailService_UT extends TestCase {
  private static final String TEST_FIRST = "First";
  private static final String TEST_LAST = "Last";
  private static final String TEST_EMAIL = "Email";
  private static final String TEST_SUBJECT = "Subject";

  protected void setUp() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(MockEmailTransporterFactory.class.getName());
  }

  protected void tearDown() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(null);
  }

  public void testCreate() throws Exception {
    MonsantoEmailService service = new MonsantoEmailService((MessageTemplateFactory) null);
    assertNotNull(service);
  }

  public void testSendMessage() throws Exception {
    MockEmailTransporterFactory.transporter = new MockEmailTransporter();
    MonsantoEmailService service = new MonsantoEmailService(new MockMessageTemplateFactory());
    EmailHeaderInfo headerInfo = new EmailHeaderInfo(TEST_FIRST, TEST_LAST, TEST_EMAIL);
    service.sendEmail("test", headerInfo, new MockObjectWithName());
    assertTrue(MockEmailTransporterFactory.transporter.isEmailSent());
  }

  public class MockObjectWithName {
    public String getName() {
      return "John Smith";
    }
  }

  private class MockMessageTemplate implements MessageTemplate {
    public String getFormattedMessage(Object object) {
      return object.toString();
    }
  }

  private class MockMessageTemplateFactory implements MessageTemplateFactory {
    public MessageTemplate getTemplateById(String templateId) {
      return new MockMessageTemplate();
    }
  }

  public static class MockEmailTransporterFactory extends AbstractEmailTransporterFactory {
    public static MockEmailTransporter transporter;

    public EmailTransporter createEmailTransporter(EmailBuilder emailBuilder) {
      return transporter;
    }
  }

  public static class MockEmailTransporter implements EmailTransporter {
    private boolean wasSent = false;

    public void sendEmail() {
      this.wasSent = true;
    }

    public boolean isEmailSent() {
      return this.wasSent;
    }
  }
}
