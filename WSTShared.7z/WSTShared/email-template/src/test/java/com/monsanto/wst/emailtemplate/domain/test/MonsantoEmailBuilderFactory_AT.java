package com.monsanto.wst.emailtemplate.domain.test;

import junit.framework.TestCase;
import com.monsanto.wst.emailtemplate.domain.MonsantoEmailBuilderFactory;
import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 9:59:16 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailBuilderFactory_AT extends TestCase {
  public void testCreate() throws Exception {
    MonsantoEmailBuilderFactory factory = new MonsantoEmailBuilderFactory();
    assertNotNull(factory);
  }

  public void testCreateEmailBuilder() throws Exception {
    MonsantoEmailBuilderFactory factory = new MonsantoEmailBuilderFactory();
    EmailBuilder emailBuilder = factory.getEmailBuilder(createEmailHeaderInfo(), "test");
    assertNotNull(emailBuilder);
  }

  private EmailHeaderInfo createEmailHeaderInfo() {
    return new EmailHeaderInfo("john.doe@monsanto.com", "test.tester@monsanto.com", "test");
  }
}
