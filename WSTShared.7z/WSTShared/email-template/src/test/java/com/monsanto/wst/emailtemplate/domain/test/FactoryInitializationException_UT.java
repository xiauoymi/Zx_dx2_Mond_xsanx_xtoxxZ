package com.monsanto.wst.emailtemplate.domain.test;

import junit.framework.TestCase;
import com.monsanto.wst.emailtemplate.domain.FactoryInitializationException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 2:37:59 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FactoryInitializationException_UT extends TestCase {
  public void testCreate() throws Exception {
    Exception cause = new Exception();
    FactoryInitializationException exception = new FactoryInitializationException("Test Message", cause);
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
