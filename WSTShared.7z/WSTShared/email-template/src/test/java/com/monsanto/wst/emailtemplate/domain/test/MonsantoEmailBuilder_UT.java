package com.monsanto.wst.emailtemplate.domain.test;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.domain.MonsantoEmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailBuilderException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 4:23:26 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MonsantoEmailBuilder_UT extends XMLTestCase {
  public void testCreate() throws Exception {
    MonsantoEmailBuilder builder = new MonsantoEmailBuilder((EmailHeaderInfo) null, (String) null, (XMLUtilities) null);
    assertNotNull(builder);
  }

  public void testToXML() throws Exception {
    EmailHeaderInfo headerInfo = new EmailHeaderInfo("john.doe@monsanto.com", "test.tester@monsanto.com", "test");
    headerInfo.addToEmailAddress("secondTo@monsanto.com");
    headerInfo.addCcEmailAddress("ccEmail@monsanto.com");
    headerInfo.addBccEmailAddress("bccEmail@monsanto.com");
    File testAttach = new File("com/monsanto/wst/emailtemplate/domain/test/testAttachment.txt");
    headerInfo.addAttachment(testAttach);
    MonsantoEmailBuilder builder = new MonsantoEmailBuilder(headerInfo, "this is a test", new XMLUtilities(new ResourceUtils()));
    Document doc = builder.toXML();
    assertNotNull(doc);
    assertXpathEvaluatesTo("john.doe@monsanto.com", "REQUEST/HEADER/TO[1]", doc);
    assertXpathEvaluatesTo("secondTo@monsanto.com", "REQUEST/HEADER/TO[2]", doc);
    assertXpathEvaluatesTo("ccEmail@monsanto.com", "REQUEST/HEADER/CC", doc);
    assertXpathEvaluatesTo("bccEmail@monsanto.com", "REQUEST/HEADER/BCC", doc);
    assertXpathEvaluatesTo(testAttach.getAbsolutePath(), "REQUEST/ATTACHMENT/FILENAME", doc);
    assertXpathEvaluatesTo("test.tester@monsanto.com", "REQUEST/HEADER/FROM", doc);
    assertXpathEvaluatesTo("test", "REQUEST/HEADER/SUBJECT", doc);
    assertXpathEvaluatesTo("text/plain", "REQUEST/BODY/CONTENT_TYPE", doc);
    assertXpathEvaluatesTo("this is a test", "REQUEST/BODY/LINE", doc);
  }

  public void testToXMLThrowsException() throws Exception {
    EmailHeaderInfo headerInfo = new EmailHeaderInfo("john.doe@monsanto.com", "test.tester@monsanto.com", "test");
    MonsantoEmailBuilder builder = new MonsantoEmailBuilder(headerInfo, "this is a test", new MockXMLUtilities(new ResourceUtils()));
    try {
      builder.toXML();
      fail("This should have thrown an exception.");
    } catch (EmailBuilderException e) {
      assertEquals("Unable to convert email into XML document.", e.getMessage());
    }
  }

  private class MockXMLUtilities extends XMLUtilities {
    public MockXMLUtilities(ResourceUtils resourceUtils) {
      super(resourceUtils);
    }

    public Document createDocument() throws XMLParserException {
      throw new XMLParserException();
    }
  }
}
