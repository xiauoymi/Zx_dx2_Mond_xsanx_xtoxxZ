package com.monsanto.wst.emailtemplate.domain.test;

import junit.framework.TestCase;
import com.monsanto.wst.emailtemplate.domain.EmailBuilderException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 4:59:11 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EmailBuilderException_UT extends TestCase {
  public void testCreateWithMessageAndCause() throws Exception {
    Exception cause = new Exception();
    EmailBuilderException exception = new EmailBuilderException("Test Message", cause);
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
