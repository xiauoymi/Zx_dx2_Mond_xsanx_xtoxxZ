package com.monsanto.wst.emailtemplate.domain.test;

import com.monsanto.wst.emailtemplate.domain.AbstractEmailBuilderFactory;
import com.monsanto.wst.emailtemplate.domain.EmailBuilder;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.domain.FactoryInitializationException;
import com.monsanto.wst.emailtemplate.transport.MonsantoEmailTransporterFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2006
 * Time: 2:06:08 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractEmailBuilderFactory_AT extends TestCase {
  protected void tearDown() throws Exception {
    AbstractEmailBuilderFactory.setImplementation(null);
  }

  public void testNewInstance() throws Exception {
    AbstractEmailBuilderFactory factory = AbstractEmailBuilderFactory.newInstance();
    assertNotNull(factory);
  }

  public void testNewInstanceReturnsCustomImplWhenCustomImplIsSet() throws Exception {
    AbstractEmailBuilderFactory.setImplementation(MockEmailBuilderFactory.class.getName());
    AbstractEmailBuilderFactory factory = AbstractEmailBuilderFactory.newInstance();
    assertNotNull(factory);
    assertEquals(MockEmailBuilderFactory.class, factory.getClass());
  }

  public void testSetImplementationDoesNotExist() throws Exception {
    try {
      AbstractEmailBuilderFactory.setImplementation("does.not.exist");
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("Unable to find AbstractEmailBuilderFactory implementation at path: 'does.not.exist'.", e.getMessage());
    }
  }

  public void testSetImplementationNotAnAbstractEmailBuilderFactory() throws Exception {
    try {
      AbstractEmailBuilderFactory.setImplementation(MonsantoEmailTransporterFactory.class.getName());
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("The class at path: '" + MonsantoEmailTransporterFactory.class.getName() + "' is not an " +
        "implementation of AbstractEmailBuilderFactory.", e.getMessage());
    }
  }

  public void testNewInstanceAbstractCustomImpl() throws Exception {
    AbstractEmailBuilderFactory.setImplementation(AbstractMockEmailBuilderFactory.class.getName());
    try {
      AbstractEmailBuilderFactory.newInstance();
      fail("This should have thrown an exception.");
    } catch (FactoryInitializationException e) {
      assertEquals("Unable to initialize AbstractEmailBuilderFactory.  This may be because the factory " +
        "implementation is abstract or an interface.", e.getMessage());
    }
  }

  public void testNewInstancePrivateCustomImpl() throws Exception {
    AbstractEmailBuilderFactory.setImplementation(PrivateMockEmailBuilderFactory.class.getName());
    try {
      AbstractEmailBuilderFactory.newInstance();
      fail("This should have thrown an exception.");
    } catch (FactoryInitializationException e) {
      assertEquals("Unable to initialize AbstractEmailBuilderFactory.  This may be because the factory " +
        "implementation is private, package or protected.", e.getMessage());
    }
  }

  public static class MockEmailBuilderFactory extends AbstractEmailBuilderFactory {
    public EmailBuilder getEmailBuilder(EmailHeaderInfo emailHeaderInfo, String body) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }

  public static abstract class AbstractMockEmailBuilderFactory extends AbstractEmailBuilderFactory {
  }

  private static class PrivateMockEmailBuilderFactory extends AbstractEmailBuilderFactory {
    public EmailBuilder getEmailBuilder(EmailHeaderInfo emailHeaderInfo, String body) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }
}
