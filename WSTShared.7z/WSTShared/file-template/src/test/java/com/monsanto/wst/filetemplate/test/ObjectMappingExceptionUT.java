package com.monsanto.wst.filetemplate.test;

import com.monsanto.wst.filetemplate.ObjectMappingException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 11:33:07 AM
 * <p/>
 * Unit test for the ObjectMappingException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectMappingExceptionUT extends TestCase {
  public void testCreate() throws Exception {
    ObjectMappingException exception = new ObjectMappingException("Test Message");
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
  }

  public void testCreateWithCause() throws Exception {
    Exception cause = new Exception();
    ObjectMappingException exception = new ObjectMappingException("Test Message", cause);
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
