package com.monsanto.wst.filetemplate.test;

import com.monsanto.wst.filetemplate.MappingConfigurationException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 7:53:36 AM
 * <p/>
 * Unit test for the MappedClassNotFoundException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MappingConfigurationExceptionUT extends TestCase {

    public void testCreate() throws Exception {
        MappingConfigurationException exception = new MappingConfigurationException("Test Message");
        assertNotNull(exception);
        assertEquals("Test Message", exception.getMessage());
    }

}
