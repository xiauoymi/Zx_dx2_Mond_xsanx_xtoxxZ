package com.monsanto.wst.filetemplate.config.test;

import com.monsanto.wst.filetemplate.config.AbstractConfigReaderStrategy;
import com.monsanto.wst.filetemplate.config.ConfigReader;
import com.monsanto.wst.filetemplate.config.xml.XMLConfigReader;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:07:43 PM
 * <p/>
 * Integration/Acceptance test for the AbstractMappingStrategy object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractConfigReaderStrategyAT extends TestCase {

    public void testNewInstance() throws Exception {
        ConfigReader configReader = AbstractConfigReaderStrategy.newInstance("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml");
        assertNotNull(configReader);
        assertEquals(XMLConfigReader.class, configReader.getClass());
    }

    public void testNewInstanceInvalidMapping() throws Exception {
        try {
            AbstractConfigReaderStrategy.newInstance("com/monsanto/wst/filetemplate/domain/xml/test/test-mapping");
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid mapping file specified 'com/monsanto/wst/filetemplate/domain/xml/test/test-mapping'.  " +
                    "Only XML is supported.", e.getMessage());
        }
    }

}
