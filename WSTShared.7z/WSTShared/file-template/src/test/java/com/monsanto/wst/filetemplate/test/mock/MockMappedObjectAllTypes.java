package com.monsanto.wst.filetemplate.test.mock;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 2:13:04 PM
 * <p/>
 * Mock mapped object that contains all supported types.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectAllTypes {
    public MockMappedObjectAllTypes(String text, Integer number, Double dbl, Date date, Long longNumber, int primitiveInt,
                            double primitiveDbl, Float f, float primitiveFloat, Short s, short primitiveShort,
                            long primitiveLong, Boolean b, boolean primitiveBoolean) {
    }
}
