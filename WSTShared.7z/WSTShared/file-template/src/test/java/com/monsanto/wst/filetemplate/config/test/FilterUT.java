package com.monsanto.wst.filetemplate.config.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.filetemplate.MappingConfigurationException;
import com.monsanto.wst.filetemplate.config.Filter;
import com.monsanto.wst.filetemplate.config.test.mock.MockAbstractType;
import com.monsanto.wst.filetemplate.config.test.mock.MockPrivateType;
import com.monsanto.wst.filetemplate.config.test.mock.MockTypeThrowsException;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObject;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObjectWithSetters;
import junit.framework.TestCase;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 29, 2006
 * Time: 2:22:34 PM
 * <p/>
 * Unit test for the Filter object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FilterUT extends TestCase {
    public void testCreate() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), (String) null, (String) null, "test value", String.class);
        assertNotNull(filter);
    }

    public void testCreateInvalidTypeConstructor() throws Exception {
        try {
            new Filter(new ObjectInspector(), (String) null, (String) null, "test value", int.class);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: Unable to find a constructor on the type 'int' that takes a string.",
                    e.getMessage());
        }
    }

    public void testCreateInstantiationException() throws Exception {
        try {
            new Filter(new ObjectInspector(), (String) null, (String) null, "test value", MockAbstractType.class);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: Unable to instantiate constructor for type " +
                    "'com.monsanto.wst.filetemplate.config.test.mock.MockAbstractType'.  This most likely happened " +
                    "because the type is abstract or an interface.", e.getMessage());
        }
    }

    public void testCreateIllegalAccessException() throws Exception {
        try {
            new Filter(new MockObjectInspector(), (String) null, (String) null, "test value", MockPrivateType.class);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: Unable to access constructor for type " +
                    "'com.monsanto.wst.filetemplate.config.test.mock.MockPrivateType'.  This most likely happened " +
                    "because the constructor for the type is private.", e.getMessage());
        }
    }

    public void testCreateTypeThrowsException() throws Exception {
        try {
            new Filter(new ObjectInspector(), (String) null, (String) null, "test value", MockTypeThrowsException.class);
            fail("This should have thrown an exception.");
        } catch (Exception e) {
            assertEquals("Invalid Filter: Unable to invoke constructor for type " +
                    "'com.monsanto.wst.filetemplate.config.test.mock.MockTypeThrowsException'.  The constructor " +
                    "threw an exception.", e.getMessage());
        }
    }

    public void testShouldFilterSuccess() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), "test", "==", "test value", String.class);
        MockMappedObject object = new MockMappedObject("test value");
        boolean result = filter.shouldFilter(object);
        assertTrue(result);
    }

    public void testShouldFilterFail() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), "test", "==", "test value", String.class);
        MockMappedObject object = new MockMappedObject("test value different");
        boolean result = filter.shouldFilter(object);
        assertFalse(result);
    }

    public void testShouldFilterFailInvalidOperation() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), "test", "invalid", "test value", String.class);
        MockMappedObject object = new MockMappedObject("test value different");
        try {
            filter.shouldFilter(object);
            fail("This should have thrown an exception.");
        } catch (Exception e) {
            assertEquals("Invalid Filter: Invalid operator 'invalid'.", e.getMessage());
        }
    }

    public void testShouldFilterPropertyNotFound() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), "doesNotExist", "==", "test value", String.class);
        MockMappedObject object = new MockMappedObject("test value");
        try {
            filter.shouldFilter(object);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: The filter property 'doesNotExist' does not appear to exist on the mapped object.",
                    e.getMessage());
        }
    }

    public void testShouldFilterIllegalAccess() throws Exception {
        Filter filter = new Filter(new MockObjectInspector(), "private", "==", "test value", String.class);
        MockMappedObject object = new MockMappedObject("test value");
        try {
            filter.shouldFilter(object);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: The filter property 'private' can not be accessed on the mapped object " +
                    "due to permissions.", e.getMessage());
        }
    }

    public void testShouldFilterAccessorThrowsException() throws Exception {
        Filter filter = new Filter(new ObjectInspector(), "throwsException", "==", "test value", String.class);
        MockMappedObjectWithSetters object = new MockMappedObjectWithSetters();
        try {
            filter.shouldFilter(object);
            fail("This should have thrown an exception.");
        } catch (MappingConfigurationException e) {
            assertEquals("Invalid Filter: The accessor for property 'throwsException' threw an exception.", e.getMessage());
        }
    }

    private class MockObjectInspector extends ObjectInspector {
        public Constructor getConstructor(Class clazz, Class[] types) throws NoSuchMethodException {
            return clazz.getDeclaredConstructor(types);
        }

        public Object getAcessorValue(Object obj, String accessorPath, boolean overridePermissions) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
            throw new IllegalAccessException("Test Exception");
        }
    }
}
