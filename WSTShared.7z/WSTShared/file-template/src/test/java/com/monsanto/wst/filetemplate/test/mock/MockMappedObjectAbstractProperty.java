package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 30, 2006
 * Time: 3:45:44 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectAbstractProperty {
    private Comparable testProperty;

    public Comparable getTestProperty() {
        return testProperty;
    }

    public void setTestProperty(Comparable testProperty) {
        this.testProperty = testProperty;
    }
}
