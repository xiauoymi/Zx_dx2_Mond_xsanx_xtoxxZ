package com.monsanto.wst.filetemplate.transform.excel.poi.test;

import com.monsanto.wst.commonutils.reflection.MethodProperties;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.filetemplate.config.Filter;
import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObject;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObjectAllTypesWithSetters;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObjectPrivateConstructor;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObjectWithSetters;
import com.monsanto.wst.filetemplate.transform.ObjectProperties;
import com.monsanto.wst.filetemplate.transform.excel.poi.POIExcelFileParser;
import junit.framework.TestCase;

import java.io.File;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 9:50:00 AM
 * <p/>
 * Unit test for the POIExcelFileParser object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class POIExcelFileParserUT extends TestCase {
    public void testCreate() throws Exception {
        POIExcelFileParser parser = new POIExcelFileParser();
        assertNotNull(parser);
    }

    public void testImportFileAllTypesNoHeader() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/AllTypesNoHeader.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(42, resultList.size());
    }

    public void testImportFileMultipleSheetsNoHeader() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/MultipleSheets.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(181, resultList.size());
    }

    public void testImportFileMultipleSheetsInvalidSheetMaxPlusOneReturnsAll() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/MultipleSheets.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setSheetIndex(new Integer(5));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(181, resultList.size());
    }

    public void testImportFileMultipleSheetsInvalidSheetMinMinusOneReturnsAll() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/MultipleSheets.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setSheetIndex(new Integer(0));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(181, resultList.size());
    }

    public void testImportFileMultipleSheetsSelectedSheet() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/MultipleSheets.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        POIExcelFileParser parser = new POIExcelFileParser();
        mapping.setSheetIndex(new Integer(1));
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(45, resultList.size());

        mapping.setSheetIndex(new Integer(4));
        resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(46, resultList.size());
    }

    public void testImportFileWithColumnIndexes() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWith1Header.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(1));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(35, resultList.size());
        assertEquals("Test With Header", ((MockMappedObjectWithSetters) resultList.get(0)).getText());
    }

    public void testImportFileWithHeaderName() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWith1Header.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(1));
        mapping.addPropertyConfigMapping("Test Header", new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(35, resultList.size());
        assertEquals("Test With Header", ((MockMappedObjectWithSetters) resultList.get(0)).getText());
    }

    public void testImportFileHeaderTextInSecondHeader() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWith2Headers.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(2));
        mapping.addPropertyConfigMapping("Header Text 2", new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List objectList = parser.importFile(spreadsheet, mapping);
        assertEquals(35, objectList.size());
    }

    public void testImportFileWithMissingRows() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWithMissingCells.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObject.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(1));
        POIExcelFileParser parser = new POIExcelFileParser();
        List objectList = parser.importFile(spreadsheet, mapping);
        assertEquals(32, objectList.size());
    }

    public void testImportFileWithFilter() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWith1Header.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(1));
        mapping.addPropertyConfigMapping("Test Header", new PropertyConfig("text", String.class, null, null, false));
        mapping.addFilter(new Filter(new ObjectInspector(), "text", "==", "Test With Header Filtered", String.class));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(34, resultList.size());
        assertEquals("Test With Header", ((MockMappedObjectWithSetters) resultList.get(0)).getText());
    }

    public void testImportFileAllTypesWithEmptyRow() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/AllTypesEmptyRow.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectAllTypesWithSetters.class, new ObjectInspector()));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("text", String.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(2), new PropertyConfig("number", Integer.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(3), new PropertyConfig("dbl", Double.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(4), new PropertyConfig("date", Date.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(5), new PropertyConfig("longNumber", Long.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(6), new PropertyConfig("primitiveInt", int.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(7), new PropertyConfig("primitiveDbl", double.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(8), new PropertyConfig("f", Float.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(9), new PropertyConfig("primitiveFloat", float.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(10), new PropertyConfig("s", Short.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(11), new PropertyConfig("primitiveShort", short.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(12), new PropertyConfig("primitiveLong", long.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(13), new PropertyConfig("b", Boolean.class, null, null, false));
        mapping.addPropertyConfigMapping(new Integer(14), new PropertyConfig("primitiveBoolean", boolean.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(42, resultList.size());
        MockMappedObjectAllTypesWithSetters obj = (MockMappedObjectAllTypesWithSetters) resultList.get(0);
        assertEquals("This is an example text cell.", obj.getText());
        assertEquals(new Integer(7), obj.getNumber());
        assertEquals(new Double(22.5), obj.getDbl());
        assertEquals(new SimpleDateFormat("MM/dd/yyyy").parse("7/31/2006"), obj.getDate());
        assertEquals(new Long(9223372036854775807l), obj.getLongNumber());
        assertEquals(2, obj.getPrimitiveInt());
        assertEquals(new Double(75.2), new Double(obj.getPrimitiveDbl()));
        assertEquals(new Float(1.2), obj.getF());
        assertEquals(new Float(2.2), new Float(obj.getPrimitiveFloat()));
        assertEquals(new Short((short) 1), obj.getS());
        assertEquals(new Short((short) 3), new Short(obj.getPrimitiveShort()));
        assertEquals(new Long(987654321987654016l), new Long(obj.getPrimitiveLong()));
        assertEquals(Boolean.TRUE, obj.getB());
        assertEquals(Boolean.FALSE, new Boolean(obj.isPrimitiveBoolean()));
    }

    public void testImportFileWithEmptyHeader() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/EmptyHeader.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectAllTypesWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(1));
        mapping.addPropertyConfigMapping("test", new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(6, resultList.size());
    }

    public void testImportFileWith2HeaderRowsAsProperties() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/SimpleWith2HeadersDifferentTypes.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectAllTypesWithSetters.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(2));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("textHeader", String.class, new Integer(1), null, false));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("integerHeader", Integer.class, new Integer(2), null, false));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(35, resultList.size());
        assertEquals("Test With Headers", ((MockMappedObjectAllTypesWithSetters) resultList.get(0)).getText());
        assertEquals("Test Header 1", ((MockMappedObjectAllTypesWithSetters) resultList.get(0)).getTextHeader());
        assertEquals(new Integer(12345), ((MockMappedObjectAllTypesWithSetters) resultList.get(0)).getIntegerHeader());
    }

    public void testImportFileUnableToConvertProperty() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/AllTypesEmptyRow.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectAllTypesWithSetters.class, new ObjectInspector()));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("date", Date.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(42, resultList.size());
        MockMappedObjectAllTypesWithSetters obj = (MockMappedObjectAllTypesWithSetters) resultList.get(0);
        assertNull(obj.getDate());
    }

    public void testImportFileEmptiedStringCellReturnsEmptyString() throws Exception {
        File spreadsheet = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/AllTypesMissingCells.xls");
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObjectAllTypesWithSetters.class, new ObjectInspector()));
        mapping.addPropertyConfigMapping(new Integer(1), new PropertyConfig("text", String.class, null, null, false));
        POIExcelFileParser parser = new POIExcelFileParser();
        List resultList = parser.importFile(spreadsheet, mapping);
        assertNotNull(resultList);
        assertEquals(42, resultList.size());
        MockMappedObjectAllTypesWithSetters obj = (MockMappedObjectAllTypesWithSetters) resultList.get(36);
        assertNull(obj.getText());
    }

    private class MockMapping extends Mapping {
        private Class mappedClass;

        public MockMapping(Class mappedClass) {
            super(new ObjectProperties(mappedClass, new ObjectInspector()));
            this.mappedClass = mappedClass;
        }

        public ObjectProperties getMappedClassProperties() {
            return new MockObjectProperties(this.mappedClass);
        }
    }

    private class MockObjectProperties extends ObjectProperties {

        public MockObjectProperties(Class clazz) {
            super(clazz, (ObjectInspector) null);
        }

        public List getConstructors(int numParameters) {
            List constructorList = new ArrayList();
            constructorList.add(MockMappedObjectPrivateConstructor.class.getDeclaredConstructors()[0]);
            return constructorList;
        }

        public MethodProperties getModifier(String propertyName, Class type, Object obj) throws NoSuchMethodException {
            Method method = MockMappedObjectWithSetters.class.getDeclaredMethod("setPrivate", new Class[] { String.class });
            return new MethodProperties(obj, method);
        }
    }
}
