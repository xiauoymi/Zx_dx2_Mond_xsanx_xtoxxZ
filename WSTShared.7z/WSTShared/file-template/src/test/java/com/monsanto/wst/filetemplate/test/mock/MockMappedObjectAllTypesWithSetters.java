package com.monsanto.wst.filetemplate.test.mock;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 26, 2006
 * Time: 10:31:56 AM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectAllTypesWithSetters {
  private String textHeader;
  private Integer integerHeader;
  private String text;
  private Integer number;
  private Double dbl;
  private Date date;
  private Long longNumber;
  private int primitiveInt;
  private double primitiveDbl;
  private Float f;
  private float primitiveFloat;
  private Short s;
  private short primitiveShort;
  private long primitiveLong;
  private Boolean b;
  private boolean primitiveBoolean;

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public Integer getNumber() {
    return number;
  }

  public void setNumber(Integer number) {
    this.number = number;
  }

  public Double getDbl() {
    return dbl;
  }

  public void setDbl(Double dbl) {
    this.dbl = dbl;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }

  public Long getLongNumber() {
    return longNumber;
  }

  public void setLongNumber(Long longNumber) {
    this.longNumber = longNumber;
  }

  public int getPrimitiveInt() {
    return primitiveInt;
  }

  public void setPrimitiveInt(int primitiveInt) {
    this.primitiveInt = primitiveInt;
  }

  public double getPrimitiveDbl() {
    return primitiveDbl;
  }

  public void setPrimitiveDbl(double primitiveDbl) {
    this.primitiveDbl = primitiveDbl;
  }

  public Float getF() {
    return f;
  }

  public void setF(Float f) {
    this.f = f;
  }

  public float getPrimitiveFloat() {
    return primitiveFloat;
  }

  public void setPrimitiveFloat(float primitiveFloat) {
    this.primitiveFloat = primitiveFloat;
  }

  public Short getS() {
    return s;
  }

  public void setS(Short s) {
    this.s = s;
  }

  public short getPrimitiveShort() {
    return primitiveShort;
  }

  public void setPrimitiveShort(short primitiveShort) {
    this.primitiveShort = primitiveShort;
  }

  public long getPrimitiveLong() {
    return primitiveLong;
  }

  public void setPrimitiveLong(long primitiveLong) {
    this.primitiveLong = primitiveLong;
  }

  public Boolean getB() {
    return b;
  }

  public void setB(Boolean b) {
    this.b = b;
  }

  public boolean isPrimitiveBoolean() {
    return primitiveBoolean;
  }

  public void setPrimitiveBoolean(boolean primitiveBoolean) {
    this.primitiveBoolean = primitiveBoolean;
  }

  public String getTextHeader() {
    return textHeader;
  }

  public void setTextHeader(String textHeader) {
    this.textHeader = textHeader;
  }

  public Integer getIntegerHeader() {
    return integerHeader;
  }

  public void setIntegerHeader(Integer integerHeader) {
    this.integerHeader = integerHeader;
  }
}
