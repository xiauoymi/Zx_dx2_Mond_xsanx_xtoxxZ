package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 3, 2006
 * Time: 9:18:08 AM
 * <p/>
 * Mock object that uses setter injection.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectWithSetters {
  private String text;
  private Object obj;
  private String header1;
  private String header2;

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  private void setPrivate(String denied) {

  }

  public void setThrowsException(String text) throws Exception {
    throw new Exception("Test");
  }

  public void getThrowsException() throws Exception {
    throw new Exception("Test Exception");
  }

  public Object getObj() {
    return obj;
  }

  public void setObj(Object obj) {
    this.obj = obj;
  }

  public String getHeader1() {
    return header1;
  }

  public void setHeader1(String header1) {
    this.header1 = header1;
  }

  public String getHeader2() {
    return header2;
  }

  public void setHeader2(String header2) {
    this.header2 = header2;
  }
}
