package com.monsanto.wst.filetemplate.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.filetemplate.ExternalConfigFileTemplate;
import junit.framework.TestCase;

import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 3:57:00 PM
 * <p/>
 * Integration/Acceptance test for the ExternalConfigFileTemplate object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ExternalConfigFileTemplateAT extends TestCase {

    public void testCreate() throws Exception {
        ExternalConfigFileTemplate template = new ExternalConfigFileTemplate("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml");
        assertNotNull(template);
    }

    public void testImportFile() throws Exception {
        ExternalConfigFileTemplate template = new ExternalConfigFileTemplate("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/Simple.xls");
        List objectList = template.importFile("spreadsheet1", file);
        assertEquals(30, objectList.size());
    }

}
