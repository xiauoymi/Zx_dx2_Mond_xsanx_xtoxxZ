package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 1:39:02 PM
 * <p/>
 * Mock mapped object that has a private constructor.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectPrivateConstructor {
    private MockMappedObjectPrivateConstructor(String text) {
    }

    private MockMappedObjectPrivateConstructor() {
    }
}
