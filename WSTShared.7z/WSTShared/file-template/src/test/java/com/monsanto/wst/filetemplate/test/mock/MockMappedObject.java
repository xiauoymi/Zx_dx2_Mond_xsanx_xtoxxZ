package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 7:35:29 AM
 * <p/>
 * Mock mapped object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObject {
  private String test;
  private Boolean bool;

  public MockMappedObject() {
  }

  public MockMappedObject(Integer testInt) {
  }

  public MockMappedObject(String test) {
    this.test = test;
  }

  public String getTest() {
    return test;
  }

  public Boolean getBool() {
    return bool;
  }

  public void setBool(Boolean bool) {
    this.bool = bool;
  }
}
