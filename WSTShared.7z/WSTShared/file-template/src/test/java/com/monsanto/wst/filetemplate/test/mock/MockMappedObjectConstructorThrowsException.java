package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 1:41:02 PM
 * <p/>
 * Mock mapped object that throws an exception.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectConstructorThrowsException {
    public MockMappedObjectConstructorThrowsException(String text) throws Exception {
        throw new Exception("Test Message");
    }
}
