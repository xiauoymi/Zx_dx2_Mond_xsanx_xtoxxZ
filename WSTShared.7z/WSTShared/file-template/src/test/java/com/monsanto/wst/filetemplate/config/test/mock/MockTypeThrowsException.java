package com.monsanto.wst.filetemplate.config.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 29, 2006
 * Time: 5:47:45 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockTypeThrowsException {
    public MockTypeThrowsException(String value) throws Exception {
        throw new Exception("Test Exception");
    }
}
