package com.monsanto.wst.filetemplate.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:53:33 PM
 * <p/>
 * Mock object with an unsupported type in it's constructor.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockMappedObjectUnsupportedType {
    public MockMappedObjectUnsupportedType(byte b) {
    }
}
