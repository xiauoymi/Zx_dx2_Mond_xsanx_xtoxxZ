package com.monsanto.wst.filetemplate.config.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 29, 2006
 * Time: 5:33:13 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class MockAbstractType {
    public MockAbstractType(String value) {
    }
}
