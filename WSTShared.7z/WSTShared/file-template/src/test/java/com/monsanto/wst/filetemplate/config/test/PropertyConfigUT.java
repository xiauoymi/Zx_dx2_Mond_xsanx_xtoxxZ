package com.monsanto.wst.filetemplate.config.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestResults;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestUtils;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 3, 2006
 * Time: 11:21:22 AM
 * <p/>
 * Unit test for the PropertyConfig object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PropertyConfigUT extends TestCase {
  public void testCreate() throws Exception {
    JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
    List propertyList = new ArrayList();
    propertyList.add("name");
    propertyList.add("type");
    propertyList.add("row");
    propertyList.add("value");
    propertyList.add("constant");
    JavaBeanTestResults results = testUtils.testProperties(PropertyConfig.class, propertyList);
    assertTrue(results.getCombinedResult());
    assertEquals(5, results.getNumResults());
  }

  public void testSetGetValue() throws Exception {
    PropertyConfig config = new PropertyConfig((String) null, String.class, null, null, false);
    Object obj = new Object();
    config.setValue(obj);
    assertEquals(obj, config.getValue());
  }
}
