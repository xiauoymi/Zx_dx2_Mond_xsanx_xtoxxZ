package com.monsanto.wst.filetemplate.config.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 29, 2006
 * Time: 5:42:49 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockPrivateType {
    private MockPrivateType(String value) {
    }
}
