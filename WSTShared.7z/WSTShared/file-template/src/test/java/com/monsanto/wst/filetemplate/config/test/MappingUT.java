package com.monsanto.wst.filetemplate.config.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.filetemplate.config.Filter;
import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObject;
import com.monsanto.wst.filetemplate.transform.ObjectProperties;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 3, 2006
 * Time: 7:22:30 AM
 * <p/>
 * Unit test for the Mapping object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MappingUT extends TestCase {

    public void testCreate() throws Exception {
        Mapping mapping = new Mapping((ObjectProperties) null);
        assertNotNull(mapping);
    }

    public void testGetMappedClassProperties() throws Exception {
        ObjectProperties objectProps = new ObjectProperties(MockMappedObject.class, new ObjectInspector());
        Mapping mapping = new Mapping(objectProps);
        assertEquals(objectProps, mapping.getMappedClassProperties());
    }

    public void testSetGetNumHeaderRows() throws Exception {
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObject.class, new ObjectInspector()));
        mapping.setNumHeaderRows(new Integer(2));
        assertEquals(new Integer(2), mapping.getNumHeaderRows());
    }

    public void testAddGetPropertyMapping() throws Exception {
        MockObjectProperties objectProps = new MockObjectProperties(MockMappedObject.class, new ObjectInspector());
        Mapping mapping = new Mapping(objectProps);
        PropertyConfig propertyConfig = new PropertyConfig("text1", String.class, null, null, false);
        mapping.addPropertyConfigMapping("Test Header 1", propertyConfig);
        assertEquals("text1", mapping.getPropertyConfig("Test Header 1", null).getName());
        assertTrue(objectProps.containsPropertyConfig(propertyConfig));
        propertyConfig = new PropertyConfig("text2", String.class, null, null, false);
        mapping.addPropertyConfigMapping("Test Header 2", propertyConfig);
        assertEquals("text2", mapping.getPropertyConfig("Test Header 2", null).getName());
        assertTrue(objectProps.containsPropertyConfig(propertyConfig));
        propertyConfig = new PropertyConfig("text3", String.class, null, null, false);
        mapping.addPropertyConfigMapping(new Integer(3), propertyConfig);
        assertEquals("text3", mapping.getPropertyConfig(new Integer(3), null).getName());
        assertTrue(objectProps.containsPropertyConfig(propertyConfig));
        propertyConfig = new PropertyConfig("text4", String.class, new Integer(1), null, false);
        mapping.addPropertyConfigMapping("Test Header 3", propertyConfig);
        assertEquals("text4", mapping.getPropertyConfig("Test Header 3", new Integer(1)).getName());
        assertTrue(objectProps.containsPropertyConfig(propertyConfig));
        propertyConfig = new PropertyConfig("text5", String.class, new Integer(1), null, false);
        mapping.addPropertyConfigMapping(new Integer(2), propertyConfig);
        assertEquals("text5", mapping.getPropertyConfig(new Integer(2), new Integer(1)).getName());
        assertTrue(objectProps.containsPropertyConfig(propertyConfig));
    }

    public void testGetPropertyConfigWithNullHeaderName() throws Exception {
        ObjectProperties objectProps = new ObjectProperties(MockMappedObject.class, new ObjectInspector());
        Mapping mapping = new Mapping(objectProps);
        assertNull(mapping.getPropertyConfig((String) null, new Integer(1)));
    }

    public void testAddFilter() throws Exception {
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObject.class, new ObjectInspector()));
        Filter filter = new Filter(new ObjectInspector(), "test", "==", "test value", String.class);
        mapping.addFilter(filter);
        MockMappedObject object = new MockMappedObject("test value");
        boolean result = mapping.filter(object);
        assertTrue(result);
    }

    public void testSetGetSheetIndex() throws Exception {
        Mapping mapping = new Mapping(new ObjectProperties(MockMappedObject.class, new ObjectInspector()));
        mapping.setSheetIndex(new Integer(1));
        assertEquals(new Integer(1), mapping.getSheetIndex());
    }

    private class MockObjectProperties extends ObjectProperties {
        private List propertyConfigList = new ArrayList();

        public MockObjectProperties(Class clazz, ObjectInspector objectInspector) {
            super(clazz, objectInspector);
        }

        public void addPropertyConfig(PropertyConfig propertyConfig) {
            this.propertyConfigList.add(propertyConfig);
        }

        public boolean containsPropertyConfig(PropertyConfig config) {
            return this.propertyConfigList.contains(config);
        }
    }
}
