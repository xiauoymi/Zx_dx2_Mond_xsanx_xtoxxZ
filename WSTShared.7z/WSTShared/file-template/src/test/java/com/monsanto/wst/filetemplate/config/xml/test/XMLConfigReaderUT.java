package com.monsanto.wst.filetemplate.config.xml.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.filetemplate.MappingConfigurationException;
import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.config.xml.XMLConfigReader;
import com.monsanto.wst.filetemplate.test.mock.MockMappedObjectWithSetters;
import com.monsanto.wst.filetemplate.transform.ObjectProperties;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 1, 2006
 * Time: 3:43:06 PM
 * <p/>
 * Unit test for the XMLMapping object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLConfigReaderUT extends TestCase {

  public void testCreate() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    assertNotNull(configReader);
  }

  public void testCreateInvalidXML() throws Exception {
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLConfigReader.class)).getLogger();
    logger.setLevel(Level.DEBUG);
    try {
      new XMLConfigReader("does/not/exist",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("Unable to parse the mapping file at 'does/not/exist'.  Please check and make sure the file " +
          "exists and contains valid xml.", e.getMessage());
    }

    logger.setLevel(Level.OFF);
    try {
      new XMLConfigReader("does/not/exist",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (IllegalArgumentException e) {
      assertEquals("Unable to parse the mapping file at 'does/not/exist'.  Please check and make sure the file " +
          "exists and contains valid xml.", e.getMessage());
    }
  }

  public void testCreateInvalidMapping() throws Exception {
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLConfigReader.class)).getLogger();
    logger.setLevel(Level.DEBUG);
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-invalid-class.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("Unable to find class 'does.not.exist' for mapping 'spreadsheetInvalidClass'.  Please " +
          "check that the object exists.", e.getMessage());
    }

    logger.setLevel(Level.OFF);
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-invalid-class.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("Unable to find class 'does.not.exist' for mapping 'spreadsheetInvalidClass'.  Please " +
          "check that the object exists.", e.getMessage());
    }
  }

  public void testGetMappingWithHeadersSetterInjection() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetWithSetterInjection");
    assertEquals("com.monsanto.wst.filetemplate.test.mock.MockMappedObjectWithSetters", mapping.getMappedClassProperties().getName());
    assertEquals(new Integer(1), mapping.getNumHeaderRows());
    assertEquals("firstColumn", mapping.getPropertyConfig("Test Header", null).getName());
    assertEquals(String.class, mapping.getPropertyConfig("Test Header", null).getType());
    assertEquals("secondColumn", mapping.getPropertyConfig(new Integer(2), null).getName());
    assertEquals(String.class, mapping.getPropertyConfig(new Integer(2), null).getType());
  }

  public void testGetMappingWithHeadersSetterInjectionUnknownType() throws Exception {
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-invalid-property-type.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("Unable to find type 'does.not.exist' in property 'firstColumn' for mapping " +
          "'spreadsheetWithSetterInjectionUnknownType'.  Please check that the " +
          "type exists.", e.getMessage());
    }
  }

  public void testCreateInvalidAccordingToSchema() throws Exception {
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLConfigReader.class)).getLogger();
    logger.setLevel(Level.DEBUG);
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-fails-validation.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("The XML mapping configuration file 'com/monsanto/wst/filetemplate/config/xml/test/" +
          "test-mapping-fails-validation.xml' is invalid according to the schema.", e.getMessage());
    }

    logger.setLevel(Level.OFF);
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-fails-validation.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("The XML mapping configuration file 'com/monsanto/wst/filetemplate/config/xml/test/" +
          "test-mapping-fails-validation.xml' is invalid according to the schema.", e.getMessage());
    }
  }

  public void testGetMappingDoesNotExist() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    try {
      configReader.getMapping("doesNotExist");
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("Unable to find mapping with id 'doesNotExist'", e.getMessage());
    }
  }

  public void testGetMappingWithFilter() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetWithFilter");
    MockMappedObjectWithSetters object = new MockMappedObjectWithSetters();
    object.setText("test value");
    boolean result = mapping.filter(object);
    assertTrue(result);
  }

  public void testGetMappingWithNullCheckFilter() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetWithNullCheckFilter");
    MockMappedObjectWithSetters object = new MockMappedObjectWithSetters();
    object.setText(null);
    boolean result = mapping.filter(object);
    assertTrue(result);
  }

  public void testGetMappingWithFilterInvalidType() throws Exception {
    try {
      new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping-invalid-filter-type.xml",
          new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
      fail("This should have thrown an exception.");
    } catch (MappingConfigurationException e) {
      assertEquals("Invalid Filter: Unable to find the filter type 'does.not.exist'.", e.getMessage());
    }
  }

  public void testGetMappingWithSelectedSheet() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetSelectSheet");
    assertEquals(new Integer(1), mapping.getSheetIndex());
  }

  public void testGetMappingWithConstant() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetWithConstant");
    ObjectProperties objectProperties = mapping.getMappedClassProperties();
    MockMappedObjectWithSetters obj = (MockMappedObjectWithSetters) objectProperties.instantiateObject();
    assertEquals("test", obj.getText());
  }

  public void testGetMappingWithHeaderProperty() throws Exception {
    XMLConfigReader configReader = new XMLConfigReader("com/monsanto/wst/filetemplate/config/xml/test/test-mapping.xml",
        new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(), new ObjectInspector());
    Mapping mapping = configReader.getMapping("spreadsheetWithHeaderProperties");
    assertEquals("header1", mapping.getPropertyConfig(new Integer(1), new Integer(1)).getName());
    assertEquals("header2", mapping.getPropertyConfig(new Integer(2), new Integer(1)).getName());
  }
}
