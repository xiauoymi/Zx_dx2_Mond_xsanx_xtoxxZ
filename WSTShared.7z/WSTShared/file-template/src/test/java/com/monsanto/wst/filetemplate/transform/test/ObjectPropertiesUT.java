package com.monsanto.wst.filetemplate.transform.test;

import com.monsanto.wst.commonutils.reflection.MethodProperties;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.filetemplate.ObjectMappingException;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import com.monsanto.wst.filetemplate.test.mock.*;
import com.monsanto.wst.filetemplate.transform.ObjectProperties;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 8:39:34 AM
 * <p/>
 * Unit test for the ObjectProperties object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectPropertiesUT extends TestCase {

  public void testCreate() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObject.class, (ObjectInspector) null);
    assertNotNull(objectProps);
  }

  public void testGetConstructors() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObject.class, new ObjectInspector());
    List constructorList = objectProps.getConstructors(1);
    assertNotNull(constructorList);
    assertEquals(2, constructorList.size());
  }

  public void testGetObjectName() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObject.class, (ObjectInspector) null);
    assertEquals("com.monsanto.wst.filetemplate.test.mock.MockMappedObject", objectProps.getName());
  }

  public void testGetModifier() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    MockMappedObjectWithSetters object = new MockMappedObjectWithSetters();
    MethodProperties methodProperties = objectProps.getModifier("text", String.class, object);
    methodProperties.invoke(new Object[] { "Test" });
    assertEquals("Test", object.getText());
  }

  public void testInstantiateObject() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    assertEquals(MockMappedObjectWithSetters.class, objectProps.instantiateObject().getClass());
  }

  public void testInstantiateObjectWithProperties() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    PropertyConfig propertyConfig = new PropertyConfig("text", String.class, null, null, false);
    propertyConfig.setValue("test");
    objectProps.addPropertyConfig(propertyConfig);
    MockMappedObjectWithSetters obj = (MockMappedObjectWithSetters) objectProps.instantiateObject();
    assertEquals("test", obj.getText());
    obj = (MockMappedObjectWithSetters) objectProps.instantiateObject();
    assertNull(obj.getText());
  }

  public void testInsantiateObjectWithConstants() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    PropertyConfig propertyConfig = new PropertyConfig("text", String.class, null, null, false);
    propertyConfig.setValue("test");
    objectProps.addPropertyConfig(propertyConfig);
    propertyConfig = new PropertyConfig("header1", String.class, null, null, true);
    propertyConfig.setValue("constant");
    objectProps.addPropertyConfig(propertyConfig);
    MockMappedObjectWithSetters obj = (MockMappedObjectWithSetters) objectProps.instantiateObject();
    assertEquals("test", obj.getText());
    assertEquals("constant", obj.getHeader1());
    obj = (MockMappedObjectWithSetters) objectProps.instantiateObject();
    assertNull(obj.getText());
    assertEquals("constant", obj.getHeader1());
  }

  public void testInstantiateObjectWithObjectProperty() throws Exception {
    ObjectProperties objectProps = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    PropertyConfig propertyConfig = new PropertyConfig("obj", Integer.class, null, null, false);
    propertyConfig.setValue(new Integer(12345));
    objectProps.addPropertyConfig(propertyConfig);
    MockMappedObjectWithSetters obj = (MockMappedObjectWithSetters) objectProps.instantiateObject();
    assertEquals(new Integer(12345), obj.getObj());
  }

  public void testInstantiateObjectPropertyNotFound() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("doesNotExist", String.class, null, "test", false));
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to find setter for property 'doesNotExist' in object '" +
          MockMappedObjectWithSetters.class.getName() + "'.  Please check your object and configuration " +
          "to verify the properties match.", e.getMessage());
    }
  }

  public void testInstantiateObjectPropertyIllegalAccess() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockMappedObjectWithSetters.class, new MockObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("private", String.class, null, "test", false));
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to access setter for property 'private' in object '" +
          MockMappedObjectWithSetters.class.getName() + "'.  Please check permissions on the setter.", e.getMessage());
    }
  }

  public void testInstantiateObjectPropertyThrowsException() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockMappedObjectWithSetters.class, new ObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("throwsException", String.class, null, "test", false));
    Logger logger = ((Log4JLogger) LogFactory.getLog(ObjectProperties.class)).getLogger();
    logger.setLevel(Level.DEBUG);
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to call setter for property 'throwsException' in object '" +
          MockMappedObjectWithSetters.class.getName() + "'.  The method threw an exception.", e.getMessage());
    }

    logger.setLevel(Level.OFF);
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to call setter for property 'throwsException' in object '" +
          MockMappedObjectWithSetters.class.getName() + "'.  The method threw an exception.", e.getMessage());
    }
  }

  public void testInstantiateObjectPropertyInterface() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockMappedObjectAbstractProperty.class, new ObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("testProperty.someField", Comparable.class, null, "test", false));
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to instantiate one of the objects specified in the property " +
          "name path.  This more than likely happened because one of the objects in the path was not " +
          "pre-initialized and has a type that is abstract or an interface.  Please pre-initialize " +
          "objects in the property path or provide a concrete class with a no args constructor.", e.getMessage());
    }
  }

  public void testInstantiateObjectIllegalAccessConstructor() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockMappedObjectPrivateConstructor.class, new MockObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("bool", Boolean.class, null, Boolean.FALSE, false));
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to access no args constructor for object '" +
          MockMappedObjectPrivateConstructor.class.getName() + "'.  Make sure it has a no args public constructor " +
          "or default constructor.", e.getMessage());
    }
  }

  public void testInstantiateObjectAbstractClass() throws Exception {
    ObjectProperties objectProperties = new ObjectProperties(MockAbstractMappedObject.class, new ObjectInspector());
    objectProperties.addPropertyConfig(new PropertyConfig("bool", Boolean.class, null, Boolean.FALSE, false));
    try {
      objectProperties.instantiateObject();
      fail("This should have thrown an exception.");
    } catch (ObjectMappingException e) {
      assertEquals("Unable to instantiate mapped object '" + MockAbstractMappedObject.class.getName() +
          "'.  Make sure the object is not an interface or abstract class.", e.getMessage());
    }
  }

  private class MockObjectInspector extends ObjectInspector {
    public MethodProperties getModifier(String propertyPath, Object obj, Class type, boolean overridePermissions)
        throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
      Method modifier = getModifier(propertyPath, obj.getClass(), type, true);
      modifier.setAccessible(false);
      return new MethodProperties(obj, modifier);
    }

    public Constructor getConstructor(Class clazz, Class[] types) throws NoSuchMethodException {
      Constructor constructor = clazz.getDeclaredConstructor(types);
      constructor.setAccessible(false);
      return constructor;
    }
  }
}
