package com.monsanto.wst.filetemplate.transform.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.filetemplate.transform.AbstractFileParserStrategy;
import com.monsanto.wst.filetemplate.transform.FileParser;
import com.monsanto.wst.filetemplate.transform.excel.poi.POIExcelFileParser;
import junit.framework.TestCase;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:19:46 PM
 * <p/>
 * Integration/Acceptance test for the AbstractFileParserStrategy object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractFileParserStrategyAT extends TestCase {

    public void testNewInstance() throws Exception {
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/filetemplate/transform/excel/poi/test/Simple.xls");
        FileParser parser = AbstractFileParserStrategy.newInstance(file);
        assertNotNull(parser);
        assertEquals(POIExcelFileParser.class, parser.getClass());
    }

    public void testNewInstanceIllegalArgument() throws Exception {
        try {
            AbstractFileParserStrategy.newInstance(null);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid file specified 'null'.  Only XLS is supported.", e.getMessage());
        }
    }

}
