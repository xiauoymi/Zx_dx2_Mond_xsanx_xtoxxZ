package com.monsanto.wst.filetemplate.config;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.filetemplate.MappingConfigurationException;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 29, 2006
 * Time: 2:23:07 PM
 * <p/>
 * This class represents a filter that will be used against a spreadsheet.  It defines methods to determine whether a
 * particular row in a spreadsheet should be filtered from the object results.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class Filter {
  private ObjectInspector objectInspector;
  private String propertyName;
  private String operator;
  private Object value;
  private static final String EQUALS_OPERATOR = "==";

  /**
   * This constructor takes an object inspector the name of the property to filter by, the operator to use to filter
   * by, the value that should be used to filter by and the type of the value.
   *
   * @param objectInspector ObjectInspector object that contains reflection tools.
   * @param propertyName String representing the name of the property.
   * @param operator String representing the operator.
   * @param value String representing the value.
   * @param valueType Class representing the value type.
   */
  public Filter(ObjectInspector objectInspector, String propertyName, String operator, String value, Class valueType) {
    this.objectInspector = objectInspector;
    this.propertyName = propertyName;
    this.operator = operator;
    if (value != null) {
      try {
        Constructor constructor = objectInspector.getConstructor(valueType, new Class[] { String.class });
        this.value = constructor.newInstance(new Object[] { value });
      } catch (NoSuchMethodException e) {
        throw new MappingConfigurationException("Invalid Filter: Unable to find a constructor on the type '" +
            valueType.getName() + "' that takes a string.");
      } catch (InstantiationException e) {
        throw new MappingConfigurationException("Invalid Filter: Unable to instantiate constructor for type '" +
            valueType.getName() + "'.  This most likely happened because the type is abstract or an interface.");
      } catch (IllegalAccessException e) {
        throw new MappingConfigurationException("Invalid Filter: Unable to access constructor for type '" +
            valueType.getName() + "'.  This most likely happened because the constructor for the type is private.");
      } catch (InvocationTargetException e) {
        throw new MappingConfigurationException("Invalid Filter: Unable to invoke constructor for type '" +
            valueType.getName() + "'.  The constructor threw an exception.");
      }
    } else {
      this.value = null;
    }
  }

  /**
   * This method returns a boolean representing if the specified object should be filtered from the results.
   *
   * @param obj Object representing a row in the spreadsheet.
   * @return boolean - Representing if the object should be filtered.
   */
  public boolean shouldFilter(Object obj) {
    try {
      Object value = this.objectInspector.getAcessorValue(obj, this.propertyName, false);
      if (EQUALS_OPERATOR.equals(this.operator) && this.value != null) {
        return this.value.equals(value);
      } else if (EQUALS_OPERATOR.equals(this.operator) && this.value == null) {
        return value == null;
      }
    } catch (NoSuchMethodException e) {
      throw new MappingConfigurationException("Invalid Filter: The filter property '" + this.propertyName +
          "' does not appear to exist on the mapped object.");
    } catch (IllegalAccessException e) {
      throw new MappingConfigurationException("Invalid Filter: The filter property '" + this.propertyName +
          "' can not be accessed on the mapped object due to permissions.");
    } catch (InvocationTargetException e) {
      throw new MappingConfigurationException("Invalid Filter: The accessor for property '" + this.propertyName +
          "' threw an exception.");
    }
    throw new MappingConfigurationException("Invalid Filter: Invalid operator '" + this.operator + "'.");
  }
}
