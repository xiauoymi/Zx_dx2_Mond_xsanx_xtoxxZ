package com.monsanto.wst.filetemplate.mock;

import com.monsanto.wst.filetemplate.FileTemplate;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 12:14:48 PM
 * <p/>
 * Mock implementation of the FileTemplate interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockFileTemplate implements FileTemplate {
    private String fileId;
    private File file;

    public List importFile(String fileId, File file) throws IOException {
        this.fileId = fileId;
        this.file = file;
        return null;
    }

    public String getFileId() {
        return fileId;
    }

    public File getFile() {
        return file;
    }
}
