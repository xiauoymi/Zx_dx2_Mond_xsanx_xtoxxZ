package com.monsanto.wst.filetemplate.transform;

import com.monsanto.wst.filetemplate.transform.excel.poi.POIExcelFileParser;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:21:28 PM
 * <p/>
 * This abstract class uses a strategy pattern for determining the correct implementation of the FileParser interface to
 * use.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractFileParserStrategy implements FileParser {
    /**
     * This method returns a new instance of the appropriate implementation of the FileParser interface.
     *
     * @param file File object representing the file being converted.
     * @return FileParser - Object used to parse a file into objects.
     */
    public static FileParser newInstance(File file) {
        if (file != null && file.getName().indexOf(".xls") > -1) {
            return new POIExcelFileParser();
        }
        throw new IllegalArgumentException("Invalid file specified '" + file + "'.  Only XLS is supported.");
    }
}
