package com.monsanto.wst.filetemplate.transform;

import com.monsanto.wst.commonutils.reflection.MethodProperties;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.filetemplate.ObjectMappingException;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 8:40:31 AM
 * <p/>
 * This class is a wrapper object for a Class object which exposes methods for retrieving specific information about the
 * class wrapped.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectProperties {
  private static final Log log = LogFactory.getLog(ObjectProperties.class);
  private Constructor[] constructors;
  private Class clazz;
  private ObjectInspector objectInspector;
  private List propertyConfigList = new ArrayList();

  /**
   * This constructor takes Class it is wrapping.
   *
   * @param clazz - Class object properties will be retrieved from.
   * @param objectInspector
   */
  public ObjectProperties(Class clazz, ObjectInspector objectInspector) {
    this.clazz = clazz;
    this.objectInspector = objectInspector;
    this.constructors = clazz.getConstructors();
  }

  /**
   * This method returns the next constructor that has the same number of parameters as specified.
   *
   * @param numParameters int representing the number of parameters in the constructor.
   * @return Constructor - Object matching the number of parameters.
   */
  public List getConstructors(int numParameters) {
    List constructorList = new ArrayList();
    for (int i = 0; i < this.constructors.length; i++) {
      if (this.constructors[i].getParameterTypes().length == numParameters) {
        constructorList.add(this.constructors[i]);
      }
    }
    return constructorList;
  }

  /**
   * This method returns the name of the class being wrapped.
   *
   * @return String - Representing the name of the object.
   */
  public String getName() {
    return this.clazz.getName();
  }

  /**
   * This method returns the setter on current class for the specified property having the specified type.
   *
   * @param propertyName String representing the property name.
   * @param type Class representing the setter type.
   * @param obj
   * @return Method - Object representing the setter.
   * @throws NoSuchMethodException - If unable to find the setter.
   */
  public MethodProperties getModifier(String propertyName, Class type, Object obj)
      throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
    return this.objectInspector.getModifier(propertyName, obj, type, false);
  }

  /**
   * This method instantiates the current class using a no args constructor.
   *
   * @return Object - Representing the instantiated class.
   */
  public Object instantiateObject() {
    try {
      Object obj = this.clazz.newInstance();
      injectPropertyValues(obj);
      return obj;
    } catch (IllegalAccessException e) {
      throw new ObjectMappingException("Unable to access no args constructor for object '" +
          this.clazz.getName() + "'.  Make sure it has a no args public constructor or default constructor.");
    } catch (InstantiationException e) {
      throw new ObjectMappingException("Unable to instantiate mapped object '" + this.clazz.getName() +
          "'.  Make sure the object is not an interface or abstract class.");
    }
  }

  /**
   * This method adds a property config which will be used when instantiating the object.
   *
   * @param propertyConfig PropertyConfig object representing property information and data.
   */
  public void addPropertyConfig(PropertyConfig propertyConfig) {
    this.propertyConfigList.add(propertyConfig);
  }

  /**
   * This method injects all the properties that have data.
   *
   * @param obj Object representing the object to inject.
   */
  private void injectPropertyValues(Object obj) {
    for (int i = 0; i < propertyConfigList.size(); i++) {
      PropertyConfig config = (PropertyConfig) propertyConfigList.get(i);
      if (config.getValue() != null) {
        try {
          MethodProperties methodProps = this.objectInspector.getModifier(config.getName(), obj, config.getType(), false);
          methodProps.invoke(new Object[] { config.getValue() });
          if (!config.getConstant()) {
            config.setValue(null);
          }
        } catch (NoSuchMethodException e) {
          throw new ObjectMappingException("Unable to find setter for property '" + config.getName() +
              "' in object '" + this.clazz.getName() + "'.  Please check your object " +
              "and configuration to verify the properties match.");
        } catch (IllegalAccessException e) {
          throw new ObjectMappingException("Unable to access setter for property '" + config.getName() +
              "' in object '" + this.clazz.getName() +
              "'.  Please check permissions on the setter.");
        } catch (InvocationTargetException e) {
          throw new ObjectMappingException("Unable to call setter for property '" + config.getName() +
              "' in object '" + this.clazz.getName() +
              "'.  The method threw an exception.", e.getTargetException());
        } catch (InstantiationException e) {
          throw new ObjectMappingException("Unable to instantiate one of the objects specified in the property " +
              "name path.  This more than likely happened because one of the objects in the path was not " +
              "pre-initialized and has a type that is abstract or an interface.  Please pre-initialize " +
              "objects in the property path or provide a concrete class with a no args constructor.");
        }
      }
    }
  }
}
