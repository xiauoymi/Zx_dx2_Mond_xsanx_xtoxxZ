package com.monsanto.wst.filetemplate.config.xml;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLValidationException;
import com.monsanto.wst.commonutils.xml.XPathUtils;
import com.monsanto.wst.filetemplate.MappingConfigurationException;
import com.monsanto.wst.filetemplate.config.ConfigReader;
import com.monsanto.wst.filetemplate.config.Filter;
import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import com.monsanto.wst.filetemplate.transform.ObjectProperties;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 1, 2006
 * Time: 3:43:38 PM
 * <p/>
 * This class is an XML implementation of the Mapping interface.  It provides methods for retrieving data from an xml
 * mapping file.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLConfigReader implements ConfigReader {
  private static final Log log = LogFactory.getLog(XMLConfigReader.class);
  private Map mappings = new HashMap();

  /**
   * This constructor takes all dependencies.
   *
   * @param mappingFile String representing the path to the XML mapping file.
   * @param xmlUtils XMLUtilities object containing xml utility methods.
   * @param xpathUtils XPathUtils object containing xpath utility methods.
   * @param objectInspector
   */
  public XMLConfigReader(String mappingFile, XMLUtilities xmlUtils, XPathUtils xpathUtils,
                         ObjectInspector objectInspector) {
    NodeList mappingList = parseMappingList(mappingFile, xmlUtils, xpathUtils);
    parseMappingsIntoMap(mappingList, xpathUtils, objectInspector);
  }

  /**
   * This method parses a list of mapping nodes and creates an internal Map for storing the data.
   *
   * @param mappingList NodeList object representing the mappings.
   * @param xpathUtils
   */
  private void parseMappingsIntoMap(NodeList mappingList, XPathUtils xpathUtils, ObjectInspector objectInspector) {
    for (int i = 0; i < mappingList.getLength(); i++) {
      Element mappingElement = (Element) mappingList.item(i);
      String mappingId = mappingElement.getAttribute("id");
      String className = mappingElement.getAttribute("class");
      Mapping mapping = null;
      try {
        ObjectProperties objectProps = new ObjectProperties(Class.forName(className), objectInspector);
        mapping = new Mapping(objectProps);
        addOptions(mappingElement, xpathUtils, mapping, mappingId, objectInspector, objectProps);
      } catch (ClassNotFoundException e) {
        if (log.isErrorEnabled()) {
          log.error("Unable to find class '" + className + "' for mapping '" + mappingId +
              "'.  Please check that the object exists.", e);
        }
        throw new MappingConfigurationException("Unable to find class '" + className + "' for mapping '" +
            mappingId + "'.  Please check that the object exists.");
      }
      this.mappings.put(mappingId, mapping);
    }
  }

  /**
   * This method adds any optional options to the mapping configuration.
   *
   * @param mappingElement Element representing the mapping.
   * @param xpathUtils XPathUtils object representing xpath utility methods.
   * @param mapping Mapping object representing the mapping.
   * @param mappingId
   * @param objectInspector
   * @param objectProps
   */
  private void addOptions(Element mappingElement, XPathUtils xpathUtils, Mapping mapping, String mappingId,
                          ObjectInspector objectInspector, ObjectProperties objectProps) {
    addHeaderInfo(mappingElement, xpathUtils, mapping, mappingId, objectProps);
    mapping.setSheetIndex(parseSheetIndex(mappingElement, xpathUtils));
    addProperties(mappingElement, xpathUtils, mapping, mappingId, objectProps, false);
    addFilters(mappingElement, xpathUtils, mapping, objectInspector);
  }

  /**
   * This method adds filter criteria to the mapping object based on configuration information provided.
   *
   * @param mappingElement Element representing the mapping element.
   * @param xpathUtils XpathUtils object used to perform xpath.
   * @param mapping Mapping object containing mapping information.
   * @param objectInspector ObjectInspector object representing tools for doing reflection.
   */
  private void addFilters(Element mappingElement, XPathUtils xpathUtils, Mapping mapping, ObjectInspector objectInspector) {
    NodeList filterElements = xpathUtils.selectNodeList(mappingElement, "filters/filter");
    for (int i = 0; i < filterElements.getLength(); i++) {
      Element filterElement = (Element) filterElements.item(i);
      String columnName = filterElement.getAttribute("property");
      String operator = filterElement.getAttribute("operator");
      String value = filterElement.getAttribute("value");
      if ("null".equalsIgnoreCase(value)) {
        value = null;
      }
      String type = filterElement.getAttribute("type");
      try {
        mapping.addFilter(new Filter(objectInspector, columnName, operator, value, Class.forName(type)));
      } catch (ClassNotFoundException e) {
        throw new MappingConfigurationException("Invalid Filter: Unable to find the filter type '" + type + "'.");
      }
    }
  }

  /**
   * This method parses the sheet index.
   *
   * @param mappingElement Element representing the mapping.
   * @param xpathUtils XPathUtils object representing xpath utility methods.
   * @return Integer - Representing the sheet index.
   */
  private Integer parseSheetIndex(Element mappingElement, XPathUtils xpathUtils) {
    return xpathUtils.evalToInteger(mappingElement, "@sheet");
  }

  /**
   * This method adds any setter properties to the mapping configuration.
   *
   * @param mappingElement Element representing the mapping.
   * @param xpathUtils XPathUtils object representing xpath utility methods.
   * @param mapping Mapping object representing the mapping.
   * @param mappingId
   * @param objectProps
   * @param constant
   */
  private void addProperties(Element mappingElement, XPathUtils xpathUtils, Mapping mapping, String mappingId,
                             ObjectProperties objectProps, boolean constant) {
    NodeList properties = xpathUtils.selectNodeList(mappingElement, "properties/property");
    for (int i = 0; i < properties.getLength(); i++) {
      Element property = (Element) properties.item(i);
      String type = property.getAttribute("type");
      try {
        Integer row = null;
        if (StringUtils.isNotEmpty(property.getAttribute("row"))) {
          row = new Integer(property.getAttribute("row"));
        }
        String headerName = property.getAttribute("header");
        if (StringUtils.isNotEmpty(headerName)) {
          mapping.addPropertyConfigMapping(headerName, new PropertyConfig(property.getAttribute("name"), Class.forName(type), row, null, constant));
        }
        String index = property.getAttribute("index");
        if (StringUtils.isNotEmpty(index)) {
          mapping.addPropertyConfigMapping(new Integer(index), new PropertyConfig(property.getAttribute("name"), Class.forName(type), row, null, constant));
        }
        String value = property.getAttribute("value");
        if (StringUtils.isNotEmpty(value)) {
          objectProps.addPropertyConfig(new PropertyConfig(property.getAttribute("name"), Class.forName(type), row, value, true));
        }
      } catch (ClassNotFoundException e) {
        throw new MappingConfigurationException("Unable to find type '" + type + "' in property '" +
            property.getAttribute("name") + "' for mapping '" + mappingId + "'.  Please check that the " +
            "type exists.");
      }
    }
  }

  /**
   * This method returns the number of header rows for the current mapping.
   *
   * @param mappingElement Element representing the mapping.
   * @param xpathUtils XPathUtils object containing xpath utility methods.
   * @param mapping
   * @param mappingId
   * @param objectProperties
   */
  private void addHeaderInfo(Element mappingElement, XPathUtils xpathUtils, Mapping mapping, String mappingId,
                             ObjectProperties objectProperties) {
    Element headerElement = (Element) xpathUtils.selectSingleNode(mappingElement, "headers");
    if (headerElement != null) {
      mapping.setNumHeaderRows(new Integer(headerElement.getAttribute("rows")));
      addProperties(headerElement, xpathUtils, mapping, mappingId, objectProperties, true);
    }
  }

  /**
   * This method creates an XML document from the path specified and parses it for mappings.
   *
   * @param mappingFile String representing the path to the XML mapping file.
   * @param xmlUtils XMLUtilities object containing xml utility methods.
   * @param xpathUtils XPathUtils object containing xpath utility methods.
   * @return NodeList - Object representing the mappings.
   */
  private NodeList parseMappingList(String mappingFile, XMLUtilities xmlUtils, XPathUtils xpathUtils) {
    try {
      xmlUtils.validateAgainstExternalSchema(getClass().getClassLoader().getResourceAsStream(mappingFile), "urn:www.monsanto.com:filetemplate",
          "http://w3.ent.monsanto.com/wst/xml_schema/usseed/filetemplate.xsd");
      Document mapping = xmlUtils.createDocument(getClass().getClassLoader().getResourceAsStream(mappingFile));
      return xpathUtils.selectNodeList(mapping, "//mapping");
    } catch (XMLParserException e) {
      if (log.isErrorEnabled()) {
        log.error("Unable to parse the mapping file at '" + mappingFile + "'.  Please check and make sure " +
            "the file exists and contains valid xml.", e);
      }
      throw new IllegalArgumentException("Unable to parse the mapping file at '" + mappingFile + "'.  " +
          "Please check and make sure the file exists and contains valid xml.");
    } catch (XMLValidationException e) {
      if (log.isErrorEnabled()) {
        log.error("The XML mapping configuration file '" + mappingFile + "' is invalid according to the schema.", e);
      }
      throw new MappingConfigurationException("The XML mapping configuration file '" + mappingFile +
          "' is invalid according to the schema.");
    }
  }

  /**
   * This method returns the class associated with the specified mapping id.
   *
   * @param mappingId String representing the id of the mapping.
   * @return Mapping - Representing the mapped configuration.
   */
  public Mapping getMapping(String mappingId) {
    if (this.mappings.get(mappingId) != null) {
      return (Mapping) this.mappings.get(mappingId);
    }
    throw new MappingConfigurationException("Unable to find mapping with id '" + mappingId + "'");
  }
}
