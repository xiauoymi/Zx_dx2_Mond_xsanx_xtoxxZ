package com.monsanto.wst.filetemplate;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:34:46 PM
 * <p/>
 * This interface defines the contract for converting file data into objects.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface FileTemplate {
    /**
     * This method imports the specified file into a list of configured objects identified by the file id.
     *
     * @param fileId String representing the file id located in the configuration.
     * @param file File representing the file to import.
     * @return List - Of configured objects representing the file data.
     * @throws java.io.IOException - If unable to access the file.
     */
    List importFile(String fileId, File file) throws IOException;
}
