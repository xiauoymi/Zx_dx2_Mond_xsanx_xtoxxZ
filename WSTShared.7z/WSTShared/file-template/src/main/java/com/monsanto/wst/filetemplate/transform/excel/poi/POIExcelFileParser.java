package com.monsanto.wst.filetemplate.transform.excel.poi;

import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.config.PropertyConfig;
import com.monsanto.wst.filetemplate.transform.FileParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 9:50:46 AM
 * <p/>
 * This class is a POI Excel implementation of the FileParser interface.  It defines methods for mapping file data
 * into objects.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class POIExcelFileParser implements FileParser {
    private static final Log log = LogFactory.getLog(POIExcelFileParser.class);

    /**
     * This method returns a list of mapped objects for the specified file.
     *
     * @param spreadsheetFile File representing the spreadsheet to transform.
     * @param mapping Mapping object that contains configuration information about the file being parsed.
     * @return List - Of configured objects representing the data in the file.
     * @throws IOException - If unable to read file.
     */
    public List importFile(File spreadsheetFile, Mapping mapping) throws IOException {
        HSSFWorkbook workbook = createWorkbook(spreadsheetFile);
        return parseSheets(workbook, mapping);
    }

    /**
     * This method parses the work books and processes all sheets.
     *
     * @param workbook HSSFWorkbook object representing the excel workbook.
     * @param mapping Mapping object that contains configuration information about the file being parsed.
     * @return List - Of objects representing the spreadsheet.
     */
    private List parseSheets(HSSFWorkbook workbook, Mapping mapping) {
        int numSheets = workbook.getNumberOfSheets();
        List objectList = new ArrayList();
        if (mapping.getSheetIndex() != null
                && mapping.getSheetIndex().intValue() <= numSheets
                && mapping.getSheetIndex().intValue() > 0) {
            objectList.addAll(parseSheet(workbook.getSheetAt(mapping.getSheetIndex().intValue() - 1), mapping));
        } else {
            for (int i = 0; i < numSheets; i++) {
                HSSFSheet sheet = workbook.getSheetAt(i);
                objectList.addAll(parseSheet(sheet, mapping));
            }
        }
        return objectList;
    }

    /**
     * This method creates a POI workbook from the specified spreadsheet file.
     *
     * @param spreadsheetFile File representing the spreadsheet.
     * @return HSSFWorkbook - Object representing the excel workbook.
     * @throws IOException - If unable to read the spreadsheet.
     */
    private HSSFWorkbook createWorkbook(File spreadsheetFile) throws IOException {
        FileInputStream stream = new FileInputStream(spreadsheetFile);
        POIFSFileSystem fs = new POIFSFileSystem(stream);
        return new HSSFWorkbook(fs);
    }

    /**
     * This method parses the specified sheet and maps the corresponding data to a list of objects.
     *
     * @param sheet HSSFSheet object representing the current sheet.
     * @param mapping - Mapping object representing the mapping configuration.
     * @return List - Of objects representing the data.
     */
    private List parseSheet(HSSFSheet sheet, Mapping mapping) {
        HSSFRow row;
        List objectList = new ArrayList();
        for (int i = 0; i < mapping.getNumHeaderRows().intValue(); i++) {
            row = sheet.getRow(i);
            injectObject(mapping, row, sheet, new Integer(row.getRowNum() + 1));
        }
        for (int i = mapping.getNumHeaderRows().intValue(); i < sheet.getLastRowNum() + 1; i++) {
            row = sheet.getRow(i);
            if (row != null) {
                injectObject(mapping, row, sheet, null);
                Object obj = mapping.getMappedClassProperties().instantiateObject();
                if (!mapping.filter(obj)) {
                    objectList.add(obj);
                }
            }
        }
        return objectList;
    }

    /**
     * This method converts the specified row into an object.
     *
     * @param mapping - Mapping object representing the mapping configuration.
     * @param row HSSFRow object representing the current spreadsheet row.
     * @param sheet
     * @param rowNum
     */
    private void injectObject(Mapping mapping, HSSFRow row, HSSFSheet sheet, Integer rowNum) {
        for (short i = 0; i < row.getLastCellNum(); i++) {
            HSSFCell cell = row.getCell(i);
            PropertyConfig config = mapping.getPropertyConfig(new Integer(i + 1), rowNum);
            if (config != null && cell != null) {
                mapCellValue(config, cell);
            } else {
                config = findPropertyByHeaderText(sheet, i, mapping, rowNum);
                if (config != null && cell != null) {
                    mapCellValue(config, cell);
                }
            }
        }
    }

    /**
     * This method calls the setter for the specified object, injecting the current cell's data.
     *
     * @param config PropertyConfig object representing information about the current property being set.
     * @param cell HSSFCell object containing the data.
     */
    private void mapCellValue(PropertyConfig config, HSSFCell cell) {
        Object cellValue = getCellValue(cell, config.getType());
        config.setValue(cellValue);
    }

    /**
     * This method locates the header for the current sheet and index and returns the text.
     *
     * @param sheet HSSFSheet representing the current sheet.
     * @param index short representing the current column index.
     * @param mapping Mapping object containing configuration information.
     * @param rowNum
     * @return PropertyConfig - Object representing property information.
     */
    private PropertyConfig findPropertyByHeaderText(HSSFSheet sheet, short index, Mapping mapping, Integer rowNum) {
        Integer numHeaders = mapping.getNumHeaderRows();
        for (int i = 0; i < numHeaders.intValue(); i++) {
            HSSFRow row = sheet.getRow(i);
            HSSFCell cell = row.getCell(index);
            if (cell != null) {
                PropertyConfig config = mapping.getPropertyConfig((String) getCellValue(cell, String.class), rowNum);
                if (config != null) {
                    return config;
                }
            }
        }
        return null;
    }

    /**
     * This method returns the value of the specified cell in the specified type.
     *
     * @param cell HSSFCell object representing the current cell.
     * @param type Class representing the type to extract.
     * @return Object - Representing the extracted value.
     */
    private Object getCellValue(HSSFCell cell, Class type) {
        try {
            if (HSSFCell.CELL_TYPE_FORMULA == cell.getCellType()) {
                return getCellFormulaValue(cell, type);
            }
            if (type == Date.class) {
                return cell.getDateCellValue();
            }
            if (HSSFCell.CELL_TYPE_NUMERIC == cell.getCellType()) {
                return convertType(new Double(cell.getNumericCellValue()), type);
            }
            if (HSSFCell.CELL_TYPE_BOOLEAN == cell.getCellType()) {
                return convertType(new Boolean(cell.getBooleanCellValue()), type);
            }
            if (HSSFCell.CELL_TYPE_STRING == cell.getCellType() || HSSFCell.CELL_TYPE_FORMULA == cell.getCellType()) {
                return convertType(cell.getStringCellValue(), type);
            }
        } catch (Exception e) {
        }
        return null;
    }

    /**
     * This method is a workaround for formula cells.  It attempts to use the property type to determine the cell value
     * type.
     *
     * @param cell HSSFCell object representing the current cell.
     * @param type Class representing the type to extract.
     * @return Object - Representing the extracted value.
     */
    private Object getCellFormulaValue(HSSFCell cell, Class type) {
        if (type == Date.class) {
            return cell.getDateCellValue();
        }
        if (Number.class.isAssignableFrom(type)) {
            return convertType(new Double(cell.getNumericCellValue()), type);
        }
        if (type == Boolean.class || type == boolean.class) {
            return convertType(new Boolean(cell.getBooleanCellValue()), type);
        }
        return convertType(cell.getStringCellValue(), type);
    }

    /**
     * This method converts the value to the specified type.
     *
     * @param value Object representing the value.
     * @param type Class representing the type.
     * @return Object - Representing the new value.
     */
    private Object convertType(Object value, Class type) {
        if (value.getClass() == type) {
            return value;
        }
        if (type == String.class) {
            return String.valueOf(value);
        }
        if (value instanceof Number && (type == Integer.class || type == int.class)) {
            return new Integer(new Double(Math.round(((Double) value).doubleValue())).intValue());
        }
        if (value instanceof Number && (type == Long.class || type == long.class)) {
            return new Long(new Double(Math.round(((Double) value).doubleValue())).longValue());
        }
        if (value instanceof Number && (type == Short.class || type == short.class)) {
            return new Short(new Double(Math.round(((Double) value).doubleValue())).shortValue());
        }
        if (value instanceof Number && (type == Double.class || type == double.class)) {
            return value;
        }
        if (value instanceof Number && (type == Float.class || type == float.class)) {
            return new Float(new Double(((Double) value).doubleValue()).floatValue());
        }
        if (type == boolean.class) {
            return value;
        }
        return null;
    }
}
