package com.monsanto.wst.filetemplate.config;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 3, 2006
 * Time: 11:22:26 AM
 * <p/>
 * This class represents object property configuration information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PropertyConfig {
  private String name;
  private Class type;
  private boolean constant;
  private Integer row;
  private Object value;

  /**
   * This constructor takes the name and type of the property.
   *
   * @param name String representing the name of the property.
   * @param type Class representing the type of the property.
   * @param row
   * @param value
   * @param constant
   */
  public PropertyConfig(String name, Class type, Integer row, Object value, boolean constant) {
    this.row = row;
    this.value = value;
    this.name = name;
    this.type = type;
    this.constant = constant;
  }

  /**
   * This method returns the name of the property.
   *
   * @return String - Representing the name of the property.
   */
  public String getName() {
    return this.name;
  }

  /**
   * This method returns the type of the property.
   *
   * @return Class - Representing the type of the property.
   */
  public Class getType() {
    return this.type;
  }

  /**
   * This method returns the value for this property.
   *
   * @return Object - Representing the value.
   */
  public Object getValue() {
    return value;
  }

  /**
   * This method sets the value for this property.
   *
   * @param value Object representing the value.
   */
  public void setValue(Object value) {
    this.value = value;
  }

  public Integer getRow() {
    return row;
  }

  public boolean getConstant() {
    return constant;
  }
}
