package com.monsanto.wst.filetemplate.config;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 8:21:52 AM
 * <p/>
 * This interface defines the contract for retrieving mapping information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ConfigReader {
    /**
     * This method returns the class associated with the specified mapping id.
     *
     * @param mappingId String representing the id of the mapping.
     * @return Class - Representing the mapped object.
     */
    Mapping getMapping(String mappingId);
}
