package com.monsanto.wst.filetemplate.config;

import com.monsanto.wst.filetemplate.transform.ObjectProperties;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 3, 2006
 * Time: 7:23:16 AM
 * <p/>
 * This class represents a mapping for a file.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class Mapping {
    private Integer numHeaderRows;
    private Map propertyMap = new HashMap();
    private List filterList = new ArrayList();
    private Integer sheetIndex;
    private ObjectProperties objectProperties;

    /**
     * This constructor takes all configured options.
     *
     * @param objectProps
     */
    public Mapping(ObjectProperties objectProps) {
        this.numHeaderRows = new Integer(0);
        this.objectProperties = objectProps;
    }

    /**
     * This method returns the Class that is mapped to the current file.
     *
     * @return ObjectProperties - Representing the mapped class.
     */
    public ObjectProperties getMappedClassProperties() {
        return this.objectProperties;
    }

    /**
     * This method returns the number of header rows in the current file.
     *
     * @return Integer - Representing the number of header rows.
     */
    public Integer getNumHeaderRows() {
        return this.numHeaderRows;
    }

    /**
     * This method sets the number of header rows in the associated file.
     *
     * @param numHeaderRows Integer representing the number of header rows.
     */
    public void setNumHeaderRows(Integer numHeaderRows) {
        this.numHeaderRows = numHeaderRows;
    }

    /**
     * This method adds a property mapping to this mapping configuration.
     *
     * @param headerName String representing the header text to tie this property to.
     */
    public void addPropertyConfigMapping(String headerName, PropertyConfig propertyConfig) {
        String key = getKey(headerName, propertyConfig.getRow());
        this.propertyMap.put(key, propertyConfig);
        this.objectProperties.addPropertyConfig(propertyConfig);
    }

    private String getKey(String headerName, Integer row) {
        return new StringBuffer(headerName).append("-").append(row).toString();
    }

    /**
     * This method returns the property name associated with the specified header text.
     *
     * @param headerName String representing the header text.
     * @param row
     * @return PropertyConfig - Representing the property configuration information.
     */
    public PropertyConfig getPropertyConfig(String headerName, Integer row) {
        if (headerName != null) {
            String key = getKey(headerName, row);
            return (PropertyConfig) this.propertyMap.get(key);
        }
        return null;
    }

    /**
     * This method adds a property mapping to this mapping configuration.
     *
     * @param columnIndex Integer representing the column index.
     */
    public void addPropertyConfigMapping(Integer columnIndex, PropertyConfig propertyConfig) {
        String key = getKey(columnIndex.toString(), propertyConfig.getRow());
        this.propertyMap.put(key, propertyConfig);
        this.objectProperties.addPropertyConfig(propertyConfig);
    }

    /**
     * This method returns the property name associated with the specified column index.
     *
     * @param columnIndex Integer representing the column index.
     * @param row
     * @return PropertyConfig - Representing the property configuration information.
     */
    public PropertyConfig getPropertyConfig(Integer columnIndex, Integer row) {
        String key = getKey(columnIndex.toString(), row);
        return (PropertyConfig) this.propertyMap.get(key);
    }

    /**
     * This method adds a filter to the mapping information.
     *
     * @param filter Filter object representing a filter criteria.
     */
    public void addFilter(Filter filter) {
        this.filterList.add(filter);
    }

    /**
     * This method returns a boolean representing if the specified object should be filtered from the result.
     *
     * @param obj Object representing a row in the spreadsheet.
     * @return boolean - Representing if the object should be filtered.
     */
    public boolean filter(Object obj) {
        for (int i = 0; i < this.filterList.size(); i++) {
            Filter filter = (Filter) this.filterList.get(i);
            if (filter.shouldFilter(obj)) {
                return true;
            }
        }
        return false;
    }

    /**
     * This methods sets the sheet index.
     *
     * @param sheetIndex Integer representing the sheet index.
     */
    public void setSheetIndex(Integer sheetIndex) {
        this.sheetIndex = sheetIndex;
    }

    /**
     * This method returns the sheet index.
     *
     * @return Integer - Representing the sheet index.
     */
    public Integer getSheetIndex() {
        return sheetIndex;
    }
}
