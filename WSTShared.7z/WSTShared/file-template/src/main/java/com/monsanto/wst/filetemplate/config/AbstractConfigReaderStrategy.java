package com.monsanto.wst.filetemplate.config;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.filetemplate.config.xml.XMLConfigReader;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 4:12:09 PM
 * <p/>
 * This abstract class uses a strategy pattern for determining the correct implementation of the Mapping interface to
 * use.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractConfigReaderStrategy implements ConfigReader {
    /**
     * This method returns a new instance of the appropriate implementation of the Mapping interface.
     *
     * @param mappingPath String representing the path to the mapping configuration file.
     * @return Mapping - Object representing the file mappings.
     */
    public static ConfigReader newInstance(String mappingPath) {
        if (mappingPath != null && mappingPath.indexOf(".xml") > -1) {
            return new XMLConfigReader(mappingPath, new XMLUtilities(new ResourceUtils()), new XalanXPathUtils(),
                    new ObjectInspector());
        }
        throw new IllegalArgumentException("Invalid mapping file specified '" + mappingPath + "'.  " +
                    "Only XML is supported.");
    }
}
