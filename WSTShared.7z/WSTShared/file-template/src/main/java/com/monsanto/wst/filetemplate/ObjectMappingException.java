package com.monsanto.wst.filetemplate;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 11:34:14 AM
 * <p/>
 * This class is a custom exception for reporting problems when mapping an object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectMappingException extends RuntimeException {
  /**
   * This constructor takes an error message.
   *
   * @param message String representing the error message.
   */
  public ObjectMappingException(String message) {
    super(message);
  }

  public ObjectMappingException(String message, Throwable cause) {
    super(message, cause);
  }
}
