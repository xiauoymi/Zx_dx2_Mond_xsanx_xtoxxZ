package com.monsanto.wst.filetemplate.transform;

import com.monsanto.wst.filetemplate.config.Mapping;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 3:51:17 PM
 * <p/>
 * This interface defines the contract for parsing files into objects.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface FileParser {
    /**
     * This method returns a list of mapped objects for the specified file.
     *
     * @param file File representing the file to transform.
     * @param mapping Mapping object that contains configuration information about the file being parsed.
     * @return List - Of configured objects representing the data in the file.
     * @throws java.io.IOException - If unable to read file.
     */
    List importFile(File file, Mapping mapping) throws IOException;
}
