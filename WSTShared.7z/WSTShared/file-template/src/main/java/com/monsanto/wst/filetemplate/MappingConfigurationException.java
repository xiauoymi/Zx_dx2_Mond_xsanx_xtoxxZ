package com.monsanto.wst.filetemplate;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 7:55:57 AM
 * <p/>
 * This class defines a custom runtime exception for reporting that there was configuration error.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MappingConfigurationException extends RuntimeException {
    /**
     * This constructor takes an error message.
     *
     * @param message String representing the error message.
     */
    public MappingConfigurationException(String message) {
        super(message);
    }
}
