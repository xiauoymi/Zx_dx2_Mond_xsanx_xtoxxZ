package com.monsanto.wst.filetemplate;

import com.monsanto.wst.filetemplate.config.AbstractConfigReaderStrategy;
import com.monsanto.wst.filetemplate.config.ConfigReader;
import com.monsanto.wst.filetemplate.config.Mapping;
import com.monsanto.wst.filetemplate.transform.AbstractFileParserStrategy;
import com.monsanto.wst.filetemplate.transform.FileParser;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 2, 2006
 * Time: 3:57:46 PM
 * <p/>
 * This class is an external configuration file implementation of the FileTemplate interface.  It is used to transform
 * file data into objects.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ExternalConfigFileTemplate implements FileTemplate {
    private ConfigReader configReader;

    /**
     * This constructor takes the path to the external configuration file.
     *
     * @param mappingPath String representing the path to the config file.
     */
    public ExternalConfigFileTemplate(String mappingPath) {
        this.configReader = AbstractConfigReaderStrategy.newInstance(mappingPath);
    }

    /**
     * This method imports the specified file into a list of configured objects identified by the file id.
     *
     * @param fileId String representing the file id located in the configuration.
     * @param file File representing the file to import.
     * @return List - Of configured objects representing the file data.
     * @throws IOException - If unable to access the file.
     */
    public List importFile(String fileId, File file) throws IOException {
        FileParser parser = AbstractFileParserStrategy.newInstance(file);
        Mapping mapping = this.configReader.getMapping(fileId);
        return parser.importFile(file, mapping);
    }
}
