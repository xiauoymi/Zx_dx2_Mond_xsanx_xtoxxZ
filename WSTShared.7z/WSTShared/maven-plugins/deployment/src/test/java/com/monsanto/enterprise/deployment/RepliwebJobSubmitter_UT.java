/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import java.io.File;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.MalformedURLException;

import org.jmock.MockObjectTestCase;

/**
 * Filename:    $RCSfile: RepliwebJobSubmitter_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class RepliwebJobSubmitter_UT extends MockObjectTestCase {

  private void deleteDirectoryContents(File fileDir) {
    for (File file : fileDir.listFiles()){
      file.delete();
    }
  }

  //keep this around for sanity
  /*
  public void testSubmitRepliwebJobForReal() throws Exception {
     File fileDir = new File("\\\\w3-s01\\javaapps_dev_staging\\sqtwebsubmission\\logs\\watson");
    deleteDirectoryContents(fileDir);
    RepliwebJobSubmitter submitter = new RepliwebJobSubmitter();
    submitter.submitJob("srmacdo", "FEOO58MN3D7MK1PMU0T2FKKVK1", 247217);
    Thread.sleep(20000);
    assertTrue(fileDir.listFiles().length > 0);
  }
*/

  public void testSubmitRepliwebJob() throws Exception {
    MockRepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter(new MockURLConnection());
    submitter.submitJob("srmacdo", "FEOO58MN3D7MK1PMU0T2FKKVK1", 247217);
    final URL expectedUrl = new URL(
        "http://w3.repliweb.monsanto.com/R1WebUI/cgi-bin/command.cgi?center=localhost&user=srmacdo&spassword=FEOO58MN3D7MK1PMU0T2FKKVK1&command=demand_submit%20-noconfirm&jobid=247217");
    assertEquals(expectedUrl, submitter.url);
  }

  public void testSubmitWithNonSuccessResponseCode() throws Exception {
    RepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter(new MockURLConnection("", HttpURLConnection.HTTP_NOT_FOUND));
    try {
      submitter.submitJob("srmacdo", "FEOO58MN3D7MK1PMU0T2FKKVK1", 247217);
      fail("Should have thrown!");
    } catch (RepliwebJobException e){
    }
  }

  public void testSubmitWithErrorResponse() throws Exception {
    RepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter(new MockURLConnection("error!", HttpURLConnection.HTTP_OK));
    try {
      submitter.submitJob("srmacdo", "GEOO58MN3D7MK1PMU0T2FKKVK1", 247217);
      fail("Should have thrown!");
    } catch (RepliwebJobException e){
    }
  }


  private class MockURLConnection extends HttpURLConnection {
    private final String error;
    private final int responseCode;

    protected MockURLConnection() throws MalformedURLException {
      super(new URL("http://localhost"));
      this.error = "";
      this.responseCode = HttpURLConnection.HTTP_OK;
    }
    protected MockURLConnection(String error, int responseCode) throws MalformedURLException {
      super(new URL("http://localhost"));
      this.error = error;
      this.responseCode = responseCode;
    }

    public void disconnect() {
    }

    public boolean usingProxy() {
      return false;
    }

    public void connect() throws IOException {
    }

    public int getResponseCode() throws IOException {
      return responseCode;
    }

    public InputStream getInputStream() throws IOException {
      ByteArrayInputStream is = new ByteArrayInputStream(error.getBytes());
      return is;
    }
  }
  private class MockRepliwebJobSubmitter extends RepliwebJobSubmitter {
    public URL url;
    private HttpURLConnection connection;

    private MockRepliwebJobSubmitter(HttpURLConnection connection) {
      this.connection = connection;
    }

    protected HttpURLConnection createHttpConnection(URL url) throws IOException {
      this.url = url;
      return connection;
    }
  }
}