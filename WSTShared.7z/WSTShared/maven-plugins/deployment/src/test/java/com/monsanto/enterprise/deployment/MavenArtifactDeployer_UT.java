/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.model.Build;
import org.apache.maven.model.Model;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.project.MavenProject;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import com.monsanto.Util.FileUtil;

/**
 * Filename:    $RCSfile: MavenArtifactDeployer_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author SRMACDO
 * @version $Revision: 1.1 $
 */
public class MavenArtifactDeployer_UT extends MockObjectTestCase {
  public void testDeployOneOfEachTypeOfArtifactNoRepliwebWorkBecauseNoJobId() throws Exception {
    Deployable projectDeployable = createProjectDeployable(null);
    Deployable dependencyDeployable = createDependencyDeployable(null);
    final Deployable[] deployables = {projectDeployable, dependencyDeployable};

    MavenProject project = createTestProject();
    MockDeployableCopier copier = new MockDeployableCopier();
    MockRepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter();
    AbstractMojo mojo = new MockMavenArtifactDeployer(project, deployables, null, copier, submitter);
    mojo.execute();
    assertTrue(Arrays.equals(deployables, copier.deployables));
    assertEquals(project, copier.project);
    assertFalse(submitter.wasCalled);
  }

  public void testDeployOneOfEachTypeOfArtifactWithRepliwebWorkRepliwebSettingsUsed() throws Exception {
    Deployable projectDeployable = createProjectDeployable(new Integer(1));
    final Deployable[] deployables = {projectDeployable};

    MavenProject project = createTestProject();
    MockDeployableCopier copier = new MockDeployableCopier();
    MockRepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter();
    AbstractMojo mojo = new MockMavenArtifactDeployer(project, deployables, new RepliwebSettings("userId", "password"), copier, submitter);
    mojo.execute();
    assertTrue(Arrays.equals(deployables, copier.deployables));
    assertEquals(project, copier.project);
    assertTrue(submitter.wasCalled);
    assertEquals("userId", submitter.userId);
    assertEquals("password", submitter.password);
    assertEquals(1, submitter.jobId);
  }

  public void testDeployOneOfEachTypeOfArtifactWithRepliwebWorkRepliwebSettingsNotGivenUsesDefault() throws Exception {
    Deployable projectDeployable = createProjectDeployable(new Integer(1));
    final Deployable[] deployables = {projectDeployable};

    MavenProject project = createTestProject();
    MockDeployableCopier copier = new MockDeployableCopier();
    MockRepliwebJobSubmitter submitter = new MockRepliwebJobSubmitter();
    AbstractMojo mojo = new MockMavenArtifactDeployer(project, deployables, null, copier, submitter);
    mojo.execute();
    assertTrue(Arrays.equals(deployables, copier.deployables));
    assertEquals(project, copier.project);
    assertTrue(submitter.wasCalled);
    assertEquals("na1000tps-ci", submitter.userId);
    File passwordFile = new File("\\\\valine\\lsi\\TPSCI\\Public\\Repliweb\\repliwebPassword.txt");
    assertTrue(passwordFile.exists());
    assertEquals(FileUtil.readFileToString(passwordFile), submitter.password);
    assertEquals(1, submitter.jobId);
  }

  private Deployable createDependencyDeployable(final Integer repliwebJobId) {
    File dependencyArtifactDestination = new File("destination/me.jar");
    Deployable dependencyDeployable = new Deployable(dependencyArtifactDestination, "com.monsanto.other.plugins", "other-plugin", "jar", repliwebJobId);
    return dependencyDeployable;
  }

  private Deployable createProjectDeployable(final Integer repliwebJobId) {
    File projectArtifactDestination = new File("destination/projectArtifact.jar");
    Deployable projectDeployable = new Deployable(projectArtifactDestination, "com.monsanto.enterprise.plugins", "teamcity-plugin", "jar", repliwebJobId);
    return projectDeployable;
  }

  private MavenProject createTestProject() {
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    return project;
  }


  private void createDefaultBuild(Model model) {
    final Build build = new Build();
    build.setDirectory("source");
    build.setFinalName("teamcity-plugin-9.8.7-SNAPSHOT");
    model.setBuild(build);
  }

  private Model createDefaultModel() {
    final Model model = new Model();
    model.setGroupId("com.monsanto.enterprise.plugins");
    model.setArtifactId("teamcity-plugin");
    model.setPackaging("jar");
    model.setVersion("9.8.7-SNAPSHOT");
    return model;
  }

  private Artifact createArtifact(String groupId, String artifactId, String version, String type, File file) {
    Mock mockArtifact = mock(Artifact.class);
    mockArtifact.stubs().method("getGroupId").will(returnValue(groupId));
    mockArtifact.stubs().method("getArtifactId").will(returnValue(artifactId));
    mockArtifact.stubs().method("getType").will(returnValue(type));
    mockArtifact.stubs().method("getFile").will(returnValue(file));
    mockArtifact.stubs().method("getVersion").will(returnValue(version));
    return (Artifact) mockArtifact.proxy();
  }

  private class MockMavenArtifactDeployer extends MavenArtifactDeployer {
    private final MockDeployableCopier copier;
    private final MockRepliwebJobSubmitter submitter;

    private MockMavenArtifactDeployer(MavenProject project, Deployable[] deployables, RepliwebSettings repliwebSettings, MavenArtifactDeployer_UT.MockDeployableCopier copier,
                                      MavenArtifactDeployer_UT.MockRepliwebJobSubmitter submitter) {
      this.repliwebSettings = repliwebSettings;
      this.copier = copier;
      this.submitter = submitter;
      this.project = project;
      this.deployables = deployables;
    }

    protected DeployableCopier createDeployableCopier() {
      assertNotNull(super.createDeployableCopier());
      return copier;
    }

    protected RepliwebJobSubmitter createRepliwebJobSubmitter() {
      assertNotNull(super.createRepliwebJobSubmitter());
      return submitter;
    }
  }

  private class MockDeployableCopier extends DeployableCopier {
    private MavenProject project;
    private Deployable[] deployables;

    public MockDeployableCopier() {
      super(null);
    }

    public void copy(MavenProject project, Deployable[] deployables) throws IOException, NoArtifactFoundForDeployableException {
      this.project = project;
      this.deployables = deployables;
    }
  }

  private class MockRepliwebJobSubmitter extends RepliwebJobSubmitter{
    public String userId;
    public String password;
    public int jobId;
    public boolean wasCalled;

    public void submitJob(String userId, String password, int jobId)  {
      wasCalled = true;
      this.userId = userId;
      this.password = password;
      this.jobId = jobId;
    }
  }
}