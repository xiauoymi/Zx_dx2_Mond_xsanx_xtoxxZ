/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.model.Build;
import org.apache.maven.model.Model;
import org.apache.maven.plugin.logging.SystemStreamLog;
import org.apache.maven.project.MavenProject;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: DeployableCopier_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class DeployableCopier_UT extends MockObjectTestCase {

  public void testCopyOneArtifactOwnedByCallingProject() throws Exception {
    createTestFolder("source");
    createTestFolder("destination");
    File source = new File("source/teamcity-plugin-9.8.7-SNAPSHOT.jar");
    source.createNewFile();
    File dest = new File("destination/me.jar");
    assertFalse(dest.exists());
    Deployable deployable = new Deployable(dest, "com.monsanto.enterprise.plugins", "teamcity-plugin", "jar", null);
    DeployableCopier copier = new DeployableCopier(new SystemStreamLog());
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    copier.copy(project, new Deployable[]{deployable});
    assertTrue(dest.exists());
  }
  
  public void testDetectingThatArtifactIsProjectArtifactBecauseArtifactGroupAndTypeNotSet() throws Exception {
    createTestFolder("source");
    createTestFolder("destination");
    File source = new File("source/teamcity-plugin-9.8.7-SNAPSHOT.jar");
    source.createNewFile();
    File dest = new File("destination/me.jar");
    assertFalse(dest.exists());
    Deployable deployable = new Deployable(dest, null, null, null, null);
    DeployableCopier copier = new DeployableCopier(new SystemStreamLog());
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    copier.copy(project, new Deployable[]{deployable});
    assertTrue(dest.exists());
  }

  public void testCopyOneArtifactAsDependencyOfCallingProject() throws Exception {
    createTestFolder("source");
    createTestFolder("destination");
    File dependencyArtifactSource = new File("source/other-plugin-1.2.3.jar");
    dependencyArtifactSource.createNewFile();
    File dependencyArtifactDestination = new File("destination/me.jar");
    assertFalse(dependencyArtifactDestination.exists());
    Deployable dependencyDeployable = new Deployable(dependencyArtifactDestination, "com.monsanto.other.plugins", "other-plugin", "jar", null);
    DeployableCopier copier = new DeployableCopier(new SystemStreamLog());
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    Set<Artifact> artifactSet = new HashSet<Artifact>();
    final Artifact artifact = createArtifact("com.monsanto.other.plugins", "other-plugin", "1.2.3", "jar", dependencyArtifactSource);
    artifactSet.add(artifact);
    project.setArtifacts(artifactSet);
    copier.copy(project, new Deployable[]{dependencyDeployable});
    assertTrue(dependencyArtifactDestination.exists());
  }

  public void testCopyOneOfEachType() throws Exception {
    createTestFolder("source");
    createTestFolder("destination");
    File projectArtifactSource = new File("source/teamcity-plugin-9.8.7-SNAPSHOT.jar");
    projectArtifactSource.createNewFile();
    File projectArtifactDestination = new File("destination/projectArtifact.jar");
    assertFalse(projectArtifactDestination.exists());
    Deployable projectDeployable = new Deployable(projectArtifactDestination, "com.monsanto.enterprise.plugins", "teamcity-plugin", "jar", null);
    File dependencyArtifactSource = new File("source/other-plugin-1.2.3.jar");
    dependencyArtifactSource.createNewFile();
    File dependencyArtifactDestination = new File("destination/me.jar");
    assertFalse(dependencyArtifactDestination.exists());
    Deployable dependencyDeployable = new Deployable(dependencyArtifactDestination, "com.monsanto.other.plugins", "other-plugin", "jar", null);

    DeployableCopier copier = new DeployableCopier(new SystemStreamLog());
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    Set<Artifact> artifactSet = new HashSet<Artifact>();
    final Artifact artifact = createArtifact("com.monsanto.other.plugins", "other-plugin", "1.2.3", "jar", dependencyArtifactSource);
    artifactSet.add(artifact);
    project.setArtifacts(artifactSet);
    copier.copy(project, new Deployable[]{projectDeployable, dependencyDeployable});
    assertTrue(projectArtifactDestination.exists());
    assertTrue(dependencyArtifactDestination.exists());
  }

  public void testThrowsWhenMissing() throws Exception {
    createTestFolder("source");
    createTestFolder("destination");
    File projectArtifactSource = new File("source/teamcity-plugin-9.8.7-SNAPSHOT.jar");
    projectArtifactSource.createNewFile();
    File projectArtifactDestination = new File("destination/projectArtifact.jar");
    assertFalse(projectArtifactDestination.exists());
    Deployable projectDeployable = new Deployable(projectArtifactDestination, "com.monsanto.enterprise.plugins", "teamcity-plugin", "jar", null);
    File dependencyArtifactSource = new File("source/other-plugin-1.2.3.jar");
    dependencyArtifactSource.createNewFile();
    File dependencyArtifactDestination = new File("destination/me.jar");
    assertFalse(dependencyArtifactDestination.exists());
    Deployable dependencyDeployable = new Deployable(dependencyArtifactDestination, "com.monsanto.other.plugins", "other-pluginNOTFOUND", "jar", null);

    DeployableCopier copier = new DeployableCopier(new SystemStreamLog());
    final Model model = createDefaultModel();
    createDefaultBuild(model);
    MavenProject project = new MavenProject(model);
    Set<Artifact> artifactSet = new HashSet<Artifact>();
    final Artifact artifact = createArtifact("com.monsanto.other.plugins", "other-plugin", "1.2.3", "jar", dependencyArtifactSource);
    artifactSet.add(artifact);
    project.setArtifacts(artifactSet);
    try {
      copier.copy(project, new Deployable[]{projectDeployable, dependencyDeployable});
      fail("Should have thrown!");
    } catch (NoArtifactFoundForDeployableException ex) {
    }
    assertFalse(projectArtifactDestination.exists());
    assertFalse(dependencyArtifactDestination.exists());
  }

  private void createDefaultBuild(Model model) {
    final Build build = new Build();
    build.setDirectory("source");
    build.setFinalName("teamcity-plugin-9.8.7-SNAPSHOT");
    model.setBuild(build);
  }

  private Model createDefaultModel() {
    final Model model = new Model();
    model.setGroupId("com.monsanto.enterprise.plugins");
    model.setArtifactId("teamcity-plugin");
    model.setPackaging("jar");
    model.setVersion("9.8.7-SNAPSHOT");
    return model;
  }

  private void createTestFolder(final String pathname) {
    File destDir = new File(pathname);
    if (destDir.exists()) {
      final File[] files = destDir.listFiles();
      for (File file : files) {
        file.delete();
      }
      destDir.delete();
    }
    destDir.mkdir();
  }

  private Artifact createArtifact(String groupId, String artifactId, String version, String type, File file) {
    Mock mockArtifact = mock(Artifact.class);
    mockArtifact.stubs().method("getGroupId").will(returnValue(groupId));
    mockArtifact.stubs().method("getArtifactId").will(returnValue(artifactId));
    mockArtifact.stubs().method("getType").will(returnValue(type));
    mockArtifact.stubs().method("getFile").will(returnValue(file));
    mockArtifact.stubs().method("getVersion").will(returnValue(version));
    return (Artifact) mockArtifact.proxy();
  }
}