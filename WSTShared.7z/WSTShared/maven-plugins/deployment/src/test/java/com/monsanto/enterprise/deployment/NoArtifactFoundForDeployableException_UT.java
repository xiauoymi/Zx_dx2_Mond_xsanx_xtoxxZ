/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: NoArtifactFoundForDeployableException_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author SRMACDO
 * @version $Revision: 1.1 $
 */
public class NoArtifactFoundForDeployableException_UT extends TestCase {
  public void testConstruction() throws Exception {
    Deployable deployable = new Deployable(new File("hi"), "group", "artifact", "type", null);
    NoArtifactFoundForDeployableException ex = new NoArtifactFoundForDeployableException(deployable);
    StringBuilder sb = new StringBuilder("No matching artifact could be found for the following deployable:\n");
    sb.append("\tGroupId: group\n");
    sb.append("\tArtifactId: artifact\n");
    sb.append("\tType: type\n");
    assertEquals(sb.toString(), ex.getMessage());
  }
}