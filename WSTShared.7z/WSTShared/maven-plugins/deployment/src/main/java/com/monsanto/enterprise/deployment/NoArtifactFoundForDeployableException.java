/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

/**
 * Filename:    $RCSfile: NoArtifactFoundForDeployableException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author SRMACDO
 * @version $Revision: 1.1 $
 */
public class NoArtifactFoundForDeployableException extends Exception {
  public NoArtifactFoundForDeployableException(Deployable deployable) {
    super(constructMessage(deployable));
  }

  private static String constructMessage(Deployable deployable) {
    StringBuilder sb = new StringBuilder("No matching artifact could be found for the following deployable:\n");
    sb.append("\tGroupId: ");
    sb.append(deployable.getGroupId());
    sb.append("\n\tArtifactId: ");
    sb.append(deployable.getArtifactId());
    sb.append("\n\tType: ");
    sb.append(deployable.getType());
    sb.append("\n");
    return sb.toString();
  }
}