/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import org.apache.maven.project.MavenProject;

import java.io.File;

/**
 * Filename:    $RCSfile: InferedProjectArtifactLocationGenerator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class InferedProjectArtifactLocationGenerator implements ArtifactLocationGenerator {
  public File generateLocation(MavenProject project, Deployable deployable) {
    File location = null;
    if (isDeployableInferingProjectArtifact(deployable)) {
      deployable.setArtifactId(project.getArtifactId());
      deployable.setGroupId(project.getGroupId());
      Deployable inferedDeployable = new Deployable(deployable.getDestination(), project.getGroupId(), project.getArtifactId(), project.getPackaging(),
          deployable.getRepliwebJobId());
      ProjectArtifactLocationGenerator generator = new ProjectArtifactLocationGenerator();
      location = generator.generateLocation(project, inferedDeployable);
    }
    return location;
  }

  private boolean isDeployableInferingProjectArtifact(Deployable deployable) {
    return deployable.getGroupId() == null && deployable.getArtifactId() == null;
  }
}