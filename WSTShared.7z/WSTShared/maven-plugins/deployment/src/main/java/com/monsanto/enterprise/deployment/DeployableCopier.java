/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import org.apache.maven.project.MavenProject;
import org.apache.maven.plugin.logging.Log;
import org.codehaus.plexus.util.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DeployableCopier.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class DeployableCopier {
  private final Log log;

  public DeployableCopier(Log log) {
    this.log = log;
  }

  public void copy(MavenProject project, Deployable[] deployables) throws IOException, NoArtifactFoundForDeployableException {
    List<DeploymentInstruction> instructionList = GetDeploymentInstructions(project, deployables);

    CopyArtifacts(instructionList);
  }

  private void CopyArtifacts(List<DeploymentInstruction> instructionList) throws IOException {
    for (DeploymentInstruction instruction : instructionList) {
      log.info("Copying " + instruction.getSourceLocation() + " to " + instruction.getDestinationLocation().getAbsolutePath());
      FileUtils.copyFile(instruction.getSourceLocation(), instruction.getDestinationLocation());
    }
  }

  private List<DeploymentInstruction> GetDeploymentInstructions(MavenProject project, Deployable[] deployables) throws NoArtifactFoundForDeployableException {
    List<DeploymentInstruction> instructionList = new ArrayList<DeploymentInstruction>();
    for (Deployable deployable : deployables) {
      ArtifactLocationGenerator[] generators = createLocationGeneratorsInOrder();
      File sourceLocation = determineLocation(project, deployable, generators);
      instructionList.add(new DeploymentInstruction(deployable, sourceLocation));
    }
    return instructionList;
  }

  private class DeploymentInstruction {
    private final Deployable deployable;
    private final File sourceLocation;

    private DeploymentInstruction(Deployable deployable, File sourceLocation) {
      this.deployable = deployable;
      this.sourceLocation = sourceLocation;
    }

    public File getDestinationLocation() {
      return deployable.getDestination();
    }

    public File getSourceLocation() {
      return sourceLocation;
    }
  }

  private File determineLocation(MavenProject project, Deployable deployable, ArtifactLocationGenerator[] generators) throws NoArtifactFoundForDeployableException {
    File sourceLocation = null;
    for (ArtifactLocationGenerator generator : generators) {
      sourceLocation = generator.generateLocation(project, deployable);
      if (sourceLocation != null) {
        break;
      }
    }
    if (sourceLocation == null) {
      throw new NoArtifactFoundForDeployableException(deployable);
    }
    log.debug("Resolved " + deployable.getGroupId() + ":" + deployable.getArtifactId() + ":" + deployable.getType() + " to " + sourceLocation);
    return sourceLocation;
  }

  private ArtifactLocationGenerator[] createLocationGeneratorsInOrder() {
    return new ArtifactLocationGenerator[]{new InferedProjectArtifactLocationGenerator(), new ProjectArtifactLocationGenerator(), new DependencyArtifactLocationGenerator()};
  }
}