/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import com.monsanto.Util.FileUtil;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.project.MavenProject;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MavenArtifactDeployer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author SRMACDO
 * @version $Revision: 1.1 $
 * @goal deploy-artifacts
 * @requiresDependencyResolution compile
 */
public class MavenArtifactDeployer extends AbstractMojo {
  /**
   * @parameter
   */
  protected Deployable[] deployables;

  /**
   * @parameter
   */
  protected RepliwebSettings repliwebSettings;

  /**
   * @parameter expression="${project}"
   * @required
   * @readonly
   */
  protected MavenProject project;

  private final String repliwebPasswordFile = "\\\\valine\\lsi\\TPSCI\\Public\\Repliweb\\repliwebPassword.txt";
  private final String defaultRepliwebUser = "na1000tps-ci";

  public void execute() throws MojoExecutionException, MojoFailureException {
    if (deployables != null) {
      copyDeployables();
      runRepliwebJobs();
    } else {
      getLog().info("Skipping deployment for artifact because no deployable configuration exists in pom");
    }
  }

  private void runRepliwebJobs() throws MojoExecutionException {
    try {
      RepliwebJobSubmitter submitter = createRepliwebJobSubmitter();
      final RepliwebSettings actualRepliwebSettings = generateRepliwebSettings();
      for (Deployable deployable : deployables) {
        if (deployable.getRepliwebJobId() != null) {
          getLog().info(
            "Deploying " + deployable.getArtifactId() + " to repliweb with job id = " + deployable.getRepliwebJobId());
          submitter.submitJob(actualRepliwebSettings.getUserId(), actualRepliwebSettings.getPassword(),
            deployable.getRepliwebJobId());
        }
      }
    } catch (Exception e) {
      throw new MojoExecutionException("Failure on running repliweb jobs: ", e);
    }
  }

  private RepliwebSettings generateRepliwebSettings() throws IOException {
    if (repliwebSettings == null) {
      String password = readPasswordFile();
      repliwebSettings = new RepliwebSettings(defaultRepliwebUser, password);
    }
    return repliwebSettings;
  }

  private String readPasswordFile() throws IOException {
    File file = new File(repliwebPasswordFile);
    return FileUtil.readFileToString(file);
  }

  protected RepliwebJobSubmitter createRepliwebJobSubmitter() {
    return new RepliwebJobSubmitter();
  }

  private void copyDeployables() throws MojoExecutionException {
    DeployableCopier copier = createDeployableCopier();
    try {
      copier.copy(project, deployables);
    } catch (Exception e) {
      throw new MojoExecutionException("Failure on copying deployables: ", e);
    }
  }

  protected DeployableCopier createDeployableCopier() {
    return new DeployableCopier(getLog());
  }
}