/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import org.apache.maven.project.MavenProject;

import java.io.File;

/**
 * Filename:    $RCSfile: ProjectArtifactLocationGenerator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class ProjectArtifactLocationGenerator implements ArtifactLocationGenerator {
  public File generateLocation(MavenProject project, Deployable deployable) {
    File location = null;
    if (projectMatchesDeployable(project, deployable)) {
      syncrhonizeTypeIfNecessary(project, deployable);
      location = new File(project.getBuild().getDirectory(), project.getBuild().getFinalName() + "."
          + computeExtension(project));
    }
    return location;
  }

  private void syncrhonizeTypeIfNecessary(MavenProject project, Deployable deployable) {
    if (deployable.getType() == null) {
      deployable.setType(project.getPackaging());
    }
  }

  private boolean projectMatchesDeployable(MavenProject project, Deployable deployable) {
    return (project.getArtifactId().equals(deployable.getArtifactId())
                && project.getGroupId().equals(deployable.getGroupId())
                && (deployable.getType() == null || project.getPackaging().equals(deployable.getType()))
                );
  }

  private String computeExtension(MavenProject project) {
    String extension = project.getPackaging();
    if (extension.equalsIgnoreCase("ejb")) {
      extension = "jar";
    } else if (extension.equalsIgnoreCase("uberwar")) {
      extension = "war";
    }
    return extension;
  }
}