/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.deployment;

import java.io.File;

/**
 * Filename:    $RCSfile: Deployable.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:59 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class Deployable {
  private File destination;
  private String groupId;
  private String artifactId;
  private String type;
  private Integer repliwebJobId;
  
  public Deployable(){
  }

  public Deployable(File destination, String groupId, String artifactId, String type, Integer repliwebJobId) {
    this.destination = destination;
    this.groupId = groupId;
    this.artifactId = artifactId;
    this.type = type;
    this.repliwebJobId = repliwebJobId;
  }

  public File getDestination() {
    return destination;
  }

  public void setDestination(File destination) {
    this.destination = destination;
  }

  public String getGroupId() {
    return groupId;
  }

  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }

  public String getArtifactId() {
    return artifactId;
  }

  public void setArtifactId(String artifactId) {
    this.artifactId = artifactId;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Integer getRepliwebJobId() {
    return repliwebJobId;
  }

  public void setRepliwebJobId(Integer repliwebJobId) {
    this.repliwebJobId = repliwebJobId;
  }
}