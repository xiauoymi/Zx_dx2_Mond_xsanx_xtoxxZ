/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.dao;

import java.util.Date;

/**
 * Filename:    $RCSfile: TeamCityBuild.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:44 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class TeamCityBuild {
  private int buildId;
  private String agentId;
  private String buildTypeId;
  private String projectId;
  private Date serverStartTime;
  private Date agentStartTime;
  private Date serverFinishTime;
  private Integer status;
  private String statusText;
  private Integer pin;
  private Integer isPersonal;
  private Integer isCanceled;
  private String buildNumber;
  private String requestor;
  private Date queuedTime;
  private Date removedFromQueueTime;
  private String[] tags;

  public TeamCityBuild(int buildId, String agentId, String buildTypeId, String projectId, Date serverStartTime, Date agentStartTime, Date serverFinishTime, Integer status,
                       String statusText, Integer pin, Integer personal, Integer canceled, String buildNumber, String requestor, Date queuedTime, Date removedFromQueueTime,
                       String[] tags) {
    this.buildId = buildId;
    this.agentId = agentId;
    this.buildTypeId = buildTypeId;
    this.projectId = projectId;
    this.serverStartTime = serverStartTime;
    this.agentStartTime = agentStartTime;
    this.serverFinishTime = serverFinishTime;
    this.status = status;
    this.statusText = statusText;
    this.pin = pin;
    isPersonal = personal;
    isCanceled = canceled;
    this.buildNumber = buildNumber;
    this.requestor = requestor;
    this.queuedTime = queuedTime;
    this.removedFromQueueTime = removedFromQueueTime;
    this.tags = tags;
  }

  public int getBuildId() {
    return buildId;
  }

  public String getAgentId() {
    return agentId;
  }

  public String getBuildTypeId() {
    return buildTypeId;
  }

  public String getProjectId() {
    return projectId;
  }

  public Date getServerStartTime() {
    return serverStartTime;
  }

  public Date getAgentStartTime() {
    return agentStartTime;
  }

  public Date getServerFinishTime() {
    return serverFinishTime;
  }

  public Integer getStatus() {
    return status;
  }

  public String getStatusText() {
    return statusText;
  }

  public Integer getPin() {
    return pin;
  }

  public Integer getIsPersonal() {
    return isPersonal;
  }

  public Integer getIsCanceled() {
    return isCanceled;
  }

  public String getBuildNumber() {
    return buildNumber;
  }

  public String getRequestor() {
    return requestor;
  }

  public Date getQueuedTime() {
    return queuedTime;
  }

  public Date getRemovedFromQueueTime() {
    return removedFromQueueTime;
  }

  public String[] getTags() {
    return tags;
  }
}