/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import java.io.File;
import java.io.FilenameFilter;

/**
 * Filename:    $RCSfile: WarFileToDeleteFilter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author WSMCQU
 * @version $Revision: 1.1 $
 */
public class WarFileToDeleteFilter implements FilenameFilter {
   private String[] FILES_NEVER_TO_DELETE = new String[]{"cargocpc.war"};
   private static final String WAR_FILE_EXTENSION = ".war";

   public boolean accept(File dir, String name) {
      return !fileShouldNeverBeDeleted(name) && isNotDirectory(dir, name) && fileHasCorrectExtension(name);
   }

   private boolean fileShouldNeverBeDeleted(String name) {
      for (String fileNeverToDelete : FILES_NEVER_TO_DELETE) {
         if (name.equalsIgnoreCase(fileNeverToDelete)) {
            return true;
         }
      }
      return false;
   }

   private boolean isNotDirectory(File dir, String name) {
      return !new File(dir, name).isDirectory();
   }

   private boolean fileHasCorrectExtension(String name) {
      return name.endsWith(WAR_FILE_EXTENSION);
   }
}