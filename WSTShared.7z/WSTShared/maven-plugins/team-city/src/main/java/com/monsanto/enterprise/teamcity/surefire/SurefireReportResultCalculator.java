/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: SurefireReportResultCalculator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportResultCalculator {
  private final SurefireReportParserResult[] results;

  public SurefireReportResultCalculator(SurefireReportParserResult[] results) {
    this.results = results;
  }

  public long getTotalNumberOfTests() {
    long total = 0;
    for (SurefireReportParserResult result : results) {
      total += result.getTotalNumberOfTests();
    }
    return total;
  }

  public double getTotalTime() {
    double total = 0;
    for (SurefireReportParserResult result : results) {
      total += result.getNumberOfSeconds();
    }
    return total;
  }

  public long getTotalFailures() {
    long total = 0;
    for (SurefireReportParserResult result : results) {
      total += result.getTotalNumberOfFailures();
    }
    return total;
  }


  public long getTotalSuccesses() {
    long total = 0;
    for (SurefireReportParserResult result : results) {
      total += result.getNumberOfSuccesses();
    }
    return total;
  }

  public long getTotalSkipped() {
    long total = 0;
    for (SurefireReportParserResult result : results) {
      total += result.getNumberOfSkipped();
    }
    return total;
  }

  public SurefireReportResultCalculator createSubsetByTestSuiteType(TestSuiteType testSuiteType) {
    ArrayList<SurefireReportParserResult> retList = new ArrayList<SurefireReportParserResult>();
    for (int i = 0; i < results.length; i++) {
      if (testSuiteType.equals(results[i].getTestSuiteType())){
        retList.add(results[i]);
      }
    }
    return new SurefireReportResultCalculator(retList.toArray(new SurefireReportParserResult[retList.size()]));
  }

  public double getAverageTimePerTest() {
    return getTotalTime() / getTotalNumberOfTests();
  }
}