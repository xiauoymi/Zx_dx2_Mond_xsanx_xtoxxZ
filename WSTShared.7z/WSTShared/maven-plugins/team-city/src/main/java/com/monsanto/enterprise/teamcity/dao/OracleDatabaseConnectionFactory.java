/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.dao;

import org.springframework.beans.factory.FactoryBean;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Filename:    $RCSfile: OracleDatabaseConnectionFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:44 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class OracleDatabaseConnectionFactory implements FactoryBean {
  private static final String ORACLE_JDBC_DRIVER = "oracle.jdbc.OracleDriver";
  private boolean singleton;
  private String connectString;
  private String userName;
  private String password;
  
  public Object getObject() throws Exception {
    try {
      Class.forName(ORACLE_JDBC_DRIVER);
      Connection conn = DriverManager.getConnection(connectString, userName, password);
      conn.setAutoCommit(false);
      return conn;
    } catch (Exception e) {
      throw new DatabaseConnectionException(e);
    }
  }

  public Class getObjectType() {
    return java.sql.Connection.class;
  }

  public boolean isSingleton() {
    return singleton;
  }

  public void setSingleton(boolean singleton) {
    this.singleton = singleton;
  }

  public void setConnectString(String connectString) {
    this.connectString = connectString;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}