/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

/**
 * Filename:    $RCSfile: MavenExecutionGoal.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class MavenExecutionGoal extends MavenExecutionCommand {
  private String pluginGroupId;
  private String pluginArtifactId;
  private String pluginGoalName;

  public String generateMavenCommand() {
    return pluginGroupId + ":" + pluginArtifactId + ":" + pluginGoalName;
  }

  public String getPluginGroupId() {
    return pluginGroupId;
  }

  public void setPluginGroupId(String pluginGroupId) {
    this.pluginGroupId = pluginGroupId;
  }

  public String getPluginArtifactId() {
    return pluginArtifactId;
  }

  public void setPluginArtifactId(String pluginArtifactId) {
    this.pluginArtifactId = pluginArtifactId;
  }

  public String getPluginGoalName() {
    return pluginGoalName;
  }

  public void setPluginGoalName(String pluginGoalName) {
    this.pluginGoalName = pluginGoalName;
  }
}