/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Filename:    $RCSfile: CloverResultsPackager.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 * @goal package-clover-results
 * @aggregator
 */
public class CloverResultsPackager extends AbstractMojo {
  private static final String DEFAULT_SOURCE_FOLDER = ".\\target\\site\\clover";
  private static final String DEFAULT_COVERAGE_ZIP = ".\\clover-coverage.zip";

  public void execute() throws MojoExecutionException, MojoFailureException {
    try {
      ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(DEFAULT_COVERAGE_ZIP));
      zipDirectory(DEFAULT_SOURCE_FOLDER, zos, "");
      zos.close();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void zipDirectory(String dir2zip, ZipOutputStream zos, String relativePath) throws Exception {
    File sourceDirectory = new File(dir2zip);
    String[] directoryContents = sourceDirectory.list();
    byte[] readBuffer = new byte[2156];
    for (int i = 0; i < directoryContents.length; i++) {
      File file = new File(sourceDirectory, directoryContents[i]);
      if (file.isDirectory()) {
        addDirectoryToZip(zos, relativePath, file);
      } else {
        addFileToZip(zos, relativePath, readBuffer, file);
      }
    }
  }

  private void addFileToZip(ZipOutputStream zos, String relativePath, byte[] readBuffer, File file) throws IOException {
    int bytesIn = 0;
    FileInputStream fis = new FileInputStream(file);
    ZipEntry anEntry = new ZipEntry(constructFilePath(file, relativePath));
    zos.putNextEntry(anEntry);
    while ((bytesIn = fis.read(readBuffer)) != -1) {
      zos.write(readBuffer, 0, bytesIn);
    }
    fis.close();
  }

  private void addDirectoryToZip(ZipOutputStream zos, String relativePath, File file) throws Exception {
    String newDir = constructFilePath(file, relativePath) + "/";
    zos.putNextEntry(new ZipEntry(newDir));
    zipDirectory(file.getPath(), zos, newDir);
  }

  private String constructFilePath(File f, String relativePath) {
    String path = f.getName();
    if (relativePath.length() > 0) {
      path = relativePath + f.getName();
    }
    return path;
  }
}