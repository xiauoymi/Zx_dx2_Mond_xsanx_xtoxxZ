/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import com.monsanto.enterprise.teamcity.surefire.*;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;

import java.io.File;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: SurefireSummaryCreator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 * @goal create-surefire-summary
 * @aggregator
 */
public class SurefireSummaryCreator extends AbstractMojo {

  public void execute() throws MojoExecutionException, MojoFailureException {
    try {
      SurefireReportFileFinder finder = new SurefireReportFileFinder();
      final File[] files = finder.findFiles();
      SurefireReportParser parser = new SurefireReportParser();
      ArrayList<SurefireReportParserResult> results = new ArrayList<SurefireReportParserResult>();

      for (File file : files) {
        results.add(parser.parseFile(file.getPath()));
      }

      SurefireReportSummaryGenerator generator = new SurefireReportSummaryGenerator();
      generator.createSummary("test-summary.html", (SurefireReportParserResult[]) results.toArray(new SurefireReportParserResult[results.size()]));
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}