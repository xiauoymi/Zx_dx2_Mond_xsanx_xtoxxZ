package com.monsanto.enterprise.teamcity.surefire;

/**
 * Filename:    $RCSfile: TestSuiteType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public enum TestSuiteType {
  UnitTest,
  AcceptanceTest,
  PerformanceTest, Unknown
}
