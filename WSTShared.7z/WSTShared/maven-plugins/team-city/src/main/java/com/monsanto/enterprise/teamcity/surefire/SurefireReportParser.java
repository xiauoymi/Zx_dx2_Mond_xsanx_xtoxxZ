/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Filename:    $RCSfile: SurefireReportParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-02-06 21:29:15 $
 *
 * @author srmacdo
 * @version $Revision: 1.2 $
 */
public class SurefireReportParser {
  public SurefireReportParserResult parseFile(String file) throws ParserException {
    final Document document = DOMUtil.newDocument(file);
    final Element testSuiteNode = (Element) DOMUtil.getChild(document, "testsuite");
    final long numberOfErrors = Long.parseLong(DOMUtil.getAttribute(testSuiteNode, "errors"));
    final long numberOfSkipped = Long.parseLong(DOMUtil.getAttribute(testSuiteNode, "skipped"));
    final long numberOfTests = Long.parseLong(DOMUtil.getAttribute(testSuiteNode, "tests"));
    final long numberOfFailures = Long.parseLong(DOMUtil.getAttribute(testSuiteNode, "failures"));
    final double time = Double.parseDouble(DOMUtil.getAttribute(testSuiteNode, "time"));
    final String name = DOMUtil.getAttribute(testSuiteNode, "name");
    return new SurefireReportParserResult(numberOfErrors, numberOfFailures, numberOfTests - (numberOfErrors + numberOfFailures + numberOfSkipped), numberOfSkipped, time,
        parseTestSuiteType(name));
  }

  private TestSuiteType parseTestSuiteType(String name) {
    if (name.endsWith("AT")) {
      return TestSuiteType.AcceptanceTest;
    } else if (name.endsWith("UT")) {
      return TestSuiteType.UnitTest;
    } else if (name.endsWith("PT")) {
      return TestSuiteType.PerformanceTest;
    } else {
	return TestSuiteType.Unknown;
    }
  }
}