package com.monsanto.enterprise.teamcity.mojos;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;

/**
 * Sets System Property
 *
 * @goal build
 * @execute phase="install" lifecycle="teamcity"
 */

public class ProjectBuilder extends AbstractMojo {
   public void execute() throws MojoExecutionException {
   }
}