/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.ParserException;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.NumberFormat;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: SurefireReportSummaryGenerator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportSummaryGenerator {
  private final String TOTAL_SECONDS = "#TOTAL_SECONDS#";
  private final String AVG_TIME_PER_TEST = "#AVG_TIME_PER_TEST#";
  private final String TOTAL_NUMBER_OF_TESTS = "#TOTAL_NUMBER_OF_TESTS#";
  private final String NUMBER_OF_UTS = "#NUMBER_OF_UTS#";
  private final String NUMBER_OF_UT_FAILURES = "#NUMBER_OF_UT_FAILURES#";
  private final String NUMBER_OF_ATS = "#NUMBER_OF_ATS#";
  private final String NUMBER_OF_AT_FAILURES = "#NUMBER_OF_AT_FAILURES#";
  private final String NUMBER_OF_PTS = "#NUMBER_OF_PTS#";
  private final String NUMBER_OF_PT_FAILURES = "#NUMBER_OF_PT_FAILURES#";
  private final String NUMBER_OF_UNKNOWNS = "#NUMBER_OF_UNKNOWNS#";
  private final String NUMBER_OF_UNKNOWN_FAILURES = "#NUMBER_OF_UNKNOWN_FAILURES#";
  private final String TOTAL_SUCCEEDED = "#TOTAL_SUCCEEDED#";
  private final String TOTAL_FAILED = "#TOTAL_FAILED#";
  private final String TOTAL_IGNORED = "#TOTAL_IGNORED#";

  public void createSummary(String fileName, SurefireReportParserResult[] results) throws ParserException, IOException {
    SurefireReportResultCalculator calculator = new SurefireReportResultCalculator(results);
    SurefireReportResultCalculator acceptanceTestCalculator = calculator.createSubsetByTestSuiteType(TestSuiteType.AcceptanceTest);
    SurefireReportResultCalculator performanceTestCalculator = calculator.createSubsetByTestSuiteType(TestSuiteType.PerformanceTest);
    SurefireReportResultCalculator unitTestCalculator = calculator.createSubsetByTestSuiteType(TestSuiteType.UnitTest);
    SurefireReportResultCalculator unknownTestCalculator = calculator.createSubsetByTestSuiteType(TestSuiteType.Unknown);

    String html = createHtmlString(calculator, acceptanceTestCalculator, unitTestCalculator, performanceTestCalculator, unknownTestCalculator);
    writeHtml(fileName, html);
  }

  private void writeHtml(String fileName, String html) throws IOException {
    FileWriter writer = new FileWriter(fileName);
    writer.write(html);
    writer.flush();
    writer.close();
  }

  private String createHtmlString(SurefireReportResultCalculator calculator, SurefireReportResultCalculator acceptanceTestCalculator,
                                  SurefireReportResultCalculator unitTestCalculator, SurefireReportResultCalculator performanceTestCalculator,
                                  SurefireReportResultCalculator unknownTestCalculator
  ) throws IOException {
    final InputStream templateStream = FileUtil.getInputStream(this.getClass(), "summary-template.html");
    String template = FileUtil.readFileToString(templateStream);
    final NumberFormat formatter = NumberFormat.getInstance();
    formatter.setMaximumFractionDigits(2);
    template = template.replace(TOTAL_SECONDS, formatter.format(calculator.getTotalTime()));
    double avgTime = calculator.getTotalTime() / calculator.getTotalNumberOfTests();
    template = template.replace(AVG_TIME_PER_TEST, formatter.format(avgTime));
    template = template.replace(TOTAL_NUMBER_OF_TESTS, Long.toString(calculator.getTotalNumberOfTests()));
    template = template.replace(NUMBER_OF_UTS, Long.toString(unitTestCalculator.getTotalNumberOfTests()));
    template = template.replace(NUMBER_OF_UT_FAILURES, Long.toString(unitTestCalculator.getTotalFailures()));
    template = template.replace(NUMBER_OF_ATS, Long.toString(acceptanceTestCalculator.getTotalNumberOfTests()));
    template = template.replace(NUMBER_OF_AT_FAILURES, Long.toString(acceptanceTestCalculator.getTotalFailures()));
    template = template.replace(NUMBER_OF_PTS, Long.toString(performanceTestCalculator.getTotalNumberOfTests()));
    template = template.replace(NUMBER_OF_PT_FAILURES, Long.toString(performanceTestCalculator.getTotalFailures()));
    template = template.replace(NUMBER_OF_UNKNOWNS, Long.toString(unknownTestCalculator.getTotalNumberOfTests()));
    template = template.replace(NUMBER_OF_UNKNOWN_FAILURES, Long.toString(unknownTestCalculator.getTotalFailures()));
    template = template.replace(TOTAL_SUCCEEDED, Long.toString(calculator.getTotalSuccesses()));
    template = template.replace(TOTAL_FAILED, Long.toString(calculator.getTotalFailures()));
    template = template.replace(TOTAL_IGNORED, Long.toString(calculator.getTotalSkipped()));
    return template;
  }

  private ArrayList<SurefireReportParserResult> filterResults(SurefireReportParserResult[] results, TestSuiteType testSuiteType) {
    ArrayList<SurefireReportParserResult> retList = new ArrayList<SurefireReportParserResult>();
    for (int i = 0; i < results.length; i++) {
      if (testSuiteType.equals(results[i].getTestSuiteType())) {
        retList.add(results[i]);
      }
    }
    return retList;
  }
}