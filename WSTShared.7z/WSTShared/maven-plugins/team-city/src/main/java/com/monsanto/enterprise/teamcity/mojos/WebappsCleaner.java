/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;

import java.io.File;

import com.monsanto.enterprise.teamcity.buildprocess.WarFileToDeleteFilter;

/**
 * Filename:    $RCSfile: WebappsCleaner.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author WSMCQU
 * @version $Revision: 1.1 $
 * @goal cleanwebapps
 */
public class WebappsCleaner extends AbstractMojo {
   private static final String FOLDER_CONTAINING_WAR_FILES = "webapps";
   private static final String FOLDER_CONTAINING_LOG_FILES = "logs";

   public void execute() throws MojoExecutionException, MojoFailureException {
     deleteWarFiles();
     deleteLogFiles();
   }

  private void deleteLogFiles() throws MojoExecutionException {
    String logDirectoryPath = deriveLogDirectoryLocation();
    getLog().info("Deleting log files from " + logDirectoryPath);
    File logDirectory = new File(logDirectoryPath);
    for (File logFile : logDirectory.listFiles()) {
       if (logFile.delete()) {
          getLog().info("Deleted file: " + logFile.getAbsolutePath());
       } else {
          getLog().error("Error deleting file: " + logFile.getAbsolutePath());
       }
    }
  }

  private String deriveLogDirectoryLocation() throws MojoExecutionException {
    String catalinaHome = System.getenv("CATALINA_HOME");
      if (catalinaHome == null) {
         throw new MojoExecutionException(
            "Unable to determine Catalina Home.  Missing CATALINA_HOME environment variable");
      }
      return catalinaHome + File.separator + FOLDER_CONTAINING_LOG_FILES;
  }

  private void deleteWarFiles() throws MojoExecutionException {
    String catalinaHome = deriveWarFileLocation();
    getLog().info("Deleting WAR files from " + catalinaHome);
    File catalinaHomeDir = new File(catalinaHome);
    for (File fileInCatalinaHome : catalinaHomeDir.listFiles(new WarFileToDeleteFilter())) {
       if (fileInCatalinaHome.delete()) {
          getLog().info("Deleted file: " + fileInCatalinaHome.getAbsolutePath());
       } else {
          getLog().error("Error deleting file: " + fileInCatalinaHome.getAbsolutePath());
       }
    }
  }

  private String deriveWarFileLocation() throws MojoExecutionException {
      String catalinaHome = System.getenv("CATALINA_HOME");
      if (catalinaHome == null) {
         throw new MojoExecutionException(
            "Unable to determine Catalina Home.  Missing CATALINA_HOME environment variable");
      }
      return catalinaHome + File.separator + FOLDER_CONTAINING_WAR_FILES;
   }
}