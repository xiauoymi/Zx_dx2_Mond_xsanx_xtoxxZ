/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.dao;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: TeamCityBuildDBDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:44 $
 *
 * @author SRMACDO
 * @version $Revision: 1.1 $
 */
public class TeamCityBuildDBDAO implements TeamCityBuildDAO {
  private final Connection conn;

  public TeamCityBuildDBDAO(Connection conn) {
    this.conn = conn;
  }

  public String getLastBuildTag(String buildTypeId) throws SQLException {
    String sql = "select tag from tc_build_tags where build_id in (select max(build_id) from history where build_type_id = ?)";
    final PreparedStatement statement = conn.prepareStatement(sql);
    statement.setString(1, buildTypeId);
    final ResultSet resultSet = statement.executeQuery();
    String tag = null;
    if (resultSet.next()) {
      tag = resultSet.getString("tag");
    }
    return tag;
  }

  public void addBuildTag(int buildId, String tag) throws SQLException {
    PreparedStatement statement = conn.prepareStatement("insert into tc_build_tags (tag, build_id) values (?, ?)");
    statement.setString(1, tag);
    statement.setInt(2, buildId);
    statement.executeUpdate();
    statement.close();
  }

  public void removeTag(int buildId, String tag) throws SQLException {
    PreparedStatement statement = conn.prepareStatement("delete from tc_build_tags where tag = ? and build_id = ?");
    statement.setString(1, tag);
    statement.setInt(2, buildId);
    statement.executeUpdate();
    statement.close();
  }

  public void removeTag(int buildId) throws SQLException {
    PreparedStatement statement = conn.prepareStatement("delete from tc_build_tags where build_id = ?");
    statement.setInt(1, buildId);
    statement.executeUpdate();
    statement.close();
  }

  public TeamCityBuild getMostRecentBuild(String buildTypeId) throws SQLException {
    String sql = "select * from history where build_id = (select max(build_id) from history where build_type_id = ?)";
    final PreparedStatement statement = conn.prepareStatement(sql);
    statement.setString(1, buildTypeId);
    final ResultSet resultSet = statement.executeQuery();
    resultSet.next();
    final int buildId = resultSet.getInt("build_id");
    TeamCityBuild build = new TeamCityBuild(buildId, resultSet.getString("agent_name"), resultSet.getString("build_type_id"), resultSet.getString("project_id"),
        new Timestamp(resultSet.getLong("build_start_time_server")), new Timestamp(resultSet.getLong("build_start_time_agent")), new Timestamp(resultSet.getLong("build_finish_time_server")),
        new Integer(resultSet.getInt("status")), resultSet.getString("status_text"), new Integer(resultSet.getInt("pin")), new Integer(resultSet.getInt("is_personal")),
        new Integer(resultSet.getInt("is_canceled")), resultSet.getString("build_number"), resultSet.getString("requestor"), new Timestamp(resultSet.getLong("queued_time")),
        new Timestamp(resultSet.getLong("remove_from_queue_time")), getTags(buildId));

    resultSet.close();
    statement.close();
    return build;
  }

  public String[] getLastBuildTags(String buildTypeId) throws SQLException {
    String sql = "select tag from tc_build_tags where build_id in (select max(build_id) from history where build_type_id = ?)";
    final PreparedStatement statement = conn.prepareStatement(sql);
    statement.setString(1, buildTypeId);
    final ResultSet resultSet = statement.executeQuery();
    List<String> tags = new ArrayList<String>();
    while (resultSet.next()) {
      tags.add(resultSet.getString("tag"));
    }
    return tags.toArray(new String[tags.size()]);
  }

  private String[] getTags(int buildId) throws SQLException {
    final PreparedStatement statement = conn.prepareStatement("select tag from tc_build_tags where build_id = ?");
    statement.setInt(1, buildId);
    final ResultSet resultSet = statement.executeQuery();
    List<String> tags = new ArrayList<String>();
    while (resultSet.next()) {
      tags.add(resultSet.getString("tag"));
    }
    statement.close();
    resultSet.close();
    return tags.toArray(new String[tags.size()]);
  }
}