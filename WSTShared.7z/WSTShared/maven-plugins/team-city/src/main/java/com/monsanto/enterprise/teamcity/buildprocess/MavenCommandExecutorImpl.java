/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.shared.invoker.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MavenCommandExecutorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class MavenCommandExecutorImpl implements MavenCommandExecutor {
  private Invoker invoker;

  public void executeCommand(MavenExecutionCommand mavenExecutionCommand) throws MojoExecutionException {
    try {
      InvocationResult invocationResult = invoker.execute(generateInvocationRequest(mavenExecutionCommand));

      if (invocationResult.getExecutionException() != null) {
        throw new MojoExecutionException("Error executing Maven.", invocationResult.getExecutionException());
      }

      if (invocationResult.getExitCode() != 0) {
        throw new MojoExecutionException("Maven execution failed, exit code: \'"
          + invocationResult.getExitCode() + "\'");
      }
    } catch (MavenInvocationException e) {
      throw new MojoExecutionException("Fatal Error", e);
    }
  }

  private InvocationRequest generateInvocationRequest(MavenExecutionCommand mavenExecutionCommand) {
    InvocationRequest invocationRequest = new DefaultInvocationRequest();
    List<String> goals = new ArrayList<String>();
    goals.add(mavenExecutionCommand.generateMavenCommand());
    invocationRequest.setGoals(goals);

    if (mavenExecutionCommand.getMavenOptions() != null) {
      invocationRequest.setMavenOpts(mavenExecutionCommand.getMavenOptions());
    }
    invocationRequest.setRecursive(mavenExecutionCommand.isRecursive());
    invocationRequest.setInteractive(mavenExecutionCommand.isInteractive());
    return invocationRequest;
  }

  public Invoker getInvoker() {
    return invoker;
  }

  public void setInvoker(Invoker invoker) {
    this.invoker = invoker;
  }
}