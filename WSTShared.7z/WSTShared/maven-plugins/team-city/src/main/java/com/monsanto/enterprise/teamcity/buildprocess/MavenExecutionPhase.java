/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

/**
 * Filename:    $RCSfile: MavenExecutionPhase.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class MavenExecutionPhase extends MavenExecutionCommand {
  private String phaseName;

  public String generateMavenCommand() {
    return phaseName;
  }

  public String getPhaseName() {
    return phaseName;
  }

  public void setPhaseName(String phaseName) {
    this.phaseName = phaseName;
  }
}