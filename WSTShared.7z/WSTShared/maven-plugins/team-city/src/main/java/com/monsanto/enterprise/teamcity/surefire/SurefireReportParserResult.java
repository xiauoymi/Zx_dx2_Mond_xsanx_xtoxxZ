/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

/**
 * Filename:    $RCSfile: SurefireReportParserResult.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportParserResult {
  private long numberOfErrors;
  private long numberOfFailures;
  private long numberOfSuccesses;
  private long numberOfSkipped;
  private double numberOfSeconds;
  private TestSuiteType testSuiteType;

  public SurefireReportParserResult(long numberOfErrors, long numberOfFailures, long numberOfSuccesses, long numberOfSkipped, double numberOfSeconds,
                                    TestSuiteType testSuiteType) {
    this.numberOfErrors = numberOfErrors;
    this.numberOfFailures = numberOfFailures;
    this.numberOfSuccesses = numberOfSuccesses;
    this.numberOfSkipped = numberOfSkipped;
    this.numberOfSeconds = numberOfSeconds;
    this.testSuiteType = testSuiteType;
  }

  public long getTotalNumberOfTests() {
    return getNumberOfErrors() + getNumberOfFailures() + getNumberOfSuccesses() + getNumberOfSkipped();
  }

  public long getNumberOfErrors() {
    return numberOfErrors;
  }

  public long getNumberOfFailures() {
    return numberOfFailures;
  }

  public long getNumberOfSuccesses() {
    return numberOfSuccesses;
  }

  public long getNumberOfSkipped() {
    return numberOfSkipped;
  }

  public long getTotalNumberOfFailures() {
    return getNumberOfErrors() + getNumberOfFailures();
  }

  public double getNumberOfSeconds() {
    return numberOfSeconds;
  }

  public TestSuiteType getTestSuiteType() {
    return testSuiteType;
  }
}