/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import com.monsanto.enterprise.teamcity.dao.TeamCityBuildDAO;
import com.monsanto.enterprise.teamcity.dao.TeamCityBuildDBDAO;
import org.apache.maven.plugin.logging.Log;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * Filename:    $RCSfile: TagDrivenCommandListFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class TagDrivenCommandListFactory implements FactoryBean, ApplicationContextAware {
  private static final String BUILD_TYPE_ID_PROPERTY_NAME = "teamcity.buildType.id";
  private Connection teamCityConnection;
  private ApplicationContext ctx;
  private Log log;

  public Object getObject() throws Exception {
    try {
      BuildType buildType = getLastBuildTag(teamCityConnection);
      log.info("Running commands for a " + buildType.toString() + " build");
      return ctx.getBean(buildType.getTagListBeanName());
    }
    finally {
      closeConnection(teamCityConnection);
    }
  }

  public Class getObjectType() {
    return List.class;
  }

  public boolean isSingleton() {
    return false;
  }

  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    ctx = applicationContext;
  }

  public void setTeamCityConnection(Connection teamCityConnection) {
    this.teamCityConnection = teamCityConnection;
  }

  public void setLog(Log log) {
    this.log = log;
  }

  private BuildType getLastBuildTag(Connection connection) throws SQLException {
    TeamCityBuildDAO teamCityBuildDAO = new TeamCityBuildDBDAO(connection);
    String buildTypeId = System.getProperty(BUILD_TYPE_ID_PROPERTY_NAME);
    log.info("Getting build latest tag for buildTypeId = " + buildTypeId);
    String buildTag = teamCityBuildDAO.getLastBuildTag(buildTypeId);
    return determineBuildType(buildTag);
  }

  private BuildType determineBuildType(String buildTag) {
    BuildType buildType = BuildType.valueOf("DEFAULT");
    for (BuildType bt : BuildType.values()) {
      if (bt.toString().equalsIgnoreCase(buildTag)) {
        log.info("Latest build tagged: \"" + buildTag + "\"");
        buildType = BuildType.valueOf(buildTag.toUpperCase());
        break;
      }
    }
    return buildType;
  }

  private void closeConnection(Connection connection) {
    if (connection != null) {
      try {
        connection.close();
      } catch (Exception IGNORED) {
        // eat it
      }
    }
  }
}