/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import com.monsanto.enterprise.teamcity.buildprocess.MavenExecutionCommand;
import com.monsanto.enterprise.teamcity.buildprocess.MultipleCommandExecutionStrategy;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.logging.Log;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * Sets System Property
 *
 * @goal complete-build
 * @aggregator
 */
public class DefaultProjectBuilder extends AbstractMojo {
  private Log mavenLogger = getLog();

  @SuppressWarnings({"unchecked"})
  public void execute() throws MojoExecutionException {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/build-process-context.xml");
    MultipleCommandExecutionStrategy executionStrategy = (MultipleCommandExecutionStrategy) context
      .getBean("stopIfFailureStrategy");
    List<MavenExecutionCommand> executionCommands = (List<MavenExecutionCommand>) context
      .getBean("tagDrivenCommandList");
    logExecutionCommands(executionCommands);
    executionStrategy.invokeMavenCommands(executionCommands);
  }

  private void logExecutionCommands(List<MavenExecutionCommand> executionCommands) {
    StringBuilder builder = new StringBuilder(128);
    builder.append("Executing the following Maven commands:");
    for (MavenExecutionCommand executionCommand : executionCommands) {
      builder.append("\n     ").append(executionCommand.toString());
    }
    mavenLogger.info(builder.toString());
  }
}