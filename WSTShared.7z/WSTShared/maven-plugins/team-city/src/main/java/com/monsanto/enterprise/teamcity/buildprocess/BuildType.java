package com.monsanto.enterprise.teamcity.buildprocess;

/**
 * Filename:    $RCSfile: BuildType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public enum BuildType {
  DEFAULT("defaultCommandList"),
  DEPLOY("deployArtifactsCommandList"),
  RELEASE("releaseCommandList");

  BuildType(String tagListBeanName) {
    this.tagListBeanName = tagListBeanName;
  }

  private final String tagListBeanName;

  public String getTagListBeanName() {
    return tagListBeanName;
  }

  public String toString(){
    return name().toLowerCase();
  }
}
