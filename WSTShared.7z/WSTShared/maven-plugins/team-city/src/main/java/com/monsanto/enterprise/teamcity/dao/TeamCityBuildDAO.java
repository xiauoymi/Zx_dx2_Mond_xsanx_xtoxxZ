/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.dao;

import java.sql.SQLException;

/**
 * Filename:    $RCSfile: TeamCityBuildDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:44 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public interface TeamCityBuildDAO {
  String getLastBuildTag(String buildTypeId) throws SQLException;

  void addBuildTag(int buildId, String tag) throws SQLException;

  void removeTag(int buildId, String tag) throws SQLException;

  void removeTag(int buildId) throws SQLException;

  TeamCityBuild getMostRecentBuild(String buildTypeId) throws SQLException;

  String[] getLastBuildTags(String buildTypeId) throws SQLException;
}