/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import com.monsanto.Util.FileUtil;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SurefireReportFileFinder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportFileFinder_UT extends TestCase {

  protected void tearDown() throws Exception {
    super.tearDown();
    deleteDirectory("target/clover/surefire-reports");
    deleteDirectory("target/clover");
    deleteDirectory("target");
    deleteDirectory("module1/surefire-reports");
    deleteDirectory("module1");
    deleteDirectory("module2");
  }

  private void deleteDirectory(String dirPath) {

    File directory = new File(dirPath);
    if (directory.exists()) {
      final File[] files = FileUtil.findFiles(new File(dirPath));

      for (File file : files) {
        if (file != null) {
        file.delete();
        }
      }
      directory.delete();
    }
  }

  public void testFindFiles() throws Exception {
    createFiles();
    SurefireReportFileFinder finder = new SurefireReportFileFinder();
    File[] files = finder.findFiles();

    assertEquals(8, files.length);
    assertTrue(hasFileName(files, "TEST-blah.boo.bang_AT.xml"));
    assertTrue(hasFileName(files, "TEST-blah.boo.bang2_UT.xml"));
    assertTrue(hasFileName(files, "TEST-blah.boo.bang3.xml"));
    assertTrue(hasFileName(files, "TEST-blah.boo.bang4.xml"));
    assertTrue(hasFileName(files, "TEST-blah.boo.bang5.xml"));
    assertTrue(hasFileName(files, "TEST-com.monsanto.lsi.phenex.cloning.importing.acceptancetest.ComplexPrimerImport_AT.xml"));
    assertTrue(hasFileName(files, "TEST-com.monsanto.lsi.phenex.cloning.fasta.writer.test.NominationFastaWriter_UT.xml"));
    assertTrue(hasFileName(files, "TEST-com.monsanto.lsi.phenex.cloning.fasta.writer.test.NominationFastaWriter_PT.xml"));
  }

  private boolean hasFileName(File[] files, String fileName) {
    for (int i = 0; i < files.length; i++) {
      if (fileName.equals(files[i].getName())) {
        return true;
      }
    }
    return false;
  }

  private void createFiles() throws IOException {
    createTestDir("target/clover/surefire-reports");
    createTestDir("module1/surefire-reports");
    createTestDir("module2");

    createTestFile("target/clover/surefire-reports/TEST-blah.boo.bang_AT.xml");
    createTestFile("target/clover/surefire-reports/TEST-blah.boo.bang2_UT.xml");
    createTestFile("target/clover/surefire-reports/TEST-blah.boo.bang3.xml");
    createTestFile("target/clover/surefire-reports/TEST-blah.boo.bang3xml");
    createTestFile("target/clover/surefire-reports/TEST-blah.boo.bang_AT.txt");
    createTestFile("target/clover/surefire-reports/blah.boo.bang_AT.xml");
    createTestFile("target/clover/surefire-reports/TESTblah.boo.bang_AT.xml");

    createTestFile("module1/surefire-reports/TEST-blah.boo.bang4.xml");
    createTestFile("module2/TEST-blah.boo.bang5.xml");

  }

  private void createTestDir(String dirPath) {
    File dir1 = new File(dirPath);
    if (dir1.exists()) {
      dir1.delete();
    }
    dir1.mkdirs();
  }

  private void createTestFile(String path) throws IOException {
    FileWriter writer = new FileWriter(path);
    writer.write("hi");
    writer.flush();
    writer.close();
  }
}