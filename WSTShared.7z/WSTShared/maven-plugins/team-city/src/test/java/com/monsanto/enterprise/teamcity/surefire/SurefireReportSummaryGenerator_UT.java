/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import java.util.ArrayList;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: SurefireReportSummaryGenerator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportSummaryGenerator_UT extends XMLTestCase {
  private static final String EXPECTED_SUMMARY_HTML = "com/monsanto/enterprise/teamcity/surefire/expected-summary.html";

  public void testCreateSummary() throws Exception {
    SurefireReportSummaryGenerator generator = new SurefireReportSummaryGenerator();
    ArrayList<SurefireReportParserResult> results = new ArrayList<SurefireReportParserResult>();
    results.add(new SurefireReportParserResult(1, 2, 3, 4, 15.1, TestSuiteType.UnitTest)); //10
    results.add(new SurefireReportParserResult(4, 3, 2, 1, 1.2, TestSuiteType.Unknown));
    results.add(new SurefireReportParserResult(5, 6, 7, 8, 2.3, TestSuiteType.UnitTest)); //26
    results.add(new SurefireReportParserResult(8, 7, 6, 5, 3.4, TestSuiteType.AcceptanceTest));
    results.add(new SurefireReportParserResult(9, 10, 11, 12, 4.5, TestSuiteType.AcceptanceTest)); //42
    results.add(new SurefireReportParserResult(12, 11, 10, 9, 6.7, TestSuiteType.UnitTest));
    results.add(new SurefireReportParserResult(20, 19, 18, 17, 10.1, TestSuiteType.PerformanceTest));
    generator.createSummary("summary.html", (SurefireReportParserResult[]) results.toArray(new SurefireReportParserResult[results.size()]));
    final Document expected = DOMUtil.newDocument(EXPECTED_SUMMARY_HTML);
    final Document actual = DOMUtil.newDocument("summary.html");
    assertXMLEqual(expected, actual);
  }
}