/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import junit.framework.TestCase;
import org.apache.maven.shared.invoker.*;
import org.codehaus.plexus.util.cli.CommandLineException;

/**
 * Filename:    $RCSfile: MavenCommandExecutorImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class MavenCommandExecutorImpl_UT extends TestCase {
  public void testExceptionThrownByCommandIsThrownByExecutor() throws Exception {
    Invoker invoker = new MockDefaultInvoker(new MavenInvocationException("Some Exception"), null);

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionGoal command = new MavenExecutionGoal();
    command.setPluginGroupId("com.monsanto.enterprise");
    command.setPluginArtifactId("teamcity-plugin");
    command.setPluginGoalName("do-something");
    try {
      mavenCommandExecutor.executeCommand(command);
      fail("Should have thrown exception");
    } catch (Exception e) {
      // Expected
    }
  }

  public void testExceptionThrownIfExecutorReturnsNonZeroExitCode() throws Exception {
    Invoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 1));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionGoal command = new MavenExecutionGoal();
    command.setPluginGroupId("com.monsanto.enterprise");
    command.setPluginArtifactId("teamcity-plugin");
    command.setPluginGoalName("do-something");
    try {
      mavenCommandExecutor.executeCommand(command);
      fail("Should have thrown exception");
    } catch (Exception e) {
      assertTrue(e.toString().indexOf("Maven execution failed") > 0);
    }
  }

  public void testExceptionThrownIfInvocurGeneratesCommandLineException() throws Exception {
    Invoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(new CommandLineException("something"), 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionGoal command = new MavenExecutionGoal();
    command.setPluginGroupId("com.monsanto.enterprise");
    command.setPluginArtifactId("teamcity-plugin");
    command.setPluginGoalName("do-something");
    try {
      mavenCommandExecutor.executeCommand(command);
      fail("Should have thrown exception");
    } catch (Exception e) {
      assertTrue(e.toString().indexOf("Error executing Maven") > 0);
    }
  }

  public void testGoalInvokedEqualsCommandExpected() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionGoal command = new MavenExecutionGoal();
    command.setPluginGroupId("com.monsanto.enterprise");
    command.setPluginArtifactId("teamcity-plugin");
    command.setPluginGoalName("do-something");
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals("com.monsanto.enterprise:teamcity-plugin:do-something", invocationRequest.getGoals().get(0));
  }

  public void testPhaseInvokedEqualsCommandExpected() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals("install", invocationRequest.getGoals().get(0));
  }

  public void testMavenOptsPassedToInvoker() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    command.setMavenOptions("-DskipTests=true");
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals("-DskipTests=true", invocationRequest.getMavenOpts());
  }

  public void testRecursiveOptionPassedToInvoker() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    command.setRecursive(false);
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals(false, invocationRequest.isRecursive());
  }

  public void testRecursiveOptionDefaultsToTrue() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals(true, invocationRequest.isRecursive());
  }

  public void testInteractiveOptionPassedToInvoker() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    command.setInteractive(false);
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals(false, invocationRequest.isInteractive());
  }

  public void testInteractiveOptionDefaultsToTrue() throws Exception {
    MockDefaultInvoker invoker = new MockDefaultInvoker(null, new MockInvocationResult(null, 0));

    MavenCommandExecutorImpl mavenCommandExecutor = new MavenCommandExecutorImpl();
    mavenCommandExecutor.setInvoker(invoker);

    MavenExecutionPhase command = new MavenExecutionPhase();
    command.setPhaseName("install");
    mavenCommandExecutor.executeCommand(command);

    InvocationRequest invocationRequest = invoker.getInvocationRequest();
    assertEquals(true, invocationRequest.isInteractive());
  }


  private class MockDefaultInvoker extends DefaultInvoker {
    private MavenInvocationException mavenInvocationException;
    private InvocationResult invocationResult;
    private InvocationRequest invocationRequest;

    private MockDefaultInvoker(MavenInvocationException mavenInvocationException, InvocationResult invocationResult) {
      this.mavenInvocationException = mavenInvocationException;
      this.invocationResult = invocationResult;
    }

    public InvocationResult execute(InvocationRequest request) throws MavenInvocationException {
      this.invocationRequest = request;
      if (mavenInvocationException != null) {
        throw mavenInvocationException;
      } else {
        return invocationResult;
      }
    }

    public InvocationRequest getInvocationRequest() {
      return invocationRequest;
    }
  }

  private class MockInvocationResult implements InvocationResult {
    private CommandLineException commandLineException;
    private int exitCode;

    private MockInvocationResult(CommandLineException commandLineException, int exitCode) {
      this.commandLineException = commandLineException;
      this.exitCode = exitCode;
    }

    public CommandLineException getExecutionException() {
      return commandLineException;
    }

    public int getExitCode() {
      return exitCode;
    }
  }
}