/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.zip.ZipFile;

/**
 * Filename:    $RCSfile: CloverResultsPackager_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class CloverResultsPackager_UT extends AbstractMojoTestCase {
  protected void setUp() throws Exception {

      // required for mojo lookups to work
      super.setUp();
   }

  public void testPackageUpDirectory() throws Exception {
    createFiles();

    CloverResultsPackager packager = new CloverResultsPackager();
    packager.execute();
    File resultFile = new File("clover-coverage.zip");
    assertTrue(resultFile.exists());

    ZipFile file = new ZipFile("clover-coverage.zip");
    assertNotNull(file.getEntry("index.html"));
    assertNotNull(file.getEntry("subdir/"));
    assertNotNull(file.getEntry("subdir/sub.html"));
    assertNotNull(file.getEntry("subdir/subdir2/"));
    assertNotNull(file.getEntry("subdir/subdir2/sub2.html"));

  }

  public void testPackageUpDirectoryRemovingOldZipFile() throws Exception {
    File resultFile = new File("clover-coverage.zip");
    if (resultFile.exists()){
      resultFile.delete();
    }
    createTestFile("clover-coverage.zip");

    CloverResultsPackager packager = new CloverResultsPackager();
    packager.execute();
    assertTrue(resultFile.exists());

    ZipFile file = new ZipFile("clover-coverage.zip");
    assertNotNull(file.getEntry("index.html"));
    assertNotNull(file.getEntry("subdir/"));
    assertNotNull(file.getEntry("subdir/sub.html"));
    assertNotNull(file.getEntry("subdir/subdir2/"));
    assertNotNull(file.getEntry("subdir/subdir2/sub2.html"));
  }
  private void createFiles() throws IOException {
    File subDir = new File("target/site/clover/subdir/subdir2");
    if (subDir.exists())
    {
      subDir.delete();
    }
    subDir.mkdirs();
    createTestFile("target/site/clover/index.html");
    createTestFile("target/site/clover/subdir/sub.html");
    createTestFile("target/site/clover/subdir/subdir2/sub2.html");
  }

  private void createTestFile(String path) throws IOException {
    FileWriter writer = new FileWriter(path);
    writer.write("hi");
    writer.flush();
    writer.close();
  }
}