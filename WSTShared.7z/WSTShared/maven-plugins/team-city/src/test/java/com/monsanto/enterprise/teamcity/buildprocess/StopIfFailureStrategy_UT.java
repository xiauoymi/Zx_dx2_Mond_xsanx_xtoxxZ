/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import junit.framework.TestCase;
import org.apache.maven.plugin.MojoExecutionException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: StopIfFailureStrategy_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class StopIfFailureStrategy_UT extends TestCase {
  public void testExecutionStoppedIfOneCommandFails() throws Exception {
    List<MavenExecutionCommand> commands = new ArrayList<MavenExecutionCommand>(4);
    commands.add(new MavenExecutionGoal());
    commands.add(new MavenExecutionPhase());
    commands.add(new MavenExecutionGoal());
    MockMavenCommandExecutor mockMavenCommandExecutor = new MockMavenCommandExecutor();
    mockMavenCommandExecutor.setThrowExceptionAtLoopNumber(2);
    StopIfFailureStrategy executionStrategy = new StopIfFailureStrategy();
    executionStrategy.setMavenCommandExecutor(mockMavenCommandExecutor);
    try {
      executionStrategy.invokeMavenCommands(commands);
      fail("Should have thrown exception");
    } catch (MojoExecutionException e) {
      assertEquals(2, mockMavenCommandExecutor.getLoopCount());
    }
  }

  public void testExecutionContinuesIfNoExceptionThrown() throws Exception {
    List<MavenExecutionCommand> commands = new ArrayList<MavenExecutionCommand>(4);
    commands.add(new MavenExecutionGoal());
    commands.add(new MavenExecutionPhase());
    commands.add(new MavenExecutionGoal());
    MockMavenCommandExecutor mockMavenCommandExecutor = new MockMavenCommandExecutor();
    StopIfFailureStrategy executionStrategy = new StopIfFailureStrategy();
    executionStrategy.setMavenCommandExecutor(mockMavenCommandExecutor);
    executionStrategy.invokeMavenCommands(commands);
    assertEquals(3, mockMavenCommandExecutor.getLoopCount());
  }

  private class MockMavenCommandExecutor implements MavenCommandExecutor {
    private int loopCount = 0;
    private int throwExceptionAtLoopNumber = -1;

    public void executeCommand(MavenExecutionCommand mavenExecutionCommand) throws MojoExecutionException {
      if (++loopCount == throwExceptionAtLoopNumber) {
        throw new MojoExecutionException("some exception");
      }
    }

    public int getLoopCount() {
      return loopCount;
    }

    public void setThrowExceptionAtLoopNumber(int throwExceptionAtLoopNumber) {
      this.throwExceptionAtLoopNumber = throwExceptionAtLoopNumber;
    }
  }
}