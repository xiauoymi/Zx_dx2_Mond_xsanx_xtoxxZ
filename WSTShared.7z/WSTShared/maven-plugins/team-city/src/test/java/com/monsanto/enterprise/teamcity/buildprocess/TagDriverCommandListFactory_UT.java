/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.buildprocess;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.apache.maven.plugin.logging.SystemStreamLog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 * Filename:    $RCSfile: TagDriverCommandListFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author wsmcqu
 * @version $Revision: 1.1 $
 */
public class TagDriverCommandListFactory_UT extends MockObjectTestCase {
  public void testDefaultCommandListReturnedAsExpected() throws Exception {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/maven-command-list-context.xml");
    Connection mockConnection = createConnection(createStatement(createResultSet("")));
    TagDrivenCommandListFactory tagDrivenCommandListFactory = new TagDrivenCommandListFactory();
    tagDrivenCommandListFactory.setTeamCityConnection(mockConnection);
    tagDrivenCommandListFactory.setApplicationContext(context);
    tagDrivenCommandListFactory.setLog(new SystemStreamLog());
    List<MavenExecutionCommand> commands = (List<MavenExecutionCommand>) tagDrivenCommandListFactory.getObject();
    assertTrue(commands.size() > 0);
    boolean cloverInstrumentCommandPresent = false;
    for (MavenExecutionCommand mavenExecutionCommand : commands) {
      assertNotNull(mavenExecutionCommand.generateMavenCommand());
      assertTrue(mavenExecutionCommand.generateMavenCommand().length() > 0);
      if (!cloverInstrumentCommandPresent && mavenExecutionCommand.generateMavenCommand().indexOf("instrument") > -1) {
        cloverInstrumentCommandPresent = true;
      }
    }
    assertTrue(cloverInstrumentCommandPresent);
  }

  public void testDefaultCommandListReturnedAsExpectedWithNullTag() throws Exception {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/maven-command-list-context.xml");
    Connection mockConnection = createConnection(createStatement(createResultSet(null)));
    TagDrivenCommandListFactory tagDrivenCommandListFactory = new TagDrivenCommandListFactory();
    tagDrivenCommandListFactory.setTeamCityConnection(mockConnection);
    tagDrivenCommandListFactory.setApplicationContext(context);
    tagDrivenCommandListFactory.setLog(new SystemStreamLog());
    List<MavenExecutionCommand> commands = (List<MavenExecutionCommand>) tagDrivenCommandListFactory.getObject();
    assertTrue(commands.size() > 0);
    boolean cloverInstrumentCommandPresent = false;
    for (MavenExecutionCommand mavenExecutionCommand : commands) {
      assertNotNull(mavenExecutionCommand.generateMavenCommand());
      assertTrue(mavenExecutionCommand.generateMavenCommand().length() > 0);
      if (!cloverInstrumentCommandPresent && mavenExecutionCommand.generateMavenCommand().indexOf("instrument") > -1) {
        cloverInstrumentCommandPresent = true;
      }
    }
    assertTrue(cloverInstrumentCommandPresent);
  }

  public void testDefaultCommandListReturnedWithUnrecognizedTag() throws Exception {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/maven-command-list-context.xml");
    Connection mockConnection = createConnection(createStatement(createResultSet("boo")));
    TagDrivenCommandListFactory tagDrivenCommandListFactory = new TagDrivenCommandListFactory();
    tagDrivenCommandListFactory.setTeamCityConnection(mockConnection);
    tagDrivenCommandListFactory.setApplicationContext(context);
    tagDrivenCommandListFactory.setLog(new SystemStreamLog());
    List<MavenExecutionCommand> commands = (List<MavenExecutionCommand>) tagDrivenCommandListFactory.getObject();
    assertTrue(commands.size() > 0);
    boolean cloverInstrumentCommandPresent = false;
    for (MavenExecutionCommand mavenExecutionCommand : commands) {
      assertNotNull(mavenExecutionCommand.generateMavenCommand());
      assertTrue(mavenExecutionCommand.generateMavenCommand().length() > 0);
      if (!cloverInstrumentCommandPresent && mavenExecutionCommand.generateMavenCommand().indexOf("instrument") > -1) {
        cloverInstrumentCommandPresent = true;
      }
    }
    assertTrue(cloverInstrumentCommandPresent);
  }

  public void testDeployGoalListReturnedIfDeployTagPresent() throws Exception {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/maven-command-list-context.xml");
    Connection mockConnection = createConnection(createStatement(createResultSet("deploy")));
    TagDrivenCommandListFactory tagDrivenCommandListFactory = new TagDrivenCommandListFactory();
    tagDrivenCommandListFactory.setTeamCityConnection(mockConnection);
    tagDrivenCommandListFactory.setApplicationContext(context);
    tagDrivenCommandListFactory.setLog(new SystemStreamLog());
    List<MavenExecutionCommand> commands = (List<MavenExecutionCommand>) tagDrivenCommandListFactory.getObject();
    assertTrue(commands.size() > 0);
    boolean deployArtifactsCommandPresent = false;
    for (MavenExecutionCommand mavenExecutionCommand : commands) {
      assertNotNull(mavenExecutionCommand.generateMavenCommand());
      assertTrue(mavenExecutionCommand.generateMavenCommand().length() > 0);
      if (!deployArtifactsCommandPresent &&
        mavenExecutionCommand.generateMavenCommand().indexOf("deploy-artifacts") > -1) {
        deployArtifactsCommandPresent = true;
      }
    }
    assertTrue(deployArtifactsCommandPresent);
  }

  public void testReleaseGoalListReturnedIfReleaseTagPresent() throws Exception {
    ApplicationContext context = new ClassPathXmlApplicationContext(
      "/com/monsanto/enterprise/teamcity/contexts/maven-command-list-context.xml");
    Connection mockConnection = createConnection(createStatement(createResultSet("release")));
    TagDrivenCommandListFactory tagDrivenCommandListFactory = new TagDrivenCommandListFactory();
    tagDrivenCommandListFactory.setTeamCityConnection(mockConnection);
    tagDrivenCommandListFactory.setApplicationContext(context);
    tagDrivenCommandListFactory.setLog(new SystemStreamLog());
    List<MavenExecutionCommand> commands = (List<MavenExecutionCommand>) tagDrivenCommandListFactory.getObject();
    assertTrue(commands.size() > 0);
    boolean releasePrepareCommandPresent = false;
    for (MavenExecutionCommand mavenExecutionCommand : commands) {
      assertNotNull(mavenExecutionCommand.generateMavenCommand());
      assertTrue(mavenExecutionCommand.generateMavenCommand().length() > 0);
      if (!releasePrepareCommandPresent &&
        mavenExecutionCommand.generateMavenCommand().indexOf("prepare") > -1) {
        releasePrepareCommandPresent = true;
      }
    }
    assertTrue(releasePrepareCommandPresent);
  }

  private Connection createConnection(PreparedStatement preparedStatement) {
    Mock mockConnection = mock(Connection.class);
    mockConnection.stubs().method("prepareStatement").will(returnValue(preparedStatement));
    mockConnection.stubs().method("close");
    return (Connection) mockConnection.proxy();
  }

  private PreparedStatement createStatement(ResultSet resultSet) {
    Mock mockStatement = mock(PreparedStatement.class);
    mockStatement.stubs().method("executeQuery").will(returnValue(resultSet));
    mockStatement.stubs().method("setString");
    return (PreparedStatement) mockStatement.proxy();
  }

  private ResultSet createResultSet(String tagName) {
    Mock mockResultSet = mock(ResultSet.class);
    mockResultSet.stubs().method("next").will(returnValue(true));
    mockResultSet.stubs().method("getString").will(returnValue(tagName));
    return (ResultSet) mockResultSet.proxy();
  }
}