/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.mojos;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: WebappsCleaner_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author WSMCQU
 * @version $Revision: 1.1 $
 */
public class WebappsCleaner_UT extends AbstractMojoTestCase {
  protected void setUp() throws Exception {

    // required for mojo lookups to work
    super.setUp();
  }

  /**
   * @exception Exception
   */
//   public void testMojoGoal() throws Exception {
//      File testPom = new File(getBasedir(),
//         "src/test/resources/com/monsanto/enterprise/teamcity/basic-test-plugin-config.xml");
//
//      WebappsCleaner mojo = (WebappsCleaner) lookupMojo("cleanwebapps", testPom);
//
//      assertNotNull(mojo);
//   }
  public void testDeletesWarFileThatShouldBeDeleted() throws Exception {
    File webappsDir = new File(System.getenv("CATALINA_HOME") + File.separator + "webapps");
    File zebraWar = new File(webappsDir, "zebra.war");
    if (!zebraWar.exists()) {
      zebraWar.createNewFile();
    }
    assertTrue(zebraWar.exists());
    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertFalse(zebraWar.exists());
  }

  public void testDoesntDeleteCargoWar() throws Exception {
    File webappsDir = new File(System.getenv("CATALINA_HOME") + File.separator + "webapps");
    File cargoWar = new File(webappsDir, "cargocpc.war");
    if (!cargoWar.exists()) {
      cargoWar.createNewFile();
    }
    assertTrue(cargoWar.exists());
    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertTrue(cargoWar.exists());
  }

  public void testNonWarFileNotDeleted() throws Exception {
    File webappsDir = new File(System.getenv("CATALINA_HOME") + File.separator + "webapps");
    File zebraJar = new File(webappsDir, "zebra.jar");
    if (!zebraJar.exists()) {
      zebraJar.createNewFile();
    }
    assertTrue(zebraJar.exists());
    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertTrue(zebraJar.exists());
    zebraJar.delete();
  }

  public void testDirectoriesNotDeleted() throws Exception {
    File webappsDir = new File(System.getenv("CATALINA_HOME") + File.separator + "webapps");
    File zebraDir = new File(webappsDir, "zebraDir");
    if (!zebraDir.exists()) {
      zebraDir.mkdir();
    }
    assertTrue(zebraDir.exists());
    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertTrue(zebraDir.exists());
    zebraDir.delete();
  }

  public void testMultipleWarsDeleted() throws Exception {
    File webappsDir = new File(System.getenv("CATALINA_HOME") + File.separator + "webapps");
    File zebraWar = new File(webappsDir, "zebra.war");
    if (!zebraWar.exists()) {
      zebraWar.createNewFile();
    }
    assertTrue(zebraWar.exists());
    File giraffeWar = new File(webappsDir, "giraffe.war");
    if (!giraffeWar.exists()) {
      giraffeWar.createNewFile();
    }
    assertTrue(giraffeWar.exists());
    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertFalse(zebraWar.exists());
    assertFalse(giraffeWar.exists());
    zebraWar.delete();
    giraffeWar.delete();
  }

  public void testLogFilesDeleted() throws Exception {
    File logDir = new File(System.getenv("CATALINA_HOME") + File.separator + "logs");
    File log1 = new File(logDir, "log1.log");
    if (!log1.exists()) {
      log1.createNewFile();
    }
    assertTrue(log1.exists());
    File log2 = new File(logDir, "log2.txt");
    if (!log2.exists()) {
      log2.createNewFile();
    }
    assertTrue(log2.exists());

    WebappsCleaner webappsCleaner = new WebappsCleaner();
    webappsCleaner.execute();
    assertFalse(log1.exists());
    assertFalse(log2.exists());
    log1.delete();
    log2.delete();
  }
}