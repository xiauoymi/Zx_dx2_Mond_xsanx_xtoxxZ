/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: SurefireReportFileParser_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportFileParser_UT extends TestCase {
  public void testParseATFile() throws Exception {
    final String testFile = "com/monsanto/enterprise/teamcity/surefire/TEST-com.monsanto.lsi.phenex.cloning.importing.acceptancetest.ComplexPrimerImport_AT.xml";
    File file = new File(testFile);
    assertTrue(file.exists());
    SurefireReportParser parser = new SurefireReportParser();
    SurefireReportParserResult result = parser.parseFile(testFile);
    assertEquals(24, result.getTotalNumberOfTests());
    assertEquals(6, result.getNumberOfErrors());
    assertEquals(13, result.getNumberOfFailures());
    assertEquals(4, result.getNumberOfSuccesses());
    assertEquals(1, result.getNumberOfSkipped());
    assertEquals(19, result.getTotalNumberOfFailures());
    assertEquals(54.844, result.getNumberOfSeconds());
    assertEquals(TestSuiteType.AcceptanceTest, result.getTestSuiteType());
  }

  public void testParseUTFile() throws Exception {
    final String testFile = "com/monsanto/enterprise/teamcity/surefire/TEST-com.monsanto.lsi.phenex.cloning.fasta.writer.test.NominationFastaWriter_UT.xml";
    File file = new File(testFile);
    assertTrue(file.exists());
    SurefireReportParser parser = new SurefireReportParser();
    SurefireReportParserResult result = parser.parseFile(testFile);
    assertEquals(10, result.getTotalNumberOfTests());
    assertEquals(0, result.getNumberOfErrors());
    assertEquals(0, result.getNumberOfFailures());
    assertEquals(10, result.getNumberOfSuccesses());
    assertEquals(0, result.getNumberOfSkipped());
    assertEquals(0, result.getTotalNumberOfFailures());
    assertEquals(0.156, result.getNumberOfSeconds());
    assertEquals(TestSuiteType.UnitTest, result.getTestSuiteType());
  }

  public void testParsePTFile() throws Exception {
    final String testFile = "com/monsanto/enterprise/teamcity/surefire/TEST-com.monsanto.lsi.phenex.cloning.fasta.writer.test.NominationFastaWriter_PT.xml";
    File file = new File(testFile);
    assertTrue(file.exists());
    SurefireReportParser parser = new SurefireReportParser();
    SurefireReportParserResult result = parser.parseFile(testFile);
    assertEquals(10, result.getTotalNumberOfTests());
    assertEquals(0, result.getNumberOfErrors());
    assertEquals(0, result.getNumberOfFailures());
    assertEquals(10, result.getNumberOfSuccesses());
    assertEquals(0, result.getNumberOfSkipped());
    assertEquals(0, result.getTotalNumberOfFailures());
    assertEquals(0.156, result.getNumberOfSeconds());
    assertEquals(TestSuiteType.PerformanceTest, result.getTestSuiteType());
  }
}