/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.enterprise.teamcity.surefire;

import junit.framework.TestCase;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: SurefireReportResultCalculator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-12 20:46:45 $
 *
 * @author srmacdo
 * @version $Revision: 1.1 $
 */
public class SurefireReportResultCalculator_UT extends TestCase {
  public void testCalculateTotalNumberOfTests() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(156, calculator.getTotalNumberOfTests());
  }

  public void testCalculateTotalTime() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(33.2, calculator.getTotalTime());
  }

  public void testCalculateTotalTestFailures() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(78, calculator.getTotalFailures());
  }
  
  public void testCalculateTotalSuccesses() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(39, calculator.getTotalSuccesses());
  }

  public void testCalculateTotalSkipped() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(39, calculator.getTotalSkipped());
  }

  public void testGetSubCollectionByTestSuiteType() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    SurefireReportResultCalculator calculatorForType = calculator.createSubsetByTestSuiteType(TestSuiteType.UnitTest);
    assertEquals(20, calculatorForType.getTotalSuccesses());
    assertEquals(37, calculatorForType.getTotalFailures());
    assertEquals(21, calculatorForType.getTotalSkipped());
  }

  public void testCalculateAvgTimePerTest() throws Exception {
    SurefireReportResultCalculator calculator = createCalculator();
    assertEquals(calculator.getAverageTimePerTest(), (calculator.getTotalTime() / calculator.getTotalNumberOfTests()));
  }
  private SurefireReportResultCalculator createCalculator() {
    ArrayList<SurefireReportParserResult> results = new ArrayList<SurefireReportParserResult>();
    results.add(new SurefireReportParserResult(1, 2, 3, 4, 15.1, TestSuiteType.UnitTest)); //10
    results.add(new SurefireReportParserResult(4, 3, 2, 1, 1.2, TestSuiteType.Unknown));
    results.add(new SurefireReportParserResult(5, 6, 7, 8, 2.3, TestSuiteType.UnitTest)); //26
    results.add(new SurefireReportParserResult(8, 7, 6, 5, 3.4, TestSuiteType.AcceptanceTest));
    results.add(new SurefireReportParserResult(9, 10, 11, 12, 4.5, TestSuiteType.AcceptanceTest)); //42
    results.add(new SurefireReportParserResult(12, 11, 10, 9, 6.7, TestSuiteType.UnitTest));
    return new SurefireReportResultCalculator((SurefireReportParserResult[]) results.toArray(new SurefireReportParserResult[results.size()]));
  }

}