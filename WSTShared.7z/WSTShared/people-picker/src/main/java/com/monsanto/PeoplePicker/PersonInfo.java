/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.PeoplePicker;

/**
 * @author SRKARNA
 */
public class PersonInfo 
{
	private String partyId = null;
	private String userId = null;
	private String lastName = null;
	private String firstName = null;
	private String middleName = null;
	private String phone = null;
	private String mailZone = null;
	private String mailStop = null;
	private String email = null;
	private String site = null;

	public String getPartyId()
	{
		return partyId;
	}
	public void setPartyId(String partyId)
	{
		this.partyId = partyId; 
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String uid) {
		userId = uid;
	}

	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lName)
	{
		lastName = lName; 
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String fName) {
		firstName = fName;
	}

	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String mName) {
		middleName = mName;
	}

	public String getPhone() {
		return phone;
	}
	public void setPhone(String contactNumber) {
		this.phone = contactNumber;
	}

	public String getMailzone() {
		return mailZone;
	}
	public void setMailzone(String mailZone) {
		this.mailZone = mailZone;
	}

	public String getMailStop() {
		return mailStop;
	}
	public void setMailStop(String mailStop) {
		this.mailStop = mailStop;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String emailAddr) {
		this.email = emailAddr;
	}

	public String getSite() {
		return site;
	}
	public void setSite(String location) {
		site = location;
	}
}
