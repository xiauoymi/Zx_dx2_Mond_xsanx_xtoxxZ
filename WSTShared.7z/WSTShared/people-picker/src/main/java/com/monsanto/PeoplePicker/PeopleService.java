/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.PeoplePicker;

import com.monsanto.Util.XMLRPC.Invocator;

/**
 * @author SRKARNA
 */
public class PeopleService implements IPeopleService {

	/* (non-Javadoc)
	 * @see com.monsanto.PeoplePicker.IPeopleService#GetPeople(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public PersonInfo[] GetPeople(String lastName, String firstName,
			String phone, String mailStop, String userId, String site,
			String mailZone) throws Exception {

		return ((IPeopleService) Invocator.getProxy(IPeopleService.class)).GetPeople(lastName, firstName, phone, mailStop, userId, site, mailZone);
	}

}
