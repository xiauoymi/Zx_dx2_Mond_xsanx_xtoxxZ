/*
 * Created on Feb 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.PeoplePicker;

/**
 * @author SRKARNA
 */
public interface IPeopleService 
{
	PersonInfo[] GetPeople(String lastName, String firstName, String phone, String mailStop, String userId, String site, String mailZone) throws Exception;
}
