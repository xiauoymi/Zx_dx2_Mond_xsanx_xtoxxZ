package com.monsanto.wst.hibernate;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;/*
 TemporaryTrueDelete was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @deprecated This is only enable for now while tables are transitioned to using the normal behavior.
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Deprecated
@Retention(RetentionPolicy.RUNTIME)
public @interface TemporaryTrueDelete {
}
