package com.monsanto.wst.hibernate;

import javax.servlet.ServletRequest;

/**
 * This is specified by declaring a filter in the web.xml and passing the app name in app-name init param
 *
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HibernateSessionRequestFilterNoAudit extends HibernateSessionRequestFilter {
    @Override
    protected void beginAuditTransaction(ServletRequest request) {
        // do nothing
    }
}
