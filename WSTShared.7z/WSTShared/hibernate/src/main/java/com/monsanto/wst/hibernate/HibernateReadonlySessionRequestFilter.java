package com.monsanto.wst.hibernate;

import org.hibernate.Query;

import javax.servlet.*;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HibernateReadonlySessionRequestFilter  implements Filter {
    private HibernateFactory hibernate;

    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        try {
            hibernate.beginTransaction();
            // would like to "SET TRANSACTION READ ONLY" or something similar here,
            // but hibernate transaction and oracle transactions don't seem to line up
            // instead we'll just rollback any changes made in the session
            chain.doFilter(request, response);
            hibernate.rollbackTransaction(); // nothing should have been changed anyway
        } catch (Exception ex) {
            try {
                if (hibernate.getSession().getTransaction().isActive()) {
                    hibernate.rollbackTransaction();
                }
            } catch (Exception rbEx) {
                System.err.println("Could not rollback transaction after exception.");
                rbEx.printStackTrace(System.err);
            }

            throw new ServletException(ex);
        }
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        String appName = filterConfig.getInitParameter("appName");
        hibernate = HibernateFactoryImpl.getInstance(appName);
    }

    public void destroy() {
    }
}
