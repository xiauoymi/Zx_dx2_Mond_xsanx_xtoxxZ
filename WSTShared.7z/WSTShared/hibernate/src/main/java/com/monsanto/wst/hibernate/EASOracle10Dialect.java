package com.monsanto.wst.hibernate;

import org.hibernate.dialect.Oracle10gDialect;

/**
 * @Author Ken Johnson, Ram Bethina, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class EASOracle10Dialect extends Oracle10gDialect {
    public static final String FORCED_ROWNUM_SQL = " and rownum > 0";

    public String getLimitString(final String s, final int min, final int max) {
        String limitString = super.getLimitString(s, min, max);
        if (min == 0) {
            limitString += FORCED_ROWNUM_SQL;
        }
        return limitString;
    }
}

