package com.monsanto.wst.hibernate;

import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import java.io.Serializable;
import java.util.List;

public class HibernateDAO<T, ID extends Serializable> implements GenericDAO<T, ID> {
    private HibernateFactory hibernate;
    private Class<? extends T> persistentClass;

    public HibernateDAO(HibernateFactory hibernate, Class<? extends T> persistentClass) {
        this.hibernate = hibernate;
        this.persistentClass = persistentClass;
    }

    public void beginTransaction() {
        hibernate.beginTransaction();
    }

    public void commitTransaction() {
        hibernate.commitTransaction();
    }

    public void delete(T entity) {
        hibernate.getSession().delete(entity);
    }

    public List<T> findAll(int startIndex, int fetchSize) {
        Criteria crit = createCriteria();
        crit.setFirstResult(startIndex);
        crit.setFetchSize(fetchSize);
        return crit.list();
    }

    public List<T> findByExample(T exampleInstance, String[] excludeProperty) {
        Criteria crit = createCriteria();
        Example example = Example.create(exampleInstance);
        for (int i = 0; i < excludeProperty.length; i++) {
            example.excludeProperty(excludeProperty[i]);
        }
        crit.add(example);
        return crit.list();

    }


    public T findByPrimaryKey(ID id) {
        return (T) hibernate.getSession().get(persistentClass, id);
    }

    public T save(T entity) {
        hibernate.getSession().save(entity);
        return entity;
    }

    public List<T> findAll() {
        return createCriteria().list();
    }

    public List<T> findAll(String key, boolean ascending) {
        Order order = getOrder(key, ascending);
        return createCriteria().addOrder(order).list();
    }

    private Order getOrder(String key, boolean ascending) {
        Order order;
        if (ascending) {
            order = Order.asc(key);
        } else {
            order = Order.desc(key);
        }
        return order;
    }

    public Criteria createCriteria() {
        return hibernate.getSession().createCriteria(persistentClass);
    }

    protected Class<? extends T> getPersistentClass() {
        return persistentClass;
    }

    protected HibernateFactory getHibernate() {
        return hibernate;
    }
}
