package com.monsanto.wst.hibernate;

import org.hibernate.FlushMode;
import org.hibernate.Query;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class HibernateSessionRequestFilter implements Filter {
    private HibernateFactory hibernate;

    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        try {
            hibernate.beginTransaction();
            hibernate.getSession().setFlushMode(FlushMode.MANUAL);
            beginAuditTransaction(request);
            chain.doFilter(request, response);
            hibernate.getSession().flush();
            hibernate.commitTransaction();
        } catch (Exception ex) {
            try {
                if (hibernate.getSession().getTransaction().isActive()) {
                    hibernate.rollbackTransaction();
                }
            } catch (Exception rbEx) {
                System.err.println("Could not rollback transaction after exception.");
                rbEx.printStackTrace(System.err);
            }

            throw new ServletException(ex);
        }
    }

    protected void beginAuditTransaction(ServletRequest request) {
        try {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            String userId = getUserId(httpRequest);
            String url = httpRequest.getRequestURI();
            recordCurrentUserInTransaction(userId, url);
        } catch (RuntimeException e) {
            System.err.println("Could not determine current user");
            e.printStackTrace(System.err);
        }
    }

    private String getUserId(HttpServletRequest httpRequest) {
        try {
            IUser user = (IUser) httpRequest.getSession().getAttribute(IUser.LOGIN_USER);
            return user.getUserId();
        } catch (RuntimeException e) {
            return "UNKNOWN";
        }
    }

    @SuppressWarnings({"JpaQueryApiInspection"})
    private void recordCurrentUserInTransaction(String userId, String url) {
        Query namedQuery = hibernate.getSession().getNamedQuery("createAuditTransaction");
        namedQuery.setParameter("requestor", userId);
        namedQuery.setParameter("processName", url);
        namedQuery.list();

    }

    public void init(FilterConfig filterConfig) throws ServletException {
        String appName = filterConfig.getInitParameter("appName");
        hibernate = HibernateFactoryImpl.getInstance(appName);
    }

    public void destroy() {
    }
}
