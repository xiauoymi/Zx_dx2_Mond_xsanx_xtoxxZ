package com.monsanto.wst.hibernate;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;/*
 TrueDelete was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface TrueDelete {
  String reason();
  String approval();
}
