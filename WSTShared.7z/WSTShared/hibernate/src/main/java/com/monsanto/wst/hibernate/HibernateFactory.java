package com.monsanto.wst.hibernate;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;/*
 HibernateFactory was created on Aug 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface HibernateFactory {
  void closeSessionFactory();

  Session getSession();

  void closeSession();

  void beginTransaction();

  void commitTransaction();

  void rollbackTransaction();

  Transaction getThreadTransaction();

  Session getThreadSession();

  Configuration getConfiguration();
}
