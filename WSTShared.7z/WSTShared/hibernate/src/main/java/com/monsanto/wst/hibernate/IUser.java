package com.monsanto.wst.hibernate;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface IUser {
    public static final String LOGIN_USER = "loginUser";
    String getUserId();
}
