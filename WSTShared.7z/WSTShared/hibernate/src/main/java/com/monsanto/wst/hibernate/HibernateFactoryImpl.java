package com.monsanto.wst.hibernate;

import com.monsanto.wst.commonutils.properties.PlatformProperties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.ExecuteUpdateResultCheckStyle;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.KeyValue;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Table;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
/*
 HibernateFactory was created on Aug 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class HibernateFactoryImpl implements HibernateFactory {
    private static final Map<String, HibernateFactory> instanceMap = new HashMap<String, HibernateFactory>();

    private final SessionFactory sessionFactory;
    private final Configuration configuration;

    public static HibernateFactory getInstance(String appName) {
        synchronized (HibernateFactoryImpl.class) {
            HibernateFactory fact = instanceMap.get(appName);
            if (fact == null) {
                fact = new HibernateFactoryImpl(appName);
                instanceMap.put(appName, fact);
            }

            return fact;
        }
    }

    public static void setInstance(String appName, HibernateFactory instance) {
        instanceMap.put(appName, instance);
    }

    private static Properties getOverrideProperties(String appName) {
        try {
            Properties baseProperties = new Properties();
            baseProperties.load(HibernateFactoryImpl.class.getClassLoader().getResourceAsStream("hibernate.properties"));
            return new PlatformProperties(baseProperties, appName, "hibernate.connection.password");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public HibernateFactoryImpl(String appName) {
        try {
            configuration = getConfigurationForApp(appName);
            sessionFactory = configuration.buildSessionFactory(); // Build and store (either in JNDI or static variable)
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public void beginReadOnlyTransaction() {
        beginTransaction();
        setReadonlyTransaction();
    }

    private void setReadonlyTransaction() {
        Query namedQuery = getSession().createSQLQuery("SET TRANSACTION READ ONLY");
        namedQuery.executeUpdate();
    }

    public static Configuration getConfigurationForApp(String appName) {
        Configuration configuration = new AnnotationConfiguration();
        configuration.configure(); // Read hibernate.cfg.xml (has to be present)

        Properties overrideProperties = getOverrideProperties(appName);
        for (Map.Entry<Object, Object> overrideEntry : overrideProperties.entrySet()) {
            String key = toString(overrideEntry.getKey());
            String value = toString(overrideEntry.getValue());
            configuration.setProperty(key, value);
        }
        updateConfigurationForCustomDelete(configuration);
        return configuration;
    }

    public static void updateConfigurationForCustomDelete(Configuration configuration) {
        configuration.buildMappings();
        Iterator<PersistentClass> mappings = configuration.getClassMappings();
        while (mappings.hasNext()) {
            PersistentClass classMapping = mappings.next();
            if (isDeleteForbidden(classMapping)) {
                classMapping.setCustomSQLDelete("update dual set dummy=dummy where 3=4 and dummy=?", false, ExecuteUpdateResultCheckStyle.NONE);
            } else if (isUsingPseudoDelete(classMapping)) {
                classMapping.getRootClass().setWhere("NVL(IS_DELETED, 'N')<>'Y'");
                String sql = getSqlForPsudoDelete(classMapping);
                classMapping.setCustomSQLDelete(sql, false, ExecuteUpdateResultCheckStyle.NONE);
            }
        }
    }

    private static boolean isDeleteForbidden(PersistentClass classMapping) {
        Class clazz = getClassForMapping(classMapping);
        return clazz.isAnnotationPresent(NoDeleteAllowed.class);
    }

    private static boolean isUsingPseudoDelete(PersistentClass classMapping) {
        Class clazz = getClassForMapping(classMapping);
        boolean trueDeleteEnabled = clazz.isAnnotationPresent(TrueDelete.class);
        //noinspection deprecation
        boolean DEPRECATEDtrueDeleteEnabled = clazz.isAnnotationPresent(TemporaryTrueDelete.class);

        return !trueDeleteEnabled && !DEPRECATEDtrueDeleteEnabled;
    }

    private static Class getClassForMapping(PersistentClass classMapping) {
        String className = classMapping.getClassName();
        //noinspection RawUseOfParameterizedType
        Class clazz;
        try {
            clazz = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return clazz;
    }

    private static String getSqlForPsudoDelete(PersistentClass classMapping) {
        Table entityTable = classMapping.getTable();
        String schema = entityTable.getSchema();
        String tableName = entityTable.getName();
        KeyValue identifer = classMapping.getIdentifier();
        Column column = (Column) identifer.getColumnIterator().next();
        return "UPDATE \"" + schema + "\".\"" + tableName + "\" SET IS_DELETED='Y' WHERE " + column.getQuotedName() + "=?";
    }

    public void closeSessionFactory() {
        if (!sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }

    public Session getSession() {
        return sessionFactory.getCurrentSession();
    }


    public void closeSession() {
        getSession().close();
    }

    public void beginTransaction() {
        getSession().beginTransaction();
    }

    public void commitTransaction() {
        getSession().getTransaction().commit();
    }

    public void rollbackTransaction() {
        getSession().getTransaction().rollback();
    }

    public Transaction getThreadTransaction() {
        return getSession().getTransaction();
    }

    public Session getThreadSession() {
        return getSession();
    }

    private static String toString(Object st) {
        if (st == null) {
            return null;
        } else {
            return st.toString();
        }
    }
}
