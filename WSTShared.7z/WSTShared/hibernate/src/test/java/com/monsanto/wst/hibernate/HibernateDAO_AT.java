package com.monsanto.wst.hibernate;

import junit.framework.TestCase;
import com.monsanto.wst.commonutils.testutils.TestUtils;

import java.util.List;

/*
 HibernateDAO_AT was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class HibernateDAO_AT extends TestCase {
    private static final String TEST_APP = "tourtrackingsystem";
    private HibernateFactory hibernateFactory;

    protected void setUp() throws Exception {
        super.setUp();
        hibernateFactory = HibernateFactoryImpl.getInstance(TEST_APP);
    }

    public void testDelete_UpdatesIsDeletedFlagInstead() throws Exception {
        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithWhereClause, String> dao = new HibernateDAO<TestEntityWithWhereClause, String>(hibernateFactory, TestEntityWithWhereClause.class);
        String testId = TestUtils.getRandomIdentifier();
        TestEntityWithWhereClause testEntity = new TestEntityWithWhereClause(testId);
        dao.save(testEntity);
        dao.delete(testEntity);
        hibernateFactory.commitTransaction();

        hibernateFactory.beginTransaction();
        TestEntityWithWhereClause entityUsingFlag = dao.findByPrimaryKey(testId);
        assertNull(entityUsingFlag);
        hibernateFactory.commitTransaction();

        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithoutWhereClause, String> daoWithoutFlag = new HibernateDAO<TestEntityWithoutWhereClause, String>(hibernateFactory, TestEntityWithoutWhereClause.class);
        TestEntityWithoutWhereClause entityNotUsingFlag = daoWithoutFlag.findByPrimaryKey(testId);
        assertNotNull(entityNotUsingFlag);
        assertEquals(testId, entityNotUsingFlag.getId());
        assertEquals("Y", entityNotUsingFlag.getDeleted());
        hibernateFactory.commitTransaction();
    }

    public void testTransitionalTrueDeleteActsLikeTrueDelete() throws Exception {
        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithWhereClause, String> dao = new HibernateDAO<TestEntityWithWhereClause, String>(hibernateFactory, TestEntityWithWhereClause.class);
        String testId = TestUtils.getRandomIdentifier();
        TestEntityWithWhereClause testEntity = new TestEntityWithWhereClause(testId);
        dao.save(testEntity);
        dao.delete(testEntity);
        hibernateFactory.commitTransaction();

        hibernateFactory.beginTransaction();
        TestEntityWithWhereClause entityUsingFlag = dao.findByPrimaryKey(testId);
        assertNull(entityUsingFlag);
        hibernateFactory.commitTransaction();

        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithoutWhereClauseTransitional, String> daoWithoutFlag = new HibernateDAO<TestEntityWithoutWhereClauseTransitional, String>(hibernateFactory, TestEntityWithoutWhereClauseTransitional.class);
        TestEntityWithoutWhereClauseTransitional entityNotUsingFlag = daoWithoutFlag.findByPrimaryKey(testId);
        assertNotNull(entityNotUsingFlag);
        assertEquals(testId, entityNotUsingFlag.getId());
        hibernateFactory.commitTransaction();
    }

    public void testDeleteNotAllowedCausesDeleteToDoNothing() throws Exception {
        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithWhereClause, String> dao = new HibernateDAO<TestEntityWithWhereClause, String>(hibernateFactory, TestEntityWithWhereClause.class);
        String testId = TestUtils.getRandomIdentifier();
        TestEntityWithWhereClause testEntity = new TestEntityWithWhereClause(testId);
        dao.save(testEntity);
        hibernateFactory.commitTransaction();

        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithDeleteDisabled, String> noDeleteDao = new HibernateDAO<TestEntityWithDeleteDisabled, String>(hibernateFactory, TestEntityWithDeleteDisabled.class);
        TestEntityWithDeleteDisabled noDeleteEntity = noDeleteDao.findByPrimaryKey(testId);
        assertNotNull(noDeleteEntity);
        try {
            noDeleteDao.delete(noDeleteEntity);
            hibernateFactory.commitTransaction();
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            // ignore expected exception
        }

        hibernateFactory.beginTransaction();
        dao = new HibernateDAO<TestEntityWithWhereClause, String>(hibernateFactory, TestEntityWithWhereClause.class);
        TestEntityWithWhereClause testEntityAfter = dao.findByPrimaryKey(testId);
        assertNotNull(testEntityAfter);
        dao.delete(testEntityAfter);
        hibernateFactory.commitTransaction();
    }

    public void testFindAll_WithOrderAscending_HasAscending() {
        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithoutWhereClause, String> dao = new HibernateDAO<TestEntityWithoutWhereClause, String>(hibernateFactory, TestEntityWithoutWhereClause.class);
        List<TestEntityWithoutWhereClause> testRecords = dao.findAll("id", true);
        TestEntityWithoutWhereClause previousRecord = null;
        for (TestEntityWithoutWhereClause currRecord : testRecords) {
            if (previousRecord != null) {
                String prevId = previousRecord.getId();
                String currId = currRecord.getId();

                if (prevId.compareTo(currId) > 0) {
                    fail("Expected prevId (" + prevId + ") < currId (" + currId + "), but wasn't.");
                }
            }

            previousRecord = currRecord;
        }
        hibernateFactory.commitTransaction();
    }

    public void testFindAll_WithOrderDescending_HasDescending() {
        hibernateFactory.beginTransaction();
        HibernateDAO<TestEntityWithoutWhereClause, String> dao = new HibernateDAO<TestEntityWithoutWhereClause, String>(hibernateFactory, TestEntityWithoutWhereClause.class);
        List<TestEntityWithoutWhereClause> testRecords = dao.findAll("id", false);
        TestEntityWithoutWhereClause previousRecord = null;
        for (TestEntityWithoutWhereClause currRecord : testRecords) {
            if (previousRecord != null) {
                String prevId = previousRecord.getId();
                String currId = currRecord.getId();

                if (prevId.compareTo(currId) < 0) {
                    fail("Expected prevId (" + prevId + ") > currId (" + currId + "), but wasn't.");
                }
            }

            previousRecord = currRecord;
        }
        hibernateFactory.commitTransaction();
    }
}