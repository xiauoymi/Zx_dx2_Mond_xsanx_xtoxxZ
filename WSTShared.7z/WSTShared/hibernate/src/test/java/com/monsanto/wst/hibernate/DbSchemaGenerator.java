package com.monsanto.wst.hibernate;

import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class DbSchemaGenerator {
    private final Configuration configuration;

    public DbSchemaGenerator(String appName) {
        configuration = HibernateFactoryImpl.getConfigurationForApp(appName);
    }

    public void generateDDL(boolean includeDropStatements, boolean includeCreateStatements) {
        SchemaExport schemaExport = new SchemaExport(configuration);
        schemaExport.setFormat(true);
        schemaExport.setDelimiter(";");
        schemaExport.execute(true, false, includeDropStatements, includeCreateStatements);
    }

    public void generateCreateStatements() {
        generateDDL(false, true);
    }

    public void generateDropStatements() {
        generateDDL(true, false);
    }

    public static void main(String[] args) {
        DbSchemaGenerator schemaGen = new DbSchemaGenerator("tourtrackingsystem");
        schemaGen.generateCreateStatements();
    }
}
