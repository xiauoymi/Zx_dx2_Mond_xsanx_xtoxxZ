package com.monsanto.wst.hibernate.mock;

import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
/*
 MockHibernateFactory was created on Aug 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockHibernateFactory implements HibernateFactory {
    private Session session = new MockHibernateSession();
    private boolean wasBeginTransactionCalled = false;
    private boolean wasCommitTransactionCalled = false;

    public boolean wasBeginTransactionCalled() {
        return wasBeginTransactionCalled;
    }

    public boolean wasCommitTransactionCalled() {
        return wasCommitTransactionCalled;
    }

    public void closeSessionFactory() {
    }

    public Session getSession() {
        return session;
    }

    public void closeSession() {
        session.close();
    }

    public void beginTransaction() {
        wasBeginTransactionCalled = true;
        session.beginTransaction();
    }

    public void commitTransaction() {
        wasCommitTransactionCalled = true;
        session.getTransaction().commit();
    }

    public void rollbackTransaction() {
        session.getTransaction().rollback();
    }

    public Transaction getThreadTransaction() {
        return session.getTransaction();
    }

    public Session getThreadSession() {
        return session;
    }

    public Configuration getConfiguration() {
        return null;
    }
}
