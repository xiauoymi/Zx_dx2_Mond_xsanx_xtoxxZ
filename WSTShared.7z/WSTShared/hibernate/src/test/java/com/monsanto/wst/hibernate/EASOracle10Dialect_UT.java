package com.monsanto.wst.hibernate;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class EASOracle10Dialect_UT extends TestCase {
    public void testMinOfZeroStringIsAdded() throws Exception {
        EASOracle10Dialect dialect = new EASOracle10Dialect();
        String baseSQL = "select * from dual";
        String resultSQL = dialect.getLimitString(baseSQL, 0, 10);
        assertStringContains(baseSQL, resultSQL);
        assertStringContains(EASOracle10Dialect.FORCED_ROWNUM_SQL, resultSQL);
    }

    public void testMinGreaterThanZeroNoStringAdded() throws Exception {
        EASOracle10Dialect dialect = new EASOracle10Dialect();
        String baseSQL = "select * from dual";
        String resultSQL = dialect.getLimitString(baseSQL, 5, 10);
        assertStringContains(baseSQL, resultSQL);
        assertStringNotContains(EASOracle10Dialect.FORCED_ROWNUM_SQL, resultSQL);
    }

    private void assertStringContains(String searchString, String target) {
        if (!target.contains(searchString)) {
            fail("Expected string to contain '" + searchString + "' but string was: '" + target + "'");
        }
    }

    private void assertStringNotContains(String searchString, String target) {
        if (target.contains(searchString)) {
            fail("Expected string to NOT contain '" + searchString + "' but string was: '" + target + "'");
        }
    }
}