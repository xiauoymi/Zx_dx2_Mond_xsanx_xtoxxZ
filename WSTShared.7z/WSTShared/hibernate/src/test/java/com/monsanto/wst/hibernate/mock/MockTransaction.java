package com.monsanto.wst.hibernate.mock;

import org.hibernate.Transaction;
import org.hibernate.HibernateException;

import javax.transaction.Synchronization;
/*
 MockTransaction was created on Aug 21, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockTransaction implements Transaction {
  private boolean rolledBack = false;
  private boolean active = false;
  private boolean committed = false;

  public void begin() throws HibernateException {
    active = true;
  }

  public void commit() throws HibernateException {
    committed = true;
    active = false;
  }

  public void rollback() throws HibernateException {
    rolledBack = true;
    active = false;
  }

  public boolean wasRolledBack() throws HibernateException {
    return rolledBack;
  }

  public boolean wasCommitted() throws HibernateException {
    return committed;
  }

  public boolean isActive() throws HibernateException {
    return active;
  }

  public void registerSynchronization(Synchronization synchronization) throws HibernateException {
  }

  public void setTimeout(int seconds) {
  }
}
