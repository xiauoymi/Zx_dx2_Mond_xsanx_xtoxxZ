package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.IdentifierEqExpression;
import org.hibernate.criterion.Expression;
import com.monsanto.wst.hibernate.criteria.IdentifierEqualsExpressionInspector;
/*
 IdentifierEqualsExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class IdentifierEqualsExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName";
  private static final Object testValue = "HelloWorld";

  private static final IdentifierEqExpression expression = (IdentifierEqExpression) Expression.idEq(testValue);

  private IdentifierEqualsExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new IdentifierEqualsExpressionInspector();
  }

  public void testCanGetValue() throws Exception {
    assertEquals(testValue, inspector.getValue(expression));
  }
}
