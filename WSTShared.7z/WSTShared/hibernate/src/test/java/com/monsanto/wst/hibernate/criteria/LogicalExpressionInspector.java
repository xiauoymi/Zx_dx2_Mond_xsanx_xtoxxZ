package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Criterion;
/*
 LogicalExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class LogicalExpressionInspector extends CriterionInspector {
  public String getOp(LogicalExpression expression) {
    return (String) getValueWithReflection(expression, "op");
  }

  public Criterion getLeftCriterion(LogicalExpression expression) {
    return (Criterion) getValueWithReflection(expression, "lhs");
  }

  public Criterion getRightCriterion(LogicalExpression expression) {
    return (Criterion) getValueWithReflection(expression, "rhs");
  }
}
