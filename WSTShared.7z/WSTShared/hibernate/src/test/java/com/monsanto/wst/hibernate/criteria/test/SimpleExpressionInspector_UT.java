package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.criterion.Expression;
import com.monsanto.wst.hibernate.criteria.SimpleExpressionInspector;
import com.monsanto.wst.hibernate.criteria.PropertyExpressionInspector;

/*
 SimpleExpressionEvaluator was created on Sep 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class SimpleExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName";
  private static final String testPropertyName2 = "myPropName";
  private static final Long testValue1 = new Long(1234L);
  private static final Long testValue2 = new Long(1234L);
  private static final SimpleExpression exprLE = Expression.le(testPropertyName1, testValue1);
  private static final SimpleExpression exprEQ = Expression.eq(testPropertyName2, testValue2).ignoreCase();

  private SimpleExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new SimpleExpressionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName1, inspector.getPropertyName(exprLE));
    assertEquals(testPropertyName2, inspector.getPropertyName(exprEQ));
  }

  public void testCanGetOp() throws Exception {
    assertEquals("<=", inspector.getOp(exprLE));
    assertEquals("=", inspector.getOp(exprEQ));
  }

  public void testCanGetValue() throws Exception {
    assertEquals(testValue1, inspector.getValue(exprLE));
    assertEquals(testValue2, inspector.getValue(exprEQ));
  }

  public void testCanGetCaseSensitivity() throws Exception {
    assertFalse(inspector.isCaseInsensitive(exprLE));
    assertTrue(inspector.isCaseInsensitive(exprEQ));
  }
}

