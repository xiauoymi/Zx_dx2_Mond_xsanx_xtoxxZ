package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.*;
import com.monsanto.wst.hibernate.criteria.LogicalExpressionInspector;
import com.monsanto.wst.hibernate.criteria.JunctionExpressionInspector;
/*
 JunctionExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class JunctionExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName1";
  private static final String testPropertyName2 = "myPropName2";
  private static final String testValue1 = "HELLO";
  private static final String testValue2 = "WORLD";
  private static final Criterion testCriteria1 = Expression.eq(testPropertyName1, testValue1);
  private static final Criterion testCriteria2 = Expression.eq(testPropertyName2, testValue2);
  private static final Criterion testCriteria3 = Expression.eq(testPropertyName1, testValue2);
  private static final Criterion testCriteria4 = Expression.eq(testPropertyName2, testValue1);

  private static final Conjunction expressionConjunction = getConjunction();
  private static final Disjunction expressionDisjunction = getDisConjunction();

  private JunctionExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new JunctionExpressionInspector();
  }

  private static Conjunction getConjunction() {
    Conjunction conjunction = Expression.conjunction();
    conjunction.add(testCriteria1);
    conjunction.add(testCriteria2);
    conjunction.add(testCriteria3);
    conjunction.add(testCriteria4);
    return conjunction;
  }


  private static Disjunction getDisConjunction() {
    Disjunction disjunction = Expression.disjunction();
    disjunction.add(testCriteria1);
    disjunction.add(testCriteria2);
    disjunction.add(testCriteria3);
    disjunction.add(testCriteria4);
    return disjunction;
  }

  public void testCanGetCriteria() throws Exception {
    assertTrue(inspector.getCriteria(expressionConjunction).contains(testCriteria1));
    assertTrue(inspector.getCriteria(expressionConjunction).contains(testCriteria2));
    assertTrue(inspector.getCriteria(expressionConjunction).contains(testCriteria3));
    assertTrue(inspector.getCriteria(expressionConjunction).contains(testCriteria4));

    assertTrue(inspector.getCriteria(expressionDisjunction).contains(testCriteria1));
    assertTrue(inspector.getCriteria(expressionDisjunction).contains(testCriteria2));
    assertTrue(inspector.getCriteria(expressionDisjunction).contains(testCriteria3));
    assertTrue(inspector.getCriteria(expressionDisjunction).contains(testCriteria4));
  }

  public void testCanGetOp() throws Exception {
    assertEquals("and", inspector.getOp(expressionConjunction));
    assertEquals("or", inspector.getOp(expressionDisjunction));
  }
}
