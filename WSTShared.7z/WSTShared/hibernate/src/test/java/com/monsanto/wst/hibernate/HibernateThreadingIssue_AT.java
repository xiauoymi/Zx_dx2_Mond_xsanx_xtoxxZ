package com.monsanto.wst.hibernate;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreDBConnection;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;
import junit.framework.TestCase;

/**
 * This test class is to test the issues we've been having with Hibernate caching (apparently) where different sessions
 * see different sets of data in the database
 *
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HibernateThreadingIssue_AT extends TestCase {
    private static final String TEST_APP = "tourtrackingsystem";
    private HibernateFactory hibernateFactory;

    protected void setUp() throws Exception {
        super.setUp();
        hibernateFactory = HibernateFactoryImpl.getInstance(TEST_APP);
    }

  //todo fix this test.
    public void testAddInOneThreadCanSeeInSecondThread() throws Exception {
//        hibernateFactory.beginTransaction();
//        String testIdForOtherThread = TestUtils.getRandomIdentifier();
//        AddNewItemRunner newItemRunner = new AddNewItemRunner(testIdForOtherThread);
//        DeleteNewItemRunner deleteItemRunner = new DeleteNewItemRunner(testIdForOtherThread);
//
//        assertFalse(idExists(testIdForOtherThread));
//
//        Thread addThread = new Thread(newItemRunner);
//        addThread.start();
//        while (!newItemRunner.isCommitted) {
//            Thread.sleep(10);
//        }
//        try {
//            assertTrue(idExists(testIdForOtherThread));
//        } finally {
//            addThread.join();
//        }
//        hibernateFactory.commitTransaction();
//
//        Thread deleteThread = new Thread(deleteItemRunner);
//        deleteThread.start();
//        while (!deleteItemRunner.isCommitted) {
//            Thread.sleep(10);
//        }
//
//        hibernateFactory.beginTransaction();
//
//        try {
//            assertFalse(idExists(testIdForOtherThread));
//        } finally {
//            deleteThread.join();
//        }
//
//        assertFalse(idExists(testIdForOtherThread));
//        hibernateFactory.commitTransaction();
    assertTrue("This test needs to be fixed later",true);
    }

    private boolean idExists(String id) {
        GenericDAO<TestEntityWithDeleteDisabled, String> dao = new HibernateDAO<TestEntityWithDeleteDisabled, String>(hibernateFactory, TestEntityWithDeleteDisabled.class);
        return dao.findByPrimaryKey(id) != null;
    }

    private abstract static class AbstractJDBCRunner implements Runnable {
        private static final String TEST_USER = "TTS";
        private static final String TEST_PASSWORD = "TTS_123_ABC";
        private static final String TEST_DATABASE = "COMGEND";
        private final String testId;

        public boolean isCommitted = false;

        protected AbstractJDBCRunner(String testId) {
            this.testId = testId;
        }

        protected PersistentStoreConnection getConnection() throws ClassNotFoundException, WrappingException {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String userName = TEST_USER;
            String password = TEST_PASSWORD;
            String dataSource = "jdbc:oracle:oci:@" + TEST_DATABASE;
//            String dataSource = "jdbc:oracle:thin:@" + TEST_DATABASE;

            return new PersistentStoreDBConnection(userName, password, dataSource);
        }

        public String getTestId() {
            return testId;
        }
    }

    private static class AddNewItemRunner extends AbstractJDBCRunner {
        public AddNewItemRunner(String testId) {
            super(testId);
        }

        public void run() {
            try {
                PersistentStoreConnection conn = getConnection();
                conn.beginTransaction();
                conn.executeInsert("INSERT INTO HIBERNATE_TEST (ID) VALUES ('" + getTestId() + "')");
                conn.endTransaction();
                isCommitted = true;
                Thread.sleep(500);
                conn.close();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } catch (WrappingException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static class DeleteNewItemRunner extends AbstractJDBCRunner {
        public DeleteNewItemRunner(String testId) {
            super(testId);
        }

        public void run() {
            try {
                PersistentStoreConnection conn = getConnection();
                conn.beginTransaction();
                conn.executeDelete("DELETE FROM HIBERNATE_TEST WHERE ID='" + getTestId() + "'");
                conn.endTransaction();
                isCommitted = true;
                Thread.sleep(500);
                conn.close();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } catch (WrappingException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}