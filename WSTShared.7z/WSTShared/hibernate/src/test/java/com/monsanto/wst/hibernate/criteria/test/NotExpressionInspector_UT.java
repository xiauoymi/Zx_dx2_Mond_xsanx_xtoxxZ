package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.NotExpression;
import com.monsanto.wst.hibernate.criteria.LogicalExpressionInspector;
import com.monsanto.wst.hibernate.criteria.NotExpressionInspector;
/*
 NotExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class NotExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName1";
  private static final String testValue1 = "HELLO";
  private static final Criterion testCriteria = Expression.eq(testPropertyName1, testValue1);
  private static final NotExpression expression = (NotExpression) Expression.not(testCriteria);

  private NotExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new NotExpressionInspector();
  }

  public void testCanGetCriterion() throws Exception {
    assertEquals(testCriteria, inspector.getCriterion(expression));
  }
}
