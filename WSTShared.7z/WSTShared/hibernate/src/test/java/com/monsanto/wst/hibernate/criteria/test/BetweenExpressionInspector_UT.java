package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.BetweenExpression;
import com.monsanto.wst.hibernate.criteria.BetweenExpressionInspector;
import com.monsanto.wst.hibernate.criteria.PropertyBasedCriterionInspector;
/*
 BetweenExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class BetweenExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName";
  private static final Long testValue1 = new Long(1234L);
  private static final Long testValue2 = new Long(4444L);
  private static final BetweenExpression expression = (BetweenExpression) Expression.between(testPropertyName1, testValue1, testValue2);

  private BetweenExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new BetweenExpressionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName1, inspector.getPropertyName(expression));
  }

  public void testCanGetValue() throws Exception {
    assertEquals(testValue1, inspector.getLowValue(expression));
    assertEquals(testValue2, inspector.getHighValue(expression));
  }
}

