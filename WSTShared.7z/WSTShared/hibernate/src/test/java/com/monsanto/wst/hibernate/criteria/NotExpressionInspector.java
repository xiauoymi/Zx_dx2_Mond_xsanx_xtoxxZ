package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.NotExpression;
/*
 NotExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class NotExpressionInspector extends CriterionInspector {
  public Object getCriterion(NotExpression expression) {
    return (Criterion) getValueWithReflection(expression, "criterion");
  }
}
