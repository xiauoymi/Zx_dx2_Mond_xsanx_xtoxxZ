package com.monsanto.wst.hibernate;

import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 TestEntity was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
@Entity
@AccessType("field")
@Table(schema="TTS", name="HIBERNATE_TEST")
public class TestEntityWithWhereClause {
  @Id
  private String id;

  public TestEntityWithWhereClause() {
  }

  public TestEntityWithWhereClause(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }
}

