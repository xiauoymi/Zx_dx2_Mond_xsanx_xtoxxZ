package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.BetweenExpression;
/*
 BetweenExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class BetweenExpressionInspector extends PropertyBasedCriterionInspector {
  public Object getLowValue(BetweenExpression expression) {
    return getValueWithReflection(expression, "lo");
  }

  public Object getHighValue(BetweenExpression expression) {
    return getValueWithReflection(expression, "hi");
  }
}
