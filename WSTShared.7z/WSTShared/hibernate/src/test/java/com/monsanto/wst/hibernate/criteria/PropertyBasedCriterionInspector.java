package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.Criterion;
/*
 PropertyBasedCriterionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class PropertyBasedCriterionInspector extends CriterionInspector {
  public String getPropertyName(Criterion expression) {
    return (String) getValueWithReflection(expression, "propertyName");
  }
}
