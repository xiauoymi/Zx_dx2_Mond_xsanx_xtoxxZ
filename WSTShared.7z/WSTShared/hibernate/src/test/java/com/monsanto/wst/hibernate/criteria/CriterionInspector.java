package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.Criterion;

import java.lang.reflect.Field;
/*
 CriterionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class CriterionInspector {
  protected Object getValueWithReflection(Criterion expression, String name) {
    try {
      Field field = getFieldForExpression(expression, name);
      return field.get(expression);
    } catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  protected int getIntValueWithReflection(Criterion expression, String name) {
    try {
      Field field = getFieldForExpression(expression, name);
      return field.getInt(expression);
    } catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  protected boolean getBooleanWithReflection(Criterion expression, String name) {
    try {
      Field field = getFieldForExpression(expression, name);
      return field.getBoolean(expression);
    } catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  private Field getFieldForExpression(Criterion expression, String name) {
    Field field = getFieldForClass(expression.getClass(), name);
    field.setAccessible(true);
    return field;
  }

  private Field getFieldForClass(Class<?> clazz, String name) {
    Class<?> currClass = clazz;
    while (currClass != null) {
      Field foundField = getFieldFromClassAtThisLevel(currClass, name);
      if (foundField != null) {
        return foundField;
      }

      currClass = currClass.getSuperclass();
    }

    throw new RuntimeException("Could not find field '" + name + "' in " + clazz.getName() + " or any classes it extends.");
  }

  private Field getFieldFromClassAtThisLevel(Class<?> clazz, String name) {
    //ideally we'd use Class.getDeclaredField(String name) instead, but that throws if name isn't found
    for (Field field : clazz.getDeclaredFields()) {
      if (field.getName().equals(name)) {
        return field;
      }
    }

    return null;
  }
}

