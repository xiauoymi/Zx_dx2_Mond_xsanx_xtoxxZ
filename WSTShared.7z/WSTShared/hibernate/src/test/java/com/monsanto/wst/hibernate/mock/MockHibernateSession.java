package com.monsanto.wst.hibernate.mock;

import org.hibernate.*;
import org.hibernate.stat.SessionStatistics;

import java.io.Serializable;
import java.sql.Connection;

@SuppressWarnings({"ClassWithTooManyMethods", "RawUseOfParameterizedType"})
public class MockHibernateSession implements Session {
    private Serializable loadID = null;
    private Class loadClass = null;
    private Object savedObject = null;
    private Object deletedObject = null;
    private MockCriteria mockCriteria = new MockCriteria();
    private MockTransaction currentTransaction = null;
    private Object queryObject = null;
    private Class classQueried = null;
    private Serializable idQueried = null;

    public EntityMode getEntityMode() {
        return null;
    }

    public Session getSession(EntityMode entityMode) {
        return this;
    }

    public void flush() throws HibernateException {
    }

    public void setFlushMode(FlushMode flushMode) {
    }

    public FlushMode getFlushMode() {
        return null;
    }

    public void setCacheMode(CacheMode cacheMode) {
    }

    public CacheMode getCacheMode() {
        return null;
    }

    public SessionFactory getSessionFactory() {
        return null;
    }

    public Connection connection() throws HibernateException {
        return null;
    }

    public Connection close() throws HibernateException {
        return null;
    }

    public void cancelQuery() throws HibernateException {
    }

    public boolean isOpen() {
        return false;
    }

    public boolean isConnected() {
        return false;
    }

    public boolean isDirty() throws HibernateException {
        return false;
    }

    public Serializable getIdentifier(Object o) throws HibernateException {
        return null;
    }

    public boolean contains(Object o) {
        return false;
    }

    public void evict(Object o) throws HibernateException {
    }

    public Object load(Class aClass, Serializable serializable, LockMode lockMode) throws HibernateException {
        return load(aClass, serializable);
    }

    public Object load(String s, Serializable serializable, LockMode lockMode) throws HibernateException {
        try {
            return load(Class.forName(s), serializable);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public Object load(Class aClass, Serializable serializable) throws HibernateException {
        this.loadClass = aClass;
        this.loadID = serializable;
        return null;
    }

    public Object load(String s, Serializable serializable) throws HibernateException {
        return null;
    }

    public void load(Object o, Serializable serializable) throws HibernateException {
    }

    public void replicate(Object o, ReplicationMode replicationMode) throws HibernateException {
    }

    public void replicate(String s, Object o, ReplicationMode replicationMode) throws HibernateException {
    }

    public Serializable save(Object o) throws HibernateException {
        savedObject = o;
        return null;
    }

    public Serializable save(String s, Object o) throws HibernateException {
        savedObject = o;
        return null;
    }

    public void saveOrUpdate(Object o) throws HibernateException {
        this.savedObject = o;
    }

    public void saveOrUpdate(String s, Object o) throws HibernateException {
        this.savedObject = o;
    }

    public void update(Object o) throws HibernateException {
    }

    public void update(String s, Object o) throws HibernateException {
    }

    public Object merge(Object o) throws HibernateException {
        return null;
    }

    public Object merge(String s, Object o) throws HibernateException {
        return null;
    }

    public void persist(Object o) throws HibernateException {
    }

    public void persist(String s, Object o) throws HibernateException {
    }

    public void delete(Object o) throws HibernateException {
        this.deletedObject = o;
    }

    public void delete(String s, Object o) throws HibernateException {
    }

    public void lock(Object o, LockMode lockMode) throws HibernateException {
    }

    public void lock(String s, Object o, LockMode lockMode) throws HibernateException {
    }

    public void refresh(Object o) throws HibernateException {
    }

    public void refresh(Object o, LockMode lockMode) throws HibernateException {
    }

    public LockMode getCurrentLockMode(Object o) throws HibernateException {
        return null;
    }

    public Transaction beginTransaction() throws HibernateException {
        currentTransaction = new MockTransaction();
        return currentTransaction;
    }

    public Transaction getTransaction() {
        return currentTransaction;
    }

    public Criteria createCriteria(Class aClass) {
        this.loadClass = aClass;
        return mockCriteria;
    }

    public Criteria createCriteria(Class aClass, String s) {
        return createCriteria(aClass);
    }

    public Criteria createCriteria(String s) {
        try {
            return createCriteria(Class.forName(s));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public Criteria createCriteria(String s, String s1) {
        return createCriteria(s);
    }

    public Query createQuery(String s) throws HibernateException {
        return null;
    }

    public SQLQuery createSQLQuery(String s) throws HibernateException {
        return null;
    }

    public Query createFilter(Object o, String s) throws HibernateException {
        return null;
    }

    public Query getNamedQuery(String s) throws HibernateException {
        return null;
    }

    public void clear() {
    }

    public void setQueryObject(Object queryObject) {
        this.queryObject = queryObject;
    }

    public Class getClassQueried() {
        return classQueried;
    }

    public Serializable getIdQueried() {
        return idQueried;
    }

    public Object get(Class aClass, Serializable serializable) throws HibernateException {
        classQueried = aClass;
        idQueried = serializable;
        return queryObject;
    }

    public Object get(Class aClass, Serializable serializable, LockMode lockMode) throws HibernateException {
        return get(aClass, serializable);
    }

    public Object get(String s, Serializable serializable) throws HibernateException {
        try {
            classQueried = Class.forName(s);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        idQueried = serializable;
        return queryObject;
    }

    public Object get(String s, Serializable serializable, LockMode lockMode) throws HibernateException {
        return get(s, serializable);
    }

    public String getEntityName(Object o) throws HibernateException {
        return null;
    }

    public Filter enableFilter(String s) {
        return null;
    }

    public Filter getEnabledFilter(String s) {
        return null;
    }

    public void disableFilter(String s) {
    }

    public SessionStatistics getStatistics() {
        return null;
    }

    public void setReadOnly(Object o, boolean b) {
    }

    public Connection disconnect() throws HibernateException {
        return null;
    }

    public void reconnect() throws HibernateException {
    }

    public void reconnect(Connection connection) throws HibernateException {
    }

    public Class getLoadClass() {
        return loadClass;
    }

    public Object getSavedObject() {
        return savedObject;
    }

    public Object getDeletedObject() {
        return deletedObject;
    }

    public MockCriteria getMockHibernateCriteria() {
        return mockCriteria;
    }

    public Serializable getLoadID() {
        return loadID;
    }
}