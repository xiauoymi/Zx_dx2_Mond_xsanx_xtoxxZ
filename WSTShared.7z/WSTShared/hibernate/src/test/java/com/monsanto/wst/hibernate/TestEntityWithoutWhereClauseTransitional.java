package com.monsanto.wst.hibernate;

import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
/*
 TestEntityWithoutWhereClauseTransitional was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

@SuppressWarnings({"deprecation"})
@Entity
@AccessType("field")
@Table(schema="TTS", name="HIBERNATE_TEST")
@TemporaryTrueDelete
public class TestEntityWithoutWhereClauseTransitional {
  @Id
  private String id;

  public TestEntityWithoutWhereClauseTransitional() {
  }

  public TestEntityWithoutWhereClauseTransitional(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }
}
