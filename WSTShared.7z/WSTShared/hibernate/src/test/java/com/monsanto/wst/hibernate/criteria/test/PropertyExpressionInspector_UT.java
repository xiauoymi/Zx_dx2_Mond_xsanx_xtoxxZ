package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.SimpleExpression;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.PropertyExpression;
import com.monsanto.wst.hibernate.criteria.PropertyExpressionInspector;
/*
 PropertyExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class PropertyExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName1";
  private static final String testPropertyName2 = "myPropName2";
  private static final PropertyExpression expressionEq = Expression.eqProperty(testPropertyName1, testPropertyName2);
  private static final PropertyExpression expressionGe = Expression.geProperty(testPropertyName1, testPropertyName2);
  private static final PropertyExpression expressionLe = Expression.leProperty(testPropertyName1, testPropertyName2);
  private static final PropertyExpression expressionLt = Expression.ltProperty(testPropertyName1, testPropertyName2);
  private static final PropertyExpression expressionGt= Expression.gtProperty(testPropertyName1, testPropertyName2);
  private static final PropertyExpression expressionNe= Expression.neProperty(testPropertyName1, testPropertyName2);

  private PropertyExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new PropertyExpressionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionEq));
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionGe));
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionLe));
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionLt));
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionGt));
    assertEquals(testPropertyName1, inspector.getPropertyName(expressionNe));
  }

  public void testCanGetOp() throws Exception {
    assertEquals("=", inspector.getOp(expressionEq));
    assertEquals(">=", inspector.getOp(expressionGe));
    assertEquals("<=", inspector.getOp(expressionLe));
    assertEquals("<", inspector.getOp(expressionLt));
    assertEquals(">", inspector.getOp(expressionGt));
    assertEquals("<>", inspector.getOp(expressionNe));
  }

  public void testCanGetOtherProperty() throws Exception {
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionEq));
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionGe));
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionLe));
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionLt));
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionGt));
    assertEquals(testPropertyName2, inspector.getOtherPropertyName(expressionNe));
  }
}

