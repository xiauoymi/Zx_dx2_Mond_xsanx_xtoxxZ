package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.*;
import com.monsanto.wst.hibernate.criteria.PropertyExpressionInspector;
import com.monsanto.wst.hibernate.criteria.LogicalExpressionInspector;
/*
 LogicalExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class LogicalExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName1";
  private static final String testPropertyName2 = "myPropName2";
  private static final String testValue1 = "HELLO";
  private static final String testValue2 = "WORLD";
  private static final Criterion testCriteria1 = Expression.eq(testPropertyName1, testValue1);
  private static final Criterion testCriteria2 = Expression.eq(testPropertyName2, testValue2);
  private static final LogicalExpression expressionAnd = Expression.and(testCriteria1, testCriteria2);
  private static final LogicalExpression expressionOr = Expression.or(testCriteria1, testCriteria2);

  private LogicalExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new LogicalExpressionInspector();
  }

  public void testCanGetLHSCriterion() throws Exception {
    assertEquals(testCriteria1, inspector.getLeftCriterion(expressionAnd));
    assertEquals(testCriteria1, inspector.getLeftCriterion(expressionOr));
  }

  public void testCanGetOp() throws Exception {
    assertEquals("and", inspector.getOp(expressionAnd));
    assertEquals("or", inspector.getOp(expressionOr));
  }

  public void testCanGetRHSCriterion() throws Exception {
    assertEquals(testCriteria2, inspector.getRightCriterion(expressionAnd));
    assertEquals(testCriteria2, inspector.getRightCriterion(expressionOr));
  }
}

