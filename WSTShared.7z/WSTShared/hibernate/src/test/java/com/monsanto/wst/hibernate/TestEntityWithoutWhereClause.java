package com.monsanto.wst.hibernate;

import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 TestEntityWithoutWhereClause was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

@Entity
@AccessType("field")
@Table(schema="TTS", name="HIBERNATE_TEST")
@TrueDelete(reason="For testing of pseudo-delete functionality", approval = "kjjohn2")
public class TestEntityWithoutWhereClause {
  @Id
  private String id;

  @Column(name = "IS_DELETED")
  private String isDeleted;

  public TestEntityWithoutWhereClause() {
  }

  public TestEntityWithoutWhereClause(String id) {
    this.id = id;
    this.isDeleted = "N";
  }

  public String getId() {
    return id;
  }

  public String getDeleted() {
    return isDeleted;
  }
}

