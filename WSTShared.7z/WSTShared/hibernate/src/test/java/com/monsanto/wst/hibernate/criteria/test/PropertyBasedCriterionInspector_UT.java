package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.*;
import com.monsanto.wst.hibernate.criteria.PropertyBasedCriterionInspector;
/*
 PropertyBasedCriterionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class PropertyBasedCriterionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName";
  private static final String testPropertyName2 = "myPropName2";
  private static final String testPropertyName3 = "myPropName3";
  private static final String testPropertyName4 = "myPropName4";
  private static final NullExpression expression1 = (NullExpression) Expression.isNull(testPropertyName1);
  private static final NotNullExpression expression2 = (NotNullExpression) Expression.isNotNull(testPropertyName2);
  private static final EmptyExpression expression3 = (EmptyExpression) Expression.isEmpty(testPropertyName3);
  private static final NotEmptyExpression expression4 = (NotEmptyExpression) Expression.isNotEmpty(testPropertyName4);

  private PropertyBasedCriterionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new PropertyBasedCriterionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName1, inspector.getPropertyName(expression1));
    assertEquals(testPropertyName2, inspector.getPropertyName(expression2));
    assertEquals(testPropertyName3, inspector.getPropertyName(expression3));
    assertEquals(testPropertyName4, inspector.getPropertyName(expression4));
  }
}
