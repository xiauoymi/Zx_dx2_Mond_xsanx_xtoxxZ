package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.PropertyExpression;
/*
 PropertyExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class PropertyExpressionInspector extends PropertyBasedCriterionInspector {

  public String getOtherPropertyName(PropertyExpression expression) {
    return (String) getValueWithReflection(expression, "otherPropertyName");
  }

  public String getOp(PropertyExpression expression) {
    return (String) getValueWithReflection(expression, "op");
  }
}
