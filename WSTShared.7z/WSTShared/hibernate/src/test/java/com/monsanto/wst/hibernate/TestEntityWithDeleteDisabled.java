package com.monsanto.wst.hibernate;

import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
/*
 TestEntityWithDeleteDisabled was created on Aug 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
@Table(schema="TTS", name="HIBERNATE_TEST")
@NoDeleteAllowed
public class TestEntityWithDeleteDisabled {
  @Id
  private String id;

  public TestEntityWithDeleteDisabled() {
  }

  public TestEntityWithDeleteDisabled(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }
}
