package com.monsanto.wst.hibernate.mock;

import org.hibernate.*;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Expression;

import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
/*
 MockCriteria was created on Aug 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockCriteria implements Criteria {
  private final List<Criterion> criteria = new ArrayList<Criterion>();
  private final List<Order> orderings = new ArrayList<Order>();
  private List results = Collections.emptyList();
  private boolean listCalled = false;

  public List<Criterion> getCriteria() {
    return criteria;
  }

  public List<Order> getOrderings() {
    return orderings;
  }

  public void setResults(List results) {
    this.results = results;
  }

  public List list() throws HibernateException {
    listCalled = true;
    return results;
  }

  public boolean wasAddCalled() {
    return !criteria.isEmpty();
  }

  public boolean wasListCalled() {
    return listCalled;
  }

  public Criteria setProjection(Projection projection) {
    return this;
  }

  public Criteria add(Criterion criterion) {
    criteria.add(criterion);
    return this;
  }

  public Criteria addOrder(Order order) {
    orderings.add(order);
    return this;
  }

  public String getAlias() {
    return null;
  }

  public Criteria setFetchMode(String associationPath, FetchMode mode) throws HibernateException {
    return this;
  }

  public Criteria setLockMode(LockMode lockMode) {
    return this;
  }

  public Criteria setLockMode(String alias, LockMode lockMode) {
    return this;
  }

  public Criteria createAlias(String associationPath, String alias) throws HibernateException {
    return this;
  }

  public Criteria createAlias(String associationPath, String alias, int joinType) throws HibernateException {
    return this;
  }

  public Criteria createCriteria(String associationPath) throws HibernateException {
    return this;
  }

  public Criteria createCriteria(String associationPath, int joinType) throws HibernateException {
    return this;
  }

  public Criteria createCriteria(String associationPath, String alias) throws HibernateException {
    return this;
  }

  public Criteria createCriteria(String associationPath, String alias, int joinType) throws HibernateException {
    return this;
  }

  public Criteria setResultTransformer(ResultTransformer resultTransformer) {
    return this;
  }

  public Criteria setMaxResults(int maxResults) {
    return this;
  }

  public Criteria setFirstResult(int firstResult) {
    return this;
  }

  public Criteria setFetchSize(int fetchSize) {
    return this;
  }

  public Criteria setTimeout(int timeout) {
    return this;
  }

  public Criteria setCacheable(boolean cacheable) {
    return this;
  }

  public Criteria setCacheRegion(String cacheRegion) {
    return this;
  }

  public Criteria setComment(String comment) {
    return this;
  }

  public Criteria setFlushMode(FlushMode flushMode) {
    return this;
  }

  public Criteria setCacheMode(CacheMode cacheMode) {
    return this;
  }

  public ScrollableResults scroll() throws HibernateException {
    return null;
  }

  public ScrollableResults scroll(ScrollMode scrollMode) throws HibernateException {
    return null;
  }

  public Object uniqueResult() throws HibernateException {
    return null;
  }
}
