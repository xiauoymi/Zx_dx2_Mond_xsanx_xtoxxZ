package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;
import org.hibernate.criterion.PropertyExpression;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.SizeExpression;
import com.monsanto.wst.hibernate.criteria.PropertyExpressionInspector;
import com.monsanto.wst.hibernate.criteria.SizeExpressionInspector;
/*
 SizeExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class SizeExpressionInspector_UT extends TestCase {
  private static final String testPropertyName = "myPropName1";
  private static final int testSize = 123;

  private static final SizeExpression expressionEq = (SizeExpression) Expression.sizeEq(testPropertyName, testSize);
  private static final SizeExpression expressionNe = (SizeExpression) Expression.sizeNe(testPropertyName, testSize);
  private static final SizeExpression expressionLt = (SizeExpression) Expression.sizeLt(testPropertyName, testSize);
  private static final SizeExpression expressionGt = (SizeExpression) Expression.sizeGt(testPropertyName, testSize);
  private static final SizeExpression expressionLe = (SizeExpression) Expression.sizeLe(testPropertyName, testSize);
  private static final SizeExpression expressionGe = (SizeExpression) Expression.sizeGe(testPropertyName, testSize);

  private SizeExpressionInspector inspector;

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new SizeExpressionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName, inspector.getPropertyName(expressionEq));
    assertEquals(testPropertyName, inspector.getPropertyName(expressionGe));
    assertEquals(testPropertyName, inspector.getPropertyName(expressionLe));
    assertEquals(testPropertyName, inspector.getPropertyName(expressionLt));
    assertEquals(testPropertyName, inspector.getPropertyName(expressionGt));
    assertEquals(testPropertyName, inspector.getPropertyName(expressionNe));
  }

  public void testCanGetOp() throws Exception {
    //note: these are backwards from how you might expect - talk to hibernate if you don't like it
    assertEquals("=", inspector.getOp(expressionEq));
    assertEquals("<=", inspector.getOp(expressionGe));
    assertEquals(">=", inspector.getOp(expressionLe));
    assertEquals(">", inspector.getOp(expressionLt));
    assertEquals("<", inspector.getOp(expressionGt));
    assertEquals("<>", inspector.getOp(expressionNe));
  }

  public void testCanSize() throws Exception {
    assertEquals(testSize, inspector.getSize(expressionEq));
    assertEquals(testSize, inspector.getSize(expressionGe));
    assertEquals(testSize, inspector.getSize(expressionLe));
    assertEquals(testSize, inspector.getSize(expressionLt));
    assertEquals(testSize, inspector.getSize(expressionGt));
    assertEquals(testSize, inspector.getSize(expressionNe));
  }
}
