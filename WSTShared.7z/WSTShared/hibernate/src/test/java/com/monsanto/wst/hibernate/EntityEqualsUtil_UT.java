package com.monsanto.wst.hibernate;

import junit.framework.TestCase;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class EntityEqualsUtil_UT extends TestCase {
    public void testNonEntityThrowsOnEqual() throws Exception {
        TestClassThatIsNotAnEntity testObj = new TestClassThatIsNotAnEntity();
        try {
            EntityEqualsUtil.identifierEquals(testObj, testObj);
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            //ignore expected exception
        }
    }

    public void testNoIdThrowsOnEquals() throws Exception {
        TestClassThatHasNoId testObj = new TestClassThatHasNoId();
        try {
            EntityEqualsUtil.identifierEquals(testObj, testObj);
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            //ignore expected exception
        }
    }

    public void testNonEntityThrowsOnHashCode() throws Exception {
        TestClassThatIsNotAnEntity testObj = new TestClassThatIsNotAnEntity();
        try {
            EntityEqualsUtil.identifierHashCode(testObj);
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            //ignore expected exception
        }
    }

    public void testNoIdThrowsOnHashcode() throws Exception {
        TestClassThatHasNoId testObj = new TestClassThatHasNoId();
        try {
            EntityEqualsUtil.identifierHashCode(testObj);
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            //ignore expected exception
        }
    }

    public void testEqualsIsReflexive() throws Exception {
        TestClass testObj = new TestClass(1, "ONE");
        assertTrue(EntityEqualsUtil.identifierEquals(testObj, testObj));
    }

    public void testTwoDifferentObjectsSameIdEquals() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        TestClass testObj2 = new TestClass(1, "TWO");
        assertTrue(EntityEqualsUtil.identifierEquals(testObj1, testObj2));
    }

    public void testTwoDifferentTypesNotEqual() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        Object testObj2 = "This is a test";
        assertFalse(EntityEqualsUtil.identifierEquals(testObj1, testObj2));
    }

    public void testObjectNotEqualsNull() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        assertFalse(EntityEqualsUtil.identifierEquals(testObj1, null));
    }

    public void testTwoDifferentObjectsTwoDifferentIdsNotEqual() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        TestClass testObj2 = new TestClass(2, "TWO");
        assertFalse(EntityEqualsUtil.identifierEquals(testObj1, testObj2));
    }

    public void testHashCodeForTwoDifferentObjectsSameIdAreEqual() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        TestClass testObj2 = new TestClass(1, "TWO");
        assertEquals(EntityEqualsUtil.identifierHashCode(testObj1), EntityEqualsUtil.identifierHashCode(testObj2));
    }

    public void testHashCodeForTwoDifferentObjectsSameDiffentIdNotEqual_SometimesAtLeast() throws Exception {
        TestClass testObj1 = new TestClass(1, "ONE");
        TestClass testObj2 = new TestClass(2, "TWO");
        assertFalse(EntityEqualsUtil.identifierHashCode(testObj1) == EntityEqualsUtil.identifierHashCode(testObj2));
    }


    private static class TestClassThatIsNotAnEntity {
        @Id
        private int id = 0;
    }

    @Entity
    private static class TestClassThatHasNoId {
        private int id = 0;
    }


    @Entity
    private static class TestClass {
        @Id
        public int id;

        private String nonIdField;

        private TestClass(int id, String nonIdField) {
            this.id = id;
            this.nonIdField = nonIdField;
        }
    }

    //todo need tests for EntityEqualsUtil_UT
}