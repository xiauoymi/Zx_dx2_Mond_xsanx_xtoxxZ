package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Junction;

import java.util.Collection;
/*
 JunctionExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class JunctionExpressionInspector extends CriterionInspector {
  public String getOp(Junction expression) {
    return (String) getValueWithReflection(expression, "op");
  }

  public Collection<Criterion> getCriteria(Junction junction) {
    return (Collection<Criterion>) getValueWithReflection(junction, "criteria");
  }
}
