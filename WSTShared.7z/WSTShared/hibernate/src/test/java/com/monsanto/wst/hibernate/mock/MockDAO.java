package com.monsanto.wst.hibernate.mock;

import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/*
 MockHibernateDAO was created on Aug 11, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockDAO<T, ID extends Serializable> implements GenericDAO<T, ID> {
    private ID idUsed = null;
    private boolean findAllCalled = false;
    private T queryValue = null;
    private String[] queryExecludeProperies = null;
    private List<T> savedItems = new ArrayList<T>();
    private List<T> deletedItems = new ArrayList<T>();
    private boolean beginTransactionCalled = false;
    private boolean commitCalled = false;
    private boolean findByPrimaryKeyCalled = false;
    private MockCriteria criteria = new MockCriteria();

    private final List<T> results;
    private Boolean sortOrder = null;
    private String sortKey = null;

    public MockDAO() {
        this(new ArrayList<T>(0));
    }

    public MockDAO(List<T> results) {
        this.results = results;
    }

    public ID getIdUsed() {
        return idUsed;
    }

    public boolean wasFindAllCalled() {
        return findAllCalled;
    }

    public T getQueryValue() {
        return queryValue;
    }

    public String[] getQueryExecludeProperies() {
        return queryExecludeProperies;
    }

    public boolean wasSaved(T entity) {
        return savedItems.contains(entity);
    }

    public boolean wasDeleted(T entity) {
        return deletedItems.contains(entity);
    }

    public int getNumSaved() {
        return savedItems.size();
    }

    public int getNumDeleted() {
        return deletedItems.size();
    }

    public boolean wasBeginTransactionCalled() {
        return beginTransactionCalled;
    }

    public boolean wasCommitCalled() {
        return commitCalled;
    }

    public T findByPrimaryKey(ID id) {
        idUsed = id;
        findByPrimaryKeyCalled = true;
        for (T result : results) {
            if (primaryKeyMatches(result, id)) {
                return result;
            }
        }

        return null;
    }

    private boolean primaryKeyMatches(T result, ID id) {
        try {
            Method idGetter = result.getClass().getMethod("getId");
            Object idReturned = idGetter.invoke(result);
            if (idReturned == null) {
                return false;
            } else {
                return id.equals(idReturned);
            }
        } catch (NoSuchMethodException e) {
            return false;
        } catch (InvocationTargetException e) {
            return false;
        } catch (IllegalAccessException e) {
            return false;
        }
    }

    public boolean wasFindByPrimaryKeyCalled() {
        return findByPrimaryKeyCalled;
    }

    public List<T> findAll(int startIndex, int fetchSize) {
        findAllCalled = true;
        return Collections.emptyList();
    }

    public List<T> findByExample(T exampleInstance, String[] excludeProperty) {
        queryValue = exampleInstance;
        queryExecludeProperies = excludeProperty;
        return Collections.emptyList();
    }

    public T save(T entity) {
        savedItems.add(entity);
        return entity;
    }

    public void delete(T entity) {
        deletedItems.add(entity);
    }

    public void beginTransaction() {
        beginTransactionCalled = true;
    }

    public void commitTransaction() {
        commitCalled = true;
    }

    public Criteria createCriteria() {
        return criteria;
    }

    public List<T> findAll(String key, boolean ascending) {
        sortOrder = ascending;
        sortKey = key;
        return findAll();
    }

    public MockCriteria getMockCriteria() {
        return criteria;
    }

    public void setMockCriteria(MockCriteria mockCriteria) {
        criteria = mockCriteria;
    }

    public List<T> findAll() {
        findAllCalled = true;
        return results;
    }

    public Boolean getSortOrder() {
        return sortOrder;
    }

    public String getSortKey() {
        return sortKey;
    }
}
