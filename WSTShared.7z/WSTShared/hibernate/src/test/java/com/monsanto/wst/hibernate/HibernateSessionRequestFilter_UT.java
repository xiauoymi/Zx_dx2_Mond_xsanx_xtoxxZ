package com.monsanto.wst.hibernate;

import junit.framework.TestCase;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;

import javax.servlet.*;
import java.util.Enumeration;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HibernateSessionRequestFilter_UT extends TestCase {
    private static final String TEST_APP_NAME = "mockApp";
    private MockHibernateFactory mockFactory;

    protected void setUp() throws Exception {
        super.setUp();
        mockFactory = new MockHibernateFactory();
        HibernateFactoryImpl.setInstance(TEST_APP_NAME, mockFactory);
    }

    public void testFilterCallsBeginTransAndCommit() throws ServletException, IOException {
        MockFilterChain mockChain = new MockFilterChain();
        FilterConfig mockConfig = new MockFilterConfig(TEST_APP_NAME);
        Filter filter = new HibernateSessionRequestFilter();
        filter.init(mockConfig);

        assertFalse(mockFactory.wasBeginTransactionCalled());
        assertFalse(mockChain.wasCalled());
        assertFalse(mockFactory.wasCommitTransactionCalled());

        filter.doFilter(null, null, mockChain);

        assertTrue(mockFactory.wasBeginTransactionCalled());
        assertTrue(mockChain.wasCalled());
        assertTrue(mockFactory.wasCommitTransactionCalled());
    }

    private static class MockFilterChain implements FilterChain {
        private boolean wasCalled = false;

        public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException, ServletException {
            wasCalled = true;
        }

        public boolean wasCalled() {
            return wasCalled;
        }
    }

    private static class MockFilterConfig implements FilterConfig {
        private final String appName;

        public MockFilterConfig(String appName) {
            this.appName = appName;
        }

        public String getFilterName() {
            return "MOCK";
        }

        public ServletContext getServletContext() {
            return null;
        }

        public String getInitParameter(String s) {
            return appName;
        }

        public Enumeration getInitParameterNames() {
            List<String> paramNames = new ArrayList<String>(1);
            paramNames.add("app-name");
            return new ListEnumeration(paramNames);
        }
    }

    static class ListEnumeration implements Enumeration {
        private final List<?> list;
        private int position;

        public ListEnumeration(List<?> list) {
            this.list = list;
            this.position = 0;
        }

        public boolean hasMoreElements() {
            return position < list.size();
        }

        public Object nextElement() {
            Object returnValue = list.get(position);
            position++;
            return returnValue;
        }
    }

}

