package com.monsanto.wst.hibernate.criteria;

import org.hibernate.criterion.SizeExpression;
/*
 SizeExpressionInspector was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class SizeExpressionInspector extends PropertyBasedCriterionInspector {
  public String getOp(SizeExpression expression) {
    return (String) getValueWithReflection(expression, "op");
  }

  public int getSize(SizeExpression expression) {
    return getIntValueWithReflection(expression, "size");
  }
}
