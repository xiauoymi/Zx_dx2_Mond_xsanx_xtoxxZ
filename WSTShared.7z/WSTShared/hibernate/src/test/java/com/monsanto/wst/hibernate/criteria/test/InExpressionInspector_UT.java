package com.monsanto.wst.hibernate.criteria.test;

import junit.framework.TestCase;

import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import org.hibernate.criterion.InExpression;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.IdentifierEqExpression;
import com.monsanto.wst.hibernate.criteria.InExpressionInspector;
import com.monsanto.wst.hibernate.criteria.IdentifierEqualsExpressionInspector;
/*
 InExpressionInspector_UT was created on Sep 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class InExpressionInspector_UT extends TestCase {
  private static final String testPropertyName1 = "myPropName";
  private static final String testPropertyName2 = "myPropName";
  private static final long TEST_NUM_1 = 1L;
  private static final long TEST_NUM_2 = 2L;
  private static final long TEST_NUM_3 = 333L;
  private static final long TEST_NUM_4 = 1234L;
  private static final Object[] testValue1 = {TEST_NUM_1, TEST_NUM_2, TEST_NUM_3, TEST_NUM_4};
  private static final Collection<Long> testValue2 = getTestValueCollection();

  private static final InExpression exprInArray = (InExpression) Expression.in(testPropertyName1, testValue1);
  private static final InExpression exprInCollection = (InExpression) Expression.in(testPropertyName2, testValue2);

  private InExpressionInspector inspector;

  private static Collection<Long> getTestValueCollection() {
    List<Long> testCollection = new ArrayList<Long>();
    testCollection.add(TEST_NUM_1);
    testCollection.add(TEST_NUM_2);
    testCollection.add(TEST_NUM_3);
    testCollection.add(TEST_NUM_4);
    return testCollection;
  }

  protected void setUp() throws Exception {
    super.setUp();
    inspector = new InExpressionInspector();
  }

  public void testCanGetPropertyName() throws Exception {
    assertEquals(testPropertyName1, inspector.getPropertyName(exprInArray));
    assertEquals(testPropertyName2, inspector.getPropertyName(exprInCollection));
  }

  public void testCanGetValues() throws Exception {
    Object[] inArrayValues = inspector.getValues(exprInArray);
    Object[] inCollectionValues = inspector.getValues(exprInArray);
    assertTrue(Arrays.equals(testValue1, inCollectionValues));
    assertTrue(Arrays.equals(testValue1, inArrayValues));
  }
}

