package com.monsanto.wst.administerreferencedata.builder.tests;

import junit.framework.TestCase;
import com.monsanto.wst.administerreferencedata.builder.DisplayLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;

/*
 DisplayLookupDBBuilder_UT was created on Mar 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */

public class DisplayLookupDBBuilder_UT extends TestCase {

  public void testNullXmlPathCausesNPE() throws Exception {
    try {
      new DisplayLookupDBBuilder(null);
      fail("Expected exception not received");
    } catch (NullPointerException IGNORE) {
      // ignore expected exception
    }
  }

  public void testNonNullXmlPathDoesntCausesNPE() throws Exception {
    DisplayLookupDBBuilder builder = new DisplayLookupDBBuilder(LookupMapConstants.LOOKUP_XML_LOCATION);
    assertNotNull(builder);
  }
}