package com.monsanto.wst.administerreferencedata.services.test;

import junit.framework.TestCase;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupServiceDBImpl;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
/*
 SequecneLookupServiceDBImpl_UT was created on Mar 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
*/
public class SequecneLookupServiceDBImpl_AT extends TestCase {
  public void testTemporary() throws Exception {
    //todo fix path issues with testSequenceNumberGoesUpEachTime and re-enable
  }

/*
  public void testSequenceNumberGoesUpEachTime() throws Exception {
    SequenceLookupService service = new SequenceLookupServiceDBImpl(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    long firstCall = Long.parseLong(service.getSequence());
    long secondCall = Long.parseLong(service.getSequence());
    assertTrue(firstCall >= 0);
    assertTrue(secondCall > firstCall);
  }
*/
}
