package com.monsanto.wst.administerreferencedata.factory.tests;

import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.ProcessLookupDAO;
import com.monsanto.wst.administerreferencedata.dao.SaveLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.dao.UpdateLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.factory.ProcessLookupDAOFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 4:12:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessLookupDAOFactory_UT extends TestCase {

    public void testCreate() throws Exception {
      ProcessLookupDAOFactory factory = new ProcessLookupDAOFactory(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
      assertNotNull(factory);
    }

    public void testProcessDAOImplForADDAction() throws Exception {
        ProcessLookupDAOFactory factory = new ProcessLookupDAOFactory(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        ProcessLookupDAO processLookupDAO = factory.getProcessDAO(TestLookupMapConstants.ADD);
        assertNotNull(processLookupDAO);
        assertEquals(SaveLookupDAOImpl.class, processLookupDAO.getClass());
    }

    public void testProcessDAOImplForEDITAction() throws Exception {
      ProcessLookupDAOFactory factory = new ProcessLookupDAOFactory(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        ProcessLookupDAO processLookupDAO = factory.getProcessDAO(TestLookupMapConstants.EDIT);
        assertNotNull(processLookupDAO);
        assertEquals(UpdateLookupDAOImpl.class, processLookupDAO.getClass());
    }
}
