package com.monsanto.wst.administerreferencedata.model.tests;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 9:55:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class LookupData_UT extends TestCase {

	public static final String PRIMARY_RELATIONSHIP_TYPE = TestLookupMapConstants.TEST_TABLE;

	public void testCreate() throws Exception {
		LookupData lookupData = new LookupData(null,null,null,null,null,null);
		assertNotNull(lookupData);
	}
	public void testTestDataGettersAndSetters() throws Exception {
		LookupData lookupData = new LookupData();
		lookupData.setActive("Y");
		lookupData.setDescription("Test Description");
		lookupData.setErrorList(new ArrayList());
		lookupData.setId("123");
		lookupData.setModDate(new Date(0));
		lookupData.setModUser("FFBRAC");
		lookupData.setType("MyType");

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		assertEquals("Y", lookupData.getActive());
		assertEquals("Test Description", lookupData.getDescription());
		assertEquals(0, lookupData.getErrorList().size());
		assertEquals("123", lookupData.getId());
		assertEquals("FFBRAC", lookupData.getModUser());
		assertEquals("1969", formatter.format(lookupData.getModDate()));
		assertEquals("MyType", lookupData.getType());
	}
/*
    public void testUpdateLookupForADDActionWithErrors() throws Exception {
        helper.setRequestParameterValue(LookupMapConstants.PROCESS, LookupMapConstants.ADD);
        helper.setRequestParameterValue(LookupMapConstants.TABLE_NAME, PRIMARY_RELATIONSHIP_TYPE);
        LookupData lookupData = new MockLookupData(helper);
        assertEquals(1, ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST)).size());
        assertEquals("Please Fill in the Required Fields", ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST)).get(0));
        assertTrue(helper.wasSentTo(LookupMapConstants.UPDATE_LOOKUP_JSP));
        assertEquals("999", lookupData.getId());
        assertNull(lookupData.getType());
        assertNull(lookupData.getDescription());
        assertEquals("N", lookupData.getActive());
    }
*/

/*
    public void testUpdateLookupForADDActionWithNoErrors() throws Exception {
        helper.setRequestParameterValue(LookupMapConstants.PROCESS, LookupMapConstants.ADD);
        helper.setRequestParameterValue(LookupMapConstants.TABLE_NAME, PRIMARY_RELATIONSHIP_TYPE);
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_TYPE, "Type");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_ACTIVE, "Y");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_DESCRIPTION, "Desc");
        new MockLookupData(helper);
        assertEquals(1, ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_SUCCESS_LIST)).size());
        assertEquals("Lookup Saved SuccessFully", ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_SUCCESS_LIST)).get(0));
        assertTrue(helper.wasSentTo(LookupMapConstants.MAPPING_DISPLAY_SERVLET+"?selectedLookup="+LookupMapConstants.TEST_TABLE));
    }
*/

/*
    public void testUpdateLookupForEDITActionWithErrors() throws Exception {
        helper.setRequestParameterValue(LookupMapConstants.PROCESS, LookupMapConstants.EDIT);
        helper.setRequestParameterValue(LookupMapConstants.TABLE_NAME, PRIMARY_RELATIONSHIP_TYPE);
        helper.setRequestParameterValue(LookupMapConstants.TABLE_DISPLAY_NAME, "Primary Relationship Type");
        helper.setRequestParameterValue(LookupMapConstants.ID, "1");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_TYPE, "Type");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_ACTIVE, "Y");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_DESCRIPTION, "");
        LookupData lookupData = new LookupData(helper, new MockProcessLookupServiceDBImpl(), new MockSequenceLookupServiceImpl());
        assertEquals(1, ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST)).size());
        assertEquals("Please Fill in the Required Fields", ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST)).get(0));
        assertTrue(helper.wasSentTo(LookupMapConstants.UPDATE_LOOKUP_JSP));
        assertEquals("1", lookupData.getId());
        assertEquals("Type",lookupData.getType());
        assertEquals("",lookupData.getDescription());
        assertEquals("Y", lookupData.getActive());
    }
*/

/*
    public void testUpdateLookupForEDITActionWithNoErrors() throws Exception {
        helper.setRequestParameterValue(LookupMapConstants.PROCESS, LookupMapConstants.EDIT);
        helper.setRequestParameterValue(LookupMapConstants.TABLE_NAME, PRIMARY_RELATIONSHIP_TYPE);
        helper.setRequestParameterValue(LookupMapConstants.ID, "100");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_TYPE, "Type1");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_ACTIVE, "N");
        helper.setRequestParameterValue(LookupMapConstants.MAPPING_DESCRIPTION, "Desc1");
        new MockLookupData(helper);
        assertEquals(1, ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_SUCCESS_LIST)).size());
        assertEquals("Lookup Saved SuccessFully", ((List)helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_SUCCESS_LIST)).get(0));
        assertTrue(helper.wasSentTo(LookupMapConstants.MAPPING_DISPLAY_SERVLET+"?selectedLookup="+LookupMapConstants.TEST_TABLE));
    }

*/

}
