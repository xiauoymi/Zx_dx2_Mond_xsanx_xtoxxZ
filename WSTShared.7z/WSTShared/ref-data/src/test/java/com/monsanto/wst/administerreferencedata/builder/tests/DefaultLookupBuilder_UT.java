package com.monsanto.wst.administerreferencedata.builder.tests;

import com.monsanto.wst.administerreferencedata.builder.DefaultLookupBuilder;
import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.BaseModel;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 11:45:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultLookupBuilder_UT extends TestCase {

    GenericLookupBuilder genericLookupBuilder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);

    public void testCreate() throws Exception {
        DefaultLookupBuilder builder = new DefaultLookupBuilder();
        assertNotNull(builder);
    }

    public void testGetDefaultBaseModelForNULLSelectedLookup() throws Exception {
        BaseModel defaultLookup = null;
        DefaultLookupBuilder builder = new DefaultLookupBuilder();
        try {
            defaultLookup = builder.createDefaultLookup(genericLookupBuilder.buildLookups(), TestLookupMapConstants.TEST_TABLE);
        } catch (GenericLookupBuilderException e) {
            assertFalse(true);
        }
        assertEquals(TestLookupMapConstants.TEST_TABLE, defaultLookup.getId());
        assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, defaultLookup.getValue());
    }

    public void testGetDefaultBaseModelForEmptySelectedLookup() throws Exception {
        BaseModel defaultLookup = null;
        DefaultLookupBuilder builder = new DefaultLookupBuilder();
        try {
            defaultLookup = builder.createDefaultLookup(genericLookupBuilder.buildLookups(), TestLookupMapConstants.TEST_TABLE);
        } catch (GenericLookupBuilderException e) {
            assertFalse(true);
        }
        assertEquals(TestLookupMapConstants.TEST_TABLE, defaultLookup.getId());
        assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, defaultLookup.getValue());
    }

    public void testGetDefaultBaseModelForSelectedLookup() throws Exception {
        BaseModel defaultLookup = null;
        DefaultLookupBuilder builder = new DefaultLookupBuilder();
        try {
            defaultLookup = builder.createDefaultLookup(genericLookupBuilder.buildLookups(), TestLookupMapConstants.TEST_TABLE);
        } catch (GenericLookupBuilderException e) {
            assertFalse(true);
        }
        assertEquals(TestLookupMapConstants.TEST_TABLE, defaultLookup.getId());
        assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, defaultLookup.getValue());
    }
}
