package com.monsanto.wst.administerreferencedata.constants.test;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
/*
 TestLookupMapConstants was created on Mar 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public interface TestLookupMapConstants extends LookupMapConstants {
  String TEST_LOOKUP_XML_LOCATION = "com/monsanto/wst/administerreferencedata/constants/test/lookup.xml";
  String TEST_TABLE = "REGION";
  String TEST_TABLE_DISPLAY_NAME = "Region";
  String TEST_TABLE_ID = "REGION_ID";
  String TEST_TABLE_ID_DISPLAY_NAME = "Region Id";
  String TEST_TABLE_NAME_DISPLAY_NAME = "Region";
  String TEST_TABLE_NAME = "REGION";
  String TEST_TABLE_INSERT = "INSERT INTO REGION(REGION_ID,REGION,ACTIVE,DESCRIPTION,MOD_USER,MOD_DATE) VALUES (?,?,?,?,?,?)";
  String TEST_TABLE_UPDATE = "UPDATE REGION SET REGION=?,ACTIVE=?,DESCRIPTION=?,MOD_USER=?,MOD_DATE=? WHERE REGION_ID =?";
  String TEST_TABLE_II = "STATUS";
  String TEST_TABLE_II_DISPLAY_NAME = "Status";
  String TEST_TABLE_II_ID = "STATUS_ID";
  String TEST_TABLE_II_ID_DISPLAY_NAME = "Status Id";
  String TEST_TABLE_II_NAME_DISPLAY_NAME = "Status";
  String TEST_TABLE_II_NAME = "STATUS";
  String TEST_REFDATA_TABLE = "SHARED_CODE.REFDATA";
}
