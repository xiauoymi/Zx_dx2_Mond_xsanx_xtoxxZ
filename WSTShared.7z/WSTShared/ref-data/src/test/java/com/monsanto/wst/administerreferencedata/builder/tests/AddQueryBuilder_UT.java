package com.monsanto.wst.administerreferencedata.builder.tests;

import com.monsanto.wst.administerreferencedata.builder.AddQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.LookupObjectBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:14:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddQueryBuilder_UT extends TestCase {

    private String addLookupQuery = TestLookupMapConstants.TEST_TABLE_INSERT;

    public void testCreate() throws Exception {
        AddQueryBuilder builder = new AddQueryBuilder();
        assertNotNull(builder);
    }

    public void testBuildQuery() throws Exception, GenericLookupBuilderException {
        AddQueryBuilder builder = new AddQueryBuilder();
        String query = builder.buildQuery(LookupObjectBuilder.getLookupObject(TestLookupMapConstants.TEST_TABLE, TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION));
        assertEquals(addLookupQuery, query);
    }


}
