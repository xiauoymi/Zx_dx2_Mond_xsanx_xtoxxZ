package com.monsanto.wst.administerreferencedata.services.test;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.DeleteLookupDAO;
import com.monsanto.wst.administerreferencedata.dao.mock.MockDeleteLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.DeleteLookupServiceImpl;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 11:00:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteLookupServiceImpl_UT extends TestCase {

    public void testCreate() throws Exception {
        DeleteLookupServiceImpl deleteLookupService = new DeleteLookupServiceImpl(null, TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        assertNotNull(deleteLookupService);
    }

    public void testdeleteLookupDataThrowsNoException() throws Exception {
        int rowsDeleted = 0;
        DeleteLookupServiceImpl deleteLookupService = new DeleteLookupServiceImpl(new MockDeleteLookupDAOImpl(), TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        try {
            rowsDeleted = deleteLookupService.deleteLookupData("1", TestLookupMapConstants.TEST_TABLE);
        } catch (GenericLookupBuilderException e) {
            assertFalse(true);
        }
        assertEquals(1, rowsDeleted);
    }

    public void testdeleteLookupDataThrowsException() throws Exception {
        int rowsDeleted = 0;
        DeleteLookupServiceImpl deleteLookupService = new ExceptionDeleteLookupServiceImpl(new MockDeleteLookupDAOImpl());
        try {
            rowsDeleted = deleteLookupService.deleteLookupData("1", "INVALID_TYPE");
            fail("This should have thrown Exception");
        } catch (GenericLookupBuilderException e) {
            assertEquals("Could Not delete data", e.getMessage());
        }
        assertEquals(0, rowsDeleted);
    }

    private class ExceptionDeleteLookupServiceImpl extends DeleteLookupServiceImpl{
        public ExceptionDeleteLookupServiceImpl(DeleteLookupDAO deleteLookupDAO) {
            super(deleteLookupDAO, TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        }

        public int deleteLookupData(String id, String selectedLookup) throws GenericLookupBuilderException {
            throw new GenericLookupBuilderException("Could Not delete data");
        }
    }
}
