package com.monsanto.wst.administerreferencedata.services.test;

import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupServiceDBImpl;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 25, 2006
 * Time: 9:27:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class SequenceLookupService_UT extends TestCase {

    public void testCreate() throws Exception {
        SequenceLookupServiceDBImpl service = new SequenceLookupServiceDBImpl(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        assertNotNull(service);
    }

    public void testGetSequenceNumber() throws Exception {
        SequenceLookupServiceDBImpl service = new TestSequenceLookupServiceDBImpl(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        String sequence = service.getSequence();
        assertNotNull(sequence);
    }

    private class TestSequenceLookupServiceDBImpl extends SequenceLookupServiceDBImpl{
	    public TestSequenceLookupServiceDBImpl(String xmlPath) {
		    super(xmlPath);
	    }

	    public String getSequenceIdFromDB(String dbSequenceName) {
	        return "999";
	    }
    }


}
