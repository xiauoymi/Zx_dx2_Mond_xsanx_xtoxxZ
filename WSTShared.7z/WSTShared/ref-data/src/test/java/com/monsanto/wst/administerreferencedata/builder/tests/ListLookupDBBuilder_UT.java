package com.monsanto.wst.administerreferencedata.builder.tests;

import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.builder.ListLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.mock.MockListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.DisplayLookupDataServiceImpl;
import junit.framework.TestCase;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 4:14:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class ListLookupDBBuilder_UT extends TestCase {

    private GenericLookupBuilder genericLookupBuilder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);

    public void testCreate() throws Exception {
        ListLookupDBBuilder builder = new ListLookupDBBuilder(null);
        assertNotNull(builder);
    }

    public void testCreateMapForSelectedLookupTable() throws Exception {
        Map lookupDataMap = null;
        ListLookupDBBuilder builder = new ListLookupDBBuilder(new DisplayLookupDataServiceImpl(new MockListDBLookupDataDAOImpl()));
        try {
            lookupDataMap = builder.listSelectedLookupData(genericLookupBuilder.buildLookups(), TestLookupMapConstants.TEST_TABLE);
        } catch (GenericLookupBuilderException e) {
            assertFalse(true);
        }
        assertNotNull(lookupDataMap);
        assertEquals(3, lookupDataMap.size());
    }
}
