package com.monsanto.wst.administerreferencedata.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.controller.PreUpdateLookupController;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.DisplayModel;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 1:55:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class PreUpdateLookupController_UT extends TestCase {

    MockUCCHelper helper = null;;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        PreUpdateLookupController controller = new PreUpdateLookupController();
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        assertNotNull(controller);
    }

    public void testCreateLookupObjectForADDAction() throws Exception {
        PreUpdateLookupController controller = new PreUpdateLookupController();
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        helper.setRequestParameterValue(TestLookupMapConstants.PROCESS,"ADD");
        helper.setRequestParameterValue(TestLookupMapConstants.SELECTED_LOOKUP, TestLookupMapConstants.TEST_TABLE);
        controller.run(helper);
        LookUpObject lookUpObject = (LookUpObject) helper.getSessionParameter(TestLookupMapConstants.LOOKUP_DATA);
        assertNotNull(lookUpObject);
        assertEquals(6, lookUpObject.getColumnMappingList().size());
        assertEquals(TestLookupMapConstants.TEST_TABLE, lookUpObject.getTableName());
        assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, lookUpObject.getTableDisplayName());
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(0)).getObjectValue());
        assertEquals(TestLookupMapConstants.TEST_TABLE_ID_DISPLAY_NAME, (((DisplayModel)lookUpObject.getColumnMappingList().get(0)).getColumnMapping().getColumnDisplayName()));
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(1)).getObjectValue());
        assertEquals(TestLookupMapConstants.TEST_TABLE_NAME_DISPLAY_NAME, (((DisplayModel)lookUpObject.getColumnMappingList().get(1)).getColumnMapping().getColumnDisplayName()));
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(2)).getObjectValue());
        assertEquals("Active", (((DisplayModel)lookUpObject.getColumnMappingList().get(2)).getColumnMapping().getColumnDisplayName()));
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(3)).getObjectValue());
        assertEquals("Description", (((DisplayModel)lookUpObject.getColumnMappingList().get(3)).getColumnMapping().getColumnDisplayName()));
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(4)).getObjectValue());
        assertEquals("Last Modified By", (((DisplayModel)lookUpObject.getColumnMappingList().get(4)).getColumnMapping().getColumnDisplayName()));
        assertNull(((DisplayModel)lookUpObject.getColumnMappingList().get(5)).getObjectValue());
        assertEquals("Last Modified Date", (((DisplayModel)lookUpObject.getColumnMappingList().get(5)).getColumnMapping().getColumnDisplayName()));
        assertTrue(helper.wasSentTo(TestLookupMapConstants.UPDATE_LOOKUP_JSP));
    }

    public void testCreateLookupObjectForEDITAction() throws Exception {
        PreUpdateLookupController controller = new PreUpdateLookupController();
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        helper.setRequestParameterValue(TestLookupMapConstants.PROCESS,"EDIT");
        helper.setRequestParameterValue(TestLookupMapConstants.SELECTED_LOOKUP, TestLookupMapConstants.TEST_TABLE);
        helper.setRequestParameterValue(TestLookupMapConstants.ID, "1");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_TYPE, "Type");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_ACTIVE, "Y");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_DESCRIPTION, "Description");
        controller.run(helper);
        LookUpObject lookUpObject = (LookUpObject) helper.getSessionParameter(TestLookupMapConstants.LOOKUP_DATA);
        assertNotNull(lookUpObject);
        assertEquals(6, lookUpObject.getColumnMappingList().size());
        assertEquals(TestLookupMapConstants.TEST_TABLE, lookUpObject.getTableName());
        assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, lookUpObject.getTableDisplayName());
        assertEquals("1",(((DisplayModel)lookUpObject.getColumnMappingList().get(0)).getObjectValue()));
        assertEquals(TestLookupMapConstants.TEST_TABLE_ID_DISPLAY_NAME, (((DisplayModel)lookUpObject.getColumnMappingList().get(0)).getColumnMapping().getColumnDisplayName()));
        assertEquals("Type",(((DisplayModel)lookUpObject.getColumnMappingList().get(1)).getObjectValue()));
        assertEquals(TestLookupMapConstants.TEST_TABLE_NAME_DISPLAY_NAME, (((DisplayModel)lookUpObject.getColumnMappingList().get(1)).getColumnMapping().getColumnDisplayName()));
        assertEquals("Y",(((DisplayModel)lookUpObject.getColumnMappingList().get(2)).getObjectValue()));
        assertEquals("Active", (((DisplayModel)lookUpObject.getColumnMappingList().get(2)).getColumnMapping().getColumnDisplayName()));
        assertEquals("Description",(((DisplayModel)lookUpObject.getColumnMappingList().get(3)).getObjectValue()));
        assertEquals("Description", (((DisplayModel)lookUpObject.getColumnMappingList().get(3)).getColumnMapping().getColumnDisplayName()));
        assertEquals("ADMIN",(((DisplayModel)lookUpObject.getColumnMappingList().get(4)).getObjectValue()));
        assertEquals("Last Modified By", (((DisplayModel)lookUpObject.getColumnMappingList().get(4)).getColumnMapping().getColumnDisplayName()));
        assertEquals(new Date(System.currentTimeMillis()),(((DisplayModel)lookUpObject.getColumnMappingList().get(5)).getObjectValue()));
        assertEquals("Last Modified Date", (((DisplayModel)lookUpObject.getColumnMappingList().get(5)).getColumnMapping().getColumnDisplayName()));
        assertTrue(helper.wasSentTo(TestLookupMapConstants.UPDATE_LOOKUP_JSP));
    }

    public void testCreateLookupObjectForEDITActionThrowsException() throws Exception {
        PreUpdateLookupController controller = new ExceptionPreUpdateLookupController();
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        helper.setRequestParameterValue(TestLookupMapConstants.PROCESS,"EDIT");
        helper.setRequestParameterValue(TestLookupMapConstants.SELECTED_LOOKUP, "PRIMARY_RELATIONSHIP_TYPE");
        helper.setRequestParameterValue(TestLookupMapConstants.ID, "1");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_TYPE, "Type");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_ACTIVE, "Y");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_DESCRIPTION, "Description");
        try {
            controller.run(helper);
            fail("This should have thrown exception");
        } catch (Exception e) {
            assertEquals(IOException.class, e.getClass());
            assertEquals("Could Not Build Lookup Object", e.getMessage());
        }
    }

    private class ExceptionPreUpdateLookupController extends PreUpdateLookupController {
        public void displayLookupData(UCCHelper helper) throws IOException, GenericLookupBuilderException {
            throw new GenericLookupBuilderException("exception");
        }
    }
}
