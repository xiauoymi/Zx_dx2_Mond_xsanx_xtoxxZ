package com.monsanto.wst.administerreferencedata.builder.tests;

import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import junit.framework.TestCase;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 21, 2006 Time: 9:44:32 AM To change this template use File |
 * Settings | File Templates.
 */
public class GenericLookupBuilder_UT extends TestCase {

  private static final String INVALID_XML_PATH = "com/monsanto/wst/nosuchproject/genericLookup.xml";

  public void testCreate() throws Exception {
    GenericLookupBuilder builder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    assertNotNull(builder);
  }

  public void testBuildLookupsThrowsNoExeption() throws Exception {
    GenericLookupBuilder builder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    Map map = builder.buildLookups();
    assertNotNull(map);
    assertTrue(map.size() > 1);
    LookUpObject lookUpObject = (LookUpObject) map.get(TestLookupMapConstants.TEST_TABLE);
    assertEquals(TestLookupMapConstants.TEST_TABLE, lookUpObject.getTableName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, lookUpObject.getTableDisplayName());
    assertEquals(6, lookUpObject.getColumnMappingList().size());
    assertEquals(TestLookupMapConstants.TEST_TABLE_ID,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getDbName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_ID_DISPLAY_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getColumnDisplayName());
    assertEquals("id", ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getMappingName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getDbName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_NAME_DISPLAY_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getColumnDisplayName());
    assertEquals("type", ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getMappingName());
    assertEquals("ACTIVE", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getDbName());
    assertEquals("Active", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getColumnDisplayName());
    assertEquals("active", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getMappingName());
    assertEquals("DESCRIPTION", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getDbName());
    assertEquals("Description", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getColumnDisplayName());
    assertEquals("description", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getMappingName());
    assertEquals("MOD_USER", ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getDbName());
    assertEquals("Last Modified By",
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getColumnDisplayName());
    assertEquals("modUser", ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getMappingName());
    assertEquals("MOD_DATE", ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getDbName());
    assertEquals("Last Modified Date",
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getColumnDisplayName());
    assertEquals("modDate", ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getMappingName());
    lookUpObject = (LookUpObject) map.get(TestLookupMapConstants.TEST_TABLE_II);
    assertEquals(TestLookupMapConstants.TEST_TABLE_II, lookUpObject.getTableName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_II_DISPLAY_NAME, lookUpObject.getTableDisplayName());
    assertEquals(6, lookUpObject.getColumnMappingList().size());
    assertEquals(TestLookupMapConstants.TEST_TABLE_II_ID,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getDbName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_II_ID_DISPLAY_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getColumnDisplayName());
    assertEquals("id", ((ColumnMapping) lookUpObject.getColumnMappingList().get(0)).getMappingName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_II_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getDbName());
    assertEquals(TestLookupMapConstants.TEST_TABLE_II_NAME_DISPLAY_NAME,
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getColumnDisplayName());
    assertEquals("type", ((ColumnMapping) lookUpObject.getColumnMappingList().get(1)).getMappingName());
    assertEquals("ACTIVE", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getDbName());
    assertEquals("Active", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getColumnDisplayName());
    assertEquals("active", ((ColumnMapping) lookUpObject.getColumnMappingList().get(2)).getMappingName());
    assertEquals("DESCRIPTION", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getDbName());
    assertEquals("Description", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getColumnDisplayName());
    assertEquals("description", ((ColumnMapping) lookUpObject.getColumnMappingList().get(3)).getMappingName());
    assertEquals("MOD_USER", ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getDbName());
    assertEquals("Last Modified By",
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getColumnDisplayName());
    assertEquals("modUser", ((ColumnMapping) lookUpObject.getColumnMappingList().get(4)).getMappingName());
    assertEquals("MOD_DATE", ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getDbName());
    assertEquals("Last Modified Date",
        ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getColumnDisplayName());
    assertEquals("modDate", ((ColumnMapping) lookUpObject.getColumnMappingList().get(5)).getMappingName());
  }

  public void testBuildLookupsWithIncorrectPathSpecified() throws Exception {
    GenericLookupBuilder builder = new GenericLookupBuilder(INVALID_XML_PATH);
    try {
      builder.buildLookups();
      fail("This should have thrown Exception");
    } catch (GenericLookupBuilderException e) {
      assertEquals("Could Not create Input Document", e.getMessage());
    }
  }

  public void testBuildLookupsWithNullPathSpecified() throws Exception {
    GenericLookupBuilder builder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    try {
      builder.buildLookups();
    } catch (GenericLookupBuilderException e) {
      assertFalse(true);
    }
  }
}
