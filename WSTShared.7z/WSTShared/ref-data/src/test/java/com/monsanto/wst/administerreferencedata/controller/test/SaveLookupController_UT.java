package com.monsanto.wst.administerreferencedata.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.controller.SaveLookupController;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupServiceDBImpl;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupServiceDBImpl;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 11:01:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaveLookupController_UT extends TestCase {

    MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        SaveLookupController controller = new SaveLookupController();
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        assertNotNull(controller);
    }

    public void testSaveLookupDateForADDAction() throws Exception {
        helper.setRequestParameterValue(TestLookupMapConstants.PROCESS, TestLookupMapConstants.ADD);
        helper.setRequestParameterValue(TestLookupMapConstants.TABLE_NAME, TestLookupMapConstants.TEST_TABLE);
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_TYPE, "Type");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_ACTIVE, "Y");
        helper.setRequestParameterValue(TestLookupMapConstants.MAPPING_DESCRIPTION, "Desc");
        SaveLookupController controller = new SaveLookupController(new MockProcessLookupServiceDBImpl(), new MockSequenceLookupService(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION));
	    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
        controller.run(helper);
        assertEquals(1, ((List)helper.getRequestAttributeValue(TestLookupMapConstants.LOOKUP_SUCCESS_LIST)).size());
        assertEquals("Lookup Saved SuccessFully", ((List)helper.getRequestAttributeValue(TestLookupMapConstants.LOOKUP_SUCCESS_LIST)).get(0));
    }

    private class MockProcessLookupServiceDBImpl extends ProcessLookupServiceDBImpl {
      public MockProcessLookupServiceDBImpl() {
        super((String) null);
      }

      public int processLookup(LookUpObject lookUpObject, String processCommand, LookupData lookupData) throws
		    IOException {
		    return super.processLookup(lookUpObject, processCommand, lookupData);
	    }

	    protected int processLookupData(String lookupQuery, LookupData lookupData) {
		    return 1;
	    }
    }
    private class MockSequenceLookupService extends SequenceLookupServiceDBImpl {
	    public MockSequenceLookupService(String xmlPath) {
		    super(xmlPath);
	    }

	    public String getSequence() throws GenericLookupBuilderException {
		    return "1";
	    }
    }
}
