package com.monsanto.wst.administerreferencedata.builder.tests;

import com.monsanto.wst.administerreferencedata.builder.EditQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.LookupObjectBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:24:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditQueryBuilder_UT extends TestCase {

    private String updateLookupQuery = TestLookupMapConstants.TEST_TABLE_UPDATE;

    public void testCreate() throws Exception {
        EditQueryBuilder builder = new EditQueryBuilder();
        assertNotNull(builder);
    }

    public void testBuildQuery() throws Exception, GenericLookupBuilderException {
        EditQueryBuilder builder = new EditQueryBuilder();
        String query = builder.buildQuery(LookupObjectBuilder.getLookupObject(TestLookupMapConstants.TEST_TABLE, TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION));
        assertEquals(updateLookupQuery, query);
    }

}
