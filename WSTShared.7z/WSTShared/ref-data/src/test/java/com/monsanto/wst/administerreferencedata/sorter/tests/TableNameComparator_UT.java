/*
 TableNameComparator_UT was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.administerreferencedata.sorter.tests;

import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.sorter.TableNameComparator;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: TableNameComparator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-04-11 19:37:50 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class TableNameComparator_UT extends TestCase {

  public void testCreate() throws Exception {
    TableNameComparator comparator = new TableNameComparator();
    assertNotNull(comparator);
  }

  public void testCompare() throws Exception {
    Map lookupMap = new HashMap();
    LookUpObject lookUpObject = new LookUpObject("Table Name", "Table Display Name", new ArrayList());
    lookupMap.put(lookUpObject.getTableName(), lookUpObject);
    lookUpObject = new LookUpObject("A Table Name", "Table Display Name", new ArrayList());
    lookupMap.put(lookUpObject.getTableName(), lookUpObject);
    List list = new ArrayList(lookupMap.entrySet());
    Collections.sort(list, new TableNameComparator());
    lookUpObject = ((LookUpObject)((Map.Entry) list.get(0)).getValue());
    assertEquals("A Table Name", lookUpObject.getTableName());
  }
}