package com.monsanto.wst.administerreferencedata.services.test;

import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.SaveLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.dao.UpdateLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupServiceDBImpl;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 8:41:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessLookupServiceImpl_UT extends TestCase {

    protected void setUp() throws Exception {
    }

    public void testCreate() throws Exception {
        ProcessLookupServiceDBImpl service = new ProcessLookupServiceDBImpl((String) null);
        assertNotNull(service);
    }

    public void testProcess() throws Exception {
        ProcessLookupServiceDBImpl service = new ProcessLookupServiceDBImpl(new MockProcessLookupDAO());
        int rowsUpdated = service.processLookup(getLookupObject(), TestLookupMapConstants.EDIT, getLookupData());
        assertEquals(1, rowsUpdated);
    }

    public void testGetNumberOfRowsProcessedForADD() throws Exception {
        ProcessLookupServiceDBImpl service = new ProcessLookupServiceDBImpl(new MockSaveLookupDAO());
        int rowsUpdated = service.processLookup(getLookupObject(), TestLookupMapConstants.ADD, getLookupData());
        assertEquals(2, rowsUpdated);
    }

    private LookUpObject getLookupObject(){
        return new LookUpObject("TABLE_NAME","TABLE_DISPLAY_NAME",new ArrayList());
    }

    private LookupData getLookupData(){
        return new LookupData("ID","TYPE1","Y","DESC1","USER1",new Date(System.currentTimeMillis()));
    }

	private class MockProcessLookupDAO extends UpdateLookupDAOImpl{
    private MockProcessLookupDAO() {
      super(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    }

    public int updateLookup(LookupData lookupData, String processQuery) {
			return 1;
		}
	}
	private class MockSaveLookupDAO extends SaveLookupDAOImpl {
    private MockSaveLookupDAO() {
      super(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    }

    public int updateLookup(LookupData lookupData, String processQuery) {
			return 2;
		}
	}
}
