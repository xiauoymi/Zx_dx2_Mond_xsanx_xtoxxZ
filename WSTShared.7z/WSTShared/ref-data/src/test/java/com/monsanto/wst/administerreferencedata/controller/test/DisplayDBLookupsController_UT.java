package com.monsanto.wst.administerreferencedata.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.administerreferencedata.builder.DisplayLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.builder.mock.MockDisplayLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.controller.DisplayDBLookupsController;
import com.monsanto.wst.administerreferencedata.model.BaseModel;
import junit.framework.TestCase;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 21, 2006 Time: 2:56:04 PM To change this template use File |
 * Settings | File Templates.
 */
public class DisplayDBLookupsController_UT extends TestCase {

  MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    helper = new MockUCCHelper(null);
  }

  public void testCreate() throws Exception {
    DisplayDBLookupsController controller = new DisplayDBLookupsController();
    controller.setXmlPath(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    assertNotNull(controller);
  }

  public void testRun() throws Exception {
    DisplayDBLookupsController controller = new MockDisplayDBLookupsController();
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
  }

  public void testCheckDisplayLookups() throws Exception {
    DisplayDBLookupsController controller = new MockDisplayDBLookupsController();
    helper.setRequestParameterValue(TestLookupMapConstants.SELECTED_LOOKUP, TestLookupMapConstants.TEST_TABLE);
    controller.run(helper);
    assertNotNull(helper.getSessionParameter(TestLookupMapConstants.LOOKUPMAP));
    assertTrue(((Map) helper.getSessionParameter(TestLookupMapConstants.LOOKUPMAP)).size() > 1);
    assertTrue(helper.wasSentTo(TestLookupMapConstants.DISPLAY_LOOKUP_JSP));
    BaseModel lookupModel = (BaseModel) helper.getSessionParameter(TestLookupMapConstants.DEFAULT_LOOKUP);
    assertEquals(TestLookupMapConstants.TEST_TABLE, lookupModel.getId());
    assertEquals(TestLookupMapConstants.TEST_TABLE_DISPLAY_NAME, lookupModel.getValue());
    assertEquals(3, ((Map) helper.getSessionParameter(TestLookupMapConstants.LOOKUP_DATA_MAP)).size());
  }

  private class MockDisplayDBLookupsController extends DisplayDBLookupsController {
    public DisplayLookupDBBuilder getLookupBuilderImpl() {
      return new MockDisplayLookupDBBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    }
  }
}
