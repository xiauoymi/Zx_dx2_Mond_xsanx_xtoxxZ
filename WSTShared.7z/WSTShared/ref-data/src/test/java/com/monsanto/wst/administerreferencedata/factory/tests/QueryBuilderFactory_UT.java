package com.monsanto.wst.administerreferencedata.factory.tests;

import com.monsanto.wst.administerreferencedata.builder.AddQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.EditQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.QueryBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.factory.QueryBuilderFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 1:59:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueryBuilderFactory_UT extends TestCase {

    public void testCreate() throws Exception {
        QueryBuilderFactory factory = new QueryBuilderFactory();
        assertNotNull(factory);
    }

    public void testQueryBuilderImplForADDAction() throws Exception {
        QueryBuilder queryBuilder = QueryBuilderFactory.getQueryBuilder(TestLookupMapConstants.ADD);
        assertNotNull(queryBuilder);
        assertEquals(AddQueryBuilder.class, queryBuilder.getClass());
    }

    public void testQueryBuilderImplForEDITAction() throws Exception {
        QueryBuilder queryBuilder = QueryBuilderFactory.getQueryBuilder(TestLookupMapConstants.EDIT);
        assertNotNull(queryBuilder);
        assertEquals(EditQueryBuilder.class, queryBuilder.getClass());
    }
}
