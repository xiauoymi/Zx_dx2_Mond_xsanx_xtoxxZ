package com.monsanto.wst.administerreferencedata.persistence.test;

import com.monsanto.wst.administerreferencedata.persistence.LookupPersistenceStoreType2;
/*
 MockLookupPersistenceStore was created on Mar 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
//todo this is poorly named, its not a mock it really hits the database (just with a test config file)
public class MockLookupPersistenceStore extends LookupPersistenceStoreType2 {
    protected String getDBTemplateConfigLocation() {
        return "com/monsanto/wst/administerreferencedata/persistence/test/dbtemplate-config.xml";
    }
}
