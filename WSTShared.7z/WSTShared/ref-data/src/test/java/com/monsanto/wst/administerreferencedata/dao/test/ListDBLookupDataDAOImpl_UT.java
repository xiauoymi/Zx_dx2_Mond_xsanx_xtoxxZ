package com.monsanto.wst.administerreferencedata.dao.test;

import junit.framework.TestCase;
import com.monsanto.wst.administerreferencedata.dao.ListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.dao.ListLookupDataDAO;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 ListDBLookupDataDAOImpl_UT was created on Mar 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */

public class ListDBLookupDataDAOImpl_UT extends TestCase {
  public void testTemporary() throws Exception {
    //todo Need to fix path problem in testDoesntCauseNPEOnLookup and re-enable it
  }

/*
  public void testDoesntCauseNPEOnLookup() throws Exception {
    //todo need to rename test when find better description
    ListLookupDataDAO dao = new ListDBLookupDataDAOImpl(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    List columnMappings = new ArrayList();
    LookUpObject obj = new LookUpObject("SHARED_CODE.REFDATA", "Reference Data", columnMappings);
    Map map = dao.listLookupData(obj, "SELECT * FROM SHARED_CODE.REFDATA");
    assertNotNull(map);
  }
*/
}