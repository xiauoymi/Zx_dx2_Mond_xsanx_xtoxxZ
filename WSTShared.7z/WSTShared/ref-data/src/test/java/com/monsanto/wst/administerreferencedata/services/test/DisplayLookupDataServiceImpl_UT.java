package com.monsanto.wst.administerreferencedata.services.test;

import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.test.TestLookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.mock.MockListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.services.DisplayLookupDataServiceImpl;
import junit.framework.TestCase;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 10:49:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayLookupDataServiceImpl_UT extends TestCase {

    private GenericLookupBuilder genericLookupBuilder = null;

    protected void setUp() throws Exception {
        genericLookupBuilder = new GenericLookupBuilder(TestLookupMapConstants.TEST_LOOKUP_XML_LOCATION);
    }

    public void testCreate() throws Exception {
        DisplayLookupDataServiceImpl displayLookupDataService = new DisplayLookupDataServiceImpl(null);
        assertNotNull(displayLookupDataService);
    }

    public void testCreateLookupDataMap() throws Exception, GenericLookupBuilderException {
        DisplayLookupDataServiceImpl displayLookupDataService = new DisplayLookupDataServiceImpl(new MockListDBLookupDataDAOImpl());
        Map dataMap = displayLookupDataService.displayDataForLookup(genericLookupBuilder.buildLookups(), TestLookupMapConstants.TEST_TABLE);
        assertNotNull(dataMap);
        assertEquals(3, dataMap.size());
        LookupData lookupData = (LookupData) dataMap.get("ID");
        assertEquals("ID", lookupData.getId());
        assertEquals("TYPE1", lookupData.getType());
        assertEquals("Y", lookupData.getActive());
        assertEquals("DESC1", lookupData.getDescription());
        assertEquals("USER1", lookupData.getModUser());
    }

}
