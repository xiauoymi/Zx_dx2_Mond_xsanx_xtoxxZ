package com.monsanto.wst.administerreferencedata.services.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupService;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupServiceDBImpl;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 9:28:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockProcessLookupServiceDBImpl extends ProcessLookupServiceDBImpl implements ProcessLookupService {

  public MockProcessLookupServiceDBImpl() {
    super((String) null);
  }

  public int processLookup(LookUpObject lookUpObject, UCCHelper helper, LookupData lookupData) throws IOException {
        return 1;
    }
}
