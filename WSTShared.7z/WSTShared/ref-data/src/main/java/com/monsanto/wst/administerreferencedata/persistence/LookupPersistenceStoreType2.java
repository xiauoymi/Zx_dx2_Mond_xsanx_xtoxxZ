package com.monsanto.wst.administerreferencedata.persistence;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.dbtemplate.domain.xml.XMLDataSourceParser;

/**
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 2:47:49 PM
 */
public class LookupPersistenceStoreType2 implements CorePersistenceStore {

    private static PersistentStore RetVal;

    protected static PersistentStore getStoreInstance(String userName, String encryptedPassword, String sid, String server) throws WrappingException {
        if (RetVal == null) {
            RetVal = new PersistentStoreOracleCachedType2(userName, encryptedPassword, sid, 0, 10);
        }
        return (PersistentStore) Logger.traceExit(RetVal);
    }

    public PersistentStore getStore() throws WrappingException {

        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        XMLDataSourceParser parser = new XMLDataSourceParser(xmlUtils, getDBTemplateConfigLocation(), xpathUtils);

        Logger.traceEntry();
        String lsifunction = System.getProperty("lsi.function");
        String userName = parser.getString(lsifunction + ".UserName");
        String datasource = parser.getString(lsifunction + ".DataSource");
        String password = parser.getString(lsifunction + ".Password");

        return getStoreInstance(userName, password, datasource, datasource);
    }

    protected String getDBTemplateConfigLocation() {
        return "database/dbtemplate-config.xml";
    }


}

