/*
 TableNameComparator was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.administerreferencedata.sorter;

import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Comparator;
import java.util.Map;

/**
 * Filename:    $RCSfile: TableNameComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-04-11 19:37:50 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class TableNameComparator implements Comparator {

    public int compare(Object o1, Object o2) {
      Map.Entry entry1  = (Map.Entry) o1;
      Map.Entry entry2  = (Map.Entry) o2;

      String tableName1 = ((LookUpObject)(entry1.getValue())).getTableName();
      String tableName2 = ((LookUpObject)(entry2.getValue())).getTableName();
      if(tableName1.compareToIgnoreCase(tableName2) > 0){
        return 1;
      }else if(tableName1.compareToIgnoreCase(tableName2) < 0){
        return -1;
      }
      return 0;
    }
}