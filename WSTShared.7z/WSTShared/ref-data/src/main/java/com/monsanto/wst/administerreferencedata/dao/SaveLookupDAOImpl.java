package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 23, 2006 Time: 2:55:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class SaveLookupDAOImpl implements ProcessLookupDAO {
  private final String lookupXmlLocation;

  public SaveLookupDAOImpl(String lookupXmlLocation) {
    this.lookupXmlLocation = lookupXmlLocation;
  }

  public int updateLookup(LookupData lookupData, String processQuery) {
    int numberOfRowsProcessed = 0;
    PersistentStoreConnection psConnection = null;
    PersistentStoreStatement persistentStoreStatement = null;
    try {
      psConnection = LookupDBUtils.createPersistentStore(lookupXmlLocation);
      persistentStoreStatement = psConnection.prepareStatement(processQuery);
      persistentStoreStatement.setParam(1, lookupData.getId());
      persistentStoreStatement.setParam(2, lookupData.getType());
      persistentStoreStatement.setParam(3, lookupData.getActive());
      persistentStoreStatement.setParam(4, lookupData.getDescription());
      persistentStoreStatement.setParam(5, lookupData.getModUser());
      persistentStoreStatement.setParam(6, lookupData.getModDate());
      numberOfRowsProcessed = persistentStoreStatement.executeInsert();
    }
    catch (WrappingException e) {
      throw new RuntimeWrappingException(e.getNestedException());
    }
    finally {
      LookupDBUtils.closeConnections(persistentStoreStatement, psConnection);
    }
    return numberOfRowsProcessed;
  }

}
