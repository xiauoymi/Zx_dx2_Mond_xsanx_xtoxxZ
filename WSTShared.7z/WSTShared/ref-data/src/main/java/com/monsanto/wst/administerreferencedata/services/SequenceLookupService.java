package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 25, 2006
 * Time: 9:30:40 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SequenceLookupService {
    String getSequence() throws GenericLookupBuilderException;
}
