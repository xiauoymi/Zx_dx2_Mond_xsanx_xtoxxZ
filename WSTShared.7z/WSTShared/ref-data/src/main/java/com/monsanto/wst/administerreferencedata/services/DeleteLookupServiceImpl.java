package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.builder.LookupObjectBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.DeleteLookupDAO;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 10:48:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteLookupServiceImpl implements DeleteLookupService{

    private DeleteLookupDAO deleteLookupDAO;
    int rowsDeleted  = 0;
	private String xmlPath;
    public DeleteLookupServiceImpl(DeleteLookupDAO deleteLookupDAO, String xmlPath) {
        this.deleteLookupDAO = deleteLookupDAO;
	    this.xmlPath = xmlPath;
    }

    public int deleteLookupData(String id, String selectedLookup) throws GenericLookupBuilderException {
        LookupData lookupData = new LookupData(id,null,null,null,null,null);
        try {
            LookUpObject lookUpObject = LookupObjectBuilder.getLookupObject(selectedLookup, xmlPath);
            String query = buildDeleteQuery(lookUpObject);
            rowsDeleted = deleteLookupDAO.deleteLookup(lookupData, query);
        } catch (GenericLookupBuilderException e) {
            throw new GenericLookupBuilderException("Could Not Build Lookup Objects From XML file & Delete Data", e);
        }
        return rowsDeleted;
    }

    private String buildDeleteQuery(LookUpObject lookUpObject) {
        StringBuffer query = new StringBuffer();
        query.append("DELETE FROM ").append(lookUpObject.getTableName()).append(" WHERE ").append(getLookupColumnId(lookUpObject.getColumnMappingList())).append(" = ?");
        return query.toString();
    }

    private String getLookupColumnId(List columnMappingList) {
        StringBuffer mappingQuery = new StringBuffer();
        if (columnMappingList!=null && columnMappingList.size()>0){
            Iterator columnIterator = columnMappingList.iterator();
            while(columnIterator.hasNext()){
                ColumnMapping columnMapping = (ColumnMapping) columnIterator.next();
                if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.ID)){
                    mappingQuery.append(columnMapping.getDbName());
                }
            }
        }
        return mappingQuery.toString();
    }
}
