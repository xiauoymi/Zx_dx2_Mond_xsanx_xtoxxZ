package com.monsanto.wst.administerreferencedata.builder.mock;

import com.monsanto.wst.administerreferencedata.builder.DisplayLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.dao.ListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.dao.mock.MockListDBLookupDataDAOImpl;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 9:50:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockDisplayLookupDBBuilder extends DisplayLookupDBBuilder {

	public MockDisplayLookupDBBuilder(String xmlPath) {
		super(xmlPath);
	}

	public ListDBLookupDataDAOImpl getDAOImplementation() {
      return new MockListDBLookupDataDAOImpl();
	}
}
