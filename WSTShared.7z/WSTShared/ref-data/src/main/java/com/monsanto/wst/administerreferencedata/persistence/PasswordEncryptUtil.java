package com.monsanto.wst.administerreferencedata.persistence;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;

import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 25, 2006 Time: 10:17:38 AM To change this template use File |
 * Settings | File Templates.
 */
public class PasswordEncryptUtil {

  public static String getEncryptedPassword(String cstrResourceBundleName) {
    String encryptedPassword = "";
    ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
    String pwdEncEnvVar = bundle.getString("password.encryption.environment.variable");
    String applicationFolder = bundle.getString("password.encryption.application.folder");
    String cipherHexFile = bundle.getString("password.encryption.cipher.hexfile");
    String keyValueHexFile = bundle.getString("password.encryption.keyvalue.hexfile");

    try {
      encryptedPassword = EncryptionUtils
          .GetDecryptedStringFromExternalStorage(pwdEncEnvVar, applicationFolder, cipherHexFile, keyValueHexFile);
    } catch (EncryptorException e) {
      throw new RuntimeWrappingException(e);
    }
    return encryptedPassword;
  }
}
