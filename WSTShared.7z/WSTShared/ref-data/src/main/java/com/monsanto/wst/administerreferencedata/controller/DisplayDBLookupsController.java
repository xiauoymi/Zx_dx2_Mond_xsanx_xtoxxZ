package com.monsanto.wst.administerreferencedata.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.administerreferencedata.builder.DisplayLookupDBBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 2:56:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayDBLookupsController implements UseCaseController {
	private String xmlPath = LookupMapConstants.LOOKUP_XML_LOCATION;


	public void run(UCCHelper helper) throws IOException {
	    DisplayLookupDBBuilder builder = getLookupBuilderImpl();
	    builder.displayLookupDataFromDB(helper);
	}

    protected DisplayLookupDBBuilder getLookupBuilderImpl() {
        return new DisplayLookupDBBuilder(this.xmlPath);
    }

	public void setXmlPath(String xmlPath) {
    if (xmlPath == null) {
      throw new NullPointerException("XML Path cannot be null"); 
    }
    this.xmlPath = xmlPath;
	}

}
