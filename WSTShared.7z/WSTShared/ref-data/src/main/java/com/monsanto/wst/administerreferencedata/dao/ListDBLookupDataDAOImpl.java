package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 21, 2006 Time: 4:36:09 PM To change this template use File |
 * Settings | File Templates.
 */
public class ListDBLookupDataDAOImpl implements ListLookupDataDAO {
  private final String lookupXmlLocation;

  public ListDBLookupDataDAOImpl(String lookupXmlLocation) {
    if (lookupXmlLocation == null) {
      throw new NullPointerException("Lookup XML Location cannot be null");
    }
    this.lookupXmlLocation = lookupXmlLocation;
  }

  public Map listLookupData(LookUpObject lookUpObject, String query) {
    Map lookupDataMap = new LinkedHashMap();
    PersistentStoreConnection psConnection = null;
    PersistentStoreStatement persistentStoreStatement = null;
    try {
      psConnection = LookupDBUtils.createPersistentStore(lookupXmlLocation);
      persistentStoreStatement = psConnection.prepareStatement(query);
      PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();
      PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet
          .getForwardIterator();
      buildLookupDataMap(persistentStoreResultSetFwdIterator, lookUpObject, lookupDataMap);
    } catch (WrappingException e) {
      throw new RuntimeWrappingException(e.getNestedException());
    } finally {
      LookupDBUtils.closeConnections(persistentStoreStatement, psConnection);
    }
    return lookupDataMap;
  }

  private void buildLookupDataMap(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator,
                                  LookUpObject lookUpObject, Map lookupDataMap) throws WrappingException {
    while (persistentStoreResultSetFwdIterator.next()) {
      LookupData lookupData = null;
      String lookupType = null;
      String activeStatus = null;
      String lookupDescription = null;
      String modUser = null;
      Date modDate = null;
      String lookupId = null;
      Iterator lookIterator = lookUpObject.getColumnMappingList().iterator();
      while (lookIterator.hasNext()) {
        ColumnMapping columnMapping = (ColumnMapping) lookIterator.next();
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.ID)) {
          lookupId = getStringValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_TYPE)) {
          lookupType = getStringValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_ACTIVE)) {
          activeStatus = getStringValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_DESCRIPTION)) {
          lookupDescription = getStringValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_USER)) {
          modUser = getStringValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_DATE)) {
          modDate = getDateValueFromDB(persistentStoreResultSetFwdIterator, columnMapping);
        }
        lookupData = new LookupData(lookupId, lookupType, activeStatus, lookupDescription, modUser, modDate);
        lookupDataMap.put(lookupId, lookupData);
      }
    }
  }

  private Date getDateValueFromDB(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator,
                                  ColumnMapping columnMapping) throws WrappingException {
    return persistentStoreResultSetFwdIterator.getDate(columnMapping.getDbName());
  }

  private String getStringValueFromDB(PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator,
                                      ColumnMapping columnMapping) throws WrappingException {
    return persistentStoreResultSetFwdIterator.getString(columnMapping.getDbName());
  }
}
