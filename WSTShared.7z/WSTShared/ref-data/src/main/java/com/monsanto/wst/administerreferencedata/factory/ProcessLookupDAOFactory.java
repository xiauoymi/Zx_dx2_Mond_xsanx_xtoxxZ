package com.monsanto.wst.administerreferencedata.factory;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.ProcessLookupDAO;
import com.monsanto.wst.administerreferencedata.dao.SaveLookupDAOImpl;
import com.monsanto.wst.administerreferencedata.dao.UpdateLookupDAOImpl;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 23, 2006 Time: 4:11:07 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProcessLookupDAOFactory {
  private String lookupXmlLocation;

  public ProcessLookupDAOFactory(String xmlLocation) {
    this.lookupXmlLocation = xmlLocation;
  }

  public ProcessLookupDAO getProcessDAO(String action) {
    ProcessLookupDAO processLookupDAO;
    if (LookupMapConstants.ADD.equalsIgnoreCase(action)) {
      processLookupDAO = new SaveLookupDAOImpl(lookupXmlLocation);
    } else if (LookupMapConstants.EDIT.equalsIgnoreCase(action)) {
      processLookupDAO = new UpdateLookupDAOImpl(lookupXmlLocation);
    } else {
      processLookupDAO = null;
    }
    return processLookupDAO;
  }
}
