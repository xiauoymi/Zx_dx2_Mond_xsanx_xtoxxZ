package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 8:38:42 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessLookupService {

    public int processLookup(LookUpObject lookUpObject, String processCommand, LookupData lookupData) throws IOException;

}
