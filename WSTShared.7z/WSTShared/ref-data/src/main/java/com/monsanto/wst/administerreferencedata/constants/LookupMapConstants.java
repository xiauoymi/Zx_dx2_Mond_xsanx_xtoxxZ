package com.monsanto.wst.administerreferencedata.constants;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 21, 2006 Time: 2:21:18 PM To change this template use File |
 * Settings | File Templates.
 */
public interface LookupMapConstants {

  String LOOKUP_XML_LOCATION = "lookup/genericLookup.xml";
  String LOOKUP = "lookup";
  String COLUMNS = "columns";
  String COLUMN = "column";
  String TABLE_DISPLAY_NAME = "tableDisplayName";
  String ID = "id";
  String DB_NAME = "dBName";
  String DISPLAY_NAME = "displayName";
  String MAPPING_OBJECT = "mappingObject";
  String MAPPING_DISPLAY_SERVLET = "/servlet/display_lookup.htm";

  String LOOKUPMAP = "lookupMap";
  String DEFAULT_LOOKUP = "defaultLookup";
  String LOOKUP_DATA_MAP = "lookupDataMap";
  String LOOKUP_ELEMENTS_ERROR_MSG = "Cannot Create Lookup Elements";
  String MAPPING_TYPE = "type";
  String MAPPING_ACTIVE = "active";
  String MAPPING_DESCRIPTION = "description";
  String MAPPING_MOD_USER = "modUser";
  String MAPPING_MOD_DATE = "modDate";

  String SELECTED_LOOKUP = "selectedLookup";
  String PROCESS = "process";

  String LOOKUP_DATA = "lookupData";
  String ADD = "ADD";
  String EDIT = "EDIT";
  String TABLE_NAME = "tableName";
  String LOOKUP_ERROR_LIST = "lookupErrorList";

  /*
      String PROJECT_SEQUENCE = "TECH_REQ";
  */
  String SAVED_LOOKUP = "savedLookup";
  String LOOKUP_SUCCESS_LIST = "lookupSuccessList";
  String UPDATE_LOOKUP_JSP = "/WEB-INF/jsp/maintenance/updateLookup.jspx";
  String LOOKUP_SUCCESS_MSG = "Lookup Saved SuccessFully";
  String ADMIN = "ADMIN";
  String NO = "N";
  String YES = "Y";
  String DISPLAY_LOOKUP_JSP = "/WEB-INF/jsp/maintenance/displayLookup.jspx";
  String SEQUENCE = "SEQUENCE";
  String DB_SEQUENCE = "dbSequence";
  String PERSISTENCE_CLASS = "PERSISTENCE_CLASS";
  String PERSISTENCE_CLASS_ID = "persistenceClass";

  Integer TABLE_COUNT = new Integer("5");

}