package com.monsanto.wst.administerreferencedata.dao.mock;

import com.monsanto.wst.administerreferencedata.dao.DeleteLookupDAO;
import com.monsanto.wst.administerreferencedata.model.LookupData;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 11:07:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockDeleteLookupDAOImpl implements DeleteLookupDAO {

    public int deleteLookup(LookupData lookupData, String deleteQuery) {
        return 1;  
    }
}
