package com.monsanto.wst.administerreferencedata.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.administerreferencedata.builder.PreUpdateAddBuilder;
import com.monsanto.wst.administerreferencedata.builder.PreUpdateEditBuilder;
import com.monsanto.wst.administerreferencedata.builder.PreUpdateLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 1:56:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class PreUpdateLookupController implements UseCaseController {

    PreUpdateLookupBuilder builder = null;
	String xmlPath = LookupMapConstants.LOOKUP_XML_LOCATION;

    public void run(UCCHelper helper) throws IOException {
        getBuilderImplementation(helper);
        try {
            displayLookupData(helper);
        } catch (GenericLookupBuilderException e) {
            throw new IOException("Could Not Build Lookup Object");
        }
    }

    protected void displayLookupData(UCCHelper helper) throws IOException, GenericLookupBuilderException {
        builder.displayLookupDataForProcess(helper);
    }

    private void getBuilderImplementation(UCCHelper helper) throws IOException {
        if (helper.getRequestParameterValue(LookupMapConstants.PROCESS).equalsIgnoreCase(LookupMapConstants.ADD)){
            builder = new PreUpdateAddBuilder(xmlPath);
        }
        if (helper.getRequestParameterValue(LookupMapConstants.PROCESS).equalsIgnoreCase(LookupMapConstants.EDIT)){
            builder = new PreUpdateEditBuilder(xmlPath);
        }
    }

	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}
}
