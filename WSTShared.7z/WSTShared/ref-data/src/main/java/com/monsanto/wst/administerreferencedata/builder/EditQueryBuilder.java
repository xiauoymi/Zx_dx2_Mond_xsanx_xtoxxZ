package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:07:57 PM
 */
public class EditQueryBuilder implements QueryBuilder {

    public String buildQuery(LookUpObject lookUpObject) {
        StringBuffer mainBuffer = new StringBuffer();
        mainBuffer.append(getUpdateString(lookUpObject.getTableName())).append(buildColumnMappingVariables(lookUpObject.getColumnMappingList()));
        return mainBuffer.toString();
    }

    private String buildColumnMappingVariables(List columnMappingList) {
        StringBuffer mappingQuery = new StringBuffer();
        Iterator columnIterator = columnMappingList.iterator();
        while (columnIterator.hasNext()) {
            ColumnMapping columnMapping = (ColumnMapping) columnIterator.next();
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_TYPE)) {
                mappingQuery.append(columnMapping.getDbName()).append("=?,");
            }
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_ACTIVE)) {
                mappingQuery.append(columnMapping.getDbName()).append("=?,");
            }
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_DESCRIPTION)) {
                mappingQuery.append(columnMapping.getDbName()).append("=?,");
            }
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_USER)) {
                mappingQuery.append(columnMapping.getDbName()).append("=?,");
            }
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_DATE)) {
                mappingQuery.append(columnMapping.getDbName()).append("=?");
            }
        }
        mappingQuery.append(buildWhereClause(columnMappingList));
        return mappingQuery.toString();
    }

    private String buildWhereClause(List mappingList) {
        StringBuffer mappingQuery = new StringBuffer();
        Iterator mappingListIterator = mappingList.iterator();
        while (mappingListIterator.hasNext()) {
            ColumnMapping columnMapping = (ColumnMapping) mappingListIterator.next();
            if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.ID)) {
                mappingQuery.append(" WHERE ").append(columnMapping.getDbName()).append(" =?");
            }
        }
        return mappingQuery.toString();
    }

    private String getUpdateString(String tableName) {
        return "UPDATE " + tableName + " SET ";
    }


}
