package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.services.DisplayLookupDataService;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 4:15:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class ListLookupDBBuilder {

    private DisplayLookupDataService service;

    public ListLookupDBBuilder(DisplayLookupDataService service) {
        this.service = service;
    }

    public Map listSelectedLookupData(Map lookupMap, String lookupSelected) {
        return service.displayDataForLookup(lookupMap, lookupSelected);
    }
}
