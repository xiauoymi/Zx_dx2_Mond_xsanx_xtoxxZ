package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.model.LookUpObject;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:01:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface QueryBuilder {

    /**
     * This method builds the sql query depeneding on ADD or EDIT action
     * @param lookUpObject - contains the data to build the query lookUpObject
     * @return string - built query
     */
    public String buildQuery(LookUpObject lookUpObject);
    
}
