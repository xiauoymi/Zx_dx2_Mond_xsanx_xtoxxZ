package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.DisplayModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 4:45:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class PreUpdateEditBuilder extends PreUpdateLookupBuilder{
	public PreUpdateEditBuilder(String xmlPath) {
		super(xmlPath);
	}

	public List getObjectForDisplay(Iterator mappingListIterator, UCCHelper helper) throws IOException {
	    List displayList = new ArrayList();
	    while(mappingListIterator.hasNext()){
	        ColumnMapping columnMapping = (ColumnMapping) mappingListIterator.next();
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.ID)){
	            String id = helper.getRequestParameterValue(LookupMapConstants.ID);
	            displayModel = new DisplayModel(columnMapping, id);
	        }
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_TYPE)){
	            String type = helper.getRequestParameterValue(LookupMapConstants.MAPPING_TYPE);
	            displayModel = new DisplayModel(columnMapping, type);
	        }
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_ACTIVE)){
	            String active = helper.getRequestParameterValue(LookupMapConstants.MAPPING_ACTIVE);
	            displayModel = new DisplayModel(columnMapping, active);
	        }
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_DESCRIPTION)){
	            String description = helper.getRequestParameterValue(LookupMapConstants.MAPPING_DESCRIPTION);
	            displayModel = new DisplayModel(columnMapping, description);
	        }
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_USER)){
	            displayModel = new DisplayModel(columnMapping, "ADMIN");
	        }
	        if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_DATE)){
	            displayModel = new DisplayModel(columnMapping, new Date(System.currentTimeMillis()));
	        }
	        displayList.add(displayModel);
	    }
	    return displayList;
	}
}
