package com.monsanto.wst.administerreferencedata.persistence;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;

/**
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 2:56:35 PM
 */
public interface CorePersistenceStore {
    PersistentStore getStore() throws WrappingException;
}
