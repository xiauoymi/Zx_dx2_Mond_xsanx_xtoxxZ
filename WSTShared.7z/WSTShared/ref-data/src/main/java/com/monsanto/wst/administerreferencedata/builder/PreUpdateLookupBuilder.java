package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.DisplayModel;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 2:04:49 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class PreUpdateLookupBuilder {

    String tableName = null;
    String tableDisplayName = null;
    List mappingList = new ArrayList();
    LookUpObject displLookUpObject = null;
    DisplayModel displayModel = null;
    GenericLookupBuilder genericLookupBuilder = null;

	protected PreUpdateLookupBuilder(String xmlPath) {
		this.genericLookupBuilder = new GenericLookupBuilder(xmlPath);
	}

	public void displayLookupDataForProcess(UCCHelper helper) throws IOException, GenericLookupBuilderException {
        Map lookupMap = genericLookupBuilder.buildLookups();
        String action = helper.getRequestParameterValue(LookupMapConstants.PROCESS);
        String selectedLookup = helper.getRequestParameterValue(LookupMapConstants.SELECTED_LOOKUP);
        Iterator lookIterator = lookupMap.values().iterator();
        getCoreLookupData(lookIterator, selectedLookup);
        Iterator mappingListIterator = mappingList.iterator();
        List lookupDataList = getObjectForDisplay(mappingListIterator, helper);
        displLookUpObject = new LookUpObject(tableName, tableDisplayName, lookupDataList);
        setSessionParamn(helper, action);
        forwardToPage(helper);
    }

    private void forwardToPage(UCCHelper helper) throws IOException {
        helper.forward(LookupMapConstants.UPDATE_LOOKUP_JSP);
    }

    private void setSessionParamn(UCCHelper helper, String action) {
        helper.setSessionParameter(LookupMapConstants.PROCESS, action);
        helper.setSessionParameter(LookupMapConstants.LOOKUP_DATA, displLookUpObject);
    }

    private void getCoreLookupData(Iterator lookIterator, String selectedLookup) {
        while(lookIterator.hasNext()){
            LookUpObject lookUpObject = (LookUpObject) lookIterator.next();
            if (lookUpObject.getTableName().equalsIgnoreCase(selectedLookup)){
                tableName = lookUpObject.getTableName();
                tableDisplayName = lookUpObject.getTableDisplayName();
                mappingList = lookUpObject.getColumnMappingList();
            }
        }
    }

    public abstract List getObjectForDisplay(Iterator mappingListIterator, UCCHelper helper) throws IOException;

}
