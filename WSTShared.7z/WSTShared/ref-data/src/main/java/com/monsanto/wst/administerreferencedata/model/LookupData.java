package com.monsanto.wst.administerreferencedata.model;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 9:27:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class LookupData {

    private String id;
    private String type;
    private String active;
    private String description;
    private String modUser;
    private Date modDate;

    private List errorList;

	public LookupData() {
	}

	public LookupData(String lookupId, String lookupType, String activeStatus, String lookupDescription, String modUser, Date modDate) {
        this.id = lookupId;
        this.type = lookupType;
        this.active = activeStatus;
        this.description = lookupDescription;
        this.modUser = modUser;
        this.modDate = modDate;
    }
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getModUser() {
		return modUser;
	}

	public void setModUser(String modUser) {
		this.modUser = modUser;
	}

	public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public List getErrorList() {
		return errorList;
	}

	public void setErrorList(List errorList) {
		this.errorList = errorList;
	}
}
