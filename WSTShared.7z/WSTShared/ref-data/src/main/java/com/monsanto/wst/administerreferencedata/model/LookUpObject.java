package com.monsanto.wst.administerreferencedata.model;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 10:05:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class LookUpObject {

    private String tableName;
    private String tableDisplayName;
    private List columnMappingList;

    public LookUpObject(String tableName, String tableDisplayName, List columnMappingList) {
        this.tableName = tableName;
        this.tableDisplayName = tableDisplayName;
        this.columnMappingList = columnMappingList;
    }

    public String getTableName() {
        return tableName;
    }

    public String getTableDisplayName() {
        return tableDisplayName;
    }

    public List getColumnMappingList() {
        return columnMappingList;
    }
}
