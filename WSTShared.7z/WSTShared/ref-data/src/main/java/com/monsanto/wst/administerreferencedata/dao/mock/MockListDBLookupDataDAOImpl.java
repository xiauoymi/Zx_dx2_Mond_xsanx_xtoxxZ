package com.monsanto.wst.administerreferencedata.dao.mock;

import com.monsanto.wst.administerreferencedata.dao.ListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 10:15:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockListDBLookupDataDAOImpl extends ListDBLookupDataDAOImpl {
  public MockListDBLookupDataDAOImpl() {
    super(LookupMapConstants.LOOKUP_XML_LOCATION);
  }

  public Map listLookupData(LookUpObject lookUpObject, String query) {
        Map lookupTableDataMap = new LinkedHashMap();
        LookupData lookupData = null;
        lookupData = new LookupData("ID","TYPE1","Y","DESC1","USER1",new Date(System.currentTimeMillis()));
        lookupTableDataMap.put("ID", lookupData);
        lookupData = new LookupData("ID2","TYPE2","N","DESC2","USER2",new Date(System.currentTimeMillis()));
        lookupTableDataMap.put("ID2", lookupData);
        lookupData = new LookupData("ID3","TYPE3","Y","DESC3","USER3",new Date(System.currentTimeMillis()));
        lookupTableDataMap.put("ID3", lookupData);
        return lookupTableDataMap;
    }
}
