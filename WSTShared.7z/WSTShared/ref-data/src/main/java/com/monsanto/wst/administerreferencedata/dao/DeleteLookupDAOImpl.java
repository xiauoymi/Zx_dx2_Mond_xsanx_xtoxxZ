package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 10:43:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteLookupDAOImpl implements DeleteLookupDAO{
  private final String lookupXmlLocation;

  public DeleteLookupDAOImpl(String lookupXmlLocation) {
    this.lookupXmlLocation = lookupXmlLocation;
  }

  public int deleteLookup(LookupData lookupData, String deleteQuery) {
        int numberOfRowsProcessed = 0;
        PersistentStoreConnection psConnection = null;
        PersistentStoreStatement persistentStoreStatement = null;
        try {
            psConnection = LookupDBUtils.createPersistentStore(lookupXmlLocation);
            persistentStoreStatement = psConnection.prepareStatement(deleteQuery);
            persistentStoreStatement.setParam(1, lookupData.getId());
            numberOfRowsProcessed = persistentStoreStatement.executeDelete();
        }
        catch (WrappingException e) {
          throw new RuntimeWrappingException(e.getNestedException());
        }
        finally {
            LookupDBUtils.closeConnections(persistentStoreStatement, psConnection);
        }
        return numberOfRowsProcessed;
    }
}
