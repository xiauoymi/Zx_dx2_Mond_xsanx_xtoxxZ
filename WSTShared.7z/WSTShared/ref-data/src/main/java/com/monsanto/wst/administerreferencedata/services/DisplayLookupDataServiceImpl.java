package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.dao.ListLookupDataDAO;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 4:27:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayLookupDataServiceImpl implements DisplayLookupDataService{

    private ListLookupDataDAO listDBLookupDataDAO;

    public DisplayLookupDataServiceImpl(ListLookupDataDAO listDBLookupDataDAO) {
        this.listDBLookupDataDAO = listDBLookupDataDAO;
    }

    public Map displayDataForLookup(Map lookupMap, String selectedLookup) {
        Iterator lookIterator = lookupMap.values().iterator();
        Map selectedLookupMap = new LinkedHashMap();
        while(lookIterator.hasNext()){
            LookUpObject lookUpObject = (LookUpObject) lookIterator.next();
            if (lookUpObject.getTableName().equalsIgnoreCase(selectedLookup)){
                selectedLookupMap = listDBLookupDataDAO.listLookupData(lookUpObject, buildRequiredTableSelectQuery(selectedLookup));
            }
        }
        return selectedLookupMap;
    }

    private String buildRequiredTableSelectQuery(String selectedLookup) {
        return "SELECT * FROM "+selectedLookup;
    }
}
