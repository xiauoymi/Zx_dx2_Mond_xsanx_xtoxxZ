package com.monsanto.wst.administerreferencedata.factory;

import com.monsanto.wst.administerreferencedata.builder.AddQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.EditQueryBuilder;
import com.monsanto.wst.administerreferencedata.builder.QueryBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:00:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueryBuilderFactory {

    public static QueryBuilder getQueryBuilder(String action) {
        QueryBuilder queryBuilder = null;
        if (action.equalsIgnoreCase(LookupMapConstants.ADD)){
            queryBuilder = new AddQueryBuilder();
        }
        if (action.equalsIgnoreCase(LookupMapConstants.EDIT)){
            queryBuilder = new EditQueryBuilder();
        }
        return queryBuilder;
    }
}
