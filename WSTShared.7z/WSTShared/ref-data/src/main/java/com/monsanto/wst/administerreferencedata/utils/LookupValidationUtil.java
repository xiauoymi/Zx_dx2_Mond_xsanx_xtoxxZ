package com.monsanto.wst.administerreferencedata.utils;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 12:51:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class LookupValidationUtil {

    public static String validateRequestParameter(UCCHelper helper, String parameterName, List errorList) throws IOException {
        String paramNameForValidation = helper.getRequestParameterValue(parameterName);
        updateErrorListForRequiredField(paramNameForValidation, errorList);
        return paramNameForValidation;
    }

    private static List updateErrorListForRequiredField(String value, List errorList) {
        if (StringUtils.isNullOrEmpty(value)){
            if (errorList!=null && errorList.size() == 0){
                errorList.add("Please Fill in the Required Fields");
            }
        }
        return errorList;
    }
}
