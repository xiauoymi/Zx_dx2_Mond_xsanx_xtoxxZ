package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.sorter.TableNameComparator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 21, 2006 Time: 9:45:00 AM
 */
public class GenericLookupBuilder {
    private final String xmlPath;
    private final Map lookupMap;

    public GenericLookupBuilder(String xmlPath) {
        if (xmlPath == null) {
            throw new RuntimeException("NULL XML PATH PROVIDED");
        }

        this.xmlPath = xmlPath;
        this.lookupMap = new LinkedHashMap();
    }

    public Map buildLookups() throws GenericLookupBuilderException {
        try {
            createXMLDocument();
        } catch (IOException e) {
            throw new GenericLookupBuilderException("Could Not create Input Document", e);
        } catch (SAXException e) {
            throw new GenericLookupBuilderException("Could Not create Input Document", e);
        }
        return lookupMap;
    }

    private void createXMLDocument() throws IOException, SAXException {
        ClassLoader classLoader = GenericLookupBuilder.class.getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(this.xmlPath);
        Document lookupDocXML = DOMUtil.newDocument(inputStream);
        buildLookupMap(lookupDocXML);
        buildDataBaseProperties(lookupDocXML);
    }

    private void buildDataBaseProperties(Document lookupDocXML) {
        buildSequenceName(lookupDocXML);
        buildPersistenceClass(lookupDocXML);
    }

    private void buildSequenceName(Document lookupDocXML) {
        String sequenceName = null;
        NodeList dbSequence = lookupDocXML.getElementsByTagName(LookupMapConstants.DB_SEQUENCE);
        for (int i = 0; i < dbSequence.getLength(); i++) {
            Node seqNode = dbSequence.item(i);
            sequenceName = DOMUtil.getTextValue(seqNode);
        }
        LookUpObject lookUpObject = new LookUpObject(LookupMapConstants.SEQUENCE, sequenceName, null);
        lookupMap.put(LookupMapConstants.SEQUENCE, lookUpObject);
    }

    private void buildPersistenceClass(Document lookupDocXML) {
        String persistenceName = null;
        NodeList dbSequence = lookupDocXML.getElementsByTagName(LookupMapConstants.PERSISTENCE_CLASS_ID);
        for (int i = 0; i < dbSequence.getLength(); i++) {
            Node persistenceNode = dbSequence.item(i);
            persistenceName = DOMUtil.getTextValue(persistenceNode);
        }
        LookUpObject lookUpObject = new LookUpObject(LookupMapConstants.PERSISTENCE_CLASS, persistenceName, null);
        lookupMap.put(LookupMapConstants.PERSISTENCE_CLASS, lookUpObject);
    }

    private void buildLookupMap(Document lookupDocXML) {
        NodeList tableLookupsList = lookupDocXML.getElementsByTagName(LookupMapConstants.LOOKUP);
        for (int i = 0; i < tableLookupsList.getLength(); i++) {
            Node lookupNode = tableLookupsList.item(i);
            String tableName = getDBTableName(lookupNode);
            String tableDisplayName = getDisplayNameForTable(lookupDocXML, i);
            Node columnsNode = DOMUtil.getChild(lookupNode, LookupMapConstants.COLUMNS);
            Node[] columns = DOMUtil.getChildren(columnsNode, LookupMapConstants.COLUMN);
            List columnMappingList = new ArrayList();
            createDBMappingAssociation(columns, columnMappingList);
            LookUpObject lookUpObject = new LookUpObject(tableName, tableDisplayName, columnMappingList);
            lookupMap.put(tableName, lookUpObject);
        }
        sort();
    }

    private void sort() {
        List list = new ArrayList(lookupMap.entrySet());
        Collections.sort(list, new TableNameComparator());
        lookupMap.clear();
        for (int i = 0; i < list.size(); i++) {
            LookUpObject lookUpObject = ((LookUpObject) ((Map.Entry) list.get(i)).getValue());
            lookupMap.put(lookUpObject.getTableName(), lookUpObject);
        }
    }

    private String getDisplayNameForTable(Document lookupDocXML, int i) {
        return DOMUtil.getTextValue(lookupDocXML.getElementsByTagName(LookupMapConstants.TABLE_DISPLAY_NAME).item(i));
    }

    private String getDBTableName(Node lookupNode) {
        return DOMUtil.getAttribute((Element) lookupNode, LookupMapConstants.ID);
    }

    private void createDBMappingAssociation(Node[] columns, List columnMappingList) {
        for (int j = 0; j < columns.length; j++) {
            Node columnNode = columns[j];
            String dbName = DOMUtil.getTextValue(DOMUtil.getChild(columnNode, LookupMapConstants.DB_NAME));
            String columnDisplayName = DOMUtil.getTextValue(DOMUtil.getChild(columnNode, LookupMapConstants.DISPLAY_NAME));
            String mappingName = DOMUtil.getTextValue(DOMUtil.getChild(columnNode, LookupMapConstants.MAPPING_OBJECT));
            ColumnMapping columnMapping = new ColumnMapping(dbName, columnDisplayName, mappingName);
            columnMappingList.add(columnMapping);
        }
    }

}
