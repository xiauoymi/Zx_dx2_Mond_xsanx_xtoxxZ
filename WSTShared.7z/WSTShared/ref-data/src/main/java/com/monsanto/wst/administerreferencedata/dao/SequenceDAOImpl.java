package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 23, 2006 Time: 4:05:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class SequenceDAOImpl implements SequenceDAO {
  private final String lookupXmlLocation;

  public SequenceDAOImpl(String lookupXmlLocation) {
    this.lookupXmlLocation = lookupXmlLocation;
  }

  public String getSequenceId(String sequenceQuery) {
    String seqId = "";
    PersistentStoreConnection psConnection = null;
    PersistentStoreStatement persistentStoreStatement = null;
    try {
      psConnection = LookupDBUtils.createPersistentStore(lookupXmlLocation);
      persistentStoreStatement = psConnection.prepareStatement(sequenceQuery);
      PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();
      PersistentStoreResultSetFwdIterator persistentStoreResultSetFwdIterator = persistentStoreResultSet
          .getForwardIterator();
      while (persistentStoreResultSetFwdIterator.next()) {
        seqId = persistentStoreResultSetFwdIterator.getString(LookupMapConstants.SEQUENCE);
      }
    } catch (WrappingException e) {
      throw new RuntimeWrappingException(e.getNestedException());
    }
    finally {
      LookupDBUtils.closeConnections(persistentStoreStatement, psConnection);
    }
    return seqId;
  }


}
