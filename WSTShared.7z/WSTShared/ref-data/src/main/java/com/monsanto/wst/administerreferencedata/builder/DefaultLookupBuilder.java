package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.model.BaseModel;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 10:34:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultLookupBuilder {

    public BaseModel createDefaultLookup(Map lookupMap, String selectedLookup) {
        List lookupList = new ArrayList(lookupMap.values());
        String defaultTable = null;
        String defaultTableDisplayName = null;
        if (selectedLookup == null || selectedLookup.equals("")){
            defaultTable = ((LookUpObject)lookupList.get(0)).getTableName();
            defaultTableDisplayName = ((LookUpObject)lookupList.get(0)).getTableDisplayName();
        }
        else{
            Iterator lookupListIterator = lookupList.iterator();
            while(lookupListIterator.hasNext()){
                LookUpObject lookUpObject = (LookUpObject) lookupListIterator.next();
                if (lookUpObject.getTableName().equalsIgnoreCase(selectedLookup)){
                    defaultTable = lookUpObject.getTableName();
                    defaultTableDisplayName = lookUpObject.getTableDisplayName();
                }
            }
        }
        return new BaseModel(defaultTable,defaultTableDisplayName);
    }
}
