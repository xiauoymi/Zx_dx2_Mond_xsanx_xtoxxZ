package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.SequenceDAO;
import com.monsanto.wst.administerreferencedata.dao.SequenceDAOImpl;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 25, 2006 Time: 9:28:55 AM To change this template use File |
 * Settings | File Templates.
 */
public class SequenceLookupServiceDBImpl implements SequenceLookupService {
  private final GenericLookupBuilder genericLookupBuilder;
  private final SequenceDAO sequenceDAO;

  public SequenceLookupServiceDBImpl(String xmlPath) {
    this.genericLookupBuilder = new GenericLookupBuilder(xmlPath);
    this.sequenceDAO = new SequenceDAOImpl(xmlPath);
  }

  public String getSequence() throws GenericLookupBuilderException {
    try {
      Map lookupMap = genericLookupBuilder.buildLookups();
      Iterator lookIterator = lookupMap.values().iterator();
      String dbSequenceName = getSequenceName(lookIterator);
      return getSequenceIdFromDB(dbSequenceName);
    } catch (GenericLookupBuilderException e) {
      throw new GenericLookupBuilderException("Could Not build Lookup", e);
    }
  }

  private String getSequenceName(Iterator lookIterator) {
    while (lookIterator.hasNext()) {
      LookUpObject lookUpObject = (LookUpObject) lookIterator.next();
      if (lookUpObject.getTableName().equalsIgnoreCase(LookupMapConstants.SEQUENCE)) {
        return lookUpObject.getTableDisplayName();
      }
    }

    throw new RuntimeException("No Sequence Name Found");
  }

  protected String getSequenceIdFromDB(String dbSequenceName) {
    return sequenceDAO.getSequenceId(buildSequenceQuery(dbSequenceName));
  }

  private String buildSequenceQuery(String dbSequenceName) {
    StringBuffer query = new StringBuffer();
    query.append("SELECT ").append(dbSequenceName).append(".NEXTVAL AS " + LookupMapConstants.SEQUENCE + " FROM DUAL");
    return query.toString();
  }
}
