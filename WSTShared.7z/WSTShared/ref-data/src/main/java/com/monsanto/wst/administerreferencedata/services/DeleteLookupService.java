package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 10:47:46 AM
 * To change this template use File | Settings | File Templates.
 */
public interface DeleteLookupService {

    public int deleteLookupData(String id, String selectedLookup) throws GenericLookupBuilderException;

}
