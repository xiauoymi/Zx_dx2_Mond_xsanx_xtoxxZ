package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:41:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class LookupObjectBuilder {


	public static LookUpObject getLookupObject(String selectedLookup, String xmlPath) throws GenericLookupBuilderException {
        LookUpObject queryLookUpObject = null;
        GenericLookupBuilder genericLookupBuilder = new GenericLookupBuilder(xmlPath);
        Map map = genericLookupBuilder.buildLookups();
        Iterator mapiterator = map.values().iterator();
        while(mapiterator.hasNext()){
            LookUpObject lookUpObject = (LookUpObject) mapiterator.next();
            if (lookUpObject.getTableName().equalsIgnoreCase(selectedLookup)){
                queryLookUpObject = lookUpObject;
            }
        }
        return queryLookUpObject;
    }
}
