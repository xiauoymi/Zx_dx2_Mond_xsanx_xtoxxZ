package com.monsanto.wst.administerreferencedata.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 2:40:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayModel {

    private ColumnMapping columnMapping;
    private Object objectValue;

    public DisplayModel(ColumnMapping columnMapping, Object objectType) {
        this.columnMapping = columnMapping;
        this.objectValue = objectType;
    }

    public ColumnMapping getColumnMapping() {
        return columnMapping;
    }

    public Object getObjectValue() {
        return objectValue;
    }
}
