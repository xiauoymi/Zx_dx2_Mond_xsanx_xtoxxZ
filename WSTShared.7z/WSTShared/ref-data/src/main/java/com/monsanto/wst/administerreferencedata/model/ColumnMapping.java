package com.monsanto.wst.administerreferencedata.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 1:48:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ColumnMapping {

    private String dbName;
    private String columnDisplayName;
    private String mappingName;

    public ColumnMapping(String dbName, String columnDisplayName, String mappingName) {
        this.dbName = dbName;
        this.columnDisplayName = columnDisplayName;
        this.mappingName = mappingName;
    }

    public String getDbName() {
        return dbName;
    }

    public String getColumnDisplayName() {
        return columnDisplayName;
    }

    public String getMappingName() {
        return mappingName;
    }

}
