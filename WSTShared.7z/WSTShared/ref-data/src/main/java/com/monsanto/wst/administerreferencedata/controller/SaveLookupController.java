package com.monsanto.wst.administerreferencedata.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.administerreferencedata.builder.LookupObjectBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupService;
import com.monsanto.wst.administerreferencedata.services.ProcessLookupServiceDBImpl;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupServiceDBImpl;
import com.monsanto.wst.administerreferencedata.utils.LookupValidationUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 11:02:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaveLookupController implements UseCaseController {

	private LookupData lookupData = null;
	private ProcessLookupService service = null;
	private SequenceLookupService sequenceLookupService = null;
	private UCCHelper helper = null;
	private String xmlPath = LookupMapConstants.LOOKUP_XML_LOCATION;

	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}

	public SaveLookupController() {
	}

	public SaveLookupController(ProcessLookupService service, SequenceLookupService sequenceLookupService) {
		this.service = service;
		this.sequenceLookupService = sequenceLookupService;
	}


	public void run(UCCHelper helper) throws IOException {
		if(service==null)
			service = new ProcessLookupServiceDBImpl(this.xmlPath);
		if(sequenceLookupService == null)
			sequenceLookupService = new SequenceLookupServiceDBImpl(this.xmlPath);
		this.helper = helper;
		getLookupDataImpl();
	}

	protected LookupData getLookupDataImpl() throws IOException {
		this.lookupData = new LookupData();
		setErrorList(helper);
		validateRequestParameters(helper);
		processBasedOnValidation(helper);
		return this.lookupData;
	}
	private void validateRequestParameters(UCCHelper helper) throws IOException {
		if (helper.getRequestParameterValue(LookupMapConstants.PROCESS).equalsIgnoreCase(LookupMapConstants.ADD)){
			this.lookupData.setId(getSequenceNumber());
		}
		if (helper.getRequestParameterValue(LookupMapConstants.PROCESS).equalsIgnoreCase(LookupMapConstants.EDIT)){
			this.lookupData.setId(helper.getRequestParameterValue(LookupMapConstants.ID));
		}
		this.lookupData.setType(LookupValidationUtil.validateRequestParameter(helper, LookupMapConstants.MAPPING_TYPE, lookupData.getErrorList()));
		this.lookupData.setDescription(LookupValidationUtil.validateRequestParameter(helper, LookupMapConstants.MAPPING_DESCRIPTION, lookupData.getErrorList()));
		if (helper.getRequestParameterValue(LookupMapConstants.MAPPING_ACTIVE) == null){
			this.lookupData.setActive(LookupMapConstants.NO);
		}
		else{
			this.lookupData.setActive(LookupMapConstants.YES);
		}
		this.lookupData.setModUser(LookupMapConstants.ADMIN);
		this.lookupData.setModDate(new Date(System.currentTimeMillis()));
	}
	private void setErrorList(UCCHelper helper) {
		this.lookupData.setErrorList((List) helper.getRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST));
		if(lookupData.getErrorList()==null){
			lookupData.setErrorList(new ArrayList());
			helper.setRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST,lookupData.getErrorList());
		}
	}
	private void processBasedOnValidation(UCCHelper helper) throws IOException {
		if (lookupData.getErrorList().size()>0){
			processOnErrors(helper);
		}else{
			processForNoErrors(helper);
		}
	}

	protected void processForNoErrors(UCCHelper helper) throws IOException {
		LookUpObject lookUpObject = null;
		try {
			lookUpObject = LookupObjectBuilder.getLookupObject(helper.getRequestParameterValue(LookupMapConstants.TABLE_NAME), xmlPath);
			String processCommand = helper.getRequestParameterValue(LookupMapConstants.PROCESS);
			processLookup(lookUpObject, processCommand);
			helper.setRequestAttributeValue(LookupMapConstants.SAVED_LOOKUP, this);
			updateSuccessList(helper);
		} catch (GenericLookupBuilderException e) {
			throw new IOException("Could Not get Selected Object");
		}
	}
	private void processLookup(LookUpObject lookUpObject, String processCommand) throws IOException{
		service.processLookup(lookUpObject, processCommand, this.lookupData);
	}
	private void processOnErrors(UCCHelper helper) throws IOException {
		helper.setRequestAttributeValue(LookupMapConstants.LOOKUP_ERROR_LIST, this.lookupData.getErrorList());
		helper.forward(LookupMapConstants.UPDATE_LOOKUP_JSP);
	}
	private void updateSuccessList(UCCHelper helper) throws IOException {
		List successList = new ArrayList();
		successList.add(LookupMapConstants.LOOKUP_SUCCESS_MSG);
		helper.setRequestAttributeValue(LookupMapConstants.LOOKUP_SUCCESS_LIST, successList);
		helper.forward(LookupMapConstants.MAPPING_DISPLAY_SERVLET+"?selectedLookup="+helper.getRequestParameterValue(LookupMapConstants.TABLE_NAME));
	}
	private String getSequenceNumber() throws IOException {
		try {
			return sequenceLookupService.getSequence();
		} catch (GenericLookupBuilderException e) {
			throw new IOException("Could Not Get Sequence Number");
		}
	}

}
