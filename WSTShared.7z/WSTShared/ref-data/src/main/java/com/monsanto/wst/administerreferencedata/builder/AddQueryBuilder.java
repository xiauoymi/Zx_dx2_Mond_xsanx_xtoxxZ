package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.model.ColumnMapping;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 2:06:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddQueryBuilder implements com.monsanto.wst.administerreferencedata.builder.QueryBuilder {

    public String buildQuery(LookUpObject lookUpObject) {
        StringBuffer mainBuffer = new StringBuffer();
      mainBuffer.append(getInsertString());
      mainBuffer.append(lookUpObject.getTableName());
      mainBuffer.append(getColumnMappings(lookUpObject.getColumnMappingList()));
      mainBuffer.append(getValueString());
      mainBuffer.append(getBindVariables(lookUpObject.getColumnMappingList()));
      return mainBuffer.toString();
    }

    private String getValueString() {
        return " VALUES ";
    }

    private String getInsertString() {
        return "INSERT INTO ";
    }

    private String getBindVariables(List columnMappingList) {
        StringBuffer mappingQuery = new StringBuffer();
        mappingQuery.append("(");
        for (int i=0;i<columnMappingList.size()-1;i++){
            mappingQuery.append("?,");
        }
        mappingQuery.append("?");
        mappingQuery.append(")");
        return mappingQuery.toString();
    }

    private String getColumnMappings(List columnMappingList) {
        StringBuffer mappingQuery = new StringBuffer();
        mappingQuery.append("(");
        if (columnMappingList!=null && columnMappingList.size()>0){
            Iterator columnIterator = columnMappingList.iterator();
            while(columnIterator.hasNext()){
                ColumnMapping columnMapping = (ColumnMapping) columnIterator.next();
                if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.ID)){
                    mappingQuery.append(columnMapping.getDbName()).append(",");
                }if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_TYPE)){
                    mappingQuery.append(columnMapping.getDbName()).append(",");
                }if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_ACTIVE)){
                    mappingQuery.append(columnMapping.getDbName()).append(",");
                }if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_DESCRIPTION)){
                    mappingQuery.append(columnMapping.getDbName()).append(",");
                }if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_USER)){
                    mappingQuery.append(columnMapping.getDbName()).append(",");
                }if (columnMapping.getMappingName().equalsIgnoreCase(LookupMapConstants.MAPPING_MOD_DATE)){
                    mappingQuery.append(columnMapping.getDbName());
                }
            }
        }
        mappingQuery.append(")");
        return mappingQuery.toString();
    }
}
