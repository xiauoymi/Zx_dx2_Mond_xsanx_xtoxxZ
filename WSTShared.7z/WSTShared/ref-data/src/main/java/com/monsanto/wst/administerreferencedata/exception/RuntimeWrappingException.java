package com.monsanto.wst.administerreferencedata.exception;
/*
 RuntimeWrappingException was created on Mar 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public class RuntimeWrappingException extends RuntimeException {
  public RuntimeWrappingException(Exception nestedException) {
    super(nestedException);
  }
}
