package com.monsanto.wst.administerreferencedata.services;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 4:23:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DisplayLookupDataService {

    public Map displayDataForLookup(Map lookupMap, String selectedLookup);

}
