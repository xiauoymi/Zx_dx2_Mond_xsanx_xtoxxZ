package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.exception.RuntimeWrappingException;
import com.monsanto.wst.administerreferencedata.model.LookupData;
import com.monsanto.wst.administerreferencedata.persistence.LookupDBUtils;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 23, 2006 Time: 4:16:48 PM To change this template use File |
 * Settings | File Templates.
 */
public class UpdateLookupDAOImpl implements ProcessLookupDAO {
  private String lookupXmlLocation;

  public UpdateLookupDAOImpl(String lookupXmlLocation) {
    this.lookupXmlLocation = lookupXmlLocation;
  }

  public int updateLookup(LookupData lookupData, String processQuery) {
    int numberOfRowsProcessed = 0;
    PersistentStoreConnection psConnection = null;
    PersistentStoreStatement persistentStoreStatement = null;
    try {
      psConnection = LookupDBUtils.createPersistentStore(lookupXmlLocation);
      persistentStoreStatement = psConnection.prepareStatement(processQuery);
      persistentStoreStatement.setParam(1, lookupData.getType());
      persistentStoreStatement.setParam(2, lookupData.getActive());
      persistentStoreStatement.setParam(3, lookupData.getDescription());
      persistentStoreStatement.setParam(4, lookupData.getModUser());
      persistentStoreStatement.setParam(5, lookupData.getModDate());
      persistentStoreStatement.setParam(6, lookupData.getId());
      numberOfRowsProcessed = persistentStoreStatement.executeUpdate();
    }
    catch (WrappingException e) {
      throw new RuntimeWrappingException(e.getNestedException());
    }
    finally {
      LookupDBUtils.closeConnections(persistentStoreStatement, psConnection);
    }
    return numberOfRowsProcessed;
  }
}
