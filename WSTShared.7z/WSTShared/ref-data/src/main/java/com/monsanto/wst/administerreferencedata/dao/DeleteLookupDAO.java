package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.wst.administerreferencedata.model.LookupData;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 10:41:51 AM
 * To change this template use File | Settings | File Templates.
 */
public interface DeleteLookupDAO {

    public int deleteLookup(LookupData lookupData, String deleteQuery);

}
