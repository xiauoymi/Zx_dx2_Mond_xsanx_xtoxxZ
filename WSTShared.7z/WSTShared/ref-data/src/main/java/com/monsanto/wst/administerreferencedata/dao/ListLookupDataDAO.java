package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 4:34:04 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ListLookupDataDAO {

    public Map listLookupData(LookUpObject lookUpObject, String query);

}
