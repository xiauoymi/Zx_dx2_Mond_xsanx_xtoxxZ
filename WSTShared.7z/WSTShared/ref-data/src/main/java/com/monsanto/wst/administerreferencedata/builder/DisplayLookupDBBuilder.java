package com.monsanto.wst.administerreferencedata.builder;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.dao.ListDBLookupDataDAOImpl;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.BaseModel;
import com.monsanto.wst.administerreferencedata.services.DisplayLookupDataServiceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 23, 2006 Time: 9:42:25 AM To change this template use File |
 * Settings | File Templates.
 */
public class DisplayLookupDBBuilder {
  private Map lookupMap = null;
  private BaseModel lookupModel = null;

  private final ListLookupDBBuilder listLookupDBBuilder;
  private final DefaultLookupBuilder defaultLookupBuilder;
  private final GenericLookupBuilder builder;

  private static final List NON_LOOKUP_ELEMENTs = getNonLookupElements();
  private final String xmlPath;

  public DisplayLookupDBBuilder(String xmlPath) {
    if (xmlPath == null) {
      throw new NullPointerException("XML Path cannot be null");
    }
    this.xmlPath = xmlPath;
    builder = new GenericLookupBuilder(xmlPath);
    listLookupDBBuilder = getListLookupBuilderImpl();
    defaultLookupBuilder = new DefaultLookupBuilder();
  }

  private static List getNonLookupElements() {
    List elements = new ArrayList();
    elements.add(LookupMapConstants.PERSISTENCE_CLASS);
    elements.add(LookupMapConstants.SEQUENCE);
    return elements;
  }

  public void displayLookupDataFromDB(UCCHelper helper) throws IOException {
    try {
      lookupMap = builder.buildLookups();
    } catch (GenericLookupBuilderException e) {
      throw new IOException(LookupMapConstants.LOOKUP_ELEMENTS_ERROR_MSG);
    }
    removeNonLookupTableObjects();
    lookupModel = defaultLookupBuilder
        .createDefaultLookup(lookupMap, helper.getRequestParameterValue(LookupMapConstants.SELECTED_LOOKUP));
    Map lookupDataMap = listLookupDBBuilder.listSelectedLookupData(lookupMap, lookupModel.getId());
    setSessionParams(helper, lookupDataMap);
    forwardToPage(helper);
  }

  private void removeNonLookupTableObjects() {
    Iterator nonLookIterator = NON_LOOKUP_ELEMENTs.iterator();
    while (nonLookIterator.hasNext()) {
      String nonLookElement = (String) nonLookIterator.next();
      if (lookupMap.containsKey(nonLookElement)) {
        lookupMap.remove(nonLookElement);
      }
    }
  }

  private ListLookupDBBuilder getListLookupBuilderImpl() {
    return new ListLookupDBBuilder(getServiceImplementation());
  }

  private DisplayLookupDataServiceImpl getServiceImplementation() {
    return new DisplayLookupDataServiceImpl(getDAOImplementation());
  }

  protected ListDBLookupDataDAOImpl getDAOImplementation() {
    return new ListDBLookupDataDAOImpl(xmlPath);
  }

  private void forwardToPage(UCCHelper helper) throws IOException {
    helper.forward(LookupMapConstants.DISPLAY_LOOKUP_JSP);
  }

  private void setSessionParams(UCCHelper helper, Map lookupDataMap) {
    helper.setSessionParameter(LookupMapConstants.LOOKUP_DATA_MAP, lookupDataMap);
    helper.setSessionParameter(LookupMapConstants.DEFAULT_LOOKUP, lookupModel);
    helper.setSessionParameter(LookupMapConstants.LOOKUPMAP, lookupMap);
  }


}
