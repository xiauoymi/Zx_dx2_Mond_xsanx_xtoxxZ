package com.monsanto.wst.administerreferencedata.model;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 22, 2006
 * Time: 10:37:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class BaseModel{

    private String id;
    private String value;

    public BaseModel(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

}
