package com.monsanto.wst.administerreferencedata.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 21, 2006
 * Time: 9:59:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenericLookupBuilderException extends Exception {

    public GenericLookupBuilderException(String message, Exception e) {
        super(message, e);
    }

  public GenericLookupBuilderException(String message) {
    super(message);
  }
}
