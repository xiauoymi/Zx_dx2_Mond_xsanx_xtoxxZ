package com.monsanto.wst.administerreferencedata.model.mock;

import com.monsanto.wst.administerreferencedata.model.LookupData;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 4:34:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockLookupData extends LookupData {

    public MockLookupData(String lookupId, String lookupType, String activeStatus, String lookupDescription, String modUser, Date modDate) {
        super(lookupId, lookupType, activeStatus, lookupDescription, modUser, modDate);
    }
}
