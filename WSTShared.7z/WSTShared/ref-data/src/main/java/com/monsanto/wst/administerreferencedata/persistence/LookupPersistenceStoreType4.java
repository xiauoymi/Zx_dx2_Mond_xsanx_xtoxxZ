package com.monsanto.wst.administerreferencedata.persistence;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType4;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.dbtemplate.domain.xml.XMLDataSourceParser;

public class LookupPersistenceStoreType4 implements CorePersistenceStore {

    private static PersistentStore RetVal;

    protected static PersistentStore getStoreInstance(String userName, String encryptedPassword, String sid, String server, int port) throws WrappingException {
        if (RetVal == null) {
            RetVal = new PersistentStoreOracleCachedType4(userName, encryptedPassword, server, port, sid, 0, 10);
        }
        return (PersistentStore) Logger.traceExit(RetVal);
    }

    public PersistentStore getStore() throws WrappingException {

        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        XMLDataSourceParser parser = new XMLDataSourceParser(xmlUtils, getDBTemplateConfigLocation(), xpathUtils);

        Logger.traceEntry();
        String lsifunction = System.getProperty("lsi.function");
        String userName = parser.getString(lsifunction + ".UserName");
        String datasource = parser.getString(lsifunction + ".DataSource");
        String password = parser.getString(lsifunction + ".Password");
        String server = datasource;
        int port = Integer.parseInt(parser.getString(lsifunction + ".Port"));

        return getStoreInstance(userName, password, datasource, server, port);
    }

    protected String getDBTemplateConfigLocation() {
        return "database/dbtemplate-config.xml";
    }
}
