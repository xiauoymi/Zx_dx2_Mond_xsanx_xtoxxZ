package com.monsanto.wst.administerreferencedata.services.mock;

import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 25, 2006
 * Time: 9:50:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockSequenceLookupServiceImpl implements SequenceLookupService {

    public String getSequence() throws GenericLookupBuilderException {
        return "999";
    }
}
