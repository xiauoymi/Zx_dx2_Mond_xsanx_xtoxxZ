package com.monsanto.wst.administerreferencedata.services;

import com.monsanto.wst.administerreferencedata.builder.QueryBuilder;
import com.monsanto.wst.administerreferencedata.dao.ProcessLookupDAO;
import com.monsanto.wst.administerreferencedata.factory.ProcessLookupDAOFactory;
import com.monsanto.wst.administerreferencedata.factory.QueryBuilderFactory;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;
import com.monsanto.wst.administerreferencedata.model.LookupData;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 24, 2006
 * Time: 8:42:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessLookupServiceDBImpl implements ProcessLookupService{
    private final ProcessLookupDAOFactory lookupDaoFactory;
    private ProcessLookupDAO processLookupDAO = null;

  public ProcessLookupServiceDBImpl(ProcessLookupDAO processLookupDAO) {
    //todo this constructor is only used by tests -- see if it can be eliminated
    lookupDaoFactory = new ProcessLookupDAOFactory(null);
		this.processLookupDAO = processLookupDAO;
	}

  public ProcessLookupServiceDBImpl(String xmlPath) {
    lookupDaoFactory = new ProcessLookupDAOFactory(xmlPath);
  }

  public int processLookup(LookUpObject lookUpObject, String processCommand, LookupData lookupData) throws IOException {
        QueryBuilder queryBuilder = QueryBuilderFactory.getQueryBuilder(processCommand);
        String lookupQuery = queryBuilder.buildQuery(lookUpObject);
		if(processLookupDAO == null) {
      processLookupDAO = lookupDaoFactory.getProcessDAO(processCommand);
		}
        return processLookupData(lookupQuery, lookupData);
    }

    protected int processLookupData(String lookupQuery, LookupData lookupData) {
        return processLookupDAO.updateLookup(lookupData, lookupQuery);
    }


}
