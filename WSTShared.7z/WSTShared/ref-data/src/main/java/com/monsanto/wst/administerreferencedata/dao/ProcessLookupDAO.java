package com.monsanto.wst.administerreferencedata.dao;

import com.monsanto.wst.administerreferencedata.model.LookupData;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 23, 2006
 * Time: 3:06:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessLookupDAO {

    public int updateLookup(LookupData lookupData, String processQuery);

}
