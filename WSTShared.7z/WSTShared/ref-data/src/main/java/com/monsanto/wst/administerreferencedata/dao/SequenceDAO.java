package com.monsanto.wst.administerreferencedata.dao;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 25, 2006
 * Time: 9:33:26 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SequenceDAO {

    String getSequenceId(String sequenceQuery);
}
