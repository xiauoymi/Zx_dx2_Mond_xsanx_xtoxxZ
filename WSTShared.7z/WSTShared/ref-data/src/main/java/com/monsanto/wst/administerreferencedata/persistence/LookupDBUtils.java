package com.monsanto.wst.administerreferencedata.persistence;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.administerreferencedata.builder.GenericLookupBuilder;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.model.LookUpObject;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by User: rgeorge Date: Aug 24, 2006 Time: 2:11:12 PM
 */
public class LookupDBUtils {
    public static PersistentStoreConnection createPersistentStore(String lookupXmlLocation) throws WrappingException {
        GenericLookupBuilder genericLookupBuilder = new GenericLookupBuilder(lookupXmlLocation);
        try {
            genericLookupBuilder.buildLookups();
        } catch (GenericLookupBuilderException e) {
            throw new WrappingException(e);
        }
        String persistentClassString = getPersistenceClassString(genericLookupBuilder);
        CorePersistenceStore persistenceClassInstance = getInstanceOfPersistenceClass(persistentClassString);
        PersistentStore persistenceStore = persistenceClassInstance.getStore();
        PersistentStore.registerInstance(persistenceStore);
        return persistenceStore.connect();
    }

    public static void closeConnections(PersistentStoreStatement perStat, PersistentStoreConnection psConnection) {
        closeStatementIfNeeded(perStat);
        closeConnectionIfNeeded(psConnection);
    }

    private static CorePersistenceStore getInstanceOfPersistenceClass(String persistentClassString) throws WrappingException {
        try {
            return (CorePersistenceStore) Class.forName(persistentClassString).newInstance();
        } catch (ClassNotFoundException e) {
            throw new WrappingException(e);
        } catch (InstantiationException e) {
            throw new WrappingException(e);
        } catch (IllegalAccessException e) {
            throw new WrappingException(e);
        }
    }

    private static String getPersistenceClassString(GenericLookupBuilder genericLookupBuilder) throws WrappingException {
        try {
            Map lookupMap = genericLookupBuilder.buildLookups();
            Iterator lookIterator = lookupMap.values().iterator();
            while (lookIterator.hasNext()) {
                LookUpObject lookUpObject = (LookUpObject) lookIterator.next();
                String tableName = lookUpObject.getTableName();
                String tableDisplayName = lookUpObject.getTableDisplayName();

                if (LookupMapConstants.PERSISTENCE_CLASS.equalsIgnoreCase(tableName)) {
                    return tableDisplayName;
                } else {
                }
            }
        } catch (GenericLookupBuilderException e) {
            throw new WrappingException(e);
        }

        throw new RuntimeException("No definitiaon for " + LookupMapConstants.PERSISTENCE_CLASS + " was found.");
    }

    private static void closeStatementIfNeeded(PersistentStoreStatement perStat) {
        if (perStat != null) {
            try {
                perStat.close();
            } catch (WrappingException e) {
                // ignore exception on close
            }
        }
    }

    private static void closeConnectionIfNeeded(PersistentStoreConnection psConnection) {
        if (psConnection != null) {
            try {
                psConnection.close();
            } catch (WrappingException e) {
                // ignore exception on close
            }
        }
    }
}
