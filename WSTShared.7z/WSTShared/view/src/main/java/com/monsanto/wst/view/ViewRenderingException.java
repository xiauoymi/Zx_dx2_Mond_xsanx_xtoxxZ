package com.monsanto.wst.view;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 16, 2005
 * Time: 11:01:32 AM
 * <p/>
 * This class is a custom exception that is used when an exception occurs while trying to render a particular view.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ViewRenderingException extends RuntimeException {

  /**
   * This constructor takes a message.
   *
   * @param message String representing the message.
   */
  public ViewRenderingException(String message) {
      super(message);
  }

public ViewRenderingException(String message, Throwable cause) {
  super(message, cause);
}

}
