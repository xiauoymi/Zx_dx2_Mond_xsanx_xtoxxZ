package com.monsanto.wst.view;

import com.monsanto.ServletFramework.UCCHelper;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 16, 2005
 * Time: 10:19:48 AM
 * <p/>
 * This interface defines the public API for a view object.  View objects are used to render a specific view like a JSP
 * page, a XML feed or a POS.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface View {

    /**
     * This method renders the appropriate view using the specified UCCHelper object.
     *
     * @param helper UCCHelper object used to perform tasks on the request and response.
     * @throws ViewRenderingException - If unable to render view.
     */
    public void renderView(UCCHelper helper) throws ViewRenderingException;

}
