package com.monsanto.wst.view;

/**
 * Created by IntelliJ IDEA.
 * Date: Jan 23, 2006
 * Time: 11:22:51 AM
 * <p/>
 * This class is a custom exception for reporting that a view was not found.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ViewNotFoundException extends RuntimeException {

    /**
     * This constructor takes a message.
     *
     * @param message String representing a message.
     */
    public ViewNotFoundException(String message) {
        super(message);
    }

}
