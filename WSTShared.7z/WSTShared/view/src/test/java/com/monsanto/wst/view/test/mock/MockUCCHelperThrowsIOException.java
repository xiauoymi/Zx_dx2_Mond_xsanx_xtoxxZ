package com.monsanto.wst.view.test.mock;

import com.monsanto.ServletFramework.Test.MockUCCHelper;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 7, 2006
 * Time: 2:20:16 PM
 * <p/>
 * Mock object for testing when the helper throws IOExceptions.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockUCCHelperThrowsIOException extends MockUCCHelper {
    public MockUCCHelperThrowsIOException(String cstrRequestedURL) {
        super(cstrRequestedURL);
    }

    public void forward(String cstrTo) throws IOException {
        throw new IOException("Test");
    }

    public Object getSessionParameter(String parameterName) {
        throw new RuntimeException("Test Exception");
    }

    public OutputStream getBinaryStream() throws IOException {
        throw new IOException("Test Exception");
    }

    public String getRequestParameterValue(String parameterName) throws IOException {
        throw new IOException("Test Exception");
    }

}
