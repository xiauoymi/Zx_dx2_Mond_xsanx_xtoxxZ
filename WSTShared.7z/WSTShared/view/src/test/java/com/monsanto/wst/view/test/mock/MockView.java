package com.monsanto.wst.view.test.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Jun 13, 2006
 * Time: 2:33:24 PM
 * <p/>
 * This class is a mock implementation of the view interface.  Used primarily for testing controllers.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockView implements View {

    private boolean viewRendered = false;

    public void renderView(UCCHelper helper) throws ViewRenderingException {
        this.viewRendered = true;
    }

    public void renderViewWithType(UCCHelper helper, List list, String type) throws ViewRenderingException {
        this.viewRendered = true;
    }

    public boolean wasViewRendered() {
        return this.viewRendered;
    }

}
