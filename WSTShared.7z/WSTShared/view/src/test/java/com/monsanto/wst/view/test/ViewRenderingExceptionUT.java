package com.monsanto.wst.view.test;

import com.monsanto.wst.view.ViewRenderingException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 16, 2005
 * Time: 11:00:04 AM
 * <p/>
 * This class is a junit test case for the ViewRenderingException.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ViewRenderingExceptionUT extends TestCase {

    public void testConstructor() {
        ViewRenderingException exception = new ViewRenderingException("Test Exception");
        assertNotNull(exception);
        assertEquals("Test Exception", exception.getMessage());
    }

}
