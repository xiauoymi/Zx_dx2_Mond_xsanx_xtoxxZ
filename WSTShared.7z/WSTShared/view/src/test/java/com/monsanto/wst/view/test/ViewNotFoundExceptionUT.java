package com.monsanto.wst.view.test;

import com.monsanto.wst.view.ViewNotFoundException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Jan 23, 2006
 * Time: 11:21:53 AM
 * <p/>
 * This class is a junit test case for the ViewNotFoundException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ViewNotFoundExceptionUT extends TestCase {

    public void testConstructor() {
        ViewNotFoundException exception = new ViewNotFoundException("Test Message");
        assertNotNull(exception);
        assertEquals("Test Message", exception.getMessage());
    }

}
