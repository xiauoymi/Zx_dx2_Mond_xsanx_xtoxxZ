package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.xml.XMLParserException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 9:23:05 AM
 * <p/>
 * This class is a junit test case for the XMLParserException class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLParserExceptionUT extends TestCase {

    public void testConstructorNoArgs() {
        XMLParserException exception = new XMLParserException();
        assertNotNull(exception);
    }

    public void testConstructorString() {
        XMLParserException exception = new XMLParserException("test");
        assertNotNull(exception);
        assertEquals("test", exception.getMessage());
    }

    public void testConstructorThrowable() {
        RuntimeException testEx = new RuntimeException();
        XMLParserException exception = new XMLParserException(testEx);
        assertNotNull(exception);
        assertEquals(testEx, exception.getCause());
    }

    public void testConstructorStringThrowable() {
        RuntimeException testEx = new RuntimeException();
        XMLParserException exception = new XMLParserException("test", testEx);
        assertNotNull(exception);
        assertEquals("test", exception.getMessage());
        assertEquals(testEx, exception.getCause());
    }

}
