package com.monsanto.wst.commonutils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 1:48:35 PM
 * <p/>
 * Unit test for TestUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TestUtilsUT extends TestCase {
  public void testCreate() throws Exception {
    TestUtils testUtils = new TestUtils();
    assertNotNull(testUtils);
  }

  public void testSetupLogging() throws Exception {
    TestUtils testUtils = new TestUtils();
    Logger.closeLogging();
    assertFalse(Logger.isEnabled(Logger.DEBUG_LOG));
    testUtils.setupLogging("CommonUtils");
    assertTrue(Logger.isEnabled(Logger.DEBUG_LOG));
  }

  public void testTearDownLogging() throws Exception {
    TestUtils testUtils = new TestUtils();
    testUtils.setupLogging("CommonUtils");
    assertTrue(Logger.isEnabled(Logger.DEBUG_LOG));
    testUtils.tearDownLogging();
    assertFalse(Logger.isEnabled(Logger.DEBUG_LOG));
  }
}
