package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLValidationException;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import java.io.*;
import java.net.URL;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 8:44:57 AM
 * <p/>
 * This class is a junit test case for the XMLUtilities class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLUtilitiesUT extends TestCase {

    private static final String DEFAULT_XML_READER = "org.apache.xerces.parsers.SAXParser";

    protected void tearDown() throws Exception {
        Properties props = System.getProperties();
        props.remove("javax.xml.parsers.DocumentBuilderFactory");
        props.remove("javax.xml.transform.TransformerFactory");
        System.setProperties(props);
        super.tearDown();
    }

    public void testConstructorWithCustomXMLReader() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        assertNotNull(utils);
    }

    public void testConstructorWithDefaultXMLReader() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils());
        assertNotNull(utils);
    }

    public void testCreateDocument() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument();
            assertNotNull(doc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("see stack trace");
        }
    }

    public void testCreateDocumentThrowsParserException() {
        System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockDocumentBuilderFactory");
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.createDocument();
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to create a new document.", e.getMessage());
        }
    }

    public void testCreateDocument_String() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        Document doc = null;
        try {
            doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            assertNotNull(doc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document.");
        }
    }

    public void testCreateDocument_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.createDocument("com/monsanto/wst/commonutils/xml/test/invalid-xml.xml");
            fail("Should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to parse document.", e.getMessage());
        }
    }

    public void testCreateDocument_DoesNotExist() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.createDocument("com/monsanto/wst/commonutils/xml/test/does-not-exist.xml");
            fail("Should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to open or read file at path: " +
                    "'com/monsanto/wst/commonutils/xml/test/does-not-exist.xml'", e.getMessage());
        }
    }

    public void testCreateDocument_ParserConfigException() {
        System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockDocumentBuilderFactory");
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to retrieve new parser.", e.getMessage());
        }
    }

    public void testGetElementByTagName() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        Document doc = null;
        try {
            doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document.");
        }
        Element chartElement = utils.getElementByTagName(doc, "bean");
        assertNotNull(chartElement);

        Element sizeElement = utils.getElementByTagName(chartElement, "constructor-arg");
        assertNotNull(sizeElement);

        chartElement = utils.getElementByTagName(doc, "blah");
        assertNull(chartElement);

        assertNull(utils.getElementByTagName(null, "blah"));
    }

    public void testGetElementById() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        Document doc = null;
        try {
            doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document.");
        }
        Element beanElement = utils.getElementById(doc, "testSingletonBean");
        assertNotNull(beanElement);
        assertEquals("com.monsanto.ApplicationContainer.TestSingletonBean", beanElement.getAttribute("class"));

        beanElement = utils.getElementById(doc, "blah");
        assertNull(beanElement);

        beanElement = utils.getElementById(doc, "nestedTest");
        assertNotNull(beanElement);
        assertEquals("some.other.class", beanElement.getAttribute("class"));

        beanElement = utils.getElementById(doc, "thirdLayerTest");
        assertNotNull(beanElement);
        assertEquals("third.layer", beanElement.getAttribute("class"));

        assertNull(utils.getElementById(null, "blah"));
    }

    public void testValidateAgainstSchema_Valid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/graph-config.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document or schema.");
        }
    }

    public void testValidateAgainstExternalSchema_Valid() throws FileNotFoundException {
//        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
//        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/database/dbtemplate-config.xml");
//        assertNotNull(inputStream);
//        try {
//            utils.validateAgainstExternalSchema(inputStream,
//                "urn:www.monsanto.com:dbtemplate-config",
//                    "http://w3.ent.monsanto.com/wst/xml_schema/usseed/mapping-config.xsd");
//        } catch (XMLValidationException e) {
//            e.printStackTrace();
//            fail("Unable to validate document.");
//        } catch (XMLParserException e) {
//            e.printStackTrace();
//            fail("Unable to parse document or schema.");
//        }
    }

    public void testValidateAgainstExternalSchema_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/invalid.xml");
        try {
            utils.validateAgainstExternalSchema(inputStream,
                "urn:www.monsanto.com:dbtemplate-config",
                    "http://w3.ent.monsanto.com/wst/xml_schema/usseed/mapping-config.xsd");
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Wrong Exception");
        }
    }

    public void testValidateAgainstSchema_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/invalid.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Wrong exception.");
        }
    }

    public void testValidateAgainstSchema_InvalidXML() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/invalid-xml.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Wrong exception.");
        } catch (XMLParserException e) {
        }
    }

    public void testValidateExternalAgainstSchema_InvalidXML() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/invalid-xml.xml");
        try {
            utils.validateAgainstExternalSchema(inputStream,
                "urn:www.monsanto.com:dbtemplate-config",
                    "http://w3.ent.monsanto.com/wst/xml_schema/usseed/mapping-config.xsd");
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Wrong exception.");
        } catch (XMLParserException e) {
        }
    }

    public void testValidateAgainstScheam_FileDoesNotExist() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/does-not-exist.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Wrong exception.");
        } catch (XMLParserException e) {
        }
    }

    public void testValidateAgainstSchema_SAXException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsSAXException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/graph-config.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to parse xml, schema or both.", e.getMessage());
        }
    }

    public void testValidateAgainstSchema_IOException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsIOException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/graph-config.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to access xml, schema or both.", e.getMessage());
        }
    }

    public void testValidateAgainstSchemaStringStringString() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/graph-config.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    "com/monsanto/wst/commonutils/xml/test/graph.xsd");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document or schema.");
        }
    }

    public void testValidateAgainstSchemaStringStringString_ThrowsIOException() throws Exception {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            utils.validateAgainstSchema("com/monsanto/wst/commonutils/xml/test/graph-config.xml",
                    "urn:www.monsanto.com:abstractGraphing",
                    "does.not.exist");
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to access xml, schema or both.", e.getMessage());
        }
    }

    public void testCreateDocumentInputStream() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/test.xml");
        try {
            Document doc = utils.createDocument(in);
            assertNotNull(doc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
    }

    public void testCreateDocumentInputStream_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/invalid-xml.xml");
        try {
            utils.createDocument(in);
            fail("Should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to parse input stream.", e.getMessage());
        }
    }

    public void testCreateDocumentInputStream_Null() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream in = new BufferedInputStream(null);
        try {
            utils.createDocument(in);
            fail("Should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to open or read input stream", e.getMessage());
        }
    }

    public void testCreateDocumentInputStream_ParserConfigException() {
        System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockDocumentBuilderFactory");
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/test.xml");
        try {
            utils.createDocument(in);
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to retrieve new parser.", e.getMessage());
        }
    }

    public void testCreateDocumentNode() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            NodeList beanList = doc.getElementsByTagName("bean");
            Document newDoc = utils.createDocument(beanList.item(0));
            assertNotNull(newDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
    }

    public void testCreateDocumentNodeNull() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            Node node = null;
            Document newDoc = utils.createDocument(node);
            assertNull(newDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
    }

    public void testCreateDocumentNode_ParserConfigException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockDocumentBuilderFactory");
            NodeList beanList = doc.getElementsByTagName("bean");
            utils.createDocument(beanList.item(0));
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to retrieve new parser.", e.getMessage());
        }
    }

    public void testValidateAgainstSchemaInputStreamStringURL() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(in,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document or schema.");
        }
    }

    public void testValidateAgainstSchemaInputStreamStringURL_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/invalid.xml");
            utils.validateAgainstSchema(in,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Wrong exception.");
        }
    }

    public void testValidateAgainstSchemaInputStreamStringURL_SAXException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsSAXException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(in,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to parse xml, schema or both.", e.getMessage());
        }
    }

    public void testValidateAgainstSchemaInputStreamStringURL_IOException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsIOException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            InputStream in = getClass().getClassLoader().getResourceAsStream("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(in,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to access xml, schema or both.", e.getMessage());
        }
    }

    public void testValidateAgainstSchemaDocStringURL() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(doc,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document or schema.");
        }
    }

    public void testValidateAgainstSchemaDocStringURL_Invalid() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/invalid.xml");
            utils.validateAgainstSchema(doc,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            assertEquals("XML is invalid according to schema.", e.getMessage());
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document or schema.");
        }
    }

    public void testValidateAgainstSchemaDocStringURL_SAXException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsSAXException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(doc,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to parse xml, schema or both.", e.getMessage());
        }
    }

    public void testValidateAgainstSchemaDocStringURL_IOException() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockXMLReaderThrowsIOException");
        URL schemaURL = getClass().getClassLoader().getResource("com/monsanto/wst/commonutils/xml/test/graph.xsd");
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            utils.validateAgainstSchema(doc,
                    "urn:www.monsanto.com:abstractGraphing",
                    schemaURL);
            fail("This should have thrown an exception.");
        } catch (XMLValidationException e) {
            e.printStackTrace();
            fail("Unable to validate document.");
        } catch (XMLParserException e) {
            assertEquals("Unable to access xml, schema or both.", e.getMessage());
        }
    }

    public void testWriteDocumentToFile() {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities utils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            File dir = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test");
            File file = new File(dir.getAbsolutePath() + "/temp.xml");
            file.createNewFile();
            assertEquals(0, file.length());
            utils.writeDocumentToFile(doc, file.getAbsolutePath());
            assertTrue(file.exists());
            assertTrue(file.length() > 0);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse xml document.");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            fail("Unable to find temp file.");
        } catch (IOException e) {
            e.printStackTrace();
            fail("Unable to write file to filesystem.");
        }

        try {
            resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test/temp.xml").delete();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("WARNING: Unable to delete temp xml file.");
        }
    }

    public void testWriteDocumentToFile_TransformerConfigException() {
        System.setProperty("javax.xml.transform.TransformerFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockTransformerFactoryThrowsTransformerConfigException");
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities utils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            File dir = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test");
            File file = new File(dir.getAbsolutePath() + "/temp.xml");
            utils.writeDocumentToFile(doc, file.getAbsolutePath());
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to create new transformer.", e.getMessage());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            fail("Unable to find temp file.");
        } catch (IOException e) {
            e.printStackTrace();
            fail("Unable to write file to filesystem.");
        }
    }

    public void testWriteDocumentToFile_TransformerException() {
        System.setProperty("javax.xml.transform.TransformerFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockTransformerFactory");
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities utils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/graph-config.xml");
            File dir = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test");
            File file = new File(dir.getAbsolutePath() + "/temp.xml");
            utils.writeDocumentToFile(doc, file.getAbsolutePath());
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to convert xml document into output stream.", e.getMessage());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            fail("Unable to find temp file.");
        } catch (IOException e) {
            e.printStackTrace();
            fail("Unable to write file to filesystem.");
        }
    }

    public void testGetFormattedXMLString() {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            String xmlString = xmlUtils.getFormattedXMLString(testDoc);
            assertEquals(
                    "<beans>" + System.getProperty("line.separator") +
                    "    <bean class=\"com.monsanto.ApplicationContainer.TestSingletonBean\" id=\"testSingletonBean\" index=\"1\">" + System.getProperty("line.separator") +
                    "        <constructor-arg ref=\"blah\"/>" + System.getProperty("line.separator") +
                    "        <bean class=\"some.other.class\" id=\"nestedTest\">" + System.getProperty("line.separator") +
                    "            <bean class=\"third.layer\" id=\"thirdLayerTest\"/>" + System.getProperty("line.separator") +
                    "        </bean>" + System.getProperty("line.separator") +
                    "    </bean>" + System.getProperty("line.separator") +
                    "</beans>",
                    xmlString);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
    }

    public void testGetFormattedXMLString_TransformerConfigException() {
        System.setProperty("javax.xml.transform.TransformerFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockTransformerFactoryThrowsTransformerConfigException");
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlUtils.getFormattedXMLString(testDoc);
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to transform xml to string.", e.getMessage());
        }
    }

    public void testGetFormattedXMLString_TransformerException() {
        System.setProperty("javax.xml.transform.TransformerFactory", "com.monsanto.wst.commonutils.xml.test.XMLUtilitiesUT$MockTransformerFactory");
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils, DEFAULT_XML_READER);
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlUtils.getFormattedXMLString(testDoc);
            fail("This should have thrown an exception.");
        } catch (XMLParserException e) {
            assertEquals("Unable to transform xml to string.", e.getMessage());
        }
    }

    public void testGetElementByNameAttribute() {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        Document doc = null;
        try {
            doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test2.xml");
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("Unable to parse document.");
        }
        Element beanElement = utils.getElementByNameAttribute(doc, "testSingletonBean");
        assertNotNull(beanElement);
        assertEquals("com.monsanto.ApplicationContainer.TestSingletonBean", beanElement.getAttribute("class"));

        beanElement = utils.getElementByNameAttribute(doc, "blah2");
        assertNull(beanElement);

        beanElement = utils.getElementByNameAttribute(doc, "nestedTest");
        assertNotNull(beanElement);
        assertEquals("some.other.class2", beanElement.getAttribute("class"));

        beanElement = utils.getElementByNameAttribute(doc, "thirdLayerTest");
        assertNotNull(beanElement);
        assertEquals("third.layer2", beanElement.getAttribute("class"));

        assertNull(utils.getElementByNameAttribute(null, "blah"));
    }

    public void testRemoveAllChildrenOneChild() throws Exception {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils());
        Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test2.xml");
        Element root = (Element) doc.getElementsByTagName("beans").item(0);
        utils.removeAllChildren(root);
        assertFalse(root.hasChildNodes());
    }

    public void testRemoveAllChildrenMultiChild() throws Exception {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils());
        Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test2.xml");
        Element root = (Element) doc.getElementsByTagName("bean").item(0);
        utils.removeAllChildren(root);
        assertFalse(root.hasChildNodes());
    }

    public void testRemoveAll() throws Exception {
        XMLUtilities utils = new XMLUtilities(new ResourceUtils());
        Document doc = utils.createDocument("com/monsanto/wst/commonutils/xml/test/test2.xml");
        NodeList nodeList = doc.getElementsByTagName("bean");
        utils.removeAll(nodeList);
        System.out.println(utils.getFormattedXMLString(doc));
        assertEquals(0, doc.getElementsByTagName("bean").getLength());
    }

    public static class MockDocumentBuilderFactory extends DocumentBuilderFactory {

        public DocumentBuilder newDocumentBuilder() throws ParserConfigurationException {
            throw new ParserConfigurationException("Test exception.");
        }

        public Object getAttribute(String name) throws IllegalArgumentException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setFeature(String name, boolean value) throws ParserConfigurationException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public boolean getFeature(String name) throws ParserConfigurationException {
            return false;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setAttribute(String name, Object value) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

    }

    public static class MockXMLReaderThrowsIOException implements XMLReader {

        public void parse(String systemId) throws IOException, SAXException {
            throw new IOException("This is a test exception.");
        }

        public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
            return false;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public ContentHandler getContentHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setContentHandler(ContentHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public DTDHandler getDTDHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setDTDHandler(DTDHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public EntityResolver getEntityResolver() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setEntityResolver(EntityResolver resolver) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public ErrorHandler getErrorHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setErrorHandler(ErrorHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void parse(InputSource input) throws IOException, SAXException {
            throw new IOException("This is a test exception.");
        }

        public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

    }

    public static class MockXMLReaderThrowsSAXException implements XMLReader {

        public void parse(String systemId) throws IOException, SAXException {
            throw new SAXException("This is a test exception.");
        }

        public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
            return false;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public ContentHandler getContentHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setContentHandler(ContentHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public DTDHandler getDTDHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setDTDHandler(DTDHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public EntityResolver getEntityResolver() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setEntityResolver(EntityResolver resolver) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public ErrorHandler getErrorHandler() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setErrorHandler(ErrorHandler handler) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void parse(InputSource input) throws IOException, SAXException {
            throw new SAXException("This is a test exception.");
        }

        public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

    }

    public static class MockTransformerFactoryThrowsTransformerConfigException extends TransformerFactory {

        public boolean getFeature(String name) {
            return false;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public ErrorListener getErrorListener() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setErrorListener(ErrorListener listener) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Transformer newTransformer() throws TransformerConfigurationException {
            throw new TransformerConfigurationException("This is a test exception.");
        }

        public URIResolver getURIResolver() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setFeature(String name, boolean value) throws TransformerConfigurationException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setURIResolver(URIResolver resolver) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Object getAttribute(String name) throws IllegalArgumentException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setAttribute(String name, Object value) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Templates newTemplates(Source source) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Transformer newTransformer(Source source) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Source getAssociatedStylesheet(Source source, String media, String title, String charset) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

    }

    public static class MockTransformerFactory extends TransformerFactory {

        public boolean getFeature(String name) {
            return false;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public ErrorListener getErrorListener() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setErrorListener(ErrorListener listener) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Transformer newTransformer() throws TransformerConfigurationException {
            return new MockTransformer();
        }

        public URIResolver getURIResolver() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setFeature(String name, boolean value) throws TransformerConfigurationException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setURIResolver(URIResolver resolver) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Object getAttribute(String name) throws IllegalArgumentException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setAttribute(String name, Object value) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Templates newTemplates(Source source) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Transformer newTransformer(Source source) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Source getAssociatedStylesheet(Source source, String media, String title, String charset) throws TransformerConfigurationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

    }

    private static class MockTransformer extends Transformer {

        public void clearParameters() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Properties getOutputProperties() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setOutputProperties(Properties oformat) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public ErrorListener getErrorListener() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setErrorListener(ErrorListener listener) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public URIResolver getURIResolver() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setURIResolver(URIResolver resolver) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Object getParameter(String name) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setParameter(String name, Object value) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getOutputProperty(String name) throws IllegalArgumentException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setOutputProperty(String name, String value) throws IllegalArgumentException {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void transform(Source xmlSource, Result outputTarget) throws TransformerException {
            throw new TransformerException("This is a test exception.");
        }

    }

}
