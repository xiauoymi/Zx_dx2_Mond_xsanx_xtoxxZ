/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.commonutils.test;

import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.commonutils.DateFormatException;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Filename:    $RCSfile: DataTypeUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date:
 * 2006/09/29 19:14:22 $
 *
 * @author jdpoul
 * @version $Revision: 1.5 $
 */
public class DataTypeUtil_UT extends TestCase {

  private DataTypeUtil util;

  protected void setUp() throws Exception {
    super.setUp();
    this.util = new DataTypeUtil();
  }

  public DataTypeUtil_UT(String name) {
    super(name);
  }

  public void testCreate() throws Exception {
    assertNotNull(util);
  }

  public void testConvertYNStringIntoBooleanReturnsTrue() throws Exception {
    assertEquals(Boolean.TRUE, util.convertYNStringIntoBoolean("Y"));
  }

  public void testConvertYNStringIntoBooleanReturnsFalse() throws Exception {
    assertEquals(Boolean.FALSE, util.convertYNStringIntoBoolean("N"));
  }

  public void testConvertYNStringIntoBooleanNullParamReturnsFalse() throws Exception {
    assertEquals(Boolean.FALSE, util.convertYNStringIntoBoolean(null));
  }

  public void testConvertPrimitiveBooleanIntoYNString_FalseParamReturnsN() throws Exception {
    assertEquals("N", util.convertPrimitiveBooleanToYNString(false));
  }

  public void testConvertPrimitiveBooleanIntoYNString_TrueParamReturnsY() throws Exception {
    assertEquals("Y", util.convertPrimitiveBooleanToYNString(true));
  }

  public void testConvertYNStringIntoBooleanNotRecognizedParamValueReturnsFalse() throws Exception {
    assertEquals(Boolean.FALSE, util.convertYNStringIntoBoolean("Yes"));
  }

  public void testConvertIntegerIntoBooleanReturnsTrue() {
    assertEquals(Boolean.TRUE, util.convertIntegerIntoBoolean(new Integer(1)));
  }

  public void testConvertIntegerIntoBooleanReturnsFalseOtherThan1Or0() {
    assertEquals(Boolean.FALSE, util.convertIntegerIntoBoolean(new Integer(12)));
  }


  public void testConvertStringToLongReturnsLongForValidInput() throws Exception {
    assertEquals(new Long(1), util.convertStringToLongIgnoreNumberFormatException("1"));
  }

  public void testConvertIntegerIntoBooleanReturnsFalse0Param() {
    assertEquals(Boolean.FALSE, util.convertIntegerIntoBoolean(new Integer(0)));
  }

  public void testConvertStringToLongReturnsNullForEmptyString() throws Exception {
    assertEquals(null, util.convertStringToLongIgnoreNumberFormatException(""));
  }

  public void testConvertStringToLongReturnsNullForNullParam() throws Exception {
    assertNull(util.convertStringToLongIgnoreNumberFormatException(null));
  }

  public void testConvertStringToLongReturnsCorrectNumberForTwoParam() throws Exception {
    assertEquals(new Long(2), util.convertStringToLongIgnoreNumberFormatException("2"));
  }

  public void testConvertStringtoLongReturnsNullForInvalidNumberString() throws Exception {
    assertEquals(null, util.convertStringToLongIgnoreNumberFormatException("t"));
  }

  public void testConvertStringToDateParseableDateString() throws Exception {
     Calendar calendar = new GregorianCalendar(2006, 11, 22);
    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    formatter.setCalendar(Calendar.getInstance());
    String stringDate = formatter.format(calendar.getTime());

    assertEquals(calendar.getTime(), util.convertStringToDate(stringDate, "MM/dd/yyyy"));
  }

  public void testConvertStringToDatePassingNull() throws Exception {
       assertNull(util.convertStringToDate(null, "MM/dd/yyyy"));
  }

  public void testConvertStringToDatePassingEmptyString() throws Exception {
    assertNull(util.convertStringToDate("", "MM/dd/yyyy"));
  }

  public void testConvertStringToDatePassingNonParseableString() throws Exception{
    String testString = "dddgssggsg";

    try{
      util.convertStringToDate(testString, "MM/dd/yyyy");
      fail();
    }catch(DateFormatException e){
      assertEquals("Unable to convert input string: " + testString + " into a Date Object using format: " + "MM/dd/yyyy" + ".", e.getMessage());
    }
  }

  public void testConvertStringToDateAnotherParseableDateStringInvalidDateFormatString() throws Exception {
     Calendar calendar = new GregorianCalendar(2006, 11, 22);
    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    formatter.setCalendar(Calendar.getInstance());
    String stringDate = formatter.format(calendar.getTime());

    try {
      util.convertStringToDate(stringDate, "yyySQWX");
      fail();
    } catch (DateFormatException e) {
      assertEquals("The format string: " + "yyySQWX" + " is not a valid java date format string.", e.getMessage());
    }
  }


  public void testConvertStringToDateAnotherParseableDateString() throws Exception {
     Calendar calendar = new GregorianCalendar(2006, 11, 22);
    SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
    formatter.setCalendar(Calendar.getInstance());
    String stringDate = formatter.format(calendar.getTime());

    assertEquals(calendar.getTime(), util.convertStringToDate(stringDate, "MMddyyyy"));
  }


}