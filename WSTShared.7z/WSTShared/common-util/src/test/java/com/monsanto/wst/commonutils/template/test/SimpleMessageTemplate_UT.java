package com.monsanto.wst.commonutils.template.test;

import junit.framework.TestCase;
import com.monsanto.wst.commonutils.template.SimpleMessageTemplate;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;

/**
 * Created by IntelliJ IDEA.
 * Date: Jan 24, 2007
 * Time: 1:57:36 PM
 * <p/>
 * Unit test for the SimpleMessageTemplate object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 * @see FileMessageTemplate_UT for more tests.
 */
public class SimpleMessageTemplate_UT extends TestCase {
    public void testCreate() throws Exception {
        SimpleMessageTemplate template = new SimpleMessageTemplate("string template", new ObjectInspector());
        assertNotNull(template);
    }
}
