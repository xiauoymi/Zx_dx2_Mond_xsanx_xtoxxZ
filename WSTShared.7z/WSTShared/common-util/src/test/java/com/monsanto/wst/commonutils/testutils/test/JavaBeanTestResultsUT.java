package com.monsanto.wst.commonutils.testutils.test;

import com.monsanto.wst.commonutils.testutils.JavaBeanTestResults;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 8:10:23 AM
 * <p/>
 * Unit test for the JavaBeanTestResults object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JavaBeanTestResultsUT extends TestCase {
    public void testCreate() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        assertNotNull(results);
    }

    public void testAddResult() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        results.addResult("test1", true);
        results.addResult("test2", false);
        assertTrue(results.getResult("test1"));
        assertFalse(results.getResult("test2"));
    }

    public void testGetResultDoesNotExist() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        assertFalse(results.getResult("test1"));
    }

    public void testGetCombinedResult() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        results.addResult("test1", true);
        results.addResult("test2", true);
        assertTrue(results.getCombinedResult());
        results.addResult("test3", false);
        assertFalse(results.getCombinedResult());
    }

    public void testGetNumResults() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        results.addResult("test1", true);
        results.addResult("test2", true);
        assertEquals(2, results.getNumResults());
    }

    public void testGetNumValidProperties() throws Exception {
        JavaBeanTestResults results = new JavaBeanTestResults();
        results.addResult("test1", true);
        results.addResult("test2", false);
        assertEquals(1, results.getNumValidProperties());
    }
}
