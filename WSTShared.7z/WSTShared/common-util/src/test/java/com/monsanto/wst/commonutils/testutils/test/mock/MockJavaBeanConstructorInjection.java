package com.monsanto.wst.commonutils.testutils.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 30, 2006
 * Time: 4:32:22 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockJavaBeanConstructorInjection {
    private String testProperty;
    private String privateProperty;
    private String throwsException;
    private Long testLongProperty;

    public MockJavaBeanConstructorInjection(String testPropery) {
        this.testProperty = testPropery;
    }

    public MockJavaBeanConstructorInjection(Long testLongProperty) {
        this.testLongProperty = testLongProperty;
    }

    public MockJavaBeanConstructorInjection(String testProperty, String privateProperty, String throwsException) throws Exception {
        throw new Exception("Test Exception");
    }

    private MockJavaBeanConstructorInjection(String testProperty, String privateProperty) {
        this.privateProperty = privateProperty;
        this.testProperty = testProperty;
    }

    public String getTestProperty() {
        return testProperty;
    }

    public String getPrivateProperty() {
        return privateProperty;
    }

    public String getThrowsException() {
        return throwsException;
    }

    public Long getTestLongProperty() {
        return testLongProperty;
    }
}
