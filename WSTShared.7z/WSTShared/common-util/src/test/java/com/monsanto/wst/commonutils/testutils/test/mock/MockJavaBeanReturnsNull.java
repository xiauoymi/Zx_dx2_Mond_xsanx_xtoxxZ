package com.monsanto.wst.commonutils.testutils.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 22, 2006
 * Time: 10:44:41 AM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockJavaBeanReturnsNull {
    private String testString;
    private Integer testInteger;

    public String getTestString() {
        return null;
    }

    public void setTestString(String testString) {
        this.testString = testString;
    }

    public Integer getTestInteger() {
        return null;
    }

    public void setTestInteger(Integer testInteger) {
        this.testInteger = testInteger;
    }
}
