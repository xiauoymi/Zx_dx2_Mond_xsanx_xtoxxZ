package com.monsanto.wst.commonutils.reflection.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 1:19:56 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockDelegateJavaBean {
    private String delegateString;
    private String preInitializedValue = "Test";

    public String getDelegateString() {
        return delegateString;
    }

    public void setDelegateString(String delegateString) {
        this.delegateString = delegateString;
    }

    public String getPreInitializedValue() {
        return preInitializedValue;
    }

    public void setPreInitializedValue(String preInitializedValue) {
        this.preInitializedValue = preInitializedValue;
    }
}
