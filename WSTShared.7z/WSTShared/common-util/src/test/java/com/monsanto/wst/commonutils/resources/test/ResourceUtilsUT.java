package com.monsanto.wst.commonutils.resources.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 8:55:57 AM
 * <p/>
 * This class is a junit test case for the ResourceUtils class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ResourceUtilsUT extends TestCase {

  public void testConstructor() {
    ResourceUtils resourceUtils = new ResourceUtils();
    assertNotNull(resourceUtils);
  }

  public void testConvertPathToURL_HTTPPath() {
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      URL url = resourceUtils.convertPathToURL("http://www.google.com");
      assertNotNull(url);
      assertEquals("http://www.google.com", url.toExternalForm());
    } catch (MalformedURLException e) {
      e.printStackTrace();
      fail("see stack trace");
    }
  }

  public void testConvertPathToURL_ClassPath() {
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      URL url = resourceUtils.convertPathToURL("com/monsanto/wst/commonutils/xml/test/test.xml");
      assertNotNull(url);
    } catch (MalformedURLException e) {
      e.printStackTrace();
      fail("Unable to resolve resource.");
    }
  }

  public void testConvertPathToURLInvalid() {
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      resourceUtils.convertPathToURL("doesNotExist");
      fail("This should have thrown an exception.");
    } catch (MalformedURLException e) {
      // Should happen.
    }
  }

  public void testConvertPathToFile_ClassPathResource() {
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test/test.xml");
      assertNotNull(file);
      assertTrue(file.exists());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      fail("Unable to resolve resource.");
    }
  }

  public void testConvertPathToFile_FilePathResource() throws Exception {
    ResourceUtils resourceUtils = new ResourceUtils();
//    File file = resourceUtils.convertPathToFile("c:/code/WSTShared/common-util/src/test/resources/com/monsanto/wst/commonutils/xml/test/test.xml");
    File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/xml/test/test.xml");
    assertNotNull(file);
    assertTrue(file.exists());
  }

  public void testConvertPathToFile_FileNotFound() {
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      resourceUtils.convertPathToFile("blah");
      fail("Should not have round this file.");
    } catch (FileNotFoundException e) {
      // Should happen.
    }
  }

}
