package com.monsanto.wst.commonutils.testutils.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 22, 2006
 * Time: 11:06:53 AM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockJavaBeanNoProperties {
}
