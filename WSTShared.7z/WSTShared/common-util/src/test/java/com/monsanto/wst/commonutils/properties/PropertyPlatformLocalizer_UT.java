package com.monsanto.wst.commonutils.properties;

import junit.framework.TestCase;

import java.util.Properties;

/*
 PlatformProperties_UT was created on May 20, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class PropertyPlatformLocalizer_UT extends TestCase {
  private Properties baseProp;
  private static final String TEST_KEY_NO_PREFIX = "key1";
  private static final String TEST_KEY_2 = "key2";
  private static final String TEST_KEY_3 = "key3";
  private static final String TEST_VALUE_1 = "value1";
  private static final String TEST_VALUE_2 = "value2";
  private static final String TEST_VALUE_3 = "value3";
  private static final String TEST_PREFIX_1 = "prefix1";
  private static final String TEST_PREFIX_2 = "prefix2";

  protected void setUp() throws Exception {
    super.setUp();
    baseProp = new Properties();
    baseProp.setProperty(TEST_KEY_NO_PREFIX, TEST_VALUE_1);
    baseProp.setProperty(TEST_PREFIX_1 + '.' + TEST_KEY_2, TEST_VALUE_2);
    baseProp.setProperty(TEST_PREFIX_2 + '.' + TEST_KEY_2, TEST_VALUE_3);
    baseProp.setProperty(TEST_PREFIX_1 + '.' + TEST_KEY_3, "WontFindIt");
  }

  public void testPropertyWithNoPrefixIsInAllEnvironments() throws Exception {
    MockPlatformPropertiesForLsiFunction prop1 = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_1);
    MockPlatformPropertiesForLsiFunction prop2 = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_2);
    assertEquals(TEST_VALUE_1, prop1.getProperty(TEST_KEY_NO_PREFIX));
    assertEquals(TEST_VALUE_1, prop2.getProperty(TEST_KEY_NO_PREFIX));
  }

  public void testPropertyWithPrefixIsNotFoundInOtherEnvironment() throws Exception {
    MockPlatformPropertiesForLsiFunction prop = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_2);
    assertNull(prop.getProperty(TEST_KEY_3));
  }

  public void testPropertyWithPrefixIsNotFoundInOtherEnvironmentWithDefault() throws Exception {
    MockPlatformPropertiesForLsiFunction prop = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_2);
    assertEquals("foo", prop.getProperty(TEST_KEY_3, "foo"));
  }

  public void testPropertyHasDifferentValuesOnDifferentEnvironments() throws Exception {
    MockPlatformPropertiesForLsiFunction prop1 = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_1);
    MockPlatformPropertiesForLsiFunction prop2 = new MockPlatformPropertiesForLsiFunction(baseProp, TEST_PREFIX_2);
    assertEquals(TEST_VALUE_2, prop1.getProperty(TEST_KEY_2));
    assertEquals(TEST_VALUE_3, prop2.getProperty(TEST_KEY_2));
  }

  public void testPrefixMatchesLsiFunction() throws Exception {
    PropertyPlatformLocalizer localizer = new PropertyPlatformLocalizer();
    String propPrefix = localizer.getPrefix();
    String lsiFunction = System.getProperty("lsi.function", PropertyPlatformLocalizer.UNKNOWN_PLATFORM);
    assertEquals(lsiFunction, propPrefix);
  }


  private static class MockPlatformPropertiesForLsiFunction extends Properties {
    public MockPlatformPropertiesForLsiFunction(Properties prop, String prefix) {
      super(new MockPropertyPlatformLocalizer(prefix).getLocalizedProperties(prop));
    }
  }

  private static class MockPropertyPlatformLocalizer extends PropertyPlatformLocalizer {
    private String prefix;

    private MockPropertyPlatformLocalizer(String prefix) {
      this.prefix = prefix;
    }

    public String getPrefix() {
      return this.prefix;
    }
  }
}