package com.monsanto.wst.commonutils.template.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.template.FileMessageTemplate;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.commonutils.template.PropertyNotFoundException;
import com.monsanto.wst.commonutils.template.TemplateNotFoundException;
import junit.framework.TestCase;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 2:18:03 PM
 * <p/>
 * Unit test for the FileMessageTemplate object
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FileMessageTemplate_UT extends TestCase {
  private static final String TEST_NAME = "John Doe";
  private static final String TEST_DAY = "Wednesday";

  public void testCreate() throws Exception {
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    assertNotNull(template);
  }

  public void testCreateThrowsFileNotFoundException() throws Exception {
    try {
      new FileMessageTemplate("does.not.exist", new ObjectInspector());
      fail("This should have thrown a file not found exception.");
    } catch (TemplateNotFoundException e) {
      assertEquals("Unable to find or open template at path: 'does.not.exist'", e.getMessage());
    }
  }

  public void testGetFormattedMessageWithoutSubstiutions() throws Exception {
    MockObjectWithName object = new MockObjectWithName(TEST_NAME);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/testWithoutSubstitutions.email", new ObjectInspector());
    String message = template.getFormattedMessage(object);
    assertEquals("Hello John Doe.", message);
  }

  public void testGetFormattedMessage() throws Exception {
    MockObjectWithName object = new MockObjectWithName(TEST_NAME);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    String message = template.getFormattedMessage(object);
    assertEquals("Hello " + TEST_NAME + ".", message);
  }

  public void testNoValueThrowsException() throws Exception {
    MockObjectWithoutName object = new MockObjectWithoutName();
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    try {
      template.getFormattedMessage(object);
      fail("Expected a PropertyNotFoundException exception");
    } catch (PropertyNotFoundException e) {
      assertTrue("Message didn't include property name", e.getMessage().indexOf("name") >= 0);
    }
  }

  public void testNullValueReturnsBlank() throws Exception {
    MockObjectWithName object = new MockObjectWithName(null);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    String message = template.getFormattedMessage(object);
    assertEquals("Hello .", message);
  }

  public void testPrivateValueThrowsException() throws Exception {
    MockObjectWithPrivateName object = new MockObjectWithPrivateName(TEST_NAME);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    try {
      template.getFormattedMessage(object);
      fail("Expected a PropertyNotFoundException exception");
    } catch (PropertyNotFoundException e) {
      assertTrue("Message didn't include property name", e.getMessage().indexOf("name") >= 0);
    }
  }

  public void testValueThrowsException() throws Exception {
    MockObjectWithNameThrowException object = new MockObjectWithNameThrowException();
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new ObjectInspector());
    try {
      template.getFormattedMessage(object);
      fail("Expected a PropertyNotFoundException exception");
    } catch (PropertyNotFoundException e) {
      assertTrue("Message didn't include property name", e.getMessage().indexOf("name") >= 0);
    }
  }

  public void testObjectInspectorThrowsIllegalArgumentException() throws Exception {
    MockObjectWithName object = new MockObjectWithName(TEST_NAME);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new MockObjectInspectorForIllegalArgumentException());
    try {
      template.getFormattedMessage(object);
      fail("Expected a PropertyNotFoundException exception");
    } catch (PropertyNotFoundException e) {
      assertTrue("Message didn't include property name", e.getMessage().indexOf("name") >= 0);
    }
  }

  public void testObjectInspectorThrowsIllegalAccessException() throws Exception {
    MockObjectWithName object = new MockObjectWithName(TEST_NAME);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/test.email", new MockObjectInspectorForIllegalAccessException());
    try {
      template.getFormattedMessage(object);
      fail("Expected a PropertyNotFoundException exception");
    } catch (PropertyNotFoundException e) {
      assertTrue("Message didn't include property name", e.getMessage().indexOf("name") >= 0);
    }
  }

  public void testMultipleReplacements() throws Exception {
    MockObjectWithName object = new MockObjectWithName(TEST_NAME, TEST_DAY);
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/testMultiple.email", new ObjectInspector());
    String message = template.getFormattedMessage(object);
    assertEquals("Hello " + TEST_NAME + ". Goodbye " + TEST_NAME + ".  Have a nice " + TEST_DAY + ".", message);
  }

  public void testGetFormattedMessageWithGlobalSystemProperty() throws Exception {
    System.setProperty("testEnv", "test");
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/env.email", new ObjectInspector());
    String message = template.getFormattedMessage(null);
    assertEquals("Global Variable = test", message);
    System.setProperty("testEnv", "");
  }

  public void testGetFormattedMessageWithSimpleType() throws Exception {
    MessageTemplate template = new FileMessageTemplate("com/monsanto/wst/commonutils/template/test/simpleType.email", new ObjectInspector());
    String message = template.getFormattedMessage("test");
    assertEquals("This is just a simple string: test", message);
  }

  public static class MockObjectWithoutName {
  }

  public static class MockObjectWithName {
    private String name;
    private String day;

    public MockObjectWithName(String name) {
      this.name = name;
    }

    public MockObjectWithName(String name, String day) {
      this.name = name;
      this.day = day;
    }

    public String getName() {
      return name;
    }

    public String getDay() {
      return day;
    }
  }

  public static class MockObjectWithPrivateName {
    private String name;

    public MockObjectWithPrivateName(String name) {
      this.name = name;
    }

    private String getName() {
      return name;
    }
  }

  public static class MockObjectWithNameThrowException {
    public MockObjectWithNameThrowException() {
    }

    public String getName() {
      throw new RuntimeException("Mock Exception");
    }
  }

  public static class MockObjectInspectorForIllegalAccessException extends ObjectInspector {
    public Object getAcessorValue(Object obj, String accessorPath, boolean overridePermissions) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
      throw new IllegalAccessException("Mock Exception");
    }
  }

  public static class MockObjectInspectorForIllegalArgumentException extends ObjectInspector {
    public Object getAcessorValue(Object obj, String accessorPath, boolean overridePermissions) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
      throw new IllegalArgumentException("Mock Exception");
    }
  }
}
