package com.monsanto.wst.commonutils.reflection.test;

import com.monsanto.wst.commonutils.reflection.MethodProperties;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.reflection.test.mock.MockJavaBean;
import junit.framework.TestCase;

import java.lang.reflect.Method;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 3:09:56 PM
 * <p/>
 * Unit test for the MethodProperties object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MethodPropertiesUT extends TestCase {
    public void testCreate() throws Exception {
        MethodProperties properties = new MethodProperties((Object) null, (Method) null);
        assertNotNull(properties);
    }

    public void testInvoke() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        bean.setTestString("Test");
        Method method = new ObjectInspector().getAccessor("testString", bean.getClass(), false);
        MethodProperties properties = new MethodProperties(bean, method);
        Object value = properties.invoke(null);
        assertEquals("Test", value);
    }

    public void testGetReturnType() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        bean.setTestString("Test");
        Method method = new ObjectInspector().getAccessor("testString", bean.getClass(), false);
        MethodProperties properties = new MethodProperties(bean, method);
        Class clazz = properties.getReturnType();
        assertEquals(String.class, clazz);
    }
}
