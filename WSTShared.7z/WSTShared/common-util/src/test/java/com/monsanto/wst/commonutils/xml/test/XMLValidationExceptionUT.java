package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLValidationException;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 20, 2005
 * Time: 9:08:03 AM
 * <p/>
 * This class is a junit test case for the XMLValidationException class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLValidationExceptionUT extends TestCase {

    private static final String DEFAULT_XML_READER = "org.apache.xerces.parsers.SAXParser";

    public void testConstructorString() {
        XMLValidationException e = new XMLValidationException("This is a test exception.");
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
    }

    public void testConstructorStringStringXMLUtilities() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        XMLValidationException e = new XMLValidationException("This is a test exception.", xmlString);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
    }

    public void testConstructor() {
        XMLValidationException e = new XMLValidationException();
        assertNotNull(e);
    }

    public void testConstructorStringThrowable() {
        Exception ex = new Exception("Test cause exception.");
        XMLValidationException e = new XMLValidationException("This is a test exception.", ex);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
        assertEquals(ex, e.getCause());
    }

    public void testConstructorStringThrowableDocumentXMLUtilities() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        Exception ex = new Exception("Test cause exception.");
        XMLValidationException e = new XMLValidationException("This is a test exception.", ex, xmlString);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
        assertEquals(ex, e.getCause());
    }

    public void testConstructorStringList() {
        List exceptionList = new ArrayList();
        Exception ex = new Exception("Test cause exception.");
        exceptionList.add(ex);
        exceptionList.add(ex);
        XMLValidationException e = new XMLValidationException("This is a test exception.", exceptionList);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
    }

    public void testConstructorStringListDocumentXMLUtilities() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        List exceptionList = new ArrayList();
        Exception ex = new Exception("Test cause exception.");
        exceptionList.add(ex);
        exceptionList.add(ex);
        XMLValidationException e = new XMLValidationException("This is a test exception.", exceptionList, xmlString);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
    }

    public void testConstructorThrowable() {
        Exception ex = new Exception("Test cause exception.");
        XMLValidationException e = new XMLValidationException(ex);
        assertNotNull(e);
        assertEquals(ex, e.getCause());
    }

    public void testConstructorThrowableDocumentXMLUtilities() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        Exception ex = new Exception("Test cause exception.");
        XMLValidationException e = new XMLValidationException(ex, xmlString);
        assertNotNull(e);
        assertEquals(ex, e.getCause());
    }

    public void testPrintStackTrace() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        List exceptionList = new ArrayList();
        Exception ex = new Exception("Test cause exception.");
        exceptionList.add(ex);
        exceptionList.add(ex);
        XMLValidationException e = new XMLValidationException("This is a test exception.", exceptionList, xmlString);
        e.printStackTrace();
        e = new XMLValidationException("This is a test exception.");
        e.printStackTrace();
    }

    public void testPrintStackTracePrintWriter() {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
        String xmlString = null;
        try {
            Document testDoc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
            xmlString = xmlUtils.getFormattedXMLString(testDoc);
        } catch (XMLParserException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
        StringWriter value = new StringWriter();
        PrintWriter writer = new PrintWriter(value);
        List exceptionList = new ArrayList();
        Exception ex = new Exception("Test cause exception.");
        exceptionList.add(ex);
        exceptionList.add(ex);
        XMLValidationException e = new XMLValidationException("This is a test exception.", exceptionList, xmlString);
        e.printStackTrace(writer);
        assertTrue(value.toString().length() > 0);
        e = new XMLValidationException("This is a test exception.");
        e.printStackTrace(writer);
        assertTrue(value.toString().length() > 0);
    }

}
