package com.monsanto.wst.commonutils.reflection.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 9:34:57 AM
 * <p/>
 * Mock base java bean object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockBaseJavaBean {
    private String superString;
    public static final String SUPER_CONSTANT = "";
    private String superPrivate;

    public String getSuperString() {
        return superString;
    }

    public void setSuperString(String superString) {
        this.superString = superString;
    }

    private String getSuperPrivate() {
        return superPrivate;
    }

    private void setSuperPrivate(String superPrivate) {
        this.superPrivate = superPrivate;
    }
}
