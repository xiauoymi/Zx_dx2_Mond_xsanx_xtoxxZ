package com.monsanto.wst.commonutils.test;

import com.monsanto.wst.commonutils.EnvironmentUtils;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 8, 2006
 * Time: 10:19:11 AM
 * <p/>
 * Unit test for the EnvironmentUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EnvironmentUtilsUT extends TestCase {
    public void testCreate() throws Exception {
        EnvironmentUtils environmentUtils = new EnvironmentUtils();
        assertNotNull(environmentUtils);
    }

    public void testGetVariable() throws Exception {
        EnvironmentUtils environmentUtils = new EnvironmentUtils();
        assertNotNull(environmentUtils.getVariable("CATALINA_HOME"));
    }

    public void testGetVariableNotFound() throws Exception {
        EnvironmentUtils environmentUtils = new EnvironmentUtils();
        try {
            environmentUtils.getVariable("doesNotExist");
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("Unable to find a value for environment variable 'doesNotExist'.", e.getMessage());
        }
    }

    public void testGetVariableWithNullName() throws Exception {
        EnvironmentUtils environmentUtils = new EnvironmentUtils();
        try {
            environmentUtils.getVariable(null);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("The environment variable name must not be empty or null.", e.getMessage());
        }
    }
}
