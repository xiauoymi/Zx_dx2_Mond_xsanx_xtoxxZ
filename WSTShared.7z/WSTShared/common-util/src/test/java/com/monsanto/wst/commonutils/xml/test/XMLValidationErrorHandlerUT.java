package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.xml.XMLValidationErrorHandler;
import junit.framework.TestCase;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 20, 2005
 * Time: 9:00:48 AM
 * <p/>
 * This class is a test case for the XMLValidationErrorHandler class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLValidationErrorHandlerUT extends TestCase {

    public void testConstructor() {
        XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();
        assertNotNull(errorHandler);
    }

    public void testWarning() {
        SAXParseException e = new SAXParseException("This is a test exception.", null);
        XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();

        try {
            errorHandler.warning(e);
        } catch (SAXException e1) {
            e1.printStackTrace();
            fail("Unable to add warning exception.");
        }

        assertEquals(e, errorHandler.getErrors().get(0));
    }

    public void testError() {
        SAXParseException e = new SAXParseException("This is a test exception.", null);
        XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();

        try {
            errorHandler.error(e);
        } catch (SAXException e1) {
            e1.printStackTrace();
            fail("Unable to add warning exception.");
        }

        assertEquals(e, errorHandler.getErrors().get(0));
    }

    public void testFatalError() {
        SAXParseException e = new SAXParseException("This is a test exception.", null);
        XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();

        try {
            errorHandler.fatalError(e);
        } catch (SAXException e1) {
            e1.printStackTrace();
            fail("Unable to add warning exception.");
        }

        assertEquals(e, errorHandler.getErrors().get(0));
    }

    public void testGetErrors() {
        SAXParseException e = new SAXParseException("This is a test exception.", null);
        XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();

        try {
            errorHandler.error(e);
            errorHandler.error(e);
            errorHandler.error(e);
        } catch (SAXException e1) {
            e1.printStackTrace();
            fail("Unable to add warning exception.");
        }

        assertEquals(3, errorHandler.getErrors().size());
    }

}
