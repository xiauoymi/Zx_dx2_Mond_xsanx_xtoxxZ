package com.monsanto.wst.commonutils.reflection.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 22, 2006
 * Time: 10:40:01 AM
 * <p/>
 * Mock java bean object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockJavaBean extends MockBaseJavaBean {
    private String testString;
    private Integer testInteger;
    private int testInt;
    private double testDouble;
    private float testFloat;
    private short testShort;
    private long testLong;
    private boolean testBoolean;
    private Comparable testInterface;
    private String testThrowsException;
    private String testPrivateAccessor;
    private MockDelegateJavaBean delegate = new MockDelegateJavaBean();
    private MockDelegateJavaBean nullChild = null;
    private String testGetterOnly;
    public static final String CONSTANT = "";

    public MockJavaBean() {
    }

    private MockJavaBean(String privateProperty) {
    }

    public String getTestString() {
        return testString;
    }

    public void setTestString(String testString) {
        this.testString = testString;
    }

    public Integer getTestInteger() {
        return testInteger;
    }

    public void setTestInteger(Integer testInteger) {
        this.testInteger = testInteger;
    }

    public int getTestInt() {
        return testInt;
    }

    public void setTestInt(int testInt) {
        this.testInt = testInt;
    }

    public String getTestGetterOnly() {
        return testGetterOnly;
    }

    public double getTestDouble() {
        return testDouble;
    }

    public void setTestDouble(double testDouble) {
        this.testDouble = testDouble;
    }

    public float getTestFloat() {
        return testFloat;
    }

    public void setTestFloat(float testFloat) {
        this.testFloat = testFloat;
    }

    public short getTestShort() {
        return testShort;
    }

    public void setTestShort(short testShort) {
        this.testShort = testShort;
    }

    public long getTestLong() {
        return testLong;
    }

    public void setTestLong(long testLong) {
        this.testLong = testLong;
    }

    public boolean getTestBoolean() {
        return testBoolean;
    }

    public void setTestBoolean(boolean testBoolean) {
        this.testBoolean = testBoolean;
    }

    public Comparable getTestInterface() {
        return testInterface;
    }

    public void setTestInterface(Comparable testInterface) {
        this.testInterface = testInterface;
    }

    public String getTestThrowsException() {
        throw new RuntimeException();
    }

    public void setTestThrowsException(String testThrowsException) {
        this.testThrowsException = testThrowsException;
    }

    private String getTestPrivateAccessor() {
        return testPrivateAccessor;
    }

    public void setTestPrivateAccessor(String testPrivateAccessor) {
        this.testPrivateAccessor = testPrivateAccessor;
    }

    public MockDelegateJavaBean getDelegate() {
        return delegate;
    }

    public MockDelegateJavaBean getNullChild() {
        return nullChild;
    }

    public void setNullChild(MockDelegateJavaBean nullChild) {
        this.nullChild = nullChild;
    }
}
