package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.InvalidXPathException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 17, 2006
 * Time: 12:33:27 PM
 * <p/>
 * Unit test for the XalanXPathUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XalanXPathUtilsUT extends TestCase {

    public void testCreate() throws Exception {
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        assertNotNull(xpathUtils);
    }

    public void testSelectNodeList() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        NodeList nodeList = xpathUtils.selectNodeList(doc, "//bean");
        assertEquals(3, nodeList.getLength());
    }

    public void testSelectNodeListInvalidExpression() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        try {
            xpathUtils.selectNodeList(doc, "!@#$%bean");
            fail("This should have thrown an exception");
        } catch (InvalidXPathException e) {
            assertEquals("The expression '!@#$%bean' is not a valid xpath expression", e.getMessage());
        }
    }

    public void testEvalToString() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        String id = xpathUtils.evalToString(doc, "//bean/@id");
        assertEquals("testSingletonBean", id);
    }

    public void testEvalToStringInvalidExpression() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        try {
            xpathUtils.evalToString(doc, "//!@#$bean/@id");
            fail("This should have thrown an exception");
        } catch (InvalidXPathException e) {
            assertEquals("The expression '//!@#$bean/@id' is not a valid xpath expression", e.getMessage());
        }
    }

    public void testEvalToInteger() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        Integer index = xpathUtils.evalToInteger(doc, "//bean/@index");
        assertEquals(new Integer(1), index);
    }

    public void testEvalToIntegerEmptyOrDoesNotExist() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        Integer index = xpathUtils.evalToInteger(doc, "//constructor-arg/@index");
        assertNull(index);
    }

    public void testEvalToIntegerNotANumber() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        try {
            xpathUtils.evalToInteger(doc, "//bean/@id");
            fail("This should have thrown an exception.");
        } catch (NumberFormatException e) {
            // This should happen.
        }
    }

    public void testEvalToIntegerInvalidExpression() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        try {
            xpathUtils.evalToInteger(doc, "//!@#$bean/@index");
            fail("This should have thrown an exception");
        } catch (InvalidXPathException e) {
            assertEquals("The expression '//!@#$bean/@index' is not a valid xpath expression", e.getMessage());
        }
    }

    public void testSelectSingleNode() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        Element element = (Element) xpathUtils.selectSingleNode(doc, "//bean[@id = 'thirdLayerTest']");
        assertEquals("thirdLayerTest", element.getAttribute("id"));
    }

    public void testSelectSingleNodeInvalidExpression() throws Exception {
        XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
        Document doc = xmlUtils.createDocument("com/monsanto/wst/commonutils/xml/test/test.xml");
        XalanXPathUtils xpathUtils = new XalanXPathUtils();
        try {
            xpathUtils.selectSingleNode(doc, "//!@#$bean/@id");
            fail("This should have thrown an exception");
        } catch (InvalidXPathException e) {
            assertEquals("The expression '//!@#$bean/@id' is not a valid xpath expression", e.getMessage());
        }
    }

}
