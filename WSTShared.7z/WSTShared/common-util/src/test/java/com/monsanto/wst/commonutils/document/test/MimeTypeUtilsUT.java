package com.monsanto.wst.commonutils.document.test;

import com.monsanto.wst.commonutils.document.MimeTypeUtils;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import junit.framework.TestCase;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 20, 2006
 * Time: 10:40:29 AM
 * <p/>
 * Unit test for the MimeTypeUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MimeTypeUtilsUT extends TestCase {

    public void testCreate() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        assertNotNull(mimeTypeUtils);
    }

    public void testGetDocumentMimeTypeMSWord() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/Test.doc");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/msword", mimeType);
    }

    public void testGetDocumentMimeTypeMSWordXML() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/testOffice07.docx");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/vnd.openxmlformats-officedocument.wordprocessingml.document", mimeType);
    }



    public void testGetDocumentMimeTypeExcel() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/Test.xls");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/vnd.ms-excel", mimeType);
    }

    public void testGetDocumentMimeTypeExcelXML() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/testoffice07.xlsx");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", mimeType);
    }

    public void testGetDocumentMimeTypePDF() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/Test.pdf");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/pdf", mimeType);
    }

    public void testGetDocumentMimeTypeXML() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/Test.xml");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("text/xml", mimeType);
    }

  public void testGetDocumentMimeTypePPTX() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/testOffice07.pptx");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/vnd.openxmlformats-officedocument.presentationml.presentation", mimeType);
    }

    public void testGetDocumentMimeTypeNoExtension() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertNull(mimeType);
    }

    public void testAddMimeType() throws Exception {
        MimeTypeUtils mimeTypeUtils = new MimeTypeUtils();
        ResourceUtils resourceUtils = new ResourceUtils();
        File file = resourceUtils.convertPathToFile("com/monsanto/wst/commonutils/document/test/Test.pdf");
        mimeTypeUtils.addMimeType("pdf", "application/msword");
        String mimeType = mimeTypeUtils.getDocumentMimeType(file);
        assertEquals("application/msword", mimeType);
    }
}
