package com.monsanto.wst.commonutils.reflection.test;

import com.monsanto.wst.commonutils.reflection.MethodProperties;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.reflection.test.mock.MockJavaBean;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.awt.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 10:06:22 AM
 * <p/>
 * This class is a junit test case for the ObjectInspector class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectInspectorUT extends TestCase {
    public void testConstructor() {
        ObjectInspector inspector = new ObjectInspector();
        assertNotNull(inspector);
    }

    public void testGetFieldValue() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        String value = (String) inspector.getFieldValue(MockJavaBean.class, "CONSTANT");
        assertEquals("", value);
    }

    public void testGetPropertyNamesOverridePermissions() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        java.util.List propertyNameList = inspector.getPropertyNames(MockJavaBean.class, true);
        assertEquals(18, propertyNameList.size());
    }

    public void testGetPropertyNames() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        java.util.List propertyNameList = inspector.getPropertyNames(MockJavaBean.class, false);
        assertEquals(2, propertyNameList.size());
    }

    public void testGetFieldValue_Null() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getFieldValue(Font.class, null);
            fail("This should have thrown a no such field exception.");
        } catch (NoSuchFieldException e) {
            assertEquals("There was no field name specified.", e.getMessage());
        }
    }

    public void testGetAccessorValue() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Font font = new Font("Arial", Font.BOLD, 10);
        Integer value = (Integer) inspector.getAcessorValue(font, "size", false);
        assertNotNull(value);
        assertEquals(new Integer(10), value);
    }

  public void testGetAccessorValueFromMap() throws Exception {
    ObjectInspector inspector = new ObjectInspector();
    Map map = new HashMap();
    map.put("theValue", new Integer(10));
    Integer size = (Integer) inspector.getAcessorValue(map, "size", false);
    Integer value = (Integer) inspector.getAcessorValue(map, "theValue", false);
    assertNotNull(size);
    assertEquals(new Integer(1), size);
    assertNotNull(value);
    assertEquals(new Integer(10), value);
  }

  public void testGetAccessorValueDelegate() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        bean.getDelegate().setDelegateString("Test");
        ObjectInspector inspector = new ObjectInspector();
        Object value = inspector.getAcessorValue(bean, "delegate.delegateString", false);
        assertEquals("Test", value);
    }

    public void testGetAccessorValue_Null() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Font font = new Font("Arial", Font.BOLD, 10);
        try {
            inspector.getAcessorValue(font, null, false);
            fail("This should have thrown a no such method exception.");
        } catch (NoSuchMethodException e) {
            assertEquals("There was no method name specified.", e.getMessage());
        }
    }

    public void testGetAccessorValue_boolean() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Object[] objs = new Object[0];
        Boolean value = (Boolean) inspector.getAcessorValue(objs, "class.array", false);
        assertNotNull(value);
        assertEquals(Boolean.TRUE, value);
    }

    public void testSetValue() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        ObjectInspector inspector = new ObjectInspector();
        inspector.setValue(bean, "testString", "Test", false);
        assertEquals("Test", bean.getTestString());
    }

    public void testSetValueMultiLevel() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        ObjectInspector inspector = new ObjectInspector();
        inspector.setValue(bean, "delegate.delegateString", "Test", false);
        assertEquals("Test", bean.getDelegate().getDelegateString());
    }

    public void testSetValueNullPropertyName() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.setValue(bean, null, "Test", false);
            fail("This should have thrown an exception.");
        } catch (NoSuchMethodException e) {
            assertEquals("There was no method/property name specified.", e.getMessage());
        }
    }

    public void testGetMethod() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getMethod("test", MockObject.class, null, false);
        assertEquals("test", method.getName());
    }

    public void testGetMethodOverridePermissions() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            Method method = inspector.getMethod("setPrivateTest", MockObject.class, new Class[] { String.class }, true);
            assertEquals("setPrivateTest", method.getName());
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            fail("See stack trace.");
        }
    }

    public void testGetConstructor() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Constructor constructor = inspector.getConstructor(MockObject.class, null);
        assertNotNull(constructor);
    }

    public void testGetAccessor() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getAccessor("test", MockObject.class, false);
        assertNotNull(method);
        assertEquals("getTest", method.getName());
    }

    public void testGetProtectedSuperAccessor() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getAccessor("superPrivate", MockJavaBean.class, true);
        assertNotNull(method);
        assertEquals("getSuperPrivate", method.getName());
    }

    public void testGetProtectedSuperAccessorDoesNotExist() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getAccessor("doesNotExist", MockJavaBean.class, true);
            fail("This should have thrown an exception.");
        } catch (NoSuchMethodException e) {
        }
    }

    public void testGetDelegateAccessor() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        MockJavaBean bean = new MockJavaBean();
        bean.getDelegate().setDelegateString("Test");
        MethodProperties methodProperties = inspector.getAccessor("delegate.delegateString", bean, true);
        assertNotNull(methodProperties);
        assertEquals("Test", methodProperties.invoke(null));
    }

    public void testGetDelegateAccessorNullObject() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        MockJavaBean bean = new MockJavaBean();
        try {
            inspector.getAccessor("nullChild.preInitializedValue", bean, true);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("One of the accessors in the property path returned a null object.", e.getMessage());
        }
    }

    public void testGetAccessorNullRootObject() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getAccessor("testString.testString", (Object) null, true);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("One of the accessors in the property path returned a null object.", e.getMessage());
        }
    }

    public void testGetAccessorWithFullMethodName() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getAccessor("getTestString", MockJavaBean.class, true);
        assertNotNull(method);
        assertEquals("getTestString", method.getName());
    }

    public void testGetModifier() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getModifier("test", MockObject.class, String.class, false);
        assertNotNull(method);
        assertEquals("setTest", method.getName());
    }

    public void testGetModifierWithFullMethodName() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getModifier("setTest", MockObject.class, String.class, false);
        assertNotNull(method);
        assertEquals("setTest", method.getName());
    }

    public void testGetModifierWithNullRootObject() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getModifier("setTest", (Object) null, String.class, false);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("The parent object must not be null.", e.getMessage());
        }
    }

    public void testGetModifierWithNullProperty() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getModifier(null, new Object(), String.class, false);
            fail("This should have thrown an exception.");
        } catch (IllegalArgumentException e) {
            assertEquals("The property path is required.", e.getMessage());
        }
    }

    public void testGetProtectedSuperModifier() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getModifier("superPrivate", MockJavaBean.class, String.class, true);
        assertNotNull(method);
        assertEquals("setSuperPrivate", method.getName());
    }

    public void testGetDelegateModifier() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        MockJavaBean bean = new MockJavaBean();
        MethodProperties methodProperties = inspector.getModifier("delegate.delegateString", bean, String.class, false);
        assertNotNull(methodProperties);
        methodProperties.invoke(new Object[] { "Test" });
        assertEquals("Test", bean.getDelegate().getDelegateString());
    }

    public void testGetDelegateModifierWithNullChild() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        MockJavaBean bean = new MockJavaBean();
        MethodProperties methodProperties = inspector.getModifier("nullChild.delegateString", bean, String.class, true);
        methodProperties.invoke(new Object[] { "Test" });
        assertEquals("Test", bean.getNullChild().getDelegateString());
    }

    public void testGetModifierFullMethodName() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Method method = inspector.getModifier("privateTest", MockObject.class, String.class, true);
        assertNotNull(method);
        assertEquals("setPrivateTest", method.getName());
    }

    public void testGetField() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Field field = inspector.getField("CONSTANT", MockJavaBean.class, false);
        assertEquals("CONSTANT", field.getName());
    }

    public void testGetFieldOverridePermissions() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Field field = inspector.getField("testString", MockJavaBean.class, true);
        assertEquals("testString", field.getName());
        MockJavaBean bean = new MockJavaBean();
        field.set(bean, "test string");
    }

    public void testGetFieldOverridePermissionsOnSuperClass() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Field field = inspector.getField("superString", MockJavaBean.class, true);
        assertEquals("superString", field.getName());
        MockJavaBean bean = new MockJavaBean();
        field.set(bean, "test string");
    }

    public void testGetFieldNoSuchField() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        try {
            inspector.getField("doesNotExist", MockJavaBean.class, true);
            fail("This should have thrown an exception.");
        } catch (NoSuchFieldException e) {
        }
    }

    public void testGetConstructors() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Constructor[] constructors = inspector.getConstructors(MockJavaBean.class, false);
        assertEquals(1, constructors.length);
    }

    public void testGetConstructorsOverridePermissions() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Constructor[] constructors = inspector.getConstructors(MockJavaBean.class, true);
        assertEquals(2, constructors.length);
        constructors[0].newInstance(new Object[] { "test value" });
    }

    public void testGetPropertyFieldToValueMapNullObjectParam() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Map properties = inspector.getPropertyFieldtoValueMap(null);
        assertNotNull(properties);
        assertEquals(0, properties.size());
    }

    public void testGetPropertyFieldToValueMapMapNotNull() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        Map properties = inspector.getPropertyFieldtoValueMap(object);
        assertNotNull(properties);
    }


    public void testGetPropertyFieldToValueMapMapCheckForSingleStringFieldSetInMap() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        Map properties = inspector.getPropertyFieldtoValueMap(object);
        assertEquals("test", properties.get("StringProp"));
    }

    public void testGetPropertyFieldToValueMapCheckForTwoFieldsOneStringAndOneBoolean() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        object.setBooleanProp(true);
        Map properties = inspector.getPropertyFieldtoValueMap(object);
        assertEquals("test", properties.get("StringProp"));
        assertEquals(new Boolean(true), properties.get("BooleanProp"));
    }

    public void testGetPropertyFieldToValueMapCheckForThreeFieldsOneStringAndOneBooleanOneInherited() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTestInheritedField object = new BeanTestInheritedField("check", new BeanTest());
        object.setStringProp("test");
        object.setBooleanProp(true);
        Map properties = inspector.getPropertyFieldtoValueMap(object);
        assertEquals("test", properties.get("StringProp"));
        assertEquals(new Boolean(true), properties.get("BooleanProp"));
        assertEquals("check", properties.get("Test"));

    }

    public void testGetPropertyFieldToValueMapCheckForThreeFields() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        object.setBooleanProp(true);
        object.setFloatProp((float) 12.3);
        Map properties = inspector.getPropertyFieldtoValueMap(object);
        assertEquals("test", properties.get("StringProp"));
        assertEquals(new Boolean(true), properties.get("BooleanProp"));
        assertEquals(new Float((float)12.3), properties.get("FloatProp"));
    }

    public void testGetPropertyFieldToValueMapSpecifyProperties()throws Exception{
        ObjectInspector inspector = new ObjectInspector();
        List fields = new ArrayList();
        fields.add("stringProp");
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        Map properties = inspector.getPropertyFieldtoValueMap(object, fields, false);
        assertEquals("test", properties.get("stringProp"));
    }


    public void testGetPropertyFieldToValueMapSpecifyAccessorPathProperty()throws Exception{
        ObjectInspector inspector = new ObjectInspector();
        List fields = new ArrayList();
        fields.add("beanTest.stringProp");
        fields.add("stringProp");
        BeanTest test = new BeanTest();
        test.setStringProp("thisIsATest");
        BeanTestInheritedField object = new BeanTestInheritedField("test", test);
        object.setStringProp("test");
        Map properties = inspector.getPropertyFieldtoValueMap(object, fields, true);
        assertEquals("test", properties.get("stringProp"));
        assertEquals("thisIsATest", properties.get("beanTest.stringProp"));
    }


    public void testGetPropertyFieldToValueMapSpecifyPropertiesNullList()throws Exception{
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        Map properties = inspector.getPropertyFieldtoValueMap(object, null, true);
        assertEquals("test", properties.get("StringProp"));
    }


    public void testGetPropertyFieldToValueMapSpecifyPropertiesEmptyList()throws Exception{
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        object.setStringProp("test");
        Map properties = inspector.getPropertyFieldtoValueMap(object, Collections.EMPTY_LIST, true);
        assertNotNull(properties);
        assertEquals(0, properties.size());
    }

    public void testGetModifierTakesSuperClass() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        BeanTest object = new BeanTest();
        Logger logger = ((Log4JLogger) LogFactory.getLog(ObjectInspector.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        MethodProperties methodProperties = inspector.getModifier("obj", object, Integer.class, false);
        methodProperties.invoke(new Object[] { new Integer(12345) });
        Object obj = inspector.getAcessorValue(object, "obj", false);
        assertEquals(new Integer(12345), obj);

        logger.setLevel(Level.OFF);
        methodProperties = inspector.getModifier("obj", object, Integer.class, false);
        methodProperties.invoke(new Object[] { new Integer(12345) });
        obj = inspector.getAcessorValue(object, "obj", false);
        assertEquals(new Integer(12345), obj);
    }

    public void testGetType_Object() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(Object.class.getName());
        assertEquals(Object.class, type);
    }

    public void testGetType_boolean() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(boolean.class.getName());
        assertEquals(boolean.class, type);
    }

    public void testGetType_int() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(int.class.getName());
        assertEquals(int.class, type);
    }

    public void testGetType_long() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(long.class.getName());
        assertEquals(long.class, type);
    }

    public void testGetType_short() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(short.class.getName());
        assertEquals(short.class, type);
    }

    public void testGetType_float() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(float.class.getName());
        assertEquals(float.class, type);
    }

    public void testGetType_double() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(double.class.getName());
        assertEquals(double.class, type);
    }

    public void testGetType_byte() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(byte.class.getName());
        assertEquals(byte.class, type);
    }

    public void testGetType_char() throws Exception {
        ObjectInspector inspector = new ObjectInspector();
        Class type = inspector.getType(char.class.getName());
        assertEquals(char.class, type);
    }

    public static class MockObject {

        public void test() {
            System.out.println("Test method.");
        }

        public String getTest() {
            return null;
        }

        public void setTest(String test) {
        }

        private void setPrivateTest(String test) {
        }

    }

    public class BeanTest {
        private String stringProp;
        private int intProp;
        private long longProp;
        private float floatProp;
        private boolean booleanProp;
        private Object obj;

        public String getStringProp() {
            return stringProp;
        }

        public void setStringProp(String stringProp) {
            this.stringProp = stringProp;
        }

        public int getIntProp() {
            return intProp;
        }

        public void setIntProp(int intProp) {
            this.intProp = intProp;
        }

        public long getLongProp() {
            return longProp;
        }

        public void setLongProp(long longProp) {
            this.longProp = longProp;
        }

        public float getFloatProp() {
            return floatProp;
        }

        public void setFloatProp(float floatProp) {
            this.floatProp = floatProp;
        }

        public boolean isBooleanProp() {
            return booleanProp;
        }

        public void setBooleanProp(boolean booleanProp) {
            this.booleanProp = booleanProp;
        }

        public Object getObj() {
            return obj;
        }

        public void setObj(Object obj) {
            this.obj = obj;
        }
    }

    public class BeanTestInheritedField extends BeanTest{
        private String test;
        private BeanTest beanTest;

        public BeanTestInheritedField(String test, BeanTest beanTest) {
            this.test = test;
            this.beanTest = beanTest;
        }

        public String getTest() {
            return test;
        }

        public BeanTest getBeanTest() {
            return beanTest;
        }
    }


}
