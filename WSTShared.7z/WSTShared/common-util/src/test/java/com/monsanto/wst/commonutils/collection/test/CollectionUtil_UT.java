/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.commonutils.collection.test;

import com.monsanto.wst.commonutils.collection.AcceptTest;
import com.monsanto.wst.commonutils.collection.CollectionUtil;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: CollectionUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $ On:	$Date:
 * 2006/10/11 19:46:02 $
 *
 * @author jdpoul
 * @version $Revision: 1.4 $
 */
public class CollectionUtil_UT extends TestCase {
  public CollectionUtil_UT(String name) {
    super(name);
  }

  public void testFilterNullListNullFilterInstanceNoExceptionThrow() throws Exception {
    try {
      CollectionUtil.filter(null, null);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals(
          "Both the Collection and the Test instances passed to the filter method were null. These are not valid argument values.",
          e.getMessage());
    }
  }

  public void testFilterRealListNullFilterNoExceptionThrow() throws Exception {
    try {

      CollectionUtil.filter(new ArrayList(), null);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("The Test implementation passed to the filter method was null.  This is not a valid argument value.",
          e.getMessage());
    }

  }

  public void testFilterNullListNoObjectsFilteredOutNoExceptionThrow() throws Exception {
    AcceptTest acceptTest = new AlwaysTrueAcceptTest();
    try {
      CollectionUtil.filter(null, acceptTest);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("The collection passed into the filter method was null.  This is not a valid argument value.",
          e.getMessage());
    }
  }

  public void testFilterRealListAlwaysTrueFilterNoContentsFilteredOut() throws Exception {
    List testList = new ArrayList();
    testList.add("this");
    testList.add("is");
    testList.add("a");
    testList.add("test");

    AcceptTest acceptTest = new AlwaysTrueAcceptTest();
    CollectionUtil.filter(testList, acceptTest);
    assertTrue(testList.contains("this"));
    assertTrue(testList.contains("is"));
    assertTrue(testList.contains("a"));
    assertTrue(testList.contains("test"));


  }

  public void testFilterRealListFilterOneItemAssertItemMissing() throws Exception {
    List testList = new ArrayList();
    testList.add("this");
    testList.add("is");
    testList.add("a");
    testList.add("test");

    AcceptTest acceptTest = new AcceptTestIsString();
    CollectionUtil.filter(testList, acceptTest);
    assertTrue(testList.contains("this"));
    assertFalse(testList.contains("is"));
    assertTrue(testList.contains("a"));
    assertTrue(testList.contains("test"));
  }

  public void testFilterRealListFilterOnlyNullContentNotFilteredOut() throws Exception {
    List testList = new ArrayList();
    testList.add("this");
    testList.add("is");
    testList.add("a");
    testList.add("test");
    testList.add(null);
    testList.add(null);


    AcceptTest acceptTest = new AlwaysTrueAcceptTest();
    CollectionUtil.filter(testList, acceptTest);
    assertEquals(6, testList.size());


  }

  public void testSubListNullParam() throws Exception {
    try {
      CollectionUtil.truncateList(null, null);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals(
          "Both the Collection and the Test instances passed to the filter method were null. These are not valid argument values.",
          e.getMessage());
    }
  }

  public void testSubListNullListRealTest() throws Exception {
    try {
      CollectionUtil.truncateList(null, new AlwaysTrueAcceptTest());
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("The collection passed into the filter method was null.  This is not a valid argument value.",
          e.getMessage());
    }
  }

  public void testRealListTestNull() throws Exception {
    try {

      CollectionUtil.truncateList(new ArrayList(), null);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("The Test implementation passed to the filter method was null.  This is not a valid argument value.",
          e.getMessage());
    }
  }

  public void testRealListNoMembers() throws Exception {
    List result = CollectionUtil.truncateList(new ArrayList(), new AlwaysTrueAcceptTest());
    assertTrue(result.size() == 0);
  }


  public void testRealList1MemberAlwaysTrueTest() throws Exception {
    List testList = new ArrayList();
    testList.add("this");
    List result = CollectionUtil.truncateList(testList, new AlwaysTrueAcceptTest());
    assertEquals(1, result.size());
    assertEquals("this", result.get(0));
  }


  public void testRealList1MemberTestFalseForIsString() throws Exception {
    List testList = new ArrayList();
    testList.add("is");
    List result = CollectionUtil.truncateList(testList, new AlwaysTrueAcceptTest());
    assertEquals(1, result.size());
    assertEquals("is", result.get(0));
  }


  public void testRealList2MemberTestFalseForIsStringIsIsFirstMember() throws Exception {
    List testList = new ArrayList();
    testList.add("is");
    testList.add("this");
    List result = CollectionUtil.truncateList(testList, new AcceptTestIsString());
    assertEquals(1, result.size());
    assertEquals("is", result.get(0));
  }


  public void testRealList4MemberWNullsTestFalseForIsStringIsIsFirstMember() throws Exception {
    List testList = new ArrayList();
    testList.add(null);
    testList.add(null);
    testList.add("is");
    testList.add("this");
    List result = CollectionUtil.truncateList(testList, new AcceptTestIsString());
    assertEquals(3, result.size());
    assertEquals("is", result.get(2));
  }


  public class AlwaysTrueAcceptTest implements AcceptTest {
    public boolean accept(Object o) {
      return true;
    }
  }


  public class AcceptTestIsString implements AcceptTest {
    public boolean accept(Object o) {
      if ("is".equals(o)) {
        return false;
      }
      return true;
    }
  }

}