package com.monsanto.wst.commonutils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestResults;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestUtils;
import com.monsanto.wst.commonutils.testutils.test.mock.MockAbstractJavaBean;
import com.monsanto.wst.commonutils.testutils.test.mock.MockJavaBean;
import com.monsanto.wst.commonutils.testutils.test.mock.MockJavaBeanConstructorInjection;
import com.monsanto.wst.commonutils.testutils.test.mock.MockJavaBeanReturnsNull;
import junit.framework.TestCase;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 22, 2006
 * Time: 10:32:49 AM
 * <p/>
 * Unit test for the BaseJavaBeanTestCase object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JavaBeanTestUtilsUT extends TestCase {
    private JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());

    protected void setUp() throws Exception {
        testUtils.setupLogging("CommonUtils");
        super.setUp();    //To change body of overridden methods use File | Settings | File Templates.
    }

    public void testAllProperties() throws Exception {
        MockJavaBean bean = new MockJavaBean();
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(bean);
        assertTrue(results.getCombinedResult());
        assertEquals(11, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(bean);
        assertTrue(results.getCombinedResult());
        assertEquals(11, results.getNumResults());
    }

    public void testSpecificProperties() throws Exception {
        List propertyList = new ArrayList();
        propertyList.add("testString");
        MockJavaBean bean = new MockJavaBean();
        JavaBeanTestResults results = testUtils.testProperties(bean, propertyList);
        assertTrue(results.getCombinedResult());
        assertEquals(1, results.getNumResults());
    }

    public void testAllPropertiesFails() throws Exception {
        MockJavaBeanReturnsNull bean = new MockJavaBeanReturnsNull();
        JavaBeanTestResults results = testUtils.testProperties(bean);
        assertFalse(results.getCombinedResult());
        assertEquals(2, results.getNumResults());
    }

    public void testSpecificPropertiesFails() throws Exception {
        List propertyList = new ArrayList();
        propertyList.add("testString");
        MockJavaBeanReturnsNull bean = new MockJavaBeanReturnsNull();
        JavaBeanTestResults results = testUtils.testProperties(bean, propertyList);
        assertFalse(results.getCombinedResult());
        assertEquals(1, results.getNumResults());
    }

    public void testAllPropertiesIllegalAccess() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new MockObjectInspector());
        MockJavaBean bean = new MockJavaBean();
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(bean);
        assertTrue(results.getCombinedResult());
        assertEquals(11, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(bean);
        assertTrue(results.getCombinedResult());
        assertEquals(11, results.getNumResults());
    }

    public void testPropertiesWithConstructor() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("testProperty");
        JavaBeanTestResults results = testUtils.testProperties(MockJavaBeanConstructorInjection.class, propertyList);
        assertTrue(results.getCombinedResult());
        assertEquals(1, results.getNumResults());
    }

    public void testPropertiesWhenTwoConstructorsSameNumberOfArgs() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("testLongProperty");
        JavaBeanTestResults results = testUtils.testProperties(MockJavaBeanConstructorInjection.class, propertyList);
        assertTrue(results.getCombinedResult());
        assertEquals(1, results.getNumResults());
    }

    public void testPropertiesWithConstructorAbstractObject() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("testString");
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(MockAbstractJavaBean.class, propertyList);
        assertEquals(0, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(MockAbstractJavaBean.class, propertyList);
        assertEquals(0, results.getNumResults());
    }

    public void testPropertiesWithConstructorIllegalAccess() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new MockObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("testString");
        propertyList.add("privateString");
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(MockJavaBeanConstructorInjection.class, propertyList);
        assertEquals(0, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(MockAbstractJavaBean.class, propertyList);
        assertEquals(0, results.getNumResults());
    }

    public void testPropertiesWithConstructorThrowsException() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("testString");
        propertyList.add("privateString");
        propertyList.add("throwsException");
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(MockJavaBeanConstructorInjection.class, propertyList);
        assertEquals(0, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(MockAbstractJavaBean.class, propertyList);
        assertEquals(0, results.getNumResults());
    }

    public void testPropertiesPropertyNotFound() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        List propertyList = new ArrayList();
        propertyList.add("doesNotExist");
        Logger.enableLogger(Logger.WARNING_LOG);
        JavaBeanTestResults results = testUtils.testProperties(new MockJavaBean(), propertyList);
        assertEquals(0, results.getNumResults());

        Logger.disableLogger(Logger.WARNING_LOG);
        results = testUtils.testProperties(new MockJavaBean(), propertyList);
        assertEquals(0, results.getNumResults());
    }

    public void testBuildObjectUsingSetters() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        MockJavaBean bean = (MockJavaBean) testUtils.buildObjectUsingSetters(MockJavaBean.class);
        assertNotNull(bean);
        assertNotNull(bean.getTestString());
        assertEquals(new Double(55.5), new Double(bean.getTestDouble()));
        assertEquals(new Integer(5), new Integer(bean.getTestInt()));
        assertEquals(new Boolean(true), new Boolean(bean.getTestBoolean()));
        assertEquals(new Float(5.5), new Float(bean.getTestFloat()));
        assertEquals(new Short((short) 1), new Short(bean.getTestShort()));
        assertEquals(new Long(12345), new Long(bean.getTestLong()));
        assertEquals(String.class, bean.getClazz());
        assertNotNull(bean.getTestInteger());
        assertNotNull(bean.getSuperString());
        assertNotNull(bean.getChild());
        assertNotNull(bean.getChild().getTestChildString());
    }

    public void testTestObjectSuccess() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        MockJavaBean bean = (MockJavaBean) testUtils.buildObjectUsingSetters(MockJavaBean.class);
        assertTrue(testUtils.testObject(bean));
    }

    public void testTestObjectFail() throws Exception {
        JavaBeanTestUtils testUtils = new JavaBeanTestUtils(new ObjectInspector());
        MockJavaBean bean = (MockJavaBean) testUtils.buildObjectUsingSetters(MockJavaBean.class);
        bean.getChild().setTestChildString("some other value");
        assertFalse(testUtils.testObject(bean));
    }

    private class MockObjectInspector extends ObjectInspector {
        public Method getAccessor(String propertyName, Class clazz, boolean overridePermissions) throws NoSuchMethodException {
            Method method = super.getAccessor(propertyName, clazz, true);
            method.setAccessible(false);
            return method;
        }

        public Constructor[] getConstructors(Class clazz, boolean overridePermissions) {
            Constructor[] constructors = super.getConstructors(clazz, true);
            for (int i = 0; i < constructors.length; i++) {
                constructors[i].setAccessible(false);
            }
            return constructors;
        }
    }
}
