package com.monsanto.wst.commonutils.xml.test;

import com.monsanto.wst.commonutils.xml.InvalidXPathException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 17, 2006
 * Time: 12:41:49 PM
 * <p/>
 * Unit test for the InvalidXPathException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class InvalidXPathExceptionUT extends TestCase {

    public void testCreate() throws Exception {
        Exception cause = new Exception();
        InvalidXPathException exception = new InvalidXPathException("Test Message", cause);
        assertNotNull(exception);
        assertEquals("Test Message", exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

}
