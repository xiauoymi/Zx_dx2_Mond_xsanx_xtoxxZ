package com.monsanto.wst.commonutils.properties;

import junit.framework.TestCase;

import java.util.Properties;

/*
 PlatformProperties_UT was created on Aug 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class PlatformProperties_UT extends TestCase {
  private static final String TEST_APP_NAME = "tourtrackingsystem";

  public void testPropertiesCannotBeChanged() throws Exception {
    PlatformProperties prop = new PlatformProperties(new Properties(), TEST_APP_NAME);
    try {
      prop.setProperty("something", "Somethin");
      fail("Expected exception not received");
    } catch (RuntimeException IGNORE) {
      // ignore expected exception
    }
  }

  public void testInvalidKeyFileLocationThrowsException() throws Exception {
    try {
      new PlatformProperties(new Properties(), "someAppThatDoesNotExist");
      fail("Expected exception not received");
    } catch (RuntimeException IGNORE) {
      // ignore expected exception
    }
  }

  public void testEncryptedPasswordIsFound() throws Exception {
    PlatformProperties prop = new PlatformProperties(new Properties(), TEST_APP_NAME);
    assertNotNull(prop.getProperty("password"));
  }

  public void testEncryptedPasswordIsFoundWithSpecifiedPropertyName() throws Exception {
    String testPropertyName = "TEST_PROP";
    PlatformProperties prop = new PlatformProperties(new Properties(), TEST_APP_NAME, testPropertyName);
    assertNotNull(prop.getProperty(testPropertyName));
  }

  public void testPlatformSpecificProperties() throws Exception {
    String testParamName = "abc";
    String testDevValue = "ItsDev";
    String testTestValue = "ItsTest";
    String lsiProperty = "lsi.function";
    Properties baseProperties = new Properties();
    baseProperties.setProperty("dev." + testParamName, testDevValue);
    baseProperties.setProperty("test." + testParamName, testTestValue);
    String originalLsiValue = System.getProperty(lsiProperty);
    try {
      System.setProperty(lsiProperty, "dev");
      Properties devProperties = new PlatformProperties(baseProperties, TEST_APP_NAME);
      assertEquals(testDevValue, devProperties.getProperty(testParamName));

      System.setProperty(lsiProperty, "test");
      Properties testProperties = new PlatformProperties(baseProperties, TEST_APP_NAME);
      assertEquals(testTestValue, testProperties.getProperty(testParamName));

      System.setProperty(lsiProperty, "dev");
      Properties devProperties2 = new PlatformProperties(baseProperties, TEST_APP_NAME);
      assertEquals(testDevValue, devProperties2.getProperty(testParamName));
    } finally {
      if (originalLsiValue != null) {
        System.setProperty(lsiProperty, originalLsiValue);
      }
    }
  }

}