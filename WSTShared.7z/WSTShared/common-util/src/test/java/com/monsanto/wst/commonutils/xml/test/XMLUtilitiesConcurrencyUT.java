package com.monsanto.wst.commonutils.xml.test;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.resources.ResourceUtils;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.ArrayList;

/*
 XMLUtilitiesConcurrencyUT was created on May 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class XMLUtilitiesConcurrencyUT extends TestCase {
  private static final String TEST_XML = "<foo><a><b id='1234'><c/><d><e name='1234'>foo</e></d></b></a></foo>";

  public void testOneThreadJustToCheckTheTest() throws Exception {
    Element elmt = readElmt();
    XMLUtilitiesTestThreadGroup threadGroup = new XMLUtilitiesTestThreadGroup();
    XMLUtilities xmlUtilities = new XMLUtilities(new ResourceUtils());
    XMLUtilitiesTestThread thread = new XMLUtilitiesTestThread(threadGroup, (Element) (elmt.cloneNode(true)), "SingleThread",
        xmlUtilities);
    thread.start();
    thread.join();

    assertFalse(threadGroup.hadError());
  }

  public void testManyThreads() throws Exception {
    Element elmt = readElmt();
    int nbThreads = 500;

    XMLUtilitiesTestThreadGroup threadGroup = new XMLUtilitiesTestThreadGroup();
    List startedThreads = new ArrayList();
    XMLUtilities xmlUtilities = new XMLUtilities(new ResourceUtils());
    for (int i = 0; i < nbThreads; i++) {
      //    Element cloned here (from main thread --v)
      XMLUtilitiesTestThread thread = new XMLUtilitiesTestThread(threadGroup, (Element) (elmt.cloneNode(true)), "Th" + i,
          xmlUtilities);
      thread.start();
      startedThreads.add(thread);
    }

    join(startedThreads);

    assertFalse(threadGroup.hadError());
  }

  private void join(List startedThreads) throws InterruptedException {
    for (int i = 0; i < startedThreads.size(); i++) {
      Thread thread = ((Thread) startedThreads.get(i));
      thread.join();
    }
  }

  private Element readElmt() throws Exception {
    Document doc = DOMUtil.newDocument(new ByteArrayInputStream(TEST_XML.getBytes()));

    NodeList liste = doc.getChildNodes();
    boolean done = false;
    Element elmt = null;
    if (liste != null) {
      for (int i = 0, max = liste.getLength(); (i < max) && (!done); i++) {
        if (liste.item(i).getNodeType() != Element.ELEMENT_NODE) continue;
        elmt = (Element) (liste.item(i));
        done = true;
      }
    }
    return elmt;
  }

  public static class XMLUtilitiesTestThreadGroup extends ThreadGroup {
    private boolean hadError;

    public XMLUtilitiesTestThreadGroup() {
      super("XMLUtilTest");
      this.hadError = false;
    }

    public void uncaughtException(Thread t, Throwable e) {
      hadError = true;
      e.printStackTrace();
      interrupt();
    }

    public boolean hadError() {
      return hadError;
    }
  }

  public static class XMLUtilitiesTestThread extends Thread {
    private final Element element;
    private final XMLUtilities xmlUtilities;

    public XMLUtilitiesTestThread(ThreadGroup threadGroup, Element element, String threadName,
                                  XMLUtilities xmlUtilities) {
      super(threadGroup, threadName);
      this.element = element;
      this.xmlUtilities = xmlUtilities;
    }

    public void run() {
      for (int i = 0; (i < 10000) && !isInterrupted(); i++) {
        Element eElement = xmlUtilities.getElementByNameAttribute(element, "1234");
        assertNotNull(eElement);
        assertEquals("e", eElement.getNodeName());
      }
    }
  }
}