package com.monsanto.wst.commonutils.testutils.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 1, 2006
 * Time: 2:29:46 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockChildJavaBean {
    private String testChildString;
    private int testInt;
    private Class clazz;

    public String getTestChildString() {
        return testChildString;
    }

    public void setTestChildString(String testChildString) {
        this.testChildString = testChildString;
    }

    public int getTestInt() {
        return testInt;
    }

    public void setTestInt(int testInt) {
        this.testInt = testInt;
    }

    public Class getClazz() {
        return clazz;
    }

    public void setClazz(Class clazz) {
        this.clazz = clazz;
    }
}
