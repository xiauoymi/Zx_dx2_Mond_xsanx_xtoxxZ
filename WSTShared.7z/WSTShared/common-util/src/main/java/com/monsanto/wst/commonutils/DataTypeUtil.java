/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.commonutils;

import com.monsanto.Util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: DataTypeUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date:
 * 2006/09/29 19:14:22 $
 *
 * @author jdpoul
 * @version $Revision: 1.4 $
 */
public class DataTypeUtil {

  public static final String BOOLEAN_TRUE_STRING = "Y";
  public static final String BOOLEAN_FALSE_STRING = "N";
  public static final Integer INTEGER_TRUE_VALUE = new Integer(1);

  public Boolean convertYNStringIntoBoolean(String yNString) {
    if (BOOLEAN_TRUE_STRING.equals(yNString)) {
      return Boolean.TRUE;
    }
    return Boolean.FALSE;
  }

  public Boolean convertIntegerIntoBoolean(Integer value) {
    if (INTEGER_TRUE_VALUE.equals(value)) {
      return Boolean.TRUE;
    }
    return Boolean.FALSE;
  }

  public Long convertStringToLongIgnoreNumberFormatException(String string) {
    try {
      return new Long(string);
    } catch (NumberFormatException e) {
      return null;
    }
  }

  public Date convertStringToDate(String stringDate, String formatOfDate) throws DateFormatException {
    Date date = null;
    if (StringUtils.isNullOrEmpty(stringDate)) {
      return null;
    }

    try {
      SimpleDateFormat formatter = new SimpleDateFormat(formatOfDate);
      date = formatter.parse(stringDate);
    } catch (ParseException e) {
      throw new DateFormatException(
          "Unable to convert input string: " + stringDate + " into a Date Object using format: " + formatOfDate + ".",
          e);
    } catch (IllegalArgumentException e) {
      throw new DateFormatException("The format string: " + formatOfDate + " is not a valid java date format string.",
          e);
    }
    return date;
  }

  public String convertPrimitiveBooleanToYNString(boolean bool) {
    if (bool) {
      return BOOLEAN_TRUE_STRING;
    } else {
      return BOOLEAN_FALSE_STRING;
    }
  }
}