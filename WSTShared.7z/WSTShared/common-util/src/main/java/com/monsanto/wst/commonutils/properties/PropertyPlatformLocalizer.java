package com.monsanto.wst.commonutils.properties;

import java.util.Properties;
import java.util.Map;
/*
 PropertyPlatformLocalizer was created on Aug 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class PropertyPlatformLocalizer {
  public static final String UNKNOWN_PLATFORM = "UNKNOWN";

  public String getLocalKey(String propertyKey) {
    String prefixValue = getPrefix() + '.';
    if (propertyKey.startsWith(prefixValue)) {
      return propertyKey.substring(prefixValue.length());
    } else {
      return propertyKey;
    }
  }

  public Properties getLocalizedProperties(Properties base) {
    Properties localized = new Properties();
    for (Map.Entry<Object, Object> entry : base.entrySet()) {
      String key = getLocalKey(safeToString(entry.getKey()));
      String value = safeToString(entry.getValue());
      localized.setProperty(key, value);
    }
    return localized;
  }

  public String getPrefix() {
    return System.getProperty("lsi.function", UNKNOWN_PLATFORM);
  }

  private String safeToString(Object obj) {
    if (obj == null) {
      return null;
    } else {
      return obj.toString();
    }
  }
}
