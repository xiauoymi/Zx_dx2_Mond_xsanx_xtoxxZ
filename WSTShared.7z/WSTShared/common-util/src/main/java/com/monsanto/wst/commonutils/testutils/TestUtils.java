package com.monsanto.wst.commonutils.testutils;

import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.*;

import java.io.IOException;
import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 1:49:07 PM
 * <p/>
 * This class defines utility methods for setting up and helping with tests.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TestUtils {
  private static final Random rand = new Random();
  private static final int MAX_IDENTIFIER_LENGTH = 20;

  /**
     * This method sets up logging for a test case.
     *
     * @throws IOException - If unable to access environment variables.
     * @throws LogRegistrationException - If unable to register loggers.
     * @param applicationName
     */
    public void setupLogging(String applicationName) throws IOException, LogRegistrationException {
      LogDevice AppLogDevice = new Log4JConsoleLogDevice();
      Logger.register(new Log4JDebugLog  (applicationName, AppLogDevice));
      Logger.enableLogger(Logger.DEBUG_LOG);
      Logger.register(new Log4JInfoLog   (applicationName, AppLogDevice));
      Logger.enableLogger(Logger.INFO_LOG);
      Logger.register(new Log4JWarningLog(applicationName, AppLogDevice));
      Logger.enableLogger(Logger.WARNING_LOG);
      Logger.register(new Log4JErrorLog  (applicationName, AppLogDevice));
      Logger.enableLogger(Logger.ERROR_LOG);
    }

    /**
     * Tears down logging and closes any open loggers.
     */
    public void tearDownLogging() {
        Logger.closeLogging();
    }

  public static String getRandomIdentifier() {
    String tempString = "test-" + rand.nextLong();
    if (tempString.length() <= MAX_IDENTIFIER_LENGTH) {
      return tempString;
    } else {
      return tempString.substring(0, MAX_IDENTIFIER_LENGTH);
    }
  }

  public static long getRandomLong() {
    return rand.nextLong();
  }

  public static long getRandomInt() {
    return rand.nextInt();
  }
}
