package com.monsanto.wst.commonutils.xml;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 19, 2005
 * Time: 10:58:33 AM
 * <p/>
 * This class is an error handler used to record xml validation errors.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLValidationErrorHandler implements ErrorHandler {

    private List errorList = new ArrayList();

    /**
     * This method adds a warning SAXParseException to the internal list of exceptions.
     *
     * @param exception SAXParseException representing the warning.
     * @throws SAXException - Currently this should not happen.
     */
    public void warning(SAXParseException exception) throws SAXException {
        this.errorList.add(exception);
    }

    /**
     * This method adds an error SAXParseException to the internal list of exceptions.
     *
     * @param exception SAXParseException representing the error.
     * @throws SAXException - Currently this should not happen.
     */
    public void error(SAXParseException exception) throws SAXException {
        this.errorList.add(exception);
    }

    /**
     * This method adds a fatal error SAXParseException to the internal list of exceptions.
     *
     * @param exception SAXParseException representing the fatal error.
     * @throws SAXException - Currently this should not happen.
     */
    public void fatalError(SAXParseException exception) throws SAXException {
        this.errorList.add(exception);
    }

    /**
     * This method returns all validation errors and warnings that occurred.
     *
     * @return List - Object representing the errors and warnings.
     */
    public List getErrors() {
        return this.errorList;
    }

}
