/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.commonutils;

/**
 * Filename:    $RCSfile: DateFormatException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-04-11 19:37:50 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class DateFormatException extends Exception{
  public DateFormatException(String message, Throwable cause) {
    super(message, cause);
  }
}