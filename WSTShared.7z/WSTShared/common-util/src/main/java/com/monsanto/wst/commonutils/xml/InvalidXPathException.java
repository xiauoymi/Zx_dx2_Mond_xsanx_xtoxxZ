package com.monsanto.wst.commonutils.xml;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 17, 2006
 * Time: 12:43:03 PM
 * <p/>
 * This is a custom exception for reporting invalid xpath expressions.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class InvalidXPathException extends RuntimeException {

    /**
     * This constructor takes a message and a cause.
     *
     * @param message String representing the error message.
     * @param cause Throwable representing the cause of the error.
     */
    public InvalidXPathException(String message, Throwable cause) {
        super(message, cause);
    }
}
