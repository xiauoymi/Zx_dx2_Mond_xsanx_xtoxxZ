package com.monsanto.wst.commonutils.template;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 2:20:55 PM
 * <p/>
 * This class is the file implementation of the MessageTemplate interface.  It uses the content of a file as the
 * template.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FileMessageTemplate extends SimpleMessageTemplate {
    /**
     * This constructor takes a string representing the path to the file and an object inspector object.
     *
     * @param template String representing the path to the file template.
     * @param objectInspector ObjectInspector object.
     */
    public FileMessageTemplate(String template, ObjectInspector objectInspector) {
        super(objectInspector);
        try {
          setStringTemplate(FileUtil.readFileToString(getClass().getClassLoader().getResourceAsStream(template)));
        } catch (IOException e) {
          throw new TemplateNotFoundException("Unable to find or open template at path: '" + template + "'");
        }
    }

}
