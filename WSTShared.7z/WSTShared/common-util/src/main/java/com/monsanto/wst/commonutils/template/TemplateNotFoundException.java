package com.monsanto.wst.commonutils.template;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 3:36:19 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TemplateNotFoundException extends RuntimeException {
  public TemplateNotFoundException() {
  }

  public TemplateNotFoundException(String message) {
    super(message);
  }

  public TemplateNotFoundException(Throwable cause) {
    super(cause);
  }

  public TemplateNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }
}
