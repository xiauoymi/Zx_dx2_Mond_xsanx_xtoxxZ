package com.monsanto.wst.commonutils.testutils;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 22, 2006
 * Time: 9:57:17 AM
 * <p>
 * This class is a custom test case for testing java beans.  To learn about what a JavaBean is and what constitutes a
 * property, see the JavaBean spec:
 * <br />
 * <a href="http://java.sun.com/products/javabeans/docs/spec.html">JavaBean Spec</a>
 * </p>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JavaBeanTestUtils extends TestUtils {
    private ObjectInspector objectInspector;

    /**
     * This constructor takes all dependencies.
     *
     * @param objectInspector ObjectInspector object for inspecting objects.
     */
    public JavaBeanTestUtils(ObjectInspector objectInspector) {
        this.objectInspector = objectInspector;
    }

    /**
     * This method tests the properties in the specified JavaBean class using an appropriate constructor to inject the
     * data.
     *
     * @param clazz Class representing the object to test.
     * @param propertyList List of property names to test in the correct order relative to the constructor.
     * @return JavaBeanTestResults - Object containing the results.
     */
    public JavaBeanTestResults testProperties(Class clazz, List propertyList) {
        JavaBeanTestResults results = new JavaBeanTestResults();
        testPropertiesWithConstructor(propertyList, results, clazz);
        return results;
    }

    /**
     * This method tests the properties of the specified class using it's constructor.
     *
     * @param propertyList List representing the property names to test.
     * @param results JavaBeanTestResults object representing the results.
     * @param clazz Class representing the object to test.
     */
    private void testPropertiesWithConstructor(List propertyList, JavaBeanTestResults results, Class clazz) {
        Constructor[] constructors = this.objectInspector.getConstructors(clazz, false);
        Object parent = null;
        for (int i = 0; i < constructors.length; i++) {
            if (isMatchedConstructor(constructors[i], propertyList)) {
                Constructor constructor = constructors[i];
                Object[] args = new Object[constructor.getParameterTypes().length];
                try {
                    parent = constructObject(constructor, propertyList, args);
                    testConstructorProperties(parent, propertyList, args, results);
                    break;
                } catch (IllegalAccessException e) {
                } catch (InstantiationException e) {
                } catch (InvocationTargetException e) {
                }
            }
        }
    }

    /**
     * This method returns whether the contructor specified matches the properties specified.
     *
     * @param constructor Constructor to match.
     * @param propertyList List of property names.
     * @return boolean - Representing if the constuctor matched the properties.
     */
    private boolean isMatchedConstructor(Constructor constructor, List propertyList) {
        if (constructor.getParameterTypes().length == propertyList.size()) {
            return isConstructorWithMatchedTypes(propertyList, constructor);
        }
        return false;
    }

    /**
     * This method checks the types of the properties specified against the constructor's args.
     *
     * @param propertyList List representing the property names.
     * @param constructor Constructor object representing the constructor to check.
     * @return boolean - Representing if the types match.
     */
    private boolean isConstructorWithMatchedTypes(List propertyList, Constructor constructor) {
        try {
            boolean haveEqualTypes = true;
            for (int i = 0; i < propertyList.size(); i++) {
                String propertyName = (String) propertyList.get(i);
                Class constuctorArgType = constructor.getParameterTypes()[i];
                Method method = objectInspector.getAccessor(propertyName, constructor.getDeclaringClass(), false);
                if (!constuctorArgType.equals(method.getReturnType())) {
                    haveEqualTypes = false;
                }
            }
            return haveEqualTypes;
        } catch (NoSuchMethodException e) {
        }
        return false;
    }

    /**
     * This method tests constructor property values to verify they are equal to the accessors they correspond to.
     *
     * @param obj Object representing the object to test.
     * @param propertyList List of property names to test.
     * @param args Object[] representing the constructor property values.
     * @param results JavaBeanTestResults object representing the results.
     */
    private void testConstructorProperties(Object obj, List propertyList, Object[] args, JavaBeanTestResults results) {
        for (int j = 0; j < propertyList.size(); j++) {
            try {
                Object value = getPropertyValue((String) propertyList.get(j), obj);
                results.addResult((String) propertyList.get(j), value.equals(args[j]));
            } catch (NoSuchMethodException e) {
            } catch (IllegalAccessException e) {
            } catch (InvocationTargetException e) {
            }
        }
    }

    /**
     * This method constructs the object to be tested using an appropriate constructor.
     *
     * @param constructor Constructor to instantiate the object with.
     * @param propertyList List of property names to test.
     * @param args Object[] representing the arguments for the constructor.
     * @return Object - Representing the constructed object.
     * @throws IllegalAccessException - If unable to access the constructor.
     * @throws InstantiationException - If unable to instantiate the constructor.
     * @throws InvocationTargetException - If the constructor throws an exception.
     */
    private Object constructObject(Constructor constructor, List propertyList, Object[] args)
            throws IllegalAccessException, InstantiationException, InvocationTargetException {
        buildConstructorArguments(constructor, propertyList, args);
        try {
            return constructor.newInstance(args);
        } catch (InstantiationException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to instantiate java bean '" +
                        constructor.getDeclaringClass().getName() + "'.  This most likely happened because the java " +
                        "bean is abstract or is an interface."));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (IllegalAccessException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to access constructor for java bean '" +
                        constructor.getDeclaringClass().getName() + "'.  This most likely happened because the java " +
                        "bean's constructor is protected or private."));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (InvocationTargetException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to invoke constructor for java bean '" +
                        constructor.getDeclaringClass().getName() + "'.  The constructor threw an exception."));
                Logger.log(new LoggableWarning((Exception) e.getCause()));
            }
            throw e;
        }
    }

    /**
     * This method builds an array of constructor arguments that will be used to create the object.
     *
     * @param constructor Constructor representing the constructor to build arguments for.
     * @param propertyList List of property names to test.
     * @param args Object[] representing the argument array to populate.
     */
    private void buildConstructorArguments(Constructor constructor, List propertyList, Object[] args) {
        for (int j = 0; j < constructor.getParameterTypes().length; j++) {
            args[j] = createTestValue(constructor.getParameterTypes()[j], (String) propertyList.get(j));
        }
    }

    /**
     * This method tests all properties according to the JavaBean spec.  A property must have a getter and setter.
     * This will verify that what goes in does come out.  If that is not the business requirement, then you should test
     * that getter and/or setter directly and use the overloaded testProperties method that takes a list of properties
     * you want to test.
     *
     * @param obj Object being tested.
     * @return JavaBeanTestResults - Object containing the test results.
     */
    public JavaBeanTestResults testProperties(Object obj) {
        List propertyList = getProperties(obj);
        return testProperties(obj, propertyList);
    }

    /**
     * This method overloads the testProperties method to allow you to specify which properties you want to test.
     *
     * @param obj Object being tested.
     * @param propertyList List of property names to test.
     * @return JavaBeanTestResults - Object containing the test results.
     */
    public JavaBeanTestResults testProperties(Object obj, List propertyList) {
        JavaBeanTestResults results = new JavaBeanTestResults();
        for (int i = 0; i < propertyList.size(); i++) {
            String propertyName = (String) propertyList.get(i);
            testSetterProperty(propertyName, obj, results);
        }
        return results;
    }

    /**
     * This method creates the object represented by the specified class and provides test values for all known types.
     *
     * @param clazz Class representing the object to build.
     * @return Object - Representing the constructed object.
     */
    public Object buildObjectUsingSetters(Class clazz) {
        Object obj = null;
        try {
            obj = clazz.newInstance();
            List propertyList = this.objectInspector.getPropertyNames(clazz, true);
            for (int i = 0; i < propertyList.size(); i++) {
                try {
                    String propertyName = (String) propertyList.get(i);
                    Class type = getPropertyType(propertyName, obj);
                    Object value = createTestValue(type, propertyName);
                    setPropertyValue(propertyName, obj, type, value);
                } catch (NoSuchFieldException e) {
                } catch (NoSuchMethodException e) {
                } catch (InvocationTargetException e) {
                } catch (IllegalAccessException e) {
                }
            }
            return obj;
        } catch (InstantiationException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to instantiate java bean '" +
                        clazz.getName() + "'.  This most likely happened because the java " +
                        "bean is abstract or is an interface."));
                Logger.log(new LoggableWarning(e));
            }
        } catch (IllegalAccessException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to access constructor for java bean '" +
                        clazz.getName() + "'.  This most likely happened because the java " +
                        "bean's constructor is protected or private."));
                Logger.log(new LoggableWarning(e));
            }
        }
        return null;
    }

    /**
     * This method tests the specified object that all valid properties are equal to those of the build object
     * methods.
     *
     * @param obj Object to be tested.
     * @return boolean - Representing that the object's properties are equal.
     */
    public boolean testObject(Object obj) {
        List propertyList = getProperties(obj);
        for (int i = 0; i < propertyList.size(); i++) {
            String propertyName = (String) propertyList.get(i);
            try {
                Object value = getPropertyValue(propertyName, obj);
                Class type = getPropertyType(propertyName, obj);
                Object testValue = createTestValue(type, propertyName);
                this.objectInspector.getModifier(propertyName, obj.getClass(), type, false);
                if (testValue != null) {
                    if (!testValue.equals(value)) {
                        if (isJavaType(value) || !testObject(value)) {
                            return false;
                        }
                    }
                }
            } catch (NoSuchMethodException e) {
            } catch (IllegalAccessException e) {
            } catch (InvocationTargetException e) {
            } catch (NoSuchFieldException e) {
            }
        }
        return true;
    }

    /**
     * This method returns a list of available properties on the specified object.
     *
     * @param obj Object containing the properties.
     * @return List - Of property names.
     */
    private List getProperties(Object obj) {
        return this.objectInspector.getPropertyNames(obj.getClass(), true);
    }

    /**
     * This method tests a property for accessors and veryifies that that property follows the JavaBean spec.
     *
     * @param propertyName String representing the name of the property to test.
     * @param obj Object that property exists in.
     * @param results JavaBeanTestResults object containing all test results.
     */
    private void testSetterProperty(String propertyName, Object obj, JavaBeanTestResults results) {
        try {
            Class type = getPropertyType(propertyName, obj);
            if (!type.equals(obj.getClass())) {
                Object initializedValue = createTestValue(type, propertyName);
                if (initializedValue != null) {
                    setPropertyValue(propertyName, obj, type, initializedValue);
                    Object value = getPropertyValue(propertyName, obj);
                    results.addResult(propertyName, initializedValue.equals(value));
                }
            }
        } catch (NoSuchMethodException e) {
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e) {
        } catch (NoSuchFieldException e) {
        }
    }

    /**
     * This method retrieves the type of the specified property on the specified object.
     *
     * @param propertyName String representing the property name.
     * @param obj Object representing the object that contains the property.
     * @return Class - Representing the property's type.
     * @throws NoSuchFieldException - If unable to find the property.
     */
    private Class getPropertyType(String propertyName, Object obj) throws NoSuchFieldException {
        try {
            Field field = this.objectInspector.getField(propertyName, obj.getClass(), true);
            return field.getType();
        } catch (NoSuchFieldException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to find property: '" + propertyName +
                        "'.  Skipping this property."));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        }
    }

    /**
     * This method returns the property value associated with the specified property name.
     *
     * @param propertyName String representing the property name.
     * @param obj Object representing the object being tested.
     * @return Object - Representing the value of the property.
     * @throws NoSuchMethodException - If unable to find an accessor for the property.
     * @throws IllegalAccessException - If unable to access the accessor for the property.
     * @throws InvocationTargetException - If the accessor throws an exception.
     */
    private Object getPropertyValue(String propertyName, Object obj)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        try {
            return this.objectInspector.getAcessorValue(obj, propertyName, false);
        } catch (NoSuchMethodException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to find accessors for property: '" + propertyName +
                        "'.  Skipping this property."));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (IllegalAccessException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to access accessors for property: '" + propertyName +
                        "'.  Skipping this property"));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (InvocationTargetException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to invoke accessor for property: '" + propertyName +
                        "'.  The method threw and exception.  Skipping this property."));
                Logger.log(new LoggableWarning((Exception) e.getCause()));
            }
            throw e;
        }
    }

    /**
     * This method sets the property value for the specified property on the specified object.
     *
     * @param propertyName String representing the property name.
     * @param obj Object representing the object to set the property on.
     * @param type Class representing the type of the property.
     * @param initializedValue Object representing the value to be set.
     * @throws NoSuchMethodException - If unable to find the setter.
     * @throws IllegalAccessException - If unable to access the setter.
     * @throws InvocationTargetException - If the setter throws an exception.
     */
    private void setPropertyValue(String propertyName, Object obj, Class type, Object initializedValue)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        try {
            Method setter = this.objectInspector.getModifier(propertyName, obj.getClass(), type, false);
            setter.invoke(obj, new Object[] { initializedValue });
        } catch (NoSuchMethodException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to find accessors for property: '" + propertyName +
                        "'.  Skipping this property."));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (IllegalAccessException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to access accessors for property: '" + propertyName +
                        "'.  Skipping this property"));
                Logger.log(new LoggableWarning(e));
            }
            throw e;
        } catch (InvocationTargetException e) {
            if (Logger.isEnabled(Logger.WARNING_LOG)) {
                Logger.log(new LoggableWarning("Unable to invoke accessor for property: '" + propertyName +
                        "'.  The method threw and exception.  Skipping this property."));
                Logger.log(new LoggableWarning((Exception) e.getCause()));
            }
            throw e;
        }
    }

    /**
     * This method creates a test value of the specified type.
     *
     * @param type Class representing the type of object to create a test value of.
     * @param propertyName String representing the name of the property.
     * @return Object - Representing the test value.
     */
    private Object createTestValue(Class type, String propertyName) {
        if (Integer.class.equals(type) || int.class.equals(type)) {
            return new Integer(5);
        } else if (Double.class.equals(type) || double.class.equals(type)) {
            return new Double(55.5);
        } else if (Float.class.equals(type) || float.class.equals(type)) {
            return new Float(5.5);
        } else if (Short.class.equals(type) || short.class.equals(type)) {
            return new Short((short) 1);
        } else if (Long.class.equals(type) || long.class.equals(type)) {
            return new Long(12345);
        } else if (Boolean.class.equals(type) || boolean.class.equals(type)) {
            return new Boolean(true);
        } else if (Class.class.equals(type)) {
            return String.class;
        } else if (String.class.equals(type)) {
            return "Y";
        }
        return buildObjectUsingSetters(type);
    }

    /**
     * This method returns that the specified object is of a java type.
     *
     * @param value Object to check.
     * @return boolean - Representing if the object is a java type.
     */
    private boolean isJavaType(Object value) {
        return value.getClass().getName().indexOf("java.lang") != -1;
    }
}
