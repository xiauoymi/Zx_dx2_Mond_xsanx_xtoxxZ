package com.monsanto.wst.commonutils.document;

import com.monsanto.POSClient.POSMIMEConstants;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 20, 2006
 * Time: 10:41:17 AM
 * <p/>
 * This class is a mime type utility object for providing mime type related functions.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MimeTypeUtils {
    private Map extensionToMimeTypeMap = new HashMap();
    {
        extensionToMimeTypeMap.put("doc", POSMIMEConstants.MIME_TYPE_MSWORD);
        extensionToMimeTypeMap.put("xls", POSMIMEConstants.MIME_TYPE_MSEXCEL);
        extensionToMimeTypeMap.put("pdf", POSMIMEConstants.MIME_TYPE_PDF);
        extensionToMimeTypeMap.put("xml", POSMIMEConstants.MIME_TYPE_XML);
        extensionToMimeTypeMap.put("txt", POSMIMEConstants.MIME_TYPE_TEXT);
        extensionToMimeTypeMap.put("docx", POSMIMEConstants.MIME_TYPE_MSWORDXML);
        extensionToMimeTypeMap.put("xlsx", POSMIMEConstants.MIME_TYPE_MSEXCELXML);
        extensionToMimeTypeMap.put("ppt", POSMIMEConstants.MIME_TYPE_MSPOWERPOINT);
        extensionToMimeTypeMap.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
    }

    /**
     * This method returns the mime type of the specified file based on it's extension.
     *
     * @param file File object representing the file.
     * @return String - Representing the mime type.
     */
    public String getDocumentMimeType(File file) {
        return (String) this.extensionToMimeTypeMap.get(getFileExtension(file));
    }

      /**
     * This method returns the mime type of the specified file based on it's extension.
     *
     * @param fileName string representing the name of the file
     * @return String - Representing the mime type.
     */
    public String getDocumentMimeType(String fileName) {
        return (String) this.extensionToMimeTypeMap.get(getFileExtension(fileName));
    }

    /**
     * This method adds or changes the mime type of the specified extension.
     *
     * @param extension String representing the extension.
     * @param mimeType String representing the mime type.
     */
    public void addMimeType(String extension, String mimeType) {
        this.extensionToMimeTypeMap.put(extension, mimeType);
    }

    /**
     * This method returns the file extension of the specified file.
     *
     * @param file File object representing the file.
     * @return String - Representing the extension.
     */
    private String getFileExtension(File file) {
        return getFileExtension(file.getName());
    }

      /**
     * This method returns the file extension of the specified file.
     *
     * @param fileName string representing name of the file
     * @return String - Representing the extension.
     */
    private String getFileExtension(String fileName) {
        if (fileName.lastIndexOf('.') > -1) {
            return fileName.substring(fileName.lastIndexOf('.') + 1);
        }
        return "";
    }
}
