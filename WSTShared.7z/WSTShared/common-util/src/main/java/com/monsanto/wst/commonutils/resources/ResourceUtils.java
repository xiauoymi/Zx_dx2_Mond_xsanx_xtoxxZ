package com.monsanto.wst.commonutils.resources;

import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 8:56:51 AM
 * <p/>
 * This class it a utility class for resolving resources.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ResourceUtils {

    /**
     * This method takes a path to a URL resource and returns a URL object representing that path.  The path can
     * represent either a url, a uri or a classpath.
     *
     * Example:
     * classpath = com/monsanto/someTeam/someApplication/somePackage/myResource.properties
     * url = http://www.google.com
     * uri = /WEB-INF/resources/myResource.properties
     *
     * @param path String representing the path to the url.
     * @return URL - Representing the url at the specified path.
     * @throws MalformedURLException - If unable to convert the path to a url.
     */
    public URL convertPathToURL(String path) throws MalformedURLException {
        URL url = getClass().getClassLoader().getResource(path);
        if (url == null) {
            url = new URL(path);
        }
        return url;
    }

    /**
     * This method takes a path and converts it into a File.  The path can represent either a uri, classpath, or file.
     *
     * Example:
     * uri = /WEB-INF/resources/myResource.properties
     * classpath = /com/monsanto/someTeam/someApplication/somePackage/myResource.properties
     * file = C:/myFile.txt
     *
     * @param path String representing the path to the file.
     * @return File - Representing the file located at the specified path.
     * @throws FileNotFoundException - If unable to find the file.
     */
    public File convertPathToFile(String path) throws FileNotFoundException {
        String decodedPath = path;

        try {
            URL url = convertPathToURL(path);
            decodedPath = StringUtils.replace(url.getFile(), "%20", " ");
            decodedPath = StringUtils.replace(decodedPath, "%5c", "/");
        } catch (MalformedURLException e) {
        }

        File file = new File(decodedPath);
        if (file.exists()) {
            return file;
        }

        throw new FileNotFoundException("Unable to find resource with path: '" +
                path + "'.  Check to make sure the resource exists.");
    }

}
