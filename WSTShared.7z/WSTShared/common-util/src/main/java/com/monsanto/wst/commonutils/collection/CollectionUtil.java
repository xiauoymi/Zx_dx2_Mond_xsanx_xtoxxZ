/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.commonutils.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: CollectionUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date:
 * 2006/10/11 15:11:53 $
 *
 * @author JDPOUL
 * @version $Revision: 1.4 $
 */
public class CollectionUtil {

  public static void filter(Collection collection, AcceptTest acceptTest) {
    checkArgs(collection, acceptTest);

    for (Iterator itemsIterator = collection.iterator(); itemsIterator.hasNext();) {
      Object item = (Object) itemsIterator.next();
      if (!acceptTest.accept(item)) {
        itemsIterator.remove();
      }
    }
  }


  public static List truncateList(List list, AcceptTest acceptTest) {
    checkArgs(list, acceptTest);
    List subList = new ArrayList();
    for (int counter = 0; counter < list.size(); counter++) {
      Object item = list.get(counter);
      subList.add(item);
      if (!acceptTest.accept(item)) {
        break;
      }
    }
    return subList;
  }

  private static void checkArgs(Collection collection, AcceptTest acceptTest) {

    if (collection == null && acceptTest == null) {
      throw new IllegalArgumentException(
          "Both the Collection and the Test instances passed to the filter method were null. These are not valid argument values.");
    }
    if (collection == null) {
      throw new IllegalArgumentException(
          "The collection passed into the filter method was null.  This is not a valid argument value.");
    }

    if (acceptTest == null) {
      throw new IllegalArgumentException(
          "The Test implementation passed to the filter method was null.  This is not a valid argument value.");
    }
  }
}