package com.monsanto.wst.commonutils.xml;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 9:20:39 AM
 * <p/>
 * This class is subclass of java.lang.Exception for defining XML parsing errors.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLParserException extends Exception {

    /**
     * Default no args constructor.
     */
    public XMLParserException() {
        super();
    }

    /**
     * This constructor takes a message describing the error.
     *
     * @param message String representing the message.
     */
    public XMLParserException(String message) {
        super(message);
    }

    /**
     * This constructor takes a message and a cause.
     *
     * @param message String representing the message.
     * @param cause Throwable object representing the cause of this exception.
     */
    public XMLParserException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * This constructor takes the cause of this exception.
     *
     * @param cause Throwable object representing the cause of this exception.
     */
    public XMLParserException(Throwable cause) {
        super(cause);
    }
    
}
