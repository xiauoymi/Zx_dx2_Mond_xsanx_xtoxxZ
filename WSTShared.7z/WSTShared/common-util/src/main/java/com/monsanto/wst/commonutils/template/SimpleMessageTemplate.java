package com.monsanto.wst.commonutils.template;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * Date: Jan 24, 2007
 * Time: 1:53:20 PM
 * <p/>
 * This class is a simple implementation of the MessageTemplate interface.  It takes a string template at creation
 * containing encoded variables and replaces them with dynamic values when requested.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SimpleMessageTemplate implements MessageTemplate {
    private static final String complexTypePatternString = "\\$\\{([^\\}]*)\\}";
    private static final String gobalRegexPatternString = "\\$\\{global:([^\\}]+)\\}";
    private static final Pattern complexTypePattern = Pattern.compile(complexTypePatternString, Pattern.MULTILINE);
    private static final Pattern globalPattern = Pattern.compile(gobalRegexPatternString);
    private String stringTemplate;
    private ObjectInspector objectInspector;

    /**
     * This constructor takes an object inspector.
     *
     * @param objectInspector Object Inspector object.
     */
    protected SimpleMessageTemplate(ObjectInspector objectInspector) {
        this.objectInspector = objectInspector;
    }

    /**
     * This constructor takes an encoded string template and an object inspector.
     *
     * @param stringTemplate String representing the encoded template.
     * @param objectInspector ObjectInspector object.
     */
    public SimpleMessageTemplate(String stringTemplate, ObjectInspector objectInspector) {
        this.objectInspector = objectInspector;
        this.stringTemplate = stringTemplate;
    }

    /**
     * This method returns the formatted message containing information from the specified object.
     *
     * @param object Object representing the object to bind to the template.
     * @return String - Representing the formatted message.
     */
    public String getFormattedMessage(Object object) {
      stringTemplate = replaceGlobalMappings();
      return replaceComplexMappings(object);
    }

    /**
     * This method replaces any global (system property) variables in the template.
     *
     * @return String - Representing the template with globals replaced.
     */
    private String replaceGlobalMappings() {
      Matcher matcher = globalPattern.matcher(this.stringTemplate);
      StringBuffer sb = new StringBuffer();
      while (matcher.find()) {
        String propertyName = matcher.group(1);
        String value = System.getProperty(propertyName);
        if (value != null) {
          matcher.appendReplacement(sb, value);
        } else {
          matcher.appendReplacement(sb, "");
        }
      }

      matcher.appendTail(sb);
      return sb.toString();
    }

    /**
     * This method replaces any encoded variables in the template with information obtained from the specified object.
     *
     * @param object Object to be used to replace variables.
     * @return String - Representing the formatted message.
     */
    private String replaceComplexMappings(Object object) {
      Matcher matcher = complexTypePattern.matcher(this.stringTemplate);
      StringBuffer sb = new StringBuffer();
      while (matcher.find()) {
        String propertyName = matcher.group(1);
        if (!"?".equals(propertyName)) {
          Object property = getProperty(propertyName, object);
          if (property != null) {
            matcher.appendReplacement(sb, property.toString());
          } else {
            matcher.appendReplacement(sb, "");
          }
        } else {
          matcher.appendReplacement(sb, "");
          sb.append(object.toString());
        }
      }

      matcher.appendTail(sb);
      return sb.toString();
    }

    /**
     * This method retrieves the value of the property with the specified name in the specified object.
     *
     * @param propertyName String representing the property name.
     * @param object Object representing the object containing the property.
     * @return Object - Representing the value.
     */
    private Object getProperty(String propertyName, Object object) {
      try {
        return objectInspector.getAcessorValue(object, propertyName, false);
      } catch (NoSuchMethodException e) {
        throw new PropertyNotFoundException("Property not found: " + propertyName, e);
      } catch (IllegalAccessException e) {
        throw new PropertyNotFoundException("Property not found: " + propertyName, e);
      } catch (InvocationTargetException e) {
        throw new PropertyNotFoundException("Property not found: " + propertyName, e);
      } catch (IllegalArgumentException e) {
        throw new PropertyNotFoundException("Property not found: " + propertyName, e);
      }
    }

    /**
     * This method sets the string template.
     *
     * @param stringTemplate String representing the encoded template.
     */
    protected void setStringTemplate(String stringTemplate) {
        this.stringTemplate = stringTemplate;
    }
}
