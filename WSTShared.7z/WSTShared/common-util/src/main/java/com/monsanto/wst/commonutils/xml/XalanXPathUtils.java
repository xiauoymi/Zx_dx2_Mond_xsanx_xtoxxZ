package com.monsanto.wst.commonutils.xml;

import org.apache.commons.lang.StringUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 17, 2006
 * Time: 12:34:12 PM
 * <p/>
 * This is the Xalan implementation of the XPathUtils object.  It is used to provide a testable isolation layer around
 * Xpath commands.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XalanXPathUtils implements XPathUtils {

    /**
     * This method returns the node list that the specified expression evaluates to.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return NodeList - Object representing the results.
     */
    public NodeList selectNodeList(Node node, String expression) {
        try {
            return XPathAPI.selectNodeList(node, expression);
        } catch (TransformerException e) {
            throw new InvalidXPathException("The expression '" + expression + "' is not a valid xpath expression", e);
        }
    }

    /**
     * This method evaluates the specified expression to a string.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return String - Representing the result.
     */
    public String evalToString(Node node, String expression) {
        try {
            return XPathAPI.eval(node, expression).toString();
        } catch (TransformerException e) {
            throw new InvalidXPathException("The expression '" + expression + "' is not a valid xpath expression", e);
        }
    }

    /**
     * This method returns the node that the specified expression evaluates to.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return Node - Object representing the result.
     */
    public Node selectSingleNode(Node node, String expression) {
        try {
            return XPathAPI.selectSingleNode(node, expression);
        } catch (TransformerException e) {
            throw new InvalidXPathException("The expression '" + expression + "' is not a valid xpath expression", e);
        }
    }

    /**
     * This method evaluates the specified expression to an integer.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return Integer - Representing the result.
     */
    public Integer evalToInteger(Node node, String expression) {
        String value = evalToString(node, expression);
        if (StringUtils.isNotEmpty(value)) {
            return new Integer(value);
        }
        return null;
    }
}
