package com.monsanto.wst.commonutils;

import org.apache.commons.lang.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 8, 2006
 * Time: 10:19:52 AM
 * <p/>
 * This class is a utility class for defining methods for retrieving information about the current environment.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class EnvironmentUtils {
    /**
     * This method returns the environment variable with the specified name.
     *
     * @param variableName String representing the name of the environment variable.
     * @return String - Representing the value of the environment variable.
     * @throws IOException - If unable to access the environment.
     */
    public String getVariable(String variableName) throws IOException {
        if (StringUtils.isEmpty(variableName)) {
            throw new IllegalArgumentException("The environment variable name must not be empty or null.");
        }
        Runtime runtime = Runtime.getRuntime();
        Process p = runtime.exec( "cmd.exe /c set" );
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) {
            int idx = line.indexOf('=');
            String key = line.substring(0, idx);
            if (variableName.equalsIgnoreCase(key)) {
                return line.substring(idx + 1);
            }
        }
        throw new IllegalArgumentException("Unable to find a value for environment variable '" + variableName + "'.");
    }
}
