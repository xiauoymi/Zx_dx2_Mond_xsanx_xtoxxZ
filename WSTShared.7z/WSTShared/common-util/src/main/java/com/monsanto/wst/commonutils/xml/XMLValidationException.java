package com.monsanto.wst.commonutils.xml;

import org.apache.commons.lang.StringUtils;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 19, 2005
 * Time: 10:46:29 AM
 * <p/>
 * This class is a subclass of java.lang.Exception that is used to define XML validation errors.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLValidationException extends Exception {

    private List exceptionList = new ArrayList();
    private String xmlString;

    /**
     * Default no args constructor.
     */
    public XMLValidationException() {
        super();
    }

    /**
     * This constructor takes a message describing the error.
     *
     * @param message String representing the message.
     */
    public XMLValidationException(String message) {
        super(message);
    }

    /**
     * This constructor takes a message and a cause.
     *
     * @param message String representing the message.
     * @param cause Throwable object representing the cause of this exception.
     */
    public XMLValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * This constructor takes a message and a list of exceptions describing the validation errors.
     * @param message String representing the message.
     * @param exceptionList List object representing the validation errors.
     */
    public XMLValidationException(String message, List exceptionList) {
        super(message);
        this.exceptionList = exceptionList;
    }

    /**
     * This constructor takes the cause of this exception.
     *
     * @param cause Throwable object representing the cause of this exception.
     */
    public XMLValidationException(Throwable cause) {
        super(cause);
    }

    /**
     * This constructor takes a message and a string representing the invalid document.
     *
     * @param message String representing the message.
     * @param xmlString String representing the invalid xml document.
     */
    public XMLValidationException(String message, String xmlString) {
        super(message);
        this.xmlString = xmlString;
    }

    /**
     * This constructor takes a message, the cause of the exception and a string representing the invalid xml document.
     *
     * @param message String representing the message.
     * @param cause Throwable representing the cause of the exception.
     * @param xmlString String representing the invalid xml document.
     */
    public XMLValidationException(String message, Throwable cause, String xmlString) {
        super(message, cause);
        this.xmlString = xmlString;
    }

    /**
     * This constructor takes a message, a list of exceptions describing the validation errors and a string representing
     * the invalid xml document.
     *
     * @param message String representing the message.
     * @param exceptionList List object representing the validaton errors.
     * @param xmlString String representing the invalid xml document.
     */
    public XMLValidationException(String message, List exceptionList, String xmlString) {
        super(message);
        this.exceptionList = exceptionList;
        this.xmlString = xmlString;
    }

    /**
     * This constructor takes the cause of the exception and a string representing the invalid xml document.
     *
     * @param cause Throwable object representing the cause of the exception.
     * @param xmlString String representing the invalid xml document.
     */
    public XMLValidationException(Throwable cause, String xmlString) {
        super(cause);
        this.xmlString = xmlString;
    }

    /**
     * This method prints a stack trace of this exception and the exception list if specified.
     */
    public void printStackTrace() {
        super.printStackTrace();
        for(int i = 0; i < this.exceptionList.size(); i++) {
            Throwable t = (Throwable) this.exceptionList.get(i);
            t.printStackTrace();
        }
        if (StringUtils.isNotEmpty(this.xmlString)) {
            System.err.println("Invalid XML:\n" + this.xmlString);
        }
    }

    /**
     * This method prints a stack trace to the specified print stream of this exception and the exception list if
     * specified.
     *
     * @param s PrintStream object representing the print stream.
     */
    public void printStackTrace(PrintStream s) {
        super.printStackTrace(s);
        for(int i = 0; i < this.exceptionList.size(); i++) {
            Throwable t = (Throwable) this.exceptionList.get(i);
            t.printStackTrace(s);
        }
        if (StringUtils.isNotEmpty(this.xmlString)) {
            s.println("Invalid XML:\n" + this.xmlString);
        }
    }

    /**
     * This method prints the stack trace to the specified print writer of this exception and the exception list if
     * specified.
     *
     * @param s PrintWriter object representing the print writer.
     */
    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
        for(int i = 0; i < this.exceptionList.size(); i++) {
            Throwable t = (Throwable) this.exceptionList.get(i);
            t.printStackTrace(s);
        }
        if (StringUtils.isNotEmpty(this.xmlString)) {
            s.println("Invalid XML:\n" + this.xmlString);
        }
    }
}
