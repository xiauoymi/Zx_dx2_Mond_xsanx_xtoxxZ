package com.monsanto.wst.commonutils.reflection;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 10:07:37 AM
 * <p/>
 * This class uses reflection to perform various object inspection and invocation tasks.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectInspector {
    private static final Log log = LogFactory.getLog(ObjectInspector.class);

    /**
     * This method retrives the value of the field with the specified field name on the specified class.
     *
     * @param clazz Class object representing the class in which the field value is being retrieved from.
     * @param fieldName String representing the name of the field to retrieve the value of.
     * @return Object - Representing the value of the field.
     * @throws NoSuchFieldException - If unable to find the specified field name.
     * @throws IllegalAccessException - If unable to access the specified field name.
     */
    public Object getFieldValue(Class clazz, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        if (fieldName != null) {
            Field field = clazz.getField(fieldName);
            return field.get(clazz);
        }

        throw new NoSuchFieldException("There was no field name specified.");
    }

    /**
     * This method retrieves the value of the accessor at the specified path.  The accessor path represents the path
     * to the accessor using dot notation.
     *
     * ie. child.child.value = obj.getChild().getChild().getValue()
     *
     * @param obj Object representing the root object.
     * @param accessorPath String representing the path to the accessor.
     * @param overridePermissions boolean representing if permissions should be override to allow access to
     *  private/protected methods.
     * @return Object - Representing the value of the accessor.
     * @throws NoSuchMethodException - If unable to find one of the the accessors.
     * @throws IllegalAccessException - If unable to access one of the accessors.
     * @throws InvocationTargetException - If one of the accessors throw an exception.
     */
    public Object getAcessorValue(Object obj, String accessorPath, boolean overridePermissions)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        if (StringUtils.isNotEmpty(accessorPath)) {
            MethodProperties properties = this.getAccessor(accessorPath, obj, overridePermissions);
            return properties.invoke(null);
        }

        throw new NoSuchMethodException("There was no method name specified.");
    }

    /**
     * This method returns a method object representing the method on the specified object with the specified method
     * name.
     *
     * @param methodName String representing the name of the method.
     * @param clazz
     * @param types Class[] of types passed into the method.
     * @param overridePermissions
     * @return Method - Object representing the method.
     * @throws NoSuchMethodException - If the method does not exist on the object.
     */
    public Method getMethod(String methodName, Class clazz, Class[] types, boolean overridePermissions)
            throws NoSuchMethodException {
        if (overridePermissions) {
            return getProtectedMethod(clazz, methodName, types);
        }
        return clazz.getMethod(methodName, types);
    }

    /**
     * This method returns the constructor on the specified class that takes the specified types.
     *
     * @param clazz Class object representing the class with the constructor.
     * @param types Class[] representing the types passed into the constructor.
     * @return Constructor - Object representing the constructor.
     * @throws NoSuchMethodException - If the constructor can not be found.
     */
    public Constructor getConstructor(Class clazz, Class[] types) throws NoSuchMethodException {
        return clazz.getConstructor(types);
    }

    /**
     * This method returns a description of the accessor at the specified path.  The property path represents the path
     * to the accessor using dot notation.
     *
     * ie. child.child.value = obj.getChild().getChild().getValue()
     *
     * @param propertyPath String representing the path to the accessor.
     * @param obj Object representing the root object.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @return MethodProperties - Object describing the accessor.
     * @throws NoSuchMethodException - If unable to find one of the accessors.
     * @throws IllegalAccessException - If unable to access one of the accessors.
     * @throws InvocationTargetException - If unable to invoke of of the accessors.
     */
    public MethodProperties getAccessor(String propertyPath, Object obj, boolean overridePermissions)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        String[] propertyNames = propertyPath.split("\\.");
        Object parent = obj;
        for (int i = 0; i < propertyNames.length - 1; i++) {
            if (parent == null) {
                throw new IllegalArgumentException("One of the accessors in the property path returned a null object.");
            }
            MethodProperties properties = getAccessor(propertyNames[i], overridePermissions, parent);
            parent = properties.invoke(null);
        }
        if (parent == null) {
            throw new IllegalArgumentException("One of the accessors in the property path returned a null object.");
        }
        return getAccessor(propertyNames[propertyNames.length - 1], overridePermissions, parent);
    }

    /**
     * This method returns the accessor for the specified property on the specified object.
     *
     * @param propertyName String representing the property name, ie. get + PropertyName.
     * @param clazz Class representing the object the accessor belongs to.
     * @param overridePermissions boolean representing if permissions should be override to allow access to
     *  private/protected methods.
     * @return Method - Object representing the accessor.
     * @throws NoSuchMethodException - If the accessor does not exist on the object.
     */
    public Method getAccessor(String propertyName, Class clazz, boolean overridePermissions) throws NoSuchMethodException {

        String methodName = new StringBuffer("get").append(StringUtils.capitalize(propertyName)).toString();
        try {
            return getAccessorMethod(overridePermissions, clazz, methodName);
        } catch (NoSuchMethodException e) {
            methodName = new StringBuffer("is").append(StringUtils.capitalize(propertyName)).toString();
            try {
                return getAccessorMethod(overridePermissions, clazz, methodName);
            } catch (NoSuchMethodException e1) {
                return getAccessorMethod(overridePermissions, clazz, propertyName);
            }
        }
    }

    private Method getAccessorMethod(boolean overridePermissions, Class clazz, String propertyName) throws NoSuchMethodException {
        if (overridePermissions) {
            Method method = getProtectedMethod(clazz, propertyName, null);
            method.setAccessible(true);
            return method;
        }
        return clazz.getMethod(propertyName, null);
    }

    /**
     * This method returns the modifier for the specified property on the specified class.
     *
     * @param propertyName String representing the property name, ie. set + propertyName
     * @param clazz Class representing the class the modifier belongs to.
     * @param type Class representing the type of the property.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @return Method - Object representing the modifier.
     * @throws NoSuchMethodException - If unable to find the modifier.
     */
    public Method getModifier(String propertyName, Class clazz, Class type, boolean overridePermissions) throws NoSuchMethodException {
        if (propertyName.indexOf("set") == -1) {
            propertyName = new StringBuffer("set").append(StringUtils.capitalize(propertyName)).toString();
        }
        if (overridePermissions) {
            Method method = getProtectedMethod(clazz, propertyName, new Class[] { type });
            method.setAccessible(true);
            return method;
        }
        try {
            return clazz.getMethod(propertyName, new Class[] { type });
        } catch (NoSuchMethodException e) {
            if (log.isDebugEnabled()) {
                log.debug("Unable to find modifier: '" + propertyName + "' on object: '" + clazz.getName()
                        + "' that takes a type of: '" + type + "'.  Traversing the superclass heirarchy for the " +
                        "next applicable type.");
            }
            if (type.getSuperclass() != null) {
                return getModifier(propertyName, clazz, type.getSuperclass(), overridePermissions); //todo tail recurssion, eliminate this
            }
            throw e;
        }
    }

    /**
     * This method returns a description of the modifier represented by the specified property path.  The property path
     * is the path to the modifier using dot notation.
     *
     * ie. child.child.value = obj.getChild().getChild().setValue()
     *
     * Note: If one of the properties in the path's accessor returns null.  This method will try to instantiate the
     * object and call it's modifier in order to get to the target modifier.
     *
     * @param propertyPath String representing the path to the modifier.
     * @param obj Object representing the root object.
     * @param type Class representing the property type.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @return MethodProperties - Object describing the modifier.
     * @throws NoSuchMethodException - If unable to find one of the methods.
     * @throws IllegalAccessException - If unable to access one of the methods.
     * @throws InvocationTargetException - If unable to invoke one of the methods.
     */
    public MethodProperties getModifier(String propertyPath, Object obj, Class type, boolean overridePermissions)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        if (StringUtils.isEmpty(propertyPath)) {
            throw new IllegalArgumentException("The property path is required.");
        }
        if (obj != null) {
            String[] propertyNames = propertyPath.split("\\.");
            Object parent = obj;
            for (int i = 0; i < propertyNames.length - 1; i++) {
                MethodProperties properties = getAccessor(propertyNames[i], overridePermissions, parent);
                Object newParent = properties.invoke(null);
                if (newParent == null) {
                    newParent = properties.getReturnType().newInstance();
                    setValue(parent, propertyNames[i], newParent, overridePermissions);
                }
                parent = newParent;
            }
            return getModifier(propertyNames[propertyNames.length - 1], overridePermissions, parent, type);
        }
        throw new IllegalArgumentException("The parent object must not be null.");
    }

    /**
     * This method returns a list of available properties on the specified object.
     *
     * @param clazz Class object representing the class to retrieve properties from.
     * @param overridePermissions boolean representing if protected properties should be returned.
     * @return List - Of property names.
     */
    public List getPropertyNames(Class clazz, boolean overridePermissions) {
        List propertyList = new ArrayList();
        return getPropertyNames(clazz, propertyList, overridePermissions);
    }

    /**
     * This method sets the property at the given path.  The property path represents the path to the property using
     * dot notation.
     *
     * ie. child.child.value = obj.getChild().getChild().setValue()
     *
     * @param obj Object representing the root object.
     * @param propertyPath String representing the path to the property.
     * @param value Object representing the value to set the property to.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @throws IllegalAccessException - If unable access any of the methods.
     * @throws NoSuchMethodException - If unable to find any of the methods.
     * @throws InvocationTargetException - If unable to invoke any of the methods.
     */
    public void setValue(Object obj, String propertyPath, Object value, boolean overridePermissions)
            throws IllegalAccessException, NoSuchMethodException, InvocationTargetException, InstantiationException {
        if (StringUtils.isNotEmpty(propertyPath)) {
            MethodProperties properties = getModifier(propertyPath, obj, value.getClass(), overridePermissions);
            properties.invoke(new Object[] { value });
        } else {
            throw new NoSuchMethodException("There was no method/property name specified.");
        }
    }

    /**
     * This method returns the field with the specified name on the specified class.
     *
     * @param fieldName String representing the name of the field.
     * @param fieldClass Class representing the class the field exists on.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @return Field - Object representing the field.
     * @throws NoSuchFieldException - If unable to find the field.
     */
    public Field getField(String fieldName, Class fieldClass, boolean overridePermissions) throws NoSuchFieldException {
        if (overridePermissions) {
            try {
                Field field = fieldClass.getDeclaredField(fieldName);
                field.setAccessible(true);
                return field;
            } catch (NoSuchFieldException e) {
                if (fieldClass.getSuperclass() != null) {
                    return getField(fieldName, fieldClass.getSuperclass(), overridePermissions); //todo tail recurssion, eliminate this
                }
            }
        }
        return fieldClass.getField(fieldName);
    }

    public Map getPropertyFieldtoValueMap(Object o)throws IllegalAccessException, NoSuchMethodException, InvocationTargetException, InstantiationException{
        Map properties = new HashMap();
        if(o!=null){
            Class clazz  = o.getClass();
            Method[] method = clazz.getMethods();
            for(int i = 0;i<method.length;i++) {
                Method thisMethod = method[i];
                if(isFieldAccessorNoArgs(thisMethod)){
                    String methodName = thisMethod.getName();
                    String fieldName = extractFieldNameFromMethodName(methodName);
                    addPropertyValueToMap(thisMethod, o, fieldName, properties);
                }
            }
        }
        return properties;
    }


    public Map getPropertyFieldtoValueMap(Object o, Collection fieldNames, boolean ignoreIllegalArgExceptions)throws IllegalAccessException, NoSuchMethodException, InvocationTargetException, InstantiationException{
        if(fieldNames != null){
            Map fields = new HashMap();
            for (Iterator iterator = fieldNames.iterator(); iterator.hasNext();) {
                String fieldName = (String) iterator.next();
                Object value = null;
                try {
                    value = getAcessorValue(o,fieldName,false);
                } catch (IllegalArgumentException e) {
                    if(!ignoreIllegalArgExceptions){
                        throw e;
                    }
                }
                fields.put(fieldName, value);
            }
            return fields;
        }
        return getPropertyFieldtoValueMap(o);
    }

    /**
     * This method returns all constructors on the specified class.
     *
     * @param clazz Class to retrieve constructors from.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @return Constructor[] - Representing the constructors.
     */
    public Constructor[] getConstructors(Class clazz, boolean overridePermissions) {
        if (overridePermissions) {
            Constructor[] constructors = clazz.getDeclaredConstructors();
            for (int i = 0; i < constructors.length; i++) {
                constructors[i].setAccessible(true);
            }
            return constructors;
        }
        return clazz.getConstructors();
    }

    public Class getType(String name) throws ClassNotFoundException {
        if (boolean.class.getName().equals(name)) {
            return boolean.class;
        }
        if (int.class.getName().equals(name)) {
            return int.class;
        }
        if (long.class.getName().equals(name)) {
            return long.class;
        }
        if (short.class.getName().equals(name)) {
            return short.class;
        }
        if (float.class.getName().equals(name)) {
            return float.class;
        }
        if (double.class.getName().equals(name)) {
            return double.class;
        }
        if (byte.class.getName().equals(name)) {
            return byte.class;
        }
        if (char.class.getName().equals(name)) {
            return char.class;
        }
        return Class.forName(name);
    }

    private String extractFieldNameFromMethodName(String methodName) {
        if ( methodName.startsWith("get")) {
            return methodName.substring(3);
        } else if(methodName.startsWith("is")){
            return methodName.substring(2);
        }else{
            return null;
        }
    }

    private boolean isFieldAccessorNoArgs(Method method){
        return method.getParameterTypes().length == 0 && (method.getName().startsWith("get") || method.getName().startsWith("is"));
    }

    private void addPropertyValueToMap(Method thisMethod, Object o, String fieldName, Map properties)throws IllegalAccessException, InvocationTargetException {
        Object value = thisMethod.invoke(o,new Object[]{});
        properties.put(fieldName, value);
    }


    /**
     * This method overloads the getPropertyNames method to take a list of current properties to add to.
     *
     * @param clazz Class object representing the class to retrieve properties from.
     * @param propertyList List representing the current properties.
     * @param overridePermissions boolean representing if protected properties should be returned.
     * @return List - Representing the properties for the specified object.
     */
    private List getPropertyNames(Class clazz, List propertyList, boolean overridePermissions) {
        Field[] fields = new Field[] {};
        if (overridePermissions) {
            fields = clazz.getDeclaredFields();
            if (clazz.getSuperclass() != null) {
                Class superClass = clazz.getSuperclass();
                propertyList = getPropertyNames(superClass, propertyList, overridePermissions);
            }
        } else {
            fields = clazz.getFields();
        }
        extractFieldNamesToList(fields, propertyList);
        return propertyList;
    }

    /**
     * This method returns all field names in the specified array of Field objects as a list of strings.
     *
     * @param fields Field[]  containing field information.
     * @param propertyList - List containing the names of the properties.
     */
    private void extractFieldNamesToList(Field[] fields, List propertyList) {
        for (int i = 0 ; i < fields.length; i++) {
            propertyList.add(fields[i].getName());
        }
    }

    /**
     * This method returns the method with the specified name ignoring permissions.
     *
     * @param clazz Class the method belongs to.
     * @param name String representing the name of the method.
     * @param types Class[] representing the parameter types.
     * @return Method - Object representing the method.
     * @throws NoSuchMethodException - If unable to fine the method.
     */
    private Method getProtectedMethod(Class clazz, String name, Class[] types) throws NoSuchMethodException {
        try {
            Method method = clazz.getDeclaredMethod(name, types);
            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException e) {
            if (clazz.getSuperclass() != null) {
                return getProtectedMethod(clazz.getSuperclass(), name, types); //todo tail recurssion, eliminate this
            }
            throw e;
        }
    }

    /**
     * This method returns a description of the accessor with the specified property name.
     *
     * @param propertyName String representing the name of the property.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @param obj Object representing the object the property belongs to.
     * @return MethodProperties - Object describing the accessor.
     * @throws NoSuchMethodException - If unable to find the accessor.
     */
    private MethodProperties getAccessor(String propertyName, boolean overridePermissions, Object obj) throws NoSuchMethodException {
      MethodProperties result = null;
      if (obj instanceof Map) {
        result = getAccessorForMap((Map) obj, propertyName, overridePermissions);
      }

      if (result == null) {
        return new MethodProperties(obj, getAccessor(propertyName, obj.getClass(), overridePermissions));
      } else {
        return result;
      }
    }

  private MethodProperties getAccessorForMap(Map map, String propertyName, boolean overridePermissions) {
    Object obj = map.get(propertyName);
    if (obj == null) {
      return null;
    } else {
      return new MethodPropertiesForObject(obj);
    }
  }

  private static class MethodPropertiesForObject extends MethodProperties {
    private final Object obj;

    public MethodPropertiesForObject(Object obj) {
      super(null, null);
      this.obj = obj;
    }

    public Object invoke(Object[] arguments) {
      return obj;
    }

    public Class getReturnType() {
      return obj.getClass();
    }
  }

  /**
     * This method returns a description of the modifier for the specified property on the specified object.
     *
     * @param propertyName String representing the name of the property.
     * @param overridePermissions boolean representing if permissions should be ignored.
     * @param obj Object representing the object the property belongs to.
     * @param type Class representing the type of the property.
     * @return MethodProperties - Object representing a description of the modifier.
     * @throws NoSuchMethodException - If unable to find the modifier.
     */
    private MethodProperties getModifier(String propertyName, boolean overridePermissions, Object obj, Class type) throws NoSuchMethodException {
        return new MethodProperties(obj, getModifier(propertyName, obj.getClass(), type, overridePermissions));
    }
}
