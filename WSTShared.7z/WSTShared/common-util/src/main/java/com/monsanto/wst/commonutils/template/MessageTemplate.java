package com.monsanto.wst.commonutils.template;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 3:48:02 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface MessageTemplate {
  String getFormattedMessage(Object object);
}
