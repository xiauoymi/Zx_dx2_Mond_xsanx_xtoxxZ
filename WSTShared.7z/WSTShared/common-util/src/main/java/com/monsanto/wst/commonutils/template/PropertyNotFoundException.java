package com.monsanto.wst.commonutils.template;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 20, 2006
 * Time: 2:50:21 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PropertyNotFoundException extends RuntimeException {
  public PropertyNotFoundException() {
  }

  public PropertyNotFoundException(String message) {
    super(message);
  }

  public PropertyNotFoundException(Throwable cause) {
    super(cause);
  }

  public PropertyNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }
}
