package com.monsanto.wst.commonutils.xml;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 14, 2005
 * Time: 8:50:55 AM
 * <p/>
 * This class is a utilities class performing tasks on XML.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLUtilities {

    private static final String DEFAULT_XML_READER = "org.apache.xerces.parsers.SAXParser";
    private ResourceUtils resourceUtils;
    private String xmlReader;

    /**
     * This constructor takes a resource utiltity object and a custom xml reader.
     *
     * @param resourceUtils Object representing a resource utility object.
     */
    public XMLUtilities(ResourceUtils resourceUtils, String xmlReader) {
        this.resourceUtils = resourceUtils;
        this.xmlReader = xmlReader;
    }

    /**
     * This constructor takes a resource utils object and uses the default xml reader.
     *
     * @param resourceUtils Object representing a resource utility object.
     */
    public XMLUtilities(ResourceUtils resourceUtils) {
        this.resourceUtils = resourceUtils;
        this.xmlReader = DEFAULT_XML_READER;
    }

    /**
     * This method creates the document at the specified path.  The documentPath can be either a uri, a classpath or
     * a file path.
     *
     * Example:
     * uri = /WEB-INF/conf/config.xml
     * classpath = com/monsanto/someTeam/SomeApplication/somePackage/resources.xml
     * file = C:/MyFiles/file.xml
     *
     * @param documentPath String representing the document path.
     * @return Document - Object representing the document at the specified path.
     * @throws XMLParserException
     */
    public Document createDocument(String documentPath) throws XMLParserException {
        File file = null;
        try {
            file = this.resourceUtils.convertPathToFile(documentPath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = factory.newDocumentBuilder();
            return parser.parse(file);
        } catch (ParserConfigurationException e) {
            throw new XMLParserException("Unable to retrieve new parser.", e);
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse document.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to open or read file at path: '" + documentPath + "'", e);
        }
    }

    /**
     * This method creates a document from the specified input stream.
     *
     * @param in InputStream object representing the xml.
     * @return Document - Object representing the xml document.
     * @throws XMLParserException - If unable to parse input stream.
     */
    public Document createDocument(InputStream in) throws XMLParserException {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = factory.newDocumentBuilder();
            return parser.parse(in);
        } catch (ParserConfigurationException e) {
            throw new XMLParserException("Unable to retrieve new parser.", e);
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse input stream.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to open or read input stream", e);
        } catch (IllegalArgumentException e){
            throw new XMLParserException("Unable to open or read input stream", e);
        }
    }

    /**
     * This method creates a document from the specified node.
     *
     * @param node Node object that will become the root of a new document.
     * @return Document - Object representing the new xml document.
     * @throws XMLParserException - If unable to retrieve a new parser.
     */
    public Document createDocument(Node node) throws XMLParserException {
      if (node == null) return null;

          try {
              DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
              DocumentBuilder docBuilder = factory.newDocumentBuilder();
              Document newDoc = docBuilder.newDocument();
            synchronized(node) {
              Node newNode = newDoc.importNode(node, true);
              newDoc.appendChild(newNode);
              return newDoc;
            }
          } catch (ParserConfigurationException e) {
              throw new XMLParserException("Unable to retrieve new parser.", e);
          }
    }

    /**
     * This method returns the first element in the specified node with the specified element name.  Returns null if
     * no element could be found.
     *
     * @param node Node object repesenting the parent node.
     * @param elementName String representing the element name.
     * @return Element - Representing the requested element.
     */
    public Element getElementByTagName(Node node, String elementName) {
      if (node == null) return null;

      synchronized(node) {
        NodeList elementList = null;
        if (node instanceof Document) {
            Document doc = (Document) node;
            elementList = doc.getElementsByTagName(elementName);
        } else if (node instanceof Element) {
            Element element = (Element) node;
            elementList = element.getElementsByTagName(elementName);
        } else {
            return null;
        }

        if (elementList.getLength() > 0) {
            return (Element) elementList.item(0);
        }

        return null;
      }
    }

  /**
   * Returns an array of child nodes of this element.  Returns an empty array if the node is null or has no children.
   * NOTE: ** This uses an array of Node's instead of NodeList to avoid the concurrency problems we were having using NodeList.
   * @param node Node to report the children of
   * @return Node[] of children
   */
    public Node[] getChildNodes(Node node) {
      if (node == null) return new Node[0];
      List nodesList = new ArrayList();
      synchronized(node) {
        Node currNode = node.getFirstChild();
        while (currNode != null) {
          nodesList.add(currNode);
          currNode = currNode.getNextSibling();
        }
      }

      return (Node[]) nodesList.toArray(new Node[nodesList.size()]);
    }


  /**
   * This method returns the first element in the specified node (recursively) that has an attribute of the specified type equal to the specified value.
   * Returns null if no element could be found.
   *
   * @param parentNode Node object representing the parent node.
   * @param id String representing the element id.
   * @return Element - Object representing the requested element.
   */
  public Element getElementByAttributeValue(Node parentNode, String attribute, String value) {
    Node[] childNodes = getChildNodes(parentNode);

    for (int i = 0; i < childNodes.length; i++) {
      Node childNode = childNodes[i];
      if (childNode instanceof Element) {
        Element childElement = (Element) childNode;
        String attributeValue = childElement.getAttribute(attribute);

        Element result;
        if (value.equals(attributeValue)) {
          result = childElement;
        } else {
          result = getElementByAttributeValue(childElement, attribute, value);
        }

        if (result != null) {
          return result;
        }
      }
    }

    return null;
  }

    /**
     * This method returns the first element in the specified node that has an id attribute equal to the specified id.
     * Returns null if no element could be found.
     *
     * @param parentNode Node object representing the parent node.
     * @param id String representing the element id.
     * @return Element - Object representing the requested element.
     */
    public Element getElementById(Node parentNode, String id) {
      return getElementByAttributeValue(parentNode, "id", id);
    }

    /**
     * This method validates the document at the specified path with the specified schema namespace with the specified
     * schema.  The document path can be either a uri, a classpath or a file path.
     *
     * Example:
     * uri = /WEB-INF/conf/config.xml
     * classpath = com/monsanto/someTeam/SomeApplication/somePackage/resources.xml
     * file = C:/MyFiles/file.xml
     *
     * @param documentPath String representing the path to the document.
     * @param schemaNamespace String representing the schema's namespace.
     * @param schemaURL URL object representing the location of the schema.
     * @throws XMLValidationException - If the document fails validation.
     * @throws XMLParserException - If unable to open or parse the document.
     */
    public void validateAgainstSchema(String documentPath, String schemaNamespace, URL schemaURL) throws XMLValidationException, XMLParserException {
        try {
            File documentFile = this.resourceUtils.convertPathToFile(documentPath);
            final XMLReader parser = XMLReaderFactory.createXMLReader(this.xmlReader);
            final XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();
            parser.setErrorHandler(errorHandler);

            parser.setFeature("http://xml.org/sax/features/validation", true);
            parser.setFeature("http://apache.org/xml/features/validation/schema", true);
            parser.setFeature("http://xml.org/sax/features/namespaces", true);
            parser.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            parser.setFeature("http://apache.org/xml/features/validation/dynamic", false);
            parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", schemaNamespace +
                    " " + schemaURL.getPath());

            parser.parse(documentFile.getAbsolutePath());

            if (errorHandler.getErrors().size() > 0) {
                throw new XMLValidationException("XML is invalid according to scheam.", errorHandler.getErrors());
            }
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse xml, schema or both.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to access xml, schema or both.", e);
        }
    }

    /**
     * This method validates the document at the specified path with the specified schema namespace with the specified
     * schema.  The document and schema path can be either a uri, a classpath or a file path.
     *
     * Example:
     * uri = /WEB-INF/conf/config.xml
     * classpath = com/monsanto/someTeam/SomeApplication/somePackage/resources.xml
     * file = C:/MyFiles/file.xml
     *
     * @param documentPath String representing the path to the document.
     * @param schemaNamespace String representing the schema's namespace.
     * @param schemaPath String representing the path to the schema.
     * @throws XMLValidationException - If the document fails validation.
     * @throws XMLParserException - If unable to open or parse the document.
     */
    public void validateAgainstSchema(String documentPath, String schemaNamespace, String schemaPath) throws XMLValidationException, XMLParserException {
        try {
            URL schemaURL = this.resourceUtils.convertPathToURL(schemaPath);
            validateAgainstSchema(documentPath, schemaNamespace, schemaURL);
        } catch (IOException e) {
            throw new XMLParserException("Unable to access xml, schema or both.", e);
        }
    }

    /**
     * This method validates the specified document input stream with the specified namespace and schema.
     *
     * @param in InputStream object representing the xml document.
     * @param schemaNamespace String representing the schema namespace.
     * @param schemaURL URL representing the schema.
     * @throws XMLValidationException - If there are validation issues with the xml document.
     * @throws XMLParserException - If unable to parse the xml document.
     */
    public void validateAgainstSchema(InputStream in, String schemaNamespace, URL schemaURL)
            throws XMLValidationException, XMLParserException {
        try {
            final XMLReader parser = XMLReaderFactory.createXMLReader(this.xmlReader);
            final XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();
            parser.setErrorHandler(errorHandler);

            InputSource source = new InputSource(in);
            parser.setFeature("http://xml.org/sax/features/validation", true);
            parser.setFeature("http://apache.org/xml/features/validation/schema", true);
            parser.setFeature("http://xml.org/sax/features/namespaces", true);
            parser.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            parser.setFeature("http://apache.org/xml/features/validation/dynamic", false);
            parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", schemaNamespace +
                    " " + schemaURL.getPath());

            parser.parse(source);

            if (errorHandler.getErrors().size() > 0) {
                throw new XMLValidationException("XML is invalid according to scheam.", errorHandler.getErrors());
            }
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse xml, schema or both.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to access xml, schema or both.", e);
        }
    }

    /**
     * This method validates the specified document input stream with the specified namespace and schema.
     *
     * @param in InputStream object representing the xml document.
     * @param schemaNamespace String representing the schema namespace.
     * @param schemaURL External URL representing the schema.
     * @throws XMLValidationException - If there are validation issues with the xml document.
     * @throws XMLParserException - If unable to parse the xml document.
     */
    public void validateAgainstExternalSchema(InputStream in, String schemaNamespace,String schemaURL)
            throws XMLValidationException, XMLParserException {
        try {
            final XMLReader parser = XMLReaderFactory.createXMLReader(this.xmlReader);
            final XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();
            parser.setErrorHandler(errorHandler);

            InputSource source = new InputSource(in);
            parser.setFeature("http://xml.org/sax/features/validation", true);
            parser.setFeature("http://apache.org/xml/features/validation/schema", true);
            parser.setFeature("http://xml.org/sax/features/namespaces", true);
            parser.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            parser.setFeature("http://apache.org/xml/features/validation/dynamic", false);
            parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", schemaNamespace +
                    " " + schemaURL);

            parser.parse(source);

            if (errorHandler.getErrors().size() > 0) {
                throw new XMLValidationException("XML is invalid according to scheam.", errorHandler.getErrors());
            }
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse xml, schema or both.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to access xml, schema or both.", e);
        }
    }

    /**
     * This method validates the specified document against the specified namespace and schema.
     *
     * @param doc Document object representing the xml document.
     * @param schemaNamespace String representing the schema namespace.
     * @param schemaURL URL representing the schema.
     * @throws XMLValidationException - If there are validation issues with the xml document.
     * @throws XMLParserException - If unable to parse the xml document.
     */
    public void validateAgainstSchema(Document doc, String schemaNamespace, URL schemaURL)
            throws XMLValidationException, XMLParserException {
      synchronized(doc) {
        try {
            final XMLReader parser = XMLReaderFactory.createXMLReader(this.xmlReader);
            final XMLValidationErrorHandler errorHandler = new XMLValidationErrorHandler();
            parser.setErrorHandler(errorHandler);

            InputSource source = new InputSource(new StringReader(getFormattedXMLString(doc)));
            parser.setFeature("http://xml.org/sax/features/validation", true);
            parser.setFeature("http://apache.org/xml/features/validation/schema", true);
            parser.setFeature("http://xml.org/sax/features/namespaces", true);
            parser.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
            parser.setFeature("http://apache.org/xml/features/validation/dynamic", false);
            parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", schemaNamespace +
                    " " + schemaURL.getPath());

            parser.parse(source);

            if (errorHandler.getErrors().size() > 0) {
                throw new XMLValidationException("XML is invalid according to schema.", errorHandler.getErrors(), getFormattedXMLString(doc));
            }
        } catch (SAXException e) {
            throw new XMLParserException("Unable to parse xml, schema or both.", e);
        } catch (IOException e) {
            throw new XMLParserException("Unable to access xml, schema or both.", e);
        }
      }
    }

    /**
     * This method writes to specified document to the specified path.  The path can be either a uri, a classpath or a
     * file path.
     *
     * Example:
     * uri = /WEB-INF/conf/config.xml
     * classpath = com/monsanto/someTeam/SomeApplication/somePackage/resources.xml
     * file = C:/MyFiles/file.xml
     *
     * @param doc Document object representing the document you wish to write to the file system.
     * @param filePath String representing the path to the file.
     * @throws XMLParserException - If there is an exception when transforming the document.
     * @throws FileNotFoundException - If unable to find the specified document.
     * @throws IOException - If unable to write to the file at the specified path.
     */
    public void writeDocumentToFile(Document doc, String filePath)
            throws XMLParserException, FileNotFoundException, IOException {
      synchronized(doc) {
        ByteArrayOutputStream out = null;
        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            out = new ByteArrayOutputStream();
            transformer.transform(new DOMSource(doc), new StreamResult(out));
            File file = this.resourceUtils.convertPathToFile(filePath);
            FileOutputStream fileOut = new FileOutputStream(file);
            fileOut.write(out.toByteArray());
            fileOut.flush();
            fileOut.close();
        } catch (TransformerConfigurationException e) {
            throw new XMLParserException("Unable to create new transformer.", e);
        } catch (TransformerException e) {
            throw new XMLParserException("Unable to convert xml document into output stream.", e);
        } finally {
            closeFile(out);
        }
      }
    }

    /**
     * This method closes the specified output stream.
     *
     * @param out OutputStream object representing the output stream you wish to close.
     */
    private void closeFile(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException e) {
            }
        }
    }

    /**
     * This method returns a string representing the formatted XML of the specified document.
     *
     * @param doc Document object representing the xml.
     * @return String - Representing the formatted xml.
     * @throws XMLParserException - If unable to parse the xml document.
     */
    public String getFormattedXMLString(Node doc) throws XMLParserException {
      synchronized(doc) {
        StringWriter writer = new StringWriter();

        try {
            final Source source = new DOMSource(doc);
            final Result result = new StreamResult(writer);
            final TransformerFactory tf = TransformerFactory.newInstance();
            final Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
        } catch (TransformerConfigurationException e) {
            throw new XMLParserException("Unable to transform xml to string.", e);
        } catch (TransformerException e) {
            throw new XMLParserException("Unable to transform xml to string.", e);
        }

        String result = writer.getBuffer().toString();
        return result.trim();
      }
    }

    /**
     * This method returns the element with the specified name attribute.
     *
     * @param parentNode Node object representing the parent node.
     * @param name String representing the name attribute value.
     * @return Element - Representing the element with the specified name attribute.
     */
    public Element getElementByNameAttribute(Node parentNode, String name) {
      return getElementByAttributeValue(parentNode, "name", name);
    }
  
    /**
     * This method creates a new empty Document object.
     *
     * @return Document - Object representing the document created.
     * @throws XMLParserException - If unable to create a new document.
     */
    public Document createDocument() throws XMLParserException {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = factory.newDocumentBuilder();
            return parser.newDocument();
        } catch (ParserConfigurationException e) {
            throw new XMLParserException("Unable to create a new document.", e);
        }
    }

    /**
     * This method removes all child nodes descending from the specified node.
     *
     * @param node Node object representing the parent node.
     */
    public void removeAllChildren(Node node) {
      synchronized(node) {
        while (node.hasChildNodes()) {
            Node childNode = node.getLastChild();
            node.removeChild(childNode);
        }
      }
    }

    /**
     * This method removes all the nodes in the specified node list from their parents.  WARNING: this will remove
     * any children of those nodes as well.
     *
     * @param nodeList NodeList object representing the nodes to be removed.
     */
    public void removeAll(NodeList nodeList) {
      synchronized(nodeList) {
        for (int i = nodeList.getLength() - 1; i > -1; i--) {
            Node node = nodeList.item(i);
            node.getParentNode().removeChild(node);
        }
      }
    }
}
