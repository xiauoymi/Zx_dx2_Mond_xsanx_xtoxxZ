package com.monsanto.wst.commonutils.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 3:11:22 PM
 * <p/>
 * This object wraps a method providing a context to execute from.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MethodProperties {
    private Object context;
    private Method method;

    /**
     * This constructor takes a method and it's context.
     *
     * @param context Object representing the context of the method.
     * @param method Method object representing the method.
     */
    public MethodProperties(Object context, Method method) {
        this.context = context;
        this.method = method;
    }

    /**
     * This method invokes the wrapped method with the specified arguments.
     *
     * @param arguments Object[] representing the method arguments.
     * @return Object - Representing the result of the method.
     * @throws IllegalAccessException - If unable to access the method.
     * @throws InvocationTargetException - If unable to invoke the method.
     */
    public Object invoke(Object[] arguments) throws IllegalAccessException, InvocationTargetException {
        return this.method.invoke(this.context, arguments);
    }

    /**
     * This method returns the return type of the wrapped method.
     *
     * @return Class - Object representing the return type.
     */
    public Class getReturnType() {
        return this.method.getReturnType();
    }
}
