package com.monsanto.wst.commonutils.testutils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 23, 2006
 * Time: 8:19:08 AM
 * <p/>
 * This object represents the results of testing a java bean object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JavaBeanTestResults {
    private Map testResultMap = new HashMap();
    int numValidProperties = 0;

    /**
     * Default no args constructor.
     */
    public JavaBeanTestResults() {
    }

    /**
     * This method adds a test result to this object.
     *
     * @param propertyName String representing the name of the property tested.
     * @param testResult boolean representing the whether the test succeeded.
     */
    public void addResult(String propertyName, boolean testResult) {
        this.testResultMap.put(propertyName, new Boolean(testResult));
        if (testResult) {
            numValidProperties++;
        }
    }

    /**
     * This method returns the test result for the specified property.
     *
     * @param propertyName String representing the name of the property.
     * @return boolean - Representing the result of the test.
     */
    public boolean getResult(String propertyName) {
        Boolean result = (Boolean) this.testResultMap.get(propertyName);
        if (result != null) {
            return result.booleanValue();
        }
        return false;
    }

    /**
     * This method returns the the combined result for all tests.
     *
     * @deprecated Use getNumValidProperties() instead, which returns the number of valid and tested properties.
     * @return boolean - Representing the combined result.
     */
    public boolean getCombinedResult() {
        List values = new ArrayList(this.testResultMap.values());
        for (int i = 0; i < values.size(); i++) {
            boolean result = ((Boolean) values.get(i)).booleanValue();
            if (!result) {
                return false;
            }
        }
        return true;
    }

    /**
     * This method return the number of test results added.
     *
     * @deprecated Use getNumValidProperties() instead, which returns the number of valid and tested properties.
     * @return int - Representing the number of test results.
     */
    public int getNumResults() {
        return this.testResultMap.size();
    }

    /**
     * This method returns the number of valid properties in the tested object.
     *
     * @return int - Representing the number of valid properties.
     */
    public int getNumValidProperties() {
        return this.numValidProperties;
    }
}
