package com.monsanto.wst.commonutils.properties;

import org.w3c.dom.Element;

import java.util.Properties;
import java.util.Map;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
/*
 PlatformProperties was created on May 20, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class PlatformProperties extends Properties {
  public PlatformProperties(Properties baseProp, String appName) {
    this(baseProp, appName, "password");
  }

  public PlatformProperties(Properties baseProp, String appName, String passwordProperty) {
    for (Map.Entry<Object, Object> entry : new PropertyPlatformLocalizer().getLocalizedProperties(baseProp).entrySet()) {
      String key = safeToString(entry.getKey());
      String value = safeToString(entry.getValue());
      super.setProperty(key, value);
    }
    setPasswordFromEncryptedFiles(appName, passwordProperty);
  }

  public synchronized Object setProperty(String key, String value) {
    throw new RuntimeException("Platform-specific properties are immutable");
  }

  protected String getPrefix() {
    return new PropertyPlatformLocalizer().getPrefix();
  }

  private static String safeToString(Object obj) {
    //todo move this to some string util method
    if (obj == null) {
      return null;
    } else {
      return obj.toString();
    }
  }

  private void setPasswordFromEncryptedFiles(String applicationFolder, String passwordProperty) {
    String envVar  = "MONCRYPTJV";
    String cipherHexPath = "CipherValue.hex";
    String keyHexPath = "KeyValue.hex";
    try {
      String password = EncryptionUtils.GetDecryptedStringFromExternalStorage(envVar, applicationFolder, cipherHexPath, keyHexPath);
      super.setProperty(passwordProperty, password);
    } catch (EncryptorException e) {
      throw new RuntimeException("Unable to decrypt the encryption password.  Unable to access the database.", e);
    }
  }
}

