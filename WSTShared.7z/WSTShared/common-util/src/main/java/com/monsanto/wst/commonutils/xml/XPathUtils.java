package com.monsanto.wst.commonutils.xml;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created by IntelliJ IDEA.
 * Date: Jul 17, 2006
 * Time: 12:51:32 PM
 * <p/>
 * This interface defines the contract for some XPath utility methods.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface XPathUtils {

    /**
     * This method returns the node list that the specified expression evaluates to.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return NodeList - Object representing the results.
     */
    NodeList selectNodeList(Node node, String expression);

    /**
     * This method evaluates the specified expression to a string.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return String - Representing the result.
     */
    String evalToString(Node node, String expression);

    /**
     * This method returns the node that the specified expression evaluates to.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return Node - Object representing the result.
     */
    Node selectSingleNode(Node node, String expression);

    /**
     * This method evaluates the specified expression to an integer.
     *
     * @param node Node object representing the parent element.
     * @param expression String representing the xpath expression.
     * @return Integer - Representing the result.
     */
    Integer evalToInteger(Node node, String expression);
}
