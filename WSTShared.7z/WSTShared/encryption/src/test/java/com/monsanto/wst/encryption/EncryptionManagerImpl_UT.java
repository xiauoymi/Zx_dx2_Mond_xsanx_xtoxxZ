package com.monsanto.wst.encryption;

import com.monsanto.wst.encryption.mock.MockEncryptorDecryptorFactory;
import com.monsanto.wst.encryption.mock.MockKeySource;
import junit.framework.TestCase;

import java.security.Key;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class EncryptionManagerImpl_UT extends TestCase {
    private MockKeySource publicSource;
    private MockKeySource privateSource;
    private EncryptionManager encryption;
    private EncryptorDecryptorFactory factory;

    protected void setUp() throws Exception {
        super.setUp();
        publicSource = new MockKeySource();
        privateSource = new MockKeySource();
        factory = new MockEncryptorDecryptorFactory();
        encryption = new EncryptionManagerImpl(publicSource, privateSource, factory);
    }

    public void testEncryptSomething_DefaultEncryptionKeyFromPublicAndNothingFromPrivate() {
        encryption.encrypt("Something");

        assertTrue(publicSource.wasPreferredCalled());
        assertFalse(privateSource.wasPreferredCalled());
        assertEquals(MockKeySource.NO_KEY_LOOKED_UP, privateSource.getLastKeyLookedUp());
    }

    public void testDecryptSomething_SpecifiedPrivateKeyUsed() {
        long testId1 = 1234L;
        encryption.decrypt(new EncryptedValue(testId1, "Something1".getBytes()));
        assertFalse(privateSource.wasPreferredCalled());
        assertEquals(testId1, privateSource.getLastKeyLookedUp());

        long testId2 = 4555L;
        encryption.decrypt(new EncryptedValue(testId2, "Something2".getBytes()));
        assertFalse(privateSource.wasPreferredCalled());
        assertEquals(testId2, privateSource.getLastKeyLookedUp());
    }

    public void testEncryptDecrypt_BackToStart() {
        String testString = "This is my test String\n\nTesting 1.2.3.\n\"\n";
        EncryptedValue encryptedValue = encryption.encrypt(testString);
        assertNotNull(encryptedValue);
        String decryptedString = encryption.decrypt(encryptedValue);
        assertEquals(testString, decryptedString);
    }

    public void testErrorOnDecrypt_ReturnsErrorMessageInsteadOfValue() {
        KeySource errorKeySource = new MockKeySourceForErrorOnGetKey();
        EncryptionManager encryptionForError = new EncryptionManagerImpl(publicSource, errorKeySource, factory);
        String decryptValue = encryptionForError.decrypt(encryption.encrypt("Test"));
        assertContains("ERROR", decryptValue);
    }

    public void testNoKey_ReturnsErrorMessageInsteadOfValue() {
        KeySource noKeySource = new MockKeySourceForNoKey();
        EncryptionManager encryptionForNoKey = new EncryptionManagerImpl(publicSource, noKeySource, factory);
        String decryptValue = encryptionForNoKey.decrypt(encryption.encrypt("Test"));
        assertContains("ERROR", decryptValue);
    }

    private void assertContains(String expectedSubstring, String fullString) {
        assertNotNull("Expected to find '" + expectedSubstring + "' but was null", fullString);
        assertTrue("Expected to find '" + expectedSubstring + "' but found: " + fullString, fullString.contains(expectedSubstring));
    }

    private static class MockKeySourceForErrorOnGetKey implements KeySource {
        public Key getPreferredKey() {
            throw new RuntimeException("Couldn't find a key");
        }

        public Key getKey(long id) {
            throw new RuntimeException("Couldn't find a key");
        }

        public void store(long id, Key key) {
        }
    }

    private static class MockKeySourceForNoKey implements KeySource {
        public Key getPreferredKey() {
            return null;
        }

        public Key getKey(long id) {
            return null;
        }

        public void store(long id, Key key) {
        }
    }

}