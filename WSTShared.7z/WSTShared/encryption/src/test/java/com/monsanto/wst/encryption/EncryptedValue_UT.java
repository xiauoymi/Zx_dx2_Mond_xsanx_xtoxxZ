package com.monsanto.wst.encryption;

import junit.framework.TestCase;

import java.util.Arrays;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class EncryptedValue_UT extends TestCase {
    public void testEncryptedValue_GettersReturnValuePassedIn() {
        long testKey = 1L;
        byte[] testData = {1, 2, 3, 4};
        EncryptedValue encryptedValue = new EncryptedValue(testKey, testData);
        assertEquals(testKey, encryptedValue.getKeyId());
        assertTrue(Arrays.equals(testData, encryptedValue.getCipherText()));
    }
}