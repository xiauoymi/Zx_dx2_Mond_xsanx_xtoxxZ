package com.monsanto.wst.encryption.mock;

import com.monsanto.wst.encryption.Decryptor;

public class MockDecryptor implements Decryptor {
    public long getId() {
        return 1L;
    }

    public String decrypt(byte[] cipherText) {
        byte[] arr = new byte[cipherText.length];
        for (int i = 0; i < cipherText.length; i++) {
            arr[i] = (byte) (cipherText[i] - 1);
        }

        return new String(arr);
    }
}
