package com.monsanto.wst.encryption.mock;

import com.monsanto.wst.encryption.EncryptedValue;
import com.monsanto.wst.encryption.EncryptionManager;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockEncryptionManager implements EncryptionManager {
    public EncryptedValue encrypt(String value) {
        return new EncryptedValue(0, value.getBytes());
    }

    public String decrypt(EncryptedValue value) {
        return new String(value.getCipherText());
    }
}
