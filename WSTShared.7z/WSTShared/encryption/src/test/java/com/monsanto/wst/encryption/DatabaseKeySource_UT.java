package com.monsanto.wst.encryption;

import com.monsanto.AbstractLogging.NotificationSource;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.dataservices.Test.MockConnection;
import com.monsanto.dataservices.Test.QueryMap;
import com.monsanto.dbdataservices.PersistentStoreDBObjectResultSetForwardIterator;
import com.monsanto.dbdataservices.PersistentStoreDBResultSetFwdIterator;
import com.monsanto.dbdataservices.PersistentStoreDBResultSetSingleResult;
import com.monsanto.wst.encryption.mock.MockKey;
import com.monsanto.wst.encryption.mock.MockKeyTranslator;
import com.monsanto.wst.encryption.mock.MockResultSet;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.security.Key;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DatabaseKeySource_UT extends TestCase {
    private static final String TEST_TABLE_NAME = "TTS.ENCRYPTION_KEYS";

    public void testStoreKey_InsertIsCalled() {
        MockDBConnection conn = new MockDBConnection();
        KeySource keyStore = new DatabaseKeySource(conn, TEST_TABLE_NAME, new MockKeyTranslator());
        Key testKey = new MockKey(1L);
        assertEquals(0, conn.getInsertCount());
        keyStore.store(1L, testKey);
        assertEquals(1, conn.getInsertCount());
    }

    public void testGetPreferredKey_QueryIsCalled() {
        MockDBConnection conn = new MockDBConnection();
        KeySource keyStore = new DatabaseKeySource(conn, TEST_TABLE_NAME, new MockKeyTranslator());
        assertEquals(0, conn.getQueryCount());
        keyStore.getPreferredKey();
        assertTrue(conn.getQueryCount() >= 1);
    }

    public void testGetKey_QueryIsCalled() {
        MockDBConnection conn = new MockDBConnection();
        KeySource keyStore = new DatabaseKeySource(conn, TEST_TABLE_NAME, new MockKeyTranslator());
        assertEquals(0, conn.getQueryCount());
        keyStore.getKey(1L);
        assertEquals(1, conn.getQueryCount());
    }

    private static class MockDBConnection extends MockConnection {
        private int insertCount = 0;
        private int queryCount = 0;

        public int executeInsert(String s) throws WrappingException {
            insertCount++;
            return super.executeInsert(s);
        }

        public int executeInsert(String s, int i) throws WrappingException, OperationTimeoutException {
            insertCount++;
            return super.executeInsert(s, i);
        }

        public int executeInsert(String s, int i, NotificationSource notificationSource, String s1) throws WrappingException {
            insertCount++;
            return super.executeInsert(s, i, notificationSource, s1);
        }

        public PersistentStoreResultSet executeQuery(String s) throws WrappingException {
            queryCount++;
            return new MockPersistentStoreResultSet();
        }

        public PersistentStoreResultSet executeQuery(String s, int i) throws WrappingException, OperationTimeoutException {
            queryCount++;
            return new MockPersistentStoreResultSet();
        }

        public PersistentStoreResultSet executeQuery(String s, int i, NotificationSource notificationSource, String s1) throws WrappingException {
            queryCount++;
            return new MockPersistentStoreResultSet();
        }

        public PersistentStoreStatement prepareStatement(String s) throws WrappingException {
            return new MockPersistentStoreStatement(s);
        }

        public int getInsertCount() {
            return insertCount;
        }

        public int getQueryCount() {
            return queryCount;
        }

        private class MockPersistentStoreStatement extends com.monsanto.dataservices.Test.MockPersistentStoreStatement {
            public MockPersistentStoreStatement(String s) {
                super(s);
            }

            public MockPersistentStoreStatement(String s, QueryMap queryMap) {
                super(s, queryMap);
            }

            public int executeInsert() throws WrappingException {
                insertCount++;
                return 1;
            }

            public PersistentStoreResultSet executeQuery() throws WrappingException {
                queryCount++;
                return new MockPersistentStoreResultSet();
            }

            public PersistentStoreResultSet executeQuery(int i) throws WrappingException {
                queryCount++;
                return new MockPersistentStoreResultSet();
            }
        }


        private class MockPersistentStoreResultSet implements PersistentStoreResultSet {
            public PersistentStoreResultSetSingleResult getSingleResult() throws EmptyResultSetException, WrappingException {
                return new PersistentStoreDBResultSetSingleResult(new MockResultSet());
            }

            public PersistentStoreResultSetFwdIterator getForwardIterator() throws WrappingException {
                return new PersistentStoreDBResultSetFwdIterator(new MockResultSet());
            }

            public PersistentStoreObjectResultSetForwardIterator getObjectIterator() {
                return new PersistentStoreDBObjectResultSetForwardIterator(new MockResultSet());
            }

            public Document toXML() throws WrappingException {
                return null;
            }

            public void close() {
            }

            public String[] getColumnNames() throws WrappingException {
                return new String[0];
            }

            public int getColumnCount() throws WrappingException {
                return 0;
            }

            public int[] getColumnTypes() throws WrappingException {
                return new int[0];
            }
        }

    }

}