package com.monsanto.wst.encryption.mock;

import com.monsanto.wst.encryption.KeyTranslator;

import java.security.Key;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockKeyTranslator implements KeyTranslator {
    public Key stringToKey(String keyString) {
        try {
            return new MockKey(Long.parseLong(keyString));
        } catch (NumberFormatException IGNORE) {
            return new MockKey(1L);
        }
    }

    public String keyToString(Key key) {
        return key.getAlgorithm();
    }
}
