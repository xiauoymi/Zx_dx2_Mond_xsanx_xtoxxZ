package com.monsanto.wst.encryption;

import com.monsanto.wst.encryption.mock.MockKey;
import com.monsanto.wst.encryption.mock.MockKeyTranslator;
import junit.framework.TestCase;

import java.security.Key;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class FileKeySource_UT extends TestCase {
    private static final String TEST_MONCRYPT_DIR = "";
    private String priorMonCryptJV;

    protected void setUp() throws Exception {
        super.setUp();
        priorMonCryptJV = System.getProperty(FileKeySource.SYS_PROPERTY_NAME);
        System.setProperty(FileKeySource.SYS_PROPERTY_NAME, TEST_MONCRYPT_DIR);
    }

    protected void tearDown() throws Exception {
        if (priorMonCryptJV != null) {
            System.setProperty(FileKeySource.SYS_PROPERTY_NAME, priorMonCryptJV);
        }
        super.tearDown();
    }

    public void testMONCRYPTJVNotSetThrowsException() {
        System.setProperty(FileKeySource.SYS_PROPERTY_NAME, "");
        try {
            KeySource fileSource = new FileKeySource(new MockKeyTranslator(), "testDir");
            fileSource.getPreferredKey();
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            //ignore expected exception
        }
    }

    public void testStoreKey_FileIsCreated() {
        MockKeyDirectory keyDir = new MockKeyDirectory();
        KeySource fileSource = new FileKeySource(new MockKeyTranslator(), keyDir);
        Key mockKey = new MockKey(3333L);
        fileSource.store(3L, mockKey);
        assertEquals("3333", keyDir.getFileContents("key-3.key"));
        assertEquals("3", keyDir.getFileContents(FileKeySource.PREFERRED_KEY_CONFIG_FILE));
    }

    public void testGetPreferredKey_PreferredFileIsRead() {
        KeySource fileSource = new FileKeySource(new MockKeyTranslator(), new MockKeyDirectory());
        Key key = fileSource.getPreferredKey();
        assertNotNull(key);
        assertEquals("1", key.getAlgorithm());
    }

    public void testGetKey_FileIsRead() {
        KeySource fileSource = new FileKeySource(new MockKeyTranslator(), new MockKeyDirectory());

        Key key1 = fileSource.getKey(1L);
        assertNotNull(key1);
        assertEquals("1", key1.getAlgorithm());

        Key key2 = fileSource.getKey(2L);
        assertNotNull(key2);
        assertEquals("222", key2.getAlgorithm());
    }

    private static class MockKeyDirectory implements KeyDirectory {
        private final Map<String, String> values;

        private MockKeyDirectory() {
            values = new HashMap<String, String>();
            values.put("key-1.key", "1");
            values.put("key-2.key", "222");
            values.put(FileKeySource.PREFERRED_KEY_CONFIG_FILE, "1");
        }

        public String getFileContents(String filename) {
            return values.get(filename);
        }

        public void setFileContents(String filename, String contents) {
            values.put(filename, contents);
        }
    }
}