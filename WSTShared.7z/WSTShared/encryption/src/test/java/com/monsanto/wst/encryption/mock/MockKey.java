package com.monsanto.wst.encryption.mock;

import java.security.Key;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockKey implements Key {
    private final long id;

    public MockKey(long id) {
        this.id = id;
    }

    public String getAlgorithm() {
        return Long.toString(id);
    }

    public String getFormat() {
        return "MOCK";
    }

    public byte[] getEncoded() {
        return "MOCK".getBytes();
    }
}
