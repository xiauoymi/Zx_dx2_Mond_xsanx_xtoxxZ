package com.monsanto.wst.encryption.mock;

import com.monsanto.wst.encryption.Encryptor;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockEncryptor implements Encryptor {
    public long getId() {
        return 1L;
    }

    public byte[] encrypt(String plainText) {
        byte[] arr = plainText.getBytes();
        for (int i = 0; i < arr.length; i++) {
            arr[i] += 1;
        }

        return arr;
    }
}

