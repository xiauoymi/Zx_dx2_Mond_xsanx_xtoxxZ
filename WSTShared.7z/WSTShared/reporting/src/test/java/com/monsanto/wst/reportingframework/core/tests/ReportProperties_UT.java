package com.monsanto.wst.reportingframework.core.tests;

import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: May 19, 2006
 * Time: 3:56:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReportProperties_UT extends TestCase {

  private static final String TEST_REPORT_NAME_WITH_EXTENSION = "testReport.xml";
  private static final String TEST_REPORT_NAME_WITH_NO_EXTENSION = "testReport";
  private static final String TEST_REPORT_WITH_NO_EXPORT_TO_EXCEL = "testReportWithoutExport";
  private static final String DUMMY_REPORT_NAME = "dummyReport";

  public void testNonExistentParseXmlFile() throws Exception {
    try {
      ReportProperties reportProperties = new ReportProperties(DUMMY_REPORT_NAME);
      fail("Report XML not found, Exception should have been thrown");
    } catch (ReportException e) {
      assertEquals("Invalid Input Document",e.getErrorMsg());
    }
  }

  public void testParseXMLFileWithExtensionThrowsException() throws Exception {
    try {
      ReportProperties reportProperties = new ReportProperties(TEST_REPORT_NAME_WITH_EXTENSION);
      fail("FileName had extension, Exception should have been thrown");
    } catch (ReportException e) {
      assertEquals("Invalid Input Document",e.getErrorMsg());
    }
  }

  public void testParseXMLFileWithoutExtensionThrowsNoException() throws Exception {
    try {
      ReportProperties reportProperties = new ReportProperties(TEST_REPORT_NAME_WITH_NO_EXTENSION);
    } catch (ReportException e) {
      assertFalse(true);
    }
  }

  public void testParseXMLFileAndCheckAttributes() throws Exception {
    ReportProperties reportProperties = new ReportProperties(TEST_REPORT_NAME_WITH_NO_EXTENSION);
    assertEquals("/Stylesheet/reportOptions.xsl",reportProperties.getFilterXSL());
    assertEquals("com.monsanto.wst.reportingframework.controller.testutils.TestReportData",reportProperties.getFilterClass());
    assertEquals("Test Report", reportProperties.getReportName());
    assertEquals("com.monsanto.wst.reportingframework.controller.testutils.TestReportData",reportProperties.getReportClass());
    assertEquals("/Stylesheet/reportMain.xsl",reportProperties.getReportXSL());
    assertEquals(2,reportProperties.getExportList().size());
    assertEquals("/Stylesheet/wordExport.xsl",reportProperties.getExportXSL(ReportingFrameworkConstants.EXPORT_TYPE_WORD));
    assertEquals("/Stylesheet/excelExport.xsl",reportProperties.getExportXSL(ReportingFrameworkConstants.EXPORT_TYPE_EXCEL));
    assertEquals("Regular Final Report Excel",reportProperties.getExportFileName());
  }

  public void testNoExportXSLDefinedForExportType() throws Exception {
    try {
      ReportProperties reportProperties = new ReportProperties(TEST_REPORT_WITH_NO_EXPORT_TO_EXCEL);
      reportProperties.getExportXSL("EXCEL");
      fail("Report Exception should have been thrown");
    } catch (ReportException e) {
      assertEquals("Export XSL not defined for export type",e.getErrorMsg());
    }
  }

}
