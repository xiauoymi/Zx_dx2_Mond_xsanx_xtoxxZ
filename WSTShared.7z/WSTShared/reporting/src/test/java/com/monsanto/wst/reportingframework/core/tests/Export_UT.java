package com.monsanto.wst.reportingframework.core.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.core.Export;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: May 19, 2006
 * Time: 4:06:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class Export_UT extends TestCase {
    private static final String TEST_RESOURCE_PATH = "src\\test\\resources\\";

  public void testTemporary() throws Exception {
    //todo there are path issues in tests that need to resolved, and then the tests re-enabled
  }


/*
    public void testBuildWORDExportParamters() throws Exception {
        Document exportDoc = DOMUtil.newDocument
                (TEST_RESOURCE_PATH + "com\\monsanto\\wst\\reportingframework\\xmlresources\\testreport.xml");
        NodeList exportNodes = exportDoc.getElementsByTagName(ReportingFrameworkConstants.EXPORT);
        Node wordExportNode = exportNodes.item(0);
        Export export = new Export(wordExportNode);
        assertEquals("WORD",export.getType());
        assertEquals("Regular Final Report Word",export.getExportFileName());
        assertEquals("/Stylesheet/wordExport.xsl",export.getXslPath());
    }
*/

/*
    public void testBuildEXCELExportParamters() throws Exception {
        Document exportDoc = DOMUtil.newDocument
                (TEST_RESOURCE_PATH + "com\\monsanto\\wst\\reportingframework\\xmlresources\\testreport.xml");
        NodeList exportNodes = exportDoc.getElementsByTagName(ReportingFrameworkConstants.EXPORT);
        Node wordExportNode = exportNodes.item(1);
        Export export = new Export(wordExportNode);
        assertEquals("EXCEL",export.getType());
        assertEquals("Regular Final Report Excel",export.getExportFileName());
        assertEquals("/Stylesheet/excelExport.xsl",export.getXslPath());
    }
*/
}
