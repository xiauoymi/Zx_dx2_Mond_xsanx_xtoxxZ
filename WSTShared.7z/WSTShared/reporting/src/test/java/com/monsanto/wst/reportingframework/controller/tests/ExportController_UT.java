/*
CreateReportController_UT was created on Jun 11, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.reportingframework.controller.ExportController;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import junit.framework.TestCase;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Filename:    $RCSfile: ExportController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-03-10 17:48:41 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class ExportController_UT extends TestCase{

  public void testExportController_ApplyStyleSheet_CheckResults() throws Exception {
    ExportController exportController = new MockExportController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"testReport");
    helper.setRequestParameterValue(ReportingFrameworkConstants.EXPORT_TYPE,ReportingFrameworkConstants.EXPORT_TYPE_WORD);
    exportController.run(helper);
    String response = helper.getResponse();
    System.out.println(response);
    assertTrue(response.indexOf("<h4>datacontentone</h4>")>=0);
  }

  public void testDifferentExceptionsExceptReportExceptions() throws Exception {
    ExportController exportController = new ExportController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"testReportException");
    helper.setRequestParameterValue(ReportingFrameworkConstants.EXPORT_TYPE,ReportingFrameworkConstants.EXPORT_TYPE_WORD);
    exportController.run(helper);
    String response = helper.getResponse();
    assertTrue(response.indexOf("<STACK_TRACE>java.lang.ClassNotFoundException: com.monsanto.wst.reportingframework.controller.testutils.TestReportDataNoClass")>0);
  }

  public void testDifferentExceptions_ReportException_NoExportToExcelDefined() throws Exception {
    ExportController exportController = new ExportController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"testReportWithoutExport");
    helper.setRequestParameterValue(ReportingFrameworkConstants.EXPORT_TYPE,ReportingFrameworkConstants.EXPORT_TYPE_WORD);
    exportController.run(helper);
    String response = helper.getResponse();
//    System.out.println(response);
    assertTrue(response.indexOf("<STACK_TRACE>java.io.FileNotFoundException: \\Stylesheet\\wordExport.xsl (The system cannot find the path specified)")>0);
  }

  public class MockExportController extends ExportController{

    protected String getExportXSL(ReportProperties reportProperties, String exportType) throws ReportException {
      String pathToSource="";
      ResourceUtils resourceUtils = new ResourceUtils();
      try {
        URL url = resourceUtils.convertPathToURL("com\\monsanto\\wst\\reportingFramework\\xmlResources\\testReport.xml");
        String path = url.getFile();
        int indexOfSource = path.indexOf("target");
        pathToSource = path.substring(1,indexOfSource);
//        System.out.println("path to source :"+pathToSource);
      } catch (MalformedURLException e) {
        e.printStackTrace();
      }
      return pathToSource+"\\src\\main\\resources\\com\\monsanto\\wst\\reportingframework\\stylesheets\\reportMain.xsl";
//      return "com\\monsanto\\wst\\reportingFramework\\stylesheets\\reportMain.xsl";
//      return "com/monsanto/wst/reportingFramework/stylesheets/reportMain.xsl";
    }
  }
}