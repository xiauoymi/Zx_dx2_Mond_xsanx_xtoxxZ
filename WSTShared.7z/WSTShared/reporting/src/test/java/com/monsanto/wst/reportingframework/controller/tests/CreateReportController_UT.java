/*
 CreateReportController_UT was created on Jun 11, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.reportingframework.controller.CreateReportController;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import junit.framework.TestCase;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Filename:    $RCSfile: CreateReportController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-03-10 17:48:41 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class CreateReportController_UT extends TestCase{

  public void testCreateReportController() throws Exception {
    CreateReportController createReportController = new MockCreateReportController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"testReport");
    createReportController.run(helper);
    String response = helper.getResponse();
//    System.out.println(response);
    assertTrue(response.indexOf("<h4>datacontentone</h4>")>=0);
  }

  public class MockCreateReportController extends CreateReportController{
    protected String getReportXSL(ReportProperties reportProperties) {
      String pathToSource="";
      ResourceUtils resourceUtils = new ResourceUtils();
      try {
        URL url = resourceUtils.convertPathToURL("com\\monsanto\\wst\\reportingFramework\\xmlResources\\testReport.xml");
        String path = url.getFile();
        int indexOfSource = path.indexOf("target");
        pathToSource = path.substring(1,indexOfSource);
      } catch (MalformedURLException e) {
        e.printStackTrace();
      }
      return pathToSource+"\\src\\main\\resources\\com\\monsanto\\wst\\reportingframework\\stylesheets\\reportMain.xsl";
//      return pathToSource+"\\Source\\Stylesheet\\reportMain.xsl";
    }
  }

}