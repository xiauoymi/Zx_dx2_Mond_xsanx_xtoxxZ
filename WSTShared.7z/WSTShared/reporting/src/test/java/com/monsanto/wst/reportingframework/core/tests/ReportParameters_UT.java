/*
ReportParameters_UT was created on May 22, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.core.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ReportParameters_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-04-11 19:37:59 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public class ReportParameters_UT extends TestCase{

    public void testReportParameters_AddRequestParameters_RetrieveSameParamter() throws Exception {
        MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
        mockUCCHelper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"closingReport");
        ReportParameters reportParameters = new ReportParameters(mockUCCHelper);
        String requestedReport = (String) reportParameters.getReportParameter(ReportingFrameworkConstants.REQUESTED_REPORT);

        assertEquals("closingReport",requestedReport);
    }

    public void testReportParameters_AddSessionParameters_RetrieveSameParamter() throws Exception {
        MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
        mockUCCHelper.setSessionParameter(ReportingFrameworkConstants.REQUESTED_REPORT,"closingReport");
        ReportParameters reportParameters = new ReportParameters(mockUCCHelper);
        String requestedReport = (String) reportParameters.getReportParameter(ReportingFrameworkConstants.REQUESTED_REPORT);

        assertEquals("closingReport",requestedReport);
    }

    public void testInitializeReportParameters() throws Exception {
        ReportParameters reportParameters = new ReportParameters();
        String key="parameter";
        Object value="value";
        reportParameters.add(key,value);
        Object reportParameter = reportParameters.getReportParameter(key);
        assertEquals("value",reportParameter.toString());
    }
}