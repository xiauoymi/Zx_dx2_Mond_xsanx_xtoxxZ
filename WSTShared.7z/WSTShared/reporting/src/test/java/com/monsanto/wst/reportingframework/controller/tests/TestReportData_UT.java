/*
 TestReportData_UT was created on May 25, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.controller.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.controller.testutils.TestReportData;
import junit.framework.TestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: TestReportData_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-03-10 17:48:41 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class TestReportData_UT extends TestCase{

  public void testTestReportData() throws Exception {
    TestReportData testReportData = new TestReportData();
    Document document = testReportData.buildReportXML(null,null);
//    DOMUtil.outputXML(document);
  }
}