/*
CreateReportController_UT was created on Jun 11, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.reportingframework.controller.GenerateReportOptions;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import com.monsanto.wst.reportingframework.utils.xmlUtil.PathUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: GenerateReportOptions_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-03-10 17:48:41 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class GenerateReportOptions_UT extends TestCase{
  public void testTemporary() throws Exception {
    //todo testGenerateReportOptions has path issues, and needs to be fixed and re-enabled
  }


/*
  public void testGenerateReportOptions() throws Exception {
        GenerateReportOptions createReportController = new MockGenerateReportOptions();
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT,"testReport");
        createReportController.run(helper);
        String response = helper.getResponse();
        System.out.println(response);
        assertTrue(response.indexOf("<h4>optionelementone</h4>")>=0);
    }
*/

    public class MockGenerateReportOptions extends GenerateReportOptions{
        protected String getReportXSL(ReportProperties reportProperties) {
            String pathToSource = PathUtil.getAbsolutePath("com\\monsanto\\wst\\reportingFramework\\xmlResources\\testReport.xml");
          return pathToSource+"src/main/resources/com/monsanto/wst/reportingframework/stylesheets/reportMain.xsl";
//            return pathToSource+"\\Source\\Stylesheet\\reportOptions.xsl";
        }
    }
}