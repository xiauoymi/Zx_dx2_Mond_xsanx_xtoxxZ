package com.monsanto.wst.reportingframework.controller;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 28, 2005
 * Time: 9:41:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateReportController extends ReportController implements UseCaseController{

    protected Document getXML(AbstractReport report, ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException {
        Document outputDocument=null;
        outputDocument = report.buildReportXML(reportParameters, reportProperties);
        return outputDocument;
    }

    protected String getReportXSL(ReportProperties reportProperties) {
        String reportXSL = reportProperties.getReportXSL();
        return reportXSL;
    }

}
