package com.monsanto.wst.reportingframework.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 28, 2005
 * Time: 9:41:25 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ReportController implements UseCaseController{

    public void run(UCCHelper helper) throws IOException {
        String selectedReport = (String) helper.getRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT);
        ReportProperties reportProperties=null;
        Document outputDocument=null;
        try{
            reportProperties = new ReportProperties(selectedReport);
            AbstractReport report = (AbstractReport) Class.forName(reportProperties.getReportClass().toString()).newInstance();
            ReportParameters reportParameters = new ReportParameters();
            addRequestParameterValues(helper, reportParameters);
            addSessionVariables(helper, reportParameters);
            helper.setSessionParameter(ReportingFrameworkConstants.REPORT_PARAMETERS,reportParameters);
            outputDocument = getXML(report, reportParameters, reportProperties);
//            DOMUtil.outputXML(outputDocument);
        }catch(Exception e){
            e.printStackTrace();
        }
        helper.applyStylesheet(outputDocument,getReportXSL(reportProperties));
    }

    protected abstract Document getXML(AbstractReport report, ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException ;

    protected abstract String getReportXSL(ReportProperties reportProperties);

    private void addRequestParameterValues(UCCHelper uccHelper, ReportParameters reportParameters) throws IOException {
        Enumeration parameterNames = uccHelper.getParameterNames();
        while(parameterNames.hasMoreElements()){
            String key = (String) parameterNames.nextElement();
            reportParameters.add(key,uccHelper.getRequestParameterValue(key));
        }
    }

    private void addSessionVariables(UCCHelper uccHelper, ReportParameters reportParameters) throws IOException {
        Iterator iterator = uccHelper.getSessionParameterNames();
        while(iterator.hasNext()){
            String sessionParameter = (String) iterator.next();
            Object sessionObject = uccHelper.getSessionParameter(sessionParameter);
            reportParameters.add(sessionParameter,sessionObject);
        }
    }
}
