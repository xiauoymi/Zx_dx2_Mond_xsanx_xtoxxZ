package com.monsanto.wst.reportingframework.utils.xmlUtil;

import com.monsanto.AbstractLogging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: May 18, 2006
 * Time: 11:16:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportingFrameworkDOMUtil {

    public static Element addCDATAChildElement(Node parent, String cstrChildElementName, String cstrText) {
        Logger.traceEntry();
        Element childElement;
        final Document doc = parent.getNodeType() == Node.DOCUMENT_NODE ? (Document) parent : parent.getOwnerDocument();
        childElement = doc.createElement(cstrChildElementName);
        parent.appendChild(childElement);

        if (cstrText != null) {
            final Text textNode = doc.createCDATASection(cstrText);
            childElement.appendChild(textNode);
        }

        return (Element) Logger.traceExit(childElement);
    }

}
