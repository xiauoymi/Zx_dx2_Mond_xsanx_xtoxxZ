package com.monsanto.wst.reportingframework.core;


import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 22, 2005
 * Time: 10:03:22 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractReport {

    public abstract Document buildReportXML(ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException ;

    public abstract Document buildFilterXML(ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException;

    public abstract String returnExportFileNameKey();
}