/*
TestReportData was created on May 25, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.controller.testutils;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Filename:    $RCSfile: TestReportData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-04-11 19:37:59 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class TestReportData extends AbstractReport{
  public Document buildReportXML(ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException {
    Document document = DOMUtil.newDocument();
    Element element = DOMUtil.addChildElement(document,"testreport");
    DOMUtil.addChildElement(element,"dataelementone","datacontentone");
    return document;
  }

  public Document buildFilterXML(ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException {
    Document document = DOMUtil.newDocument();
    Element element = DOMUtil.addChildElement(document,"testreport");
    DOMUtil.addChildElement(element,"optionelementone","optionelementone");
    return document;
  }

  public String returnExportFileNameKey() {
    return null;
  }
}