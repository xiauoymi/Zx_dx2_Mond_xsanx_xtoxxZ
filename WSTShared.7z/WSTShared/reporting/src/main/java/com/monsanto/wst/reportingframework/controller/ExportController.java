package com.monsanto.wst.reportingframework.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.Exceptions.ExceptionAsXML;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.core.ReportingFrameworkConstants;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 28, 2005
 * Time: 9:41:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportController implements UseCaseController{

  public void run(UCCHelper helper) throws IOException {
    ExceptionAsXML exceptionAsXML = new ExceptionAsXML();
    String selectedReport = (String) helper.getRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT);
    ReportProperties reportProperties=null;
    Document outputDocument=null;
    AbstractReport abstractReport = null;
    ReportParameters reportParameters = (ReportParameters) helper.getSessionParameter(ReportingFrameworkConstants.REPORT_PARAMETERS);
    try {
      reportProperties = new ReportProperties(selectedReport);
      String reportClassString = reportProperties.getReportClass();
      Class reportClass = Class.forName(reportClassString.toString());
      Object reportClassInstance = reportClass.newInstance();
      abstractReport = (AbstractReport) reportClassInstance;
      outputDocument = abstractReport.buildReportXML(reportParameters, reportProperties);
      String exportType = (String) helper.getRequestParameterValue(ReportingFrameworkConstants.EXPORT_TYPE);
      createExportDocumentBasedOnSelection(exportType, reportProperties, helper, outputDocument);
      DOMUtil.outputXML(outputDocument);
    }catch (ReportException e) {
      Logger.log(new LoggableError("Error exporting, Stack Trace..."));
      Logger.log(new LoggableError(e));
      outputDocument = exceptionAsXML.addExceptionAsXML(null,-1,null);
    } catch (Exception e) {
      outputDocument = exceptionAsXML.addExceptionAsXML(null, -1, e);
      helper.writeXMLDocument(outputDocument);
    }
  }

  private void createExportDocumentBasedOnSelection(String exportType, ReportProperties reportProperties,
                                                    UCCHelper helper, Document outputDocument) throws IOException,
      ReportException {
    if(exportType.equalsIgnoreCase(ReportingFrameworkConstants.EXPORT_TYPE_WORD)){
      helper.writeToWord(outputDocument,getExportXSL(reportProperties, exportType));
    }
    if(exportType.equalsIgnoreCase(ReportingFrameworkConstants.EXPORT_TYPE_EXCEL)){
      helper.writeToExcel(outputDocument, getExportXSL(reportProperties, exportType));
    }
  }

  protected String getExportXSL(ReportProperties reportProperties, String exportType) throws ReportException {
    return reportProperties.getExportXSL(exportType);
  }
}
