package com.monsanto.wst.reportingframework.core;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: May 18, 2006
 * Time: 10:57:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportingFrameworkConstants {

  public static final String REQUESTED_REPORT = "reporting_framework_requested_report";
   public static final String REPORT_OPTIONS_TAG = "reportOptions";

   public static final String EXPORT_TYPE = "exporttype";
   public static final String EXPORT = "export";
   public static final String EXPORT_TYPE_WORD = "WORD";
   public static final String EXPORT_TYPE_EXCEL = "EXCEL";
   public static final String WORDING = "wording";
   public static final String REPORT_PARAMETERS = "reportParameters";
   public static final String REPORT_ACTION_FILENAME = "actionname";

   public static final String TYPE = "type";
   public static final String EXPORT_XSL = "exportxsl";
   public static final String EXPORT_FILE_NAME = "exportFileName";
   public static final String XML_RESOURCE_PATH = "com/monsanto/wst/reportingframework/xmlResources/";
   public static final String MAIN_REPORT_HEADER = "name";
   public static final String FILTEROPTIONS = "filterOptions";
   public static final String XSL = "xsl";
   public static final String FILTERCLASS = "filterClass";
   public static final String REPORTCLASS = "reportClass";

   public static final String WORD_EXTENSION = ".doc";
   public static final String EXCEL_EXTENSION = ".xls";
   public static final String XML_EXTENSION = ".xml";

   public static final String EXPORT_WORD_TEXT = "Export To Word";
   public static final String EXPORT_EXCEL_TEXT = "Export To Excel";
}
