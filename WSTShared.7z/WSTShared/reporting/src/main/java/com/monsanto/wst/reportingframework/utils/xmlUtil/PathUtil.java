/*
 PathUtil was created on Jun 27, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.reportingframework.utils.xmlUtil;

import com.monsanto.wst.commonutils.resources.ResourceUtils;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Filename:    $RCSfile: PathUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-03-10 17:48:41 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class PathUtil {
  public static String getAbsolutePath(String pathToConvert) {
    String pathToSource="";
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      URL url = resourceUtils.convertPathToURL(pathToConvert);
      String path = url.getFile();
      int indexOfSource = path.indexOf("target");
      pathToSource = path.substring(1,indexOfSource);
      System.out.println("path to source :"+pathToSource);
    } catch (MalformedURLException e) {
      e.printStackTrace();
    }
    return pathToSource;
  }
}