package com.monsanto.wst.reportingframework.core;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 22, 2005
 * Time: 10:16:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportParameters {

    private Map reportParameters;

    //TODO Remove this constructor
    public ReportParameters(UCCHelper uccHelper) throws IOException {
        reportParameters = new HashMap();
        addRequestParameterValues(uccHelper);
        addSessionVariables(uccHelper);
    }

    public ReportParameters() {
        reportParameters = new HashMap();
    }

    private void addSessionVariables(UCCHelper uccHelper) throws IOException {
        Iterator iterator = uccHelper.getSessionParameterNames();
        while(iterator.hasNext()){
            String sessionParameter = (String) iterator.next();
            Object sessionObject = uccHelper.getSessionParameter(sessionParameter);
            reportParameters.put(sessionParameter,sessionObject);
        }
    }

    private void addRequestParameterValues(UCCHelper uccHelper) throws IOException {
        Enumeration parameterNames = uccHelper.getParameterNames();
        while(parameterNames.hasMoreElements()){
            String key = (String) parameterNames.nextElement();
            reportParameters.put(key,uccHelper.getRequestParameterValue(key));
        }
    }

    public Object getReportParameter(String reportParameter){
        return reportParameters.get(reportParameter);
    }

    public void add(String key, Object value) {
        reportParameters.put(key,value);
    }
}
