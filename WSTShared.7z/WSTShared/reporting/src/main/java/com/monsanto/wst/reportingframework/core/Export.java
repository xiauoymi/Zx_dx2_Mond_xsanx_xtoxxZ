package com.monsanto.wst.reportingframework.core;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Dec 8, 2005
 * Time: 4:12:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class Export {

    private String type;
    private String xslPath;
    private String exportFileName;

    public Export(Node node){
        NodeList childNodes = node.getChildNodes();
        for(int i=0;i<childNodes.getLength();i++){
            Node currentNode = childNodes.item(i);

            if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.TYPE)){
                type=DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.EXPORT_XSL)){
                xslPath=DOMUtil.getTextValue(currentNode);
            }
            if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.EXPORT_FILE_NAME)){
                exportFileName = DOMUtil.getTextValue(currentNode);
            }
        }
    }

    public String getType() {
        return type;
    }

    public String getXslPath() {
        return xslPath;
    }

    public String getExportFileName() {
        return exportFileName;
    }
}
