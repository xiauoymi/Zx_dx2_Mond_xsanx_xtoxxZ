package com.monsanto.wst.reportingframework.core;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Nov 9, 2005
 * Time: 9:51:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportProperties {

  //TODO Change this name
  private Document typeXmlDom;
  private String reportName;
  private String xmlFileName;
  private String filterXSL;
  private String filterClass;
  private String reportXSL;
  private String reportClass;
  private List exportList = new ArrayList();
  private String exportFileName = "";


  public ReportProperties(String xmlFileName) throws IOException, ReportException {
    this.xmlFileName = ReportingFrameworkConstants.XML_RESOURCE_PATH + xmlFileName + ReportingFrameworkConstants.XML_EXTENSION;
    parseXmlFile();
  }

  private void parseXmlFile() throws ReportException, IOException {
    ClassLoader classLoader = ReportProperties.class.getClassLoader();
    InputStream inputStream = classLoader.getResourceAsStream(xmlFileName);
    createDocument(inputStream);
    getReportNameFromDocument();
    buildReportFilterOptionParameters();
    buildMainReportParameters();
  }

  private void buildReportFilterOptionParameters() {
    NodeList nodeList = typeXmlDom.getElementsByTagName(ReportingFrameworkConstants.FILTEROPTIONS);
    Node firstFilterNode = nodeList.item(0);
    NodeList filterNodes = firstFilterNode.getChildNodes();
    for(int i=0;i<filterNodes.getLength();i++){
      Node currentNode = filterNodes.item(i);
      if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.XSL)){
        getStyleSheetForFilterOptions(currentNode);
      }
      if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.FILTERCLASS)){
        getClassForBuildingFilters(currentNode);
      }
    }
  }

  private void getClassForBuildingFilters(Node currentNode) {
    filterClass = DOMUtil.getTextValue(currentNode);
  }

  private void getStyleSheetForFilterOptions(Node currentNode) {
    filterXSL = DOMUtil.getTextValue(currentNode);
  }

  private void buildMainReportParameters() {
    NodeList nodeListONe = typeXmlDom.getElementsByTagName(ReportingFrameworkConstants.REPORT_OPTIONS_TAG);
    Node firstReportNode = nodeListONe.item(0);
    NodeList reportNodes = firstReportNode.getChildNodes();
    for(int i=0;i<reportNodes.getLength();i++){
      Node currentNode = reportNodes.item(i);
      if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.XSL)){
        getStyleSheetForMainReport(currentNode);
      }
      if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.REPORTCLASS)){
        getClassForBuildingMainReport(currentNode);
      }
      if(currentNode.getNodeName().equalsIgnoreCase(ReportingFrameworkConstants.EXPORT)){
        buildExportTypes(currentNode);
      }
    }
  }

  private void buildExportTypes(Node currentNode) {
    Export export = new Export(currentNode);
    exportFileName = export.getExportFileName();
    exportList.add(export);
  }

  private void getClassForBuildingMainReport(Node currentNode) {
    reportClass = DOMUtil.getTextValue(currentNode);
  }

  private void getStyleSheetForMainReport(Node currentNode) {
    reportXSL = DOMUtil.getTextValue(currentNode);
  }

  private void getReportNameFromDocument() {
    NodeList reportNodeNameList = typeXmlDom.getElementsByTagName(ReportingFrameworkConstants.MAIN_REPORT_HEADER);
    Node reportNode = reportNodeNameList.item(0);
    reportName = DOMUtil.getTextValue(reportNode);
  }

  private void createDocument(InputStream inputStream) throws ReportException, IOException {
    try {
      typeXmlDom = DOMUtil.newDocument(inputStream);
    } catch (SAXException e) {
      throw new ReportException("Invalid Input Document");
    }
  }

  public String getFilterXSL() {
    return filterXSL;
  }

  public String getFilterClass() {
    return filterClass;
  }

  public String getReportXSL() {
    return reportXSL;
  }

  public String getReportClass() {
    return reportClass;
  }

  public String getExportXSL(String exportType) throws ReportException {
    Iterator iterator = exportList.iterator();
    while(iterator.hasNext()){
      Export export = (Export) iterator.next();
      if(exportType.equalsIgnoreCase(export.getType())){
        return export.getXslPath();
      }
    }
    throw new ReportException("Export XSL not defined for export type");
  }

  public List getExportList() {
    return exportList;
  }

  public String getReportName() {
    return reportName;
  }

  public String getExportFileName() {
    return exportFileName;
  }
}
