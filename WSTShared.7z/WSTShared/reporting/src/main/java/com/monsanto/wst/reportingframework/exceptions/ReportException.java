package com.monsanto.wst.reportingframework.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: May 18, 2006
 * Time: 10:42:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportException extends Exception{

    String errorMsg;

    public ReportException(Exception e){
		super(e.getMessage());
		System.out.println("Error occured during xml operation: " + e.getMessage());
	}

    public ReportException(String errorMsg){
        this.errorMsg=errorMsg;
	}

    public String getErrorMsg() {
        return errorMsg;
    }

}
