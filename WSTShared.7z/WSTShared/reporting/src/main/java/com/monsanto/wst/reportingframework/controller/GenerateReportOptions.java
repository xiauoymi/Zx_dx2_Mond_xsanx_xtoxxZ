package com.monsanto.wst.reportingframework.controller;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 28, 2005
 * Time: 9:41:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenerateReportOptions extends ReportController implements UseCaseController{
//    public void run(UCCHelper helper) throws IOException {
//        ReportProperties reportProperties=null;
//        String selectedReport = helper.getRequestParameterValue(ReportingFrameworkConstants.REQUESTED_REPORT);
//        try {
//            helper.setRequestAttributeValue(ReportingFrameworkConstants.REQUESTED_REPORT, selectedReport);
//            reportProperties = new ReportProperties(selectedReport);
//            AbstractReport abstractReportFilterOptions = (AbstractReport) Class.forName(reportProperties.getFilterClass().toString()).newInstance();
//            Document outputDocument = abstractReportFilterOptions.buildFilterXML(new ReportParameters(helper), reportProperties);
//            DOMUtil.outputXML(outputDocument);
//            String filterXSL = getFilterXSL(reportProperties);
//            helper.applyStylesheet(outputDocument,filterXSL);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    protected String getFilterXSL(ReportProperties reportProperties) {
//        String filterXSL = reportProperties.getFilterXSL();
//        return filterXSL;
//    }
    protected Document getXML(AbstractReport report, ReportParameters reportParameters, ReportProperties reportProperties) throws ReportException {
        return report.buildFilterXML(reportParameters,reportProperties);
    }

    protected String getReportXSL(ReportProperties reportProperties) {
        return reportProperties.getFilterXSL();
    }


}
