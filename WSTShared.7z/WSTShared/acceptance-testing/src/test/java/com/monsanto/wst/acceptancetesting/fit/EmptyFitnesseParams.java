package com.monsanto.wst.acceptancetesting.fit;
/*
 EmptyFitnesseParams was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class EmptyFitnesseParams implements FitnesseParameters {
  public String getParam(int paramNum, String paramName) throws IllegalArgumentException {
        return null;
      }
}
