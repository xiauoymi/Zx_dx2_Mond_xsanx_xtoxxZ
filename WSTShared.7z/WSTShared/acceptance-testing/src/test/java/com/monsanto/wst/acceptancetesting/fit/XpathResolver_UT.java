package com.monsanto.wst.acceptancetesting.fit;

import com.monsanto.wst.acceptancetesting.fit.identifier.strategy.ResolverStrategy;
import com.monsanto.wst.acceptancetesting.fit.identifier.strategy.XPathResolver;
import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;
import junit.framework.TestCase;

import java.util.Collections;
import java.util.Map;

/*
 XpathResolver_UT was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class XpathResolver_UT extends TestCase {
  private static final Map<String, String> NO_VARS = Collections.emptyMap();

  public void testConstructResolver() throws Exception {
    ResolverStrategy resolver = new XPathResolver();
    assertEquals("xpath", resolver.getName());
  }

  public void testResolveXPathDoesNotCallGetEval() throws Exception {
    ResolverStrategy resolver = new XPathResolver();
    MockSeleniumBotForEval bot = new MockSeleniumBotForEval();
    String xpath = "/html/@id";
    String result = resolver.resolve(xpath, bot, NO_VARS);
    assertFalse(bot.wasEvalCalled());
  }

  public void testResolveXPathGetsCorrectValue() throws Exception {
    ResolverStrategy resolver = new XPathResolver();
    SeleniumBot bot = new MockSeleniumBotForHtml("<html id='foo'><br></html>");
    String xpath = "/html/@id";
    String result = resolver.resolve(xpath, bot, NO_VARS);
    assertEquals("foo", result);
  }

  private static class MockSeleniumBotForHtml extends MockSeleniumBot {
    private final String html;

    private MockSeleniumBotForHtml(String html) {
      this.html = html;
    }

    public String getHtmlSource() {
      return html;
    }
  }

  private static class MockSeleniumBotForEval extends MockSeleniumBot {
    private boolean evalCalled = false;

    public MockSeleniumBotForEval() {
    }

    public String getEval(String eval) {
      evalCalled = true;
      return "";
    }

    public boolean wasEvalCalled() {
      return evalCalled;
    }
  }
}