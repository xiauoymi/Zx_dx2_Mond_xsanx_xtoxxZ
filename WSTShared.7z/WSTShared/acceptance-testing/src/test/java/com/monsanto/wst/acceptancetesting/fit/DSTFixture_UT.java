package com.monsanto.wst.acceptancetesting.fit;

import fit.Parse;
import junit.framework.TestCase;

/*
 DSTFixture_UT was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DSTFixture_UT extends TestCase {
  public void testGetParam() throws Exception {
    String testTable = "<td>foo</td><td>bar</td>";
    Parse testCells = new Parse(testTable, Parse.tags, 2, 0);
    DSTFixture fixture = new MockDSTFixture(testCells);
    String param0 = fixture.getParam(0, "param0");
    String param1 = fixture.getParam(1, "param1");
    assertEquals("foo", param0);
    assertEquals("bar", param1);
  }

  public void testGetParamTexesVariable() throws Exception {
    String testTable = "<td>foo</td><td>hello, {myvariable}</td>";
    Parse testCells = new Parse(testTable, Parse.tags, 2, 0);
    MockDSTFixture fixture = new MockDSTFixture(testCells);
    fixture.setVariable("myvariable", "world");
    String param0 = fixture.getParam(0, "param0");
    String param1 = fixture.getParam(1, "param1");
    assertEquals("foo", param0);
    assertEquals("hello, world", param1);
  }

  public class MockDSTFixture extends DSTFixture {
    public MockDSTFixture(Parse cells) {
      super.cells = cells;
    }

    protected void setVariable(String variableId, String value) {
      super.setVariable(variableId, value);
    }
  }
}