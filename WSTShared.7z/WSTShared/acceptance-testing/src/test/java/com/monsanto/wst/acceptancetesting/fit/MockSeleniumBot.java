package com.monsanto.wst.acceptancetesting.fit;

import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;
/*
 MockSeleniumBot was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MockSeleniumBot implements SeleniumBot {
  public void stop() {
  }

  public void open(String path) {
  }

  public String doCommand(String command, String field, String value) {
    return null;
  }

  public String resolveUri(String path) {
    return null;
  }

  public void pause(int duration) {
  }

  public void waitForPopUp(String windowId, int timeout) {
  }

  public void waitForPageToLoad(int timeout) {
  }

  public void waitForCondition(String script, int timeout) {
  }

  public void waitForPropertyMatch(String locator, String propertyPath, String regex) {
  }

  public void waitForPropertyMatch(String locator, String propertyPath, String regex, int timeout) {
  }

  public boolean isOptionPresent(String locator, String label) {
    return false;
  }

  public void waitForOptions(String locator) {
  }

  public void waitForOptions(String locator, int timeout) {
  }

  public int getDefaultTimeout() {
    return 10000;
  }

  public void setDefaultTimeout(int timeout) {
  }

  public boolean isSelected(String locator, String label) {
    return false;
  }

  public String getProperty(String locator, String propertyPath) {
    return null;
  }

  public void selectByIndex(String locator, int index) {
  }

  public void waitForElement(String locator) {
  }

  public void waitForElement(String locator, int timeout) {
  }

  public void waitForAlert() {
  }

  public void waitForAlert(int timeout) {
  }

  public void waitForConfirmation() {
  }

  public void waitForConfirmation(int timeout) {
  }

  public void waitForLocationContains(String search) {
  }

  public void waitForLocationContains(String search, int timeout) {
  }

  public void waitForTitle(String title) {
  }

  public void waitForTitle(String title, int timeout) {
  }

  public boolean isChecked(String identifier) {
    return false;
  }

  public String getValue(String s) {
    return null;
  }

  public String getEval(String s) {
    return null;
  }

  public String getBodyText() {
    return null;
  }

  public String getTitle() {
    return null;
  }

  public String getLocation() {
    return null;
  }

  public boolean isAlertPresent() {
    return false;
  }

  public String getAlert() {
    return null;
  }

  public void goBack() {
  }

  public String getTable(String s) {
    return null;
  }

  public void uncheck(String identifier) {
  }

  public void check(String identifier) {
  }

  public void select(String fieldId, String fieldValue) {
  }

  public void addSelection(String fieldId, String fieldValue) {
  }

  public void removeSelection(String fieldId, String fieldValue) {
  }

  public String[] getSelectOptions(String fieldId) {
    return new String[0];
  }

  public void type(String fieldId, String fieldValue) {
  }

  public void click(String linkLocator) {
  }

  public void start() {
  }

  public String getHtmlSource() {
    return "";
  }
}
