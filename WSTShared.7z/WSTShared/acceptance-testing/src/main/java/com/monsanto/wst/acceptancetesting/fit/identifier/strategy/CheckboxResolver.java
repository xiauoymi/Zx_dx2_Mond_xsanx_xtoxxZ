package com.monsanto.wst.acceptancetesting.fit.identifier.strategy;

import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;

import java.util.Map;
/*
 CheckboxResolver was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class CheckboxResolver implements ResolverStrategy {
  public String getName() {
    return "checkbox";
  }

  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
    String identifier = "name=" + controlId;
    if (bot.isChecked(identifier)) {
      return "ON";
    } else {
      return "OFF";
    }
  }
}
