package com.monsanto.wst.acceptancetesting.fit.identifier.strategy;

import com.monsanto.wst.acceptancetesting.fit.FitnesseParameters;
import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;

import java.util.Map;
/*
 RadioResolver was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class RadioResolver extends XPathResolver {
  private final FitnesseParameters params;

  public RadioResolver(FitnesseParameters params) {
    this.params = params;
  }

  public String getName() {
    return "radio";
  }

  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
    try {
      String value = params.getParam(2, "value");
      return super.resolve("//input[@type='radio' and @name='" + controlId + "' and @value='" + value + "']", bot,
          variables);
    } catch (Exception e) {
      return super.resolve("//input[@type='radio' and @name='" + controlId + "']", bot, variables);
    }
  }
}
