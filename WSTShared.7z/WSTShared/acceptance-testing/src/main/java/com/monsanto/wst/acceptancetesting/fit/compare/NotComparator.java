package com.monsanto.wst.acceptancetesting.fit.compare;
/*
 NotComparator was created on Jan 14, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class NotComparator implements ValueComparator {
  private final ValueComparator baseComparator;

  public NotComparator(ValueComparator comparator) {
    baseComparator = comparator;
  }

  public boolean compare(String expectedValue, String actualValue) {
    return !baseComparator.compare(expectedValue, actualValue);
  }

}

