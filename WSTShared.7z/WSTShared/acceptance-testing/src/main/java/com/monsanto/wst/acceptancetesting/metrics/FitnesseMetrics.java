package com.monsanto.wst.acceptancetesting.metrics;

import java.io.OutputStream;
import java.io.PrintStream;
import java.text.NumberFormat;
import java.util.*;
/*
 FitnesseMetrics was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class FitnesseMetrics {
  private final List<TestRecord> results = new ArrayList<TestRecord>();
  private final List<String> errors = new ArrayList<String>();

  public void report(OutputStream outputStream) {
    PrintStream output = new PrintStream(outputStream);
    Map<String, ProjectSummary> summaries = generateSummariesByProject();
    ProjectSummary totals = generateTotals(summaries);

//    outputResultsDetail(output);
    outputProjectSummaries(output, summaries);
    outputTotals(output, totals);
    outputErrors(output);
    output.println("\n!3 Results generated " + new Date());
  }

  private void outputTotals(PrintStream output, ProjectSummary totals) {
    output.println("!2 Totals for All Iterations");
    outputProjectSummary(output, totals);
  }

  private void outputProjectSummary(PrintStream output, ProjectSummary summary) {
    int validTests = summary.getNumValidTests();
    int passFail = summary.getNumPassFailTests();
    int performanceTests  = summary.getNumPerformanceTests();
    if (validTests > 0) {
      output.println("|number of completed tests|" + validTests + '|' + computePercentage(validTests, validTests) + '|');
      output.println("|number of pass/fail, manual tests|" + passFail + '|' + computePercentage(passFail, validTests) +
          '|');
      output.println("|number of performance tests|" + performanceTests + '|' + computePercentage(performanceTests, validTests) +
          '|');
    } else {
      output.println("There were no completed tests");
    }
    output.println("\nThere are an additional " + summary.getNumIncompleteTests() + " test(s) that are not complete, and were not analyzed.\n");
  }

  private String computePercentage(int success, int total) {
    NumberFormat format = NumberFormat.getPercentInstance();
    return format.format((double) success / (double) total);
  }

  private void outputProjectSummaries(PrintStream output, Map<String, ProjectSummary> summaries) {
    for (String projectName : summaries.keySet()) {
      ProjectSummary projectData = summaries.get(projectName);
      output.println("!2 " + projectName);
      outputProjectSummary(output, projectData);
    }
  }

  private ProjectSummary generateTotals(Map<String, ProjectSummary> summaries) {
    ProjectSummary totals = new ProjectSummary();
    for (ProjectSummary projectData : summaries.values()) {
      totals = totals.add(projectData);
    }
    
    return totals;
  }

  private Map<String, ProjectSummary> generateSummariesByProject() {
    Map<String, ProjectSummary> summaries = new HashMap<String, ProjectSummary>();

    for (TestRecord result : results) {
      String projectName = result.getIterationName();
      ProjectSummary summary = summaries.get(projectName);
      if (summary == null) {
        summary = new ProjectSummary();
      }
      summary = summary.add(result.getResults());
      summaries.put(projectName, summary);
    }

    return summaries;
  }

/*
  private void outputResultsDetail(PrintStream output) {
    if (results.size() > 0) {
      for (TestRecord result : results) {
        outputResult(output, result);
      }
    }
  }

  private void outputResult(PrintStream output, TestRecord result) {
    output.println(result.getIterationName() + " : " + result.getTestName());
  }
*/

  private void outputErrors(PrintStream output) {
    if (errors.size() > 0) {
      output.println("\n!2 Errors\n");
      for (String error : errors) {
        output.println(error);
      }
    }
  }

  public void logError(String msg) {
    errors.add(msg);
  }

  public void recordTest(String iterationName, String testName, TestData result) {
    results.add(new TestRecord(iterationName, testName, result));
  }

  private static class TestRecord {
    private final String iterationName;
    private final String testName;
    private final TestData results;

    private TestRecord(String iterationName, String testName, TestData results) {
      this.iterationName = iterationName;
      this.testName = testName;
      this.results = results;
    }

    public String getIterationName() {
      return iterationName;
    }

    public String getTestName() {
      return testName;
    }

    public TestData getResults() {
      return results;
    }
  }

  private static class ProjectSummary {
    private final int numValidTests; // does NOT include incomplete tests
    private final int numPassFailTests;
    private final int numIncompleteTests;
    private final int numPerformanceTests;

    private ProjectSummary(int numValidTests, int numPassFailTests, int numIncompleteTests, int numPerformanceTests) {
      this.numValidTests = numValidTests;
      this.numPassFailTests = numPassFailTests;
      this.numIncompleteTests = numIncompleteTests;
      this.numPerformanceTests = numPerformanceTests;
    }

    public ProjectSummary() {
      this(0,0,0,0);
    }

    public int getNumValidTests() {
      return numValidTests;
    }

    public int getNumPassFailTests() {
      return numPassFailTests;
    }

    public int getNumIncompleteTests() {
      return numIncompleteTests;
    }

    public int getNumPerformanceTests() {
      return numPerformanceTests;
    }

    public ProjectSummary add(TestData testData) {
      return add(boolToInt(testData.isValid()),
          boolToInt(testData.isPassFail()),
          boolToInt(testData.isIncomplete()),
          boolToInt(testData.isPerformance()));
    }

    public ProjectSummary add(ProjectSummary summary) {
      return add(summary.getNumValidTests(), summary.getNumPassFailTests(), summary.getNumIncompleteTests(), summary.getNumPerformanceTests());
    }

    private ProjectSummary add(int numValidTests, int numPassFailTests, int numIncompleteTests,
                               int numPerformanceTests) {
      return new ProjectSummary(this.numValidTests + numValidTests, this.numPassFailTests + numPassFailTests, this.numIncompleteTests + numIncompleteTests, this.numPerformanceTests + numPerformanceTests);
    }

    private static int boolToInt(boolean booleanValue) {
      if (booleanValue) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}
