package com.monsanto.wst.acceptancetesting.fit;

import fit.Parse;
/*
 PassFailFixture was created on Feb 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class PassFailFixture extends DSTFixture {
  private static final String JUSTIFICATION_REQUIRED_MESSAGE = "a justification for making this test pass/fail is required.";
  private String justification = null;
  private boolean passFailCalled = false;


  public void doTable(Parse parse) {
    super.doTable(parse);
    if (!passFailCalled) {
      throw new IllegalStateException("either pass or fail must be called with the PassFailFixture");
    }
  }

  public void justify() {
    String reason = getParam(1, "pass/fail justification");
    if (reason == null || reason.length() == 0) {
      justification = null;
      wrong(cells.more, JUSTIFICATION_REQUIRED_MESSAGE);
    } else {
      justification = reason;
      right(cells.more);
    }
  }

  public void fail() {
    passFailCalled = true;
    Parse cellToFlag = getCellToFlag();
    if (justification == null) {
      wrong(cellToFlag, JUSTIFICATION_REQUIRED_MESSAGE);
    } else {
      wrong(cellToFlag);
    }
  }

  public void pass() {
    passFailCalled = true;
    Parse cellToFlag = getCellToFlag();
    if (justification == null) {
      wrong(cellToFlag, JUSTIFICATION_REQUIRED_MESSAGE);
    } else {
      right(cellToFlag);
    }
  }

  private Parse getCellToFlag() {
    Parse cellToFlag;
    if (cells.more != null) {
      cellToFlag = cells.more;
    } else {
      cellToFlag = cells;
    }
    return cellToFlag;
  }

  //todo implement PassFailFixture
}
