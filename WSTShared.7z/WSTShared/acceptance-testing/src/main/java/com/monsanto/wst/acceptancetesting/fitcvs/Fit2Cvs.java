package com.monsanto.wst.acceptancetesting.fitcvs;

import java.io.*;
import java.util.List;
import java.util.ArrayList;
/*
 Fit2Cvs was created on Jan 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class Fit2Cvs {
  private static final String NEW_FILE_PREFIX = "? ";
  private static final String REMOVE_FILE_PREFIX = "U ";

  public static void main(String[] args) throws IOException, InterruptedException {
    if (args.length != 2) {
      System.out.println("syntax: java com.monsanto.wst.acceptancetesting.fitcvs.Fit2CVS REPOSITORY_ROOT CVS_PROJECT_NAME");
      return;
    }

    String repositoryRoot = args[0];
    String projectName = args[1];

    File fitRepoRoot = new File(repositoryRoot);

    System.out.println("Adding new files");
    addFilesMissingFromCVS(fitRepoRoot, projectName);
    System.out.println("Committing");
    cvsCommit(fitRepoRoot);
    System.out.println("Removing old files");
    removeFilesThatHaveBeenDeleted(fitRepoRoot, projectName);
    System.out.println("Committing");
    cvsCommit(fitRepoRoot);
  }

  private static void removeFilesThatHaveBeenDeleted(File fitRepoRoot, String projectName) throws IOException,
      InterruptedException {
    FileAction addAction = new RemoveFileAction(fitRepoRoot);
    processFilesFromCVS(REMOVE_FILE_PREFIX, addAction, fitRepoRoot, projectName);
  }

  private static void cvsCommit(File fitRepoRoot) throws IOException, InterruptedException {
    exec("cvs -Q commit -m AutoUpdate", fitRepoRoot);
  }

  private interface FileAction {
    void process(String filename) throws IOException, InterruptedException;
  }

  private static abstract class CVSAction implements FileAction {
    protected File fitRepoRoot;

    public CVSAction(File fitRepoRoot) {
      this.fitRepoRoot = fitRepoRoot;
    }

    protected File getLocalDir(String fullFilename) {
      File fullfile = new File(fullFilename);
      String parentName = fullfile.getParent();
      return (parentName == null) ? fitRepoRoot : new File(fitRepoRoot, parentName);
    }

    protected String getFilename(String fullFilename) {
      File fullfile = new File(fullFilename);
      return fullfile.getName();
    }

    public void process(String fullFilename) throws IOException, InterruptedException {
      String filename = getFilename(fullFilename);
      File localDir = getLocalDir(fullFilename);

      String cmd = "cvs " + getCVSCommand() + " " + filename;
      runCommand(cmd, localDir);
    }

    protected void runCommand(String cmd, File localDir) throws IOException, InterruptedException {
      exec(cmd, localDir);
    }

    protected abstract String getCVSCommand();
  }

  private static class AddFileAction extends CVSAction {
    public AddFileAction(File fitRepoRoot) {
      super(fitRepoRoot);
    }

    protected String getCVSCommand() {
      return "-Q add";
    }
  }

  private static class RemoveFileAction extends CVSAction {
    public RemoveFileAction(File fitRepoRoot) {
      super(fitRepoRoot);
    }

    public void process(String fullFilename) throws IOException, InterruptedException {
      if (isRemoveNeeded(fullFilename)) {
        String filename = getFilename(fullFilename);
        File localDir = getLocalDir(fullFilename);

        String cmd = "cvs -Q remove " + fullFilename; // doesn't chdir dir directory since it may no longer exist
        runCommand(cmd, fitRepoRoot);
      }
    }

    private boolean isRemoveNeeded(String fullFilename) {
      String filename = getFilename(fullFilename);
      File localDir = getLocalDir(fullFilename);

      File localfile = new File(localDir, filename);
      return !localfile.exists();
    }

    protected String getCVSCommand() {
      return "-Q remove";
    }
  }

  private static void exec(String cmd, File localDir) throws IOException, InterruptedException {
    Thread execThread = new ExecThread(cmd, localDir);
    execThread.start();
    execThread.join(60000); //todo remove timeout
  }

  private static class ExecThread extends Thread {
    private final String cmd;
    private final File localDir;

    private Process process;
    private InputStream stdout;
    private InputStream stderr;

    public ExecThread(String cmd, File localDir) {
      super("cvsexec");
      this.cmd = cmd;
      this.localDir = localDir;
    }

    public void run() {
      try {
//        System.out.println("> " + cmd + " -- " + localDir);
        process = Runtime.getRuntime().exec(cmd, null, localDir);
        stdout = process.getInputStream();
        stderr = process.getErrorStream();

        while (stdout.read() != -1);
        while (stderr.read() != -1);

        int resultCode = process.waitFor();
        if (resultCode != 0) {
          System.out.println("resultCode = " + resultCode + " for: " + cmd + " in " + localDir);
        }
        
        stdout.close();
        stderr.close();
      } catch (IOException e) {
        e.printStackTrace();
        throw new RuntimeException(e);
      } catch (InterruptedException e) {
        e.printStackTrace();
        throw new RuntimeException(e);
      }
    }
  }

  private static int processFilesFromCVS(String prefix, FileAction action, File fitRepoRoot, String projectName) throws IOException,
      InterruptedException {

    int processedCount = 0;
    Runtime runtime = Runtime.getRuntime();
    Process process = runtime.exec("cvs -n -q update -d", null, fitRepoRoot);
    String[] lines = readResults(process);

    for (String line : lines) {
//      System.out.println("< " + line);

      if (line.startsWith(prefix)) {
        String filename = line.substring(prefix.length());
        action.process(filename);
        processedCount++;
      }
    }

    return processedCount;
  }

  private static String[] readResults(Process process) throws IOException, InterruptedException {
    List<String> lines = new ArrayList<String>();

    BufferedReader procResults = new BufferedReader(new InputStreamReader(process.getInputStream()));
    String line = procResults.readLine();

    while (line != null) {
      lines.add(line);
      line = procResults.readLine();
    }

    return (String[]) lines.toArray(new String[lines.size()]);
  }

  private static void addFilesMissingFromCVS(File fitRepoRoot, String projectName) throws IOException,
      InterruptedException {
    FileAction addAction = new AddFileAction(fitRepoRoot);
    int addCount;
    do {
      addCount = processFilesFromCVS(NEW_FILE_PREFIX, addAction, fitRepoRoot, projectName);
    } while (addCount > 0);
  }

/*
  private static class DumpFilenameAction implements FileAction {
    public void process(String filename) {
      System.out.println("filename = " + filename);
    }
  }

  private static class MockAddFileAction extends AddFileAction {
    public MockAddFileAction(File fitRepoRoot) {
      super(fitRepoRoot);
    }

    protected void runCommand(String cmd, File localDir) throws IOException, InterruptedException {
      System.out.println("> " + cmd + " (" + localDir + ")");
    }
  }

  private static class MockRemoveFileAction extends RemoveFileAction {
    public MockRemoveFileAction(File fitRepoRoot) {
      super(fitRepoRoot);
    }

    protected void runCommand(String cmd, File localDir) throws IOException, InterruptedException {
      System.out.println("> " + cmd + " (" + localDir + ")");
    }
  }

  private static void cvslist(File fitRepoRoot, String projectName) throws IOException, InterruptedException {
    processFilesFromCVS(NEW_FILE_PREFIX, new DumpFilenameAction(), fitRepoRoot, projectName);
  }
*/
}
