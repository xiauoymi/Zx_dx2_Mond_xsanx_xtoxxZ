package com.monsanto.wst.acceptancetesting.fit;

import fit.Fixture;
import fit.Parse;
/*
 IncompleteFixture was created on Feb 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class IncompleteFixture extends Fixture {
  public void doTable(Parse parse) {
    wrong(parse, "This test has not been writeen yet");
  }
}
