package com.monsanto.wst.acceptancetesting.metrics;
/*
 TestData was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class TestData {
  boolean valid;
  boolean passFail;
  boolean incomplete;
  boolean performance;

  public TestData(boolean valid, boolean passFail, boolean incomplete, boolean performance) {
    this.valid = valid;
    this.passFail = passFail;
    this.incomplete = incomplete;
    this.performance = performance;
  }

  public boolean isValid() {
    return valid;
  }

  public boolean isPassFail() {
    return passFail;
  }

  public boolean isIncomplete() {
    return incomplete;
  }

  public boolean isPerformance() {
    return performance;
  }
}
