package com.monsanto.wst.acceptancetesting.selenium;/*
 SeleniumBot was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface SeleniumBot {
  void stop();

  /**
	 * Opens the provided url in the test frame.  If the path provided is a relative url,
   * it will first be resolved using the base url of the application under test.
   *
   * @param path The url of the page to open (may be relative to the AUT)
   */
  void open(String path);

  /**
	 * Directly call a client side selenium action.  Provides access to client side selenium
   * actions that have not been otherwise exposed.
   *
   * @param command The name of the action to call
   * @param field   The first argument to pass to the action
   * @param value   The second argument to pass to the action
   * @return The result returned by the selenium action
   */
  String doCommand(String command, String field, String value);

  /**
	 * Resolves the provided uri using the url of the AUT.  If the provided path appears to be
   * absolute, this method will return the provided path.
   *
   * @param path The path to resolve
   * @return The resolved path.
   */
  String resolveUri(String path);

  /**
	 * Pause for the specified duration.
   *
   * @param duration The length of time to pause (in milliseconds).
   */
  void pause(int duration);

  /**
	 * Wait until a popup window appears or the specified timeout has elapsed.
   *
   * @param windowId The ID of the popup window to wait for
   * @param timeout  The maximum time to wait (in milliseconds).
   */
  void waitForPopUp(String windowId, int timeout);

  /**
	 * Waits for the current page load to completed or until the specified time has elapsed.
   *
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForPageToLoad(int timeout);

  /**
	 * Execute the provided javascript snippet until the snippet evaluates to true or until
   * the specified time has elapsed.  The script may get a reference to the window element
   * for the AUT using the following:  this.page().currentWindow.  It may also find an element
   * within the AUT using:  this.page().findElement(locator).
   * <p/>
   * For Example:
   * bot.waitForCondition("return this.page().findElement('someElementId').currentStyle.display=='none';", 500);
   * This will wait until the element whose id is "someElementId" is no longer
   * visible (the currentStyle property has a display property value of 'none').
   *
   * @param script  The script to be executed
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForCondition(String script, int timeout);

  /**
	 * @param locator      The locator to use to find the target element
   * @param propertyPath The property path (may be nested) of the property to evaluate
   * @param regex        The regular expression that the value of the property should match
   * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForPropertyMatch(String, String, String, int);
   */
  void waitForPropertyMatch(String locator, String propertyPath, String regex);

  /**
	 * Wait until the element at the specified location has a property value that matches
   * the provided regular expression or the specified time elapses.  The property may
   * be a nested property of the element in which case the propertyPath will be
   * dot-separated.
   * <p/>
   * For Example:
   * bot.waitForPropertyMatch("someElementId", "currentStyle.display", "none");
   * This will wait until the element whose id is "someElementId" is no longer
   * visible (the currentStyle property has a display property value of 'none').
   *
   * @param locator      The locator to use to find the target element
   * @param propertyPath The property path (may be nested) of the property to evaluate
   * @param regex        The regular expression that the value of the property should match
   * @param timeout      The maximum time to wait (in milliseconds).
   */
  void waitForPropertyMatch(String locator, String propertyPath, String regex, int timeout);

  /**
	 * Determines if an option is present in a select element.
   *
   * @param locator Used to find the select element on the page
   * @param label   The label to look for in the select element
   * @return true if the label is present, false otherwise
   */
  boolean isOptionPresent(String locator, String label);

  /**
	 * @param locator Used to find the select element on the page
   * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForOptions(String, int)
   */
  void waitForOptions(String locator);

  /**
	 * Waits for the select to contain options or until the
   *
   * @param locator Used to find the select element on the page.
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForOptions(String locator, int timeout);

  /**
	 * Provides the default timeout to use in waitFor* methods that do not have a timeout parameter.
   *
   * @return The default timeout (in milliseconds)
   */
  int getDefaultTimeout();

  void setDefaultTimeout(int timeout);

  /**
	 * Determines if a select element has a particular option selected.
   *
   * @param locator Used to locate the select element on the page
   * @param label   The label being tested for selection
   * @return true if the label is selected, false otherwise
   */
  boolean isSelected(String locator, String label);

  /**
	 * Get the value of the specified property of an element.  The property may
   * be a nested property of the element in which case the propertyPath will be
   * dot-separated.
   * <p/>
   * For Example:
   * bot.getProperty("someElementId", "currentStyle.display");
   * This will find the element whose id is "someElementId" and return its
   * currentStyle's display property value (which can be used to determine if
   * the element is visible).
   *
   * @param locator      Used to locate the element
   * @param propertyPath The property to be returned
   * @return the value of the property for the element
   */
  String getProperty(String locator, String propertyPath);

  /**
	 * Set the selected value in a select element by the provided index.
   *
   * @param locator Used to locate the select element
   * @param index   The index (zero-based) of the option to select
   */
  void selectByIndex(String locator, int index);

  /**
	 * @param locator Used to locate the element
   * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForElement(String, int)
   */
  void waitForElement(String locator);

  /**
	 * Wait for the specified element to be present on the page or until the specified
   * time has elapsed.
   *
   * @param locator Used to locate the element
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForElement(String locator, int timeout);

  /**
	 * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForAlert(int)
   */
  void waitForAlert();

  /**
	 * Wait for a javascript alert to popup on the screen or until the specified time
	 * has elapsed.
	 *
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
  void waitForAlert(int timeout);

  /**
	 * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForConfirmation(int)
   */
  void waitForConfirmation();

  /**
	 * Waits for a confirmation dialog in the browser, or until the specified
   * time has elapsed.
   *
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForConfirmation(int timeout);

  /**
	 * @param search The string that should appear in the url
   * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForLocationContains(String, int)
   */
  void waitForLocationContains(String search);

  /**
	 * Waits until the current url loaded in the browser contains the specified
   * search string or until the specified time has elapsed.
   *
   * @param search  The string that should appear in the url
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForLocationContains(String search, int timeout);

  /**
	 * @param title The title to wait for
   * @see com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver#waitForTitle(String, int)
   */
  void waitForTitle(String title);

  /**
	 * Waits for the window title of the primary page for the AUT to be equal to the
   * specified title string.
   *
   * @param title   The title to wait for
   * @param timeout The maximum time to wait (in milliseconds).
   */
  void waitForTitle(String title, int timeout);

  boolean isChecked(String identifier);

  String getValue(String s);

  String getEval(String s);

  String getBodyText();

  String getTitle();

  String getLocation();

  boolean isAlertPresent();

  String getAlert();

  void goBack();

  String getTable(String s);

  void uncheck(String identifier);
  void check(String identifier);

  void select(String fieldId, String fieldValue);

  void addSelection(String fieldId, String fieldValue);

  void removeSelection(String fieldId, String fieldValue);

  String[] getSelectOptions(String fieldId);

  void type(String fieldId, String fieldValue);

  void click(String linkLocator);

  void start();

  String getHtmlSource();
}
