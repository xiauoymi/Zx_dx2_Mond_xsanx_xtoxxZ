package com.monsanto.wst.acceptancetesting.metrics;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
/*
 MetricsProcessor was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MetricsProcessor {
  private final File repoDir;
  private final MetricsConfigOptions options;

  private static final String INCOMPLETE_FIXTURE = "IncompleteFixture";
  private static final String PASSFAIL_FIXTURE = "PassFailFixture";
  private static final String PERFORMANCE_TEST_COMMAND = "|endTimer|";

  public MetricsProcessor(File repoDir, MetricsConfigOptions options) {
    this.repoDir = repoDir;
    this.options = options;
  }

  public FitnesseMetrics generateMetrics() {
    FitnesseMetrics metrics = new FitnesseMetrics();
    for (String subDirName : options.getSubDirs()) {
      generateMetrics(metrics, subDirName);
    }
    return metrics;
  }

  private void generateMetrics(FitnesseMetrics metrics, String subDirName) {
    File rootOfIteration = new File(repoDir, subDirName);
    if (rootOfIteration.exists()) {
      generateMetrics(subDirName, metrics, rootOfIteration);
    } else {
      metrics.logError("Unable to locate iteration: " + rootOfIteration);
    }
  }

  private void generateMetrics(String iterationName, FitnesseMetrics metrics, File wikiDir) {
    if (isPageATest(wikiDir)) {
      generateMetricsForTest(iterationName, metrics, wikiDir);
    } else {
      for (File subDir : wikiDir.listFiles()) {
        if (subDir.isDirectory()) {
          generateMetrics(iterationName, metrics, subDir);
        }
      }
    }
  }

  private void generateMetricsForTest(String iterationName, FitnesseMetrics metrics, File wikiDir) {
    TestData testData = null;
    try {
      testData = generateTestData(wikiDir);
    } catch (IOException e) {
      metrics.logError("Unable to analyze test: " + wikiDir.getName());
    }
    metrics.recordTest(iterationName, wikiDir.getName(), testData);
  }

  private TestData generateTestData(File wikiDir) throws IOException {
    List<String> testContents = getContents(wikiDir);
    String fixture = getFixture(testContents);
    if (fixture == null) {
      return new TestData(false, false, true, false);
    } else {
      boolean isPerformanceTest = isPerformanceTest(testContents);
      boolean isIncomplete = fixture.contains(INCOMPLETE_FIXTURE);
      boolean isPassFail = fixture.contains(PASSFAIL_FIXTURE);
      return new TestData(!isIncomplete, isPassFail, isIncomplete, isPerformanceTest);
    }
  }

  private String getFixture(List<String> testContents) {
    for (String line : testContents) {
      if (line.startsWith("!|")) {
        return getFixture(line.substring(2));
      } else if (line.startsWith("|")) {
        return getFixture(line.substring(1));
      }
    }
    return null;
  }

  private String getFixture(String line) {
    String[] tokens = line.split("\\|");
    return tokens[0];
  }

  private List<String> getContents(File wikiDir) throws IOException {
    File contentsFile = new File(wikiDir, MetricsGenerator.CONTENT_FILENAME);
    if (contentsFile.exists()) {
      List<String> contents = new ArrayList<String>();
      BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(contentsFile)));
      String line = input.readLine();
      while (line != null) {
        contents.add(line);
        line = input.readLine();
      }
      input.close();
      return contents;
    } else {
      return new ArrayList<String>(0);
    }
  }

  private boolean isPerformanceTest(List<String> testContents) {
    for (String line : testContents) {
      if (line.contains(PERFORMANCE_TEST_COMMAND)) {
        return true;
      }
    }
    return false;
  }

  private boolean isPageATest(File wikiDir) {
    File propertiesFile = new File(wikiDir, MetricsGenerator.PROPERTIES_FILENAME);
    if (!propertiesFile.exists()) {
      return false;
    }

    //todo this should be change latter to use XML and XPATH
    try {
      BufferedReader propertiesReader = new BufferedReader(new InputStreamReader(new FileInputStream(propertiesFile)));
      String line = propertiesReader.readLine();
      while (line != null) {
        if (line.contains("<Test/>")) {
          return true;
        } else if (line.contains("<Test>")) {
          return true;
        }
        line = propertiesReader.readLine();
      }
      return false;
    } catch (IOException e) {
      return false;
    }
  }

}
