package com.monsanto.wst.acceptancetesting.fit.identifier.strategy;

import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;

import java.util.Map;
/*
 PageResolver was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class PageResolver implements ResolverStrategy {
  public String getName() {
    return "page";
  }

  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
    if ("content".equals(controlId)) {
      return bot.getBodyText();
    } else if ("title".equals(controlId)) {
      return bot.getTitle();
    } else if ("url".equals(controlId)) {
      return bot.getLocation();
    } else {
      throw new IllegalArgumentException("Unknown page attribute: " + controlId);
    }
  }
}
