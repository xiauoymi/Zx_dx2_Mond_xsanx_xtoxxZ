package com.monsanto.wst.acceptancetesting.fit.compare;
/*
 ValueComparator was created on Dec 11, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public interface ValueComparator{
  boolean compare(String expectedValue, String actualValue);
}
