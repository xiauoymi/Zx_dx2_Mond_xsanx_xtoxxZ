package com.monsanto.wst.acceptancetesting.fit.identifier.strategy;

import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;

import java.util.Map;
import java.util.Random;
/*
 RandomResolver was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class RandomResolver implements ResolverStrategy {
  private static final Random rand = new Random();

  public String getName() {
    return "random";
  }

  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
    try {
      if ("number".equals(controlId)) {
        return getLongString();
      } else {
        int numChars = Integer.parseInt(controlId);
        StringBuffer buf = new StringBuffer(numChars);
        for (int i = 0; i < numChars; i++) {
          buf.append(getRandomChar());
        }
        return buf.toString();
      }
    } catch (NumberFormatException nfe) {
      return controlId + getLongString();
    }
  }

  private char getRandomChar() {
    final int MIN_CHAR = 32;
    final int MAX_CHAR = 126;

    int randChar = rand.nextInt(MAX_CHAR - MIN_CHAR + 1);
    return (char) (MIN_CHAR + randChar);
  }

  private String getLongString() {
    return Long.toString(Math.abs(rand.nextLong()));
  }
}
