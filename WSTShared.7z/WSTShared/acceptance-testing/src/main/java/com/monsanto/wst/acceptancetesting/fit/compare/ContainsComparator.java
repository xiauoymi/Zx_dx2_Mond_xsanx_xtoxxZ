package com.monsanto.wst.acceptancetesting.fit.compare;
/*
 ContainsComparator was created on Dec 11, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class ContainsComparator implements ValueComparator {
  public boolean compare(String expectedValue, String actualValue) {
    return actualValue.contains(expectedValue);
  }
}
