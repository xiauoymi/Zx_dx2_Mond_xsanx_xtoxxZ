package com.monsanto.wst.acceptancetesting.fit;/*
 FitnesseParameters was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface FitnesseParameters {
  String getParam(int paramNum, String paramName) throws IllegalArgumentException;
}
