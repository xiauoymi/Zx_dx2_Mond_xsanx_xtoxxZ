package com.monsanto.wst.acceptancetesting.fit.identifier;

import com.monsanto.wst.acceptancetesting.fit.FitnesseParameters;
import com.monsanto.wst.acceptancetesting.fit.identifier.strategy.*;
import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;

import java.util.HashMap;
import java.util.Map;
/*
 IdentifierResolver was created on Dec 11, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class IdentifierResolver {
  private final SeleniumBot bot;
  private final Map<String, String> variables;
  private final FitnesseParameters params;
  private final Map<String, ResolverStrategy> resolvers;

  public IdentifierResolver(SeleniumBot bot, FitnesseParameters params, Map<String,String> variables) {
    this.bot = bot;
    this.params = params;
    this.variables = variables;
    this.resolvers = loadResolvers(params);
  }

  private static Map<String, ResolverStrategy> loadResolvers(FitnesseParameters fitnessParams) {
    Map<String, ResolverStrategy> resolvers = new HashMap<String, ResolverStrategy>();
    addResolver(resolvers, new PageResolver());
    addResolver(resolvers, new XPathResolver());
    addResolver(resolvers, new RadioResolver(fitnessParams));
    addResolver(resolvers, new CheckboxResolver());
    addResolver(resolvers, new FrameResolver());
    addResolver(resolvers, new FieldResolver());
    addResolver(resolvers, new LiteralResolver());
    addResolver(resolvers, new VariableResolver());
    addResolver(resolvers, new RandomResolver());
    return resolvers;
  }

  private static void addResolver(Map<String, ResolverStrategy> resolverList, ResolverStrategy resolver) {
    resolverList.put(resolver.getName(), resolver);
  }

  public String getValue(int offset) {
      String controlType = params.getParam(offset, "controlType");
      String controlId = params.getParam(offset + 1, "controlId");
      return getControlValue(controlType, controlId);
  }

  public String getControlValue(String controlType, String controlId) {
    ResolverStrategy resolver = resolvers.get(controlType);

    if (resolver == null) {
      throw new IllegalArgumentException("Unknown control type:" + controlType + " supported types: " + listResolverTypes());
    } else {
      return resolver.resolve(controlId, bot, variables);
    }
  }

  private String listResolverTypes() {
    StringBuffer buf = new StringBuffer();
    for (ResolverStrategy resolver : resolvers.values()) {
      if (buf.length() > 0) {
        buf.append(", ");
      }

      buf.append(resolver.getName());
    }

    return buf.toString();
  }
}
