package com.monsanto.wst.acceptancetesting.fit;

import com.monsanto.wst.acceptancetesting.fit.compare.*;
import com.monsanto.wst.acceptancetesting.fit.identifier.IdentifierResolver;
import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;
import com.monsanto.wst.acceptancetesting.selenium.SeleniumDriver;
import com.thoughtworks.selenium.SeleniumException;
import fit.Fixture;
import fit.Parse;

import java.io.*;
import java.util.*;
/*
 RCCustomFixture was created on Oct 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WSTvariables, Monsanto
 */
public class RCCustomFixture extends DSTFixture {
  public static final long DEFAULT_TIMER_LIMIT = 10000;
  //todo refactor these into maps
  private static final int[] SELENIUM_PORTS = {4444, 4445, 4446, 4447};
  private static final String[] USER_CONTEXT_TEXT = {"user1", "user2", "user3", "user4"};

  private SeleniumBot bot;
  private Stack<Long> timers = new Stack<Long>();
  private IdentifierResolver resolver;

  private String currTableName = null;
  private int currTableRow = 0;
  private int botPort = 0;
  private static final String BASE_URL_VARIABLE_NAME = "baseUrl";

  public void notest() {
    wrong(cells);
  }

  public void start() throws Throwable {
    String baseUrl = getVariable(BASE_URL_VARIABLE_NAME);
    if (!hasParam(1) && baseUrl == null) {
      throw new IllegalArgumentException("url not specified, and no baseUrl defined");
    }
    setActor(this);

    String url;

    try {
      url = getParam(1, "baseUrl");
    } catch (Exception e) {
      url = baseUrl;
    }

    int port = getPortNumber();
    startSeleniumClient(url, port);
    url(url);
    resolver = new IdentifierResolver(bot, this, getVariables());
    right(cells.more);
  }

  private static void setActor(Fixture rcCustomFixture) {
    synchronized (RCCustomFixture.class) {
      actor = rcCustomFixture;
    }
  }

  public void fail() {
    if (cells.more == null) {
      wrong(cells);
    } else {
      wrong(cells.more);
    }
  }

  private int getUserContext() {
    String userContextString;
    try {
      userContextString = getParam(2, "userContext");
    } catch (Exception e) {
      return 0;
    }

    for (int i = 0; i < USER_CONTEXT_TEXT.length; i++) {
      if (USER_CONTEXT_TEXT[i].equals(userContextString)) {
        return i;
      }
    }

    StringBuffer buf = new StringBuffer("Unknown User context argument specified: ");
    buf.append(userContextString);
    buf.append(". Valid values are : ");
    buf.append(USER_CONTEXT_TEXT[0]);
    for (int i = 1; i < USER_CONTEXT_TEXT.length; i++) {
      buf.append(',');
      buf.append(USER_CONTEXT_TEXT[i]);
    }
    throw new IllegalArgumentException(buf.toString());
  }

  private int getPortNumber() {
    return SELENIUM_PORTS[getUserContext()];
  }

  public void startTimer() {
    timers.push(new Long(System.currentTimeMillis()));
    right(cells);
  }

  public void endTimer() {
    try {
      Parse parse;
      long timer = timers.pop().longValue();
      long maxTime;
      if (cells.more == null) {
        maxTime = DEFAULT_TIMER_LIMIT;
        parse = cells;
      } else {
        maxTime = Long.parseLong(getParam(1, "maxTime"));
        parse = cells.more;
      }

      long elapsed = System.currentTimeMillis() - timer;
      if (elapsed > maxTime) {
        wrong(parse, Long.toString(elapsed));
      } else {
        right(parse);
      }
    } catch (EmptyStackException e) {
      wrong(cells, "No Timer Set");
    }
  }

  public void url(String url) {
    bot.open(url);
  }

  public void end() {
    if (bot.isAlertPresent()) {
      String alertText = bot.getAlert();
      wrong(cells, "unexpected alert: " + alertText);
    }
    shutDownSeleniumClient();
  }

  public void back() {
    synchronized (RCCustomFixture.class) {
      bot.goBack();
    }
    right(cells);
  }

  public void contains() {
    compare(new ContainsComparator());
  }

  public void containsIgnoreCase() {
    compare(new CaseInsensitiveComparator(new ContainsComparator()));
  }

  public void notContains() {
    compare(new NotComparator(new ContainsComparator()));
  }

  public void notContainsIgnoreCase() {
    compare(new NotComparator(new CaseInsensitiveComparator(new ContainsComparator())));
  }

  public void equalsIgnoreCase() {
    compare(new EqualsComparator());
  }

  public void equals() {
    compare(new EqualsComparator());
  }

  public void exists() {
    try {
      resolver.getValue(1);
      right(cells);
    } catch (SeleniumException e) {
      wrong(cells);
    }
  }

  public void notExists() {
    try {
      resolver.getValue(1);
      wrong(cells);
    } catch (SeleniumException e) {
      right(cells);
    }
  }

  public void notEquals() {
    compare(new NotComparator(new EqualsComparator()));
  }

  public void notEqualsIgnoreCase() {
    compare(new NotComparator(new CaseInsensitiveComparator(new EqualsComparator())));
  }

  public void matchTable() {
    currTableName = getParam(1, "tableName");
    currTableRow = 0;
    String tableData = bot.getTable(currTableName + ".0.0");
    if (tableData == null) {
      wrong(cells.more, "* table not found *");
    }
  }

  //todo change header to read in columns in any order and use the header to identify the columns later

  public void endTable() {
    currTableName = null;
  }

  public void noalert() {
    if (bot.isAlertPresent()) {
      wrong(cells, bot.getAlert());
    } else {
      right(cells);
    }
  }

  public void clearalert() {
    if (bot.isAlertPresent()) {
      bot.getAlert();
    }
  }

  public void heading() {
    verifyTableRow(cells);
  }

  public void data() {
    verifyTableRow(cells);
  }

  private void verifyTableRow(Parse parse) {
    int col = 0;
    Parse currCell = parse.more;
    while (currCell != null) {
      String actualValue = bot.getTable(currTableName + '.' + currTableRow + '.' + col);
      String currValue = getParam(col + 1, "column:" + col);
      if (currValue.equals(actualValue)) {
        right(currCell);
      } else {
        wrong(currCell, actualValue);
      }
      currCell = currCell.more;
      col++;
    }
    currTableRow++;
  }

  public void dump() {
    try {
      File dumpFile = File
          .createTempFile("dump", ".html", new File("c:\\fitnesse\\fitnesse\\FitNesseRoot\\files\\dump"));
      BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dumpFile)));
//      String source = bot.getHtmlSource();
      String source = bot.getEval("selenium.page().getDocument().getElementsByTagName('html')[0].innerHTML");
      writer.write(source);
      writer.close();
      cells.addToBody(": <a href=\"/files/dump/" + dumpFile.getName() + "\">Dump Results</a>");
      right(cells);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public void checkbox() {
    String boxName = getParam(1, "checkboxName");
    String boxValue = getParam(2, "checkboxValue");

    String identifier = "name=" + boxName;
    boolean boxValueBool = getValueForBoolean(boxValue);
    if (boxValueBool) {
      bot.check(identifier);
    } else {
      bot.uncheck(identifier);
    }

    right(cells);
  }

  public void cssclass() {
    String controlType = getParam(1, "controlType");
    String controlName = getParam(2, "controlName");
    String expectedClass = getParam(3, "expectedClass");

    if ("id".equalsIgnoreCase(controlType)) {
      if (controlExists(controlName)) {
        List<String> cssClasses = getCSSClasses(controlName);
        if (cssClasses.contains(expectedClass)) {
          right(cells.more.more.more);
        } else {
          wrong(cells.more.more.more, cssClasses.toString());
        }
      } else {
        wrong(cells.more.more, "- id '" + controlName + "' not found -");
      }
    } else {
      wrong(cells.more, "id");
    }
  }

  private boolean controlExists(String id) {
    String expression = "window.document.getElementById('" + id + "')";
    String value = bot.getEval(expression);
    return (value != null && value.length() != 0 && !value.equalsIgnoreCase("null"));
  }

  private List<String> getCSSClasses(String id) {
    String expression = "window.document.getElementById('" + id + "').className";

    String cssClasses = bot.getEval(expression);
    StringTokenizer tokenizer = new StringTokenizer(cssClasses, " ", false);
    List<String> classList = new ArrayList<String>();
    while (tokenizer.hasMoreTokens()) {
      classList.add(tokenizer.nextToken());
    }

    return classList;
  }

  private boolean getValueForBoolean(String boxValue) {
    String[] trueValues = {"T", "TRUE", "YES", "Y", "ON", "1"};
    String[] falseValues = {"F", "FALSE", "NO", "N", "OFF", "0", "NIL"};
    List<String> trueList = Arrays.asList(trueValues);
    List<String> falseList = Arrays.asList(falseValues);

    if (trueList.contains(boxValue.toUpperCase())) {
      return true;
    } else if (falseList.contains(boxValue.toUpperCase())) {
      return false;
    } else {
      throw new IllegalArgumentException("Unknown value for checkbox: " + boxValue + ".  Use either ON or OFF.");
    }
  }

  public void clickButton() {
    String linkIdType = getParam(1, "linkIdType");
    if ("id".equals(linkIdType)) {
      String buttonId = getParam(2, "linkId");
      clickButton(buttonId);
      right(cells);
    } else {
      wrong(cells.more, "id");
    }
  }

  public void clickLink() {
    String linkIdType = getParam(1, "linkIdType");
    String linkId = getParam(2, "linkId");
    clickLink(linkIdType, linkId);
    right(cells);
  }

  public void clickRadio() {
    String fieldName = getParam(1, "fieldName");
    String value = getParam(2, "value");
    String xpath = "//input[@type='radio' and @name='" + fieldName + "' and @value='" + value + "']";
    clickLink("xpath", xpath);
    right(cells);
  }

  public void select() {
    String fieldId = getParam(1, "fieldId");
    String fieldValue = getParam(2, "fieldValue");
    bot.select(fieldId, fieldValue);
    right(cells);
  }

  public void selectOption() {
    String fieldId = getParam(1, "fieldId");
    String fieldValue = getParam(2, "fieldValue");
    bot.addSelection(fieldId, fieldValue);
    right(cells);
  }

  public void deselectOption() {
    String fieldId = getParam(1, "fieldId");
    String fieldValue = getParam(2, "fieldValue");
    bot.removeSelection(fieldId, fieldValue);
    right(cells);
  }

  private boolean doesSelectOptionExist() {
    String fieldId = getParam(1, "fieldId");
    String fieldValue = getParam(2, "fieldValue");
    String[] options = bot.getSelectOptions(fieldId);
    for (String option : options) {
      if (option.equals(fieldValue)) {
        return true;
      }
    }

    return false;
  }

  public void selectExists() {
    if (doesSelectOptionExist()) {
      right(cells);
    } else {
      wrong(cells);
    }
  }

  public void selectNotExists() {
    if (doesSelectOptionExist()) {
      wrong(cells);
    } else {
      right(cells);
    }
  }

  public void type() {
    String fieldId = getParam(1, "fieldId");
    String fieldValue = getParam(2, "fieldValue");
    bot.type(fieldId, fieldValue);
    right(cells);
  }

  public void store() {
    String variableId = getParam(1, "variableId");
    String controlValue = resolver.getValue(2);
    setVariable(variableId, controlValue);

    cells.more.addToBody(" = " + controlValue);
    right(cells.more);
  }

  private void compare(ValueComparator comparator) {
    String controlValue = resolver.getValue(1);
    String expectedValue = getParam(3, "expectedValue");
    if (comparator.compare(expectedValue, controlValue)) {
      right(cells.more.more.more);
    } else {
      wrong(cells.more.more.more, controlValue);
    }
  }

  private void radioCompare(boolean expected) {
    String fieldName = getParam(1, "fieldName");
    String value = getParam(2, "value");
    if (radioChecked(fieldName, value) == expected) {
      right(cells);
    } else {
      wrong(cells);
    }
  }

  public void radioChecked() {
    radioCompare(true);
  }

  public void radioUnchecked() {
    radioCompare(false);
  }

  private boolean radioChecked(String fieldName, String value) {
    return bot.isChecked("name=" + fieldName + " value=" + value);
  }

  private void clickButton(String buttonId) {
    String linkLocator = "//input[@id='" + buttonId + "']";
    click(linkLocator);
  }

  private void clickLink(String linkIdType, String linkId) {
    String xpathFragment = getLinkXPath(linkIdType);
    String linkLocator = getLinkLocator(linkId, xpathFragment);
    click(linkLocator);
  }

  private void click(String linkLocator) {
    bot.click(linkLocator);
    waitForPageLoad();
  }

  public void sleep() {
    int waitMS = Integer.parseInt(getParam(1, "waitMS"));
    try {
      Thread.sleep(waitMS);
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
    right(cells.more);
  }

  private void waitForPageLoad() {
    //todo this should be made to wait for the minimum amount of time (subject to a timeout)
    try {
      Thread.sleep(6000);
    } catch (InterruptedException e) {
      e.printStackTrace();  //todo handle this e
    }
    //todo bot.waitForPageToLoad(10000);
  }

  private String getLinkLocator(String linkId, String xpathFragment) {
    String linkLocator;
    if (xpathFragment == null) {
      linkLocator = linkId;
    } else {
      linkLocator = "//a[" + xpathFragment + "='" + linkId + "']";
    }
    return linkLocator;
  }

  private String getLinkXPath(String linkIdType) {
    String xpathFragment;
    if ("name".equalsIgnoreCase(linkIdType)) {
      xpathFragment = "text()";
    } else if ("id".equalsIgnoreCase(linkIdType)) {
      xpathFragment = "@id";
    } else if ("xpath".equalsIgnoreCase(linkIdType)) {
      xpathFragment = null;
    } else {
      throw new IllegalArgumentException("Unknown link id type: " + linkIdType);
    }
    return xpathFragment;
  }

  private void startSeleniumClient(String url, int seleniumPort) {
    if (bot == null) {
      bot = createSeleniumDriver(url, seleniumPort);
      bot.start();
      botPort = seleniumPort;
    } else {
      if (botPort != seleniumPort) {
        throw new IllegalArgumentException("Cannot change user context in the middle of a test");
      }
    }
  }

  private void shutDownSeleniumClient() {
    synchronized (RCCustomFixture.class) {
      if (bot != null) {
        bot.stop();
        bot = null;
      }
    }
  }

  private SeleniumBot createSeleniumDriver(String url, int seleniumPort) {
    return new SeleniumDriver("localhost", seleniumPort, "*iehta", url);
  }
}
