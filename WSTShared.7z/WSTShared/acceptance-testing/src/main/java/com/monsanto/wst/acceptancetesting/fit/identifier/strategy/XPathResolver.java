package com.monsanto.wst.acceptancetesting.fit.identifier.strategy;

import com.monsanto.wst.acceptancetesting.selenium.SeleniumBot;
import org.w3c.dom.Document;
import org.w3c.tidy.Tidy;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.util.Map;
/*
 XPathResolver was created on Mar 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class XPathResolver implements ResolverStrategy {
  private final Tidy tidyHtml;

  public XPathResolver() {
    this.tidyHtml = new Tidy();
    tidyHtml.setShowWarnings(false);
    tidyHtml.setQuiet(true);
  }

  public String getName() {
    return "xpath";
  }

//  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
//    return bot.getValue("xpath=" + controlId);
//  }

  public String resolve(String controlId, SeleniumBot bot, Map<String, String> variables) {
    Document doc = getDOM(bot);
    XPath xpath = XPathFactory.newInstance().newXPath();
    try {
      return xpath.evaluate(controlId, doc);
    } catch (XPathExpressionException e) {
      throw new RuntimeException(e);
    }
  }

  private Document getDOM(SeleniumBot bot) {
    String html = bot.getHtmlSource();
    return tidyHtml.parseDOM(new ByteArrayInputStream(html.getBytes()), null);
  }
}
