package com.monsanto.wst.acceptancetesting.fit.compare;
/*
 CaseInsensitiveComparator was created on Jan 18, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class CaseInsensitiveComparator implements ValueComparator {
  private final ValueComparator baseComparator;

  public CaseInsensitiveComparator(ValueComparator comparator) {
    baseComparator = comparator;
  }

  public boolean compare(String expectedValue, String actualValue) {
    return !baseComparator.compare(expectedValue.toUpperCase(), actualValue.toUpperCase());
  }
}
