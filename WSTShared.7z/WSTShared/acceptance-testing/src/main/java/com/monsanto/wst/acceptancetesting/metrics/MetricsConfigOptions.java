package com.monsanto.wst.acceptancetesting.metrics;

import java.util.ArrayList;
import java.util.List;
/*
 MetricsConfigOptions was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MetricsConfigOptions {
  private List<String> subDirs = new ArrayList<String>();

  public void addSubDir(String subDir) {
    subDirs.add(subDir);
  }

  public String[] getSubDirs() {
    return subDirs.toArray(new String[subDirs.size()]);
  }
}
