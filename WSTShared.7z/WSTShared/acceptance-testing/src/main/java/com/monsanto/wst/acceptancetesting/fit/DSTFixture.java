package com.monsanto.wst.acceptancetesting.fit;

import fit.ActionFixture;
import fit.Parse;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
/*
 DSTFixture was created on Feb 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class DSTFixture extends ActionFixture implements FitnesseParameters {
  private Map<String, String> variables = new HashMap<String,String>();

  public boolean hasParam(int paramNum) {
    Parse parse = cells;
    for (int i = 0; i < paramNum; i++) {
      if (parse.more == null) {
        return false;
      } else {
        parse = parse.more;
      }
    }

    return true;
  }

  public String getParam(int paramNum, String paramName) throws IllegalArgumentException {
    Parse parse = cells;
    for (int i = 0; i < paramNum; i++) {
      if (parse.more == null) {
        throw new IllegalArgumentException(paramName + " not specified");
      } else {
        parse = parse.more;
      }
    }

    return processVariables(parse.text());
  }

  private String processVariables(String raw) {
    StringBuffer buf = new StringBuffer();
    StringTokenizer tokenizer = new StringTokenizer(raw, "{}", true);
    boolean inVariable = false;
    while (tokenizer.hasMoreTokens()) {
      String token = tokenizer.nextToken();
      if ("{".equals(token)) {
        if (inVariable) {
          buf.append(token); // if a {{} is evaluated as {
        } else {
          inVariable = true;
        }
      } else if ("}".equals(token)) {
        if (inVariable) {
          inVariable = false;
        } else {
          buf.append(token); // if a {}} or } is evaluated as }
        }
      } else {
        if (inVariable) {
          buf.append(getVariable(token));
        } else {
          buf.append(token);
        }
      }
    }

    return buf.toString();
  }

  protected String getVariable(String variableName) {
    return variables.get(variableName);
  }

  protected void setVariable(String variableId, String value) {
    variables.put(variableId, value);
  }

  public Map<String, String> getVariables() {
    return variables;
  }
}
