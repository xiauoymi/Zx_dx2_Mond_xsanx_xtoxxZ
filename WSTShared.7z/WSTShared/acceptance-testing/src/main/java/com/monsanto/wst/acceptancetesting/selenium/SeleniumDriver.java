package com.monsanto.wst.acceptancetesting.selenium;

import com.thoughtworks.selenium.DefaultSelenium;

/**
 * Provides additional browser interaction methods for use in testing web applications.
 * <p/>
 * User: jdestes
 * Date: Mar 13, 2006
 * Time: 12:12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class SeleniumDriver extends DefaultSelenium implements SeleniumBot {
	private String webAppURL;
	private int defaultTimeout;

	/**
	 * @param seleniumHost Host where the selenium server is running
	 * @param seleniumPort Port where the selenium server is running
	 * @param browser      code Indicating what browser should be launched
	 * @param webAppURL    Base URL of the application under test
	 */
	public SeleniumDriver(String seleniumHost, int seleniumPort, String browser, String webAppURL) {
		super(seleniumHost, seleniumPort, browser, webAppURL);

    this.webAppURL = webAppURL;
		if (!this.webAppURL.endsWith("/")) {
			this.webAppURL += '/';
		}
		defaultTimeout = 15000;
	}

  public void stop() {
		super.stop();
		try {
			//This is (was?) needed because of a timing issue with the browser being closed
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Opens the provided url in the test frame.  If the path provided is a relative url,
	 * it will first be resolved using the base url of the application under test.
	 *
	 * @param path The url of the page to open (may be relative to the AUT)
	 */
	public void open(String path) {
		super.open(resolveUri(path));
	}

	/**
	 * Directly call a client side selenium action.  Provides access to client side selenium
	 * actions that have not been otherwise exposed.
	 *
	 * @param command The name of the action to call
	 * @param field   The first argument to pass to the action
	 * @param value   The second argument to pass to the action
	 * @return The result returned by the selenium action
	 */
	public String doCommand(String command, String field, String value) {
		return commandProcessor.doCommand(command, new String[]{field, value});
	}

	/**
	 * Resolves the provided uri using the url of the AUT.  If the provided path appears to be
	 * absolute, this method will return the provided path.
	 *
	 * @param path The path to resolve
	 * @return The resolved path.
	 */
	public String resolveUri(String path) {
		if (path.indexOf("://") == -1) {
			StringBuffer buff = new StringBuffer(webAppURL);
			if (path.startsWith("/")) {
				buff.append(path.substring(1));
			} else {
				buff.append(path);
			}

			return buff.toString();
		}
		return path;
	}

	/**
	 * Pause for the specified duration.
	 *
	 * @param duration The length of time to pause (in milliseconds).
	 */
	public void pause(int duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException e) {
		}
	}

	/**
	 * Wait until a popup window appears or the specified timeout has elapsed.
	 *
	 * @param windowId The ID of the popup window to wait for
	 * @param timeout  The maximum time to wait (in milliseconds).
	 */
	public void waitForPopUp(String windowId, int timeout) {
		super.waitForPopUp(windowId, "" + timeout);    //To change body of overridden methods use File | Settings | File Templates.
	}

	/**
	 * Waits for the current page load to completed or until the specified time has elapsed.
	 *
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForPageToLoad(int timeout) {
		super.waitForPageToLoad("" + timeout);
  }

	/**
	 * Execute the provided javascript snippet until the snippet evaluates to true or until
	 * the specified time has elapsed.  The script may get a reference to the window element
	 * for the AUT using the following:  this.page().currentWindow.  It may also find an element
	 * within the AUT using:  this.page().findElement(locator).
	 * <p/>
	 * For Example:
	 * bot.waitForCondition("return this.page().findElement('someElementId').currentStyle.display=='none';", 500);
	 * This will wait until the element whose id is "someElementId" is no longer
	 * visible (the currentStyle property has a display property value of 'none').
	 *
	 * @param script  The script to be executed
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForCondition(String script, int timeout) {
		super.waitForCondition(script, "" + timeout);
	}

	/**
	 * @param locator      The locator to use to find the target element
	 * @param propertyPath The property path (may be nested) of the property to evaluate
	 * @param regex        The regular expression that the value of the property should match
	 * @see SeleniumDriver#waitForPropertyMatch(String, String, String, int);
	 */
	public void waitForPropertyMatch(String locator, String propertyPath, String regex) {
		this.waitForPropertyMatch(locator, propertyPath, regex, getDefaultTimeout());
	}

	/**
	 * Wait until the element at the specified location has a property value that matches
	 * the provided regular expression or the specified time elapses.  The property may
	 * be a nested property of the element in which case the propertyPath will be
	 * dot-separated.
	 * <p/>
	 * For Example:
	 * bot.waitForPropertyMatch("someElementId", "currentStyle.display", "none");
	 * This will wait until the element whose id is "someElementId" is no longer
	 * visible (the currentStyle property has a display property value of 'none').
	 *
	 * @param locator      The locator to use to find the target element
	 * @param propertyPath The property path (may be nested) of the property to evaluate
	 * @param regex        The regular expression that the value of the property should match
	 * @param timeout      The maximum time to wait (in milliseconds).
	 */
	public void waitForPropertyMatch(String locator, String propertyPath, String regex, int timeout) {
		long start = System.currentTimeMillis();

		this.waitForElement(locator, timeout);

		do {
			String val = this.getProperty(locator, propertyPath);
			if (val.matches(regex)) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for '" + locator + "." + propertyPath + "' to match '" + regex + "'");
	}

	/**
	 * Determines if an option is present in a select element.
	 *
	 * @param locator Used to find the select element on the page
	 * @param label   The label to look for in the select element
	 * @return true if the label is present, false otherwise
	 */
	public boolean isOptionPresent(String locator, String label) {
		String[] opts = this.getSelectOptions(locator);
		for (int i = 0; i < opts.length; i++) {
			if (opts[i].equals(label)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param locator Used to find the select element on the page
	 * @see SeleniumDriver#waitForOptions(String, int)
	 */
	public void waitForOptions(String locator) {
		this.waitForOptions(locator, getDefaultTimeout());
	}

	/**
	 * Waits for the select to contain options or until the
	 *
	 * @param locator Used to find the select element on the page.
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForOptions(String locator, int timeout) {
		long start = System.currentTimeMillis();

		this.waitForElement(locator, timeout);

		do {
			String[] opts = this.getSelectOptions(locator);
			if (opts.length > 0 && !"".equals(opts[0].trim())) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for options for select '" + locator + "'");
	}

	/**
	 * Provides the default timeout to use in waitFor* methods that do not have a timeout parameter.
	 *
	 * @return The default timeout (in milliseconds)
	 */
	public int getDefaultTimeout() {
		return defaultTimeout;
	}

	public void setDefaultTimeout(int timeout) {
		this.defaultTimeout = timeout;
	}

	/**
	 * Determines if a select element has a particular option selected.
	 *
	 * @param locator Used to locate the select element on the page
	 * @param label   The label being tested for selection
	 * @return true if the label is selected, false otherwise
	 */
	public boolean isSelected(String locator, String label) {
		String[] labels = this.getSelectedLabels(locator);
		for (int i = 0; i < labels.length; i++) {
			if (label.equals(labels[i])) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Get the value of the specified property of an element.  The property may
	 * be a nested property of the element in which case the propertyPath will be
	 * dot-separated.
	 * <p/>
	 * For Example:
	 * bot.getProperty("someElementId", "currentStyle.display");
	 * This will find the element whose id is "someElementId" and return its
	 * currentStyle's display property value (which can be used to determine if
	 * the element is visible).
	 *
	 * @param locator      Used to locate the element
	 * @param propertyPath The property to be returned
	 * @return the value of the property for the element
	 */
	public String getProperty(String locator, String propertyPath) {
		locator = locator.replaceAll("'", "\\\\'");
		String expression = "var value = null; try{value = this.page().findElement('" + locator + "')." + propertyPath + "}catch(e){};var val = value;";
		return this.getEval(expression);
	}

	/**
	 * Set the selected value in a select element by the provided index.
	 *
	 * @param locator Used to locate the select element
	 * @param index   The index (zero-based) of the option to select
	 */
	public void selectByIndex(String locator, int index) {
		String[] opts = this.getSelectOptions(locator);
		this.select(locator, opts[index]);
	}

	/**
	 * @param locator Used to locate the element
	 * @see SeleniumDriver#waitForElement(String, int)
	 */
	public void waitForElement(String locator) {
		this.waitForElement(locator, this.getDefaultTimeout());
	}

	/**
	 * Wait for the specified element to be present on the page or until the specified
	 * time has elapsed.
	 *
	 * @param locator Used to locate the element
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForElement(String locator, int timeout) {
		long start = System.currentTimeMillis();
		do {
			if (this.isElementPresent(locator)) {
				return;
			}
			pause(250);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for element '" + locator + "'");
	}

	/**
	 * @see SeleniumDriver#waitForAlert(int)
	 */
	public void waitForAlert() {
		this.waitForAlert(this.getDefaultTimeout());
	}

  /**
	 * Wait for a javascript alert to popup on the screen or until the specified time
	 * has elapsed.
	 *
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForAlert(int timeout) {
		long start = System.currentTimeMillis();
		do {
			if (this.isAlertPresent()) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for alert.");
	}

	/**
	 * @see SeleniumDriver#waitForConfirmation(int)
	 */
	public void waitForConfirmation() {
		waitForConfirmation(this.getDefaultTimeout());
	}

	/**
	 * Waits for a confirmation dialog in the browser, or until the specified
	 * time has elapsed.
	 *
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForConfirmation(int timeout) {
		long start = System.currentTimeMillis();
		do {
			if (this.isConfirmationPresent()) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for confirmation.");
	}

	/**
	 * @param search The string that should appear in the url
	 * @see SeleniumDriver#waitForLocationContains(String, int)
	 */
	public void waitForLocationContains(String search) {
		this.waitForLocationContains(search, this.getDefaultTimeout());
	}

	/**
	 * Waits until the current url loaded in the browser contains the specified
	 * search string or until the specified time has elapsed.
	 *
	 * @param search  The string that should appear in the url
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForLocationContains(String search, int timeout) {
		long start = System.currentTimeMillis();
		do {
			String location = this.getLocation();
			if (location.indexOf(search) != -1) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for location to match '" + search + "'.");
	}

	/**
	 * @param title The title to wait for
	 * @see SeleniumDriver#waitForTitle(String, int)
	 */
	public void waitForTitle(String title) {
		this.waitForTitle(title, this.getDefaultTimeout());
	}

	/**
	 * Waits for the window title of the primary page for the AUT to be equal to the
	 * specified title string.
	 *
	 * @param title   The title to wait for
	 * @param timeout The maximum time to wait (in milliseconds).
	 */
	public void waitForTitle(String title, int timeout) {
		long start = System.currentTimeMillis();
        boolean titleFound = false;
        do {

            try {
                String currentTitle = this.getTitle();
                titleFound = title.equals(currentTitle);
            } catch (Exception e){
                // this is a catch for browsers not being ready to report a title
                System.out.println("Caught an exception while checking Title on Browser! Waiting until browser is ready...");
            }
            if (titleFound) {
				return;
			}
			pause(1000);
		} while (System.currentTimeMillis() - start < timeout);
		throw new RuntimeException("Timed out waiting for title to match '" + title + "'.");
	}
}
