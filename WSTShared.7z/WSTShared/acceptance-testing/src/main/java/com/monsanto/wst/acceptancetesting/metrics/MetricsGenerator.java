package com.monsanto.wst.acceptancetesting.metrics;

import java.io.*;
/*
 MetricsGenerator was created on Mar 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MetricsGenerator {
  public static final String CONTENT_FILENAME = "content.txt";
  public static final String PROPERTIES_FILENAME = "properties.xml";
  private static final String DST_DIR = "DevelopmentServices";
  private static final String METRICS_DIR = "DevServicesMetrics";
  private static final String METRICS_OUTPUT_FILE = "FitnesseMetrics\\" + CONTENT_FILENAME;
  private static final String METRICS_CONFIG_FILE = "MetricsConfig\\" + CONTENT_FILENAME;

  @SuppressWarnings({"UseOfSystemOutOrSystemErr"})
  public static void main(String[] args) throws IOException {
    if (args.length < 1) {
      System.err.println("syntax: java " + MetricsGenerator.class.getName() + " PATH_TO_ROOT_OF_REPOSITORY");
      return;
    }

    File repoRoot = new File(args[0]);
    if (!repoRoot.exists()) {
      System.err.println("Repository root was not found: " + args[0]);
      return;
    }

    File dstDirectory = new File(repoRoot, DST_DIR);
    if (!dstDirectory.exists()) {
      System.err.println("Dev Services root was not found: " + dstDirectory.getAbsolutePath());
      return;
    }

    File metricsDir = new File(dstDirectory, METRICS_DIR);
    if (!metricsDir.exists()) {
      System.err.println("Metrics dir root was not found: " + metricsDir.getAbsolutePath());
      return;
    }

    File metricsConfig = new File(metricsDir, METRICS_CONFIG_FILE);
    if (!metricsConfig.exists()) {
      System.err.println("Metrics config file was not found: " + metricsConfig.getAbsolutePath());
      return;
    }

    File metricsOutput = new File(metricsDir, METRICS_OUTPUT_FILE);
    if (!metricsOutput.exists()) {
      System.err.println("Metrics output file was not found: " + metricsConfig.getAbsolutePath());
      return;
    }

    MetricsConfigOptions options = readConfigOptions(metricsConfig);
    MetricsProcessor metricsProcessor = new MetricsProcessor(dstDirectory, options);
    FitnesseMetrics metrics = metricsProcessor.generateMetrics();
    metrics.report(new FileOutputStream(metricsOutput, false));
  }

  private static MetricsConfigOptions readConfigOptions(File metricsConfig) throws IOException {
    MetricsConfigOptions options = new MetricsConfigOptions();
    BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(metricsConfig)));
    String line = input.readLine();
    while (line != null) {
      String[] lineOptions = line.split("\\|");
      if (lineOptions.length == 1) {
        options.addSubDir(lineOptions[0]);
      } else {
        options.addSubDir(lineOptions[1]);
      }
      line = input.readLine();
    }
    input.close();

    return options;
  }

}
