package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 2:21:05 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject1 {

    private MockObject2Interface obj2;

    public MockObject1(MockObject2Interface obj2) {
        this.obj2 = obj2;
    }

    public MockObject2Interface getObj2() {
        return this.obj2;
    }

}
