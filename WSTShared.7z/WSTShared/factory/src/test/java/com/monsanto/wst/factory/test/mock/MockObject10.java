package com.monsanto.wst.factory.test.mock;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 8, 2006
 * Time: 8:45:02 AM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject10 {
    private List stringList;

    public MockObject10(List stringList) {

        this.stringList = stringList;
    }

    public List getStringList() {
        return stringList;
    }
}
