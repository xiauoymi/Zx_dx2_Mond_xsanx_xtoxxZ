package com.monsanto.wst.factory.test;

import com.monsanto.wst.factory.*;
import com.monsanto.wst.factory.test.mock.MockFactory1;
import com.monsanto.wst.factory.test.mock.MockDelegatingLocatorGenericFactory;
import junit.framework.TestCase;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: May 24, 2006
 * Time: 6:12:19 PM
 * <p/>
 * This class is an integration/acceptance test for the abstract class AbstractGenericeFactory.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractGenericFactoryAT extends TestCase {
    protected void setUp() throws Exception {
        super.setUp();
        AbstractGenericFactory.clear();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        AbstractGenericFactory.clear();
    }

    public void testGetInstanceXMLImpl() throws Exception {
        AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
        GenericFactory factory = AbstractGenericFactory.getInstance();
        assertNotNull(factory);
        assertEquals(XMLGenericFactory.class, factory.getClass());
    }

    public void testGetInstanceInvalidContext() throws Exception {
        AbstractGenericFactory.setContext("does.not.exist");
        try {
            AbstractGenericFactory.getInstance();
            fail("this should have thrown an exception");
        } catch (GenericFactoryInitializationException e) {
            assertEquals("Unable to initialize generic factory.", e.getMessage());
        }
    }

    public void testGetInstanceCustomImpl() throws Exception {
        AbstractGenericFactory.setImplementation("com.monsanto.wst.factory.test.AbstractGenericFactoryAT$MockGenericFactory");
        GenericFactory factory = AbstractGenericFactory.getInstance();
        assertNotNull(factory);
        assertEquals(MockGenericFactory.class, factory.getClass());
    }

    public void testGetInstanceNoContextOrImpl() throws Exception {
        try {
            AbstractGenericFactory.getInstance();
            fail("This should have thrown an exception.");
        } catch (GenericFactoryInitializationException e) {
            assertEquals("You must provide either a custom implementation or the path to the context xml file in order " +
                    "to create a GenericFactory.", e.getMessage());
        }
    }

    public void testSetImplementationInvalidImplementation() throws Exception {
        try {
            AbstractGenericFactory.setImplementation("java.lang.String");
            fail("this should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("The class at path: 'java.lang.String' is not an implementation of " +
                    "GenericFactory.", e.getMessage());
        }
    }

    public void testSetImplementationClassNotFound() throws Exception {
        try {
            AbstractGenericFactory.setImplementation("does.not.exist");
            fail("this should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("Unable to find GenericFactory implementation at path: 'does.not.exist'.", e.getMessage());
        }
    }

    public void testSetImplementationNull() throws Exception {
        try {
            AbstractGenericFactory.setImplementation(null);
            fail("this should have thrown an exception");
        } catch (IllegalArgumentException e) {
            assertEquals("The GenericFactory implementation path can not be empty or null.", e.getMessage());
        }
    }

    public void testGetInstanceDefaultCaching() throws Exception {
        AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
        GenericFactory factory1 = AbstractGenericFactory.getInstance();
        GenericFactory factory2 = AbstractGenericFactory.getInstance();
        assertEquals(factory1, factory2);
    }

    public void testClearCausesNewFactoryToBeCreated() throws Exception {
        AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
        GenericFactory factory1 = AbstractGenericFactory.getInstance();
        AbstractGenericFactory.clear();
        AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
        GenericFactory factory2 = AbstractGenericFactory.getInstance();
        assertNotSame(factory1, factory2);
    }

    public void testSetCachingToFalseTurnsOffCaching() throws Exception {
        AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
        AbstractGenericFactory.setCaching(false);
        GenericFactory factory1 = AbstractGenericFactory.getInstance();
        GenericFactory factory2 = AbstractGenericFactory.getInstance();
        assertNotSame(factory1, factory2);
    }

    public void testAddCustomFactoryAddsToDelegatingFactory() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.factory.test.mock.MockFactory1");
        MockDelegatingLocatorGenericFactory factory = (MockDelegatingLocatorGenericFactory) AbstractGenericFactory.getInstance();
        assertTrue(factory.containsFactory(MockFactory1.class));
    }

    public void testAddCustomFactoryDoesNotExist() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        try {
            AbstractGenericFactory.addCustomFactory("does.not.exist");
            fail("This should throw an exception.");
        } catch (IllegalArgumentException e) {
            // This should happen.
        }
    }

    public void testAddCustomFactoryIllegalAccess() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        try {
            AbstractGenericFactory.addCustomFactory(MockFactoryIllegalAccess.class.getName());
            fail("This should throw an exception.");
        } catch (IllegalArgumentException e) {
            // This should happen.
        }
    }

    public void testAddCustomFactoryInstantiationException() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        try {
            AbstractGenericFactory.addCustomFactory(MockAbstractFactory.class.getName());
            fail("This should throw an exception.");
        } catch (IllegalArgumentException e) {
            // This should happen.
        }
    }

    public void testAddCustomFactoryNotApplicationContainerAware() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        try {
            AbstractGenericFactory.addCustomFactory(MockFactoryNotApplicationContainerAware.class.getName());
            fail("This should throw an exception.");
        } catch (IllegalArgumentException e) {
            // This should happen.
        }
    }

    public void testAddCustomFactoryNull() throws Exception {
        AbstractGenericFactory.setImplementation(MockDelegatingLocatorGenericFactory.class.getName());
        try {
            AbstractGenericFactory.addCustomFactory(null);
            fail("This should throw an exception.");
        } catch (IllegalArgumentException e) {
            // This should happen.
        }
    }

    public static class MockGenericFactory implements GenericFactory {
        public MockGenericFactory() {
        }

        public Object getBean(String beanId) throws BeanInitializationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Object getBean(String beanId, Map runtimeDependencyMap) throws BeanInitializationException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void addBean(String beanId, Object obj, boolean isSingleton) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void addBeanAlias(String newBeanId, String oldBeanId) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
    }

    public static class MockFactoryIllegalAccess {
        private MockFactoryIllegalAccess() {
        }
    }

    public static abstract class MockAbstractFactory {
    }

    public static class MockFactoryNotApplicationContainerAware {
    }
}
