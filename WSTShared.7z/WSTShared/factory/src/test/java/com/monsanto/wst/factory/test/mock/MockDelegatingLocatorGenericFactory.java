package com.monsanto.wst.factory.test.mock;

import com.monsanto.wst.factory.DelegatingLocatorGenericFactory;
import com.monsanto.wst.factory.ApplicationContainerAware;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 8, 2007
 * Time: 3:57:49 PM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockDelegatingLocatorGenericFactory extends DelegatingLocatorGenericFactory {
    private List customFactoryList = new ArrayList();

    public void addFactory(ApplicationContainerAware customFactory) {
        this.customFactoryList.add(customFactory);
    }

    public boolean containsFactory(Class customFactory) {
        for (int i = 0; i < customFactoryList.size(); i++) {
            ApplicationContainerAware factory = (ApplicationContainerAware) customFactoryList.get(i);
            if (customFactory.equals(factory.getClass())) {
                return true;
            }
        }
        return false;
    }
}
