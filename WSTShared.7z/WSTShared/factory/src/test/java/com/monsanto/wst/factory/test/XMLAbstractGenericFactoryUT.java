package com.monsanto.wst.factory.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.factory.XMLGenericFactory;
import com.monsanto.wst.factory.test.mock.*;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 8:34:25 AM
 * <p/>
 * This class is a junit test case for the XMLApplicationContainer class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLAbstractGenericFactoryUT extends TestCase {
  public void testConstructor() throws Exception {
    GenericFactory container = getApplicationContainer();
    assertNotNull(container);
  }

  public void testCreateNoContextSpecified() throws Exception {
    try {
      XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
      new XMLGenericFactory("does.not.exist", xmlUtils, new XalanXPathUtils());
      fail("This should have thrown an exception.");
    } catch (FileNotFoundException e) {
      assertEquals("In order to use the XMLGenericFactory implementation, you must specify the xml context file in " +
          "the root classpath and it must be named 'does.not.exist'.", e.getMessage());
    }
  }

  public void testGetBean_Singleton() throws Exception {
    GenericFactory container = getApplicationContainer();
    Object obj1 = container.getBean("testSingletonBean");
    assertNotNull(obj1);
    Object obj2 = container.getBean("testSingletonBean");
    assertNotNull(obj2);
    assertEquals(obj1, obj2);
  }

  public void testGetBean_LayeredDependencies() throws Exception {
    GenericFactory container = getApplicationContainer();
    MockObject0 bean = null;
    bean = (MockObject0) container.getBean("testSingletonBean");
    assertNotNull(bean);
    assertNotNull(bean.getObj1());
    assertNotNull(bean.getObj2());
    assertNotNull(bean.getObj1().getObj2());
    Assert.assertEquals("someString", bean.getObj1().getObj2().getTestString());
  }

  public void testGetBean_NonSingleton() throws Exception {
    GenericFactory container = getApplicationContainer();
    MockObject0 obj1 = (MockObject0) container.getBean("testNonSingletonBean");
    assertNotNull(obj1);
    MockObject0 obj2 = (MockObject0) container.getBean("testNonSingletonBean");
    assertNotNull(obj2);
    assertNotSame(obj1, obj2);
  }

  public void testGetBean_DoesNotExist() throws Exception {
    GenericFactory container = getApplicationContainer();
    try {
      container.getBean("doesNotExist");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find bean with id: 'doesNotExist'", e.getMessage());
    }
  }

  public void testGetBean_ClassDoesNotExist() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject4");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find class with bean id: 'testObject4'", e.getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject4");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find class with bean id: 'testObject4'", e.getMessage());
    }
  }

  public void testGetBean_NoAttributesConstructorArg() throws Exception {
    GenericFactory container = getApplicationContainer();
    try {
      container.getBean("testObject5");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("You must specify either a value or a ref attribute for the constructor-arg element.",
          e.getMessage());
    }
  }

  public void testGetBean_PrivateConstructor() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject7");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to access constructor for object with id: 'testObject7'",
          e.getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject7");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to access constructor for object with id: 'testObject7'",
          e.getMessage());
    }
  }

  public void testGetBean_InvocationTargetException() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject16");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("This is to test the invocation target exception handling.", e.getCause().getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject16");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("This is to test the invocation target exception handling.", e.getCause().getMessage());
    }
  }

  public void testGetBeanWithDependencies_InvocationTargetException() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject8");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("This is to test the invocation target exception handling.", e.getCause().getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject8");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("This is to test the invocation target exception handling.", e.getCause().getMessage());
    }
  }

  public void testGetBean_InterfaceOrAbstract() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject9");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to instantiate object with id: 'testObject9'",
          e.getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject9");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to instantiate object with id: 'testObject9'",
          e.getMessage());
    }
  }

  public void testGetBean_WrongConstructor() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject10");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject10'",
          e.getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject10");
      fail("This should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject10'",
          e.getMessage());
    }
  }

  public void testGetBean_Prototype() throws Exception {
    MockObject3 obj1 = new MockObject3();
    MockObject3 obj2 = new MockObject3();
    Map runtimeMap = new HashMap();
    runtimeMap.put("request", obj1);
    runtimeMap.put("response", obj2);
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    container.getBean("testObject11", runtimeMap);
    logger.setLevel(Level.DEBUG);

    container.getBean("testObject11", runtimeMap);
  }

  public void testGetBean_TypeResolution() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    Object obj = container.getBean("testObject1");
    assertNotNull(obj);
    logger.setLevel(Level.DEBUG);

    container.getBean("testObject1");
    assertNotNull(obj);
  }

  public void testBean_TypeMismatch() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);
    try {
      container.getBean("testObject12");
      fail("Should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject12'", e.getMessage());
    }
    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject12");
      fail("Should have thrown an exception.");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject12'", e.getMessage());
    }
  }

  public void testGetBean_ApplicationContainerAware() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);

    Object obj = container.getBean("testObject13");
    assertNotNull(obj);
    assertTrue(obj instanceof ApplicationContainerAware);
    assertNotNull(((MockObject8) obj).getApplicationContainer());
    logger.setLevel(Level.DEBUG);

    obj = container.getBean("testObject13");
    assertNotNull(obj);
    assertTrue(obj instanceof ApplicationContainerAware);
    assertNotNull(((MockObject8) obj).getApplicationContainer());
  }

  public void testGetBean_ApplicationContextAwareConstructorNotFound() throws Exception {
    GenericFactory container = getApplicationContainer();
    Logger logger = ((Log4JLogger) LogFactory.getLog(XMLGenericFactory.class)).getLogger();
    logger.setLevel(Level.OFF);

    try {
      container.getBean("testObject15");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject15'", e.getMessage());
    }

    logger.setLevel(Level.DEBUG);

    try {
      container.getBean("testObject15");
    } catch (BeanInitializationException e) {
      assertEquals("Unable to find constructor for bean with id: 'testObject15'", e.getMessage());
    }
  }

  public void testAddBean() throws Exception {
    Object obj = new Object();
    XMLGenericFactory container = getApplicationContainer();
    container.addBean("testNewObject", obj, false);
    Object retrievedObj = container.getBean("testNewObject");
    assertEquals(obj, retrievedObj);
  }

  public void testGetBeanWithListArgument() throws Exception {
    GenericFactory container = getApplicationContainer();
    MockObject10 obj = (MockObject10) container.getBean("testObject18");
    assertNotNull(obj);
    assertNotNull(obj.getStringList());
    assertEquals(2, obj.getStringList().size());
    assertEquals("test1", obj.getStringList().get(0));
    assertEquals("test2", obj.getStringList().get(1));
  }

  public void testGetBeanWithStringArrayArgument() throws Exception {
    GenericFactory container = getApplicationContainer();
    MockObject9 obj = (MockObject9) container.getBean("testObject17");
    assertNotNull(obj);
    assertNotNull(obj.getTestStrings());
    assertEquals(2, obj.getTestStrings().length);
    assertEquals("test1", obj.getTestStrings()[0]);
    assertEquals("test2", obj.getTestStrings()[1]);
  }

  private XMLGenericFactory getApplicationContainer() throws FileNotFoundException {
    try {
      XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
      return new XMLGenericFactory("com/monsanto/wst/factory/test/context.xml", xmlUtils, new XalanXPathUtils());
    } catch (XMLParserException e) {
      e.printStackTrace();
      fail("Unable to parse context file.");
    }

    return null;
  }

}
