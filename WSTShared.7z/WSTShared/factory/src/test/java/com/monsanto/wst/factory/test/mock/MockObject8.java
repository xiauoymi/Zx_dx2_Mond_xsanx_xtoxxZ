package com.monsanto.wst.factory.test.mock;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 21, 2005
 * Time: 9:45:46 AM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject8 implements ApplicationContainerAware {

    private GenericFactory container;

    public GenericFactory getApplicationContainer() {
        return this.container;
    }

    public void setApplicationContainer(GenericFactory container) {
        this.container = container;
    }

}
