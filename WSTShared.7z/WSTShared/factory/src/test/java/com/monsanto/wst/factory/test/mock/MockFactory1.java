package com.monsanto.wst.factory.test.mock;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 8, 2007
 * Time: 12:26:36 PM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockFactory1 implements ApplicationContainerAware {
    private GenericFactory container;

    public String getTest1() {
        return "test1";
    }

    public String getTest3() {
        return (String) this.container.getBean("test2");
    }

    public void setApplicationContainer(GenericFactory container) {
        this.container = container;
    }
}
