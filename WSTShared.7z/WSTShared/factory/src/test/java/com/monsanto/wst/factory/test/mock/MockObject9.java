package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 8, 2006
 * Time: 8:39:09 AM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject9 {
    private String[] testStrings;

    public MockObject9(String[] testStrings) {
        this.testStrings = testStrings;
    }

    public String[] getTestStrings() {
        return testStrings;
    }
}
