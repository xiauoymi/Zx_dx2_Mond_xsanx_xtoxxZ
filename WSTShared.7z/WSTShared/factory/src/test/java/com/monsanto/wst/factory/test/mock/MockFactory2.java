package com.monsanto.wst.factory.test.mock;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 8, 2007
 * Time: 12:27:09 PM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockFactory2 implements ApplicationContainerAware {
    public String getTest2() {
        return "test2";
    }

    public void setApplicationContainer(GenericFactory container) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
