package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 2:21:21 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject2 implements MockObject2Interface {

    private String testString;
    private MockObject3 obj3;
    private MockObject3 obj4;

    public MockObject2(String testString, MockObject3 obj3, MockObject3 obj4) {
        this.testString = testString;
        this.obj3 = obj3;
        this.obj4 = obj4;
    }

    public String getTestString() {
        return this.testString;
    }

    public MockObject3 getObj3() {
        return this.obj3;
    }

    public MockObject3 getObj4() {
        return this.obj4;
    }

}
