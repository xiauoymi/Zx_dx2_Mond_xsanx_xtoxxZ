package com.monsanto.wst.factory.test;

import com.monsanto.wst.factory.BeanInitializationException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Oct 3, 2005
 * Time: 11:40:38 AM
 * <p/>
 * Unit test for the BeanInitializationException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class BeanInitializationExceptionUT extends TestCase {

    public void testConstructorNoArgs() {
        BeanInitializationException e = new BeanInitializationException();
        assertNotNull(e);
    }

    public void testConstructorString() {
        BeanInitializationException e = new BeanInitializationException("This is a test exception.");
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
    }

    public void testConstructorStringThrowable() {
        Exception testE = new Exception("Test cause.");
        BeanInitializationException e = new BeanInitializationException("This is a test exception.", testE);
        assertNotNull(e);
        assertEquals("This is a test exception.", e.getMessage());
        assertEquals(testE, e.getCause());
    }

    public void testConstructorThrowable() {
        Exception cause = new Exception("Test cause.");
        BeanInitializationException e = new BeanInitializationException(cause);
        assertNotNull(e);
        assertEquals(cause, e.getCause());
    }

}
