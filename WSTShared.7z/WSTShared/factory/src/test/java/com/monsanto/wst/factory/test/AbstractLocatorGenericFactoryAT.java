package com.monsanto.wst.factory.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.AbstractLocatorGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.factory.GenericFactory;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Jun 12, 2006
 * Time: 5:28:37 PM
 * <p/>
 * This class is an integration/acceptance test for the abstract class AbstractLocatorGenericFactory.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AbstractLocatorGenericFactoryAT extends TestCase {
    protected void setUp() throws Exception {
        super.setUp();
    }

    public void testGetBeanString() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Object bean = factory.getBean("testBean");
        assertEquals("Test Result", bean);
    }

    public void testGetBeanStringMethodDoesNotExist() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("doesNotExist");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to locate accessor for bean with id 'doesNotExist'.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("doesNotExist");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to locate accessor for bean with id 'doesNotExist'.", e.getMessage());
        }
    }

    public void testGetBeanStringIllegalAccess() throws Exception {
        GenericFactory factory = new MockFactory(new MockObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("privateBean");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to access accessor for bean with id 'privateBean'.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("privateBean");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to access accessor for bean with id 'privateBean'.", e.getMessage());
        }
    }

    public void testGetBeanStringTargetThrowsException() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("testBeanThrowsException");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Bean with id 'testBeanThrowsException' threw an exception.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("testBeanThrowsException");
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Bean with id 'testBeanThrowsException' threw an exception.", e.getMessage());
        }
    }

    public void testGetBeanStringMap() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Map runtimeMap = new HashMap();
        runtimeMap.put("testValue", "Test Result");
        Object bean = factory.getBean("testBeanWithDependency", runtimeMap);
        assertEquals("Test Result", bean);
    }

    public void testGetBeanStringMapMethodDoesNotExist() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("doesNotExist", new HashMap());
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to locate accessor for bean with id 'doesNotExist'.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("doesNotExist", new HashMap());
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to locate accessor for bean with id 'doesNotExist'.", e.getMessage());
        }
    }

    public void testGetBeanStringMapIllegalAccess() throws Exception {
        GenericFactory factory = new MockFactory(new MockObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("privateTestBeanWithDependency", (Map) null);
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to access accessor for bean with id 'privateTestBeanWithDependency'.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("privateTestBeanWithDependency", (Map) null);
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Unable to access accessor for bean with id 'privateTestBeanWithDependency'.", e.getMessage());
        }
    }

    public void testGetBeanStringMapTargetThrowsException() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        Logger logger = ((Log4JLogger) LogFactory.getLog(AbstractLocatorGenericFactory.class)).getLogger();
        logger.setLevel(Level.DEBUG);
        try {
            factory.getBean("testBeanWithDependencyThrowsException", null);
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Bean with id 'testBeanWithDependencyThrowsException' threw an exception.", e.getMessage());
        }

        logger.setLevel(Level.OFF);
        try {
            factory.getBean("testBeanWithDependencyThrowsException", null);
            fail("This should have thrown an exception.");
        } catch (BeanInitializationException e) {
            assertEquals("Bean with id 'testBeanWithDependencyThrowsException' threw an exception.", e.getMessage());
        }
    }

    public void testAddBeanNonSingleton() throws Exception {
        GenericFactory factory = new MockFactory(new ObjectInspector());
        factory.addBean("testBean", "Test String", false);
        String value = (String) factory.getBean("testBean");
        assertEquals("Test String", value);
        // Thread local magic, hard to test beyond this.
    }

    public void testAddBeanSingleton() throws Exception {
        AbstractGenericFactory.setImplementation(MockFactory.class.getName());
        GenericFactory container1 = AbstractGenericFactory.getInstance();
        container1.addBean("testBean", "Test String", true);
        String value = (String) container1.getBean("testBean");
        assertEquals("Test String", value);
        GenericFactory container2 = AbstractGenericFactory.getInstance();
        value = (String) container2.getBean("testBean");
        assertEquals("Test String", value);
        AbstractGenericFactory.clear();
    }

    public void testGetBeanUsingAlias() throws Exception {
        AbstractGenericFactory.setImplementation(MockFactory.class.getName());
        GenericFactory container = AbstractGenericFactory.getInstance();
        String value = (String) container.getBean("/test");
        assertEquals("Test Result", value);
    }

    public static class MockFactory extends AbstractLocatorGenericFactory {
        public MockFactory() {
            super(new ObjectInspector());
            addBeanAlias("/test", "testBean");
        }

        public MockFactory(ObjectInspector objectInspector) {
            super(objectInspector);
        }

        public String getTestBean() {
            return "Test Result";
        }

        public String getTestBeanWithDependency(Map runtimeDependencyMap) {
            return (String) runtimeDependencyMap.get("testValue");
        }

        private String getPrivateTestBeanWithDependency(Map runtimeDependencyMap) {
            return (String) runtimeDependencyMap.get("testValue");
        }

        public String getTestBeanThrowsException() throws Exception {
            throw new Exception("Test Exception");
        }

        public String getTestBeanWithDependencyThrowsException(Map runtimeDependencyMap) throws Exception {
            throw new Exception("Test Exception");
        }

        private String getPrivateBean() {
            return "This bean should not be seen.";
        }
    }

    private class MockObjectInspector extends ObjectInspector {
        public Method getAccessor(String propertyName, Class clazz, boolean overridePermissions) throws NoSuchMethodException {
            Method method = super.getAccessor(propertyName, clazz, true);
            method.setAccessible(false);
            return method;
        }

        public Method getMethod(String methodName, Class clazz, Class[] types, boolean overridePermissions) throws NoSuchMethodException {
            return clazz.getDeclaredMethod(methodName, types);
        }
    }
}
