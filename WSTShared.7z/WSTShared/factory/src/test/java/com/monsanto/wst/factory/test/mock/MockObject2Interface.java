package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 20, 2005
 * Time: 4:26:06 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface MockObject2Interface {

    public String getTestString();

}
