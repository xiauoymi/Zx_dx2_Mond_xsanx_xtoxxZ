package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 5:23:54 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject5 {

    public MockObject5(String arg) throws Exception {
        throw new Exception("This is to test the invocation target exception handling.");
    }

    public MockObject5() throws Exception {
        throw new Exception("This is to test the invocation target exception handling.");
    }

}
