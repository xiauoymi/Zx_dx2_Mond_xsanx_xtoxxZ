package com.monsanto.wst.factory.test.mock;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 8:41:18 AM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockObject0 {

    private MockObject1 obj1;
    private MockObject2 obj2;

    public MockObject0(MockObject1 obj1, MockObject2 obj2) {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }

    public MockObject1 getObj1() {
        return this.obj1;
    }

    public MockObject2 getObj2() {
        return this.obj2;
    }

}
