package com.monsanto.wst.factory.test;

import junit.framework.TestCase;
import com.monsanto.wst.factory.DelegatingLocatorGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.factory.test.mock.MockFactory1;
import com.monsanto.wst.factory.test.mock.MockFactory2;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 8, 2007
 * Time: 12:24:28 PM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DelegatingLocatorGenericFactory_UT extends TestCase {
    public void testCreate() throws Exception {
        DelegatingLocatorGenericFactory factory = new DelegatingLocatorGenericFactory();
        assertNotNull(factory);
    }

    public void testGetBeanFrom2Factories() throws Exception {
        DelegatingLocatorGenericFactory factory = new DelegatingLocatorGenericFactory();
        factory.addFactory(new MockFactory1());
        factory.addFactory(new MockFactory2());
        assertEquals("test1", factory.getBean("test1"));
        assertEquals("test2", factory.getBean("test2"));
    }

    public void testGetBeanFromFactory1WithDependencyOnFactory2() throws Exception {
        DelegatingLocatorGenericFactory factory = new DelegatingLocatorGenericFactory();
        factory.addFactory(new MockFactory1());
        factory.addFactory(new MockFactory2());
        assertEquals("test2", factory.getBean("test3"));
    }

    public void testGetBeanDoesNotExistThrowsBeanInitializationException() throws Exception {
        DelegatingLocatorGenericFactory factory = new DelegatingLocatorGenericFactory();
        try {
            factory.getBean("doesNotExist");
            fail("This should throw an exception.");
        } catch (BeanInitializationException e) {
            // This should happen.
        }
    }
}
