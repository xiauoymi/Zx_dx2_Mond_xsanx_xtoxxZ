package com.monsanto.wst.factory.test;

import com.monsanto.wst.factory.GenericFactoryInitializationException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Nov 7, 2006
 * Time: 9:41:33 AM
 * <p/>
 * Unit test for the GenericFactoryInitializationException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class GenericFactoryInitializationException_UT extends TestCase {
  public void testCreate() throws Exception {
    GenericFactoryInitializationException exception = new GenericFactoryInitializationException("Test Message");
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
  }

  public void testCreateWithCause() throws Exception {
    Exception cause = new Exception();
    GenericFactoryInitializationException exception = new GenericFactoryInitializationException("Test Message", cause);
    assertNotNull(exception);
    assertEquals("Test Message", exception.getMessage());
    assertEquals(cause, exception.getCause());
  }
}
