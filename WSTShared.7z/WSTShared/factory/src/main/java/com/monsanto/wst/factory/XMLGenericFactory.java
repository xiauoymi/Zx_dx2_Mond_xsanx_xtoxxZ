package com.monsanto.wst.factory;

import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XPathUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 16, 2005
 * Time: 8:39:25 AM
 * <p/>
 * This class functions as an Inversion of Control/Dependency Infection Bean Factory.  It uses an xml based
 * configuration file in order to do object look-ups and resolves any dependencies.  It's purpose is to provide a
 * lightweight container around any application and to centralize object management and creation.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLGenericFactory implements GenericFactory {
    private static final Log log = LogFactory.getLog(XMLGenericFactory.class);
    private Document context;
    private Map singletonMap = new HashMap();
    private XMLUtilities xmlUtils;
    private XPathUtils xpathUtils;

    /**
     * This constructor takes the path to the xml configuration file and an XMLUtilities class.  It constructs a
     * DOM object based on the path and does any necessary initialization.
     * <p/>
     * The path to the xml file can be either a classpath, a file path or a URI.
     * Examples:
     * classpath = com/monsanto/ApplicationContainer/resources/context.xml
     * file path = C:/Documents And Settings/MyAccount/MyDocuments/context.xml
     * URI = /WEB-INF/conf/context.xml
     *
     * @param contextPath String representing the path to the xml context file.
     * @param xmlUtils    XMLUtilities object for performing tasks on xml.
     * @param xpathUtils  XpathUtils object representing xpath utility methods.
     * @throws com.monsanto.wst.commonutils.xml.XMLParserException
     *          - If unable to open or parse configuration file.
     */
    public XMLGenericFactory(String contextPath, XMLUtilities xmlUtils, XPathUtils xpathUtils) throws XMLParserException, FileNotFoundException {
        this.xpathUtils = xpathUtils;
//        try {
//            new ResourceUtils().convertPathToFile(contextPath);
//        } catch (FileNotFoundException e) {
//            throw new FileNotFoundException("In order to use the XMLGenericFactory implementation, you must specify the " +
//                    "xml context file in the root classpath and it must be named '" + contextPath + "'.");
//        }
      InputStream asStream = getClass().getClassLoader().getResourceAsStream(contextPath);
      if(asStream == null){
            throw new FileNotFoundException("In order to use the XMLGenericFactory implementation, you must specify the " +
                    "xml context file in the root classpath and it must be named '" + contextPath + "'.");
      }
      this.context = xmlUtils.createDocument(asStream);
        this.xmlUtils = xmlUtils;
    }

    /**
     * This method returns the bean with the specified id and all of it's dependencies resolved and injected.
     *
     * @param beanId String representing the id of the object requested.
     * @return Object - Representing the requested object.
     * @throws BeanInitializationException - If an exception occurred when calling the object's constructor.
     */
    public synchronized Object getBean(String beanId) throws BeanInitializationException {
        return getBean(beanId, new HashMap());
    }

    /**
     * This method returns the bean with the specified id and also provides a map of additional runtime dependencies.
     * This allows you to configure prototype objects in the configuration file.
     *
     * @param beanId               String representing the id of the object requested.
     * @param runtimeDependencyMap Map object representing any additional dependencies resolved at runtime.
     * @return Object - Representing the object mapped to the specified id.
     * @throws BeanInitializationException - If an exception occurred when calling the object's constructor.
     */
    public synchronized Object getBean(String beanId, Map runtimeDependencyMap) throws BeanInitializationException {
        if (!isSingleton(beanId)) {
            if (runtimeDependencyMap.containsKey(beanId)) {
                return runtimeDependencyMap.get(beanId);
            } else {
                Element beanElement = xmlUtils.getElementById(context, beanId);
                if (beanElement != null) {
                    return registerBean(beanElement, beanId, runtimeDependencyMap);
                } else {
                    throw new BeanInitializationException("Unable to find bean with id: '" + beanId + "'");
                }
            }
        }

        return getSingleton(beanId);
    }

    /**
     * This method will add the specified bean to the context with the specified id.  It will be treated as a quasi
     * singleton when accessed.  WARNING:  If a bean with the specified id already exists in the context, it will be
     * overridden.
     *
     * @param beanId      String representing the id of the bean.
     * @param obj         Object representing the object to be added to the context.
     * @param isSingleton boolean representing if the specified object is a singleton (currently only singletons are
     *                    supported for this implementation)
     */
    public void addBean(String beanId, Object obj, boolean isSingleton) {
        this.singletonMap.put(beanId, obj);
    }

    public void addBeanAlias(String newBeanId, String oldBeanId) {
        // TODO: Think about how this might be useful here.
    }

    /**
     * This method returns whether the object represented by the specified id is a cached singleton.
     *
     * @param beanId String representing the object id.
     * @return boolean - Representing if the object is a cached singleton.
     */
    private boolean isSingleton(String beanId) {
        return singletonMap.containsKey(beanId);
    }

    /**
     * This method returns the cached singleton object with the specified id.
     *
     * @param beanId String representing the object id.
     * @return Object - Representing the object.
     */
    private Object getSingleton(String beanId) {
        return singletonMap.get(beanId);
    }

    /**
     * This method takes a bean element from the configuration file and creates the object that bean represents with
     * all it's dependencies resolved.
     *
     * @param beanElement          Element object representing the object's configuration.
     * @param beanId               String representing the id of the bean.
     * @param runtimeDependencyMap Map object representing any runtime dependencies.
     * @return Object - Representing the configured object.
     * @throws BeanInitializationException - If an exception occurred when calling the object's constructor.
     */
    private Object registerBean(Element beanElement, String beanId, Map runtimeDependencyMap) throws BeanInitializationException {
        NodeList dependencyList = beanElement.getElementsByTagName("constructor-arg");
        Object[] dependencies = resolveDependencies(dependencyList, runtimeDependencyMap);
        return createBean(beanElement, dependencies, beanId);
    }

    /**
     * This method calls the constructor of the bean represeted by the specified bean element passing it all it's
     * dependencies already resolved.
     *
     * @param beanElement  Element object representing the object's configuration.
     * @param dependencies Object[] representing the constructor dependencies.
     * @param beanId       String representing the id of the object.
     * @return Object - Representing the instantiated object.
     * @throws BeanInitializationException - If an exception occurred when calling the object's constructor.
     */
    private Object createBean(Element beanElement, Object[] dependencies, String beanId) throws BeanInitializationException {
        try {
            Class clazz = Class.forName(beanElement.getAttribute("class"));
            String isSingleton = beanElement.getAttribute("singleton");
            Object obj = null;
            if (dependencies.length > 0) {
                Constructor constructor = findConstructor(clazz.getConstructors(), dependencies);
                obj = constructor.newInstance(dependencies);
            } else {
                try {
                    obj = clazz.newInstance();
                } catch (InstantiationException e) {
                    throw e;
                } catch (IllegalAccessException e) {
                    throw e;
                } catch (Throwable t) {
                    // Why oh why is class.getInstance different from constructor.getInstance?
                    throw new InvocationTargetException(t);
                }
            }
            if (isApplicationContainerAware(obj)) {
                setApplicationContainer(obj);
            }
            registerSingleton(obj, beanId, isSingleton);
            return obj;
        } catch (InstantiationException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to instantiate object with id: '" + beanId + "'. It might be a interface or an " +
                        "abstract class.", e);
            }
            throw new BeanInitializationException("Unable to instantiate object with id: '" + beanId + "'");
        } catch (IllegalAccessException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to access constructor for object with id: '" + beanId + "'", e);
            }
            throw new BeanInitializationException("Unable to access constructor for object with id: '" + beanId + "'");
        } catch (ClassNotFoundException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to find class with bean id: '" + beanId + "'", e);
            }
            throw new BeanInitializationException("Unable to find class with bean id: '" + beanId + "'");
        } catch (NoSuchMethodException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to find constructor for bean with id: '" + beanId + "'", e);
            }
            throw new BeanInitializationException("Unable to find constructor for bean with id: '" + beanId + "'");
        } catch (InvocationTargetException e) {
            if (log.isErrorEnabled()) {
                log.error("An exception occurred while attempting to instantiate bean with id: '" + beanId + "'",
                        e);
            }
            throw new BeanInitializationException("An exception occurred while attempting to instantiate bean " +
                    "with id: '" + beanId + "'", e.getCause());
        }
    }

    private boolean isApplicationContainerAware(Object obj) {
        return ApplicationContainerAware.class.isAssignableFrom(obj.getClass());
    }

    /**
     * This method caches the specified object if it is a singleton.
     *
     * @param obj         Object representing the object to cache.
     * @param beanId      String representing the id of the object.
     * @param isSingleton String representing if the object is a singleton.
     */
    private void registerSingleton(Object obj, String beanId, String isSingleton) {
        if (StringUtils.isEmpty(isSingleton) || new Boolean(isSingleton).booleanValue()) {
            singletonMap.put(beanId, obj);
        }
    }

    /**
     * This method calls the setter for the application container.
     *
     * @param obj Object to set application container to.
     * @throws NoSuchMethodException     - If the setter can not be found.
     * @throws IllegalAccessException    - If unable to access the setter.
     * @throws InvocationTargetException - If the setter throws an exception.
     */
    private void setApplicationContainer(Object obj)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Method method = obj.getClass().getMethod("setApplicationContainer", new Class[]{GenericFactory.class});
        method.invoke(obj, new Object[]{this});
    }

    /**
     * This method takes the specified bean node list of dependencies and instantiates them resolving any dependencies
     * they may have and returns them as an object[].
     *
     * @param dependencyList       NodeList object of bean elements.
     * @param runtimeDependencyMap Map object representing any runtime dependencies.
     * @return Object[] - Representing the instantiated dependencies.
     * @throws BeanInitializationException - If unable to invoke one of the constructors.
     */
    private Object[] resolveDependencies(NodeList dependencyList, Map runtimeDependencyMap) throws BeanInitializationException {
        Object[] dependencies = new Object[dependencyList.getLength()];
        for (int i = 0; i < dependencyList.getLength(); i++) {
            Element dependencyElement = (Element) dependencyList.item(i);
            if (StringUtils.isNotEmpty(dependencyElement.getAttribute("value"))) {
                dependencies[i] = dependencyElement.getAttribute("value");
            } else if (StringUtils.isNotEmpty(dependencyElement.getAttribute("ref"))) {
                dependencies[i] = getBean(dependencyElement.getAttribute("ref"), runtimeDependencyMap);
            } else if (this.xpathUtils.selectNodeList(dependencyElement, "list").getLength() == 1) {
                dependencies[i] = resolveList((Element) this.xpathUtils.selectNodeList(dependencyElement, "list").item(0));
            } else {
                throw new BeanInitializationException("You must specify either a value or a ref attribute for the " +
                        "constructor-arg element.");
            }
        }
        return dependencies;
    }

    private List resolveList(Element listElement) {
        List list = new ArrayList();
        NodeList valueElements = this.xpathUtils.selectNodeList(listElement, "value");
        for (int i = 0; i < valueElements.getLength(); i++) {
            list.add(((Element) valueElements.item(i)).getFirstChild().getNodeValue());
        }
        return list;
    }

    /**
     * This method takes an array of constructors and an array of instantiated dependencies and finds the constructor
     * that maps to those dependencies.
     *
     * @param constructors Constructor array of available constructors.
     * @param dependencies Object array of dependencies.
     * @return Constructor that maps to the specified dependencies.
     * @throws NoSuchMethodException - If unable to find an appropriate constructor.
     */
    private Constructor findConstructor(Constructor[] constructors, Object[] dependencies) throws NoSuchMethodException {
        for (int i = 0; i < constructors.length; i++) {
            Constructor constructor = constructors[i];
            Class[] types = constructor.getParameterTypes();
            if (types.length == dependencies.length) {
                boolean match = true;
                for (int j = 0; j < types.length; j++) {
                    if (dependencies[j] != null && List.class.isAssignableFrom(dependencies[j].getClass())
                            && types[j].isArray()) {
                        List list = (List) dependencies[j];
                        String[] argument = (String[]) Array.newInstance(String.class, list.size());
                        dependencies[j] = list.toArray(argument);
                    } else if (dependencies[j] != null && !types[j].isAssignableFrom(dependencies[j].getClass())) {
                        match = false;
                    }
                }

                if (match) {
                    return constructor;
                }
            }
        }

        throw new NoSuchMethodException("Unable to find constructor.");
  }
}
