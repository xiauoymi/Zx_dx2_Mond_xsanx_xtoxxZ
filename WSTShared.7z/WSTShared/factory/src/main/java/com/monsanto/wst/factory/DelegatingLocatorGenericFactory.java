package com.monsanto.wst.factory;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 8, 2007
 * Time: 12:25:19 PM
 * <p/>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DelegatingLocatorGenericFactory extends AbstractLocatorGenericFactory {
    private List factoryList = new ArrayList();

    public DelegatingLocatorGenericFactory() {
        super(new ObjectInspector());
    }

    public Object getBean(String beanId) throws BeanInitializationException {
        for (int i = 0; i < factoryList.size(); i++) {
            try {
                return super.getBean(beanId, factoryList.get(i));
            } catch (BeanInitializationException e) {
            }
        }
        throw new BeanInitializationException("Unable to locate bean with id '" + beanId + "'.");
    }

    public void addFactory(ApplicationContainerAware customFactory) {
        customFactory.setApplicationContainer(this);
        this.factoryList.add(customFactory);
    }
}
