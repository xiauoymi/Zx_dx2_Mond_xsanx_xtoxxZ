package com.monsanto.wst.factory;

/**
 * Created by IntelliJ IDEA.
 * Date: Nov 7, 2006
 * Time: 9:43:06 AM
 * <p/>
 * This exception is used for reporting issues in intializing a GenericFactory implementation.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class GenericFactoryInitializationException extends RuntimeException {
  /**
   * This constructor takes a message.
   *
   * @param message String representing the error message.
   */
  public GenericFactoryInitializationException(String message) {
    super(message);
  }

  /**
   * This constructor takes a message and a cause.
   *
   * @param message String representing the error message.
   * @param cause Throwable representing the cause of the exception.
   */
  public GenericFactoryInitializationException(String message, Throwable cause) {
    super(message, cause);
  }
}
