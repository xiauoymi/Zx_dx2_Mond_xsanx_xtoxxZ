package com.monsanto.wst.factory;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 24, 2006
 * Time: 6:21:45 PM
 * <p/>
 * This class uses the abstract factory pattern to allow the overriding of the type of GenericFactory created.  Look at
 * the getInstance(Object[] args) method for a definition of how to configure.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractGenericFactory implements GenericFactory {
    private static final Log log = LogFactory.getLog(AbstractGenericFactory.class);
    private static final XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());
    private static GenericFactory factory;
    private static boolean isCachingEnabled = true;
    private static Class implementation;
    private static String contextPath;


    /**
     * This method returns an instance of the current implementation of this factory.  You can define the system property
     * "com.monsanto.wst.factory.AbstractGenericFactory" to point to the fully qualified name of a
     * specific implementation, otherwise the default implementation will be created.
     *
     * ie. System.setProperty("com.monsanto.wst.factory.AbstractGenericFactory", "com.monsanto.wst.factory.MyGenericFactory");
     *
     * @return GenericFactory - Object representing the current configured implementation of this factory.
     */
    public static synchronized GenericFactory getInstance() {
        if (isCachingEnabled && factory == null) {
            factory = initializeFactory();
        } else if (!isCachingEnabled) {
            return initializeFactory();
        }
        return factory;
    }

    /**
     * This method clears the current cached GenericFactory instance.
     */
    public static void clear() {
        contextPath = null;
        implementation = null;
        factory = null;
        isCachingEnabled = true;
    }

    /**
     * This method enables or disables caching depending on the boolean specified.
     *
     * Note: Caching is enabled by default.
     *
     * @param caching boolean representing if caching should be enabled.
     */
    public static void setCaching(boolean caching) {
        isCachingEnabled = caching;
    }

    /**
     * This method sets the custom implementation to be used when the getInstance method is called.
     *
     * @param implementationPath String representing the path to the custom implementation.
     */
    public static void setImplementation(String implementationPath) {
        if (StringUtils.isEmpty(implementationPath)) {
            throw new IllegalArgumentException("The GenericFactory implementation path can not be empty or null.");
        }
        try {
            if (!GenericFactory.class.isAssignableFrom(Class.forName(implementationPath))) {
                throw new IllegalArgumentException("The class at path: '" + implementationPath + "' is not an implementation of " +
                        "GenericFactory.");
            }
            implementation = Class.forName(implementationPath);
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("Unable to find GenericFactory implementation at path: '" +
                    implementationPath + "'.");
        }
    }

    /**
     * This method sets the path of the context xml file to be used.
     *
     * @param path String representing the path to the context xml file.
     */
    public static void setContext(String path) {
        contextPath = path;
    }

    public static void addCustomFactory(String path) {
        if (StringUtils.isEmpty(path)) {
            throw new IllegalArgumentException("The custom factory path can not be null.");
        }
        try {
            Class factoryType = Class.forName(path);
            ((DelegatingLocatorGenericFactory) getInstance()).addFactory((ApplicationContainerAware) factoryType.newInstance());
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("Unable to find custom factory at path: '" + path + "'");
        } catch (IllegalAccessException e) {
            throw new IllegalArgumentException("Unable to access class at path: '" + path + "'");
        } catch (InstantiationException e) {
            throw new IllegalArgumentException("Unable to instantiate class at path: '" + path + "'");
        } catch (ClassCastException e) {
            throw new IllegalArgumentException("Class at path: '" + path + "' must be an implementation of ApplicationContainerAware.");
        }
    }

    /**
     * This method initializes the factory.
     *
     * @return GenericFactory - Object representing a new instance of the GenericFactory.
     */
    private static GenericFactory initializeFactory() {
        if (implementation != null) {
            return createCustomImpl();
        }
        if (StringUtils.isNotEmpty(contextPath)) {
            return createXMLImpl();
        }
        throw new GenericFactoryInitializationException("You must provide either a custom implementation or the path " +
                "to the context xml file in order to create a GenericFactory.");
    }

    /**
     * This method returns a new instance of the XML GenericFactory implementation.
     *
     * @return GenericFactory - Object representing the xml generic factory impl.
     */
    private static GenericFactory createXMLImpl() {
        try {
            return new XMLGenericFactory(contextPath, xmlUtils, new XalanXPathUtils());
        } catch (XMLParserException e) {
            throw new GenericFactoryInitializationException("Unable to initialize generic factory.", e);
        } catch (FileNotFoundException e) {
            throw new GenericFactoryInitializationException("Unable to initialize generic factory.", e);
        }
    }

    /**
     * This method returns a new instance of the custom generic factory implementation.
     *
     * @return GenericFactory - Object representing the custom generic factory impl.
     */
    private static GenericFactory createCustomImpl() {
        try {
            return (GenericFactory) implementation.newInstance();
        } catch (Exception e) {
            if (log.isWarnEnabled()) {
                log.warn("Unable to create GenericFactory implementation of type: '" + implementation.getName() + "'.", e);
            }
            throw new GenericFactoryInitializationException("Unable to create GenericFactory implementation of type: '" +
                    implementation.getName() + "'.", e);
        }
    }
}
