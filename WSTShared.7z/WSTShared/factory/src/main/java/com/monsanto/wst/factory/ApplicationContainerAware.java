package com.monsanto.wst.factory;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 21, 2005
 * Time: 9:43:30 AM
 * <p/>
 * This interface is used to define an object that is aware of it's application container.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ApplicationContainerAware {

    /**
     * This method provides the application container to the individual implementations.
     *
     * @param container Object representing the application container.
     */
    void setApplicationContainer(GenericFactory container);

}
