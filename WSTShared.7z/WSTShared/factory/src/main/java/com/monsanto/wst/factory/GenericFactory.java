package com.monsanto.wst.factory;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 23, 2005
 * Time: 9:11:32 AM
 * <p/>
 * This is an interface to define a contract for any application container implementations.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface GenericFactory {

    /**
     * This method returns the instantiated object with the specified id.
     *
     * @param beanId String representing the object id.
     * @return Object - Representing the instantiated object.
     * @throws BeanInitializationException - If Unable to invoke the object or one of it's dependencies.
     */
    Object getBean(String beanId) throws BeanInitializationException;

    /**
     * This method returns the instantiated object with the specified id and specified additional runtime dependencies.
     *
     * @param beanId String representing the object id.
     * @param runtimeDependencyMap Map object representing any additional runtime dependencies.
     * @return Object - Representing the instantiated object.
     * @throws BeanInitializationException - If Unable to invoke the object or one of it's dependencies.
     * @deprecated Use addBean or getBean(java.lang.String) instead.
     */
    Object getBean(String beanId, Map runtimeDependencyMap) throws BeanInitializationException;

    /**
     * This method will add the specified bean to the context with the specified id.  It will be treated as a quasi
     * singleton when accessed.  WARNING:  If a bean with the specified id already exists in the context, it will be
     * overridden.
     *
     * @param beanId String representing the id of the bean.
     * @param obj Object representing the object to be added to the context.
     * @param isSingleton boolean representing if the bean should be added as a singleton.
     */
    void addBean(String beanId, Object obj, boolean isSingleton);

    void addBeanAlias(String newBeanId, String oldBeanId);
}
