package com.monsanto.wst.factory;

/**
 * Created by IntelliJ IDEA.
 * Date: Oct 3, 2005
 * Time: 11:47:49 AM
 * <p/>
 * This class is a custom exception for defining application container bean initialization errors.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class BeanInitializationException extends RuntimeException {

    /**
     * No args constructor.
     */
    public BeanInitializationException() {
    }

    /**
     * This constructor takes the message to be displayed.
     *
     * @param message String representing the message.
     */
    public BeanInitializationException(String message) {
        super(message);
    }

    /**
     * This constructor takes the message to be displayed and the underline cause of the exception.
     *
     * @param message String representing the message.
     * @param cause Throwable object representing the cause.
     */
    public BeanInitializationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * This constructor takes the underline cause of the exception.
     *
     * @param cause Throwable object representing the cause.
     */
    public BeanInitializationException(Throwable cause) {
        super(cause);
    }
}
