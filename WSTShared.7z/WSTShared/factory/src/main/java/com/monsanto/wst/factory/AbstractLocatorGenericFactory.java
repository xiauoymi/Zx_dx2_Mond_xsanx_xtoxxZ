package com.monsanto.wst.factory;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. Date: Jun 12, 2006 Time: 5:32:10 PM <p/> This class is an abstract implementation of the
 * GenericFactory interface.  This object uses a service locator pattern to resolve factory methods by id.  You just
 * need to create a subclass of this object exposing your factory methods in getter notation.  Then reference that
 * object through the GenericFactory interface calling getBean with the id.  The id is everything after the get in your
 * factory method, ie.
 *
 * getMyService()'s id would by myService
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractLocatorGenericFactory implements GenericFactory {
    private static final Log log = LogFactory.getLog(AbstractLocatorGenericFactory.class);
    private ObjectInspector objectInspector;
    private ThreadLocal nonThreadSafeObjects = new ThreadLocal();
    private Map singletonMap = new HashMap();
    private Map beanAliasMap = new HashMap();

    /**
     * This constructor takes all dependencies.
     *
     * @param objectInspector ObjectInspector object tool for doing reflection and invocation.
     */
    public AbstractLocatorGenericFactory(ObjectInspector objectInspector) {
        this.objectInspector = objectInspector;
    }

    /**
     * This method returns the instantiated object with the specified id.
     *
     * @param beanId String representing the object id.
     *
     * @return Object - Representing the instantiated object.
     *
     * @exception BeanInitializationException - If Unable to invoke the object or one of it's dependencies.
     */
    public Object getBean(String beanId) throws BeanInitializationException {
        return getBean(beanId, this);
    }

    protected Object getBean(String beanId, Object parent) {
        Object obj = lookupNonThreadSafeObject(beanId);
        if (obj != null) {
            return obj;
        }
        if (singletonMap.containsKey(beanId)) {
            return singletonMap.get(beanId);
        }
        beanId = getBeanAlias(beanId);
        try {
            Method method = this.objectInspector.getAccessor(beanId, parent.getClass(), false);
            return method.invoke(parent, null);
        } catch (NoSuchMethodException e) {
            if (log.isDebugEnabled()) {
                log.debug("Unable to locate accessor for bean with id '" + beanId + "'.", e);
            }
            throw new BeanInitializationException("Unable to locate accessor for bean with id '" + beanId + "'.");
        } catch (IllegalAccessException e) {
            if (log.isDebugEnabled()) {
                log.debug("Unable to access accessor for bean with id '" + beanId + "'.", e);
            }
            throw new BeanInitializationException("Unable to access accessor for bean with id '" + beanId + "'.");
        } catch (InvocationTargetException e) {
            if (log.isDebugEnabled()) {
                log.debug("Bean with id '" + beanId + "' threw an exception.", e);
            }
            throw new BeanInitializationException("Bean with id '" + beanId + "' threw an exception.", e);
        }
    }

    private String getBeanAlias(String beanId) {
        String aliasedBeanId = (String) beanAliasMap.get(beanId);
        if (aliasedBeanId != null) {
            return aliasedBeanId;
        }
        return beanId;
    }

    /**
     * This method returns the instantiated object with the specified id and specified additional runtime dependencies.
     *
     * @param beanId               String representing the object id.
     * @param runtimeDependencyMap Map object representing any additional runtime dependencies.
     *
     * @return Object - Representing the instantiated object.
     *
     * @exception BeanInitializationException - If Unable to invoke the object or one of it's dependencies.
     */
    public Object getBean(String beanId, Map runtimeDependencyMap) throws BeanInitializationException {
        try {
            StringBuffer sb = new StringBuffer("get").append(StringUtils.capitalize(beanId));
            Method method = this.objectInspector.getMethod(sb.toString(), getClass(), new Class[]{Map.class}, false);
            return method.invoke(this, new Object[]{runtimeDependencyMap});
        } catch (NoSuchMethodException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to locate accessor for bean with id '" + beanId + "'.", e);
            }
            throw new BeanInitializationException("Unable to locate accessor for bean with id '" + beanId + "'.");
        } catch (IllegalAccessException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to access accessor for bean with id '" + beanId + "'.", e);
            }
            throw new BeanInitializationException("Unable to access accessor for bean with id '" + beanId + "'.");
        } catch (InvocationTargetException e) {
            if (log.isErrorEnabled()) {
                log.error("Bean with id '" + beanId + "' threw an exception.", e);
            }
            throw new BeanInitializationException("Bean with id '" + beanId + "' threw an exception.");
        }
    }

    /**
     * This method will add the specified bean to the context with the specified id.  It will be treated as a quasi
     * singleton when accessed.  WARNING:  If a bean with the specified id already exists in the context, it will be
     * overridden.
     *
     * @param beanId String representing the id of the bean.
     * @param obj Object representing the object to be added to the context.
     * @param isSingleton boolean representing if the bean should be added as a singleton.
     */
    public void addBean(String beanId, Object obj, boolean isSingleton) {
        if (!isSingleton) {
            Map threadSafeMap = (Map) this.nonThreadSafeObjects.get();
            if (threadSafeMap == null) {
                threadSafeMap = new HashMap();
            }
            threadSafeMap.put(beanId, obj);
            this.nonThreadSafeObjects.set(threadSafeMap);
        } else {
            singletonMap.put(beanId, obj);
        }
    }

    /**
     * This method retrieves a non-thread safe object from the container that was added using the addBean method. This
     * provides the ability to override any object or create dynamic container beans at runtime.
     *
     * @param beanId String representing the id of the bean.
     * @return Object - Representing the non thread safe object.
     */
    private Object lookupNonThreadSafeObject(String beanId) {
        Map nonThreadSafeMap = (Map) this.nonThreadSafeObjects.get();
        if (nonThreadSafeMap != null && nonThreadSafeMap.get(beanId) != null) {
            return nonThreadSafeMap.get(beanId);
        }
        return null;
    }

    public void addBeanAlias(String newBeanId, String oldBeanId) {
        beanAliasMap.put(newBeanId, oldBeanId);
    }
}
