/*
HealthControllerUT was created on Jan 22, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.applicationinfo.test;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.applicationinfo.HealthController;

/**
 * Filename:    $RCSfile: HealthControllerUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-07-19 18:45:47 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class HealthControllerUT extends TestCase{

    public void testCreateHealthController() throws Exception {
        UseCaseController healthController = new HealthController();
        MockUCCHelper helper = new MockUCCHelper(null);
        healthController.run(helper);
        assertTrue(helper.wasSentTo("/WEB-INF/jsp/shared/wst/health.jspx"));
    }
}