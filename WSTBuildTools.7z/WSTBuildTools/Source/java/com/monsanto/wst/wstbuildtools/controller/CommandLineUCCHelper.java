/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.controller;

import com.monsanto.ServletFramework.*;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import org.w3c.dom.Document;

import java.io.*;
import java.util.*;
import java.net.URL;

/**
 * Filename:    $RCSfile: CommandLineUCCHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-28 19:13:45 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class CommandLineUCCHelper implements UCCHelper {

  private OutputStream out;

  public CommandLineUCCHelper(OutputStream oStream){
    out = oStream;
  }

  public void setContentType(String contentType) {
  }

  public void applyStylesheet(Document xmlDoc, String xslURL) throws IOException {
  }

  public void applyStylesheet(Document xmlDoc, String xslURL, String contentType) throws IOException {
  }

  public void applyStylesheet(Document xmlDoc, String xsltURI, Map paramMap) throws IOException {
  }

  public void writeToFormattedWriter(FormattedWriter writer) throws IOException {
  }

  public void writeToExcel(Document xmlDoc, String xsltURI, Map paramMap) throws IOException {
  }

  public void writeToExcel(Document xmlDoc, String xsltURI) throws IOException {
  }

  public void writeToWord(final Document xmlDoc, final String xsltURI, final Map paramMap) throws IOException {
  }

  public void writeToWord(final Document xmlDoc, final String xsltURI) throws IOException {
  }

  public InputStream getInputStream(String url) throws IOException {
    return null;
  }

  public Enumeration getParameterNames() throws IOException {
    return null;
  }

  public OutputStream getBinaryStream() throws IOException {
    return out;
  }

  public PrintWriter getPrintWriter() throws IOException {
    return null;
  }

  public String getRequestParameterValue(String parameterName) throws IOException {
    return null;
  }

  public String[] getRequestParameterValues(String parameterName) throws IOException {
    return new String[0];
  }

  public Iterator getRequestAttributeNames() throws IOException {
    return null;
  }

  public Object getRequestAttributeValue(String attributeName) {
    return null;
  }

  public void setRequestAttributeValue(String name, Object value) {
  }

  public void removeRequestAttribute(String attributeName) {
  }

  public Iterator getSessionParameterNames() throws IOException {
    return null;
  }

  public Object getSessionParameter(String parameterName) {
    return null;
  }

  public HashMap getInitParameters() {
    return null;
  }

  public void reportError(String message) {
  }

  public void reportError(Throwable t) {
  }

  public void setSessionParameter(String name, Object value) {
  }

  public void removeSessionParameter(String cstrName) {
  }

  public void closeSession() {
  }

  public void clearSession() {
  }

  public String encodeURL(String cstrURL) {
    return null;
  }

  public String serverAuthorizedUser() {
    return null;
  }

  public void displayHTML_File(String cstrFileName) throws IOException {
  }

  public void include(String cstrTo) throws IOException {
  }

  public void forward(String cstrTo) throws IOException {
  }

  public ArrayList getClientFiles() throws IOException {
    return null;
  }

  public String getCurrentDirectory() {
    return null;
  }

  public File getTempDirectory() {
    return null;
  }

  public String getRealPath(String path) {
    return null;
  }

  public String setImportFileDir(String cstrDirectory) throws IOException {
    return null;
  }

  public String setImportFileDir(String cstrDirectory, boolean relative) throws IOException {
    return null;
  }

  public int setMaxImportFileSize(int iMaxSize) {
    return 0;
  }

  public String name() {
    return null;
  }

  public String getHeader(String name) {
    return null;
  }

  public String[] getHeaderNames() {
    return new String[0];
  }

  public void setHeader(String name, String value) {
  }

  public void writeXMLDocument(Document doc) {
  }

  public void writeXMLDocument(Document doc, String encoding) {
  }

  public void expire() {
  }

  public Object getContextAttribute(String name) {
    return null;
  }

  public void setContextAttribute(String name, Object object) {
  }

  public void removeContextAttribute(String name) {
  }

  public String requestedURL() {
    return null;
  }

  public void redirect(String cstrTo) throws IOException {
  }

  public HashMap getContextAttributes() {
    return null;
  }

  public URL getResource(String uri) throws IOException {
    return null;
  }

  public String getScratchFolder() {
    return null;
  }

  public void deleteScratchFolder() {
  }

  public boolean isSystemSecurityEnabled() {
    return false;
  }

  public String getAuthenticatedUserID() {
    return null;
  }

  public String getAuthenticatedUserFullName() {
    return null;
  }

  public int getFailedLogonAttempts() {
    return 0;
  }

  public Date getLastLogon() {
    return null;
  }

  public String getAuthenticatedUserDomain() {
    return null;
  }

  public boolean isUserInRole(String role) {
    return false;
  }

  public Cookie[] getClientCookies() {
    return new Cookie[0];
  }

  public Cookie[] getCookies(String dummyValue) {
    return new Cookie[0];
  }

  public javax.servlet.http.Cookie[] getCookies() {
    return new javax.servlet.http.Cookie[0];
  }

  public void addCookie(Cookie cookie) {
  }

  public SystemSecurityProxy getSystemSecurityProxy() {
    return null;
  }

  public void setMaxInactiveInterval(int iTimeOut) {
  }

  public String getServletName() {
    return null;
  }

  public String getPathInfo() {
    return null;
  }

  public FormRequestData getFormRequestData() throws BadFormDataException {
    return null;
  }

  public String getRequestURI() {
    return null;
  }

  public String getContextPath() {
    return null;
  }
}