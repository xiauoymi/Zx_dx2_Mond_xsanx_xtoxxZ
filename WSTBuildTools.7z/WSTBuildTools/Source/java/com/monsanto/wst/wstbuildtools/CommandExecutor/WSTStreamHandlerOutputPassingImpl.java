/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor;

import java.io.InputStream;
import java.io.PrintStream;

/**
 * Filename:    $RCSfile: WSTStreamHandlerOutputPassingImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-06 19:18:49 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class WSTStreamHandlerOutputPassingImpl extends BaseWSTStreamHandler {

  /**
   *
   * @param is: InputStream to monitor and read
   * @param os: This OutputStream must be emptied as it is being written to, otherwise the buffer may be
   * filled, causing this process to block. Thus it is a PrintStream.
   */

  public WSTStreamHandlerOutputPassingImpl(InputStream is, PrintStream os){
    super(is, os);
  }
}