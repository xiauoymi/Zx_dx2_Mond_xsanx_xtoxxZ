/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.controller;

import com.monsanto.wst.wstbuildtools.DBAccess.DeployDBAccessor;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: WSTBuildToolController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class WSTBuildToolController {

  private DeployDBAccessor DBAccessor;
  private InputStreamReader inputReader;

  //possible projects to deploy
  private static final String[] project_Names =
      {
          "BreedingComplaintsAudits",
          "ExternalTechRequests",
          "AccountVerification",
          "WST_SOIC_INTERNAL_CONTROLS",
          "WST_MANUFACT_COMPL_TOM4",
          "WST_IA_SYNC_SERVICE",
          "USSeedPlanning",
          "WST_IA_IAUDIT",
          "TourTrackingSystem",
          "SummaryReports",
          "HumanRightsPolicy"
      };
  
  private Object view;

  public WSTBuildToolController() {
    DBAccessor = new DeployDBAccessor();
    inputReader = new InputStreamReader(System.in);
  }


  public static void main(String[] argv){
//    if(argv.length==0){
      executeMenu();
//    }
//    else if(argv.length >= 2){
//      //executeCommand(args);
//    }
//    else{
//      System.out.println("Please Specify Correct Parameters or Invoke Menu System by using No Paramters");
//    }
  }

  private static void executeMenu(){
//    try{
      System.out.println("HelloWorld");
    //displayServers();
    //accept server choice
    //display possible projects to deploy based on server
    //accept project choice
    //if server == dev
      //cvs checkout
      //build
    //Send files to staging area
    //Launch repliweb job
    //Update DB
    //Update build.preperties file
    //Ask for user defined tag (optional tag)
    //write CVS tag
//    }catch(IOException io){
//      System.out.println(io.getMessage());
//    }
  }

  private String displayServers() throws IOException {
    char[] input = {};
    do{
      System.out.println("Please Choose Server to Deply To");
      System.out.println("1. Development");
      System.out.println("2. Test");
      System.out.println("3. Production");
      inputReader.read(input);
    } while (new String(input) != "1");
    return "Development";
  }

  private void displayAvailableProjects(String server){
    //view.displayProjects(getAvailableProjects(server));
  }

  private List<WSTDeployment> getAvailableProjects(String server){
    List<WSTDeployment> allDeployed = new ArrayList<WSTDeployment>();
    if(server.equals("Test")){
      for(String proj: project_Names){
        allDeployed.add(DBAccessor.getCurrDevDeployed(proj));
      }
    }
    else if(server.equals("Prod")){
      for(String proj: project_Names){
        allDeployed.add(DBAccessor.getCurrTestDeployed(proj));
      }
    }
    else{
      for(String proj: project_Names){
        allDeployed.add(new WSTDeployment(proj, "Head Revision", "None", "None", new Date(), -1));
      }
    }
    return allDeployed;
  }
}