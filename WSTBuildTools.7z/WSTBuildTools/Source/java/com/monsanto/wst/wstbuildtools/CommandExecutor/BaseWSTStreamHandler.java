/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: BaseWSTStreamHandler.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-06 19:18:49 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 * @description This class is only to clarify the use of the WSTStreamHandlers threads that extend
 *              this class. The constructor of this class sets the stream variables to null, so this class
 *              will not do anything. One of the implementations must be used.
 * @dependencies THIS THREAD MUST BE EXPLICITLY ENDED BY CALLING THE Stop FUNCTION.
 */
public abstract class BaseWSTStreamHandler extends Thread {

  private final InputStream is;
  private final OutputStream os;
  private boolean started;
  private boolean stopped;

  protected BaseWSTStreamHandler(InputStream is, OutputStream os){
    this.is = is;
    this.os = os;
    started = false;
    stopped = false;
  }
  
  public void run(){
    super.run();
    int data = 0;
    try{
      while(!isStopped() || is.available()>0){
        synchronized(this) {
          started = true;
        }
        while ((data = is.read()) != -1) {
          os.write(data);
        }
        os.flush();
      }
    }
    catch(IOException ioE){
      ioE.printStackTrace();
    }
  }

  public boolean isStarted() {
    synchronized(this) {
      return started;
    }
  }

  /**
   * @description Will cause this thread to end as soon as the InputStream provided runs empty.
   */
  public void stopWhenBufferEmpties() {
    synchronized(this) {
      this.stopped = true;
    }
  }

  public boolean isStopped() {
    synchronized(this) {
      return stopped;
    }
  }

  protected InputStream getIs() {
    return is;
  }

  protected OutputStream getOs() {
    return os;
  }
}