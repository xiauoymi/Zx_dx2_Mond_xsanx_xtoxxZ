/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor.test;

import com.monsanto.wst.wstbuildtools.CommandExecutor.WSTStreamHandlerOutputHoldingImpl;
import com.monsanto.wst.wstbuildtools.CommandExecutor.WSTStreamHandlerOutputPassingImpl;
import com.monsanto.wst.wstbuildtools.CommandExecutor.BaseWSTStreamHandler;
import junit.framework.TestCase;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Filename:    $RCSfile: WSTStreamHandler_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-07 18:57:46 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class WSTStreamHandler_UT extends TestCase {

  public void testHandlerStoresOutput() throws Exception {
    InputStream is = new ByteArrayInputStream(new byte[]{'a','b','c'});
    WSTStreamHandlerOutputHoldingImpl handler = new WSTStreamHandlerOutputHoldingImpl(is);
    handler.start();
    waitForHandlerToStart(handler);
    handler.stopWhenBufferEmpties();
    handler.join();
    byte[] out = handler.getOutput();
    assertTrue(out.length==3);
    assertTrue(out[0]=='a');
    assertTrue(out[1]=='b');
    assertTrue(out[2]=='c');
  }

  private void waitForHandlerToStart(BaseWSTStreamHandler handler) throws InterruptedException {
    while (!handler.isStarted()) {
      Thread.sleep(10);
    }
  }

  public void testHandlerPassesOutput() throws Exception {
    InputStream is = new ByteArrayInputStream(new byte[]{'a','b','c'});
    ByteArrayOutputStream os = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(os);
    WSTStreamHandlerOutputPassingImpl handler = new WSTStreamHandlerOutputPassingImpl(is, ps);
    handler.start();
    waitForHandlerToStart(handler);
    handler.stopWhenBufferEmpties();
    handler.join();
    assertTrue(os.size()==3);
  }

  public void testHandlerContinuesUntilToldToStop() throws Exception {
    InputStream is = new ByteArrayInputStream(new byte[]{});
    BaseWSTStreamHandler handler = new WSTStreamHandlerOutputHoldingImpl(is);
    handler.start();
    waitForHandlerToStart(handler);
    assertTrue(handler.isAlive());
    handler.stopWhenBufferEmpties();
    handler.join();
    assertFalse(handler.isAlive());
  }

}