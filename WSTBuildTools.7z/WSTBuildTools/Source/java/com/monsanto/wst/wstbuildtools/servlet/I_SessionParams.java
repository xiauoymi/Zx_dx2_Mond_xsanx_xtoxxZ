package com.monsanto.wst.wstbuildtools.servlet;



import java.io.File;




/**
 *
 * <p>Title: I_WSTBuildToolsSessionParams</p>
 * <p>Description: This will serve for constants for putting proposal session lists</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: I_SessionParams.java,v 1.1 2007-05-29 19:14:37 mterry Exp $
 */
public interface I_SessionParams
{
   /*  User roles  */
   public static final String sf_cstrSECURITY_GATEKEEPER = "WSTBuildToolsSecurityGatekeeper";
   public static final String sf_cstrCURRENT_USER        = "WSTBuildToolsUser";

   /*  Directories.  */
   public static final String sf_cstrCONFIG_DIR = "../Config";     // Properties files
   public static final String sf_cstrLINKFILES_DIR = "../linkfiles";  // Files for temp html links
   public static final String sf_cstrIMPORT_DIR = File.separator + "import";        // Uploaded files
   public static final String sf_cstrJAVASCRIPT_DIR = "../JavaScript"; // JavaScript files
   public static final String sf_cstrSTYLESHEET_DIR = "../Stylesheet"; // Stylesheets
   public static final String sf_cstrHTML_DIR = "../html";       // Static html files
   public static final String sf_cstrXML_SCHEMAS_DIR = "";
}
