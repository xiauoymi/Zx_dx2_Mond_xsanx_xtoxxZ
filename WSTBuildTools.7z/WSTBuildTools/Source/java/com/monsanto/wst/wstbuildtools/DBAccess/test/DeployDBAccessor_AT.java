/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.DBAccess.test;

import com.monsanto.wst.wstbuildtools.DBAccess.DeployDBAccessor;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTProject;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: DeployDBAccessor_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-24 17:39:13 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class DeployDBAccessor_AT extends TestCase {

  DeployDBAccessor DBAccessor;

  public void setUp() throws Exception{
    super.setUp();
    DBAccessor = new DeployDBAccessor();
  }

  public void testgetAllProjs_ReturnsAllProjects() throws Exception {

    List<WSTProject> testResult = DBAccessor.getAllProjs();
    WSTProject firstProject = testResult.get(0);

    assertNotNull(testResult);
    assertFalse(testResult.isEmpty());

    assertNotNull(firstProject);
  }

  public void testCheckUSSeedHasCorrectInfo() throws Exception {

    List<WSTProject> testResult = DBAccessor.getAllProjs();
    String usSeedCVSName = "USSeedPlanning";
    WSTProject usSeed = getProjectByName(testResult, usSeedCVSName);

    assertNotNull(testResult);
    assertFalse(testResult.isEmpty());
    
    assertNotNull(usSeed);
    assertEquals(usSeedCVSName, usSeed.getCvsName());
    assertEquals("usseedplanning", usSeed.getWarName());
  }

  private WSTProject getProjectByName(List<WSTProject> result, String cvsName) {
    for (WSTProject proj : result) {
      if (proj.getCvsName().equals(cvsName)) {
        return proj;
      }
    }

    return null;
  }

  public void testgetLastDeployedReturnsDeployment() throws Exception {

    WSTDeployment result = DBAccessor.getLastDeployed();

    assertTrue(result.getBuildNum() > 0);
  }


 //todo: These cannot be run as a continuous AT, as it will corrupt the DB
 //todo: Get Prod DB?

    //Note: This test is commented because:
    //       It will not work every time. The DB is not guaranteed to return the
    //       rows in the order they were submitted
//  public void testInsertDeploymentAddsOneDeploymentToDB() throws Exception {
//
//    List<WSTDeployment> testResult = DBAccessor.getAllDeployments();
//    int resultSizeBefore = testResult.size();
//
//    DBAccessor.insertDeployment(new WSTDeployment("USSeedPlanning","test","username", "test",new Date(),62));
//    testResult = DBAccessor.getAllDeployments();
//    int resultSizeAfter = testResult.size();
//
//    WSTDeployment testDeploy = testResult.get(testResult.size()-1); //get last row
//
//    assertTrue(resultSizeAfter == resultSizeBefore+1);
//    assertTrue(testDeploy.getBuildTag().equals("test"));
//    assertTrue(testDeploy.getUsername().equals("username"));
//  }
//
//  public void testInsertBuildAssignsBuildNum() throws Exception {
//    WSTBuild testBuild = new WSTBuild("USSeedPlanning");
//
//    DBAccessor.insertBuild(testBuild);
//
//    assertTrue(testBuild.getBuildNum()>0);
//  }
//
//  public void testUpdateandGetCurrDeployedReturnsCorrectly() throws Exception {
//
//    WSTDeployment testUpdate = DBAccessor.getLastDeployed();
//
//    DBAccessor.updateDevCurrDeployed(testUpdate);
//
//    WSTDeployment testGet = DBAccessor.getCurrDevDeployed("USSeedPlanning");
//
//    assertTrue(testUpdate.getProjName().equals(testGet.getProjName()));
//    assertTrue(testUpdate.getBuildTag().equals(testGet.getBuildTag()));
//    assertTrue(testUpdate.getUsername().equals(testGet.getUsername()));
//    assertTrue(testUpdate.getDate().equals(testGet.getDate()));
//  }
}