/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.DBAccess;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTProject;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTBuild;

import java.util.List;

/**
 * Filename:    $RCSfile: DeployDBAccessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @Description This class wraps the functionality of DBTemplate and the DeployDB xml Mappings in this package.
 * @version $Revision: 1.2 $
 */
public class DeployDBAccessor {
  private DBTemplate template;
  //These must be identical to the statement names in the QueryMapping.xml file
  public static final String GET_ALL_PROJECT_STATEMENT_NAME = "getAllProjs";
  public static final String INSERT_DEPLOYMENT_STATEMENT_NAME = "insertDeployment";
  public static final String GET_ALL_DEPLOYMENTS_STATEMENT_NAME = "getAllDeployments";
  public static final String GET_DEV_CURR_DEPLOYED_STATEMENT_NAME = "getCurrDevDeployed";
  public static final String GET_TEST_CURR_DEPLOYED_STATEMENT_NAME = "getCurrTestDeployed";
  public static final String GET_PROD_CURR_DEPLOYED_STATEMENT_NAME = "getCurrProdDeployed";
  public static final String UPDATE_DEV_CURR_DEPLOYED_STATEMENT_NAME = "updateDevCurrDeployed";
  public static final String UPDATE_TEST_CURR_DEPLOYED_STATEMENT_NAME = "updateTestCurrDeployed";
  public static final String UPDATE_PROD_CURR_DEPLOYED_STATEMENT_NAME = "updateProdCurrDeployed";
  public static final String GET_LAST_DEPLOYED_STATEMENT_NAME = "getLastDeployed";
  public static final String INSERT_BUILD_STATEMENT_NAME = "insertBuild";
  public static final String GET_LAST_BUILD_NUM_STATEMENT_NAME = "getLastBuild";


  //can specify own DBTemplate implementation (for testing)
  public DeployDBAccessor(DBTemplate template) {
    this.template = template;
  }

  public DeployDBAccessor() {
    this(new BuildToolsDBTemplate());
  }

  public List<WSTProject> getAllProjs() {
    //note: warning here because we can't make DBTemplate support Java 1.5 features
    return (List<WSTProject>) template.executeListResultQuery(GET_ALL_PROJECT_STATEMENT_NAME);
  }

  public void insertDeployment(WSTDeployment deployment) {
    template.executeInsert(INSERT_DEPLOYMENT_STATEMENT_NAME, deployment);
  }

  public List<WSTDeployment> getAllDeployments() {
    //note: warning here because we can't make DBTemplate support Java 1.5 features    
    return (List<WSTDeployment>) template.executeListResultQuery(GET_ALL_DEPLOYMENTS_STATEMENT_NAME);
  }

  public WSTDeployment getCurrDevDeployed(String project) {
    return (WSTDeployment) template.executeSingleResultQuery(GET_DEV_CURR_DEPLOYED_STATEMENT_NAME, project);
  }

  public WSTDeployment getCurrTestDeployed(String project) {
    return (WSTDeployment) template.executeSingleResultQuery(GET_TEST_CURR_DEPLOYED_STATEMENT_NAME, project);
  }

  public WSTDeployment getCurrProdDeployed(String project) {
    return (WSTDeployment) template.executeSingleResultQuery(GET_PROD_CURR_DEPLOYED_STATEMENT_NAME, project);
  }

  /**
   *
   * @param deployment: deployment must have buildNum specified. This means the deployment must be
   *        returned from the database, as this is the only way to get a valid buildNum. The project
   *        updated is the project the deployment is tied to.
   */
  public void updateDevCurrDeployed(WSTDeployment deployment) {
    template.executeUpdate(UPDATE_DEV_CURR_DEPLOYED_STATEMENT_NAME, deployment);
  }

  /**
   *
   * @param deployment: deployment must have buildNum specified. This means the deployment must be
   *        returned from the database, as this is the only way to get a valid buildNum. The project
   *        updated is the project the deployment is tied to.
   */
  public void updateTestCurrDeployed(WSTDeployment deployment) {
    template.executeUpdate(UPDATE_TEST_CURR_DEPLOYED_STATEMENT_NAME, deployment);    
  }

  /**
   *
   * @param deployment: deployment must have buildNum specified. This means the deployment must be
   *        returned from the database, as this is the only way to get a valid buildNum. The project
   *        updated is the project the deployment is tied to.
   */
  public void updateProdCurrDeployed(WSTDeployment deployment) {
    template.executeUpdate(UPDATE_PROD_CURR_DEPLOYED_STATEMENT_NAME, deployment);
  }

  public WSTDeployment getLastDeployed() {
    return (WSTDeployment) template.executeSingleResultQuery(GET_LAST_DEPLOYED_STATEMENT_NAME);
  }

  /**
   * @desc inserts build and assigns buildNum
   * @param build: build to be entered into the DB. The build will have the correct buildNum
   *        after this function executes.
   */
  public void insertBuild(WSTBuild build) {
    template.executeInsert(INSERT_BUILD_STATEMENT_NAME, build);
    Object result = template.executeSingleResultQuery(GET_LAST_BUILD_NUM_STATEMENT_NAME);
    if(result!=null){
      build.setBuildNum((Integer)result);
    }
    else{
      build.setBuildNum(-1);
    }
  }
}