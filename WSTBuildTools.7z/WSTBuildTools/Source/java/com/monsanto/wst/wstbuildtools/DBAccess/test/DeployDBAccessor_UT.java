/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.DBAccess.test;

import com.monsanto.wst.wstbuildtools.DBAccess.DeployDBAccessor;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTBuild;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: DeployDBAccessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-24 17:39:13 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class DeployDBAccessor_UT extends TestCase {

  MockDeployDBTemplate template;
  DeployDBAccessor DBAccessor;

  public void setUp() throws Exception{
    super.setUp();
    template = new MockDeployDBTemplate();
    DBAccessor = new DeployDBAccessor(template);
  }

  public void testDBTemplateIsCalledCorrectlyForGetAllProj() throws Exception {

    DBAccessor.getAllProjs();
    
    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_ALL_PROJECT_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForInsertDeployment() throws Exception {
    
    DBAccessor.insertDeployment(new WSTDeployment("test", "test", "test", "test", new Date(),0));
    
    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.INSERT_DEPLOYMENT_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForGetAllDeployments() throws Exception {

    DBAccessor.getAllDeployments();
    
    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_ALL_DEPLOYMENTS_STATEMENT_NAME));
  }
  
  public void testDBTemplateIsCalledCorrectlyForGetCurrDevDeployed() throws Exception {

    DBAccessor.getCurrDevDeployed("test");

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_DEV_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForGetCurrTestDeployed() throws Exception {

    DBAccessor.getCurrTestDeployed("test");

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_TEST_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForGetCurrProdDeployed() throws Exception {

    DBAccessor.getCurrProdDeployed("test");

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_PROD_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForUpdateCurrDeployed() throws Exception {

    DBAccessor.updateDevCurrDeployed(new WSTDeployment("test", "test", "test", "test", new Date(),0));

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.UPDATE_DEV_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForUpdateTestDeployed() throws Exception {

    DBAccessor.updateTestCurrDeployed(new WSTDeployment("test", "test", "test", "test", new Date(),0));

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.UPDATE_TEST_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForUpdateProdDeployed() throws Exception {

    DBAccessor.updateProdCurrDeployed(new WSTDeployment("test", "test", "test", "test", new Date(),0));

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.UPDATE_PROD_CURR_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIsCalledCorrectlyForGetLastDeployed() throws Exception {

    DBAccessor.getLastDeployed();

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.GET_LAST_DEPLOYED_STATEMENT_NAME));
  }

  public void testDBTemplateIscalledCorrectlyForInsertBuild() throws Exception {

    DBAccessor.insertBuild(new WSTBuild("test"));

    assertTrue(template.wasStatementNameCalled(DeployDBAccessor.INSERT_BUILD_STATEMENT_NAME));
  }
}