/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CVSAccess;

import com.monsanto.wst.wstbuildtools.CommandExecutor.CommandExecutor;
import com.monsanto.wst.wstbuildtools.CommandExecutor.OutputPassingCommandExecutorImpl;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: WSTProjCVSAccessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-11 15:58:54 $
 *
 * @author zznels
 * @version $Revision: 1.7 $
 */
public class WSTProjCVSAccessor {
  private boolean loggedIn = false;
  private String username;
  private String cvsCommandPrefix;
  private String lastCommandErrorOutput;

  public void finalize() {
    if(loggedIn){
      logout();
    }
  }

  public boolean login(String username, String password) {

    this.username = username;
    String cmd = "cvs -d :pserver:"+username+':'+password+
                 "@cvs01.monsanto.com:/export/home/repository -z 9 -w login";
    try {
      loggedIn = executeCommand(cmd, null);
      if(loggedIn){
        cvsCommandPrefix = "cvs -d :pserver:"+username+
                           "@cvs01.monsanto.com:/export/home/repository -z 9 -w ";
      }
    } catch (IOException e) {
      lastCommandErrorOutput += e.getMessage();
    }

    return loggedIn;
  }

  public boolean logout() {
    boolean ret = false;
    String cmd = "cvs -d :pserver:"+username+"@cvs01.monsanto.com:/export/home/repository -z 9 -w logout";
    try {
      if(executeCommand(cmd, null)){
        loggedIn = false;
        ret = true;
      }
    } catch (IOException e) {
      lastCommandErrorOutput += e.getMessage();
    }
    return ret;
  }

  public boolean isLoggedIn() {
    return loggedIn;
  }

  public boolean checkout(String projName) {
    boolean cmdSuccess = false;
    if(loggedIn){
      File cwd = new File("C:\\projects\\WSTBuildTools\\workspace");
      String cmd = cvsCommandPrefix+"checkout -A "+projName;
      try {
        cmdSuccess = executeCommand(cmd, cwd);
      } catch (IOException e) {
        lastCommandErrorOutput += e.getMessage();
      }
    }
    else{
      lastCommandErrorOutput = "Not logged into CVS";
    }
    return cmdSuccess;
  }

  public boolean checkoutByTag(String projName, String tag){
    boolean cmdSuccess = false;

    if(loggedIn){
      File cwd = new File("C:\\projects\\WSTBuildTools\\workspace");
      String cmd = cvsCommandPrefix+"checkout -r "+ tag + " -A " + projName;
      try {
        cmdSuccess = executeCommand(cmd, cwd);
      } catch (IOException e) {
        lastCommandErrorOutput += e.getMessage();
      }
    }
    else{
      lastCommandErrorOutput = "Not logged into CVS";
    }
    return cmdSuccess;
  }

  private boolean executeCommand (String cmd, File cwd) throws IOException{
    CommandExecutor executor = new OutputPassingCommandExecutorImpl(System.out);
    return executor.executeCommand(cmd, cwd);
  }

  public boolean tagCurrentCheckout(String projName, String tag) {
    boolean cmdSuccess = false;

    File cwd = new File("C:\\projects\\WSTBuildTools\\workspace\\"+projName+"\\Source\\java\\com\\monsanto\\wst\\"+projName);
    String cmd = cvsCommandPrefix+"tag "+tag;
    try {
      cmdSuccess = executeCommand(cmd, cwd);
    } catch (IOException e) {
      lastCommandErrorOutput += e.getMessage();
    }
    return cmdSuccess;
  }

  public String getLastCommandErrorOutput() {
    return lastCommandErrorOutput;
  }
}