/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor.test;

import junit.framework.TestCase;
import com.monsanto.wst.wstbuildtools.CommandExecutor.OutputPassingCommandExecutorImpl;

import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.IOException;

/**
 * Filename:    $RCSfile: OutputPassingCommandExecutor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-07 18:57:46 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class OutputPassingCommandExecutor_UT extends TestCase {

  ByteArrayOutputStream os;
  PrintStream ps;
  OutputPassingCommandExecutorImpl executor;

  public void setUp() throws Exception {
    super.setUp();
    os = new ByteArrayOutputStream();
    ps = new PrintStream(os);
    executor = new OutputPassingCommandExecutorImpl(ps);
  }

  public void testExecutorThrowsExceptionForBadCommand() throws Exception {
    try{
      executor.executeCommand("notacommand", new File("."));
      fail("Should Throw IOException When Executing Non Existant Command");
    } catch(IOException e){
    }
  }

}