/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.test;


import junit.framework.TestCase;
import junit.framework.Test;
import com.monsanto.testutil.TestCollector;

/**
 *
 * <p>Title: RunAllProjectUTs</p>
 * <p>Description: This test runs all Unit tests under the project specific package.</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: RunAllProjectUTs.java,v 1.1 2007-05-29 19:14:19 mterry Exp $
 */
public class RunAllProjectUTs extends TestCase {
  public static Test suite(){
    TestCollector testCollector =  new TestCollector();
    String[] packages = new String[1];
    packages[0] = "com.monsanto.wst.wstbuildtools";
    return testCollector.createSuiteOfTestCases(packages);
  }
}