/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.controller.test;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: WSTBuildToolsController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class WSTBuildToolsController_UT extends TestCase {

  public void testDisplayServerNames() throws Exception {
  }
}