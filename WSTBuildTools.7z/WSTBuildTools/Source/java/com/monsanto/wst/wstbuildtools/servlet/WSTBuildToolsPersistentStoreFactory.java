package com.monsanto.wst.wstbuildtools.servlet;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: WSTBuildToolsPersistentStoreFactory</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: WSTBuildToolsPersistentStoreFactory.java,v 1.2 2007-08-24 17:39:13 zznels Exp $
 */
public class WSTBuildToolsPersistentStoreFactory
{
   public static final String DEFAULT_BUNDLE        = "com.monsanto.wst.wstbuildtools.servlet.WSTBuildTools";
   public static final String PERSISTENT_STORE_NAME = "WSTBuildTools";

  /**
       * Returns a Persistent Store.
       *
       * @param cstrResourceBundleName The name of the resource bundle that points
       *                               to the correct database.
       * @return A PersistentStore object.
       * @throws WrappingException
       */
      public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
         Logger.traceEntry();

         ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
         PersistentStore RetVal = getPersistentStore(bundle);

         return (PersistentStore) Logger.traceExit(RetVal);
      }


      public static PersistentStoreConnection getDefaultConnection() throws WrappingException {
         final PersistentStore store = getStore(DEFAULT_BUNDLE);
         PersistentStore.registerInstance(WSTBuildToolsPersistentStoreFactory.PERSISTENT_STORE_NAME, store);

         return PersistentStore.instance(WSTBuildToolsPersistentStoreFactory.PERSISTENT_STORE_NAME).connect();
      }

      private static PersistentStore getPersistentStore(ResourceBundle bundle) throws WrappingException {
         String userName     = null;
         String sequenceName = null;
         String dataSource   = null;
         String password     = null;

         String storageEnvVariable = "MONCRYPTJV";

	//Todo: fix the three strings based on your project and remove the syntax error line
	//ToDo: & fix WSTBuildTools.properties file

        // this isn't being used for WSTBuildTools yet, set if/when it is

         String appFolderName      = "Needs to be set for project - application folder name";
         String encryptedFileName  = "Needs to be set for project - encrypted password file name";
         String keyFileName        = "Needs to be set for project - key file name";

         /*
            Example section from ResourceBundle

            dev.UserName=XXXXXXXX
            dev.DataSource=Devl
            dev.SequenceName=shared_code.SHARED_ID_SEQ
            dev.MinConnections=1
            dev.MaxConnections=3
            dev.Increment=1
         */
         try {
            userName     = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "UserName");
            sequenceName = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "SequenceName");
            dataSource   = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "DataSource");

            password = EncryptionUtils.GetDecryptedStringFromExternalStorage(storageEnvVariable,
                                                                             appFolderName,
                                                                             encryptedFileName,
                                                                             keyFileName);
         } catch (Exception e) {
            throw new WrappingException(e);
         }

         return new PersistentStoreOracleCachedType2(userName, password, dataSource, sequenceName);
      }

  }