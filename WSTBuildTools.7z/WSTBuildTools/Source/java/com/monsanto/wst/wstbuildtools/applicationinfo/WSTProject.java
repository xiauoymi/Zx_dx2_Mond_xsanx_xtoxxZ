/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.applicationinfo;

/**
 * Filename:    $RCSfile: WSTProject.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-24 17:39:13 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class WSTProject {
  private String cvsName = "";
  private String warName = "";
  private String email = "";

  public WSTProject() {
  }

  public WSTProject(String cvsName) {
    this.cvsName = cvsName;
  }

  public String getCvsName() {
    return cvsName;
  }

  public void setCvsName(String cvsName) {
    this.cvsName = cvsName;
  }

  public String getWarName() {
    return warName;
  }

  public void setWarName(String warName) {
    this.warName = warName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }
}