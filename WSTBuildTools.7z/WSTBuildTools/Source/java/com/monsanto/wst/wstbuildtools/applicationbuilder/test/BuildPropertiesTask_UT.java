/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.applicationbuilder.test;

import com.monsanto.wst.wstbuildtools.applicationbuilder.BuildPropertiesTask;
import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;
import junit.framework.TestCase;

import java.io.File;
import java.util.Date;

/**
 * Filename:    $RCSfile: BuildPropertiesTask_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class BuildPropertiesTask_UT extends TestCase {
  
  public void testProjectBuilder_CreatePropFile() throws Exception {
    File testFile = new File("C:\\projects\\WSTBuildTools\\workspace\\WSTBuildTools\\Source\\java\\com\\monsanto\\wst\\wstbuildtools\\applicationinfo\\build.properties");
    testFile.delete();
    WSTDeployment testRecord = new WSTDeployment("WSTBuildTools","Tag","username", "server",new Date(), 0);
    BuildPropertiesTask propFileBuilder = new BuildPropertiesTask(testRecord);
    propFileBuilder.execute();
    assertTrue(testFile.exists());
  }

  public void testProjectBuilder_CreateAppInfoDirWhenDoesntExist() throws Exception {
    File testDir = new File("C:\\projects\\WSTBuildTools\\workspace\\USSeedPlanning\\Source\\java\\com\\monsanto\\wst\\USSeedPlanning\\applicationinfo\\");
    testDir.delete();
    WSTDeployment testRecord = new WSTDeployment("USSeedPlanning","Tag","username", "server",new Date(), 0);
    BuildPropertiesTask propFileBuilder = new BuildPropertiesTask(testRecord);
    propFileBuilder.execute();
    assertTrue(testDir.exists());
  }
}