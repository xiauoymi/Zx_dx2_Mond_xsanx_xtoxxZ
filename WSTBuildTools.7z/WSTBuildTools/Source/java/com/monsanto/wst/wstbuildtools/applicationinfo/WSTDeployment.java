/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.applicationinfo;

import java.util.Date;

/**
 * Filename:    $RCSfile: WSTDeployment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-24 17:39:13 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class WSTDeployment {
  private Integer deployID = 0;
  private Integer buildNum = 0;
  private String projName = "";
  private String buildTag = "";
  private String username = "";
  private String server = "";
  private Date date;

  public WSTDeployment(String projName, String buildDesc, String username, String server, Date date, int buildNum) {
    this.projName = projName;
    this.buildTag = buildDesc;
    this.username = username;
    this.server = server;
    this.date = date;
    this.buildNum = buildNum;
  }

  public WSTDeployment() {
  }

  public String getBuildTag() {
    return buildTag;
  }

  public void setBuildTag(String buildTag) {
    this.buildTag = buildTag;
  }

  public String getProjName() {
    return projName;
  }

  public void setProjName(String projName) {
    this.projName = projName;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }

  public int getBuildNum() {
    return buildNum;
  }

  public void setBuildNum(Integer buildNum) {
    this.buildNum = buildNum;
  }

  public String getServer() {
    return server;
  }

  public void setServer(String server) {
    this.server = server;
  }

  public int getDeployID() {
    return deployID;
  }

  public void setDeployID(Integer deployID) {
    this.deployID = deployID;
  }
}