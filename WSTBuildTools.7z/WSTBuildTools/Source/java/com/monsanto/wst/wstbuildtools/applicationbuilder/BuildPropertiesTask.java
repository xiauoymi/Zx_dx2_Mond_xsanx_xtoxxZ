/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.applicationbuilder;

import com.monsanto.wst.wstbuildtools.applicationinfo.WSTDeployment;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: BuildPropertiesTask.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class BuildPropertiesTask extends Task {

  WSTDeployment localRecord;
  String srcDir;

  public void setLocalRecord(WSTDeployment record) {
    this.localRecord = record;
    srcDir = "C:\\projects\\WSTBuildTools\\workspace\\"+record.getProjName()+"\\Source";
  }

  public BuildPropertiesTask(){
  }

  public BuildPropertiesTask(WSTDeployment record) {
    localRecord=record;
    srcDir = "C:\\projects\\WSTBuildTools\\workspace\\"+record.getProjName()+"\\Source";
  }

  public void setSrcDir(String srcdir) {
    srcDir = srcdir;
  }

  private void writePropertyInfo(File bldFile) throws IOException {
    FileWriter writer = new FileWriter(bldFile);
    writer.write("build.number="+localRecord.getBuildNum()+"\n");
    writer.write("build.projectname="+localRecord.getProjName()+"\n");
    writer.write("build.username="+localRecord.getUsername()+"\n");
    writer.write("build.server="+localRecord.getServer()+"\n");
    writer.write("build.tag="+localRecord.getBuildTag()+"\n");
    writer.write("build.date="+localRecord.getDate().toString()+"\n");
    writer.close();
  }

  public void execute() throws BuildException {
    super.execute();
    File infoDir = new File(srcDir+"\\java\\com\\monsanto\\wst\\"+localRecord.getProjName()+"\\applicationinfo");
    File bldFile = new File(srcDir+"\\java\\com\\monsanto\\wst\\"+localRecord.getProjName()+"\\applicationinfo\\build.properties");

    try{
      //if app info dir doesn't exist, create it
      infoDir.mkdir();
      //if file doesn't exist, create it
      bldFile.createNewFile();
      //write new build.properties file
      writePropertyInfo(bldFile);
    }
    catch(IOException ex){
      System.out.println("IOException in BuildProperties:");
      System.out.print(ex.getMessage());
    }
  }

}
