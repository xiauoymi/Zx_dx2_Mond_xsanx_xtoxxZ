/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CVSAccess.test;

import com.monsanto.wst.wstbuildtools.CVSAccess.WSTProjCVSAccessor;
import com.monsanto.wst.wstbuildtools.CommandExecutor.WSTStreamHandlerOutputHoldingImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: WSTProjCVSAccessor_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-13 17:38:52 $
 *
 * @author zznels
 * @version $Revision: 1.8 $
 */
public class WSTProjCVSAccessor_AT extends TestCase {

  WSTProjCVSAccessor cvsAccessor;
  WSTStreamHandlerOutputHoldingImpl inputHandler, errorHandler;

  public void setUp() throws Exception {
    super.setUp();
    cvsAccessor = new WSTProjCVSAccessor();
  }

  public void testCVSLoginFailsWithBadUsername() throws Exception {
    assertFalse(cvsAccessor.login("user", "password"));
  }

  public void testCheckoutProjByNameFromHeadFailsIfNotLoggedIn() throws Exception {
    assertFalse(cvsAccessor.checkout("testProj"));
    assertTrue("Not logged into CVS".equals(cvsAccessor.getLastCommandErrorOutput()));
  }

  //todo: change to Service Account
  public void testLoginWithProperIDSucceeds() throws Exception {
    cvsAccessor.login("wstserv", "Tega33");

    assertTrue(cvsAccessor.isLoggedIn());
    cvsAccessor.logout();
  }

  public void testLogoffAfterProperLoginSucceeds() throws Exception {
    cvsAccessor.login("wstserv", "Tega33");
    cvsAccessor.logout();

    assertFalse(cvsAccessor.isLoggedIn());
  }

  public void testCheckoutProjByNameFromHeadFailsIfBadProjName() throws Exception {
    cvsAccessor.login("wstserv", "Tega33");

    assertFalse(cvsAccessor.checkout("testProj"));
    cvsAccessor.logout();
  }

  public void testCheckoutProjByNameFromTagFailsIfNotLoggedIn() throws Exception {
    assertFalse(cvsAccessor.checkoutByTag("testProj", "testTag"));
    assertTrue("Not logged into CVS".equals(cvsAccessor.getLastCommandErrorOutput()));
  }

  public void testLogoutWhenNotLoggedInSucceeds() throws Exception {
    assertTrue(cvsAccessor.logout());
  }

  public void testCheckoutByWrongTagFails() throws Exception {
    cvsAccessor.login("wstserv", "Tega33");

    assertFalse(cvsAccessor.checkoutByTag("WSTBuildTools", "WrongTag"));
    cvsAccessor.logout();
  }
  
  //This test can take over 5 minutes to run
//  public void testCheckoutPopulatesWorkspaceDir() throws Exception {
//    cvsAccessor.login("wstserv", "Tega33");
//
//    assertTrue(cvsAccessor.checkout("WSTBuildTools"));
//    File file = new File("C:\\projects\\WSTBuildTools\\workspace\\WSTBuildTools\\Source\\"+
//                        "java\\com\\monsanto\\wst\\wstbuildtools\\CVSAccess\\WSTProjCVSAccessor.java");
//    assertTrue(file.exists());
//    cvsAccessor.logout();
//  }

  //This test can take over 5 minutes to run
//  public void testCheckoutByTagPopulatesWorkspaceDir() throws Exception {
//    cvsAccessor.login("wstserv", "Tega33");
//
//    assertTrue(cvsAccessor.checkoutByTag("WSTBuildTools", "TestTag"));
//    File file = new File("C:\\projects\\WSTBuildTools\\workspace\\WSTBuildTools\\Source\\"+
//                        "java\\com\\monsanto\\wst\\wstbuildtools\\CVSAccess\\WSTProjCVSAccessor.java");
//    assertTrue(file.exists());
//    cvsAccessor.logout();
//  }
//
//  public void testTagCurrentCheckout() throws Exception {
//    cvsAccessor.login("wstserv", "Tega33");
//
//    assertTrue(cvsAccessor.tagCurrentCheckout("WSTBuildTools", "TestTag2"));
//    cvsAccessor.logout();
//  }
}