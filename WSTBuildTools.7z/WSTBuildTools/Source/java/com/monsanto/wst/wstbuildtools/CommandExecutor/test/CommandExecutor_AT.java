/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor.test;

import com.monsanto.wst.wstbuildtools.CommandExecutor.OutputPassingCommandExecutorImpl;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;

/**
 * Filename:    $RCSfile: CommandExecutor_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-07 18:57:46 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class CommandExecutor_AT extends TestCase {

  ByteArrayOutputStream os;
  PrintStream ps;
  OutputPassingCommandExecutorImpl executor;

  public void setUp() throws Exception {
    super.setUp();
    os = new ByteArrayOutputStream();
    ps = new PrintStream(os);
    executor = new OutputPassingCommandExecutorImpl(ps);
  }

  public void testProperCommandThatGivesErrorReturnsFalse() throws Exception {
    assertFalse(executor.executeCommand("cvs checkout", new File(".")));
  }

  public void testProperCommandRunsReturnsTrue() throws Exception {
    assertTrue(executor.executeCommand("cvs logout", new File(".")));
  }

  public void testExecutorPassesOutput() throws Exception {
    assertTrue(os.size()==0);
    executor.executeCommand("cvs checkout", new File("."));
    assertTrue(os.size()>0);
  }

}