/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor.test;

import junit.framework.TestCase;
import com.monsanto.wst.wstbuildtools.CommandExecutor.OutputHoldingCommandExecutorImpl;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: OutputHoldingCommandExecutor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-07 18:57:46 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class OutputHoldingCommandExecutor_UT extends TestCase {

  OutputHoldingCommandExecutorImpl cmd;

  public void setUp() throws Exception{
    super.setUp();
    cmd = new OutputHoldingCommandExecutorImpl();
  }

  public void testUnknownCommandReturnsFalse() throws Exception {
    try{
      cmd.executeCommand("nosuchcommandexists", new File("."));
      fail("Should Throw IOException");
    }catch(IOException e){
    }
  }


}