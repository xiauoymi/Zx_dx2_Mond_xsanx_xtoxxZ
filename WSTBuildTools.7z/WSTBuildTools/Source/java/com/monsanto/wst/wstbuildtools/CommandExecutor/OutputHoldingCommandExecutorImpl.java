/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.wstbuildtools.CommandExecutor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: OutputHoldingCommandExecutorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-06 19:18:49 $
*
* @author zznels
* @version $Revision: 1.1 $
*/
public class OutputHoldingCommandExecutorImpl implements CommandExecutor {

  private ByteArrayOutputStream output;
  private ByteArrayOutputStream errorOutput;


  public OutputHoldingCommandExecutorImpl() {
    output = new ByteArrayOutputStream();
    errorOutput = new ByteArrayOutputStream();
  }


  public boolean executeCommand (String cmd, File cwd) throws IOException{
    boolean cmdSuccess = false;
    Runtime runtime = Runtime.getRuntime();

    Process cvsProc = runtime.exec(cmd, null, cwd);

    WSTStreamHandlerOutputHoldingImpl errorHandler =
        new WSTStreamHandlerOutputHoldingImpl(cvsProc.getErrorStream());
    WSTStreamHandlerOutputHoldingImpl outputHandler =
        new WSTStreamHandlerOutputHoldingImpl(cvsProc.getInputStream());

    errorHandler.start();
    outputHandler.start();

    int returnValue = 0;
    try {
      returnValue = cvsProc.waitFor();

      errorHandler.stopWhenBufferEmpties();
      outputHandler.stopWhenBufferEmpties();

      errorHandler.join();
      outputHandler.join();
    } catch (InterruptedException e) {
      for(char c: e.getMessage().toCharArray()){
        errorOutput.write(c);
      }
      errorOutput.write('\n');
    }

    output.write(outputHandler.getOutput());
    errorOutput.write(errorHandler.getOutput());

    cmdSuccess = returnValue == 0;

    return cmdSuccess;
  }

  public byte[] getOutput() {
    return output.toByteArray();
  }

  public byte[] getErrorOutput() {
    return errorOutput.toByteArray();
  }
}