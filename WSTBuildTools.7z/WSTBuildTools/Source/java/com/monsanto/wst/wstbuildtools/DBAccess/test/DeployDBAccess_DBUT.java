package com.monsanto.wst.wstbuildtools.DBAccess.test;

import org.dbunit.DatabaseTestCase;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.ext.oracle.OracleConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.database.IDatabaseConnection;
import org.xml.sax.InputSource;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Sep 17, 2007
 * Time: 2:25:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeployDBAccess_DBUT extends DatabaseTestCase {
    private OracleConnection oracleConnection;

    protected DatabaseOperation getSetUpOperation() throws Exception {
        System.out.println("In setup\n");
        return DatabaseOperation.INSERT;
    }

    protected DatabaseOperation getTearDownOperation() throws Exception {
        return DatabaseOperation.DELETE;
     }

    protected IDatabaseConnection getConnection() throws Exception {
        Class driver = Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection jdbcConnection =
                DriverManager.getConnection("jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "wst_build", "wst_123");
        oracleConnection = new OracleConnection(jdbcConnection, "wst_build");
        return oracleConnection;
    }

    protected IDataSet getDataSet() throws Exception {
        System.out.println("In getDataSet");
        InputSource input = new InputSource("com/monsanto/wst/wstbuildtools/dbaccess/test/Publish.xml");
        return new FlatXmlDataSet(input);
    }
    
    public void test() throws Exception{
        
    }
}
