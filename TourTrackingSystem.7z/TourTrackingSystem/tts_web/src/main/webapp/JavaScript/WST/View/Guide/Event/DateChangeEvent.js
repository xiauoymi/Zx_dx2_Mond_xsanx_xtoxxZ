// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.View.WindowNavigator');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Utils.DateUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * @constructor
 * description:
 *   This object is an event object for submitting the form when guide selection changes on scheduled Tours page.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.Guide.Event.DateChangeEvent = function(eventUtils, baseElement, formUtils) {
    this._eventUtils = eventUtils;
    this._baseElement = baseElement;
    this._formUtils = formUtils;
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method attaches an event of the specified type to the specified element, binding it to this object.
 *
 * @param element - Page element to bind event to.
 * @param type - String representing the type of event, ie. "click"
 */
WST.View.Guide.Event.DateChangeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method executes the event for this object, submitting the form after re-setting tourdate
 *
 * @param evt - Event object provided by the browser.
 */
WST.View.Guide.Event.DateChangeEvent.prototype.executeEvent = function(evt) {
     var selectedYear = document.getElementById("year");
     var selectedMonth = document.getElementById("month");
     var monthValue = selectedMonth.options[selectedMonth.selectedIndex].value;
     var acutalMonth = parseInt(monthValue)+1;
     var currentDate = acutalMonth + "/01/" + selectedYear.options[selectedYear.selectedIndex].value;
     var tourDate=currentDate;

    var guide = cssQuery('#guide', this._baseElement)[0];
    var guideId = this._formUtils.getSelectedValue(guide);
    var navigator = new Lib.View.WindowNavigator(window);
    var redirectUrl;
    if (Lib.Utils.ObjectUtils.isDefined(tourDate)) {
        redirectUrl = 'listTours.htm?method=listToursByCriteria&status=SCHEDULED';
        if (tourDate.value != '') {
            var startDate = new Date(tourDate);
            var todaysDate = new Date();
            startDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(startDate);
            var endDate = new Date(tourDate);
            endDate.setDate(Lib.Utils.DateUtils.getDaysInMonth(endDate.getMonth(), endDate.getFullYear()));
            endDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(endDate);
            redirectUrl = redirectUrl + '&startDate=' + startDate + '&endDate=' + endDate;
        }
        if (guideId != 'All') {
            redirectUrl = redirectUrl + '&guide=' + guideId;
        }
        navigator.redirect(redirectUrl);
    } else {
        navigator.redirect('changedTours.htm?guide=' + guideId);
    }
}