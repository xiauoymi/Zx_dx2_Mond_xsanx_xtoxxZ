// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");

/**
* author: Nate Minshew
* date created: 07/25/2006
* @constructor
* description:
*   This object is a controller for the confirm section of the request a tour page.  It acts as an interface for
*   performing actions on the confirm section.
*/
WST.Controller.RequestTour.ConfirmController = function() {
    this._confirmValueListeners = new Array();
    this._addGuestListeners = new Array();
    this._editGuestListeners = new Array();
    this._deleteGuestListeners = new Array();
    this._addGuideListeners = new Array();
    this._editGuideListeners = new Array();
    this._deleteGuideListeners = new Array();
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to setConfirmValue.  When another object calls the
*   setConfirmValue method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the setConfirmValue method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerConfirmValueListener = function(listener) {
    this._confirmValueListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to addGuest.  When another object calls the
*   addGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerAddGuestListener = function(listener) {
    this._addGuestListeners.push(listener);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to addGuide.  When another object calls the
*   addGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerAddGuideListener = function(listener) {
    this._addGuideListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to editGuest.  When another object calls the
*   editGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the editGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerEditGuestListener = function(listener) {
    this._editGuestListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to deleteGuest.  When another object calls the
*   deleteGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerDeleteGuestListener = function(listener) {
    this._deleteGuestListeners.push(listener);
}


/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to deleteGuide.  When another object calls the
*   deleteGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerDeleteGuideListener = function(listener) {
    this._deleteGuideListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to set the confirm value of the specified
*   input element.
*
* @param inputElement - HTML element with the confirm value.
*/
WST.Controller.RequestTour.ConfirmController.prototype.setConfirmValue = function(inputElement) {
    this._notifyConfirmValueListeners(inputElement);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to add the guest to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location
*/
WST.Controller.RequestTour.ConfirmController.prototype.addGuest = function(name, classification, location) {
    this._notifyAddGuestListeners(name, classification, location);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to add the guide to the confirm section.
*
* @param name - Guide's name.
*/
WST.Controller.RequestTour.ConfirmController.prototype.addGuide = function(guideName) {
    this._notifyAddGuideListeners(guideName);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to edit the guest in the confirm section.
*
* @param index - Index of guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location
*/
WST.Controller.RequestTour.ConfirmController.prototype.editGuest = function(index, name, classification, location) {
    this._notifyEditGuestListeners(index, name, classification, location);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to delete the guest in the confirm section.
*
* @param index - Index of guest.
*/
WST.Controller.RequestTour.ConfirmController.prototype.deleteGuest = function(index) {
    this._notifyDeleteGuestListeners(index);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to delete the guide in the confirm section.
*
* @param index - Index of guest.
*/
WST.Controller.RequestTour.ConfirmController.prototype.deleteGuide = function(index) {
    this._notifyDeleteGuideListeners(index);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the setConfirmValue method was called.
*
* @param inputElement - HTML element passed to the setConfirmValue method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyConfirmValueListeners = function(inputElement) {
    for (var i = 0; i < this._confirmValueListeners.length; i++) {
        this._confirmValueListeners[i](inputElement);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the addGuest method was called.
*
* @param inputElement - HTML element passed to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyAddGuestListeners = function(name, classification, location) {
    for (var i = 0; i < this._addGuestListeners.length; i++) {
        this._addGuestListeners[i](name, classification, location);
    }
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the addGuide method was called.
*
* @param inputElement - HTML element passed to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyAddGuideListeners = function(name) {
    for (var i = 0; i < this._addGuideListeners.length; i++) {
        this._addGuideListeners[i](name);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the editGuest method was called.
*
* @param inputElement - HTML element passed to the editGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyEditGuestListeners = function(index, name, classification, location) {
    for (var i = 0; i < this._editGuestListeners.length; i++) {
        this._editGuestListeners[i](index, name, classification, location);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the deleteGuest method was called.
*
* @param inputElement - HTML element passed to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyDeleteGuestListeners = function(index) {
    for (var i = 0; i < this._deleteGuestListeners.length; i++) {
        this._deleteGuestListeners[i](index);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the deleteGuest method was called.
*
* @param inputElement - HTML element passed to the deleteGuide method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyDeleteGuideListeners = function(index) {
    for (var i = 0; i < this._deleteGuideListeners.length; i++) {
        this._deleteGuideListeners[i](index);
    }
}
