// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

WST.View.Admin.BlackoutDateView = function() {
}

WST.View.Admin.BlackoutDateView.prototype.updateDateElement = function(dateElement, isBlackedOut) {
    if (isBlackedOut) {
        Lib.Utils.DocumentUtils.addClass(dateElement, 'blackoutDate');
    } else {
        Lib.Utils.DocumentUtils.removeClass(dateElement, 'blackoutDate');
    }
}