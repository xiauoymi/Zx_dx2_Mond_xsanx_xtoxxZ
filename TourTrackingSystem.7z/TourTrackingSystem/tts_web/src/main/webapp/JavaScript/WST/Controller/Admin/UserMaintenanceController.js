// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.Admin.UserMaintenanceList');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Admin");

/**
* author: Sonal Patidar
* date created: 08/23/2006
* @constructor
* description:
*   This object is a controller for users.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param userMaintenanceListUrl - Url of the users list service.
*/
WST.Controller.Admin.UserMaintenanceController = function(ajaxUtils, userMaintenanceListUrl) {
    this._ajaxUtils = ajaxUtils;
    this.userMaintenanceListUrl = userMaintenanceListUrl;
}

/**
* author: Sonal Patidar
* date created: 08/23/2006
* access level: public
* description:
*   This method retrieves a list of users from the server.
*/
WST.Controller.Admin.UserMaintenanceController.prototype.getUserMaintenanceList = function() {
    var xml = this._ajaxUtils.requestSynchronousFeed(this.userMaintenanceListUrl);
    return new WST.Model.Admin.UserMaintenanceList(xml);
}