// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.Tour');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('WST.TourCalendar.Model.Guide');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.TourList = function(status, getGuidesOrNot, guideId, calendar, currentDate, parentClass, callback) {
    var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._status = status;
    this._guideId = guideId;
    this._tours = new Array();
    this.refreshListAsynchronously(getGuidesOrNot, currentDate, calendar, this, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.TourList.prototype.refreshList = function() {
    this._tours = this._parseTourXml(this._getToursXml());
}

WST.TourCalendar.Model.TourList.prototype.refreshListAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject,  parentClass, callback) {
    this._tours = this._getToursXmlAsynchronously(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype._getToursXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getTourServiceUrl());
}

WST.TourCalendar.Model.TourList.prototype._getToursXmlAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
    return Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed(this._getTourServiceUrl(), getGuidesOrNot, currentDate, calendar, tourListObject, callback, parentClass, this._parseTourXmlAsynchronously);
}

WST.TourCalendar.Model.TourList.prototype.setStatus = function(status) {
    this._status = status;
}

WST.TourCalendar.Model.TourList.prototype.getToursByDate = function(date) {
    var tours = new Array();
    for (var i = 0; i < this._tours.length; i++) {
        if (this._tours[i].getStartDate().getFullYear() == date.getFullYear()
                && this._tours[i].getStartDate().getMonth() == date.getMonth()
                && this._tours[i].getStartDate().getDate() == date.getDate()) {
            tours.push(this._tours[i]);
        }
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseTourXmlAsynchronously = function(request, getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
  var xmlDoc = request.responseXML;
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
        if (getGuidesOrNot) {
          guides = tourListObject._parseGuideXml(tourElements[i]);
        }
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    tourListObject._tours = tours;
    callback(tourListObject, calendar, currentDate, parentClass);
}

WST.TourCalendar.Model.TourList.prototype._parseTourXml = function(xmlDoc) {
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
//        var guides = this._parseGuideXml(tourElements[i]);
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseGuideXml = function(tourElement) {
    var guideElements = tourElement.getElementsByTagName('guide');
    var guides = new Array();
    for (var i = 0; i < guideElements.length; i++) {
        var id = guideElements[i].getAttribute('id');
        var name = guideElements[i].getAttribute('name');
        guides.push(new WST.TourCalendar.Model.Guide(id, name));
    }
    return guides;
}


WST.TourCalendar.Model.TourList.prototype._getTourServiceUrl = function() {
    var tourServiceUrl = 'listTours.htm?method=listToursByCriteria&view=xml&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&status=' + this._status;
    if (Lib.Utils.ObjectUtils.isDefined(this._guideId) && this._guideId != 'All') {
        tourServiceUrl = tourServiceUrl + '&guide=' + this._guideId;
    }
    return tourServiceUrl;
}

WST.TourCalendar.Model.TourList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
