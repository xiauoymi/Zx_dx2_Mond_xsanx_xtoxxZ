// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a save tour event for submitting the tour form to the server.
*
* @param formElement - HTML element representing the form.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.Event.SaveTourEvent = function(formElement, eventUtils) {
    this._formElement = formElement;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.SaveTourEvent.prototype.attachEvent = function(element, type) {
    this._element = element;
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This methd executes the event, submitting the form.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.SaveTourEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    var linkName = this._element.id;
    var status = cssQuery('#tourStatus', this._baseElement)[0];
    if(linkName == "finishedNav"){
      if(status.value == ""){
        status.value = "NEW";
        }
    }
    if(linkName == "saveAsNav"){
      document.getElementById("method").value = "makeACopyOfTour";
    }
    if(linkName == "approveNav"){
      status.value = "SCHEDULED";
    }
    if(linkName == "addonNav"){
      status.value = "ADDON";
    }
    if(linkName == "pendingNav"){
      status.value = "PENDING";
    }
    if(linkName == "declineNav"){
      status.value = "CANCELLED";
    }
    if(linkName == "resetToNewNav"){
      status.value = "NEW";
    }
    this._formElement.submit();
}