// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the tabs on the request a tour page.  It handles manipulating the tabs on the page
*   as well as adding events.
*
* @param baseElement - Root html element of the tabs.
* @param tabNavigator - Tab navigator widget.
* @param objectUtils - Object utility object.
*/
WST.View.RequestTour.TabsView = function(baseElement, tabNavigator, objectUtils) {
    this._baseElement = baseElement;
    this.roundTabs();
    var reference = objectUtils.weakBind(this.roundTabs, this);
    tabNavigator.addListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method rounds the tabs using niftycorners.
*/
WST.View.RequestTour.TabsView.prototype.roundTabs = function() {
    if (typeof NiftyCheck != 'undefined' && NiftyCheck()) {
        this.removeAllRoundedCorners();
        // TODO: Would like to eventually rewrite niftycorners to use css classes instead.
        Rounded('a.tab', "top", "#FFF", "#336633", "smooth");
        this._roundActiveTab();
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method removes the rounded corners from the specified element.
*
* @param element - HTML element to be squared off.
*/
WST.View.RequestTour.TabsView.prototype._removeRoundedCorners = function(element) {
    if (element != null) {
        var roundedElements = element.getElementsByTagName('b');
        for (var i = 0; i < roundedElements.length; i++) {
            roundedElements[i].parentNode.removeChild(roundedElements[i]);
        }
    }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method removes all rounded corners.
*/
WST.View.RequestTour.TabsView.prototype.removeAllRoundedCorners = function() {
    var tabs = cssQuery('a.tab', this._baseElement);
    for (var i = 0; i < tabs.length; i++) {
        this._removeRoundedCorners(tabs[i]);
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method rounds the active tab.
*/
WST.View.RequestTour.TabsView.prototype._roundActiveTab = function() {
    var activeTab = cssQuery('a.activeTab', this._baseElement)[0];
    this._removeRoundedCorners(activeTab);
    Rounded('a.activeTab', "top", "#FFF", "#C3DDAD", "smooth");
}