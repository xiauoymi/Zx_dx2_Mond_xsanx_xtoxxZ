// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event");

WST.Event.WindowCloseEvent = function(targetElement) {
    this._targetElement = targetElement;
}

WST.Event.WindowCloseEvent.prototype.attachEvent = function(element, type) {
    Lib.Utils.EventUtils.addEvent(element, "mouseout", this.executeEvent, this);
}

WST.Event.WindowCloseEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
//    var selectElements = document.getElementsByTagName('select');
//    for (var i = 0; i < selectElements.length; i++) {
//        Lib.Utils.DocumentUtils.removeClass(selectElements[i], 'invisible');
//    }
    Lib.Utils.DocumentUtils.addClass(this._targetElement, 'hide');
}