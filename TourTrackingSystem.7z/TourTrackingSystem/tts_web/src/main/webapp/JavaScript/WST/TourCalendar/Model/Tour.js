// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Tour = function(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization,
                                       guides, status) {
    this._id = id;
    this._startDate = new Date(startDate);
    this._endDate = new Date(endDate);
    this._startTime = startTime;
    this._endTime = endTime;
    this._location = location;
    this._numGuests = numGuests;
    this._place = place;
    this._organization = organization;
    this._guides = guides;
    this._status = status;
}

WST.TourCalendar.Model.Tour.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Tour.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.Tour.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.Tour.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.Tour.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.Tour.prototype.getLocation = function() {
    return this._location;
}

WST.TourCalendar.Model.Tour.prototype.getNumGuests = function() {
    return this._numGuests;
}

WST.TourCalendar.Model.Tour.prototype.getPlace = function() {
    return this._place;
}

WST.TourCalendar.Model.Tour.prototype.getOrganization = function() {
    return this._organization;
}

WST.TourCalendar.Model.Tour.prototype.getGuides = function() {
    return this._guides;
}

WST.TourCalendar.Model.Tour.prototype.getStatus = function() {
    return this._status;
}

WST.TourCalendar.Model.Tour.prototype.getFormattedDateRange = function() {
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedStartDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedEndDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
}
