// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
* author: Nate Minshew
* date created: 07/31/2006
* @constructor
* description:
*   This object is an event object for hiding and showing end date fields based on an input's state.
*
* @param eventUtils - Event utility object.
* @param guestsView - Object representing the guests view.
*/
WST.View.Guide.Event.RecursEvent = function(eventUtils, outOfOfficeView, recursElement) {
    this._eventUtils = eventUtils;
    this._outOfOfficeView = outOfOfficeView;
    this._recursElement = recursElement;
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.Guide.Event.RecursEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method executes the event for this object, hiding or showing the reoccurring fields.
*
* @param evt - Event object provided by the browser.
*/
WST.View.Guide.Event.RecursEvent.prototype.executeEvent = function(evt) {
    if (this._recursElement.checked) {
        this._outOfOfficeView.showReoccurringFields();
    } else {
        this._outOfOfficeView.hideReoccurringFields();
    }
}