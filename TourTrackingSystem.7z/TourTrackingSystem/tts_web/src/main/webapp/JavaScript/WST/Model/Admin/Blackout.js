// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

WST.Model.Admin.Blackout = function(date, reason) {
    this._date = date;
    this._reason = reason;
}

WST.Model.Admin.Blackout.prototype.getDate = function() {
    return this._date;
}

WST.Model.Admin.Blackout.prototype.getReason = function() {
    return this._reason;
}