// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ToggleLocationTypeEvent');
JSAN.use('WST.View.RequestTour.Event.AddEditGuestEvent');
JSAN.use('WST.View.RequestTour.Validator.GuestValidator');
JSAN.use('WST.View.RequestTour.Event.LoadGuestEvent');
JSAN.use('WST.View.RequestTour.Event.DeleteGuestEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/13/2006
* @constructor
* description:
*   This object is a view object for the guests section of the request a tour page.  It is responsible for interacting
*   with the html on the page providing events and any necessary dhtml.
*
* @param baseElement - Root html element for the guests section.
* @param formUtils - Form utility object.
* @param objectUtils - Object utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param numGuestsElement - HTML element representing the number of guests that have been entered.
*/
WST.View.RequestTour.GuestsView = function(baseElement, formUtils, objectUtils, documentUtils, eventUtils,
                                           numGuestsElement, validatorUtils, errorView, confirmController) {
    this._baseElement = baseElement;
    this._formUtils = formUtils;
    this._objectUtils = objectUtils;
    this._documentUtils = documentUtils;
    this._numGuestsElement = numGuestsElement;
    this._validator = new WST.View.RequestTour.Validator.GuestValidator(validatorUtils, formUtils, errorView);
    this._errorView = errorView;
    this._eventUtils = eventUtils;
    this._confirmController = confirmController;
    this._createLocationEvent(eventUtils);
    this._createAddEditGuestEvent(eventUtils);
    this._attachEventsToExistingGuests();
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method adds or edits a guest depending on the current mode and updates the guests table.
*/
WST.View.RequestTour.GuestsView.prototype.addEditGuest = function() {
    var button = cssQuery('#addGuestButton', this._baseElement)[0];
    var index = button.className.substring(button.className.indexOf('-') + 1, button.className.indexOf('-') + 2);
    if (this._documentUtils.containsClass(button, 'addMode')) {
        this._addGuest();
    } else if (this._documentUtils.containsClass(button, 'editMode')) {
        this._editGuest(index);
    }
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method adds the entered guest to the request a tour form and the guests table.
*/
WST.View.RequestTour.GuestsView.prototype._addGuest = function() {
    var firstNameElement = cssQuery('#guestFirstName-dhtml', this._baseElement)[0];
    var lastNameElement = cssQuery('#guestLastName-dhtml', this._baseElement)[0];
    var locationElement = cssQuery('#guestLocation-dhtml', this._baseElement)[0];
    var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0];
    var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0];
    var classificationElement = cssQuery('#guestClassification-dhtml', this._baseElement)[0];

    this._errorView.clearAllErrors();
    if (this._validator.validate(firstNameElement, lastNameElement, locationElement, stateElement, countryElement,
            classificationElement)) {
        var fieldset = document.createElement('fieldset');
        var index = this._getNumGuests();
        fieldset.id = 'guest-' + index;
        this._createHiddenInput('guestFirstName', firstNameElement.value, fieldset, index);
        this._createHiddenInput('guestLastName', lastNameElement.value, fieldset, index);
        this._createHiddenInput('guestLocation', this._formUtils.getSelectedValue(locationElement), fieldset, index);

        if (this._formUtils.getSelectedValue(locationElement) == 'Domestic') {
            this._createHiddenInput('guestState', this._formUtils.getSelectedValue(stateElement), fieldset, index);
            this._createHiddenInput('guestCountry', '', fieldset, index);
        } else {
            this._createHiddenInput('guestCountry', this._formUtils.getSelectedValue(countryElement), fieldset, index);
            this._createHiddenInput('guestState', '', fieldset, index);
        }
        this._createHiddenInput('guestClassification', this._formUtils.getSelectedValue(classificationElement), fieldset, index);
        this._baseElement.appendChild(fieldset);

        var fullName = firstNameElement.value + ' ' + lastNameElement.value;
        var classification = this._formUtils.getSelectedText(classificationElement);

        var location;
        if (this._formUtils.getSelectedValue(locationElement) == 'Domestic') {
            location = this._formUtils.getSelectedText(stateElement);
        } else {
            location = this._formUtils.getSelectedText(countryElement);
        }

        this._removeNoGuestsRow();
        this._addGuestToTable(fullName, classification, location);

        this._clearNameFields();
        this._updateNumGuests();
        this._confirmController.addGuest(fullName, classification, location);
    }
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method edits the guest at the specified index in the request a tour form and guests table.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.GuestsView.prototype._editGuest = function(index) {
    var firstNameElement = cssQuery('#guestFirstName-dhtml', this._baseElement)[0];
    var lastNameElement = cssQuery('#guestLastName-dhtml', this._baseElement)[0];
    var locationElement = cssQuery('#guestLocation-dhtml', this._baseElement)[0];
    var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0];
    var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0];
    var classificationElement = cssQuery('#guestClassification-dhtml', this._baseElement)[0];

    this._errorView.clearAllErrors();
    if (this._validator.validate(firstNameElement, lastNameElement, locationElement, stateElement, countryElement,
            classificationElement)) {
        var firstNameHiddenElement = cssQuery('#guestFirstName-' + index, this._baseElement)[0];
        var lastNameHiddenElement = cssQuery('#guestLastName-' + index, this._baseElement)[0];
        var locationHiddenElement = cssQuery('#guestLocation-' + index, this._baseElement)[0];
        var stateHiddenElement = cssQuery('#guestState-' + index, this._baseElement)[0];
        var countryHiddenElement = cssQuery('#guestCountry-' + index, this._baseElement)[0];
        var classificationHiddenElement = cssQuery('#guestClassification-' + index, this._baseElement)[0];

        firstNameHiddenElement.value = firstNameElement.value;
        lastNameHiddenElement.value = lastNameElement.value;
        locationHiddenElement.value = this._formUtils.getSelectedValue(locationElement);
        stateHiddenElement.value = this._formUtils.getSelectedValue(stateElement);
        countryHiddenElement.value = this._formUtils.getSelectedValue(countryElement);
        classificationHiddenElement.value = this._formUtils.getSelectedValue(classificationElement);

        var fullName = firstNameElement.value + ' ' + lastNameElement.value;
        var classification = this._formUtils.getSelectedText(classificationElement);
        var location;
        if (this._formUtils.getSelectedValue(locationElement) == 'Domestic') {
            location = this._formUtils.getSelectedText(stateElement);
        } else {
            location = this._formUtils.getSelectedText(countryElement);
        }

        this._editGuestInTable(index, fullName, classification, location);

        var button = cssQuery('#addGuestButton', this._baseElement)[0];
        button.value = 'Add Guest';
        this._documentUtils.removeClass(button, 'editMode');
        this._documentUtils.addClass(button, 'addMode');

        this._clearNameFields();
        this._confirmController.editGuest(index, fullName, classification, location);
    }
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: public
* description:
*   This method removes the guest at the specified index from the form and table.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.GuestsView.prototype.deleteGuest = function(index) {
    var firstNameHiddenElement = cssQuery('#guestFirstName-' + index, this._baseElement)[0];
    var lastNameHiddenElement = cssQuery('#guestLastName-' + index, this._baseElement)[0];
    var locationHiddenElement = cssQuery('#guestLocation-' + index, this._baseElement)[0];
    var stateHiddenElement = cssQuery('#guestState-' + index, this._baseElement)[0];
    var countryHiddenElement = cssQuery('#guestCountry-' + index, this._baseElement)[0];
    var classificationHiddenElement = cssQuery('#guestClassification-' + index, this._baseElement)[0];

    firstNameHiddenElement.parentNode.removeChild(firstNameHiddenElement);
    lastNameHiddenElement.parentNode.removeChild(lastNameHiddenElement);
    locationHiddenElement.parentNode.removeChild(locationHiddenElement);
    stateHiddenElement.parentNode.removeChild(stateHiddenElement);
    countryHiddenElement.parentNode.removeChild(countryHiddenElement);
    classificationHiddenElement.parentNode.removeChild(classificationHiddenElement);

    this._removeGuestFromTable(index);
    this._updateNumGuests();
    this._confirmController.deleteGuest(index);
}

/**
* author: Nate Minshew
* date created: 07/18/2006
* access level: public
* description:
*   This method loads the guest associated with the specified index into the dhtml input fields to be edited.
*
* @param index - Index of guest to load.
*/
WST.View.RequestTour.GuestsView.prototype.loadGuest = function(index) {
    var firstNameHiddenElement = cssQuery('#guestFirstName-' + index, this._baseElement)[0];
    var lastNameHiddenElement = cssQuery('#guestLastName-' + index, this._baseElement)[0];
    var locationHiddenElement = cssQuery('#guestLocation-' + index, this._baseElement)[0];
    var stateHiddenElement = cssQuery('#guestState-' + index, this._baseElement)[0];
    var countryHiddenElement = cssQuery('#guestCountry-' + index, this._baseElement)[0];
    var classificationHiddenElement = cssQuery('#guestClassification-' + index, this._baseElement)[0];

    var firstNameElement = cssQuery('#guestFirstName-dhtml', this._baseElement)[0];
    var lastNameElement = cssQuery('#guestLastName-dhtml', this._baseElement)[0];
    var locationElement = cssQuery('#guestLocation-dhtml', this._baseElement)[0];
    var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0];
    var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0];
    var classificationElement = cssQuery('#guestClassification-dhtml', this._baseElement)[0];
    firstNameElement.value = firstNameHiddenElement.value;
    lastNameElement.value = lastNameHiddenElement.value;
    locationElement.selectedIndex = this._formUtils.getIndexOfValue(locationElement, locationHiddenElement.value);
    stateElement.selectedIndex = this._formUtils.getIndexOfValue(stateElement, stateHiddenElement.value);
    countryElement.selectedIndex = this._formUtils.getIndexOfValue(countryElement, countryHiddenElement.value);
    classificationElement.selectedIndex = this._formUtils.getIndexOfValue(classificationElement, classificationHiddenElement.value);
    //Added this code so that either State/Country is displayed when the edit button is clicked.
      if (this._formUtils.getSelectedValue(locationElement) == 'Domestic') {
        this.displayStates();
      } else if (this._formUtils.getSelectedValue(locationElement) == 'International') {
        this.displayCountries();
      } else {
        this.hideStatesAndCountries();
      }
    var button = cssQuery('#addGuestButton', this._baseElement)[0];
    button.value = 'Edit Guest';
    // this._documentUtils.removeClass(button, 'addMode');
    this._documentUtils.removeClasses(button);
    this._documentUtils.addClass(button, 'editMode');
    this._documentUtils.addClass(button, 'guest-' + index);
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method displays the states drop down in the guests section.
*/
WST.View.RequestTour.GuestsView.prototype.displayStates = function() {
    var stateElementParent = cssQuery('#guestState-dhtml', this._baseElement)[0].parentNode;
    var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0];
    countryElement.selectedIndex = 0;
    var countryElementParent = countryElement.parentNode;
    this._documentUtils.addClass(countryElementParent, 'hide');
    this._documentUtils.removeClass(stateElementParent, 'hide');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method displays the countries drop down in the guests section.
*/
WST.View.RequestTour.GuestsView.prototype.displayCountries = function() {
    var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0];
    stateElement.selectedIndex = 0;
    var stateElementParent = stateElement.parentNode;
    var countryElementParent = cssQuery('#guestCountry-dhtml', this._baseElement)[0].parentNode;
    this._documentUtils.addClass(stateElementParent, 'hide');
    this._documentUtils.removeClass(countryElementParent, 'hide');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method hides both the states drop down and the countries drop down.
*/
WST.View.RequestTour.GuestsView.prototype.hideStatesAndCountries = function() {
    var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0].parentNode;
    var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0].parentNode;
    this._documentUtils.addClass(stateElement, 'hide');
    this._documentUtils.addClass(countryElement, 'hide');
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method attaches the edit and delete events to any existing guests.
*/
WST.View.RequestTour.GuestsView.prototype._attachEventsToExistingGuests = function() {
    var editGuestLinks = cssQuery('.editGuestLink');
    var deleteGuestLinks = cssQuery('.deleteGuestLink');

    for (var i = 0; i < editGuestLinks.length; i++) {
        this._attachEditEvent(editGuestLinks[i], i);
    }

    for (var i = 0; i < deleteGuestLinks.length; i++) {
        this._attachDeleteEvent(deleteGuestLinks[i], i);
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates a hidden input field for one of the guest fields.
*
* @param name - Name of the input field.
* @param value - Value of the input field.
*/
WST.View.RequestTour.GuestsView.prototype._createHiddenInput = function(name, value, parent, index) {
    var element = this._formUtils.createInputField(name);
    element.type = 'hidden';
    element.id = name + '-' + index;
    element.value = value;
    parent.appendChild(element);
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method adds a guest to the guest table.
*
* @param name - Text representing the guests full name.
* @param classification - Text representing the guest's classification
* @param location - Text representing the guest's location.
*/
WST.View.RequestTour.GuestsView.prototype._addGuestToTable = function(name, classification, location) {
    var tableBody = cssQuery('#guestTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    row.className = 'guestRow';
    row.id = 'guestRow-' + this._getNumGuests();
    row.appendChild(this._createGuestColumn(name));
    row.appendChild(this._createGuestColumn(classification));
    row.appendChild(this._createGuestColumn(location));
    row.appendChild(this._createActionsColumn());
    tableBody.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method updates a guest in the guests table.
*
* @param index - Index of the guest.
* @param fullName - New name of the guest.
* @param classification - New classification of the guest.
* @param loction - New location of the guest.
*/
WST.View.RequestTour.GuestsView.prototype._editGuestInTable = function(index, name, classification, location) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    if (this._objectUtils.isDefined(row)) {
        var tdElements = row.getElementsByTagName('td');
        tdElements[0].innerHTML = name;
        tdElements[1].innerHTML = classification;
        tdElements[2].innerHTML = location;
    }
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method deletes the guest at the specified index from the guests table
*
* @param index - Index of guest.
*/
WST.View.RequestTour.GuestsView.prototype._removeGuestFromTable = function(index) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
    if (this._getNumGuests() == 0) {
        this._addNoGuestsRow();
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the actions column with edit and delete links.
*/
WST.View.RequestTour.GuestsView.prototype._createActionsColumn = function() {
    var columnElement = this._createGuestColumn();
    columnElement.className = 'guestActions';
    var editLink = document.createElement('a');
    editLink.id = 'guestEditLink-' + this._getNumGuests();
    editLink.className = 'editGuestLink';
    editLink.href = '#';
    this._attachEditEvent(editLink, this._getNumGuests());
    editLink.appendChild(document.createTextNode('edit'));

    var deleteLink = document.createElement('a');
    deleteLink.id = 'guestDeleteLink-' + this._getNumGuests();
    deleteLink.className = 'deleteGuestLink';
    deleteLink.href = '#';
    this._attachDeleteEvent(deleteLink, this._getNumGuests());
    deleteLink.appendChild(document.createTextNode('delete'));

    columnElement.appendChild(editLink);
    columnElement.appendChild(deleteLink);

    return columnElement;
}

/**
* author: Nate Minshew
* date created: 07/18/2006
* access level: private
* description:
*   This method attaches the edit guest event to the specified edit link.
*
* @param editLink - HTML link element.
*/
WST.View.RequestTour.GuestsView.prototype._attachEditEvent = function(editLink, index) {
    var event = new WST.View.RequestTour.Event.LoadGuestEvent(this._eventUtils, this, index);
    event.attachEvent(editLink, 'click');
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method attaches the delete guest event to the specified delete link.
*
* @param deleteLink - HTML link element.
*/
WST.View.RequestTour.GuestsView.prototype._attachDeleteEvent = function(deleteLink, index) {
    var event = new WST.View.RequestTour.Event.DeleteGuestEvent(this._eventUtils, this, index);
    event.attachEvent(deleteLink, 'click');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This methood creates a guest column with the value specified.
*
* @param value - The text to be added to the column.
*/
WST.View.RequestTour.GuestsView.prototype._createGuestColumn = function(value) {
    var column = document.createElement('td');
    if (this._objectUtils.isDefined(value)) {
        column.appendChild(document.createTextNode(value));
    }
    return column;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method removes the no guests row.
*/
WST.View.RequestTour.GuestsView.prototype._removeNoGuestsRow = function() {
    var noGuestsCol = cssQuery('#noGuests', this._baseElement)[0];
    if (this._objectUtils.isDefined(noGuestsCol)) {
        noGuestsRow = noGuestsCol.parentNode;
        noGuestsRow.parentNode.removeChild(noGuestsRow);
    }
}

/**
* author: Nate Minshew
* date created: 07/19/2006
* access level: private
* description:
*   This method adds the no guests column to the guests table.
*/
WST.View.RequestTour.GuestsView.prototype._addNoGuestsRow = function() {
    var tableBody = cssQuery('#guestTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    var noGuestsCol = document.createElement('td');
    noGuestsCol.id = 'noGuests';
    noGuestsCol.colSpan = 4;
    noGuestsCol.appendChild(document.createTextNode('No Guests Entered'));
    row.appendChild(noGuestsCol);
    tableBody.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the location event for displaying the states and countries drop downs.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.GuestsView.prototype._createLocationEvent = function(eventUtils) {
    var locationElement = cssQuery('#guestLocation-dhtml', this._baseElement)[0];
    var event = new WST.View.RequestTour.Event.ToggleLocationTypeEvent(eventUtils, this, locationElement, this._formUtils);
    event.attachEvent(locationElement, 'change');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the add guest event for adding guests to the form and table.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.GuestsView.prototype._createAddEditGuestEvent = function(eventUtils) {
    var addGuestButton = cssQuery('#addGuestButton', this._baseElement)[0];
    var event = new WST.View.RequestTour.Event.AddEditGuestEvent(eventUtils, this);
    event.attachEvent(addGuestButton, 'click');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method clears the guest name fields on the form.
*/
WST.View.RequestTour.GuestsView.prototype._clearNameFields = function() {
    var firstNameElement = cssQuery('#guestFirstName-dhtml', this._baseElement)[0];
    var lastNameElement = cssQuery('#guestLastName-dhtml', this._baseElement)[0];
    firstNameElement.value = '';
    lastNameElement.value = '';
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method updates the number guests info in the tab.
*/
WST.View.RequestTour.GuestsView.prototype._updateNumGuests = function() {
    var numGuests = this._getNumGuests();
    this._numGuestsElement.firstChild.nodeValue = '(' + numGuests + ')';
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method returns the number of guests that have been created.
*/
WST.View.RequestTour.GuestsView.prototype._getNumGuests = function() {
    return cssQuery('.guestRow', this._baseElement).length;
}