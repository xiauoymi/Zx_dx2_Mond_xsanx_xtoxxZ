// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Guide.Event.GuideChangeEvent');
JSAN.use('WST.View.Guide.Event.DateChangeEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide");

/**
* author: Sonal Patidar
* date created: 08/28/2006
* @constructor
* description:
*   This object is a view object for the Scheduled Tours page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Guide.ScheduledToursView = function(calendar, baseElement, xmlUtils,documentUtils, eventUtils, objectUtils, formUtils, logger) {
//    logger.debug("ScheduledToursView - Enter create ");
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._formUtils = formUtils;
    this._createGuideChangeEvent(eventUtils, logger);
    this._createDateChangeEvent(eventUtils, logger);
    if (calendar != null) {
        calendar.setLocationHref(this._getLocationHref());
        if (objectUtils.isDefined(calendar)) {
            this._attachCalendar(calendar, xmlUtils, eventUtils);
            var reference = objectUtils.weakBind(this.updateDate, this);
            calendar.registerDateEventListener(reference);
        }
    }
//  logger.debug("ScheduledToursView - Exit create ");
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: private
* description:
*   This method creates the location href to be set in calendar. This will be used as location.href when
* incrementing and decrementing months in the calendar.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._getLocationHref = function() {
  var guide = cssQuery('#guide', this._baseElement)[0];
  var guideId = this._formUtils.getSelectedValue(guide);
  return 'listTours.htm?method=listToursByCriteria&guide=' + guideId + '&status=SCHEDULED';
}
/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the add guide event for adding guides to the form and table.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._createGuideChangeEvent = function(eventUtils, logger) {
    var guideSelect = cssQuery('#guide', this._baseElement)[0];
    var event = new WST.View.Guide.Event.GuideChangeEvent(eventUtils, this._baseElement, this._formUtils);
    event.attachEvent(guideSelect,'change');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the add guide event for adding guides to the form and table.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._createDateChangeEvent = function(eventUtils, logger) {
    var monthSelect = cssQuery('#month', this._baseElement)[0];
    if(monthSelect!=null){
        var event = new WST.View.Guide.Event.DateChangeEvent(eventUtils, this._baseElement, this._formUtils);
        event.attachEvent(monthSelect,'change');
    }
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method attaches the calendar html element to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._attachCalendar = function(calendar, xmlUtils,eventUtils) {
    var element = calendar.getCalendar();
    var tourDateLabel = cssQuery('#tourDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    xmlUtils.insertAfter(brElement, tourDateLabel);
    xmlUtils.insertAfter(element, brElement)
    }

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Guide.ScheduledToursView.prototype.updateDate = function(date) {
    var tourDate = cssQuery('#tourDate', this._baseElement)[0];
    var dateStr = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    tourDate.value = dateStr;
    var guide = cssQuery('#guide', this._baseElement)[0];
    var guideId = this._formUtils.getSelectedValue(guide);
    location.href = 'listTours.htm?method=listToursByCriteria&guide=' + guideId + '&startDate=' + dateStr + '&endDate=' + dateStr + '&status=SCHEDULED';
   // location.href = 'scheduledTours.htm?guide=' + guideId + '&tourDate=' + (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
}

