// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

/**
* author: Sonal Patidar
* date created: 08/23/2006
* @constructor
* description:
*   This object is a view object for the usersmaintenance page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Admin.UserMaintenanceView = function(baseElement, documentUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
}

