// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Utils");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is used to perform date functions.
*/
WST.Utils.DateUtils = function() {
}

// Array of formatted month names.
WST.Utils.DateUtils.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];
// Array of formatted weekday names.
WST.Utils.DateUtils.WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method formats the specified date object as a date string.
*
* @param date - Date object representing the date.
* @return string - Representing the date.
*/
WST.Utils.DateUtils.prototype.getFormattedDate = function(date) {
    var weekday = WST.Utils.DateUtils.WEEK_DAYS[date.getDay()];
    var month = WST.Utils.DateUtils.MONTHS[date.getMonth()];
    var year = date.getFullYear();
    var day = date.getDate();
    return weekday + ", " + month + " " + day + ", " + year;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the specified date object as a date/time string.
*
* @param date - Date object representing the date.
* @return string - Representing the date and time.
*/
WST.Utils.DateUtils.prototype.getFormattedDateTime = function(date) {
    var dateString = this.getFormattedDate(date);
    var hours = this.getFormattedHours(date);
    var minutes = this.getFormattedMinutes(date);
    var ampm = this.getAMPM(date);
    return dateString + ", " + hours + ":" + minutes + " " + ampm;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the minutes of the specified date object formatted as a 2 digit string.
*
* @param date - Date object representing the date.
* @return string - Representing the formatted minutes.
*/
WST.Utils.DateUtils.prototype.getFormattedMinutes = function(date) {
    if (date.getMinutes() < 10) {
        return "0" + date.getMinutes();
    }
    return date.getMinutes();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns am or pm based on the specified date object.
*
* @param date - Date object representing the date and time.
* @return string - Representing whether it is am or pm.
*/
WST.Utils.DateUtils.prototype.getAMPM = function(date) {
    if (date.getHours() >= 12) {
        return "pm";
    }
    return "am";
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the hour for the specified date based on the 12 hour clock.
*
* @param date - Date object representing the date and time.
* @return string - Representing the hour.
*/
WST.Utils.DateUtils.prototype.getFormattedHours = function(date) {
    if (date.getHours() > 12) {
        return date.getHours() - 12;
    }
    return date.getHours();
}

WST.Utils.DateUtils.prototype.getFormattedDateRange = function(startDate, startTime, endDate, endTime) {
    var formattedDate = this.getFormattedSummarizedDate(startDate);
    if (Lib.Utils.ObjectUtils.isDefined(startTime)) {
        formattedDate = formattedDate + " " + startTime;
    }
    formattedDate = formattedDate + " - ";
    if (Lib.Utils.ObjectUtils.isDefined(endDate)) {
        formattedDate = formattedDate + this.getFormattedSummarizedDate(endDate);
        if (Lib.Utils.ObjectUtils.isDefined(endTime)) {
            formattedDate = formattedDate + " " + endTime;
        }
    } else {
        formattedDate = formattedDate + "No End Date";
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedDateAndTime = function(date, time) {
    var formattedDate = this.getFormattedSummarizedDate(date);
    if (Lib.Utils.ObjectUtils.isDefined(time)) {
        formattedDate = formattedDate + " " + time;
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedSummarizedDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}