// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Event.WindowCloseEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.View");

WST.TourCalendar.View.CalendarEntryView = function(template, tourList, outOfOfficeList, viewDataType) {
    this._template = template;
    this._tourList = tourList;
    this._outOfOfficeList = outOfOfficeList;
    this._viewDataType = viewDataType;
    this._entryEvents = new Array();
}

WST.TourCalendar.View.CalendarEntryView.prototype.updateDateElement = function(date, dateElement) {
    if (Lib.Utils.ObjectUtils.isDefined(this._tourList)) {
        this._addTours(date, dateElement);
    }
    if (Lib.Utils.ObjectUtils.isDefined(this._outOfOfficeList)) {
        this._addOutOfOffice(date, dateElement);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype.registerCalendarEntryEvent = function(event) {
    this._entryEvents.push(event);
}

WST.TourCalendar.View.CalendarEntryView.prototype._attachCalendarEntryEvents = function(calendarEntryLink, entryDetailElement) {
    for (var i = 0; i < this._entryEvents.length; i++) {
        var event = new this._entryEvents[i](entryDetailElement);
        event.attachEvent(calendarEntryLink);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTours = function(date, dateElement) {
  var tours = this._tourList.getToursByDate(date);
  if (tours != null && tours.length > 0){
     if (Lib.Utils.ObjectUtils.isDefined(this._viewDataType)
         && this._viewDataType == 'RequestTour'){
                 this._addToursForRequestTours(dateElement, tours);
     }else{
       this._addToursForScheduledTours(dateElement, tours);
     }
  }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForRequestTours = function(dateElement, tours) {
      if (tours != null && tours.length > 0){
      var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarRequestedTourEntry'));
      var dateLink = cssQuery('.dateLink', dateElement)[0];
      var entryDetail = cssQuery('.entryRequestedTourDetail', calendarEntry)[0];

        var popupHTML = '<ul class="calStartTimePlace">';
        for (var i = 0; i < tours.length; i++) {
          popupHTML  +=  '   <li>' +
                               tours[i].getStartTime() +
                               '  ' +
                               tours[i].getPlace() +
                          '   </li>';
        }
        popupHTML += '</ul>';
        entryDetail.innerHTML = popupHTML;
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

//      var calStartTimePlace = cssQuery('.calStartTimePlace', entryDetail)[0];
//      Lib.Utils.XML.XMLUtils.removeAllChildren(calStartTimePlace);
//      for (var i = 0; i < tours.length; i++) {
//          var listElement = document.createElement('li');
//          listElement.innerHTML = tours[i].getStartTime() + " " + tours[i].getPlace() ;
//          calStartTimePlace.appendChild(listElement);
//      }
//      Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

      this._attachCalendarEntryEvents(dateLink, entryDetail);
      dateElement.appendChild(calendarEntry);
    }
  }

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForScheduledTours = function(dateElement, tours) {
           var dateEntry = document.createElement('div');
           dateEntry.className = 'dateEntry';
           for (var i = 0; i < tours.length; i++) {
              var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarTourEntry'));
              var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
                //calendarEntryLink.title = tours[i].getOrganization(); // in anticipation of client req
                calendarEntryLink.title = tours[i].getPlace();
              var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];             
              timeElement.innerHTML = tours[i].getStartTime();
              var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
                 // descElement.innerHTML = tours[i].getOrganization();// in anticipation of client req
                  descElement.innerHTML = tours[i].getPlace();
              var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
              this._addTourDetails(entryDetail, tours[i], calendarEntryLink);
              Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
              this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
              dateEntry.appendChild(calendarEntry);
            }
       dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOffice = function(date, dateElement) {
    var outOfOfficeList = this._outOfOfficeList.getOutOfOfficeByDate(date);
    var dateEntry = document.createElement('div');
    dateEntry.className = 'dateEntry';
    for (var i = 0; i < outOfOfficeList.length; i++) {
        var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarOutOfOfficeEntry'));
        var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
        var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];
        timeElement.innerHTML = outOfOfficeList[i].getStartTime();
        var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
        descElement.innerHTML = 'OOO';
        var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
        this._addOutOfOfficeDetails(entryDetail, outOfOfficeList[i], calendarEntryLink);
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
        this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
        dateEntry.appendChild(calendarEntry);
    }
    dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTourDetails = function(entryDetails, tour, calendarEntryLink) {
  var guideElements = "";
  for (var i = 0; i < tour.getGuides().length; i++) {
      guideElements = guideElements + "<li>" + tour.getGuides()[i].getName() + "</li>";
  }

  var detailPopupHtml = '<h3 class="tourDetailsHeader">Tour</h3>' +
                        '<dl class="detailedDefinitions">' +
                        '    <dt>Location:</dt>' +
                        '    <dd class="calDetailPlace">' + tour.getPlace() + '</dd>' +
                        '    <dt>Start:</dt>' +
                        '    <dd class="entryDetailStartDateAndTime">' + tour.getFormattedStartDateAndTime() + '</dd>' +
                        '    <dt>End:</dt>' +
                        '    <dd class="entryDetailEndDateAndTime">' + tour.getFormattedEndDateAndTime() + '</dd>' +
                        '    <dt>Organization:</dt>' +
                        '    <dd class="calDetailOrganization">' + tour.getOrganization() + '</dd>' +
                        '    <dt>Guests:</dt>' +
                        '    <dd class="calDetailNumGuests">' + tour.getNumGuests() + '</dd>' +
                        '    <dt>Room Number:</dt>' +
                        '    <dd class="calDetailLocation">' + tour.getLocation() + '</dd>' +
                        '</dl>' +
                        '<br class="mozclear"/>' +
                        '<span class="calDetailGuidesLabel">Guides:</span>' +
                        '<ul class="calDetailGuideList">' +
                        guideElements +
                        '</ul>';
  
  entryDetails.innerHTML = detailPopupHtml;

  calendarEntryLink.href = 'tourDetails.htm?method=tourDetail&tourId=' + tour.getId();

//    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
//    entryDetailStartDateAndTime.innerHTML = tour.getFormattedStartDateAndTime();
//    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
//    entryDetailEndDateAndTime.innerHTML = tour.getFormattedEndDateAndTime();
//    var calDetailOrganization = cssQuery('.calDetailOrganization', entryDetails)[0];
//    calDetailOrganization.innerHTML = tour.getOrganization();
//    var calDetailNumGuests = cssQuery('.calDetailNumGuests', entryDetails)[0];
//    calDetailNumGuests.innerHTML = tour.getNumGuests();
//    var calDetailPlace = cssQuery('.calDetailPlace', entryDetails)[0];
//    calDetailPlace.innerHTML = tour.getPlace();
//    var calDetailLocation = cssQuery('.calDetailLocation', entryDetails)[0];
//    calDetailLocation.innerHTML = tour.getLocation();
    //var tourDetailsLink = cssQuery('.tourDetailsLink', entryDetails)[0];
//    var calDetailGuideList = cssQuery('.calDetailGuideList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailGuideList);
//    for (var i = 0; i < tour.getGuides().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = tour.getGuides()[i].getName();
//        calDetailGuideList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOfficeDetails = function(entryDetails, outOfOffice, calendarEntryLink) {
    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
    entryDetailStartDateAndTime.innerHTML = outOfOffice.getStartTime();
    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
    entryDetailEndDateAndTime.innerHTML = outOfOffice.getEndTime();
    calendarEntryLink.href = 'outofoffice.htm?guide=' + outOfOffice.getGuideId();
//    var calDetailDayList = cssQuery('.calDetailDayList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailDayList);
//    for (var i = 0; i < outOfOffice.getDays().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = outOfOffice.getDays()[i];
//        calDetailDayList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

//WST.TourCalendar.View.CalendarEntryView.prototype._attachWindowCloseEvent = function(entryDetails) {
//    var closeLink = cssQuery('.xClose', entryDetails)[0];
//    var event = new WST.Event.WindowCloseEvent(entryDetails);
//    event.attachEvent(closeLink, 'click');
//}

WST.TourCalendar.View.CalendarEntryView.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
