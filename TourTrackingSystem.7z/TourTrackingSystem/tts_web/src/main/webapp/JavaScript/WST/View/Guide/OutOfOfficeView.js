// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
JSAN.use('WST.View.Guide.Event.AllDayEvent');
JSAN.use('WST.View.Guide.Event.RecursEvent');
JSAN.use('WST.View.Guide.Event.ViewOutOfOfficeEvent');
JSAN.use('WST.View.Guide.Event.EndTimeChangeEvent');
JSAN.use('WST.View.Guide.Event.EndDateChangeEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide");

/**
* author: Nate Minshew
* date created: 07/26/2006
* @constructor
* description:
*   This object is a view object for the Out of Office page.  It sents any events on the page and interacts with the
*   HTML.
*
* @param startDateCalendar - Calendar for the start date.
* @param endDateCalendar - Calendar for the end date.
* @param baseElement - Base HTML element for this view.
* @param xmlUtils - XML utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param objectUtils - Object utility object.
*/
WST.View.Guide.OutOfOfficeView = function(startDateCalendar, endDateCalendar, baseElement, xmlUtils, documentUtils,
                                          eventUtils, objectUtils, formUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._formUtils = formUtils;
    this._objectUtils = objectUtils;
    this._attachCalendars(startDateCalendar, endDateCalendar, xmlUtils, eventUtils);
    this._attachAllDayEvent(eventUtils);
    this._attachRecursEvent(eventUtils);
    this.hideReoccurringFields();
    this._attachViewResultsEvent(formUtils, eventUtils);
    this._attachDateChangeEvent(eventUtils);
    this._attachTimeChangeEvent(eventUtils);
    this.updateEndTimeField();
    var reference = objectUtils.weakBind(this.updateStartDate, this);
    startDateCalendar.registerDateEventListener(reference);
    reference = objectUtils.weakBind(this.updateEndDate, this);
    endDateCalendar.registerDateEventListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method attaches the calendar html elements to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param xmlUtils - XML utility object.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachCalendars = function(startDateCalendar, endDateCalendar, xmlUtils,
                                                                     eventUtils) {
    var startDateCalendarElement = startDateCalendar.getCalendar();
    var endDateCalendarElement = endDateCalendar.getCalendar();
    this._documentUtils.addClass(startDateCalendarElement, 'hide');
    this._documentUtils.addClass(endDateCalendarElement, 'hide');
    var dateFieldsElement = cssQuery('#dateFields', this._baseElement)[0];
    var endDateLabel = cssQuery('#endDateLabel', this._baseElement)[0];
    var startDateLabel = cssQuery('#startDateLabel', this._baseElement)[0];
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
//    dateFieldsElement.appendChild(brElement);
//    dateFieldsElement.appendChild(startDateCalendarElement);
//    dateFieldsElement.appendChild(endDateCalendarElement);
//    dateFieldsElement.appendChild(brElement);

    xmlUtils.insertAfter(brElement, startDateLabel);
    xmlUtils.insertAfter(startDateCalendarElement, startDateLabel);
    this._documentUtils.removeClass(brElement, 'mozclear');
    xmlUtils.insertAfter(brElement, startDateCalendarElement);

//  startDateCalendarElement.appendChild(brElement);
//  startDateLabel.appendChild(brElement);
//  startDateLabel.appendChild(brElement);
//  startDateLabel.appendChild(startDateCalendarElement);

  this._documentUtils.addClass(brElement, 'mozclear');
xmlUtils.insertAfter(brElement, endDateLabel);
xmlUtils.insertAfter(endDateCalendarElement, endDateLabel);
this._documentUtils.removeClass(brElement, 'mozclear');
xmlUtils.insertAfter(brElement, endDateCalendarElement);

//  endDateCalendarElement.appendChild(brElement);
//  endDateLabel.appendChild(brElement);
//  endDateLabel.appendChild(brElement);
//  endDateLabel.appendChild(endDateCalendarElement);
  
    this._attachCalendarEvents(startDateCalendarElement, endDateCalendarElement, eventUtils);
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method updates the start date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Guide.OutOfOfficeView.prototype.updateStartDate = function(date) {
    var dateField = cssQuery('#startDate', this._baseElement)[0];
    var calendarElement = cssQuery('#startDateCalendar', this._baseElement)[0];
    this._updateDate(dateField, calendarElement, date);
    var endDateField = cssQuery('#endDate', this._baseElement)[0];
    if ( endDateField.value < dateField.value){
      this.updateEndDate(date);
    }
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method updates the end date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Guide.OutOfOfficeView.prototype.updateEndDate = function(date) {
    var dateField = cssQuery('#endDate', this._baseElement)[0];
    var calendarElement = cssQuery('#endDateCalendar', this._baseElement)[0];
    this._updateDate(dateField, calendarElement, date);
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method hides the time fields.
*/
WST.View.Guide.OutOfOfficeView.prototype.hideTimeFields = function() {
    var startTimeLabel = cssQuery('#startTimeLabel', this._baseElement)[0];
    var endTimeLabel = cssQuery('#endTimeLabel', this._baseElement)[0];
    var startTimeField = cssQuery('#startTime', this._baseElement)[0];
    var endTimeField = cssQuery('#endTime', this._baseElement)[0];
    startTimeField.selectedIndex = -1;
    endTimeField.selectedIndex = -1;
    this._documentUtils.addClass(startTimeLabel, 'invisible');
    this._documentUtils.addClass(endTimeLabel, 'invisible');
}

WST.View.Guide.OutOfOfficeView.prototype.updateEndTimeField = function() {
    var startTimeField = cssQuery('#startTime', this._baseElement)[0];
    var endTimeField = cssQuery('#endTime', this._baseElement)[0];
//    if ( endTimeField.value <= startTimeField.value){
//        endTimeField.selectedIndex = startTimeField.selectedIndex + 2;
//    }
//    if ( startTimeField.value == '17:00'){
    if ( startTimeField.selectedIndex >= 44){ //5pm
      // TODO Need to set the end time to 9:00 am the next day.
      endTimeField.selectedIndex = startTimeField.selectedIndex + 2;
    }
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method displays the time fields.
*/
WST.View.Guide.OutOfOfficeView.prototype.showTimeFields = function() {
    var startTimeLabel = cssQuery('#startTimeLabel', this._baseElement)[0];
    var endTimeLabel = cssQuery('#endTimeLabel', this._baseElement)[0];
    var startTimeField = cssQuery('#startTime', this._baseElement)[0];
    var endTimeField = cssQuery('#endTime', this._baseElement)[0];
    startTimeField.selectedIndex = 8; //8am
    endTimeField.selectedIndex = 44; //5pm
    this._documentUtils.removeClass(startTimeLabel, 'invisible');
    this._documentUtils.removeClass(endTimeLabel, 'invisible');
}

/**
* author: Nate Minshew
* date created: 08/01/2006
* access level: public
* description:
*   This method hides the reoccurring fields.
*/
WST.View.Guide.OutOfOfficeView.prototype.hideReoccurringFields = function() {
    var recurringFields = cssQuery('#reoccurringFields', this._baseElement)[0];
    var monday = cssQuery('#monday', this._baseElement)[0];
    var tuesday = cssQuery('#tuesday', this._baseElement)[0];
    var wednesday = cssQuery('#wednesday', this._baseElement)[0];
    var thursday = cssQuery('#thursday', this._baseElement)[0];
    var friday = cssQuery('#friday', this._baseElement)[0];
    var saturday = cssQuery('#saturday', this._baseElement)[0];
    var sunday = cssQuery('#sunday', this._baseElement)[0];
    monday.checked = false;
    tuesday.checked = false;
    wednesday.checked = false;
    thursday.checked = false;
    friday.checked = false;
    saturday.checked = false;
    sunday.checked = false;
    this._documentUtils.addClass(recurringFields, 'invisible');
}

/**
* author: Nate Minshew
* date created: 08/01/2006
* access level: public
* description:
*   This method displays the reoccurring fields.
*/
WST.View.Guide.OutOfOfficeView.prototype.showReoccurringFields = function() {
    var recurringFields = cssQuery('#reoccurringFields', this._baseElement)[0];
    this._documentUtils.removeClass(recurringFields, 'invisible');
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: private
* description:
*   This method attaches the all day event to the all day checkbox.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachAllDayEvent = function(eventUtils) {
    var allDayElement = cssQuery('#allDay', this._baseElement)[0];
    var event = new WST.View.Guide.Event.AllDayEvent(eventUtils, this, allDayElement);
    event.attachEvent(allDayElement, 'click');
}

/**
* author: Uma K
* date created: 12/12/2006
* access level: private
* description:
*   This method attaches the time change event
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachTimeChangeEvent = function(eventUtils) {
    var startTimeField = cssQuery('#startTime', this._baseElement)[0];
    var event = new WST.View.Guide.Event.EndTimeChangeEvent(eventUtils, this._baseElement, this._formUtils);
    event.attachEvent(startTimeField, 'change');
}

/**
* author: Uma K
* date created: 12/12/2006
* access level: private
* description:
*   This method attaches the date change event
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachDateChangeEvent = function(eventUtils) {
    var startDateField = cssQuery('#startDate', this._baseElement)[0];
    var event = new WST.View.Guide.Event.EndDateChangeEvent(eventUtils, this._baseElement, this._formUtils);
    event.attachEvent(startDateField, 'change');
}

/**
* author: Nate Minshew
* date created: 08/01/2006
* access level: private
* description:
*   This method attaches the Recurs event to the Recurs checkbox.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachRecursEvent = function(eventUtils) {
    var recursElement = cssQuery('#recurs', this._baseElement)[0];
    var event = new WST.View.Guide.Event.RecursEvent(eventUtils, this, recursElement);
    event.attachEvent(recursElement, 'click');
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method attaches the calendar events to the calendar icons.
*
* @param startDateCalendarElement - HTML element of the start date calendar.
* @param endDateCalendarElement - HTML element of the end date calendar.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.OutOfOfficeView.prototype._attachCalendarEvents = function(startDateCalendarElement,
                                                                         endDateCalendarElement, eventUtils) {
    var calendarLink = cssQuery('#startDateCalendarLink', this._baseElement)[0];
    var event = new WST.View.Event.ToggleCalendarEvent(startDateCalendarElement, eventUtils, this._documentUtils);
    event.attachEvent(calendarLink, 'click');
    calendarLink = cssQuery('#endDateCalendarLink', this._baseElement)[0];
    event = new WST.View.Event.ToggleCalendarEvent(endDateCalendarElement, eventUtils, this._documentUtils);
    event.attachEvent(calendarLink, 'click');
}

WST.View.Guide.OutOfOfficeView.prototype._attachViewResultsEvent = function(formUtils, eventUtils) {
    var guideElement = cssQuery('#guide', this._baseElement)[0];
    if (this._objectUtils.isDefined(guideElement)) {
        var event = new WST.View.Guide.Event.ViewOutOfOfficeEvent(eventUtils, formUtils, guideElement);
        event.attachEvent(guideElement, 'change');
    }
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: private
* description:
*   This method updates the date of the specified date field.
*
* @param dateField - HTML input field to update.
* @param calendarElement - HTML element of the calendar for specified date field.
* @param date - Date object representing the new date.
*/
WST.View.Guide.OutOfOfficeView.prototype._updateDate = function(dateField, calendarElement, date) {
    dateField.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    this._documentUtils.addClass(calendarElement, 'hide');
}
