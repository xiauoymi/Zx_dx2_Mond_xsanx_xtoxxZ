// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.SaveTourEvent');
JSAN.use('WST.View.RequestTour.Event.NextTabEvent');
JSAN.use('WST.View.RequestTour.Event.SkipTabEvent');
JSAN.use('WST.View.RequestTour.Event.PreviousTabEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the form navigation section of the request a tour page.  It is responsible for
*   updating the html and adding events related to form navigation.
*
* @param tabNavigator - Tab Navigation widget.
* @param disableCssClass - CSS class used for hidding html.
* @param documentUtils - Document utility object.
* @param baseElement - Root html element for the section.
* @param objectUtils - Object utility object.
* @param formElement - HTML element representing the form.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView = function(
        tabNavigator,
        disableCssClass,
        documentUtils,
        baseElement,
        objectUtils,
        formElement,
        eventUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._disableCssClass = disableCssClass;
    this._tabNavigator = tabNavigator;
    this.updateVisibleNavigation();
    this._attachFinishedEvent(formElement, eventUtils);
    this._attachNextEvent(eventUtils);
    this._attachSkipEvent(eventUtils);
    this._attachBackEvent(eventUtils);
    var reference = objectUtils.weakBind(this.updateVisibleNavigation, this);
    tabNavigator.addListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method updates the visible navigation, hiding the back link if on the first tab, etc.
*/
WST.View.RequestTour.FormNavView.prototype.updateVisibleNavigation = function() {
    if (this._tabNavigator.isFirstTabActive()) {
        this._hideBackLink();
        this._showNextLink();
        this._hideSubmitLink();
        this._showSkipLink();
    } else if (this._tabNavigator.isLastTabActive()) {
        this._hideNextLink();
        this._showBackLink();
        this._showSubmitLink();
        this._hideSkipLink();
    } else {
        this._showNextLink();
        this._showBackLink();
        this._hideSubmitLink();
        this._showSkipLink();
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the back link.
*/
WST.View.RequestTour.FormNavView.prototype._hideBackLink = function() {
    var backElement = cssQuery('#backNav', this._baseElement);
    for(var i = 0; i < backElement.length; i++){
      this._documentUtils.addClass(backElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the submit link only if skipNav exists on the page
*/
WST.View.RequestTour.FormNavView.prototype._hideSubmitLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    if(skipElement.length > 0){
    var submitElement = cssQuery('#finishedNav', this._baseElement);
    for(var i = 0; i < submitElement.length; i++){
      this._documentUtils.addClass(submitElement[i], this._disableCssClass);
    }
   }
}


/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the submit link only if skipNav exists on the page
*/
WST.View.RequestTour.FormNavView.prototype._showSubmitLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    if(skipElement.length > 0){
    var submitElement = cssQuery('#finishedNav', this._baseElement);
      for(var i = 0; i < submitElement.length; i++){
         this._documentUtils.removeClass(submitElement[i], this._disableCssClass);
     }
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the skip link.
*/
WST.View.RequestTour.FormNavView.prototype._hideSkipLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    for(var i = 0; i < skipElement.length; i++){
      this._documentUtils.addClass(skipElement[i], this._disableCssClass);
   }

}


/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the skip link.
*/
WST.View.RequestTour.FormNavView.prototype._showSkipLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
      for(var i = 0; i < skipElement.length; i++){
         this._documentUtils.removeClass(skipElement[i], this._disableCssClass);
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the back link.
*/
WST.View.RequestTour.FormNavView.prototype._showBackLink = function() {
    var backElement = cssQuery('#backNav', this._baseElement);
      for(var i = 0; i < backElement.length; i++){
         this._documentUtils.removeClass(backElement[i], this._disableCssClass);
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the next link.
*/
WST.View.RequestTour.FormNavView.prototype._hideNextLink = function() {
    var nextElement = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextElement.length; i++){
         this._documentUtils.addClass(nextElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the next link.
*/
WST.View.RequestTour.FormNavView.prototype._showNextLink = function() {
    var nextElement = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextElement.length; i++){
         this._documentUtils.removeClass(nextElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the form submit events to the submit link.
*
* @param formElement - Form html element.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachFinishedEvent = function(formElement, eventUtils) {
    var saveAsLink = cssQuery('#saveAsNav', this._baseElement);
  if(saveAsLink != null){
    for(var i = 0; i < saveAsLink.length; i++){
      var event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
      event.attachEvent(saveAsLink[i], 'click');
    }
  }
      //    var finishedLink = cssQuery('#finishedNav', this._baseElement);
  //    if(finishedLink != null){
  //        for(var i = 0; i < finishedLink.length; i++){
  //          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
  //          event.attachEvent(finishedLink[i], 'click');
  //         }
  //    }
  //    var approveLink = cssQuery('#approveNav', this._baseElement);
  //    if(approveLink != null){
  //      for(var i = 0; i < approveLink.length; i++){
  //        event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
  //        event.attachEvent(approveLink[i], 'click');
//        }
//    }
//    var pendingLink = cssQuery('#pendingNav', this._baseElement);
//    if(pendingLink != null){
//      for(var i = 0; i < pendingLink.length; i++){
//          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//          event.attachEvent(pendingLink[i], 'click');
//       }
//    }
//    var resetToNewLink = cssQuery('#resetToNewNav', this._baseElement);
//    if(resetToNewLink != null){
//      for(var i = 0; i < resetToNewLink.length; i++){
//          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//          event.attachEvent(resetToNewLink[i], 'click');
//       }
//    }
//   var declineLink = cssQuery('#declineNav', this._baseElement);
//    if(declineLink != null){
//      for(var i = 0; i < declineLink.length; i++){
//        event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//        event.attachEvent(declineLink[i], 'click');
//       }
//    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the next tab event to the next link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachNextEvent = function(eventUtils) {
    var nextLink = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextLink.length; i++){
        var event = new WST.View.RequestTour.Event.NextTabEvent(eventUtils, this._tabNavigator);
        event.attachEvent(nextLink[i], 'click');
    }
}
/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the skip(confirm) tab event to the skip link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachSkipEvent = function(eventUtils) {
    var skipLink = cssQuery('#skipNav', this._baseElement);
    if(skipLink != null){
      for(var i = 0; i < skipLink.length; i++){
         var event = new WST.View.RequestTour.Event.SkipTabEvent(eventUtils, this._tabNavigator);
         event.attachEvent(skipLink[i], 'click');
      }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the previous tab event to the back link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachBackEvent = function(eventUtils) {
    var backLink = cssQuery('#backNav', this._baseElement);
    for(var i = 0; i < backLink.length; i++){
        var event = new WST.View.RequestTour.Event.PreviousTabEvent(eventUtils, this._tabNavigator);
        event.attachEvent(backLink[i], 'click');
   }

}
