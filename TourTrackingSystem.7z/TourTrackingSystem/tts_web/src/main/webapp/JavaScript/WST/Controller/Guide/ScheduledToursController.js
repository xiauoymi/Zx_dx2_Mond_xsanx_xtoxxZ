// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.TourList');
JSAN.use('WST.TourCalendar.Model.OutOfOfficeList');
JSAN.use('WST.TourCalendar.View.CalendarEntryView');
JSAN.use('WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Guide");

/**
* author: Sonal Patidar
* date created: 08/28/2006
* @constructor
* description:
*   This object is a controller for scheduled tours.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param scheduledTourListUrl - Url of the scheduled tours list service.
*/
WST.Controller.Guide.ScheduledToursController = function(template, guideId) {
    this._template = template;
    this._guideId = guideId;
}

WST.Controller.Guide.ScheduledToursController.prototype._getTourList = function(calendar, currentDate) {
    return new WST.TourCalendar.Model.TourList('SCHEDULED', true, this._guideId, calendar, currentDate, this, this.updateCalendar);
}

WST.Controller.Guide.ScheduledToursController.prototype._getOutOfOfficeList = function(currentDate) {
    return new WST.TourCalendar.Model.OutOfOfficeList(this._guideId, currentDate);
}

WST.Controller.Guide.ScheduledToursController.prototype._getCalendarEntryView = function(tourList, outOfOfficeList) {
    var viewDataType = 'ScheduledTours';
    var view = new WST.TourCalendar.View.CalendarEntryView(this._template, tourList, outOfOfficeList, viewDataType);
    view.registerCalendarEntryEvent(WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent);
    view.registerCalendarEntryEvent(WST.Event.WindowCloseEvent);
    return view;
}

WST.Controller.Guide.ScheduledToursController.prototype.updateCalendar = function(tourList, calendar, currentDate, thisClass) {
//  var tourList = this._getTourList(currentDate);
    var outOfOfficeList = thisClass._getOutOfOfficeList(currentDate);
    thisClass._registerCalendarEntryViewWithCalendar(tourList, outOfOfficeList, calendar, thisClass);
    thisClass._registerTourListWithCalendar(tourList, calendar, currentDate);
    thisClass._registerOutOfOfficeListWithCalendar(outOfOfficeList, calendar);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerCalendarEntryViewWithCalendar = function(tourList, outOfOfficeList, calendar, thisClass) {
    var calendarEntryView = thisClass._getCalendarEntryView(tourList, outOfOfficeList);
    var reference = Lib.Utils.ObjectUtils.weakBind(calendarEntryView.updateDateElement, calendarEntryView);
    calendar.registerDateInitListener(reference);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerTourListWithCalendar = function(tourList, calendar, currentDate) {
    reference = Lib.Utils.ObjectUtils.weakBind(tourList.updateList, tourList);
    calendar.registerMonthChangeListener(reference);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerOutOfOfficeListWithCalendar = function(outOfOfficeList, calendar) {
    reference = Lib.Utils.ObjectUtils.weakBind(outOfOfficeList.updateList, outOfOfficeList);
    calendar.registerMonthChangeListener(reference);
}