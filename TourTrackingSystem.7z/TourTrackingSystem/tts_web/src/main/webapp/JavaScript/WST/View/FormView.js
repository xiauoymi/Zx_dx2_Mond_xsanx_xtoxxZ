// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object adds global functionality across all forms on the site.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView = function(xmlUtils, objectUtils) {
    this._appendSpecialTextToRequiredFormLabels(xmlUtils, objectUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method prepends all required field labels with a special character.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView.prototype._appendSpecialTextToRequiredFormLabels = function(xmlUtils, objectUtils) {
    var requiredLabels = cssQuery('.required');
    for (var i = 0; i < requiredLabels.length; i++) {
        var spanElement = document.createElement('span');
        spanElement.className = 'requiredIndicator';
        spanElement.appendChild(document.createTextNode('*'));

        var newNode = requiredLabels[i].cloneNode();
        var childNodes = requiredLabels[i].childNodes;
        newNode.appendChild(spanElement);
        for (var j = 0; j < childNodes.length; j++) {
            newNode.appendChild(childNodes[j]);
        }
        var parent = requiredLabels[i].parentNode;
        parent.replaceChild(newNode, requiredLabels[i]);
    }
}