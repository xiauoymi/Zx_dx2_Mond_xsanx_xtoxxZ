// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Model.Admin.UserMaintenance");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

/**
* author: Sonal Patidar
* date created: 08/23/2006
* @constructor
* description:
*   This object represents a list of users .
*
* @param blackoutListXML - XML document representing the users .
*/
WST.Model.Admin.UserMaintenanceList = function(userMaintenanceListXML) {
    this._users = new Array();
    this._parseList(userMaintenanceListXML);
}

/**
* author: Sonal Patidar
* date created: 08/23/2006
* access level: public
* description:
*   This method returns an array of users objects.
*/
WST.Model.Admin.UserMaintenanceList.prototype.getUsers = function() {
    return this._users;
}

/**
* author: Sonal Patidar
* date created: 08/23/2006
* access level: public
* description:
*   This method returns an array of name name.
*/
WST.Model.Admin.UserMaintenanceList.prototype.getUserNames = function() {
    var names = new Array();
    for (var i = 0; i < this._users.length; i++) {
        names.push(this._users[i].getName());
    }
    return names;
}

/**
* author: Sonal Patidar
* date created: 08/23/2006
* access level: public
* description:
*   This method returns an array of user roles.
*/
WST.Model.Admin.UserMaintenanceList.prototype.getUserRoles = function() {
    var roles = new Array();
    for (var i = 0; i < this._users.length; i++) {
        roles.push(this._users[i].getRole());
    }
    return names;
}

/**
* author: Sonal Patidar
* date created: 08/23/2006
* access level: private
* description:
*   This method parses the xml document of users into user objects.
*
* @param blackoutListXML - XML document representing the user .
*/
WST.Model.Admin.UserMaintenanceList.prototype._parseList = function(usersListXML) {
    var userElements = usersListXML.getElementsByTagName('user');
    for (var i = 0; i < userElements.length; i++) {
        var userName = userElements[i].getAttribute('userName');
        var roles = userElements[i].getAttribute('roles');
        this._users.push(new WST.Model.Admin.UserMaintenance(userName, roles));
    }
}
