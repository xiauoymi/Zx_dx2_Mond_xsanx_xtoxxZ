// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/13/2006
* @constructor
* description:
*   This object is used to display error messages to the user.
*
* @param baseElement - Root html element for error messages.
* @param documentUtils - Document utility object
* @param objectUtils - Object utility object.
* @param xmlUtils - XML utility object.
*/
WST.View.ErrorView = function(baseElement, documentUtils, objectUtils, xmlUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._objectUtils = objectUtils;
    this._xmlUtils = xmlUtils;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method displays the specified error message and decorates the specified field's label.
*
* @param message - Text error message.
* @param field - HTML element for the field that has the error.
*/
WST.View.ErrorView.prototype.displayErrorMessage = function(message, field) {
    var brElement = document.createElement('br');
    this._baseElement.appendChild(document.createTextNode(message));
    this._baseElement.appendChild(brElement);
    if (this._objectUtils.isDefined(field)) {
        this._decorateErrorFieldLabel(field);
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method clears all error messages currently being displayed.
*/
WST.View.ErrorView.prototype.clearAllErrors = function() {
    this._xmlUtils.removeAllChildren(this._baseElement);
    this._clearErrorLabels();
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method clears all error labels.
*/
WST.View.ErrorView.prototype._clearErrorLabels = function() {
    var errorFields = cssQuery('.fieldError');
    for (var i = 0; i < errorFields.length; i++) {
        Lib.Utils.DocumentUtils.removeClass(errorFields[i], 'fieldError');
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method decorates the label of the specified field.
*
* @param field - HTML input element with the error.
*/
WST.View.ErrorView.prototype._decorateErrorFieldLabel = function(field) {
    var fieldLabel = document.getElementById(field.id + '-label');
    if (this._objectUtils.isDefined(fieldLabel)) {
        this._documentUtils.addClass(fieldLabel, 'fieldError');
    }
}