// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This is an event object for switching to a previous tab on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param tabNavigator - DHTML tab navigator widget.
*/
WST.View.RequestTour.Event.PreviousTabEvent = function(eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.PreviousTabEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event, switching to the previous tab.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.PreviousTabEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.previousTab();
}