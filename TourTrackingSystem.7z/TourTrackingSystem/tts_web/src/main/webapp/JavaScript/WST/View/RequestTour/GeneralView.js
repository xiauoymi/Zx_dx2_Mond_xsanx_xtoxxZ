// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is the view for the general section of the request a tour page.  It handles all events and html on the
*   general section.
*
* @param calendar - Calendar widget.
* @param baseElement - Root html element of the general section.
* @param xmlUtils - XML utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param objectUtils - Object utility object.
*/
WST.View.RequestTour.GeneralView = function(calendar, baseElement, xmlUtils, documentUtils, eventUtils, objectUtils,
                                            confirmController) {
    this._confirmController = confirmController;
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._attachCalendarEvent(calendar, eventUtils, xmlUtils);
    var reference = objectUtils.weakBind(this.updateDate, this);
    calendar.registerDateEventListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method attaches the calendar event to the calendar icon.
*
* @param calendarElement - HTML element of the calendar.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.GeneralView.prototype._attachCalendarEvent = function(calendar, eventUtils, xmlUtils) {
//    var calendarElement = cssQuery('#calendarContainer')[0];
//    var calendarLinks = cssQuery('.calendarLink');
//  for(var i = 0; i < calendarLinks.length; i++) {
//    var calendarLink = calendarLinks[i];
//    var event = new WST.View.Event.ToggleCalendarEvent(calendarElement, eventUtils, this._documentUtils);
//    event.attachEvent(calendarLink, 'click');
//  }

    var element = calendar.getCalendar();
    this._documentUtils.addClass(element, 'hide');
    var tourDateLabel = cssQuery('#tourDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    xmlUtils.insertAfter(brElement, tourDateLabel);
    xmlUtils.insertAfter(element, tourDateLabel);
    this._documentUtils.removeClass(brElement, 'mozclear');
    xmlUtils.insertAfter(brElement, element);

    var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
    if(calendarLink != null){
      var event = new WST.View.Event.ToggleCalendarEvent(element, eventUtils, this._documentUtils);
      event.attachEvent(calendarLink, 'click');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.RequestTour.GeneralView.prototype.updateDate = function(date) {
  var tourDate = cssQuery('#tourDate', this._baseElement)[0];
  tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
  tourDate.onchange();//have to call this manually coz date change from calendar does not trigger onchange automatically
  var calendarElement = cssQuery('.calendar', this._baseElement)[0];
  this._documentUtils.addClass(calendarElement, 'hide');
  this._confirmController.setConfirmValue(tourDate);
 }