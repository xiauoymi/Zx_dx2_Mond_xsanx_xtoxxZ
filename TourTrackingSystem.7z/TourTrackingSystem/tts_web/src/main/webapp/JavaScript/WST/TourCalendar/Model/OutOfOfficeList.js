// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.TourCalendar.Model.OutOfOffice');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOfficeList = function(guideId, currentDate) {
     var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._guideId = guideId;
    this._outOfOfficeList = new Array();
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.refreshList = function() {
    this._outOfOfficeList = this._parseOutOfOfficeXml(this._getOutOfOfficeXml());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.getOutOfOfficeByDate = function(date) {
    var outOfOfficeList = new Array();
    for (var i = 0; i < this._outOfOfficeList.length; i++) {
        if (this._outOfOfficeList[i].getStartDate().getFullYear() == date.getFullYear()
                && this._outOfOfficeList[i].getStartDate().getMonth() == date.getMonth()
                && this._outOfOfficeList[i].getStartDate().getDate() == date.getDate()) {
            outOfOfficeList.push(this._outOfOfficeList[i]);
        }
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseOutOfOfficeXml = function(xmlDoc) {
    var outOfOfficeElements = xmlDoc.getElementsByTagName('outOfOffice');
    var outOfOfficeList = new Array();
    for (var i = 0; i < outOfOfficeElements.length; i++) {
        var id = null; //outOfOfficeElements[i].getAttribute('id');
        var guideId = outOfOfficeElements[i].getAttribute('guideId');
        var guideName = null; //outOfOfficeElements[i].getAttribute('guideName');
        var startDate = outOfOfficeElements[i].getAttribute('startDate');
        var startTime = outOfOfficeElements[i].getAttribute('startTime');
        var endDate = outOfOfficeElements[i].getAttribute('endDate');
        var endTime = outOfOfficeElements[i].getAttribute('endTime');
        var allDay = outOfOfficeElements[i].getAttribute('allDay');
        var noEndDate = outOfOfficeElements[i].getAttribute('noEndDate');
        var days = this._parseDaysXml(outOfOfficeElements[i]);
        outOfOfficeList.push(new WST.TourCalendar.Model.OutOfOffice(id, guideId, guideName, startDate, startTime, endDate,
                endTime, allDay, noEndDate, days));
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseDaysXml = function(outOfOfficeElement) {
    var dayElements = outOfOfficeElement.getElementsByTagName('day');
    var days = new Array();
    for (var i = 0; i < dayElements.length; i++) {
        days.push(dayElements[i].firstChild.nodeValue);
    }
    return days;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getOutOfOfficeServiceUrl());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeServiceUrl = function() {
    return 'lookupOutOfOffice.htm?method=lookupOutOfOfficeByCriteria&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&guideId=' + this._guideId;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
