// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
* author: Uma K
* date created: 12/12/2006
* @constructor
* description:
* This object is an event object for changing the End Time for Out Of Office when the Start Time is changed.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.Event.EndTimeChangeEvent = function(eventUtils, baseElement, formUtils) {
    this._eventUtils = eventUtils;
    this._baseElement = baseElement;
    this._formUtils = formUtils;
}

/**
* author: Uma K
* date created: 12/12/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.Guide.Event.EndTimeChangeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Uma.K
* date created: 12/12/2006
* access level: public
* description:
*   This method executes the event for this object, re-setting the end time based on start time selected
*
* @param evt - Event object provided by the browser.
*/
WST.View.Guide.Event.EndTimeChangeEvent.prototype.executeEvent = function(evt) {
  var startTimeField = cssQuery('#startTime', this._baseElement)[0];
  var endTimeField = cssQuery('#endTime', this._baseElement)[0];
  var startDateField = cssQuery('#startDate', this._baseElement)[0];
  var endDateField = cssQuery('#endDate', this._baseElement)[0];
//  if ( endTimeField.value <= startTimeField.value){
//      endTimeField.selectedIndex = startTimeField.selectedIndex + 2;
//  }
//  if ( startTimeField.value == '16:00'){
  if ( startTimeField.selectedIndex >= 44){//5 pm
  // TODO Need to set the end time to 9:00 am the next day.
    endTimeField.selectedIndex = startTimeField.selectedIndex + 2;
  }
  var guideElement = cssQuery('#guide', this._baseElement)[0];
  var guideId = this._formUtils.getSelectedValue(guideElement);
  location.href = 'outofoffice.htm?guide=' + guideId + '&startTime=' + startTimeField.value + '&endTime=' + endTimeField.value
      + '&startDate=' + startDateField.value + '&endDate=' + endDateField.value
      + '&timeChange=true';

}