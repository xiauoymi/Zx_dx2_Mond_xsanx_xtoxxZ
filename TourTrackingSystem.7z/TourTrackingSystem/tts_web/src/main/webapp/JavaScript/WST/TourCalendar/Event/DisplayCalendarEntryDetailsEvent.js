// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to define events that will cause the calendar to display and hide.
*
* @param calendarElement - HTML element representing the calendar.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent = function(calendarElement) {
    this._calendarElement = calendarElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.attachEvent = function(element) {
    Lib.Utils.EventUtils.addEvent(element, 'mouseover', this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the toggle calendar event, causing the calendar to either be displayed or hidden.
*
* @param evt - Event object provided by the browser.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
    Lib.Utils.DocumentUtils.removeClass(this._calendarElement, 'hide');
}