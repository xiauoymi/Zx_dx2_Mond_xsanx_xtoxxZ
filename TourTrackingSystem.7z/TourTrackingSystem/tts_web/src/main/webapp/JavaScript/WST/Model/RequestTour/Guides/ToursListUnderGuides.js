JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('WST.TourCalendar.Model.Tour');
JSAN.use('WST.TourCalendar.Model.Guide');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.RequestTour.Guides");

WST.Model.RequestTour.Guides.ToursListUnderGuides = function(currentDate, parentClass, callback) {
    if (currentDate != null) {
      this._startDate = currentDate;
      this._tours = new Array();
      this.refreshListAsynchronously(this, parentClass, callback);
    }
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype.refreshListAsynchronously = function(tourListObject,  parentClass, callback) {
    this._tours = this._getToursXmlAsynchronously(tourListObject, parentClass, callback);
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._getToursXmlAsynchronously = function(tourListObject, parentClass, callback) {
    return Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed(this._getTourServiceUrl(), null, null, null, tourListObject, callback, parentClass, this._parseTourXmlAsynchronously);
}


WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._getTourServiceUrl = function() {
    return 'listNewAndScheduledTours.htm?method=lookupNewAndScheduledToursForGuide&view=xml&startDate=' + this._startDate;
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._parseTourXmlAsynchronously = function(request, getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
  var xmlDoc = request.responseXML;
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var status = tourElements[i].getAttribute('status');
        var organization = tourElements[i].getAttribute('organization');
//        if (getGuidesOrNot) {
          guides = tourListObject._parseGuideXml(tourElements[i]);
//        }
        tours.push(new WST.TourCalendar.Model.Tour(id, null, null, startTime, endTime, null, null, null, organization, guides, status));
    }
    tourListObject._tours = tours;
    callback(tourListObject, parentClass);
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._parseGuideXml = function(tourElement) {
    var guideElements = tourElement.getElementsByTagName('guide');
    var guides = new Array();
    for (var i = 0; i < guideElements.length; i++) {
        var id = guideElements[i].getAttribute('id');
        var name = guideElements[i].getAttribute('name');
        guides.push(new WST.TourCalendar.Model.Guide(id, name));
    }
    return guides;
}
