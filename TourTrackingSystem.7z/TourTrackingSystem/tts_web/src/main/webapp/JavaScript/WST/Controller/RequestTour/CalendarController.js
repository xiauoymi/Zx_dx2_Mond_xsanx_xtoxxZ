// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.TourList');
JSAN.use('WST.TourCalendar.Model.OutOfOfficeList');
JSAN.use('WST.TourCalendar.View.CalendarEntryView');
JSAN.use('WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent');
JSAN.use('WST.Event.WindowCloseEvent');
JSAN.use('WST.Event.CancelEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");


WST.Controller.RequestTour.CalendarController = function(template) {
    this._template = template;
}

WST.Controller.RequestTour.CalendarController.prototype._getTourList = function(calendar) {
//    return new WST.TourCalendar.Model.TourList('SCHEDULED');
  return new WST.TourCalendar.Model.TourList('SCHEDULED', false, null, calendar, null, this, this.updateCalendar);

}

WST.Controller.RequestTour.CalendarController.prototype._getCalendarEntryView = function(tourList) {
    var viewDataType = 'RequestTour';
    var view = new WST.TourCalendar.View.CalendarEntryView(this._template, tourList, null, viewDataType);
    view.registerCalendarEntryEvent(WST.Event.CancelEvent);
  view.registerCalendarEntryEvent(WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent);
  view.registerCalendarEntryEvent(WST.Event.WindowCloseEvent);
    return view;
}

WST.Controller.RequestTour.CalendarController.prototype.updateCalendar = function(tourList, calendar, currentDate, thisClass) {
//    var tourList = this._getTourList();
    thisClass._registerCalendarEntryViewWithCalendar(tourList, calendar, thisClass);
    thisClass._registerTourListWithCalendar(tourList, calendar);
}

WST.Controller.RequestTour.CalendarController.prototype._registerCalendarEntryViewWithCalendar = function(tourList, calendar, thisClass) {
    var calendarEntryView = thisClass._getCalendarEntryView(tourList);
    var reference = Lib.Utils.ObjectUtils.weakBind(calendarEntryView.updateDateElement, calendarEntryView);
    calendar.registerDateInitListener(reference);
}

WST.Controller.RequestTour.CalendarController.prototype._registerTourListWithCalendar = function(tourList, calendar) {
    reference = Lib.Utils.ObjectUtils.weakBind(tourList.updateList, tourList);
    calendar.registerMonthChangeListener(reference);
}
