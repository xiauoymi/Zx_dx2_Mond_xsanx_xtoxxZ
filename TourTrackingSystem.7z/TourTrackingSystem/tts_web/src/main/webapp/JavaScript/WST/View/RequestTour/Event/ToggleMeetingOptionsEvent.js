// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object represents the toggle meeting options event.  This causes the meeting options section to be displayed
*   based on whether a meeting room is selected.
*
* @param inputElement - HTML meeting room input element.
* @param eventUtils - Event utility object.
* @param disableCssClass - CSS class used to hide the meeting options sections.
* @param documentUtils - Document utility object.
* @param baseElement - Root html element for the meeting room section.
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent = function(inputElement, eventUtils, disableCssClass, documentUtils, baseElement) {
    this._inputElement = inputElement;
    this._eventUtils = eventUtils;
    this._disableCssClass = disableCssClass;
    this._documentUtils = documentUtils;
    this._baseElement = baseElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, causing the meeting options to be displayed if a meeting room is selected.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent.prototype.executeEvent = function(evt) {
    var extension = cssQuery('#' + this._inputElement.name + '-extension', this._baseElement)[0];
    if (this._inputElement.value == 'true') {
        this._documentUtils.removeClass(extension, this._disableCssClass);
    } else if (this._inputElement.value == 'false') {
        this._documentUtils.addClass(extension, this._disableCssClass);
    }
}