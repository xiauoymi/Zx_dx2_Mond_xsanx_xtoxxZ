// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.RequestTour.Guides.ToursListUnderGuides');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");
      
WST.Controller.RequestTour.TourControllerUnderGuides = function() {
}

WST.Controller.RequestTour.TourControllerUnderGuides.prototype._getTourList = function(currentDate) {
    return new WST.Model.RequestTour.Guides.ToursListUnderGuides(currentDate, this, this.updateTourTableUnderGuides);
}


WST.Controller.RequestTour.TourControllerUnderGuides.prototype.updateTourTableUnderGuides = function(tourListObject, thisClass) {
    var tableElement = document.getElementById('tourTableUnderGuides');
    var tourId = document.getElementById('tourId').value;
    var tbodyElement = tableElement.getElementsByTagName('tbody')[0];
    Lib.Utils.XML.XMLUtils.removeAllChildren(tbodyElement);
    var tours = tourListObject._tours;
    if (tours.length == 1){
        tour = tours[0];
        if (tour.getId() == tourId) {
            var trElement = document.createElement('tr');
            var tdElement = document.createElement('td');
            trElement.colspan = 5;
            tdElement.innerHTML = "No Tours Found."
            trElement.appendChild(tdElement);
            tbodyElement.appendChild(trElement);
            return;
        }
    }
    for(var i=0; i < tours.length; i++) {
        var tour = tours[i];
        if (tour.getId() == tourId){
            continue;
        }
        
        var trElement = document.createElement('tr');

        if (i % 2 == 0) {
            Lib.Utils.DocumentUtils.addClass(trElement, 'even');
        } else {
            Lib.Utils.DocumentUtils.addClass(trElement, 'odd');
        }

        var tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getStartTime();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getEndTime();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getId() + "-" + tour.getOrganization();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        var guides = tour.getGuides();
        if (guides.length == 0){
           tdElement.innerHTML = "No Guide Assigned";
        }

        for (var j = 0; j < guides.length; j++) {
            var guide = guides[j];
                tdElement.innerHTML += guide.getName() + "<br />";
        }
        
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getStatus();
        trElement.appendChild(tdElement);

        tbodyElement.appendChild(trElement);
    }
}