// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a toggle credit card event.  It either displays or hides the credit card section on the page.
*
* @param elements - Array of html elements representing the refreshment fields.
* @param creditCardInfoElement - HTML element representing the credit card section.
* @param disableCssClass - CSS class that causes the credit card section to be hidden.
* @param eventUtils - Event utililty object.
* @param documentUtils - Document utility object.
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent = function(elements, creditCardInfoElement, disableCssClass, eventUtils, documentUtils) {
    this._elements = elements;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
    this._creditCardInfoElement = creditCardInfoElement;
    this._disableCssClass = disableCssClass;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the event, causing the credit card section to toggle if any refreshments are selected.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent.prototype.executeEvent = function(evt) {
    var display = false;
    for (var i = 0; i < this._elements.length; i++) {
        if (this._elements[i].options[this._elements[i].selectedIndex].value.length > 0) {
            display = true;
        }
    }
    if (display) {
        this._documentUtils.removeClass(this._creditCardInfoElement, this._disableCssClass);
    } else {
        this._documentUtils.addClass(this._creditCardInfoElement, this._disableCssClass);
    }
}