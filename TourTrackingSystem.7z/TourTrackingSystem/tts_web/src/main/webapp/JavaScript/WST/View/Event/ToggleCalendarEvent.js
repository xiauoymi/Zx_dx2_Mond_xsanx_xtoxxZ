// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to define events that will cause the calendar to display and hide.
*
* @param calendarElement - HTML element representing the calendar.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
*/
WST.View.Event.ToggleCalendarEvent = function(calendarElement, eventUtils, documentUtils) {
    this._calendarElement = calendarElement;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.Event.ToggleCalendarEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the toggle calendar event, causing the calendar to either be displayed or hidden.
*
* @param evt - Event object provided by the browser.
*/
WST.View.Event.ToggleCalendarEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    if (this._documentUtils.containsClass(this._calendarElement, 'hide')) {
//        var selectElements = document.getElementsByTagName('select');
//        for (var i = 0; i < selectElements.length; i++) {
//            Lib.Utils.DocumentUtils.addClass(selectElements[i], 'invisible');
//        }
        this._documentUtils.removeClass(this._calendarElement, 'hide');
    } else {
//        var selectElements = document.getElementsByTagName('select');
//        for (var i = 0; i < selectElements.length; i++) {
//            Lib.Utils.DocumentUtils.removeClass(selectElements[i], 'invisible');
//        }
        this._documentUtils.addClass(this._calendarElement, 'hide');
    }
}