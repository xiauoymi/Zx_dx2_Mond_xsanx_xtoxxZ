// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOffice = function(id, guideId, guideName, startDate, startTime, endDate, endTime, allDay,
                                              noEndDate, days) {
    this._id = id;
    this._guideId = guideId;
    this._guideName = guideName;
    this._startDate = new Date(startDate);
    if (endDate != '' && endDate != null) {
        this._endDate = new Date(endDate);
    }
    this._startTime = startTime;
    if (endTime != '' && endTime != null) {
        this._endTime = endTime;
    }
    this._allDay = allDay;
    this._noEndDate = noEndDate;
    this._days = days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideId = function() {
    return this._guideId;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideName = function() {
    return this._guideName;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getAllDay = function() {
    return this._allDay;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getNoEndDate = function() {
    return this._noEndDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getDays = function() {
    return this._days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedDateRange = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, null, null);
    }
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, this._endDate, null);
    }
    if (this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, null, null);
    }
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedStartDateAndTime = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, null);
    }else{
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
    }
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedEndDateAndTime = function() {
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, null);
    }else {
      return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
    }
}
