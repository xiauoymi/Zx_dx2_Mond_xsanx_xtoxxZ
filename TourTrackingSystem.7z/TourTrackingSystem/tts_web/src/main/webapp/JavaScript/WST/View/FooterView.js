// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is a view object for the footer.  It handles interacting with the html document and setting up any
*   events.
*
* @param footerElement - Root html element of the footer.
* @param dateUtils - Date utility object.
*/
WST.View.FooterView = function(footerElement, dateUtils) {
    this._footerElement = footerElement;
    this._dateUtils = dateUtils;
    this._setCurrentDate();
    this._setLastModifiedDate();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the current date on the page.
*/
WST.View.FooterView.prototype._setCurrentDate = function() {
    var currentDateElement = cssQuery('#currentDateValue', this._footerElement)[0];
    if (currentDateElement.childNodes.length > 0) {
        currentDateElement.firstChild.nodeValue = this._dateUtils.getFormattedDate(new Date());
    } else {
        currentDateElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDate(new Date())));
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the last modified date on the page.
*/
WST.View.FooterView.prototype._setLastModifiedDate = function() {
    var lastModifiedElement = cssQuery('#lastModifiedDateValue', this._footerElement)[0];
    if (lastModifiedElement.childNodes.length > 0) {
        lastModifiedElement.firstChild.nodeValue = this._dateUtils.getFormattedDateTime(new Date(document.lastModified));
    } else {
        lastModifiedElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDateTime(new Date(document.lastModified))));
    }
}