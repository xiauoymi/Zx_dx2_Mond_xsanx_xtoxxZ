// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.AddGuideEvent');
JSAN.use('WST.View.RequestTour.Event.DeleteGuideEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * @constructor
 * description:
 *   This object is a view object for the guests section of the request a tour page.  It is responsible for interacting
 *   with the html on the page providing events and any necessary dhtml.
 *
 * @param baseElement - Root html element for the guests section.
 * @param formUtils - Form utility object.
 * @param objectUtils - Object utility object.
 * @param documentUtils - Document utility object.
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView = function(baseElement, formUtils, objectUtils, documentUtils, eventUtils,
                                           numGuidesElement, confirmController, errorView, calendar, xmlUtils) {
    this._baseElement = baseElement;
    this._formUtils = formUtils;
    this._objectUtils = objectUtils;
    this._documentUtils = documentUtils;
    this._eventUtils = eventUtils;
    this._numGuidesElement = numGuidesElement;
    this._confirmController = confirmController;
    this._createAddGuideEvent(eventUtils);
    this._attachEventsToExistingGuides();
    this._errorView = errorView;
    this._calendar = calendar;
    this._xmlUtils = xmlUtils;
    this._attachCalendarEvent(calendar, eventUtils, xmlUtils);
    var reference = objectUtils.weakBind(this.updateTourTable, this);
    calendar.registerDateEventListener(reference);
}

/**
 * author: Nate Minshew
 * date created: 07/12/2006
 * access level: private
 * description:
 *   This method attaches the calendar event to the calendar icon.
 *
 * @param calendarElement - HTML element of the calendar.
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView.prototype._attachCalendarEvent = function(calendar, eventUtils, xmlUtils) {
    //    var calendarElement = cssQuery('#calendarContainer')[0];
    //    var calendarLinks = cssQuery('.calendarLink');
    //  for(var i = 0; i < calendarLinks.length; i++) {
    //    var calendarLink = calendarLinks[i];
    //    var event = new WST.View.Event.ToggleCalendarEvent(calendarElement, eventUtils, this._documentUtils);
    //    event.attachEvent(calendarLink, 'click');
    //  }
    var element = calendar.getCalendar();
    var guidesTable = cssQuery('#guideTable', this._baseElement)[0];
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    if (guidesTable != null){
    xmlUtils.insertAfter(brElement, guidesTable);
    xmlUtils.insertAfter(element, guidesTable);
    this._documentUtils.removeClass(brElement, 'mozclear');
    xmlUtils.insertAfter(brElement, element);
    }

//    var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
    //    if(calendarLink != null){
    //      var event = new WST.View.Event.ToggleCalendarEvent(element, eventUtils, this._documentUtils);
    //      event.attachEvent(calendarLink, 'click');
    //    }

}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: public
 * description:
 *   This method adds a guide depending on the current mode and updates the guides table.
 */
WST.View.RequestTour.GuidesView.prototype.addGuide = function() {
    var button = cssQuery('#addGuideButton', this._baseElement)[0];
    this._addGuide();
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method adds the entered guide to the request a tour form and the gudies table.
 */
WST.View.RequestTour.GuidesView.prototype._addGuide = function() {
    this._errorView.clearAllErrors();
    var idElement = cssQuery('#guideName-dhtml', this._baseElement)[0];

    var fieldset = document.getElementById('guidesPage');
    var index = this._getNumGuides();

    var guideId = idElement.options[idElement.selectedIndex].value;

    if (guideId != null && guideId != '') {
        if (!this._isGuideAlreadyAdded(guideId)) {
          this._createHiddenInput('guideId', guideId, fieldset, index);
          this._removeNoGuidesRow();
          this._addGuideToTable(this._formUtils.getSelectedText(idElement));
          //this._updateNumGuides();
          this._confirmController.addGuide(idElement.value);
          autosave(document.forms['tourForm']);
        } else {
            this._errorView.displayErrorMessage('Guide already added');
        }
    }
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: public
 * description:
 *   This method removes the guide at the specified index from the form and table.
 *
 * @param index - Index of guest.
 */
WST.View.RequestTour.GuidesView.prototype.deleteGuide = function(index) {
    this._errorView.clearAllErrors();
    var idHiddenElement = cssQuery('#guideId-' + index, this._baseElement)[0];
    idHiddenElement.parentNode.removeChild(idHiddenElement);
    this._removeGuideFromTable(index);
    //this._updateNumGuides();
    this._confirmController.deleteGuide(index);
    autosave(document.forms['tourForm']);
  
}

WST.View.RequestTour.GuidesView.prototype._isGuideAlreadyAdded = function(guideId) {
    var guideIds = cssQuery('.guideIds', this._baseElement);
    for (var i = 0; i < guideIds.length; i++) {
        var currentId = guideIds[i].value;
        if (currentId == guideId) {
            return true;
        }
    }
    return false;
}

/**
 * author: Nate Minshew
 * date created: 07/25/2006
 * access level: private
 * description:
 *   This method attaches the edit and delete events to any existing guides.
 */
WST.View.RequestTour.GuidesView.prototype._attachEventsToExistingGuides = function() {
    var deleteGuideLinks = cssQuery('.deleteGuideLink');
    for (var i = 0; i < deleteGuideLinks.length; i++) {
        this._attachDeleteEvent(deleteGuideLinks[i], i);
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates a hidden input field for one of the guide fields.
 *
 * @param name - Name of the input field.
 * @param value - Value of the input field.
 */
WST.View.RequestTour.GuidesView.prototype._createHiddenInput = function(name, value, parent, index) {
    var element = this._formUtils.createInputField(name);
    element.type = 'hidden';
    element.id = name + '-' + index;
    element.className = "guideIds";
    element.value = value;
    parent.appendChild(element);
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method adds a guest to the guide table.
 *
 * @param name - Text representing the guide name
 */
WST.View.RequestTour.GuidesView.prototype._addGuideToTable = function(name) {
    var tableBody = cssQuery('#guideTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    row.className = 'guideRow';
    row.id = 'guideRow-' + this._getNumGuides();
    row.appendChild(this._createGuideColumn(name));
    row.appendChild(this._createActionsColumn());
    tableBody.appendChild(row);
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method deletes the guide at the specified index from the guides table
 *
 * @param index - Index of guest.
 */
WST.View.RequestTour.GuidesView.prototype._removeGuideFromTable = function(index) {
    var row = cssQuery('#guideRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
    if (this._getNumGuides() == 0) {
        this._addNoGuidesRow();
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates the actions column with edit and delete links.
 */
WST.View.RequestTour.GuidesView.prototype._createActionsColumn = function() {
    var columnElement = this._createGuideColumn();
    columnElement.className = 'guideActions';
    var deleteLink = document.createElement('a');
    deleteLink.className = 'deleteGuideLink';
    deleteLink.href = '#';
    this._attachDeleteEvent(deleteLink, this._getNumGuides());
    deleteLink.appendChild(document.createTextNode('delete'));

    columnElement.appendChild(deleteLink);

    return columnElement;
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method attaches the delete guide event to the specified delete link.
 *
 * @param deleteLink - HTML link element.
 */
WST.View.RequestTour.GuidesView.prototype._attachDeleteEvent = function(deleteLink, index) {
    var event = new WST.View.RequestTour.Event.DeleteGuideEvent(this._eventUtils, this, index);
    event.attachEvent(deleteLink, 'click');
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This methood creates a guide column with the value specified.
 *
 * @param value - The text to be added to the column.
 */
WST.View.RequestTour.GuidesView.prototype._createGuideColumn = function(value) {
    var column = document.createElement('td');
    if (this._objectUtils.isDefined(value)) {
        column.appendChild(document.createTextNode(value));
    }
    return column;
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method removes the no guests row.
 */
WST.View.RequestTour.GuidesView.prototype._removeNoGuidesRow = function() {
    var noGuidesCol = cssQuery('#noGuides', this._baseElement)[0];
    if (this._objectUtils.isDefined(noGuidesCol)) {
        noGuidesRow = noGuidesCol.parentNode;
        noGuidesRow.parentNode.removeChild(noGuidesRow);
    }
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method adds the no guides column to the guides table.
 */
WST.View.RequestTour.GuidesView.prototype._addNoGuidesRow = function() {
    var tableBody = cssQuery('#guideTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    var noGuidesCol = document.createElement('td');
    noGuidesCol.id = 'noGuides';
    noGuidesCol.colSpan = 4;
    noGuidesCol.appendChild(document.createTextNode('No Guides Entered'));
    row.appendChild(noGuidesCol);
    tableBody.appendChild(row);
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates the add guest event for adding guests to the form and table.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView.prototype._createAddGuideEvent = function(eventUtils) {
    var addGuideButton = cssQuery('#addGuideButton', this._baseElement)[0];
    if (addGuideButton != null) {
        var event = new WST.View.RequestTour.Event.AddGuideEvent(eventUtils, this);
        event.attachEvent(addGuideButton, 'click');
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method updates the number guides info in the tab.
 */
WST.View.RequestTour.GuidesView.prototype._updateNumGuides = function() {
    var numGuides = this._getNumGuides();
    this._numGuidesElement.firstChild.nodeValue = '(' + numGuides + ')';
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method returns the number of guides that have been created.
 */
WST.View.RequestTour.GuidesView.prototype._getNumGuides = function() {
    return cssQuery('.guideRow', this._baseElement).length;
}

/**
 * author: Nate Minshew
 * date created: 07/12/2006
 * access level: private
 * description:
 *   This method updates the tour table in the guides tab based on the value of the date object specified.
 *
 * @param date - Date object representing the new date.
 */
WST.View.RequestTour.GuidesView.prototype.updateTourTable = function(date) {
    var tourDate = cssQuery('#tourTableUnderGuides', this._baseElement)[0];
    var tourController = new WST.Controller.RequestTour.TourControllerUnderGuides();
    var currentDate = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    tourController._getTourList(currentDate);
//    tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
//    var calendarElement = cssQuery('.calendar', this._baseElement)[0];
  //  var calendarElement = cssQuery('#calendar', this._baseElement)[0];
//    this._documentUtils.addClass(calendarElement, 'hide');
//    this._confirmController.setConfirmValue(tourDate);
}