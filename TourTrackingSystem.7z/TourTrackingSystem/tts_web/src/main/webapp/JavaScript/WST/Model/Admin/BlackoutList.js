// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Model.Admin.Blackout");
JSAN.use('WST.View.Admin.BlackoutDateView');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object represents a list of blackout dates.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList = function(blackoutListXML) {
    this._blackouts = new Array();
    this._parseList(blackoutListXML);
    this._blackoutDateView = new WST.View.Admin.BlackoutDateView();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of Blackout objects.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackouts = function() {
    return this._blackouts;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackoutDates = function() {
    var dates = new Array();
    for (var i = 0; i < this._blackouts.length; i++) {
        dates.push(new Date(this._blackouts[i].getDate()));
    }
    return dates;
}

WST.Model.Admin.BlackoutList.prototype.processDateElement = function(date, dateElement) {
    this._blackoutDateView.updateDateElement(dateElement, this._isBlackedOut(date));
}

WST.Model.Admin.BlackoutList.prototype._isBlackedOut = function(date) {
    var blackoutDates = this.getBlackoutDates();
    for (var i = 0; i < blackoutDates.length; i++) {
        if (blackoutDates[i].getYear() == date.getYear()
                && blackoutDates[i].getMonth() == date.getMonth()
                && blackoutDates[i].getDate() == date.getDate()) {
            return true;
        }
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method parses the xml document of blackout dates into Blackout objects.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype._parseList = function(blackoutListXML) {
    var blackoutElements = blackoutListXML.getElementsByTagName('blackout');
    for (var i = 0; i < blackoutElements.length; i++) {
        var date = blackoutElements[i].getAttribute('date');
        var reason = null; //blackoutElements[i].getAttribute('reason');
        this._blackouts.push(new WST.Model.Admin.Blackout(date, reason));
    }
}
