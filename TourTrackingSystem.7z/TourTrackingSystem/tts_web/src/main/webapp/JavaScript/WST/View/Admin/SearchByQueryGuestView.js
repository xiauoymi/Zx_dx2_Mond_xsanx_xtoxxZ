// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ToggleLocationTypeEvent');

Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * @constructor
 * description:
 *   This object is a view object for the Search By Query date page.  It sents any events on the page and interacts with the
 *   HTML.
 */
WST.View.Admin.SearchByQueryGuestView = function(baseElement, eventUtils, formUtils, documentUtils) {
  this._baseElement = baseElement;
  this._formUtils = formUtils;
  this._documentUtils = documentUtils;
  this._createLocationEvent(eventUtils);
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates the location event for displaying the states and countries drop downs.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.Admin.SearchByQueryGuestView.prototype._createLocationEvent = function(eventUtils) {
  var locationElement = cssQuery('#guestLocation-dhtml', this._baseElement)[0];
  var event = new WST.View.RequestTour.Event.ToggleLocationTypeEvent(eventUtils, this, locationElement, this._formUtils);
  event.attachEvent(locationElement, 'change');

  //To show/hide states and countries when comes back with results
  if (this._formUtils.getSelectedValue(locationElement) == 'Domestic') {
    this.displayStates();
  } else if (this._formUtils.getSelectedValue(locationElement) == 'International') {
    this.displayCountries();
  } else {
    this.hideStatesAndCountries();
  }

}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: public
 * description:
 *   This method displays the states drop down in the guests section.
 */
WST.View.Admin.SearchByQueryGuestView.prototype.displayStates = function() {
  var stateElementParent = cssQuery('#guestState-dhtml', this._baseElement)[0].parentNode;
  var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0];
  countryElement.selectedIndex = 0;
  var countryElementParent = countryElement.parentNode;
  this._documentUtils.addClass(countryElementParent, 'hide');
  this._documentUtils.removeClass(stateElementParent, 'hide');
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: public
 * description:
 *   This method displays the countries drop down in the guests section.
 */
WST.View.Admin.SearchByQueryGuestView.prototype.displayCountries = function() {
  var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0];
  stateElement.selectedIndex = 0;
  var stateElementParent = stateElement.parentNode;
  var countryElementParent = cssQuery('#guestCountry-dhtml', this._baseElement)[0].parentNode;
  this._documentUtils.addClass(stateElementParent, 'hide');
  this._documentUtils.removeClass(countryElementParent, 'hide');
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: public
 * description:
 *   This method hides both the states drop down and the countries drop down.
 */
WST.View.Admin.SearchByQueryGuestView.prototype.hideStatesAndCountries = function() {
  var stateElement = cssQuery('#guestState-dhtml', this._baseElement)[0].parentNode;
  var countryElement = cssQuery('#guestCountry-dhtml', this._baseElement)[0].parentNode;
  this._documentUtils.addClass(stateElement, 'hide');
  this._documentUtils.addClass(countryElement, 'hide');
}
