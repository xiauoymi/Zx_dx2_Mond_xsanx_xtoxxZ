// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
* author: Nate Minshew
* date created: 07/31/2006
* @constructor
* description:
*   This object is an event object for redirecting with guide information to display .
*
* @param eventUtils - Event utility object.
* @param guestsView - Object representing the guests view.
*/
WST.View.Guide.Event.ViewOutOfOfficeEvent = function(eventUtils, formUtils, guideElement) {
    this._eventUtils = eventUtils;
    this._formUtils = formUtils;
    this._guideElement = guideElement;
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.Guide.Event.ViewOutOfOfficeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/31/2006
* access level: public
* description:
*   This method executes the event for this object, redirecting to the out of office page with guide information.
*
* @param evt - Event object provided by the browser.
*/
WST.View.Guide.Event.ViewOutOfOfficeEvent.prototype.executeEvent = function(evt) {
    var guideId = this._formUtils.getSelectedValue(this._guideElement);
    location.href = 'outofoffice.htm?guide=' + guideId;
}