// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for editing guests to the request a tour page.
*
* @param eventUtils - Event utility object.
* @param guestsView - Object representing the guests view.
*/
WST.View.RequestTour.Event.LoadGuestEvent = function(eventUtils, guestsView, index) {
    this._eventUtils = eventUtils;
    this._guestsView = guestsView;
    this._index = index;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.LoadGuestEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event for this object, editing the entered guest.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.LoadGuestEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._guestsView.loadGuest(this._index);
}
