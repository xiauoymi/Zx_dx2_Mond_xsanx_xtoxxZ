// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event");

WST.Event.CancelEvent = function() {
}

WST.Event.CancelEvent.prototype.attachEvent = function(element, type) {
    Lib.Utils.EventUtils.addEvent(element, type, this.executeEvent, this);
}

WST.Event.CancelEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
}