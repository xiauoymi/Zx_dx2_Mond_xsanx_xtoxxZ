// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ToggleMeetingOptionsEvent');
JSAN.use('WST.View.RequestTour.Event.ToggleCreditCardEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the additional services section of the request a tour page.  It is responsible
*   for interacting with the html in the additional services section.  It is also responsible for creating any
*   necessary events.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    this._attachMeetingEvents(baseElement, eventUtils, documentUtils, disableCssClass);
    this._attachCreditCardEvents(baseElement, eventUtils, documentUtils, disableCssClass);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the events related to the meeting sections.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView.prototype._attachMeetingEvents = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    var meetings = cssQuery('.meeting', baseElement);
    for (var i = 0; i < meetings.length; i++) {
        var event = new WST.View.RequestTour.Event.ToggleMeetingOptionsEvent(meetings[i], eventUtils, disableCssClass, documentUtils, baseElement);
        event.attachEvent(meetings[i], 'click');
        if (meetings[i].id == 'meetingBeforeTrue' && meetings[i].checked) {
            event.executeEvent();
        }
        if (meetings[i].id == 'meetingAfterTrue' && meetings[i].checked) {
            event.executeEvent();
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the events related to the credit card section.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView.prototype._attachCreditCardEvents = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    var refreshments = cssQuery('.refreshment', baseElement);
    var creditCardInfo = cssQuery('#creditCardInfo', baseElement)[0];
    var event = new WST.View.RequestTour.Event.ToggleCreditCardEvent(refreshments, creditCardInfo, disableCssClass, eventUtils, documentUtils);
    for (var i = 0; i < refreshments.length; i++) {
        event.attachEvent(refreshments[i], 'change');
        if (refreshments[i].selectedIndex > 0) {
            event.executeEvent();
        }
    }
}
