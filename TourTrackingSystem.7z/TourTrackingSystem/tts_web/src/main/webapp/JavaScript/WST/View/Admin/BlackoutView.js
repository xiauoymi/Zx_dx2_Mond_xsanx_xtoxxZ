// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

/**
* author: Nate Minshew
* date created: 07/26/2006
* @constructor
* description:
*   This object is a view object for the Blackout date page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Admin.BlackoutView = function(calendar, baseElement, xmlUtils, documentUtils, eventUtils, objectUtils, logger) {
//    logger.debug("BlackoutView - Enter Create BlackoutView");
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._attachCalendar(calendar, xmlUtils, eventUtils, logger);
    var reference = objectUtils.weakBind(this.updateDate, this);
    calendar.registerDateEventListener(reference);
//    logger.debug("BlackoutView - Exit Create BlackoutView");
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method attaches the calendar html element to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param xmlUtils - XML utility object.
* @param eventUtils - Event utility object.
*/
WST.View.Admin.BlackoutView.prototype._attachCalendar = function(calendar, xmlUtils, eventUtils, logger) {
//    logger.debug("BlackoutView - Enter _attachCalendar");
    var element = calendar.getCalendar();
    this._documentUtils.addClass(element, 'hide');
    var blackoutDateLabel = cssQuery('#blackoutDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    //brElement.className = 'mozclear';
    xmlUtils.insertAfter(brElement, blackoutDateLabel);
    xmlUtils.insertAfter(element, blackoutDateLabel);
 // this._documentUtils.removeClass(brElement, 'mozclear');
  xmlUtils.insertAfter(brElement, element);
    //xmlUtils.insertAfter(brElement, element);
    this._attachCalendarEvent(element, eventUtils);
//    logger.debug("BlackoutView - Attached Calendar Event");
//    logger.debug("BlackoutView - Exit _attachCalendar");
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method attaches the calendar event to the calendar icon.
*
* @param calendarElement - HTML element of the calendar.
* @param eventUtils - Event utility object.
*/
WST.View.Admin.BlackoutView.prototype._attachCalendarEvent = function(calendarElement, eventUtils) {
    var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
    var event = new WST.View.Event.ToggleCalendarEvent(calendarElement, eventUtils, this._documentUtils);
    event.attachEvent(calendarLink, 'click');
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method updates the date in the blackout date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Admin.BlackoutView.prototype.updateDate = function(date) {
    var blackoutDate = cssQuery('#blackoutDate', this._baseElement)[0];
    blackoutDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    var calendarElement = cssQuery('.calendar', this._baseElement)[0];
    this._documentUtils.addClass(calendarElement, 'hide');
}
