// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Guide");

WST.Model.Guide.Tour = function(tourDate, startTime,  orgName, guests, place, guides, location) {
    this._tourDate = tourDate;
    this._startTime = startTime;
    this._orgName = orgName;
    this._guests = guests;
    this._place = place;
    this._guides = guides;
    this._location = location;
}

WST.Model.Guide.Tour.prototype.getTourDate = function() {
    return this._tourDate;
}

WST.Model.Guide.Tour.prototype.getStartTime = function() {
    return this._startTime;
}

WST.Model.Guide.Tour.prototype.getOrgName = function() {
    return this._orgName;
}

WST.Model.Guide.Tour.prototype.getGuests = function() {
    return this._guests;
}

WST.Model.Guide.Tour.prototype.getPlace = function() {
    return this._place;
}

WST.Model.Guide.Tour.prototype.getGuides = function() {
    return this._guides;
}

WST.Model.Guide.Tour.prototype.getLocation = function() {
    return this._location;
}