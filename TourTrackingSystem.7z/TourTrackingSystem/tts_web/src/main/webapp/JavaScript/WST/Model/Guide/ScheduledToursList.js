// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Model.Guide.Tour");
JSAN.use('Lib.DHTML.Model.DateStyleConfiguration');
JSAN.use('WST.View.Guide.ScheduledDateView');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Guide");

/**
* author: Sonal Patidar
* date created: 08/28/2006
* @constructor
* description:
*   This object represents a list of scheduled tours.
*
* @param scheduledToursListXML - XML document representing the scheduled tours.
*/
WST.Model.Guide.ScheduledToursList = function(scheduledToursListXML) {
    this._scheduledTours = new Array();
    this._parseList(scheduledToursListXML);
    this._scheduledDateView = new WST.View.Guide.ScheduledDateView();
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: public
* description:
*   This method returns an array of scheduled tours
*/
WST.Model.Guide.ScheduledToursList.prototype.getScheduledTours = function() {
    return this._scheduledTours;
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: public
* description:
*   This method returns an array of scheduled tours
*/
WST.Model.Guide.ScheduledToursList.prototype.getScheduledToursDates = function() {
    var dates = new Array();
    for (var i = 0; i < this._scheduledTours.length; i++) {
        dates.push(new Date(this._scheduledTours[i].getTourDate()));
    }
    return dates;
}

WST.Model.Guide.ScheduledToursList.prototype.processDateElement = function(date, dateElement) {
    if (this._isScheduled(date)) {
        this._scheduledDateView.updateDateElement(dateElement);
    }
}

WST.Model.Guide.ScheduledToursList.prototype._isScheduled = function(date) {
    var scheduledDates = this.getScheduledToursDates();
    for (var i = 0; i < scheduledDates.length; i++) {
        if (scheduledDates[i].getYear() == date.getYear()
                && scheduledDates[i].getMonth() == date.getMonth()
                && scheduledDates[i].getDate() == date.getDate()) {
            return true;
        }
    }
    return false;
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method parses the xml document of tour dates into tours objects.
*
* @param scheduledToursListXML - XML document representing the scheduled tours
*/
WST.Model.Guide.ScheduledToursList.prototype._parseList = function(scheduledToursListXML) {
    var tourElements = scheduledToursListXML.getElementsByTagName('tour');
    for (var i = 0; i < tourElements.length; i++) {
        var date = tourElements[i].getAttribute('tourDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var orgName = tourElements[i].getAttribute('orgName');
        var guests = tourElements[i].getAttribute('guests');
        var guides = tourElements[i].getAttribute('guides');
        var location = tourElements[i].getAttribute('location');
       this._scheduledTours.push(new WST.Model.Guide.Tour(date, startTime, orgName,guests,guides,location));
    }
}
