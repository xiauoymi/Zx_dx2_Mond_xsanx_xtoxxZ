// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for change to the skip tab on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param tabNavigator - Object used for switching and maintaining tabs.
*/
WST.View.RequestTour.Event.SkipTabEvent = function(eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches this event to the specified element using the specified type.
*
* @param element - Page element to attach event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.SkipTabEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes this event.  It uses the tab navigator to switch to the confirm tab.
*
* @param evt - System event object.
*/
WST.View.RequestTour.Event.SkipTabEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.skipTab();
}