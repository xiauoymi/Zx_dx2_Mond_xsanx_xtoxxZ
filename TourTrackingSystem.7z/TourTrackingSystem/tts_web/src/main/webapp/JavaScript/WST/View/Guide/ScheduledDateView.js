// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide");

WST.View.Guide.ScheduledDateView = function() {
}

WST.View.Guide.ScheduledDateView.prototype.updateDateElement = function(dateElement) {
    Lib.Utils.DocumentUtils.addClass(dateElement, 'scheduledTourDate');
}