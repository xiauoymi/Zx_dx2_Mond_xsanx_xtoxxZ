// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
* author: Uma K
* date created: 12/12/2006
* @constructor
* description:
* This object is an event object for changing the End  Date for Out Of Office when the Start Date is changed.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.Event.EndDateChangeEvent = function(eventUtils, baseElement, formUtils) {
    this._eventUtils = eventUtils;
    this._baseElement = baseElement;
    this._formUtils = formUtils;
}

/**
* author: Uma K
* date created: 12/12/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.Guide.Event.EndDateChangeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Uma.K
* date created: 12/12/2006
* access level: public
* description:
*   This method executes the event for this object, re-setting the end date based on start date selected
*
* @param evt - Event object provided by the browser.
*/
WST.View.Guide.Event.EndDateChangeEvent.prototype.executeEvent = function(evt) {
  var startDateField = cssQuery('#startDate', this._baseElement)[0];
  var endDateField = cssQuery('#endDate', this._baseElement)[0];
  if ( endDateField.value < startDateField.value){
      endDateField.value = startDateField.value;
  }
  var guideElement = cssQuery('#guide', this._baseElement)[0];
  var guideId = this._formUtils.getSelectedValue(guideElement);
  location.href = 'outofoffice.htm?guide=' + guideId + '&startDate=' + startDateField.value + '&endDate=' + endDateField.value
         + '&timeChange=true';

}