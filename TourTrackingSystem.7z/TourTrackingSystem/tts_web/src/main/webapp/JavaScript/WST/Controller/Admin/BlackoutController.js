// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.Admin.BlackoutList');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Admin");

/**
* author: Nate Minshew
* date created: 07/25/2006
* @constructor
* description:
*   This object is a controller for blackout dates.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param blackoutListUrl - Url of the blackout list service.
*/
WST.Controller.Admin.BlackoutController = function(ajaxUtils, blackoutListUrl, selectedDate) {
    this._selectedDate = selectedDate;
    this._ajaxUtils = ajaxUtils;
    this._blackoutListUrl = blackoutListUrl;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method retrieves a list of blackout dates from the server.
*/
WST.Controller.Admin.BlackoutController.prototype.getBlackoutList = function() {
    if (Lib.Utils.ObjectUtils.isDefined(this._selectedDate)
       && Lib.Utils.ObjectUtils.isDefined(this._blackoutListUrl)){
       this._blackoutListUrl = this._blackoutListUrl + '&selectedDate=' + this._selectedDate;
    }
    var xml = this._ajaxUtils.requestSynchronousFeed(this._blackoutListUrl);
    return new WST.Model.Admin.BlackoutList(xml);
}

WST.Controller.Admin.BlackoutController.prototype.updateCalendar = function(calendar) {
    var blackoutList = this.getBlackoutList();
    var reference = Lib.Utils.ObjectUtils.weakBind(blackoutList.processDateElement, blackoutList);
    calendar.registerDateInitListener(reference);
    for (var i = 0; i < blackoutList.getBlackoutDates().length; i++) {
        calendar.disableDate(blackoutList.getBlackoutDates()[i]);
    }
}