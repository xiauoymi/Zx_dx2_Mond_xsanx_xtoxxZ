// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Guide = function(id, name) {
    this._id = id;
    this._name = name;
}

WST.TourCalendar.Model.Guide.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Guide.prototype.getName = function() {
    return this._name;
}