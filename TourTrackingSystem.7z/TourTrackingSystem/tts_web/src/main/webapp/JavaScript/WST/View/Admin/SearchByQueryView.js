// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
JSAN.use('WST.View.Request.Event.ToggleLocationTypeEvent');

Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

/**
* author: Sonal Pstidar
* date created: 4/27/2007
* @constructor
* description:
*   This object is a view object for the Search By Query date page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Admin.SearchByQueryView = function(startCalendar, endCalendar, baseElement, xmlUtils, documentUtils, eventUtils, objectUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._attachCalendars(startCalendar, endCalendar, xmlUtils, eventUtils);
    var reference = objectUtils.weakBind(this.updateStartDate, this);
    startCalendar.registerDateEventListener(reference);
    reference = objectUtils.weakBind(this.updateEndDate, this);
    endCalendar.registerDateEventListener(reference);
}

/**
* author: Sonal Pstidar
* date created: 4/27/2007
* access level: private
* description:
*   This method attaches the calendar html element to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param xmlUtils - XML utility object.
* @param eventUtils - Event utility object.
*/
WST.View.Admin.SearchByQueryView.prototype._attachCalendars = function(startCalendar, endCalendar, xmlUtils, eventUtils) {
    var startCalendarElement = startCalendar.getCalendar();
    this._documentUtils.addClass(startCalendarElement, 'hide');
    var tourStartDateLabel = cssQuery('#tourStartDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    xmlUtils.insertAfter(brElement, tourStartDateLabel);
    xmlUtils.insertAfter(startCalendarElement, tourStartDateLabel);
    xmlUtils.insertAfter(brElement, startCalendarElement);

    var endCalendarElement = endCalendar.getCalendar();
    this._documentUtils.addClass(endCalendarElement, 'hide');
    var tourEndDateLabel = cssQuery('#tourEndDate', this._baseElement)[0].parentNode;
    xmlUtils.insertAfter(brElement, tourEndDateLabel);
    xmlUtils.insertAfter(endCalendarElement, tourEndDateLabel);
    xmlUtils.insertAfter(brElement, endCalendarElement);
    this._attachCalendarEvent(startCalendarElement, endCalendarElement, eventUtils);
}


/**
        * author: Sonal Pstidar
        * date created: 4/27/2007
        * access level: private
        * description:
        *   This method attaches the calendar event to the calendar icon.
        *
        * @param calendarElement - HTML element of the calendar.
        * @param eventUtils - Event utility object.
        */
WST.View.Admin.SearchByQueryView.prototype._attachCalendarEvent = function(startCalendarElement, endCalendarElement, eventUtils) {
    var calendarLink = cssQuery('#startDateCalendarLink', this._baseElement)[0];
    var event = new WST.View.Event.ToggleCalendarEvent(startCalendarElement, eventUtils, this._documentUtils);
    event.attachEvent(calendarLink, 'click');

    calendarLink = cssQuery('#endDateCalendarLink', this._baseElement)[0];
    event = new WST.View.Event.ToggleCalendarEvent(endCalendarElement, eventUtils, this._documentUtils);
    event.attachEvent(calendarLink, 'click');
}

/**
        * author: Sonal Pstidar
* date created: 4/27/2007
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Admin.SearchByQueryView.prototype.updateStartDate = function(date) {
    var tourDate = cssQuery('#tourStartDate', this._baseElement)[0];
    tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    var calendarElement = cssQuery('#startDateCalendar', this._baseElement)[0];
    this._documentUtils.addClass(calendarElement, 'hide');
}

/**
* author: Sonal Pstidar
* date created: 4/27/2007
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Admin.SearchByQueryView.prototype.updateEndDate = function(date) {
    var tourDate = cssQuery('#tourEndDate', this._baseElement)[0];
    tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    var calendarElement = cssQuery('#endDateCalendar', this._baseElement)[0];
    this._documentUtils.addClass(calendarElement, 'hide');
}
