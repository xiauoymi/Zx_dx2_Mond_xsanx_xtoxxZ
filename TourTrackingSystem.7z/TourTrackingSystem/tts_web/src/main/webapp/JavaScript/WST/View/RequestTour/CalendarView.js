// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('WST.Event.WindowCloseEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

WST.View.RequestTour.CalendarView = function(calendar, baseElement, eventUtils, documentUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._attachCalendar(calendar, eventUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method attaches the calendar html element to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param xmlUtils - XML utility object.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.CalendarView.prototype._attachCalendar = function(calendar, eventUtils) {
//  var element = calendar.getCalendar();
//  var calendarBackground = cssQuery('.calendarBackground', this._baseElement)[0];
//  Lib.Utils.DocumentUtils.addClass(this._baseElement, 'hide');
//  calendarBackground.appendChild(element);
//  this._attachWindowCloseEvent();

  var element = calendar.getCalendar();
  var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
  var event = new WST.View.Event.ToggleCalendarEvent(element, eventUtils, this._documentUtils);
  event.attachEvent(calendarLink, 'click');

}
//
//WST.View.RequestTour.CalendarView.prototype._attachWindowCloseEvent = function() {
//    var closeLink = cssQuery('.xClose', this._baseElement)[0];
//    var event = new WST.Event.WindowCloseEvent(this._baseElement);
//    event.attachEvent(closeLink, 'click');
//}
