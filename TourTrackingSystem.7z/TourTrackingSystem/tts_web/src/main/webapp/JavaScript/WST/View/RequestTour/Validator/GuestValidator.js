// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Validator");

/**
* author: Nate Minshew
* date created: 07/14/2006
* @constructor
* description:
*   This object is a validator for the guests section of the request a tour.  It is used to validate added guests.
*
* @param validatorUtils - Validator utility object.
* @param formUtils - Form utility object.
* @param errorView - View object for displaying error messages.
*/
WST.View.RequestTour.Validator.GuestValidator = function(validatorUtils, formUtils, errorView) {
    this._validatorUtils = validatorUtils;
    this._formUtils = formUtils;
    this._errorView = errorView;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: public
* description:
*   This method validates the specified fields for errors.
*
* @param firstNameField - HTML element representing the guest first name field.
* @param lastNameField - HTML element representing the guest last name field.
* @param locationField - HTML element representing the guest location.
* @param stateField - HTML element representing the guest state.
* @param countryField - HTML element representing the guest country.
* @param classificationField - HTML element representing the guest classification.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype.validate = function(firstNameField, lastNameField,
        locationField, stateField, countryField, classificationField) {
    var isValid = true;
    if (!this._validateFirstName(firstNameField)) {
        isValid = false;
    }
    if (!this._validateLastName(lastNameField)) {
        isValid = false;
    }
    if (!this._validateLocation(locationField)) {
        isValid = false;
    }
    if (!this._validateState(stateField, locationField)) {
        isValid = false;
    }
    if (!this._validateCountry(countryField, locationField)) {
        isValid = false;
    }
    if (!this._validateClassification(classificationField)) {
        isValid = false;
    }
    return isValid;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the first name field for errors.
*
* @param firstNameField - HTML element containing the guest first name.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateFirstName = function(firstNameField) {
    if (!this._validatorUtils.validateRequired(firstNameField.value)) {
        this._errorView.displayErrorMessage('The first name field is required.', firstNameField);
        return false;
    }
    return true;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the last name field for errors.
*
* @param lastNameField - HTML element containing the guest last name.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateLastName = function(lastNameField) {
    if (!this._validatorUtils.validateRequired(lastNameField.value)) {
        this._errorView.displayErrorMessage('The last name field is required.', lastNameField);
        return false;
    }
    return true;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the location field for errors.
*
* @param locationField - HTML element containing the guest location.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateLocation = function(locationField) {
    if (!this._validatorUtils.validateRequired(this._formUtils.getSelectedValue(locationField))) {
        this._errorView.displayErrorMessage('The domestic/international field is required.', locationField);
        return false;
    }
    return true;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the state field for errors.
*
* @param stateField - HTML element containing the guest state.
* @param locationField - HTML element containing the guest location.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateState = function(stateField, locationField) {
    if (this._formUtils.getSelectedValue(locationField) == 'Domestic'
            && !this._validatorUtils.validateRequired(this._formUtils.getSelectedValue(stateField))) {
        this._errorView.displayErrorMessage('The state field is required if domestic is selected.', stateField);
        return false;
    }
    return true;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the country field for errors.
*
* @param countryField - HTML element containing the guest country.
* @param locationField - HTML element containing the guest location.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateCountry = function(countryField, locationField) {
    if (this._formUtils.getSelectedValue(locationField) == 'International'
            && !this._validatorUtils.validateRequired(this._formUtils.getSelectedValue(countryField))) {
        this._errorView.displayErrorMessage('The country field is required if international is selected.', countryField);
        return false;
    }
    return true;
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method validates the classification field for errors.
*
* @param classificationField - HTML element containing the guest classification.
*/
WST.View.RequestTour.Validator.GuestValidator.prototype._validateClassification = function(classificationField) {
    if (!this._validatorUtils.validateRequired(this._formUtils.getSelectedValue(classificationField))) {
        this._errorView.displayErrorMessage('The visitor classification field is required.', classificationField);
        return false;
    }
    return true;
}