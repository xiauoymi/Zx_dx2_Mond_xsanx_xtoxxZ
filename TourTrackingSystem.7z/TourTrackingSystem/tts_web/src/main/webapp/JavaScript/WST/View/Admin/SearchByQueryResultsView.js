// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

/**
* author: Sonal Patidar
* date created: 04/30/2007
* @constructor
* description:
*   This object is a view object for the searchByQueryResults page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Admin.SearchByQueryResultsView = function(baseElement, documentUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
}

