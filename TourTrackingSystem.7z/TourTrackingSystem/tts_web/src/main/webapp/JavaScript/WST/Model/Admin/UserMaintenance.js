// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

WST.Model.Admin.UserMaintenance = function(name, role) {
    this._name = name;
    this._role = role;
}

WST.Model.Admin.UserMaintenance.prototype.getName = function() {
    return this._name;
}

WST.Model.Admin.UserMaintenance.prototype.getRole = function() {
    return this._role;
}