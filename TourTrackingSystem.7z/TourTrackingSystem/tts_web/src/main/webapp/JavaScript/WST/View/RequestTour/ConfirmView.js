// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ConfirmEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view for the confirmation section of the request a tour page.  It handles updating the html on the
*   confirmation page and attaching events.
*
* @param objectUtils - Object utility object.
* @param eventUtil - Event utility object
* @param xmlUtils - XML utility object.
* @param formUtils - Form utility object.
* @param confirmController - Controller object for the confirm section.
*/
WST.View.RequestTour.ConfirmView = function(objectUtils, eventUtils, xmlUtils, formUtils, confirmController, baseElement) {
    this._baseElement = baseElement;
    this._objectUtils = objectUtils;
    this._xmlUtils = xmlUtils;
    this._formUtils = formUtils;
    var inputElements = this._getInputElements();
    var reference = objectUtils.weakBind(this.setConfirmValue, this);
    confirmController.registerConfirmValueListener(reference);
    reference = objectUtils.weakBind(this.addGuide, this);
    confirmController.registerAddGuideListener(reference);
    reference = objectUtils.weakBind(this.deleteGuide, this);
    confirmController.registerDeleteGuideListener(reference);
  
    //reference = objectUtils.weakBind(this.addGuest, this);
    //confirmController.registerAddGuestListener(reference);
    //reference = objectUtils.weakBind(this.editGuest, this);
    //confirmController.registerEditGuestListener(reference);
    //reference = objectUtils.weakBind(this.deleteGuest, this);
    //confirmController.registerDeleteGuestListener(reference);
    for (var i = 0; i < inputElements.length; i++) {
        var event = new WST.View.RequestTour.Event.ConfirmEvent(eventUtils, inputElements[i], this);
        event.attachEvent(inputElements[i], 'change');
        this.setConfirmValue(inputElements[i]);
    }
  var disabledElements = cssQuery('.disabled');
    for (var i = 0; i < disabledElements.length; i++) {
      disabledElements[i].disabled = true;
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the entered/selected value of the specified input element in it's corresponding location on the
*   confirmation page.
*
* @param inputElement - HTML input element.
*/
WST.View.RequestTour.ConfirmView.prototype.setConfirmValue = function(inputElement) {

    var confirmElement = cssQuery('#' + inputElement.id + "-value")[0];
    if (inputElement.nodeName == 'INPUT') {
        if (inputElement.type == 'radio' && inputElement.checked) {
            confirmElement = cssQuery('#' + inputElement.name + '-value')[0];
            if (inputElement.value == 'true') {
                this._setValue(confirmElement, 'Yes');
            } else {
                this._setValue(confirmElement, 'No');
            }
        } else if (inputElement.type != 'radio') {
            var value = inputElement.value;
            if(inputElement.id == 'creditCardNumber'){
                value = this._maskCreditCardNumber(value);
            }
            this._setValue(confirmElement, value);
        }
    } else if (inputElement.nodeName == 'SELECT') {
        if (this._formUtils.getSelectedValue(inputElement) != '') {
            var value = this._formUtils.getSelectedText(inputElement);
            this._setValue(confirmElement, value);
        } else {
            this._setValue(confirmElement, '');
        }
    }
     else if (inputElement.nodeName == 'TEXTAREA') {
         this._setValue(confirmElement, inputElement.value);
    } else {
        throw new Error("The html element '" + inputElement.nodeName + "' is not supported");
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method adds the specified guest to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.addGuest = function(name, classification, location) {
    this._removeNoConfirmGuestsRow();
    this._addGuestRow(name, classification, location);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method adds the specified guide to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.addGuide = function(guideName) {
    this._removeNoConfirmGuidesRow();
    this._addGuideRow(guideName);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method updates the specified guest in the confirm section.
*
* @param index - Index of Guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.editGuest = function(index, name, classification, location) {
    this._editGuestRow(index, name, classification, location);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method deletes the specified guest in the confirm section.
*
* @param index - Index of Guest.
*/
WST.View.RequestTour.ConfirmView.prototype.deleteGuest = function(index) {
    this._deleteGuestRow(index);
    if (this._getNumGuests() == 0) {
        this._addNoConfirmGuestsRow();
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method deletes the specified guide in the confirm section.
*
* @param index - Index of Guest.
*/
WST.View.RequestTour.ConfirmView.prototype.deleteGuide = function(index) {
    this._deleteGuideRow(index);
    if (this._getNumGuides() == 0) {
        this._addNoConfirmGuidesRow();
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method removes the no confirm guests row from the guest table.
*/
WST.View.RequestTour.ConfirmView.prototype._removeNoConfirmGuestsRow = function() {
    var row = cssQuery('#noConfirmGuests', this._baseElement)[0];
    if (this._objectUtils.isDefined(row)) {
        row.parentNode.removeChild(row);
    }
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method removes the no confirm guests row from the guide table.
*/
WST.View.RequestTour.ConfirmView.prototype._removeNoConfirmGuidesRow = function() {
    var row = cssQuery('#noConfirmGuides', this._baseElement)[0];
    if (this._objectUtils.isDefined(row)) {
        row.parentNode.removeChild(row);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds the no confirm guests row to the guests table.
*/
WST.View.RequestTour.ConfirmView.prototype._addNoConfirmGuestsRow = function() {
    var guestsTable = cssQuery('#confirmGuestsTable', this._baseElement)[0];
    var tbodyElement = guestsTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.id = 'noConfirmGuests';
    var column = document.createElement('td');
    column.colspan = 4;
    column.appendChild(document.createTextNode('No Guests Entered'));
    row.appendChild(column);
    tbodyElement.appendChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds the no confirm gudies row to the guests table.
*/
WST.View.RequestTour.ConfirmView.prototype._addNoConfirmGuidesRow = function() {
    var guidesTable = cssQuery('#confirmGuidesTable', this._baseElement)[0];
    var tbodyElement = guidesTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.id = 'noConfirmGuides';
    var column = document.createElement('td');
    column.colspan = 2;
    column.appendChild(document.createTextNode('No Gudies Entered'));
    row.appendChild(column);
    tbodyElement.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds a guest row to the guest table.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype._addGuestRow = function(name, classification, location) {
    var guestTable = cssQuery('#confirmGuestsTable', this._baseElement)[0];
    var tbodyElement = guestTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.className = 'guestRow';
    row.id = 'guestRow-' + this._getNumGuests();
    row.appendChild(this._createGuestHeader());
    row.appendChild(this._createGuestColumn(name));
    row.appendChild(this._createGuestColumn(classification));
    var lastCol = this._createGuestColumn(location);
    lastCol.className = 'lastGuestColumn';
    row.appendChild(lastCol);
    tbodyElement.appendChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds a guest row to the gudie table.
*
* @param name - Guides's name.
*/
WST.View.RequestTour.ConfirmView.prototype._addGuideRow = function(guideName) {
    var guideTable = cssQuery('#confirmGuidesTable', this._baseElement)[0];
    var tbodyElement = guideTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.className = 'guideRow';
    row.id = 'guideRow-' + this._getNumGuides();
    row.appendChild(this._createGuideHeader());
    var lastCol = this._createGuideColumn(guideName);
    lastCol.className = 'lastGuideColumn';
    row.appendChild(lastCol);
    tbodyElement.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method edits the guest at the specified index.
*
* @param index - Index of Guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype._editGuestRow = function(index, name, classification, location) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    var tdElements = row.getElementsByTagName('td');
    tdElements[0].innerHTML = name;
    tdElements[1].innerHTML = classification;
    tdElements[2].innerHTML = location;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method deletes the guest row at the specified index.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.ConfirmView.prototype._deleteGuestRow = function(index) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method deletes the guide row at the specified index.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.ConfirmView.prototype._deleteGuideRow = function(index) {
    var row = cssQuery('#guideRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the guest header.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuestHeader = function() {
    var thElement = document.createElement('th');
    thElement.appendChild(document.createTextNode('Guest ' + (this._getNumGuests() + 1) + ':'));
    return thElement;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the guide header.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuideHeader = function() {
    var thElement = document.createElement('th');
    thElement.appendChild(document.createTextNode('Guide ' + (this._getNumGuides() + 1) + ':'));
    return thElement;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates a guest column with the specified value.
*
* @param value - Representing the text of the column.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuestColumn = function(value) {
    var tdElement = document.createElement('td');
    tdElement.appendChild(document.createTextNode(value));
    return tdElement;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates a guest column with the specified value.
*
* @param value - Representing the text of the column.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuideColumn = function(value) {
    var tdElement = document.createElement('td');
    tdElement.appendChild(document.createTextNode(value));
    return tdElement;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method returns the number of guests in the confirm guest section.
*/
WST.View.RequestTour.ConfirmView.prototype._getNumGuests = function() {
    return cssQuery('.guestRow', this._baseElement).length;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method returns the number of guides in the confirm gudie section.
*/
WST.View.RequestTour.ConfirmView.prototype._getNumGuides = function() {
    return cssQuery('.guideRow', this._baseElement).length;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method returns all input elements on the current page with the "confirm-value" class.
*/
WST.View.RequestTour.ConfirmView.prototype._getInputElements = function() {
    return cssQuery('.confirm-value');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the specified value in the specified confirmation element.
*
* @param confirmElement - HTML element which to insert value.
* @param value - Value to insert.
*/
WST.View.RequestTour.ConfirmView.prototype._setValue = function(confirmElement, value) {
    if (this._objectUtils.isDefined(confirmElement)
            && this._objectUtils.isDefined(confirmElement.firstChild)
            && this._objectUtils.isDefined(confirmElement.firstChild.nodeValue)) {
        confirmElement.firstChild.nodeValue = value;
    } else if (this._objectUtils.isDefined(confirmElement)) {
        this._xmlUtils.removeAllChildren(confirmElement);
        confirmElement.appendChild(document.createTextNode(value));
    }
}

WST.View.RequestTour.ConfirmView.prototype._maskCreditCardNumber = function(creditCardNumber) {
    var lastFourDigits = creditCardNumber.substring(creditCardNumber.length - 4, creditCardNumber.length);
    var xStr = '';
    for(var j = 0; j < creditCardNumber.length - 4; j++){
      xStr += 'X';
    }
    creditCardNumber = xStr + lastFourDigits;
    return creditCardNumber;
}
