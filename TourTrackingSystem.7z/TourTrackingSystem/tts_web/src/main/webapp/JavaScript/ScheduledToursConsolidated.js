//var guestTable;
//var confirmGuestTable;
//var statesArray = [{value:"", text:"Select"}];
//var countriesArray = [{value:"", text:"Select"}];
//var classificationsArray = [{value:"", text:"Select"}];
//var locationsArray = [{value:" ", text:"Select"}, {value:"Domestic", text:"Domestic"}, {value:"International", text:"International"}];
//var requiredFieldClass = 'requiredField';
//var usaCountry = 'United States Of America';
//var naState = 'Not applicable';
//
//function loadGuestList() {
//    var loader = new YAHOO.util.YUILoader();
//    var contextPath = document.getElementById('contextPath').value;
//    loader.sandbox({
//        require: ["container", "connection", "datatable"],
//        base: contextPath + '/JavaScript/yui/',
//        loadOptional: false,
//        onSuccess: function() {
//            loadGuests();
//        }
//    });
//    loader.insert();
//}
//
//function loadGuests() {
//
//    this.createGuestTable = {
//        success: function(o) {
//            populateGuestTable(o);
//        },
//        failure: function(o) {
//        },
//        timeout: 30000 //30 seconds
//    };
//
//    var tourId = document.getElementById('__AUTOSAVE_ITEM_ID').value;
//    if (tourId === "") {
//        tourId = document.getElementById('originalTourId').value;
//    }
//    var url = document.getElementById('contextPath').value + "/servlet/guest.htm?tourId=" + tourId;
//    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
//            url,
//            this.createGuestTable);
//}
//
//function populateGuestTable(o) {
//    this.cache = null;
//    var xmlDoc = o.responseXML;
//    populateArray(xmlDoc, 'state', statesArray);
//    populateArray(xmlDoc, 'country', countriesArray);
//    populateArray(xmlDoc, 'classification', classificationsArray);
//
//    this.guestsSource = new YAHOO.util.DataSource(xmlDoc);
//    this.guestsSource.responseType = YAHOO.util.DataSource.TYPE_XML;
//    this.guestsSource.responseSchema = {
//        resultNode: "guest",
//        fields: ["firstName", "lastName", "location", "guestState", "guestCountry", "guestClassification"]
//    };
//
//
//    guestTable = getGuestTable(getGuestColumnDefs(), this.guestsSource);
//    confirmGuestTable = getConfirmGuestTable(getConfirmGuestColumnDefs(), this.guestsSource);
//    markMissingGuestFieldsAsRequired(xmlDoc);
//    displayNumberOfGuests(xmlDoc.getElementsByTagName('guest').length);
//    createHiddenFields();
//}
//
//function populateArray(xmlDoc, tagName, array) {
//    var elements = xmlDoc.getElementsByTagName(tagName);
//    var j = 1;
//    for (var i = 0; i < elements.length; i++) {
//        var idNodes = elements[i].getElementsByTagName('id');
//        if (idNodes.length > 0) {
//            var valueStr = elements[i].getElementsByTagName('id')[0].text;
//            var textStr = elements[i].getElementsByTagName('name')[0].text;
//            array[j++] = {value:valueStr, text:textStr};
//        }
//    }
//}
//
//function displayNumberOfGuests(numGuests) {
//    var numGuestsElement = document.getElementById('numGuests');
//    if (numGuestsElement != null) {
//        numGuestsElement.innerHTML = '(' + numGuests + ')';
//    }
//}
//
//function markMissingGuestFieldsAsRequired(xmlDoc) {
//    var guestElements = xmlDoc.getElementsByTagName('guest');
//    for (var k = 0; k < guestElements.length; k++) {
//        var firstName = guestElements[k].getElementsByTagName('firstName')[0].text;
//        if (firstName == "") {
//            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[1], requiredFieldClass);
//        }
//        var lastName = guestElements[k].getElementsByTagName('lastName')[0].text;
//        if (lastName == "") {
//            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[2], requiredFieldClass);
//        }
//        var location = guestElements[k].getElementsByTagName('location')[0].text;
//        if (location == "") {
//            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[3], requiredFieldClass);
//        }
//        var state = guestElements[k].getElementsByTagName('guestState')[0].text;
//        if (location == "Domestic") {
//            if (state == "") {
//                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[4], requiredFieldClass);
//            }
//            guestTable.getRow(k).cells[5].innerHTML = usaCountry;
//        }
//        var country = guestElements[k].getElementsByTagName('guestCountry')[0].text;
//        if (location == "International") {
//            if (country == "") {
//                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[5], requiredFieldClass);
//            }
//            guestTable.getRow(k).cells[4].innerHTML = naState;
//        }
//        var classification = guestElements[k].getElementsByTagName('guestClassification')[0].text;
//        if (classification == "") {
//            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[6], requiredFieldClass);
//        }
//    }
//}
//
//function createHiddenFields() {
//    var formElement = document.forms[0];
//    for (var i = 0; i < guestTable.getRecordSet().getLength(); i++) {
//        var firstName = guestTable.getRecordSet().getRecord(i).getData().firstName;
//        var lastName = guestTable.getRecordSet().getRecord(i).getData().lastName;
//        var location = guestTable.getRecordSet().getRecord(i).getData().location;
//        var state = guestTable.getRecordSet().getRecord(i).getData().guestState;
//        var country = guestTable.getRecordSet().getRecord(i).getData().guestCountry;
//        var classification = guestTable.getRecordSet().getRecord(i).getData().guestClassification;
//
//        if (firstName != "" || lastName != "") {
//            formElement.appendChild(document.createElement("<input name='guestFirstName' type='hidden' value='" +
//                                                           firstName +
//                                                           "'/>"));
//            formElement.appendChild(document.createElement("<input name='guestLastName' type='hidden' value='" +
//                                                           lastName +
//                                                           "'/>"));
//            formElement.appendChild(document.createElement("<input name='guestLocation' type='hidden' value='" +
//                                                           location +
//                                                           "'/>"));
//            formElement.appendChild(document.createElement("<input name='guestState' type='hidden' value='" + state +
//                                                           "'/>"));
//            formElement.appendChild(document.createElement("<input name='guestCountry' type='hidden' value='" +
//                                                           country +
//                                                           "'/>"));
//            formElement.appendChild(document.createElement("<input name='guestClassification' type='hidden' value='" +
//                                                           classification + "'/>"));
//        }
//    }
//}
//
//function deleteHiddenFields() {
//    var formElement = document.forms[0];
//    var firstNameElemets = document.getElementsByName('guestFirstName');
//    var lastNameElemets = document.getElementsByName('guestLastName');
//    var locationElemets = document.getElementsByName('guestLocation');
//    var stateElemets = document.getElementsByName('guestState');
//    var countryElemets = document.getElementsByName('guestCountry');
//    var classficationElemets = document.getElementsByName('guestClassification');
//    var firstNameLength = firstNameElemets.length;
//    for (var i = firstNameLength - 1; i > -1; i--) {
//        formElement.removeChild(firstNameElemets[i]);
//        formElement.removeChild(lastNameElemets[i]);
//        formElement.removeChild(locationElemets[i]);
//        formElement.removeChild(stateElemets[i]);
//        formElement.removeChild(countryElemets[i]);
//        formElement.removeChild(classficationElemets[i]);
//    }
//}
//
//function onkeyupEvent(v, newData, oColumn, oRecord) {
//
//    var numColumns = guestTable.getColumnSet().keys.length;
//    var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
//    var totalRows = guestTable.getRecordSet().getLength();
//    if (v.keyCode == 13) {//enter
//        if (totalRows - rowIndex == 1) {//if last row add a new row
//            addGuest();//create a new row
//            guestTable.fireEvent("cellClickEvent",
//            {target:guestTable.getLastTrEl().cells[1], event:event}
//                    );
//        } else {//go to the next row
//            guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
//        }
//    }
//    if (v.keyCode == 9) {//tab
//        if (oColumn.key == 'location') {
//            if (newData == 'Domestic') {//go to state
//                guestTable.fireEvent("cellClickEvent",
//                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//                        );
//            } else if (newData == 'International') {//go to country
//                guestTable.fireEvent("cellClickEvent",
//                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//                        );
//            } else {//go to classification if location not selected
//                guestTable.fireEvent("cellClickEvent",
//                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
//                        );
//            }
//        } else
//            if (oColumn.key == 'guestState') {//go to classfication
//                guestTable.fireEvent("cellClickEvent",
//                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//                        );
//            }
//            else //go to the next column
//                if (numColumns - oColumn.getIndex() == 2) {//if last but one column
//                    if (totalRows - rowIndex == 1) {//if last row add a new row
//                        addGuest();
//                        guestTable.fireEvent("cellClickEvent",
//                        {target:guestTable.getLastTrEl().cells[1], event:event}
//                                );
//                    } else {
//                        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
//                    }
//                } else {
//                    //go to the next column
//                    guestTable.fireEvent("cellClickEvent",
//                    {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//                            );
//                }
//    }
//}
//
////
////    if (numColumns - oColumn.getIndex() == 2) {//if last but one column
////      var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
////      var totalRows = guestTable.getRecordSet().getLength();
////      if (totalRows - rowIndex == 1) {//if last row add a new row
////        addGuest();
////        guestTable.fireEvent("cellClickEvent",
////        {target:guestTable.getLastTrEl().cells[1], event:event}
////            );
////      } else {
////        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
////      }
////    } else {
////      if (oColumn.key == 'location') {
////        if (newData == 'Domestic') {//go to state
////          guestTable.fireEvent("cellClickEvent",
////          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
////              );
////        } else if (newData == 'International') {//go to country
////          guestTable.fireEvent("cellClickEvent",
////          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
////              );
////        } else {//go to classification iff location not selected
////          guestTable.fireEvent("cellClickEvent",
////          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
////              );
////        }
////      } else {
////        if (oColumn.key == 'guestState') {//go to classfication
////          guestTable.fireEvent("cellClickEvent",
////          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
////              );
////        }
////        else {//go to the next column
////          guestTable.fireEvent("cellClickEvent",
////          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
////              );
////        }
////      }
////    }
//
//
//function onchangeEvent(newData, toSaveOrNot) {
//    var oldData = guestTable._oCellEditor.record.getData(guestTable._oCellEditor.column.key);
//    guestTable._oRecordSet.updateKey(guestTable._oCellEditor.record, guestTable._oCellEditor.column.key, newData);
//    guestTable.formatCell(guestTable._oCellEditor.cell);
//    guestTable.fireEvent("editorSaveEvent",
//    {editor:guestTable._oCellEditor, oldData:oldData, newData:newData, record:guestTable._oCellEditor.record, toSaveOrNot:toSaveOrNot}
//            );
//}
//
//
//function getGuestColumnDefs() {
//
//    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
//        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
//        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
//                            oRecord.getData(oColumn.key);
//        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
//                      oColumn.editorOptions.dropdownOptions : null;
//        for (var i = 0; i < options.length; i++) {
//            if (options[i].value == selectedValue) {
//                if (selectedValue.length > 0) {
//                    el.innerHTML = options[i].text;
//                }
//                break;
//            }
//        }
//    }
//
//    this.deleteGuestFormatter = function(el, oRecord, oColumn, oData) {
//        el.innerHTML = '<img border="0" alt="Delete Guest" src="' + document.getElementById('contextPath').value +
//                       '/images/icon_delete.gif">';
//        el.style.cursor = 'pointer';
//    }
//
//    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
//        var rowId = this.getTrEl(el).sectionRowIndex;
//        el.innerHTML = rowId + 1;
//    }
//
//    this.editTextBox = function (oEditor, oSelf) {
//        var oRecord = oEditor.record;
//        var oColumn = oEditor.column;
//        var elContainer = oEditor.container;
//        var value = oRecord.getData(oColumn.key);
//
//        var elTextbox = elContainer.appendChild(document.createElement("input"));
//        elTextbox.type = "text";
//        elTextbox.style.width = "100px";
//        elTextbox.value = value;
//
//        YAHOO.util.Event.addListener(elTextbox, "keydown", function(v) {
//            onkeyupEvent(v, elTextbox.value, oColumn, oRecord);
//        });
//
//        YAHOO.util.Event.addListener(elTextbox, "focusout", function() {
//            onchangeEvent(elTextbox.value, true);
//        });
//        elTextbox.focus();
//        elTextbox.select();
//    };
//
//    this.editDropdown = function (oEditor, oSelf) {
//
//        var oRecord = oEditor.record;
//        var oColumn = oEditor.column;
//        var elContainer = oEditor.container;
//
//        var value = oRecord.getData(oColumn.key);
//        var elDropdown = elContainer.appendChild(document.createElement("select"));
//        var dropdownOptions = (oColumn.editorOptions && YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
//                              oColumn.editorOptions.dropdownOptions : [];
//        for (var j = 0; j < dropdownOptions.length; j++) {
//            var dropdownOption = dropdownOptions[j];
//            var elOption = document.createElement("option");
//            elOption.value = (YAHOO.lang.isValue(dropdownOption.value)) ? dropdownOption.value : dropdownOption;
//            elOption.innerHTML = (YAHOO.lang.isValue(dropdownOption.text)) ? dropdownOption.text : dropdownOption;
//            elOption = elDropdown.appendChild(elOption);
//            if (value === elDropdown.options[j].value) {
//                elDropdown.options[j].selected = true;
//            }
//        }
//        YAHOO.util.Event.addListener(elDropdown, "keydown", function(v) {
//            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, false);
//
//            onkeyupEvent(v, elDropdown[elDropdown.selectedIndex].value, oColumn, oRecord);
//        });
//
//        YAHOO.util.Event.addListener(elDropdown, "focusout", function() {
//            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, true);
//        });
//        oSelf._focusEl(elDropdown);
//    };
//
//    return [
//        {label:"", formatter:this.rowNumberFormatter},
//        {key:"firstName", label:"<b>First Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
//        {key:"lastName", label:"<b>Last Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
//        {key:"location", label:"<b>Location</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:locationsArray}, sortable:true, resizeable:true},
//        {key:"guestState", label:"<b>State</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:statesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
//        {key:"guestCountry", label:"<b>Country</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:countriesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
//        {key:"guestClassification", label:"<b>Classification</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true, width:300},
//        {key:"delete", label:"", formatter:this.deleteGuestFormatter}
//    ];
//}
//
//function getConfirmGuestColumnDefs() {
//
//    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
//        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
//        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
//                            oRecord.getData(oColumn.key);
//        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
//                      oColumn.editorOptions.dropdownOptions : null;
//        for (var i = 0; i < options.length; i++) {
//            if (options[i].value == selectedValue) {
//                if (selectedValue.length > 0) {
//                    el.innerHTML = options[i].text;
//                }
//                break;
//            }
//        }
//    }
//
//    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
//        var rowId = this.getTrEl(el).sectionRowIndex;
//        el.innerHTML = rowId + 1;
//    }
//
//    return [
//        {label:"", formatter:this.rowNumberFormatter},
//        {key:"firstName", label:"<b>First Name</b>"},
//        {key:"lastName", label:"<b>Last Name</b>"},
//        {key:"location", label:"<b>Location</b>", editor:"dropdown", editorOptions:{dropdownOptions:locationsArray}},
//        {key:"guestState", label:"<b>State</b>", editor:"dropdown", editorOptions:{dropdownOptions:statesArray}, formatter:this.dropDownFormatter},
//        {key:"guestCountry", label:"<b>Country</b>", editor:"dropdown", editorOptions:{dropdownOptions:countriesArray}, formatter:this.dropDownFormatter},
//        {key:"guestClassification", label:"<b>Classification</b>", editor:"dropdown", editorOptions:{dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter}
//    ];
//}
//
//function getGuestTable(columnDefs, dataSource) {
//
//    this.onCellEditSaveGuestValue = function(oArgs) {
//        var toSaveOrNot = oArgs.toSaveOrNot;
//        var currentCell = oArgs.editor.cell;
//        var newData = oArgs.newData;
//        var oRecord = oArgs.editor.record;
//        var guestRow = this.getTrEl(oRecord);
//        var guestTableRowIndex = guestRow.sectionRowIndex;
//        confirmGuestTable.updateRow(confirmGuestTable.getTrEl(guestTableRowIndex), oRecord.getData());
//        if (oArgs.editor.column.key == 'location') {
//            if (newData == 'Domestic') {
//                guestRow.cells[4].innerHTML = "";
//                oRecord.getData().guestCountry = "";
//                guestRow.cells[5].innerHTML = usaCountry;
//                YAHOO.util.Dom.addClass(guestRow.cells[4], requiredFieldClass);
//                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
//            } else if (newData == 'International') {
//                oRecord.getData().guestState = "";
//                guestRow.cells[4].innerHTML = naState;
//                guestRow.cells[5].innerHTML = "";
//                YAHOO.util.Dom.addClass(guestRow.cells[5], requiredFieldClass);
//                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
//            } else {
//                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
//                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
//            }
//        }
//        if (newData == '') {
//            YAHOO.util.Dom.addClass(currentCell, requiredFieldClass);
//        } else {
//            YAHOO.util.Dom.removeClass(currentCell, requiredFieldClass);
//        }
//
//        if (toSaveOrNot) {
//            deleteHiddenFields();
//            createHiddenFields();
//            autosave(document.forms['tourForm']);
//        }
//    }
//
//    this.onCellClickEvent = function(ev) {
//        var target = YAHOO.util.Event.getTarget(ev);
//        var column = guestTable.getColumn(target);
//        if (column.key == 'delete') {
//            var rowId = guestTable.getRow(target).sectionRowIndex;
//            deleteGuest(rowId);
//        } else {
//            guestTable.onEventShowCellEditor(ev);
//        }
//    }
//
//    guestTable = new YAHOO.widget.DataTable("guestTableDiv", columnDefs, dataSource);
//    guestTable.subscribe("cellMouseoverEvent", guestTable.onEventHighlightCell);
//    guestTable.subscribe("cellMouseoutEvent", guestTable.onEventUnhighlightCell);
//    var addGuestButton = document.getElementById("addRow");
//    var disabled = addGuestButton.getAttribute("disabled");
//    if (disabled != true) {
//        guestTable.subscribe("editorSaveEvent", this.onCellEditSaveGuestValue);
//        guestTable.subscribe("cellClickEvent", this.onCellClickEvent);
//        guestTable.subscribe("editorBlurEvent", function(oArgs) {
//            this.cancelCellEditor();
//        });
//    }
//    return guestTable;
//}
//
//function getConfirmGuestTable(columnDefs, dataSource) {
//    confirmGuestTable = new YAHOO.widget.DataTable("confirmGuestsDiv", columnDefs, dataSource);
//    return confirmGuestTable;
//}
//
//function addGuest() {
//    var prevRow = guestTable.getLastTrEl();
//    var location = '';
//    var state = '';
//    var country = '';
//    var classification = '';
//
//    if (prevRow != null) {//copy previous row's values to the new row
//        var lastRecord = guestTable.getRecord(prevRow);
//        location = lastRecord.getData().location;
//        state = lastRecord.getData().guestState;
//        country = lastRecord.getData().guestCountry;
//        classification = lastRecord.getData().guestClassification;
//    }
//    guestTable.addRow({
//        firstName:"",
//        lastName:"",
//        location:location,
//        guestState:state,
//        guestCountry:country,
//        guestClassification:classification
//    });
//
//    confirmGuestTable.addRow({
//        firstName:"",
//        lastName:"",
//        location:location,
//        guestState:state,
//        guestCountry:country,
//        guestClassification:classification
//    });
//
//    var newRow = guestTable.getLastTrEl();
//    if (prevRow != null) {
//        if (state == "") {
//            state = prevRow.cells[4].innerHTML;//In case previous row had 'Not Applicable' in state column
//            newRow.cells[4].innerHTML = state;//In case previous row had 'Not Applicable' in state column
//        }
//
//        if (country == "") {
//            country = prevRow.cells[5].innerHTML;//In case previous row had 'United States of America' in country column
//            newRow.cells[5].innerHTML = country;//In case previous row had 'United States of America' in country column
//        }
//    }
//
//    var cells = newRow.cells;
//    for (var t = 1; t < cells.length - 1; t++) {
//        var cell = cells[t];
//        YAHOO.util.Dom.addClass(cell, requiredFieldClass);
//    }
//    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);
//
//    //deleteHiddenFields();
//    //createHiddenFields();
//    //autosave(document.forms['tourForm']);
//}
//
//function deleteGuest(rowId) {
//    guestTable.deleteRow(rowId);
//    guestTable.refreshView();
//
//    confirmGuestTable.deleteRow(rowId);
//    confirmGuestTable.refreshView();
//
//    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);
//
//    deleteHiddenFields();
//    createHiddenFields();
//    autosave(document.forms['tourForm']);
//}
//
//
//function showModalSaveMyChangesWarning(status) {
//    var handleSubmit = function() {
//        saveMyChanges();
//    };
//    var handleCancel = function() {
//        this.cancel();
//    };
//
//    if (status != null) {
//        var tourStatus = document.getElementById('tourStatus');
//        tourStatus.value = status;
//    }
//    var anotherUserElement = document.getElementById('anotherUserHasUncompleteChanges');
//    if (anotherUserElement == null) {
//        saveMyChanges();
//    } else {
//        var message = anotherUserElement.value;
//        message = "<b>Are you sure?</b><br/>" + message + "<br/>";
//        message += "<b>Clicking on Save Changes will override other user's Incomplete Changes for this tour.</b><br/>";
//        var areYouSure =
//                new YAHOO.widget.Dialog("modalDialogForSaveMyChanges",
//                { width:"400px",
//                    fixedcenter:true,
//                    close:false,
//                    draggable:false,
//                    zindex:4,
//                    visible:false,
//                    modal:true,
//                    buttons : [ { text:"Save My Changes", handler:handleSubmit },
//                        { text:"Cancel", handler:handleCancel } ]
//                }
//                        );
//
//        //areYouSure.setHeader("Are you sure?");
//        areYouSure.setBody(message);
//        areYouSure.render();
//        areYouSure.show();
//    }
//}
//
//function saveMyChanges() {
//    document.getElementById('method').value = 'addTour';
//    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
//    document.forms[0].submit();
//}
//
//function saveImportGuestInfo() {
//    autosave(document.forms['tourForm']);
//    document.getElementById('method').value = 'addTour';
//    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
//    document.forms[0].submit();
//
//}

//ppsclient.js
//=====================================================================================================================
//DIMENSION GLOBAL SCOPE CLIENT SIDE VARIABLES
//=====================================================================================================================
//var oPeoplePicker					//USED TO STORE A REFERENCE TO THE PEOPLE PICKER BROWSER WINDOW OBJECT
//var bPeoplePickerIsOpen = false;	//USED TO DENOTE WHETHER THE PEOPLE PICKER WINDOW HAS BEEN OPENED
//
//
//function Search4People()
//{
//	//=====================================================================================================================
//	//Synopsis: OPENS THE PEOPLE PICKER UTILITY IN A NEW WINDOW
//	//
//	//   NOTE: loadPeople() MUST exist in this page in order for this feature to work properly.
//	//
//	//=====================================================================================================================
//	// var fieldObject = document.all.hdnPartyID.value;
//	//OPEN THE PEOPLE PICKER UTILITY IN A NEW WINDOW
//	var lwidth = 600, lheight = 450;
//	var ltop = (window.screen.availHeight - lheight)/2;
//	var lleft = (window.screen.availWidth - lwidth)/2;
//
//	// changed for getting the people picker url from web.config file.
//	var sPickerURL = "/ppsclient/PPService.do?selectable=single";
//	//var sPickerURL = document.all.hdnPeoplePickerURL.value;
//	// If the party ID is present.
//	// if(fieldObject != null || fieldObject != "")
//	//	sPickerURL = sPickerURL + "?LoadPeople=1";
//	oPeoplePicker = window.open(sPickerURL, "PeoplePicker", "status=1,toolbar=0,location=0,directories=0,menubar=0,resizable=0,scrollbars=yes,width=" + lwidth + ",height=" + lheight + ",top=" + ltop + ",left=" + lleft, true);
//
//
//	bPeoplePickerIsOpen = true;
//	//alert(bPeoplePickerIsOpen);
//}
//
//
//function loadPeople()
//{//alert("loadPeople = "+bPeoplePickerIsOpen);
////=====================================================================================================================
////Synopsis: PASSES A LIST OF PEOPLE TO BE LOADED IN THE PEOPLE PICKER
////
////			NOTE: The list passed to the PeoplePicker MUST be a comma delimited list of PeopleDirectory PartyIDs!!!
////			NOTE: This function is called by the People Picker Window after it has been loaded and called with
////				  the querystring parameter: "?LoadPeople=1".  Therefore, this function must be named exactly as is!!!
////=====================================================================================================================
//	if (bPeoplePickerIsOpen)
//	{//alert("in loadPeople , bPeoplePickerIsOpen = "+bPeoplePickerIsOpen);
//		oPeoplePicker.loadPeople(document.all.hdnPartyID.value);	//comma delimited list of PartyIDs passed to People Picker
//	}
//}
//
//
//function ClosePopUp()
//{
////=====================================================================================================================
////Synopsis: ATTEMPTS TO CLOSE THE PEOPLE PICKER IF IT HAS BEEN OPENED, OTHER WISE NOTHING IS DONE
////=====================================================================================================================
//	if (bPeoplePickerIsOpen)
//	{
//		oPeoplePicker.close();
//		bPeoplePickerIsOpen = false;
//	}
//}
//
//
//function GetSelectedPeople()
//{
//    //Check to see if any people were selected, If not return
//	var iNumSelPeople = oPeoplePicker.GetNumSelectedPeople_Java();
//	var lPersonData = 0;
//	var lPersonText = 1;
//	var arrPeopleDataFrmPP = new Array();
//	var arrPartyIDs = new Array();
//	var arrLastNameList = new Array();
//	var arrFirstNameList = new Array();
//	var arrMiddleNameList = new Array();
//	var arrPhoneList = new Array();
//	var arrUserIDs	= new Array();
//	var arrEmailIDs = new Array();
//	var aPeople; // 2 diemensional array
//	if(iNumSelPeople > 0)
//	{
//		// alert('inside getselectedpeople');
//		aPeople = oPeoplePicker.GetSelectedPeople_Java();
//		// alert('after getselectedpeople');
//		var tempStrData;
//		var tempStrText;
//		var tempArray = new Array();
//		for (i = 0; i < aPeople.length; i++)
//		{
//		// alert('inside loop');
//		// alert(aPeople.length);
//		//	tempStrData = aPeople[i][lPersonData];
//		tempStrData = aPeople[i];
//		//	tempStrText = aPeople[i][lPersonText];
//		// alert(tempStrData);
//		// alert(tempStrText);
//			// Person text is separated by '<+>', split using this string to separate
//			// Text at 0th position is = Party ID
//			// Text at 1st positions is = Email Address
//			// Text at 2nd positon is = Name in "Last, First Middel" format
//			// Text at 3rd position is = User ID(Lan ID)
//			tempArray = tempStrData.split("<+>");
//			arrPartyIDs[i] = tempArray[0];
//			//alert("Party ID = " + arrPartyIDs[i]);
//			arrLastNameList[i] = tempArray[2];
//			arrFirstNameList[i] = tempArray[3];
//			arrMiddleNameList[i] = tempArray[4];
//			//alert("Name List = " + arrNameList[i]);
//			arrUserIDs[i] = tempArray[5];
//			//alert("User Id = " + arrUserIDs[i]);
//			// arrPhoneList[i] = tempStrText.substring(tempStrText.indexOf(":")+1,tempStrText.length);
//			arrPhoneList[i] = tempArray[6];
//			//alert("Phone number = " + arrPhoneList[i]);
//			arrEmailIDs[i] = tempArray[1];
//		}
//		arrPeopleDataFrmPP[0] = arrPartyIDs;
//		arrPeopleDataFrmPP[1] = arrLastNameList;
//		arrPeopleDataFrmPP[2] = arrFirstNameList;
//		arrPeopleDataFrmPP[3] = arrMiddleNameList;
//		arrPeopleDataFrmPP[4] = arrUserIDs;
//		arrPeopleDataFrmPP[5] = arrPhoneList;
//		arrPeopleDataFrmPP[6] = arrEmailIDs;
//	}
//	// alert(arrPeopleDataFrmPP);
//	setValuesFromPeoplePicker(arrPeopleDataFrmPP)
//	//setValuesFromPeoplePickerFirstNameLastName(arrPeopleDataFrmPP)
//}
//
//// Commented and moved this code on each page.
//// --------------------------------------------------
//// Each page specific controls need to modify this section according to their needs
////
////	arrPeopleData
////		index - 0 : party id
////		index - 1 : last name
////		index - 2 : first name
////		index - 3 : middle name
////		index - 4 : user id
////		index - 5 : phone id
////		index - 6 : email
////
//// ---------------------------------------------------
////function setValuesFromPeoplePicker(arrPeopleData)
////{
////	document.getElementById("username").value = arrPeopleData[4];
////	document.getElementById("reportInitiator").value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
////	document.getElementById("fromAddress").value = arrPeopleData[6] + "@monsanto.com";
////}
//
////mcas_common.js
//// Common Javascript functions.
//	// --------------------------------------------------
//	// Each page need to have this method customized to get data from People Picker Utility.
//	// Do not change anything other than the html element ids.
//	//	arrPeopleData
//	//		index - 0 : party id
//	//		index - 1 : last name
//	//		index - 2 : first name
//	//		index - 3 : middle name
//	//		index - 4 : user id
//	//		index - 5 : phone id
//	//		index - 6 : email
//	//
//	// ---------------------------------------------------
//	var usernameConrolId="";
//	var fullnameConrolId="";
//	var emailConrolId="";
//	var phoneControlId="";
//	function setValuesFromPeoplePicker(arrPeopleData)
//	{
//		if (!usernameConrolId=="")
//			document.getElementById(usernameConrolId).value = arrPeopleData[4];
//		if (!fullnameConrolId=="")
//			document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
//    if (!emailConrolId=="")
//			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
//		if (!phoneControlId=="")
//			document.getElementById(phoneControlId).value = arrPeopleData[5];
//
//    //manually call onchange coz it is not triggered automatically when ppsclient sets values
//    if(document.getElementById(fullnameConrolId).onchange != null){
//         document.getElementById(fullnameConrolId).onchange();
//     }
//
//    document.getElementById(fullnameConrolId).focus();
//	}
//
//function setValuesFromPeoplePickerFirstNameLastName(arrPeopleData)
//	{
//		if (!usernameConrolId=="")
//			document.getElementById(usernameConrolId).value = arrPeopleData[4];
//		if (!fullnameConrolId==""){
//            if (arrPeopleData[3] != "") {
//                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[3] + " " + arrPeopleData[1];
//            }
//            else {
//                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[1];
//            }
//        }
//        if (!emailConrolId=="")
//			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
//		if (!phoneControlId=="")
//			document.getElementById(phoneControlId).value = arrPeopleData[5];
//
//    document.getElementById(fullnameConrolId).focus();
//	}
//	function setPeoplePickerControlIds(usrname,fullname,email,phone) {
//		usernameConrolId=usrname;
//		fullnameConrolId=fullname;
//		emailConrolId=email;
//    phoneControlId=phone;
//  }
//
//	function strtrim(s) {
//	 //Match spaces at beginning and end of text and replace with null strings
//		return s.replace(/^\s+/,'').replace(/\s+$/,'');
//	}

//Start niftycorners.js
function NiftyCheck(){
if(!document.getElementById || !document.createElement)
    return(false);
isXHTML=/html\:/.test(document.getElementsByTagName('body')[0].nodeName);
if(Array.prototype.push==null){Array.prototype.push=function(){
      this[this.length]=arguments[0]; return(this.length);}}
return(true);
}

function Rounded(selector,wich,bk,color,opt){
var i,prefixt,prefixb,cn="r",ecolor="",edges=false,eclass="",b=false,t=false;

if(color=="transparent"){
    cn=cn+"x";
    ecolor=bk;
    bk="transparent";
    }
else if(opt && opt.indexOf("border")>=0){
    var optar=opt.split(" ");
    for(i=0;i<optar.length;i++)
        if(optar[i].indexOf("#")>=0) ecolor=optar[i];
    if(ecolor=="") ecolor="#666";
    cn+="e";
    edges=true;
    }
else if(opt && opt.indexOf("smooth")>=0){
    cn+="a";
    ecolor=Mix(bk,color);
    }
if(opt && opt.indexOf("small")>=0) cn+="s";
prefixt=cn;
prefixb=cn;
if(wich.indexOf("all")>=0){t=true;b=true}
else if(wich.indexOf("top")>=0) t="true";
else if(wich.indexOf("tl")>=0){
    t="true";
    if(wich.indexOf("tr")<0) prefixt+="l";
    }
else if(wich.indexOf("tr")>=0){
    t="true";
    prefixt+="r";
    }
if(wich.indexOf("bottom")>=0) b=true;
else if(wich.indexOf("bl")>=0){
    b="true";
    if(wich.indexOf("br")<0) prefixb+="l";
    }
else if(wich.indexOf("br")>=0){
    b="true";
    prefixb+="r";
    }
var v=cssQuery(selector, document);
var l=v.length;
for(i=0;i<l;i++){
    if(edges) AddBorder(v[i],ecolor);
    if(t) AddTop(v[i],bk,color,ecolor,prefixt);
    if(b) AddBottom(v[i],bk,color,ecolor,prefixb);
    }
}

function AddBorder(el,bc){
var i;
if(!el.passed){
    if(el.childNodes.length==1 && el.childNodes[0].nodeType==3){
        var t=el.firstChild.nodeValue;
        el.removeChild(el.lastChild);
        var d=CreateEl("span");
        d.style.display="block";
        d.appendChild(document.createTextNode(t));
        el.appendChild(d);
        }
    for(i=0;i<el.childNodes.length;i++){
        if(el.childNodes[i].nodeType==1){
            el.childNodes[i].style.borderLeft="1px solid "+bc;
            el.childNodes[i].style.borderRight="1px solid "+bc;
            }
        }
    }
el.passed=true;
}

function AddTop(el,bk,color,bc,cn){
var i,lim=4,d=CreateEl("b");

if(cn.indexOf("s")>=0) lim=2;
if(bc) d.className="artop";
else d.className="rtop";
d.style.backgroundColor=bk;
for(i=1;i<=lim;i++){
    var x=CreateEl("b");
    x.className=cn + i;
    x.style.backgroundColor=color;
    if(bc) x.style.borderColor=bc;
    d.appendChild(x);
    }
el.style.paddingTop=0;
el.insertBefore(d,el.firstChild);
}

function AddBottom(el,bk,color,bc,cn){
var i,lim=4,d=CreateEl("b");

if(cn.indexOf("s")>=0) lim=2;
if(bc) d.className="artop";
else d.className="rtop";
d.style.backgroundColor=bk;
for(i=lim;i>0;i--){
    var x=CreateEl("b");
    x.className=cn + i;
    x.style.backgroundColor=color;
    if(bc) x.style.borderColor=bc;
    d.appendChild(x);
    }
el.style.paddingBottom=0;
el.appendChild(d);
}

function CreateEl(x){
if(isXHTML) return(document.createElementNS('http://www.w3.org/1999/xhtml',x));
else return(document.createElement(x));
}

function Mix(c1,c2){
var i,step1,step2,x,y,r=new Array(3);
if(c1.length==4)step1=1;
else step1=2;
if(c2.length==4) step2=1;
else step2=2;
for(i=0;i<3;i++){
    x=parseInt(c1.substr(1+step1*i,step1),16);
    if(step1==1) x=16*x+x;
    y=parseInt(c2.substr(1+step2*i,step2),16);
    if(step2==1) y=16*y+y;
    r[i]=Math.floor((x*50+y*50)/100);
    }
return("#"+r[0].toString(16)+r[1].toString(16)+r[2].toString(16));
}
//End niftycorners.js

//Start cssQuery.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

// the following functions allow querying of the DOM using CSS selectors
var cssQuery = function() {
var version = "2.0.2";

// -----------------------------------------------------------------------
// main query function
// -----------------------------------------------------------------------

var $COMMA = /\s*,\s*/;
var cssQuery = function($selector, $$from) {
try {
    var $match = [];
    var $useCache = arguments.callee.caching && !$$from;
    var $base = ($$from) ? ($$from.constructor == Array) ? $$from : [$$from] : [document];
    // process comma separated selectors
    var $$selectors = parseSelector($selector).split($COMMA), i;
    for (i = 0; i < $$selectors.length; i++) {
        // convert the selector to a stream
        $selector = _toStream($$selectors[i]);
        // faster chop if it starts with id (MSIE only)
        if (isMSIE && $selector.slice(0, 3).join("") == " *#") {
            $selector = $selector.slice(2);
            $$from = _msie_selectById([], $base, $selector[1]);
        } else $$from = $base;
        // process the stream
        var j = 0, $token, $filter, $arguments, $cacheSelector = "";
        while (j < $selector.length) {
            $token = $selector[j++];
            $filter = $selector[j++];
            $cacheSelector += $token + $filter;
            // some pseudo-classes allow arguments to be passed
            //  e.g. nth-child(even)
            $arguments = "";
            if ($selector[j] == "(") {
                while ($selector[j++] != ")" && j < $selector.length) {
                    $arguments += $selector[j];
                }
                $arguments = $arguments.slice(0, -1);
                $cacheSelector += "(" + $arguments + ")";
            }
            // process a token/filter pair use cached results if possible
            $$from = ($useCache && cache[$cacheSelector]) ?
                cache[$cacheSelector] : select($$from, $token, $filter, $arguments);
            if ($useCache) cache[$cacheSelector] = $$from;
        }
        $match = $match.concat($$from);
    }
    delete cssQuery.error;
    return $match;
} catch ($error) {
    cssQuery.error = $error;
    return [];
}};

// -----------------------------------------------------------------------
// public interface
// -----------------------------------------------------------------------

cssQuery.toString = function() {
    return "function cssQuery() {\n  [version " + version + "]\n}";
};

// caching
var cache = {};
cssQuery.caching = false;
cssQuery.clearCache = function($selector) {
    if ($selector) {
        $selector = _toStream($selector).join("");
        delete cache[$selector];
    } else cache = {};
};

// allow extensions
var modules = {};
var loaded = false;
cssQuery.addModule = function($name, $script) {
    if (loaded) eval("$script=" + String($script));
    modules[$name] = new $script();;
};

// hackery
cssQuery.valueOf = function($code) {
    return $code ? eval($code) : this;
};

// -----------------------------------------------------------------------
// declarations
// -----------------------------------------------------------------------

var selectors = {};
var pseudoClasses = {};
// a safari bug means that these have to be declared here
var AttributeSelector = {match: /\[([\w-]+(\|[\w-]+)?)\s*(\W?=)?\s*([^\]]*)\]/};
var attributeSelectors = [];

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// descendant selector
selectors[" "] = function($results, $from, $tagName, $namespace) {
    // loop through current selection
    var $element, i, j;
    for (i = 0; i < $from.length; i++) {
        // get descendants
        var $subset = getElementsByTagName($from[i], $tagName, $namespace);
        // loop through descendants and add to results selection
        for (j = 0; ($element = $subset[j]); j++) {
            if (thisElement($element) && compareNamespace($element, $namespace))
                $results.push($element);
        }
    }
};

// ID selector
selectors["#"] = function($results, $from, $id) {
    // loop through current selection and check ID
    var $element, j;
    for (j = 0; ($element = $from[j]); j++) if ($element.id == $id) $results.push($element);
};

// class selector
selectors["."] = function($results, $from, $className) {
    // create a RegExp version of the class
    $className = new RegExp("(^|\\s)" + $className + "(\\s|$)");
    // loop through current selection and check class
    var $element, i;
    for (i = 0; ($element = $from[i]); i++)
        if ($className.test($element.className)) $results.push($element);
};

// pseudo-class selector
selectors[":"] = function($results, $from, $pseudoClass, $arguments) {
    // retrieve the cssQuery pseudo-class function
    var $test = pseudoClasses[$pseudoClass], $element, i;
    // loop through current selection and apply pseudo-class filter
    if ($test) for (i = 0; ($element = $from[i]); i++)
        // if the cssQuery pseudo-class function returns "true" add the element
        if ($test($element, $arguments)) $results.push($element);
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

pseudoClasses["link"] = function($element) {
    var $document = getDocument($element);
    if ($document.links) for (var i = 0; i < $document.links.length; i++) {
        if ($document.links[i] == $element) return true;
    }
};

pseudoClasses["visited"] = function($element) {
    // can't do this without jiggery-pokery
};

// -----------------------------------------------------------------------
// DOM traversal
// -----------------------------------------------------------------------

// IE5/6 includes comments (LOL) in it's elements collections.
// so we have to check for this. the test is tagName != "!". LOL (again).
var thisElement = function($element) {
    return ($element && $element.nodeType == 1 && $element.tagName != "!") ? $element : null;
};

// return the previous element to the supplied element
//  previousSibling is not good enough as it might return a text or comment node
var previousElementSibling = function($element) {
    while ($element && ($element = $element.previousSibling) && !thisElement($element)) continue;
    return $element;
};

// return the next element to the supplied element
var nextElementSibling = function($element) {
    while ($element && ($element = $element.nextSibling) && !thisElement($element)) continue;
    return $element;
};

// return the first child ELEMENT of an element
//  NOT the first child node (though they may be the same thing)
var firstElementChild = function($element) {
    return thisElement($element.firstChild) || nextElementSibling($element.firstChild);
};

var lastElementChild = function($element) {
    return thisElement($element.lastChild) || previousElementSibling($element.lastChild);
};

// return child elements of an element (not child nodes)
var childElements = function($element) {
    var $childElements = [];
    $element = firstElementChild($element);
    while ($element) {
        $childElements.push($element);
        $element = nextElementSibling($element);
    }
    return $childElements;
};

// -----------------------------------------------------------------------
// browser compatibility
// -----------------------------------------------------------------------

// all of the functions in this section can be overwritten. the default
//  configuration is for IE. The functions below reflect this. standard
//  methods are included in a separate module. It would probably be better
//  the other way round of course but this makes it easier to keep IE7 trim.

var isMSIE = true;

var isXML = function($element) {
    var $document = getDocument($element);
    return (typeof $document.mimeType == "unknown") ?
        /\.xml$/i.test($document.URL) :
        Boolean($document.mimeType == "XML Document");
};

// return the element's containing document
var getDocument = function($element) {
    return $element.ownerDocument || $element.document;
};

var getElementsByTagName = function($element, $tagName) {
    return ($tagName == "*" && $element.all) ? $element.all : $element.getElementsByTagName($tagName);
};

var compareTagName = function($element, $tagName, $namespace) {
    if ($tagName == "*") return thisElement($element);
    if (!compareNamespace($element, $namespace)) return false;
    if (!isXML($element)) $tagName = $tagName.toUpperCase();
    return $element.tagName == $tagName;
};

var compareNamespace = function($element, $namespace) {
    return !$namespace || ($namespace == "*") || ($element.scopeName == $namespace);
};

var getTextContent = function($element) {
    return $element.innerText;
};

function _msie_selectById($results, $from, id) {
    var $match, i, j;
    for (i = 0; i < $from.length; i++) {
        if ($match = $from[i].all.item(id)) {
            if ($match.id == id) $results.push($match);
            else if ($match.length != null) {
                for (j = 0; j < $match.length; j++) {
                    if ($match[j].id == id) $results.push($match[j]);
                }
            }
        }
    }
    return $results;
};

// for IE5.0
if (![].push) Array.prototype.push = function() {
    for (var i = 0; i < arguments.length; i++) {
        this[this.length] = arguments[i];
    }
    return this.length;
};

// -----------------------------------------------------------------------
// query support
// -----------------------------------------------------------------------

// select a set of matching elements.
// "from" is an array of elements.
// "token" is a character representing the type of filter
//  e.g. ">" means child selector
// "filter" represents the tag name, id or class name that is being selected
// the function returns an array of matching elements
var $NAMESPACE = /\|/;
function select($$from, $token, $filter, $arguments) {
    if ($NAMESPACE.test($filter)) {
        $filter = $filter.split($NAMESPACE);
        $arguments = $filter[0];
        $filter = $filter[1];
    }
    var $results = [];
    if (selectors[$token]) {
        selectors[$token]($results, $$from, $filter, $arguments);
    }
    return $results;
};

// -----------------------------------------------------------------------
// parsing
// -----------------------------------------------------------------------

// convert css selectors to a stream of tokens and filters
//  it's not a real stream. it's just an array of strings.
var $STANDARD_SELECT = /^[^\s>+~]/;
var $$STREAM = /[\s#.:>+~()@]|[^\s#.:>+~()@]+/g;
function _toStream($selector) {
    if ($STANDARD_SELECT.test($selector)) $selector = " " + $selector;
    return $selector.match($$STREAM) || [];
};

var $WHITESPACE = /\s*([\s>+~(),]|^|$)\s*/g;
var $IMPLIED_ALL = /([\s>+~,]|[^(]\+|^)([#.:@])/g;
var parseSelector = function($selector) {
    return $selector
    // trim whitespace
    .replace($WHITESPACE, "$1")
    // e.g. ".class1" --> "*.class1"
    .replace($IMPLIED_ALL, "$1*$2");
};

var Quote = {
    toString: function() {return "'"},
    match: /^('[^']*')|("[^"]*")$/,
    test: function($string) {
        return this.match.test($string);
    },
    add: function($string) {
        return this.test($string) ? $string : this + $string + this;
    },
    remove: function($string) {
        return this.test($string) ? $string.slice(1, -1) : $string;
    }
};

var getText = function($text) {
    return Quote.remove($text);
};

var $ESCAPE = /([\/()[\]?{}|*+-])/g;
function regEscape($string) {
    return $string.replace($ESCAPE, "\\$1");
};

// -----------------------------------------------------------------------
// modules
// -----------------------------------------------------------------------

// -------- >>      insert modules here for packaging       << -------- \\

loaded = true;

// -----------------------------------------------------------------------
// return the query function
// -----------------------------------------------------------------------

return cssQuery;

}(); // cssQuery

///end cssQuery.js

///start end CSSQueryLevel2.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

cssQuery.addModule("css-level2", function() {

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// child selector
selectors[">"] = function($results, $from, $tagName, $namespace) {
    var $element, i, j;
    for (i = 0; i < $from.length; i++) {
        var $subset = childElements($from[i]);
        for (j = 0; ($element = $subset[j]); j++)
            if (compareTagName($element, $tagName, $namespace))
                $results.push($element);
    }
};

// sibling selector
selectors["+"] = function($results, $from, $tagName, $namespace) {
    for (var i = 0; i < $from.length; i++) {
        var $element = nextElementSibling($from[i]);
        if ($element && compareTagName($element, $tagName, $namespace))
            $results.push($element);
    }
};

// attribute selector
selectors["@"] = function($results, $from, $attributeSelectorID) {
    var $test = attributeSelectors[$attributeSelectorID].test;
    var $element, i;
    for (i = 0; ($element = $from[i]); i++)
        if ($test($element)) $results.push($element);
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

pseudoClasses["first-child"] = function($element) {
    return !previousElementSibling($element);
};

pseudoClasses["lang"] = function($element, $code) {
    $code = new RegExp("^" + $code, "i");
    while ($element && !$element.getAttribute("lang")) $element = $element.parentNode;
    return $element && $code.test($element.getAttribute("lang"));
};

// -----------------------------------------------------------------------
//  attribute selectors
// -----------------------------------------------------------------------

// constants
AttributeSelector.NS_IE = /\\:/g;
AttributeSelector.PREFIX = "@";
// properties
AttributeSelector.tests = {};
// methods
AttributeSelector.replace = function($match, $attribute, $namespace, $compare, $value) {
    var $key = this.PREFIX + $match;
    if (!attributeSelectors[$key]) {
        $attribute = this.create($attribute, $compare || "", $value || "");
        // store the selector
        attributeSelectors[$key] = $attribute;
        attributeSelectors.push($attribute);
    }
    return attributeSelectors[$key].id;
};
AttributeSelector.parse = function($selector) {
    $selector = $selector.replace(this.NS_IE, "|");
    var $match;
    while ($match = $selector.match(this.match)) {
        var $replace = this.replace($match[0], $match[1], $match[2], $match[3], $match[4]);
        $selector = $selector.replace(this.match, $replace);
    }
    return $selector;
};
AttributeSelector.create = function($propertyName, $test, $value) {
    var $attributeSelector = {};
    $attributeSelector.id = this.PREFIX + attributeSelectors.length;
    $attributeSelector.name = $propertyName;
    $test = this.tests[$test];
    $test = $test ? $test(this.getAttribute($propertyName), getText($value)) : false;
    $attributeSelector.test = new Function("e", "return " + $test);
    return $attributeSelector;
};
AttributeSelector.getAttribute = function($name) {
    switch ($name.toLowerCase()) {
        case "id":
            return "e.id";
        case "class":
            return "e.className";
        case "for":
            return "e.htmlFor";
        case "href":
            if (isMSIE) {
                // IE always returns the full path not the fragment in the href attribute
                //  so we RegExp it out of outerHTML. Opera does the same thing but there
                //  is no way to get the original attribute.
                return "String((e.outerHTML.match(/href=\\x22?([^\\s\\x22]*)\\x22?/)||[])[1]||'')";
            }
    }
    return "e.getAttribute('" + $name.replace($NAMESPACE, ":") + "')";
};

// -----------------------------------------------------------------------
//  attribute selector tests
// -----------------------------------------------------------------------

AttributeSelector.tests[""] = function($attribute) {
    return $attribute;
};

AttributeSelector.tests["="] = function($attribute, $value) {
    return $attribute + "==" + Quote.add($value);
};

AttributeSelector.tests["~="] = function($attribute, $value) {
    return "/(^| )" + regEscape($value) + "( |$)/.test(" + $attribute + ")";
};

AttributeSelector.tests["|="] = function($attribute, $value) {
    return "/^" + regEscape($value) + "(-|$)/.test(" + $attribute + ")";
};

// -----------------------------------------------------------------------
//  parsing
// -----------------------------------------------------------------------

// override parseSelector to parse out attribute selectors
var _parseSelector = parseSelector;
parseSelector = function($selector) {
    return _parseSelector(AttributeSelector.parse($selector));
};

}); // addModule
// end CSSQueryLevel2.js

// start CSSQueryLevel3.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

/* Thanks to Bill Edney */

cssQuery.addModule("css-level3", function() {

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// indirect sibling selector
selectors["~"] = function($results, $from, $tagName, $namespace) {
    var $element, i;
    for (i = 0; ($element = $from[i]); i++) {
        while ($element = nextElementSibling($element)) {
            if (compareTagName($element, $tagName, $namespace))
                $results.push($element);
        }
    }
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

// I'm hoping these pseudo-classes are pretty readable. Let me know if
//  any need explanation.

pseudoClasses["contains"] = function($element, $text) {
    $text = new RegExp(regEscape(getText($text)));
    return $text.test(getTextContent($element));
};

pseudoClasses["root"] = function($element) {
    return $element == getDocument($element).documentElement;
};

pseudoClasses["empty"] = function($element) {
    var $node, i;
    for (i = 0; ($node = $element.childNodes[i]); i++) {
        if (thisElement($node) || $node.nodeType == 3) return false;
    }
    return true;
};

pseudoClasses["last-child"] = function($element) {
    return !nextElementSibling($element);
};

pseudoClasses["only-child"] = function($element) {
    $element = $element.parentNode;
    return firstElementChild($element) == lastElementChild($element);
};

pseudoClasses["not"] = function($element, $selector) {
    var $negated = cssQuery($selector, getDocument($element));
    for (var i = 0; i < $negated.length; i++) {
        if ($negated[i] == $element) return false;
    }
    return true;
};

pseudoClasses["nth-child"] = function($element, $arguments) {
    return nthChild($element, $arguments, previousElementSibling);
};

pseudoClasses["nth-last-child"] = function($element, $arguments) {
    return nthChild($element, $arguments, nextElementSibling);
};

pseudoClasses["target"] = function($element) {
    return $element.id == location.hash.slice(1);
};

// UI element states

pseudoClasses["checked"] = function($element) {
    return $element.checked;
};

pseudoClasses["enabled"] = function($element) {
    return $element.disabled === false;
};

pseudoClasses["disabled"] = function($element) {
    return $element.disabled;
};

pseudoClasses["indeterminate"] = function($element) {
    return $element.indeterminate;
};

// -----------------------------------------------------------------------
//  attribute selector tests
// -----------------------------------------------------------------------

AttributeSelector.tests["^="] = function($attribute, $value) {
    return "/^" + regEscape($value) + "/.test(" + $attribute + ")";
};

AttributeSelector.tests["$="] = function($attribute, $value) {
    return "/" + regEscape($value) + "$/.test(" + $attribute + ")";
};

AttributeSelector.tests["*="] = function($attribute, $value) {
    return "/" + regEscape($value) + "/.test(" + $attribute + ")";
};

// -----------------------------------------------------------------------
//  nth child support (Bill Edney)
// -----------------------------------------------------------------------

function nthChild($element, $arguments, $traverse) {
    switch ($arguments) {
        case "n": return true;
        case "even": $arguments = "2n"; break;
        case "odd": $arguments = "2n+1";
    }

    var $$children = childElements($element.parentNode);
    function _checkIndex($index) {
        var $index = ($traverse == nextElementSibling) ? $$children.length - $index : $index - 1;
        return $$children[$index] == $element;
    };

    //    it was just a number (no "n")
    if (!isNaN($arguments)) return _checkIndex($arguments);

    $arguments = $arguments.split("n");
    var $multiplier = parseInt($arguments[0]);
    var $step = parseInt($arguments[1]);

    if ((isNaN($multiplier) || $multiplier == 1) && $step == 0) return true;
    if ($multiplier == 0 && !isNaN($step)) return _checkIndex($step);
    if (isNaN($step)) $step = 0;

    var $count = 1;
    while ($element = $traverse($element)) $count++;

    if (isNaN($multiplier) || $multiplier == 1)
        return ($traverse == nextElementSibling) ? ($count <= $step) : ($step >= $count);

    return ($count % $multiplier) == $step;
};

}); // addModule

//end CSSQueryLevel3.js

//start JSAN.js
/*

*/

var JSAN = function () { JSAN.addRepository(arguments) }

JSAN.VERSION = 0.10;

/*

*/

JSAN.globalScope   = self;
JSAN.includePath   = ['.', 'lib'];
JSAN.errorLevel    = "none";
JSAN.errorMessage  = "";
JSAN.loaded        = {};

/*

*/

JSAN.use = function () {
    var classdef = JSAN.require(arguments[0]);
    if (!classdef) return null;

    var importList = JSAN._parseUseArgs.apply(JSAN, arguments).importList;
    JSAN.exporter(classdef, importList);

    return classdef;
}

/*

*/

JSAN.require = function (pkg) {
    var path = JSAN._convertPackageToPath(pkg);
    if (JSAN.loaded[path]) {
        return JSAN.loaded[path];
    }

    try {
        var classdef = eval(pkg);
        if (typeof classdef != 'undefined') return classdef;
    } catch (e) { /* nice try, eh? */ }


    for (var i = 0; i < JSAN.includePath.length; i++) {
        var js;
        try{
            var url = JSAN._convertPathToUrl(path, JSAN.includePath[i]);
                js  = JSAN._loadJSFromUrl(url);
        } catch (e) {
            if (i == JSAN.includePath.length - 1) throw e;
        }
        if (js != null) {
            var classdef = JSAN._createScript(js, pkg);
            if(classdef!=null){
              JSAN.loaded[path] = classdef;
              return classdef;
            }
        }
    }
    return false;

}

/*

*/

JSAN.exporter = function () {
    JSAN._exportItems.apply(JSAN, arguments);
}

/*

*/

JSAN.addRepository = function () {
    var temp = JSAN._flatten( arguments );
    // Need to go in reverse to do something as simple as unshift( @foo, @_ );
    for ( var i = temp.length - 1; i >= 0; i-- )
        JSAN.includePath.unshift(temp[i]);
    return JSAN;
}

JSAN._flatten = function( list1 ) {
    var list2 = new Array();
    for ( var i = 0; i < list1.length; i++ ) {
        if ( typeof list1[i] == 'object' ) {
            list2 = JSAN._flatten( list1[i], list2 );
        }
        else {
            list2.push( list1[i] );
        }
    }
    return list2;
};

JSAN._findMyPath = function () {
    if (document) {
        var scripts = document.getElementsByTagName('script');
        for ( var i = 0; i < scripts.length; i++ ) {
            var src = scripts[i].getAttribute('src');
            if (src) {
                var inc = src.match(/^(.*?)\/?JSAN.js/);
                if (inc && inc[1]) {
                    var repo = inc[1];
                    for (var j = 0; j < JSAN.includePath.length; j++) {
                        if (JSAN.includePath[j] == repo) {
                            return;
                        }
                    }
                    JSAN.addRepository(repo);
                }
            }
        }
    }
}
JSAN._findMyPath();

JSAN._convertPathToUrl = function (path, repository) {
    return repository.concat('/' + path);
};


JSAN._convertPackageToPath = function (pkg) {
    var path = pkg.replace(/\./g, '/');
        path = path.concat('.js');
    return path;
}

JSAN._parseUseArgs = function () {
    var pkg        = arguments[0];
    var importList = [];

    for (var i = 1; i < arguments.length; i++)
        importList.push(arguments[i]);

    return {
        pkg:        pkg,
        importList: importList
    }
}

JSAN._loadJSFromUrl = function (url) {
	return new JSAN.Request().getText(url);
}

JSAN._findExportInList = function (list, request) {
    if (list == null) return false;
    for (var i = 0; i < list.length; i++)
        if (list[i] == request)
            return true;
    return false;
}

JSAN._findExportInTag = function (tags, request) {
    if (tags == null) return [];
    for (var i in tags)
        if (i == request)
            return tags[i];
    return [];
}

JSAN._exportItems = function (classdef, importList) {
    var exportList  = new Array();
    var EXPORT      = classdef.EXPORT;
    var EXPORT_OK   = classdef.EXPORT_OK;
    var EXPORT_TAGS = classdef.EXPORT_TAGS;

    if (importList.length > 0) {
       importList = JSAN._flatten( importList );

       for (var i = 0; i < importList.length; i++) {
            var request = importList[i];
            if (   JSAN._findExportInList(EXPORT,    request)
                || JSAN._findExportInList(EXPORT_OK, request)) {
                exportList.push(request);
                continue;
            }
            var list = JSAN._findExportInTag(EXPORT_TAGS, request);
            for (var i = 0; i < list.length; i++) {
                exportList.push(list[i]);
            }
        }
    } else {
        exportList = EXPORT;
    }
    JSAN._exportList(classdef, exportList);
}

JSAN._exportList = function (classdef, exportList) {
    if (typeof(exportList) != 'object') return null;
    for (var i = 0; i < exportList.length; i++) {
        var name = exportList[i];

        if (JSAN.globalScope[name] == null)
            JSAN.globalScope[name] = classdef[name];
    }
}

JSAN._makeNamespace = function(js, pkg) {
    var spaces = pkg.split('.');
    var parent = JSAN.globalScope;
    eval(js);
    var classdef = eval(pkg);
    for (var i = 0; i < spaces.length; i++) {
        var name = spaces[i];
        if (i == spaces.length - 1) {
            if (typeof parent[name] == 'undefined') {
                parent[name] = classdef;
                if ( typeof classdef['prototype'] != 'undefined' ) {
                    parent[name].prototype = classdef.prototype;
                }
            }
        } else {
            if (parent[name] == undefined) {
                parent[name] = {};
            }
        }

        parent = parent[name];
    }
    return classdef;
}

JSAN._handleError = function (msg, level) {
    if (!level) level = JSAN.errorLevel;
    JSAN.errorMessage = msg;

    switch (level) {
        case "none":
            break;
        case "warn":
            alert(msg);
            break;
        case "die":
        default:
            throw new Error(msg);
            break;
    }
}

JSAN._createScript = function (js, pkg) {
    try {
        return JSAN._makeNamespace(js, pkg);
    } catch (e) {
        JSAN._handleError("Could not create namespace[" + pkg + "]: " + e);
    }
    return null;
}


JSAN.prototype = {
    use: function () { JSAN.use.apply(JSAN, arguments) }
};


// Low-Level HTTP Request
JSAN.Request = function (jsan) {
    if (JSAN.globalScope.XMLHttpRequest) {
        this._req = new XMLHttpRequest();
    } else {
        this._req = new ActiveXObject("Microsoft.XMLHTTP");
    }
}

JSAN.Request.prototype = {
    _req:  null,
    _useIframe: false,
    _tempIFrame: null,
    _loaded: false,

    getText: function (url) {
        if (!this._useIframe) {
          try {
            this._req.open("GET", url, false);
          } catch (e) {
            return this.readFile(url);
          }
          try {
	            this._req.send(null);
	            if (this._req.status == 200 || this._req.status == 0)
	                return this._req.responseText;
	        } catch (e) {
	            JSAN._handleError("File not found: " + url);
	            return null;
	        };

	        JSAN._handleError("File not found: " + url);
	        return null;
	    }

		var _content = "";
	    if (!this._tempIFrame) {
			this._tempIFrame = document.createElement('iframe');
		    this._tempIFrame.src = "http://localhost:8080/summaryreports/" + url;
		    this._tempIFrame.setAttribute('id', 'jsSrc');
			this._tempIFrame.style.border='0px';
			this._tempIFrame.style.width='30px';
			this._tempIFrame.style.height='30px';
			alert(this._tempIFrame.innerHTML);
			var _self = this;
			this._tempIFrame.onload = function() {
				_content = _self.getContent();
			}
			document.getElementById('content').appendChild(this._tempIFrame);
		}
	    if (_content == "") {
	    	if (confirm(document.getElementById('jsSrc').innerHTML + " continue?")) {
		    	this.getText(url);
		    }
	    }
		alert("js returned from iframe = " + this._tempIFrame.contentDocument.childNodes[1].innerTEXT);
	    return this._tempIFrame.contentDocument.childNodes[1].innerTEXT;
    },

    getContent: function() {
    	alert("content loaded.");
    	this._loaded = true;
    	return this._tempIFrame.contentDocument.childNodes[1].innerTEXT;
    },

    readFile: function(url) {
       var oFS = new ActiveXObject("Scripting.FileSystemObject")
       var contents = null;
       var currentLocation = window.location.href;
       var locarray = currentLocation.split("/");
       locarray.splice(locarray.length - 1, locarray.length);
       var arraytext = locarray.join("/");
       arraytext = arraytext.replace(/%20/g, " ").replace(/file:\/\/\//, "") + '/' + url;
       if (oFS.fileExists(arraytext)) {
          var oTextStream = oFS.openTextFile(arraytext,1);
          contents = oTextStream.readAll();
          oTextStream.close();
          oTextStream = null;
       } else {
          JSAN._handleError("File not found: " + url);
       }
       oFS = null;
       return contents;
    }
};

/*

*/
//end JSAN.js

//start autoSave.js
var http_request = false;

function sendSyncRequest(url) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, false);
    http_request.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
    http_request.onreadystatechange = function() {
        if (http_request.readyState == 4) {
            callbackMethodAfterSync();
        }
    }

    http_request.send();
}

function callbackMethodAfterSync() {
    var autosaveSessionId = http_request.responseText;
//  autosaveSessionId = autosaveSessionId.replace("\r\n", '');
    document.getElementById('__AUTOSAVE_SESSION_ID').value = autosaveSessionId;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = 0;
    var itemId = this.document.getElementById('__AUTOSAVE_ITEM_ID').value;
    if (itemId == "" || itemId == "null") {
        itemId = "NEW" + autosaveSessionId;
        document.getElementById('__AUTOSAVE_ITEM_ID').value = itemId;
        document.getElementById('incompleteNewTourId').value = itemId;
    }
}

function sendAsyncRequest(url, parameters) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, true);
    http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http_request.setRequestHeader("Content-length", parameters.length);
    http_request.onreadystatechange = callbackMethodAfterAsync;
    http_request.send(parameters);
}

function callbackMethodAfterAsync() {
    // do nothing in the callback method
    if (http_request.readyState == 4) {
        if (http_request.status == 200) {
            var okAfterAutosave = http_request.responseText;
            if (okAfterAutosave.indexOf('OK') >= 0) {
                document.getElementsByName('discardChanges')[0].disabled = false;
                document.getElementsByName('discardChanges')[1].disabled = false;
                var saveChangesButton = document.getElementsByName('saveChanges');
                if (saveChangesButton.length > 0) {
                    document.getElementsByName('saveChanges')[0].disabled = false;
                    document.getElementsByName('saveChanges')[1].disabled = false;
                }
//          var submitChangesButton = document.getElementsByName('submitChanges');
                //          if(submitChangesButton.length > 0){
                //            document.getElementsByName('submitChanges')[0].disabled = false;
                //            document.getElementsByName('submitChanges')[1].disabled = false;
                //          }
                //          this.document.getElementById('currentUserHasIncompleteChanges').innerHTML = "You have incomplete changes from autosave";
                document.getElementById('currentUserHasIncompleteChanges').style.display = "";
            }
        }
    }


}

function getQueryStringForAutosave(obj) {
    var getstr = "";
    for (i = 0; i < obj.childNodes.length; i++) {
        if (obj.childNodes[i].tagName.toLowerCase() == "input") {
            if (obj.childNodes[i].type == "text") {
                getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
            }

            if (obj.childNodes[i].type.toLowerCase() == "checkbox") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                } else {
                    getstr += obj.childNodes[i].name + "=&";
                }
            }
            if (obj.childNodes[i].type.toLowerCase() == "radio") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                }
            }
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "select") {
            var sel = obj.childNodes[i];
            getstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "textarea") {
            getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
        }
    }
    return getstr;
}

function getQueryStringForAutosaveForEntireForm(frm) {
    var getstr = "";
    for (i = 0; i < frm.elements.length; i++) {
        var frmElement = frm.elements[i];
        if (frmElement.tagName.toLowerCase() == "input") {
            if (frmElement.type == "text") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type == "hidden") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type.toLowerCase() == "checkbox") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                } else {
                    getstr += frmElement.name + "=&";
                }
            }
            if (frmElement.type.toLowerCase() == "radio") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                }
            }
        }
        if (frmElement.tagName.toLowerCase() == "select") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.options[frmElement.selectedIndex].value) + "&";
        }
        if (frmElement.tagName.toLowerCase() == "textarea") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
        }
    }
    return getstr;
}

function startSessionIfNotAlreadyStarted() {
    var autosaveSessionId = document.getElementById('__AUTOSAVE_SESSION_ID').value;
    if (autosaveSessionId == null || autosaveSessionId == "") {
        startAutosaveSession();
    }
}

function autosave(formObj) {
    startSessionIfNotAlreadyStarted();
    var autosaveSeqStr = document.getElementById('__AUTOSAVE_SESSION_SEQ').value;
    var autosaveSeq = parseInt(autosaveSeqStr);
    autosaveSeq += 1;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = autosaveSeq;
    var getstr = getQueryStringForAutosaveForEntireForm(formObj);
    sendAsyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=SAVE', getstr);
}

function startAutosaveSession() {
    sendSyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=START');
}
//end autoSave.js

//Start NamespaceUtils.js
// Create each namespace in the path if it doesn't already exists.
if (typeof Lib == 'undefined') {
    Lib = {};
}

if (!Lib.Utils) {
    Lib.Utils = {};
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description:
*   This is a javascript object that performs utility functions on a namespace.
*/
Lib.Utils.NamespaceUtils = {};

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description: This method takes a namespace classpath and creates any levels of the namespace that have not already
*   been created.
*
*   ie: 'Lib.Utils.JSAN'
*
* @param classpath - String representing a namespace path.
*/
Lib.Utils.NamespaceUtils.createIfNecessary = function(classpath) {
    var namespaces = classpath.split('.');
    var currentNamespace = "";
    for (var i = 0; i < namespaces.length; i++) {
        currentNamespace = currentNamespace + namespaces[i];
        var classdef;
        try {
            classdef = eval(currentNamespace);
        } catch (e) {
            this.createNewNamespace(currentNamespace);
        }
        if (typeof classdef == 'undefined') {
            this.createNewNamespace(currentNamespace);
        }
        currentNamespace = currentNamespace + ".";
    }
}

Lib.Utils.NamespaceUtils.createNewNamespace = function(namespace) {
    eval(namespace + " = {}");
}
//End NamespaceUtils.js


//Start Lib.Utils.ObjectUtils.js

JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* description:
*   This object is used to perform utility operations on objects.
*/
Lib.Utils.ObjectUtils = {};

// Array of context objects used for binding.
Lib.Utils.ObjectUtils.CTX_OBJECTS = new Array();

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method returns whether the specified parameter is an object.
*
* @param object - Parameter to check.
*/
Lib.Utils.ObjectUtils.isObject = function(object) {
    if (typeof object == 'object') {
        return true;
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method provides the ability to subclass javascript objects.  You just pass it the would be child and the parent
*   and it grants the child inheritance.
*
* @param child - Child object.
* @param parent - Parent object to extend.
*/
Lib.Utils.ObjectUtils.extend = function(child, parent) {
    for (var property in parent) {
        child[property] = parent[property];
    }
    return child;
}

/**
* author: Nate Minshew
* date created: 03/28/2006
* access level: public
* description:
*   This method binds the specified function to the specified context using a weak bind pattern.  Weak binds reduce
*   memory leaks that occur in IE when having circular dependencies on the DOM.  This creates an indirect reference
*   between the function and it's context.
*
* @param fn - Function to bind.
* @param ctx - Context object to find the function to.
* @return Function representing the original function with a weak binding to the context object.
*/
Lib.Utils.ObjectUtils.weakBind = function(fn, ctx) {
    var index = Lib.Utils.ObjectUtils.CTX_OBJECTS.length;
    Lib.Utils.ObjectUtils.CTX_OBJECTS.push(ctx);
    return Lib.Utils.ObjectUtils._bindIndexAndReturnFunction(fn, index);
}

/**
* author: Nate Minshew
* date created: 03/28/2006
* access level: non-public
* description:
*   This method takes the specified function and weakly binds it to the context object represented by the specified
*   index.
*
* @param fn - Function to bind.
* @param index - Representing the index of the context object.
* @return Function representing the original function with a weak binding to the context object.
*/
Lib.Utils.ObjectUtils._bindIndexAndReturnFunction = function(fn, index) {
    return function() {
        var ctx = Lib.Utils.ObjectUtils.CTX_OBJECTS[index];
        fn.apply(ctx, arguments);
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method clears all cached context objects.  This is important to call on unload events to prevent memory leaks.
*/
Lib.Utils.ObjectUtils.clearContextObjects = function() {
    Lib.Utils.ObjectUtils.CTX_OBJECTS = new Array();
}

/**
* author: Nate Minshew
* date created: 04/11/2006
* access level: public
* description:
*   This method returns whether the specified object/property is defined and not null.
*
* @param obj - object/property to check.
* @param boolean - Representing if the object/property is defined.
*/
Lib.Utils.ObjectUtils.isDefined = function(obj) {
    if (typeof obj != 'undefined' && obj != null) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 03/06/2006
* description:
*   This object contains utility methods for performing tasks on an array.
*/
Lib.Utils.ObjectUtils.ArrayUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method returns whether the specified object is an array.
*
* @param object - The object to check.
*/
Lib.Utils.ObjectUtils.ArrayUtils.isArray = function(object) {
    if (Lib.Utils.ObjectUtils.isObject(object) && typeof object.length != 'undefined') {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 03/06/2006
* access level: public
* description:
*   This method returns a boolean representing if the specified entry is contained within the specified array.
*
* @param array - Array object.
* @param entry - Value to check array for.
* @return boolean - Representing if the array contains the entry.
*/
Lib.Utils.ObjectUtils.ArrayUtils.contains = function(array, entry) {
    for (var i = 0; Lib.Utils.ObjectUtils.ArrayUtils.isArray(array) && i < array.length; i++) {
        if (array[i] == entry) {
            return true;
        }
    }
    return false;
}
//End Lib.Utils.ObjectUtils.js



//Start Lib.Utils.EventUtils.js
/**
* created by: Nate Minshew
* date created: 09/06/2005
* description: This is a javascript class that handles modifying events on javascript objects.  It allows you to add
*   and remove multiple events like 'onclick' and 'onchange' to html elements.  This is provided in replace of changing
*   the function that the event is set to, for example:
*
*   window.onload = function () { ... };
*
*   This is bad because no other object can now set onload events without overridding the current event.  This class
*   solves that problem.
*/
Lib.Utils.EventUtils = {};

// This array represents events in the global context.
Lib.Utils.EventUtils.EVENTS = new Array();

/**
* created by: Nate Minshew
* date created: 09/06/2005
* access level: public
* description: Adds an event to the specified object.
*
* obj - Object the event is to be applied to.
* type - Type of event to add, ei. 'click' for 'onclick'.
* fn - Function to call for the event.
* ctxObj - Object representing the context to weakly bind to the specified event.
*/
Lib.Utils.EventUtils.addEvent = function(obj, type, fn, ctxObj) {
    if (typeof ctxObj != 'undefined' && ctxObj != null) {
        fn = Lib.Utils.ObjectUtils.weakBind(fn, ctxObj);
    }

    if (obj.addEventListener) {
        obj.addEventListener(type, fn, false);
        var id = Lib.Utils.EventUtils.EVENTS.length;
        Lib.Utils.EventUtils.EVENTS.push(fn);
        return id;
    } else if (obj.attachEvent) {
        var r = obj.attachEvent("on" + type, fn);
        var id = Lib.Utils.EventUtils.EVENTS.length;
        Lib.Utils.EventUtils.EVENTS.push(fn);
        return id;
    } else {
        return -1;
    }
}

/**
* created by: Nate Minshew
* date created: 09/06/2005
* access level: public
* description: Removes an event from the specified object.
*
* obj - Object the event is to be removed from.
* type - Type of event to remove, ei. 'click' for 'onclick'.
* id - integer representing the event to remove.
*/
Lib.Utils.EventUtils.removeEvent = function(obj, type, id) {
    var fn = Lib.Utils.EventUtils.EVENTS[id];
    if (obj.removeEventListener) {
        obj.removeEventListener(type, fn, false);
        return true;
    } else if (obj.detachEvent) {
        var r = obj.detachEvent("on" + type, fn);
        return r;
    } else {
        return false;
    }
}

/**
* created by: Nate Minshew
* date created: 03/30/2006
* access level: public
* description:
*   This method cancels the default action taken by the specified event.
*
* @param event - Event containing the action to cancel.
*/
Lib.Utils.EventUtils.cancelDefaultAction = function(event) {
    if (Lib.Utils.ObjectUtils.isDefined(event) && Lib.Utils.ObjectUtils.isDefined(event.preventDefault)) {
        event.preventDefault();
    } else if (Lib.Utils.ObjectUtils.isDefined(event)) {
        event.returnValue = false;
    }
}

/**
* created by: Nate Minshew
* date created: 03/30/2006
* access level: public
* description:
*   This method cancels event bubbling for the specified event.  This means that any other actions tied to the event at
*   a higher level will be canceled.
*
* @param event - Event object to cancel bubbling on.
*/
Lib.Utils.EventUtils.cancelEventBubbling = function(event) {
    if (Lib.Utils.ObjectUtils.isDefined(event) && Lib.Utils.ObjectUtils.isDefined(event.stopPropagation)) {
        event.stopPropagation();
    } else if (Lib.Utils.ObjectUtils.isDefined(event)) {
        event.cancelBubble = true;
    }
}

//end Lib.Utils.EventUtils

//start Lib.Utils.StringUtils.js
/**
* author: Nate Minshew
* date created: 11/22/2006
* description:
*   This object is a utility object for performing actions on strings.
*/
Lib.Utils.StringUtils = {}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method trims the specified string of leading and ending whitespace.
*
* @param value - String representing the value to trim.
* @return String representing the trimmed value.
*/
Lib.Utils.StringUtils.trim = function(value) {
  var leftTrimExp = /\s*((\S+\s*)*)/;
  var rightTrimExp = /((\s*\S+)*)\s*/;
  return value.replace(leftTrimExp, "$1").replace(rightTrimExp, "$1");
}
//end Lib.Utils.StringUtils.js

//start Lib.Utils.XML.XMLUtils.js
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("Lib.Utils.ObjectUtils");
JSAN.use("Lib.Utils.StringUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils.XML");


/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description: This is a static javascript class for defining XML/DOM utility functions.
*/
Lib.Utils.XML.XMLUtils = {};

/**
* author: James Estes
* date created: 10/06/2005
* access level: public
* description:
*   This method inserts the specified element before the referenced element.
*
* element = DOM Element representing the element you wish to insert.
* reference = DOM Element representing the next sibling element in the document.
*/
Lib.Utils.XML.XMLUtils.insertBefore = function(element, reference) {
    if(reference.insertAdjacentElement) {
        reference.insertAdjacentElement('beforeBegin', element);
    } else {
        reference.parentNode.insertBefore(element, reference);
    }
}

/**
* author: James Estes
* date created: 11/05/2005
* access level: public
* description:
*   This method inserts the specified element after the referenced element.
*
* element - DOM Element representing the element to add.
* reference - DOM Element representing the element to insert after.
*/
Lib.Utils.XML.XMLUtils.insertAfter = function(element, reference) {
    if (reference.insertAdjacentElement ) {
        reference.insertAdjacentElement('afterEnd', element);
    } else if (reference.nextSibling) {
        reference.parentNode.insertBefore(element, reference.nextSibling);
    } else {
        reference.parentNode.appendChild(element);
    }
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   This method returns the first child element in the specified element.
*
* element - DOM Element representing the parent element.
*/
Lib.Utils.XML.XMLUtils.getFirstElementNode = function(element) {
    var children = element.childNodes;
    for(var i = 0; i < children.length; i++) {
        if(children[i].nodeType == 1) {
            return children[i];
        }
    }
    return null;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This method returns the next sibling to the specified element.
*
* origin - Origin element.
*/
Lib.Utils.XML.XMLUtils.getNextSibling = function(origin) {
	while (origin.nextSibling.nodeType != 1) {
		origin = origin.nextSibling;
	}

	return origin.nextSibling;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method retrieves the previous sibling to the specified element.
*
* @param origin - Origin element.
*/
Lib.Utils.XML.XMLUtils.getPrevSibling = function(origin) {
    while (origin.previousSibling.nodeType != 1) {
        origin = origin.previousSibling;
    }

    return origin.previousSibling;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/25/2005
* access level: public
* description:
*   This method removes all child nodes of the given element.
*
* element - Element to clear.
*/
Lib.Utils.XML.XMLUtils.removeAllChildren = function(element) {
    while (element.childNodes.length && element.childNodes.length > 0) {
        element.removeChild(element.lastChild);
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/18/2006
* access level: public
* description:
*   This method returns whether the specified element contains child nodes.
*
* @param element - Element to check.
*/
Lib.Utils.XML.XMLUtils.hasChildren = function(element) {
    if (typeof element != 'undefined'
            && element != null
            && typeof element.childNodes != 'undefined'
            && element.childNodes.length > 0) {
        return true;
    }

    return false;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/18/2006
* access level: public
* description:
*   This method returns the value of the specified element.  It returns an empty string if the element has no value.
*
* @param element - Representing the element to retrieve the value from.
*/
Lib.Utils.XML.XMLUtils.getElementValue = function(element) {
    var value = '';
    if (this.hasChildren(element)) {
        for (var i = 0; i < element.childNodes.length; i++) {
            if (element.childNodes[i].nodeType == 3) {
                value = value + element.childNodes[i].nodeValue;
            }
        }
    }
    return value;
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method is used to convert and xml node into a string representation of the xml.
*
* @param node - Representing the xml node.
* @return String - String representation of the node.
*/
Lib.Utils.XML.XMLUtils.convertXmlToString = function(node) {
  if (Lib.Utils.ObjectUtils.isDefined(node.xml)) {
    return Lib.Utils.StringUtils.trim(node.xml);
  }
  var serializer = new XMLSerializer();
  return serializer.serializeToString(node);
}
//end Lib.Utils.XML.XMLUtils.js

//start WST.View.FooterView.js
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is a view object for the footer.  It handles interacting with the html document and setting up any
*   events.
*
* @param footerElement - Root html element of the footer.
* @param dateUtils - Date utility object.
*/
WST.View.FooterView = function(footerElement, dateUtils) {
    this._footerElement = footerElement;
    this._dateUtils = dateUtils;
    this._setCurrentDate();
    this._setLastModifiedDate();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the current date on the page.
*/
WST.View.FooterView.prototype._setCurrentDate = function() {
    var currentDateElement = cssQuery('#currentDateValue', this._footerElement)[0];
    if (currentDateElement.childNodes.length > 0) {
        currentDateElement.firstChild.nodeValue = this._dateUtils.getFormattedDate(new Date());
    } else {
        currentDateElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDate(new Date())));
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the last modified date on the page.
*/
WST.View.FooterView.prototype._setLastModifiedDate = function() {
    var lastModifiedElement = cssQuery('#lastModifiedDateValue', this._footerElement)[0];
    if (lastModifiedElement.childNodes.length > 0) {
        lastModifiedElement.firstChild.nodeValue = this._dateUtils.getFormattedDateTime(new Date(document.lastModified));
    } else {
        lastModifiedElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDateTime(new Date(document.lastModified))));
    }
}
//end WST.View.FooterView.js

//start WST.Utils.DateUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Utils");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is used to perform date functions.
*/
WST.Utils.DateUtils = function() {
}

// Array of formatted month names.
WST.Utils.DateUtils.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];
// Array of formatted weekday names.
WST.Utils.DateUtils.WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method formats the specified date object as a date string.
*
* @param date - Date object representing the date.
* @return string - Representing the date.
*/
WST.Utils.DateUtils.prototype.getFormattedDate = function(date) {
    var weekday = WST.Utils.DateUtils.WEEK_DAYS[date.getDay()];
    var month = WST.Utils.DateUtils.MONTHS[date.getMonth()];
    var year = date.getFullYear();
    var day = date.getDate();
    return weekday + ", " + month + " " + day + ", " + year;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the specified date object as a date/time string.
*
* @param date - Date object representing the date.
* @return string - Representing the date and time.
*/
WST.Utils.DateUtils.prototype.getFormattedDateTime = function(date) {
    var dateString = this.getFormattedDate(date);
    var hours = this.getFormattedHours(date);
    var minutes = this.getFormattedMinutes(date);
    var ampm = this.getAMPM(date);
    return dateString + ", " + hours + ":" + minutes + " " + ampm;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the minutes of the specified date object formatted as a 2 digit string.
*
* @param date - Date object representing the date.
* @return string - Representing the formatted minutes.
*/
WST.Utils.DateUtils.prototype.getFormattedMinutes = function(date) {
    if (date.getMinutes() < 10) {
        return "0" + date.getMinutes();
    }
    return date.getMinutes();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns am or pm based on the specified date object.
*
* @param date - Date object representing the date and time.
* @return string - Representing whether it is am or pm.
*/
WST.Utils.DateUtils.prototype.getAMPM = function(date) {
    if (date.getHours() >= 12) {
        return "pm";
    }
    return "am";
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the hour for the specified date based on the 12 hour clock.
*
* @param date - Date object representing the date and time.
* @return string - Representing the hour.
*/
WST.Utils.DateUtils.prototype.getFormattedHours = function(date) {
    if (date.getHours() > 12) {
        return date.getHours() - 12;
    }
    return date.getHours();
}

WST.Utils.DateUtils.prototype.getFormattedDateRange = function(startDate, startTime, endDate, endTime) {
    var formattedDate = this.getFormattedSummarizedDate(startDate);
    if (Lib.Utils.ObjectUtils.isDefined(startTime)) {
        formattedDate = formattedDate + " " + startTime;
    }
    formattedDate = formattedDate + " - ";
    if (Lib.Utils.ObjectUtils.isDefined(endDate)) {
        formattedDate = formattedDate + this.getFormattedSummarizedDate(endDate);
        if (Lib.Utils.ObjectUtils.isDefined(endTime)) {
            formattedDate = formattedDate + " " + endTime;
        }
    } else {
        formattedDate = formattedDate + "No End Date";
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedDateAndTime = function(date, time) {
    var formattedDate = this.getFormattedSummarizedDate(date);
    if (Lib.Utils.ObjectUtils.isDefined(time)) {
        formattedDate = formattedDate + " " + time;
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedSummarizedDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
//end WST.Utils.DateUtils.js

//start WST.View.FormView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object adds global functionality across all forms on the site.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView = function(xmlUtils, objectUtils) {
    this._appendSpecialTextToRequiredFormLabels(xmlUtils, objectUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method prepends all required field labels with a special character.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView.prototype._appendSpecialTextToRequiredFormLabels = function(xmlUtils, objectUtils) {
    var requiredLabels = cssQuery('.required');
    for (var i = 0; i < requiredLabels.length; i++) {
        var spanElement = document.createElement('span');
        spanElement.className = 'requiredIndicator';
        spanElement.appendChild(document.createTextNode('*'));

        var newNode = requiredLabels[i].cloneNode();
        var childNodes = requiredLabels[i].childNodes;
        newNode.appendChild(spanElement);
        for (var j = 0; j < childNodes.length; j++) {
            newNode.appendChild(childNodes[j]);
        }
        var parent = requiredLabels[i].parentNode;
        parent.replaceChild(newNode, requiredLabels[i]);
    }
}
//end WST.View.FormView.js

//start TTSMain().js

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', createTTSMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method instantiates the TTSMain object.
*/
function createTTSMain() {
  //var logger = new TTSLog4javascriptLogger();
  new TTSMain();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method clears the cached context objects.
*/
function clearCtx() {
    Lib.Utils.ObjectUtils.clearContextObjects();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is the main object for the TTS application.  It handles wiring up all global events.
*/
TTSMain = function() {
    var dateUtils = this._createDateUtils();
    var formView = this._createFormView();
    var footerView = this._createFooterView(dateUtils);
//    logger.debug("TTSMain - dateUtils, formView and footerView complete");
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates a date utils object.
*/
TTSMain.prototype._createDateUtils = function() {
    return new WST.Utils.DateUtils();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates the footer view object.
*/
TTSMain.prototype._createFooterView = function(dateUtils) {
    var footerElement = document.getElementById('footer');
    return new WST.View.FooterView(footerElement, dateUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates the form view object.
*/
TTSMain.prototype._createFormView = function() {
    return new WST.View.FormView(Lib.Utils.XML.XMLUtils, Lib.Utils.ObjectUtils);
}

//end TTSMain();

//start scheduledTours.jspx

//start Lib.Utils.XML.AjaxUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("Lib.Utils.ObjectUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils.XML");

/**
* author: NJMINSH (Nate Minshew)
* date created: 05/26/2005
* last updated: 10/06/2005
* description:
*   This is a javascript object for componentizing AJAX functionality.
*/
Lib.Utils.XML.AjaxUtils = {};

Lib.Utils.XML.AjaxUtils.successStatus = 200;
Lib.Utils.XML.AjaxUtils.errorStatus = 12029;
Lib.Utils.XML.AjaxUtils.sendingState = 1;
Lib.Utils.XML.AjaxUtils.waitingState = 3;
Lib.Utils.XML.AjaxUtils.completeState = 4;

/**
* created by: NJMINSH (Nate Minshew)
* date created: 05/26/2005
* access level: public
* description:
*   This function makes an AJAX request to the specified url and defines the function that will process the
*   response.
*
*   updated: 08/30/2005 - Changed name to requestAsynchronousFeed and added new method for synchronous feeds.
*   updated: 10/06/2005 - Now implementing JSAN and using namespaces.
*
* url - String representing the url of the service.
* functionObject - Object representing the callback method used for processing the result.
*/
Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed = function(url, getGuides, currentDate, calendar, tourListObject, callback, parentClass, functionObject) {
    var request;
  if (window.XMLHttpRequest) {
      // This is how we setup XMLHttpRequest for none IE browsers.
      request = new XMLHttpRequest();
      request.onreadystatechange = function() {
              if(request.readyState == 4){
                functionObject(request, getGuides, currentDate, calendar, tourListObject, parentClass, callback);
            }
       }
        request.open("GET", url, true);
        request.send(null);
    } else if (window.ActiveXObject) {
        // This is how we setup XMLHttpRequest for IE.
        request = new ActiveXObject("Microsoft.XMLHTTP");
      request.onreadystatechange = function() {
              if(request.readyState == 4){
                functionObject(request, getGuides, currentDate, calendar, tourListObject, parentClass, callback);
            }
       }

      request.open("GET", url, true);
      request.setRequestHeader( "If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT" );
      request.send();
    }

    return request;
}

/**
* created by: Nate Minshew
* date created: 08/30/2005
* access level: public
* description:
*   This function makes a synchronous request to the specified url and returns the response.
*
* url - String representing the url of the service.
* returnText - Representing whether the response should be returned as text or xml
*/
Lib.Utils.XML.AjaxUtils.requestSynchronousFeed = function(url, returnText) {
    var request;
    if (window.XMLHttpRequest) {
        // This is how we setup XMLHttpRequest for none IE browsers.
        request = new XMLHttpRequest();
        try {
          request.open("GET", url, false);
          request.send(null);
        } catch(ex) {
        }
    } else if (window.ActiveXObject) {
        // This is how we setup XMLHttpRequest for IE.
        request = new ActiveXObject("Microsoft.XMLHTTP");
        request.open("GET", url, false);
        request.setRequestHeader( "If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT" );
        request.send();
    }
    if (returnText) {
        return this.getResponseText(request);
    }
    return this.getResponse(request);
}

/**
* created by: Nate Minshew
* date created: 04/11/2006
* access level: public
* description:
*   This function loads and XML file from a URL.  This is typically used for loading XML from a static source like the
*   filesystem.
*
* @param url - String representing the url to the XML file.
* @return Javascript DOM representing the XML.
*/
Lib.Utils.XML.AjaxUtils.loadXML = function(url) {
    var xmlDoc;
    if (typeof ActiveXObject != 'undefined' &&
            typeof new ActiveXObject("Microsoft.XMLDOM") != 'undefined') {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.load(url);
    } else if (typeof document.implementation.createDocument != 'undefined') {
        var xmlText = this.requestSynchronousFeed(url, true);
        if (Lib.Utils.ObjectUtils.isDefined(xmlText)) {
          var parser = new DOMParser();
          xmlDoc = parser.parseFromString(xmlText, "text/xml");
        }
    }
    return xmlDoc;
}

/**
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 * access level: public
 * description:
 *   This function returns the xml response from the AJAX request and null if there wasn't a response or
 *   there was an error returned.
 *
 * request - Object representing the request to the service.
 */
Lib.Utils.XML.AjaxUtils.getResponse = function(request) {
    if (request) {
        if (request.readyState == 4) {
            if (request.status == 200) {
                if (request.responseXML) {
                    return request.responseXML;
                }
            }
        }
    }

    return null;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/7/2005
* access level: public
* description:
*   This function returns the current status of the AJAX request.
*/
Lib.Utils.XML.AjaxUtils.getStatus = function(request) {
    if (request) {
        if (request.readyState == 4) {
            return request.status;
        }
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/7/2005
* access level: public
* description:
*   This function returns the current state of the AJAX request.
*/
Lib.Utils.XML.AjaxUtils.getState = function(request) {
    if (request) {
        return request.readyState;
    }
}

/**
* created by: Nate Minshew
* date created: 08/30/2005
* access level: public
* description:
*   This function returns the full response returned from the server.
*
* request - Object representing the request to the service.
*/
Lib.Utils.XML.AjaxUtils.getResponseText = function(request) {
    if (request) {
        if (request.readyState == 4 && (request.status == 200 || request.status == 0)) {
            return request.responseText;
        }
    }
}

/**
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 * access level: public
 * description:
 *   This function returns whether AJAX is supported in the current browser.  It returns false if
 *   getElementById is not defined, meaning that DHTML is not supported.
 */
Lib.Utils.XML.AjaxUtils.isAjaxSupported = function() {
    // If we can't access elements in the page using document.getElementById
    // then the Ajax stuff isn't very useful to us.
    if (!document.getElementById) {
        return false;
    }

    if (window.XMLHttpRequest || (window.ActiveXObject
            && new ActiveXObject("Microsoft.XMLHTTP"))) {
        return true;
    }

    return false;
}
//end Lib.Utils.XML.AjaxUtils.js

//start Lib.Utils.DateUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a utility object for performing date functions.
*/
Lib.Utils.DateUtils = {};

// Array of formatted month names.
Lib.Utils.DateUtils.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the days in the specified month and year.
*/
Lib.Utils.DateUtils.getDaysInMonth = function(month, year) {
    var date = new Date(year, month + 1, 0);
    return date.getDate();
}
//end Lib.Utils.DateUtils.js

//start Lib.Utils.DocumentUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* description:
*   This object is a utility object for performing actions on the document.
*/
Lib.Utils.DocumentUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* access level: public
* description:
*   This method adds the specified class name to the specified element.
*
* element - Element on the page.
* className - Name of the class to add to the element.
*/
Lib.Utils.DocumentUtils.addClass = function(element, className) {
    if (!this.containsClass(element, className)) {
        if (element) {
            if (element.className.length > 0) {
                element.className = element.className + ' ' + className;
            } else {
                element.className = className;
            }
        }
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* access level: public
* description:
*   This method removes the specified class name for the specified element.
*
* element - Element on the page.
* className - Name of the class to remove from the element.
*/
Lib.Utils.DocumentUtils.removeClass = function(element, className) {
    if (this.containsClass(element, className)) {
        if (element && element.className.indexOf(className) > -1) {
            var pre = element.className.substring(0, element.className.indexOf(className) - 1);
            var post = element.className.substring(element.className.indexOf(className) + className.length + 1);
            element.className = pre + ' ' + post;
        }
    }
}

/**
* author: Ken Johnson (KJJOHN2)
* date created: 12/18/2007
* access level: public
* description:
*   This method removes all classes for the specified element.  This is to address a bug where some classes are being
*   left on an element because the name isn't known
*
* element - Element on the page.
*/
Lib.Utils.DocumentUtils.removeClasses = function(element) {
  element.className = '';
}

/**
* author: Nate Minshew
* date created: 03/08/2006
* access level: public
* description:
*   This method returns whether the specified element contains the specified css class.
*
* @param element - Page Element to check.
* @param className - String representing the css class to check for.
* @return boolean - Representing if the element contains the class.
*/
Lib.Utils.DocumentUtils.containsClass = function(element, className) {
    return element.className.indexOf(className) > -1;
}

Lib.Utils.DocumentUtils.copyHTMLElement = function(targetElement) {
    var container = document.createElement('div');
    container.innerHTML = targetElement.outerHTML;
    return container.firstChild;
}
//end Lib.Utils.DocumentUtils.js

//start Lib.View.Templates.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.XMLUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.View");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to defined external dhtml templates to be provided to widgets.  You just define an html page
*   with your widget embedded in the templates id with any added classes or ids and then provide the url to this object.
*   It will read in the template and and provide it to your widget as html.
*
* @param ajaxUtils - Ajax utility object.
* @param url - URL of the template.
* @param templateId - Id of the template.
* @param objectUtils - Object utility object.
*/
Lib.View.Templates = function(ajaxUtils, url, objectUtils) {
    this._templatesXML = this._parseTemplateXML(ajaxUtils, url, objectUtils);
    this._templatesElement = this._convertXMLToHTML(this._templatesXML, objectUtils);
    this._objectUtils = objectUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the root element of your template as an HTML element.
*/
Lib.View.Templates.prototype.getRootElement = function(templateId) {
    var template = cssQuery('#' + templateId, this._templatesElement);
    if (template.length > 0) {
        for(var i = 0; i < template[0].childNodes.length; i++) {
            if (template[0].childNodes[i].nodeType == 1) {
                return template[0].childNodes[i];
            }
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method will append this template to the specified HTML element.
*
* @param element - HTML element to append template to.
*/
Lib.View.Templates.prototype.attachTemplateToPage = function(element, templateId) {
    if (!this._objectUtils.isDefined(element)) {
        element = document.getElementsByTagName('body')[0];
    }
    element.appendChild(this.getRootElement(templateId));
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method retrieves the template from the specified url and returns it as XML.
*
* @param ajaxUtils - Ajax utility object.
* @param url - URL of the template.
* @param templateId - Id of the template.
* @param objectUtils - Object utility object.
*/
Lib.View.Templates.prototype._parseTemplateXML = function(ajaxUtils, url, objectUtils) {
    var resultXML;
    try {
        resultXML = ajaxUtils.loadXML(url);
    } catch(ex) {
        throw new Error("The template at '" + url + "' was not found or is invalid.");
    }
    if (resultXML == null
            || resultXML.getElementsByTagName('div').length == 0
            || resultXML.getElementsByTagName('div')[0].getAttribute('id') != 'templates') {
        throw new Error("The template at '" + url + "' was not found or is invalid.");
    }

    return resultXML.getElementsByTagName('div')[0];
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method converts the XML returned from the url into HTML.
*
* @param xmlDoc - XML document.
* @param objectUtils - Object utility object.
* @param templateId - Id of the template.
*/
Lib.View.Templates.prototype._convertXMLToHTML = function(xmlDoc, objectUtils) {
    var container = document.createElement('div');
    container.innerHTML = Lib.Utils.XML.XMLUtils.convertXmlToString(xmlDoc);
    return cssQuery('#templates', container)[0];
}

//end Lib.View.Templates.js

//start   Lib.DHTML.Event.CalendarIncrementMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that increment the month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, incrementing the month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.incrementMonth();
}
//end Lib.DHTML.Event.CalendarIncrementMonthEvent

//start   Lib.DHTML.Event.CalendarCurrentMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Sonal Patidar
* date created: 10/1/2007
* @constructor
* description:
*   This object is used to handle events that refreshes the calendar with the curernt month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method executes this event, refreshing the calendar with current month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.currentMonth();
}
//end Lib.DHTML.Event.CalendarCurrentMonthEvent

//start   Lib.DHTML.Event.CalendarDecrementMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that decrement the month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, decrementing the month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.decrementMonth();
}
//end Lib.DHTML.Event.CalendarDecrementMonthEvent

//start   Lib.DHTML.Event.CalendarSelectDateEvent.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that select a date on the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarSelectDateEvent = function(dateLinkElement, calendar, eventUtils, documentUtils) {
    this._dateLinkElement = dateLinkElement;
    this._calendar = calendar;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarSelectDateEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, selected the date representing by the dateLinkElement field and notifying the
*   calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarSelectDateEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    var date = this._dateLinkElement.firstChild.nodeValue;
    if (!this._calendar.isDateDisabled(date)) {
        this._calendar.notifyDateSelected(date, this._dateLinkElement);
    }
}
//end Lib.DHTML.Event.CalendarSelectDateEvent.js

//start Lib.DHTML.Calendar.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.DHTML.Event.CalendarIncrementMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarCurrentMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarDecrementMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarSelectDateEvent');
JSAN.use('Lib.Utils.DateUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a dhtml calendar object for creating a functional calendar on an html page.  It provides all
*   functionality typically associated with a dhtml calendar.  The ability to change months and select dates.
*
* @param template - Object representing the template to use for the html and css.
* @param dateUtils - Object representing a date utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
* @param blackoutDates - Array of days that should be blacked out.
* @param otherDates - Array of DateStyleConfiguration that should be shaded out.
* @param selectedDate - selected date to be shaded.
*/
Lib.DHTML.Calendar = function(template, dateUtils, documentUtils, eventUtils, xmlUtils, objectUtils, currentDate, currentMonthIsALink) {
    this._template = template;
    this._templateElement = template;
    this._date = currentDate;
    this._currentMonthIsALink = currentMonthIsALink;
    var todaysDate = new Date();
    this._currentDate = todaysDate.getDate();
    this._currentMonth = todaysDate.getMonth();
    this._currentYear = todaysDate.getFullYear();
    this._selectedDate;
    this._selectedYear;
    this._selectedMonth;
    this._dateUtils = dateUtils;
    this._documentUtils = documentUtils;
    this._xmlUtils = xmlUtils;
    this._eventUtils = eventUtils;
    this._objectUtils = objectUtils;
    this._dateListeners = new Array();
    this._dateInitListeners = new Array();
    this._disabledDates = new Array();
    this._monthChangeListeners = new Array();
    this._initialize();
    this._attachHeaderEvents();
}

// Array of formatted month names.
Lib.DHTML.Calendar.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];
// Array of formatted weekday names.
Lib.DHTML.Calendar.WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];

Lib.DHTML.Calendar.prototype.refresh = function() {
    this._initialize();
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method sets the location href use for decrementing or incrementing month
*/
Lib.DHTML.Calendar.prototype.setLocationHref = function(locationHref) {
  this._locationHref = locationHref;
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method increments the month on this calendar object.  If the last month, the year will be incremented and the
*   month will start over from the beginning.
*/
Lib.DHTML.Calendar.prototype.currentMonth = function() {
  if (this._locationHref != null){
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method increments the month on this calendar object.  If the last month, the year will be incremented and the
*   month will start over from the beginning.
*/
Lib.DHTML.Calendar.prototype.incrementMonth = function() {
  if (this._locationHref == null) {
      this._date.setMonth(this._date.getMonth() + 1);
      this._notifyMonthChangeListeners(this._date.getMonth(), this._date.getYear());
      this._initialize();
  } else {
      this._date.setMonth(this._date.getMonth() + 1);
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method decrements the month on this calendar object.  If the first month, the year will be decremented and the
*   month will go to december.
*/
Lib.DHTML.Calendar.prototype.decrementMonth = function() {
    if (this._locationHref == null) {
      this._date.setMonth(this._date.getMonth() - 1);
      this._notifyMonthChangeListeners(this._date.getMonth(), this._date.getYear());
      this._initialize();
  } else {
      this._date.setMonth(this._date.getMonth() - 1);
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the root element of the HTML calendar.
*/
Lib.DHTML.Calendar.prototype.getCalendar = function() {
    return this._templateElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method registers the specified date listener for notification when a date is selected.
*
* @param listener - Object/function to call when a date is selected.
*/
Lib.DHTML.Calendar.prototype.registerDateEventListener = function(listener) {
    this._dateListeners.push(listener);
}

Lib.DHTML.Calendar.prototype.registerDateInitListener = function(listener) {
    this._dateInitListeners.push(listener);
    this._initialize();
}

Lib.DHTML.Calendar.prototype.registerMonthChangeListener = function(listener) {
    this._monthChangeListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method notifies all date listeners that a new date has been selected.
*
* @param date - Date object representing the new date.
* @param dateLinkElement - Element representing the date.
*/
Lib.DHTML.Calendar.prototype.notifyDateSelected = function(date, dateLinkElement) {
    this._date.setDate(date);
    this._selectDate(dateLinkElement);
    for (var i = 0; i < this._dateListeners.length; i++) {
        this._dateListeners[i](this._date);
    }
}

/**
* author: Nate Minshew
* date created: 08/01/2006
* access level: public
* description:
*   This method changes the calendar to the specified date.
*
* @param date - Date object representing the new date.
*/
Lib.DHTML.Calendar.prototype.setDate = function(date) {
    this._date = date;
    this._selectedDate = date.getDate();
    this._selectedMonth = date.getMonth();
    this._selectedYear = date.getFullYear();
    this._clearSelectedDate();
    this._initialize();
}

Lib.DHTML.Calendar.prototype.disableDate = function(date) {
    this._disabledDates.push(date);
}

Lib.DHTML.Calendar.prototype.isDateDisabled = function(dateNumber) {
    for (var i = 0; i < this._disabledDates.length; i++) {
        if (dateNumber == this._disabledDates[i].getDate()
                && this._date.getFullYear() == this._disabledDates[i].getFullYear()
                && this._date.getMonth() == this._disabledDates[i].getMonth()) {
            return true;
        }
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method initializes the calendar, creating the html relative to the current selected date.
*/
Lib.DHTML.Calendar.prototype._initialize = function() {
    this._setMonth(this._date.getMonth(), this._templateElement);
    this._setYear(this._date.getFullYear(), this._templateElement);
    this._updateCalendarDays(this._templateElement);
    this._attachDateEvents();
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the month header to the specified month.
*
* @param month - Index of the new month.
*/
Lib.DHTML.Calendar.prototype._setMonth = function(month) {
    var monthNameElement = cssQuery('span#monthName', this._templateElement)[0];
    if (this._objectUtils.isDefined(monthNameElement)) {
        if(this._currentMonthIsALink != null){
          this._documentUtils.addClass(monthNameElement, 'underline');
      }
    }
    monthNameElement.firstChild.nodeValue = Lib.Utils.DateUtils.MONTHS[month];
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the year header to the specified year.
*
* @param year - Representing the new year.
*/
Lib.DHTML.Calendar.prototype._setYear = function(year) {
    var yearElement = cssQuery('span#year', this._templateElement)[0];
    yearElement.firstChild.nodeValue = year;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method updates the days on the calendar.
*/
Lib.DHTML.Calendar.prototype._updateCalendarDays = function() {
    this._date.setDate(1);
    var firstDayOfMonth = Lib.DHTML.Calendar.WEEK_DAYS[this._date.getDay()];
    var dayHeaderElement = cssQuery('th#' + firstDayOfMonth, this._templateElement)[0];
    var dateIndex = this._findElementIndex(dayHeaderElement);
    this._clearAllDates();
    this._setDates(dateIndex);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method finds the index of the specified element according to it's parent.
*
* @param element - HTML element's index to retrieve.
*/
Lib.DHTML.Calendar.prototype._findElementIndex = function(element) {
    var parent = element.parentNode;
    var index = -1;
    for (var i = 0; i < parent.childNodes.length; i++) {
        if (parent.childNodes[i].nodeType == 1) {
            index++;
            if (parent.childNodes[i] == element) {
                return index;
            }
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method clears all current calendar dates.
*/
Lib.DHTML.Calendar.prototype._clearAllDates = function() {
    var dateElements = this._templateElement.getElementsByTagName('td');
    this._clearSelectedDate();
    for (var i = 0; i < dateElements.length; i++) {
        this._xmlUtils.removeAllChildren(dateElements[i]);
        dateElements[i].innerHTML = '&nbsp;';
        this._documentUtils.removeClass(dateElements[i], 'currentDate');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method clears the selected date.
*/
Lib.DHTML.Calendar.prototype._clearSelectedDate = function() {
    var dateElement = cssQuery('.selectedDate', this._templateElement)[0];
    if (this._objectUtils.isDefined(dateElement)) {
        this._documentUtils.removeClass(dateElement, 'selectedDate');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets all the dates on the calendar based on the specified starting index.
*
* @param startingIndex - Index of the first calendar date field.
*/
Lib.DHTML.Calendar.prototype._setDates = function(startingIndex) {
    var dateElements = this._templateElement.getElementsByTagName('td');
    var dateNumber = 1;
    var daysInMonth = this._dateUtils.getDaysInMonth(this._date.getMonth(), this._date.getFullYear());
    for (var i = startingIndex; i < daysInMonth + startingIndex; i++) {
    	this._xmlUtils.removeAllChildren(dateElements[i]);
        this._createDate(dateElements[i], dateNumber);
        this._notifyDateInitListeners(new Date(this._date.getFullYear(), this._date.getMonth(), dateNumber), dateElements[i])
        if (this._isCurrentDate(dateNumber)) {
            this._documentUtils.addClass(dateElements[i], 'currentDate');
        }
        if (this._isSelectedDate(dateNumber)) {
            this._documentUtils.addClass(dateElements[i], 'selectedDate');
        }
        dateNumber++;
    }
}

Lib.DHTML.Calendar.prototype._notifyDateInitListeners = function(date, dateElement) {
    for (var i = 0; i < this._dateInitListeners.length; i++) {
        this._dateInitListeners[i](date, dateElement);
    }
}

Lib.DHTML.Calendar.prototype._notifyMonthChangeListeners = function(month, year) {
    for (var i = 0; i < this._monthChangeListeners.length; i++) {
        this._monthChangeListeners[i](month, year);
    }
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns whether the specified date (number) is today's date.
*
* @param dateNumber - Representing the date.
*/
Lib.DHTML.Calendar.prototype._isCurrentDate = function(dateNumber) {
    if (dateNumber == this._currentDate
            && this._date.getMonth() == this._currentMonth
            && this._date.getFullYear() == this._currentYear) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns whether the specified date (number) is the selected date.
*
* @param dateNumber - Representing the date.
*/
Lib.DHTML.Calendar.prototype._isSelectedDate = function(dateNumber) {
    if (dateNumber == this._selectedDate
            && this._date.getMonth() == this._selectedMonth
            && this._date.getFullYear() == this._selectedYear) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates a date field in the specified date element with the specified date value.
*
* @param dateElement - HTML element to create the date in.
* @param dateValue - Value to set the date to.
*/
Lib.DHTML.Calendar.prototype._createDate = function(dateElement, dateValue) {
    var linkElement = document.createElement('a');
    linkElement.href = '#';
    linkElement.className = 'dateLink';
    linkElement.appendChild(document.createTextNode(dateValue));
    dateElement.appendChild(linkElement);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method attaches the navigation events to the header.
*/
Lib.DHTML.Calendar.prototype._attachHeaderEvents = function() {
    var nextMonthLink = cssQuery('a#nextMonthLink', this._templateElement)[0];
    var event = new Lib.DHTML.Event.CalendarIncrementMonthEvent(this, this._eventUtils);
    event.attachEvent(nextMonthLink, 'click');

    var monthYearLink = cssQuery('a#monthYearLink', this._templateElement)[0];
    event = new Lib.DHTML.Event.CalendarCurrentMonthEvent(this, this._eventUtils);
    event.attachEvent(monthYearLink, 'click');

    var prevMonthLink = cssQuery('a#prevMonthLink', this._templateElement)[0];
    event = new Lib.DHTML.Event.CalendarDecrementMonthEvent(this, this._eventUtils);
    event.attachEvent(prevMonthLink, 'click');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches the date events.
*/
Lib.DHTML.Calendar.prototype._attachDateEvents = function() {
    var dateLinks = cssQuery('a.dateLink', this._templateElement);
    for (var i = 0; i < dateLinks.length; i++) {
        var event = new Lib.DHTML.Event.CalendarSelectDateEvent(dateLinks[i], this, this._eventUtils, this._documentUtils);
        event.attachEvent(dateLinks[i], 'click');
    }
}

  /**
  * author: Nate Minshew
  * date created: 07/12/2006
  * access level: private
  * description:
  *   This method selects the specified date link element.
  *
  * @param dateLinkElement - HTML element representing the selected date.
  */
  Lib.DHTML.Calendar.prototype._selectDate = function(dateLinkElement) {
      this._selectedDate = this._date.getDate();
      this._selectedMonth = this._date.getMonth();
      this._selectedYear = this._date.getFullYear();
      this._clearSelectedDate();
      this._documentUtils.addClass(dateLinkElement.parentNode, 'selectedDate');
}
//end Lib.DHTML.Calendar.js

//start Lib.Utils.FormUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description:
*   This is a javascript class for defining common static utility functions that will be used throughout the
*   application.
*/
Lib.Utils.FormUtils = {};

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   Clears the specified select element by creating a single option with an empty value and '-'s for text.
*
* element - DOM Select Element that will be modified.
* defaultValue - Default value of the select element.
* defaultText - Default text of the select element.
*/
Lib.Utils.FormUtils.clearSelectElement = function(element, defaultValue, defaultText) {
    element.innerHTML = "";
    var optionElement = document.createElement('option');
    optionElement.setAttribute('value', defaultValue);
    var textNode = document.createTextNode(defaultText);
    optionElement.appendChild(textNode);
    element.appendChild(optionElement);
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   This method clears the specified text box element.
*
* element - DOM Input Element representing the text box.
* defaultValue - Default value of the field.
*/
Lib.Utils.FormUtils.clearTextBox = function(element, defaultValue) {
    element.value = defaultValue;
}

/**
* author: Nate Minshew
* date created: 03/08/2006
* access level: public
* description:
*   This method creates a new input field with the specified name.
*
* @return Element - Representing the new input field.
*/
Lib.Utils.FormUtils.createInputField = function(name) {
    if (document.all) {
        return document.createElement('<input name="' + name + '">');
    }
    var field = document.createElement('input');
    field.name = name;
    return field;
}

/**
* author: njminsh (Nate Minshew)
* date created: 11/02/2005
* access level: public
* description:
*   This method validates that the value of the specified element is numeric.
*
* element - Element representing the form field to validate.
*/
Lib.Utils.FormUtils.isNumeric = function(element) {
    if (isNaN(element.value)) {
        return false;
    }

    return true;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method returns the current selected value of the specified select box element.
*
* @param element - HTML select box element to retrieve value from.
*/
Lib.Utils.FormUtils.getSelectedValue = function(element) {
    return element.options[element.selectedIndex].value;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method returns the current selected text of the specified select box element.
*
* @param element - HTML select box element to retrieve text from.
*/
Lib.Utils.FormUtils.getSelectedText = function(element) {
    return element.options[element.selectedIndex].text;
}

/**
* author: Nate Minshew
* date created: 07/18/2006
* access level: public
* description:
*   This method returns the index of the specified value of the specified select element.
*
* @param element - HTML select element.
* @param value - Text value of requested option index.
*/
Lib.Utils.FormUtils.getIndexOfValue = function(element, value) {
    for (var i = 0; i < element.options.length; i++) {
        if (element.options[i].value == value) {
            return i;
        }
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* description:
*   This object contains utility functions for checkbox elements.
*/
Lib.Utils.FormUtils.CheckboxUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function clears all selected checkboxes.
*
* element - Checkbox element to clear.
*/
Lib.Utils.FormUtils.CheckboxUtils.clearAllCheckboxes = function(element) {
    if (element.length) {
        for (var i = 0; i < element.length; i++) {
            element[i].checked = false;
        }
    } else {
        element.checked = false;
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: private
* description:
*   This function returns the number of checked checkboxes.
*
* element - Checkbox element to query.
*/
Lib.Utils.FormUtils.CheckboxUtils._getNumChecked = function(element) {
	var counter = 0;
	if (element.length) {
		for (var i = 0; i < element.length; i++) {
			if (element[i].checked) {
				counter++;
			}
		}
	} else if (element && element.checked) {
		counter ++;
	}

	return counter;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function returns whether the number of checkboxes checked is less than or equal to the max.
*
* element - The checkbox element.
* max - The maximum number of checks.
*/
Lib.Utils.FormUtils.CheckboxUtils.isNumCheckedLTEQMax = function(element, max) {
    var counter = this._getNumChecked(element);

    if (counter > max) {
        return false;
    }

    return true;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function returns whether the number of checkboxes checked is greater than or equal to the minimum.
*
* element - The checkbox element.
* min - The minimum number of checks.
*/
Lib.Utils.FormUtils.CheckboxUtils.isNumCheckedGTEQMin = function(element, min) {
	var counter = this._getNumChecked(element);

	if (counter < min) {
		return false;
	}

	return true;
}

//end Lib.Utils.FormUtils.js

//start  Lib.View.WindowNavigator.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.View");

Lib.View.WindowNavigator = function(targetWindow) {
    this._targetWindow = targetWindow
}

Lib.View.WindowNavigator.prototype.redirect = function(url) {
    this._targetWindow.location.href = url;
}

//end  Lib.View.WindowNavigator.js

//start   WST.View.Guide.Event.GuideChangeEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.View.WindowNavigator');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Utils.DateUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * @constructor
 * description:
 *   This object is an event object for submitting the form when guide selection changes on scheduled Tours page.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.Guide.Event.GuideChangeEvent = function(eventUtils, baseElement, formUtils) {
    this._eventUtils = eventUtils;
    this._baseElement = baseElement;
    this._formUtils = formUtils;
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method attaches an event of the specified type to the specified element, binding it to this object.
 *
 * @param element - Page element to bind event to.
 * @param type - String representing the type of event, ie. "click"
 */
WST.View.Guide.Event.GuideChangeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method executes the event for this object, submitting the form after re-setting tourdate
 *
 * @param evt - Event object provided by the browser.
 */
WST.View.Guide.Event.GuideChangeEvent.prototype.executeEvent = function(evt) {
//    var tourDate = cssQuery('#tourDate', this._baseElement)[0];
    var tourDate = cssQuery('#currentDate', this._baseElement)[0];
    var guide = cssQuery('#guide', this._baseElement)[0];
    var guideId = this._formUtils.getSelectedValue(guide);
    var navigator = new Lib.View.WindowNavigator(window);
    var redirectUrl;
    if (Lib.Utils.ObjectUtils.isDefined(tourDate)) {
        redirectUrl = 'listTours.htm?method=listToursByCriteria&status=SCHEDULED';
        if (tourDate.value != '') {
            var startDate = new Date(tourDate.value);
            var todaysDate = new Date();
            if(startDate.getMonth().value == todaysDate.getMonth().value){
              startDate = todaysDate;
            }else{
              startDate.setDate(1);
            }
            startDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(startDate);
            var endDate = new Date(tourDate.value);
            endDate.setDate(Lib.Utils.DateUtils.getDaysInMonth(endDate.getMonth(), endDate.getFullYear()));
            endDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(endDate);
            redirectUrl = redirectUrl + '&startDate=' + startDate + '&endDate=' + endDate;
        }
        if (guideId != 'All') {
            redirectUrl = redirectUrl + '&guide=' + guideId;
        }
        navigator.redirect(redirectUrl);
    } else {
        navigator.redirect('changedTours.htm?guide=' + guideId);
    }
}

//end   WST.View.Guide.Event.GuideChangeEvent.js

//start   WST.View.Guide.Event.DateChangeEvent.js

// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.View.WindowNavigator');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Utils.DateUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide.Event");

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * @constructor
 * description:
 *   This object is an event object for submitting the form when guide selection changes on scheduled Tours page.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.Guide.Event.DateChangeEvent = function(eventUtils, baseElement, formUtils) {
    this._eventUtils = eventUtils;
    this._baseElement = baseElement;
    this._formUtils = formUtils;
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method attaches an event of the specified type to the specified element, binding it to this object.
 *
 * @param element - Page element to bind event to.
 * @param type - String representing the type of event, ie. "click"
 */
WST.View.Guide.Event.DateChangeEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
 * author: Nate Minshew
 * date created: 07/31/2006
 * access level: public
 * description:
 *   This method executes the event for this object, submitting the form after re-setting tourdate
 *
 * @param evt - Event object provided by the browser.
 */
WST.View.Guide.Event.DateChangeEvent.prototype.executeEvent = function(evt) {
     var selectedYear = document.getElementById("year");
     var selectedMonth = document.getElementById("month");
     var monthValue = selectedMonth.options[selectedMonth.selectedIndex].value;
     var acutalMonth = parseInt(monthValue)+1;
     var currentDate = acutalMonth + "/01/" + selectedYear.options[selectedYear.selectedIndex].value;
     var tourDate=currentDate;

    var guide = cssQuery('#guide', this._baseElement)[0];
    var guideId = this._formUtils.getSelectedValue(guide);
    var navigator = new Lib.View.WindowNavigator(window);
    var redirectUrl;
    if (Lib.Utils.ObjectUtils.isDefined(tourDate)) {
        redirectUrl = 'listTours.htm?method=listToursByCriteria&status=SCHEDULED';
        if (tourDate.value != '') {
            var startDate = new Date(tourDate);
            var todaysDate = new Date();
            startDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(startDate);
            var endDate = new Date(tourDate);
            endDate.setDate(Lib.Utils.DateUtils.getDaysInMonth(endDate.getMonth(), endDate.getFullYear()));
            endDate = new WST.Utils.DateUtils().getFormattedSummarizedDate(endDate);
            redirectUrl = redirectUrl + '&startDate=' + startDate + '&endDate=' + endDate;
        }
        if (guideId != 'All') {
            redirectUrl = redirectUrl + '&guide=' + guideId;
        }
        navigator.redirect(redirectUrl);
    } else {
        navigator.redirect('changedTours.htm?guide=' + guideId);
    }
}

//end   WST.View.Guide.Event.DateChangeEvent.js

//start  WST.View.Guide.ScheduledToursView.js

// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Guide.Event.GuideChangeEvent');
JSAN.use('WST.View.Guide.Event.DateChangeEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Guide");

/**
* author: Sonal Patidar
* date created: 08/28/2006
* @constructor
* description:
*   This object is a view object for the Scheduled Tours page.  It sents any events on the page and interacts with the
*   HTML.
*/
WST.View.Guide.ScheduledToursView = function(calendar, baseElement, xmlUtils,documentUtils, eventUtils, objectUtils, formUtils) {
//    logger.debug("ScheduledToursView - Enter create ");
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._formUtils = formUtils;
    this._createGuideChangeEvent(eventUtils);
    this._createDateChangeEvent(eventUtils);
    if (calendar != null) {
        calendar.setLocationHref(this._getLocationHref());
        if (objectUtils.isDefined(calendar)) {
            this._attachCalendar(calendar, xmlUtils, eventUtils);
            var reference = objectUtils.weakBind(this.updateDate, this);
            calendar.registerDateEventListener(reference);
        }
    }
//  logger.debug("ScheduledToursView - Exit create ");
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: private
* description:
*   This method creates the location href to be set in calendar. This will be used as location.href when
* incrementing and decrementing months in the calendar.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._getLocationHref = function() {
  var guide = cssQuery('#guide', this._baseElement)[0];
  var guideId = this._formUtils.getSelectedValue(guide);
  return 'listTours.htm?method=listToursByCriteria&guide=' + guideId + '&status=SCHEDULED';
}
/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the add guide event for adding guides to the form and table.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._createGuideChangeEvent = function(eventUtils) {
    var guideSelect = cssQuery('#guide', this._baseElement)[0];
    var event = new WST.View.Guide.Event.GuideChangeEvent(eventUtils, this._baseElement, this._formUtils);
    event.attachEvent(guideSelect,'change');
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the add guide event for adding guides to the form and table.
*
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._createDateChangeEvent = function(eventUtils) {
    var monthSelect = cssQuery('#month', this._baseElement)[0];
    if(monthSelect!=null){
        var event = new WST.View.Guide.Event.DateChangeEvent(eventUtils, this._baseElement, this._formUtils);
        event.attachEvent(monthSelect,'change');
    }
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method attaches the calendar html element to the page and creates the calendar events.
*
* @param calendar - Calendar widget.
* @param eventUtils - Event utility object.
*/
WST.View.Guide.ScheduledToursView.prototype._attachCalendar = function(calendar, xmlUtils,eventUtils) {
    var element = calendar.getCalendar();
    var tourDateLabel = cssQuery('#tourDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    xmlUtils.insertAfter(brElement, tourDateLabel);
    xmlUtils.insertAfter(element, brElement)
    }

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.Guide.ScheduledToursView.prototype.updateDate = function(date) {
    var tourDate = cssQuery('#tourDate', this._baseElement)[0];
    var dateStr = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    tourDate.value = dateStr;
    var guide = cssQuery('#guide', this._baseElement)[0];
    var guideId = this._formUtils.getSelectedValue(guide);
    location.href = 'listTours.htm?method=listToursByCriteria&guide=' + guideId + '&startDate=' + dateStr + '&endDate=' + dateStr + '&status=SCHEDULED';
   // location.href = 'scheduledTours.htm?guide=' + guideId + '&tourDate=' + (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
}

//end  WST.View.Guide.ScheduledToursView.js

//start  WST.TourCalendar.Model.Tour.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Tour = function(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization,
                                       guides, status) {
    this._id = id;
    this._startDate = new Date(startDate);
    this._endDate = new Date(endDate);
    this._startTime = startTime;
    this._endTime = endTime;
    this._location = location;
    this._numGuests = numGuests;
    this._place = place;
    this._organization = organization;
    this._guides = guides;
    this._status = status;
}

WST.TourCalendar.Model.Tour.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Tour.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.Tour.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.Tour.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.Tour.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.Tour.prototype.getLocation = function() {
    return this._location;
}

WST.TourCalendar.Model.Tour.prototype.getNumGuests = function() {
    return this._numGuests;
}

WST.TourCalendar.Model.Tour.prototype.getPlace = function() {
    return this._place;
}

WST.TourCalendar.Model.Tour.prototype.getOrganization = function() {
    return this._organization;
}

WST.TourCalendar.Model.Tour.prototype.getGuides = function() {
    return this._guides;
}

WST.TourCalendar.Model.Tour.prototype.getStatus = function() {
    return this._status;
}

WST.TourCalendar.Model.Tour.prototype.getFormattedDateRange = function() {
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedStartDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedEndDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
}

//end  WST.TourCalendar.Model.Tour.js

//start WST.TourCalendar.Model.Guide.js
 // Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Guide = function(id, name) {
    this._id = id;
    this._name = name;
}

WST.TourCalendar.Model.Guide.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Guide.prototype.getName = function() {
    return this._name;
}
//end WST.TourCalendar.Model.Guide.js

//start  WST.TourCalendar.Model.TourList.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.Tour');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('WST.TourCalendar.Model.Guide');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.TourList = function(status, getGuidesOrNot, guideId, calendar, currentDate, parentClass, callback) {
    var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._status = status;
    this._guideId = guideId;
    this._tours = new Array();
    this.refreshListAsynchronously(getGuidesOrNot, currentDate, calendar, this, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.TourList.prototype.refreshList = function() {
    this._tours = this._parseTourXml(this._getToursXml());
}

WST.TourCalendar.Model.TourList.prototype.refreshListAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject,  parentClass, callback) {
    this._tours = this._getToursXmlAsynchronously(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype._getToursXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getTourServiceUrl());
}

WST.TourCalendar.Model.TourList.prototype._getToursXmlAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
    return Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed(this._getTourServiceUrl(), getGuidesOrNot, currentDate, calendar, tourListObject, callback, parentClass, this._parseTourXmlAsynchronously);
}

WST.TourCalendar.Model.TourList.prototype.setStatus = function(status) {
    this._status = status;
}

WST.TourCalendar.Model.TourList.prototype.getToursByDate = function(date) {
    var tours = new Array();
    for (var i = 0; i < this._tours.length; i++) {
        if (this._tours[i].getStartDate().getFullYear() == date.getFullYear()
                && this._tours[i].getStartDate().getMonth() == date.getMonth()
                && this._tours[i].getStartDate().getDate() == date.getDate()) {
            tours.push(this._tours[i]);
        }
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseTourXmlAsynchronously = function(request, getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
  var xmlDoc = request.responseXML;
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
        if (getGuidesOrNot) {
          guides = tourListObject._parseGuideXml(tourElements[i]);
        }
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    tourListObject._tours = tours;
    callback(tourListObject, calendar, currentDate, parentClass);
}

WST.TourCalendar.Model.TourList.prototype._parseTourXml = function(xmlDoc) {
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
//        var guides = this._parseGuideXml(tourElements[i]);
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseGuideXml = function(tourElement) {
    var guideElements = tourElement.getElementsByTagName('guide');
    var guides = new Array();
    for (var i = 0; i < guideElements.length; i++) {
        var id = guideElements[i].getAttribute('id');
        var name = guideElements[i].getAttribute('name');
        guides.push(new WST.TourCalendar.Model.Guide(id, name));
    }
    return guides;
}


WST.TourCalendar.Model.TourList.prototype._getTourServiceUrl = function() {
    var tourServiceUrl = 'listTours.htm?method=listToursByCriteria&view=xml&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&status=' + this._status;
    if (Lib.Utils.ObjectUtils.isDefined(this._guideId) && this._guideId != 'All') {
        tourServiceUrl = tourServiceUrl + '&guide=' + this._guideId;
    }
    return tourServiceUrl;
}

WST.TourCalendar.Model.TourList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}

//end WST.TourCalendar.Model.TourList.js

//start  WST.TourCalendar.Model.OutOfOffice.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOffice = function(id, guideId, guideName, startDate, startTime, endDate, endTime, allDay,
                                              noEndDate, days) {
    this._id = id;
    this._guideId = guideId;
    this._guideName = guideName;
    this._startDate = new Date(startDate);
    if (endDate != '' && endDate != null) {
        this._endDate = new Date(endDate);
    }
    this._startTime = startTime;
    if (endTime != '' && endTime != null) {
        this._endTime = endTime;
    }
    this._allDay = allDay;
    this._noEndDate = noEndDate;
    this._days = days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideId = function() {
    return this._guideId;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideName = function() {
    return this._guideName;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getAllDay = function() {
    return this._allDay;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getNoEndDate = function() {
    return this._noEndDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getDays = function() {
    return this._days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedDateRange = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, null, null);
    }
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, this._endDate, null);
    }
    if (this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, null, null);
    }
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedStartDateAndTime = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, null);
    }else{
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
    }
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedEndDateAndTime = function() {
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, null);
    }else {
      return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
    }
}

//end  WST.TourCalendar.Model.OutOfOffice.js

//start  WST.TourCalendar.Model.OutOfOfficeList.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.TourCalendar.Model.OutOfOffice');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOfficeList = function(guideId, currentDate) {
     var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._guideId = guideId;
    this._outOfOfficeList = new Array();
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.refreshList = function() {
    this._outOfOfficeList = this._parseOutOfOfficeXml(this._getOutOfOfficeXml());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.getOutOfOfficeByDate = function(date) {
    var outOfOfficeList = new Array();
    for (var i = 0; i < this._outOfOfficeList.length; i++) {
        if (this._outOfOfficeList[i].getStartDate().getFullYear() == date.getFullYear()
                && this._outOfOfficeList[i].getStartDate().getMonth() == date.getMonth()
                && this._outOfOfficeList[i].getStartDate().getDate() == date.getDate()) {
            outOfOfficeList.push(this._outOfOfficeList[i]);
        }
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseOutOfOfficeXml = function(xmlDoc) {
    var outOfOfficeElements = xmlDoc.getElementsByTagName('outOfOffice');
    var outOfOfficeList = new Array();
    for (var i = 0; i < outOfOfficeElements.length; i++) {
        var id = null; //outOfOfficeElements[i].getAttribute('id');
        var guideId = outOfOfficeElements[i].getAttribute('guideId');
        var guideName = null; //outOfOfficeElements[i].getAttribute('guideName');
        var startDate = outOfOfficeElements[i].getAttribute('startDate');
        var startTime = outOfOfficeElements[i].getAttribute('startTime');
        var endDate = outOfOfficeElements[i].getAttribute('endDate');
        var endTime = outOfOfficeElements[i].getAttribute('endTime');
        var allDay = outOfOfficeElements[i].getAttribute('allDay');
        var noEndDate = outOfOfficeElements[i].getAttribute('noEndDate');
        var days = this._parseDaysXml(outOfOfficeElements[i]);
        outOfOfficeList.push(new WST.TourCalendar.Model.OutOfOffice(id, guideId, guideName, startDate, startTime, endDate,
                endTime, allDay, noEndDate, days));
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseDaysXml = function(outOfOfficeElement) {
    var dayElements = outOfOfficeElement.getElementsByTagName('day');
    var days = new Array();
    for (var i = 0; i < dayElements.length; i++) {
        days.push(dayElements[i].firstChild.nodeValue);
    }
    return days;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getOutOfOfficeServiceUrl());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeServiceUrl = function() {
    return 'lookupOutOfOffice.htm?method=lookupOutOfOfficeByCriteria&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&guideId=' + this._guideId;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
//end WST.TourCalendar.Model.OutOfOfficeList.js

//start WST.Event.WindowCloseEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event");

WST.Event.WindowCloseEvent = function(targetElement) {
    this._targetElement = targetElement;
}

WST.Event.WindowCloseEvent.prototype.attachEvent = function(element, type) {
    Lib.Utils.EventUtils.addEvent(element, "mouseout", this.executeEvent, this);
}

WST.Event.WindowCloseEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
//    var selectElements = document.getElementsByTagName('select');
//    for (var i = 0; i < selectElements.length; i++) {
//        Lib.Utils.DocumentUtils.removeClass(selectElements[i], 'invisible');
//    }
    Lib.Utils.DocumentUtils.addClass(this._targetElement, 'hide');
}

//end WST.Event.WindowCloseEvent.js

//start WST.TourCalendar.View.CalendarEntryView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Event.WindowCloseEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.View");

WST.TourCalendar.View.CalendarEntryView = function(template, tourList, outOfOfficeList, viewDataType) {
    this._template = template;
    this._tourList = tourList;
    this._outOfOfficeList = outOfOfficeList;
    this._viewDataType = viewDataType;
    this._entryEvents = new Array();
}

WST.TourCalendar.View.CalendarEntryView.prototype.updateDateElement = function(date, dateElement) {
    if (Lib.Utils.ObjectUtils.isDefined(this._tourList)) {
        this._addTours(date, dateElement);
    }
    if (Lib.Utils.ObjectUtils.isDefined(this._outOfOfficeList)) {
        this._addOutOfOffice(date, dateElement);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype.registerCalendarEntryEvent = function(event) {
    this._entryEvents.push(event);
}

WST.TourCalendar.View.CalendarEntryView.prototype._attachCalendarEntryEvents = function(calendarEntryLink, entryDetailElement) {
    for (var i = 0; i < this._entryEvents.length; i++) {
        var event = new this._entryEvents[i](entryDetailElement);
        event.attachEvent(calendarEntryLink);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTours = function(date, dateElement) {
  var tours = this._tourList.getToursByDate(date);
  if (tours != null && tours.length > 0){
     if (Lib.Utils.ObjectUtils.isDefined(this._viewDataType)
         && this._viewDataType == 'RequestTour'){
                 this._addToursForRequestTours(dateElement, tours);
     }else{
       this._addToursForScheduledTours(dateElement, tours);
     }
  }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForRequestTours = function(dateElement, tours) {
      if (tours != null && tours.length > 0){
      var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarRequestedTourEntry'));
      var dateLink = cssQuery('.dateLink', dateElement)[0];
      var entryDetail = cssQuery('.entryRequestedTourDetail', calendarEntry)[0];

        var popupHTML = '<ul class="calStartTimePlace">';
        for (var i = 0; i < tours.length; i++) {
          popupHTML  +=  '   <li>' +
                               tours[i].getStartTime() +
                               '  ' +
                               tours[i].getPlace() +
                          '   </li>';
        }
        popupHTML += '</ul>';
        entryDetail.innerHTML = popupHTML;
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

//      var calStartTimePlace = cssQuery('.calStartTimePlace', entryDetail)[0];
//      Lib.Utils.XML.XMLUtils.removeAllChildren(calStartTimePlace);
//      for (var i = 0; i < tours.length; i++) {
//          var listElement = document.createElement('li');
//          listElement.innerHTML = tours[i].getStartTime() + " " + tours[i].getPlace() ;
//          calStartTimePlace.appendChild(listElement);
//      }
//      Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

      this._attachCalendarEntryEvents(dateLink, entryDetail);
      dateElement.appendChild(calendarEntry);
    }
  }

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForScheduledTours = function(dateElement, tours) {
           var dateEntry = document.createElement('div');
           dateEntry.className = 'dateEntry';
           for (var i = 0; i < tours.length; i++) {
              var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarTourEntry'));
              var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
                //calendarEntryLink.title = tours[i].getOrganization(); // in anticipation of client req
                calendarEntryLink.title = tours[i].getPlace();
              var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];
              timeElement.innerHTML = tours[i].getStartTime();
              var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
                 // descElement.innerHTML = tours[i].getOrganization();// in anticipation of client req
                  descElement.innerHTML = tours[i].getPlace();
              var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
              this._addTourDetails(entryDetail, tours[i], calendarEntryLink);
              Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
              this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
              dateEntry.appendChild(calendarEntry);
            }
       dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOffice = function(date, dateElement) {
    var outOfOfficeList = this._outOfOfficeList.getOutOfOfficeByDate(date);
    var dateEntry = document.createElement('div');
    dateEntry.className = 'dateEntry';
    for (var i = 0; i < outOfOfficeList.length; i++) {
        var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarOutOfOfficeEntry'));
        var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
        var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];
        timeElement.innerHTML = outOfOfficeList[i].getStartTime();
        var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
        descElement.innerHTML = 'OOO';
        var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
        this._addOutOfOfficeDetails(entryDetail, outOfOfficeList[i], calendarEntryLink);
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
        this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
        dateEntry.appendChild(calendarEntry);
    }
    dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTourDetails = function(entryDetails, tour, calendarEntryLink) {
  var guideElements = "";
  for (var i = 0; i < tour.getGuides().length; i++) {
      guideElements = guideElements + "<li>" + tour.getGuides()[i].getName() + "</li>";
  }

  var detailPopupHtml = '<h3 class="tourDetailsHeader">Tour</h3>' +
                        '<dl class="detailedDefinitions">' +
                        '    <dt>Location:</dt>' +
                        '    <dd class="calDetailPlace">' + tour.getPlace() + '</dd>' +
                        '    <dt>Start:</dt>' +
                        '    <dd class="entryDetailStartDateAndTime">' + tour.getFormattedStartDateAndTime() + '</dd>' +
                        '    <dt>End:</dt>' +
                        '    <dd class="entryDetailEndDateAndTime">' + tour.getFormattedEndDateAndTime() + '</dd>' +
                        '    <dt>Organization:</dt>' +
                        '    <dd class="calDetailOrganization">' + tour.getOrganization() + '</dd>' +
                        '    <dt>Guests:</dt>' +
                        '    <dd class="calDetailNumGuests">' + tour.getNumGuests() + '</dd>' +
                        '    <dt>Room Number:</dt>' +
                        '    <dd class="calDetailLocation">' + tour.getLocation() + '</dd>' +
                        '</dl>' +
                        '<br class="mozclear"/>' +
                        '<span class="calDetailGuidesLabel">Guides:</span>' +
                        '<ul class="calDetailGuideList">' +
                        guideElements +
                        '</ul>';

  entryDetails.innerHTML = detailPopupHtml;

  calendarEntryLink.href = 'tourDetails.htm?method=tourDetail&tourId=' + tour.getId();

//    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
//    entryDetailStartDateAndTime.innerHTML = tour.getFormattedStartDateAndTime();
//    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
//    entryDetailEndDateAndTime.innerHTML = tour.getFormattedEndDateAndTime();
//    var calDetailOrganization = cssQuery('.calDetailOrganization', entryDetails)[0];
//    calDetailOrganization.innerHTML = tour.getOrganization();
//    var calDetailNumGuests = cssQuery('.calDetailNumGuests', entryDetails)[0];
//    calDetailNumGuests.innerHTML = tour.getNumGuests();
//    var calDetailPlace = cssQuery('.calDetailPlace', entryDetails)[0];
//    calDetailPlace.innerHTML = tour.getPlace();
//    var calDetailLocation = cssQuery('.calDetailLocation', entryDetails)[0];
//    calDetailLocation.innerHTML = tour.getLocation();
    //var tourDetailsLink = cssQuery('.tourDetailsLink', entryDetails)[0];
//    var calDetailGuideList = cssQuery('.calDetailGuideList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailGuideList);
//    for (var i = 0; i < tour.getGuides().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = tour.getGuides()[i].getName();
//        calDetailGuideList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOfficeDetails = function(entryDetails, outOfOffice, calendarEntryLink) {
    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
    entryDetailStartDateAndTime.innerHTML = outOfOffice.getStartTime();
    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
    entryDetailEndDateAndTime.innerHTML = outOfOffice.getEndTime();
    calendarEntryLink.href = 'outofoffice.htm?guide=' + outOfOffice.getGuideId();
//    var calDetailDayList = cssQuery('.calDetailDayList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailDayList);
//    for (var i = 0; i < outOfOffice.getDays().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = outOfOffice.getDays()[i];
//        calDetailDayList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

//WST.TourCalendar.View.CalendarEntryView.prototype._attachWindowCloseEvent = function(entryDetails) {
//    var closeLink = cssQuery('.xClose', entryDetails)[0];
//    var event = new WST.Event.WindowCloseEvent(entryDetails);
//    event.attachEvent(closeLink, 'click');
//}

WST.TourCalendar.View.CalendarEntryView.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}

//end WST.TourCalendar.View.CalendarEntryView.js

//start WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to define events that will cause the calendar to display and hide.
*
* @param calendarElement - HTML element representing the calendar.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent = function(calendarElement) {
    this._calendarElement = calendarElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.attachEvent = function(element) {
    Lib.Utils.EventUtils.addEvent(element, 'mouseover', this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the toggle calendar event, causing the calendar to either be displayed or hidden.
*
* @param evt - Event object provided by the browser.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
    Lib.Utils.DocumentUtils.removeClass(this._calendarElement, 'hide');
}
//end WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.js

//start  WST.Controller.Guide.ScheduledToursController.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.TourList');
JSAN.use('WST.TourCalendar.Model.OutOfOfficeList');
JSAN.use('WST.TourCalendar.View.CalendarEntryView');
JSAN.use('WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Guide");

/**
* author: Sonal Patidar
* date created: 08/28/2006
* @constructor
* description:
*   This object is a controller for scheduled tours.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param scheduledTourListUrl - Url of the scheduled tours list service.
*/
WST.Controller.Guide.ScheduledToursController = function(template, guideId) {
    this._template = template;
    this._guideId = guideId;
}

WST.Controller.Guide.ScheduledToursController.prototype._getTourList = function(calendar, currentDate) {
    return new WST.TourCalendar.Model.TourList('SCHEDULED', true, this._guideId, calendar, currentDate, this, this.updateCalendar);
}

WST.Controller.Guide.ScheduledToursController.prototype._getOutOfOfficeList = function(currentDate) {
    return new WST.TourCalendar.Model.OutOfOfficeList(this._guideId, currentDate);
}

WST.Controller.Guide.ScheduledToursController.prototype._getCalendarEntryView = function(tourList, outOfOfficeList) {
    var viewDataType = 'ScheduledTours';
    var view = new WST.TourCalendar.View.CalendarEntryView(this._template, tourList, outOfOfficeList, viewDataType);
    view.registerCalendarEntryEvent(WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent);
    view.registerCalendarEntryEvent(WST.Event.WindowCloseEvent);
    return view;
}

WST.Controller.Guide.ScheduledToursController.prototype.updateCalendar = function(tourList, calendar, currentDate, thisClass) {
//  var tourList = this._getTourList(currentDate);
    var outOfOfficeList = thisClass._getOutOfOfficeList(currentDate);
    thisClass._registerCalendarEntryViewWithCalendar(tourList, outOfOfficeList, calendar, thisClass);
    thisClass._registerTourListWithCalendar(tourList, calendar, currentDate);
    thisClass._registerOutOfOfficeListWithCalendar(outOfOfficeList, calendar);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerCalendarEntryViewWithCalendar = function(tourList, outOfOfficeList, calendar, thisClass) {
    var calendarEntryView = thisClass._getCalendarEntryView(tourList, outOfOfficeList);
    var reference = Lib.Utils.ObjectUtils.weakBind(calendarEntryView.updateDateElement, calendarEntryView);
    calendar.registerDateInitListener(reference);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerTourListWithCalendar = function(tourList, calendar, currentDate) {
    reference = Lib.Utils.ObjectUtils.weakBind(tourList.updateList, tourList);
    calendar.registerMonthChangeListener(reference);
}

WST.Controller.Guide.ScheduledToursController.prototype._registerOutOfOfficeListWithCalendar = function(outOfOfficeList, calendar) {
    reference = Lib.Utils.ObjectUtils.weakBind(outOfOfficeList.updateList, outOfOfficeList);
    calendar.registerMonthChangeListener(reference);
}

//end  WST.Controller.Guide.ScheduledToursController.js

//start WST.Model.Admin.Blackout.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

WST.Model.Admin.Blackout = function(date, reason) {
    this._date = date;
    this._reason = reason;
}

WST.Model.Admin.Blackout.prototype.getDate = function() {
    return this._date;
}

WST.Model.Admin.Blackout.prototype.getReason = function() {
    return this._reason;
}
//end WST.Model.Admin.Blackout.js

//start WST.View.Admin.BlackoutDateView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

WST.View.Admin.BlackoutDateView = function() {
}

WST.View.Admin.BlackoutDateView.prototype.updateDateElement = function(dateElement, isBlackedOut) {
    if (isBlackedOut) {
        Lib.Utils.DocumentUtils.addClass(dateElement, 'blackoutDate');
    } else {
        Lib.Utils.DocumentUtils.removeClass(dateElement, 'blackoutDate');
    }
}
//end WST.View.Admin.BlackoutDateView.js

//start WST.Model.Admin.BlackoutList.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Model.Admin.Blackout");
JSAN.use('WST.View.Admin.BlackoutDateView');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object represents a list of blackout dates.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList = function(blackoutListXML) {
    this._blackouts = new Array();
    this._parseList(blackoutListXML);
    this._blackoutDateView = new WST.View.Admin.BlackoutDateView();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of Blackout objects.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackouts = function() {
    return this._blackouts;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackoutDates = function() {
    var dates = new Array();
    for (var i = 0; i < this._blackouts.length; i++) {
        dates.push(new Date(this._blackouts[i].getDate()));
    }
    return dates;
}

WST.Model.Admin.BlackoutList.prototype.processDateElement = function(date, dateElement) {
    this._blackoutDateView.updateDateElement(dateElement, this._isBlackedOut(date));
}

WST.Model.Admin.BlackoutList.prototype._isBlackedOut = function(date) {
    var blackoutDates = this.getBlackoutDates();
    for (var i = 0; i < blackoutDates.length; i++) {
        if (blackoutDates[i].getYear() == date.getYear()
                && blackoutDates[i].getMonth() == date.getMonth()
                && blackoutDates[i].getDate() == date.getDate()) {
            return true;
        }
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method parses the xml document of blackout dates into Blackout objects.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype._parseList = function(blackoutListXML) {
    var blackoutElements = blackoutListXML.getElementsByTagName('blackout');
    for (var i = 0; i < blackoutElements.length; i++) {
        var date = blackoutElements[i].getAttribute('date');
        var reason = null; //blackoutElements[i].getAttribute('reason');
        this._blackouts.push(new WST.Model.Admin.Blackout(date, reason));
    }
}

//end WST.Model.Admin.BlackoutList.js


//start WST.Controller.Admin.BlackoutController.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.Admin.BlackoutList');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Admin");

/**
* author: Nate Minshew
* date created: 07/25/2006
* @constructor
* description:
*   This object is a controller for blackout dates.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param blackoutListUrl - Url of the blackout list service.
*/
WST.Controller.Admin.BlackoutController = function(ajaxUtils, blackoutListUrl, selectedDate) {
    this._selectedDate = selectedDate;
    this._ajaxUtils = ajaxUtils;
    this._blackoutListUrl = blackoutListUrl;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method retrieves a list of blackout dates from the server.
*/
WST.Controller.Admin.BlackoutController.prototype.getBlackoutList = function() {
    if (Lib.Utils.ObjectUtils.isDefined(this._selectedDate)
       && Lib.Utils.ObjectUtils.isDefined(this._blackoutListUrl)){
       this._blackoutListUrl = this._blackoutListUrl + '&selectedDate=' + this._selectedDate;
    }
    var xml = this._ajaxUtils.requestSynchronousFeed(this._blackoutListUrl);
    return new WST.Model.Admin.BlackoutList(xml);
}

WST.Controller.Admin.BlackoutController.prototype.updateCalendar = function(calendar) {
    var blackoutList = this.getBlackoutList();
    var reference = Lib.Utils.ObjectUtils.weakBind(blackoutList.processDateElement, blackoutList);
    calendar.registerDateInitListener(reference);
    for (var i = 0; i < blackoutList.getBlackoutDates().length; i++) {
        calendar.disableDate(blackoutList.getBlackoutDates()[i]);
    }
}
//end WST.Controller.Admin.BlackoutController.js

//start ScheduledToursMain.js

//JSAN.addRepository('../JavaScript');

// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');

//JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.Guide.ScheduledToursView');
JSAN.use('WST.Controller.Guide.ScheduledToursController');
JSAN.use('WST.Controller.Admin.BlackoutController');
JSAN.use('WST.Event.WindowCloseEvent');

// Load ScheduledToursMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new ScheduledToursMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * @constructor
 * description:
 *   This is the main object for the blackout page.  It is used to create any needed objects for the page, as well
 *   as set up all the views, controllers and events.
 */
ScheduledToursMain = function() {

//  var logger = new TTSLog4javascriptLogger();

//  logger.debug("ScheduledToursMain Enter create method");

  var scheduledToursView = this._createScheduledToursView();

//  logger.debug("ScheduledToursMain Exit create method");
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method returns the url of the templates file.
 */
ScheduledToursMain.prototype._getTemplatesURL = function() {
  return '../JavaScript/templates/templates.html';
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the calendar template.
 */
ScheduledToursMain.prototype._createTemplates = function() {
  return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the calendar widget.
 */
ScheduledToursMain.prototype._createCalendar = function() {
  var scheduledToursController = this._createScheduledToursController();
  var blackoutController = this._createBlackoutController();
  var currentDate = document.getElementById('currentDate').value;
    if (currentDate == null) {
       currentDate = new Date();
    }else{
      currentDate = new Date(currentDate);
    }
   var calendar = new Lib.DHTML.Calendar(
      this._createTemplates().getRootElement('calendar'),
      Lib.Utils.DateUtils,
      Lib.Utils.DocumentUtils,
      Lib.Utils.EventUtils,
      Lib.Utils.XML.XMLUtils,
      Lib.Utils.ObjectUtils,
      currentDate,
      true);
//  if (currentDate != '') {
//    calendar.setDate(new Date(currentDate));
//  }
//  logger.debug("ScheduledToursMain - Before updating blackout calendar");
  blackoutController.updateCalendar(calendar);
//  logger.debug("ScheduledToursMain - Updated blackout calendar before updating tour calendar");
//  scheduledToursController.updateCalendar(calendar, currentDate);
  scheduledToursController._getTourList(calendar, currentDate);
//  logger.debug("ScheduledToursMain - Exit _createCalendar");
  return calendar;
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the ScheduledToursView.
 */
ScheduledToursMain.prototype._createScheduledToursView = function() {
//  logger.debug("ScheduledToursMain - Enter _createScheduledToursView ");
  var scheduledToursFields = document.getElementById('scheduledToursFields');
  var calendar = this._createCalendar();
//  logger.debug("ScheduledToursMain - Calendar created");
  return new WST.View.Guide.ScheduledToursView(calendar, scheduledToursFields,Lib.Utils.XML.XMLUtils,
      Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, Lib.Utils.ObjectUtils, Lib.Utils.FormUtils);
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates a scheduled Tours controller object.
 */
ScheduledToursMain.prototype._createScheduledToursController = function() {
  var guideId = document.getElementById('guide')[document.getElementById('guide').selectedIndex].value;
  return new WST.Controller.Guide.ScheduledToursController(this._createTemplates(), guideId);
}
/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates a blackout controller object.
 */
ScheduledToursMain.prototype._createBlackoutController = function() {
  return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL());
}


/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method returns the URL for the blackout list service.
 */
ScheduledToursMain.prototype._getBlackoutListURL = function() {
  return 'blackout.htm?method=listBlackoutDates';
}

//end ScheduledToursMain.js
var reportWindow
var bReportWindowOpen = false;


function openReportWindow(sURL, sName)
{
	reportWindow = window.open(sURL, sName, 'status=0,toolbar=0,location=0,directories=0,menubar=0,resizable=yes,scrollbars=yes,width=800,height=600,top=50,left=50,true');
	bReportWindowOpen = true;
}


function ClosePopUp()
{
	if (bReportWindowOpen)
	{
		reportWindow.close();
		bReportWindowOpen = false;
	}
}

