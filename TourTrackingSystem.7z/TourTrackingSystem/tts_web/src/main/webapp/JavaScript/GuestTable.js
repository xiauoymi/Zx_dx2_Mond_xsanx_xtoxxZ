var guestTable;
var confirmGuestTable;
var statesArray = [{value:"", text:"Select"}];
var countriesArray = [{value:"", text:"Select"}];
var classificationsArray = [{value:"", text:"Select"}];
var locationsArray = [{value:" ", text:"Select"}, {value:"Domestic", text:"Domestic"}, {value:"International", text:"International"}];
var requiredFieldClass = 'requiredField';
var usaCountry = 'United States Of America';
var naState = 'Not applicable';

function loadGuestList() {
    var loader = new YAHOO.util.YUILoader();
    var contextPath = document.getElementById('contextPath').value;
    loader.sandbox({
        require: ["container", "connection", "datatable"],
        base: contextPath + '/JavaScript/yui/',
        loadOptional: false,
        onSuccess: function() {
            loadGuests();
        }
    });
    loader.insert();
}

function loadGuests() {

    this.createGuestTable = {
        success: function(o) {
            populateGuestTable(o);
        },
        failure: function(o) {
        },
        timeout: 30000 //30 seconds
    };

    var tourId = document.getElementById('__AUTOSAVE_ITEM_ID').value;
    if (tourId === "") {
        tourId = document.getElementById('originalTourId').value;
    }
    var url = document.getElementById('contextPath').value + "/servlet/guest.htm?tourId=" + tourId;
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            this.createGuestTable);
}

function populateGuestTable(o) {
    this.cache = null;
    var xmlDoc = o.responseXML;
    populateArray(xmlDoc, 'state', statesArray);
    populateArray(xmlDoc, 'country', countriesArray);
    populateArray(xmlDoc, 'classification', classificationsArray);

    this.guestsSource = new YAHOO.util.DataSource(xmlDoc);
    this.guestsSource.responseType = YAHOO.util.DataSource.TYPE_XML;
    this.guestsSource.responseSchema = {
        resultNode: "guest",
        fields: ["firstName", "lastName", "location", "guestState", "guestCountry", "guestClassification"]
    };


    guestTable = getGuestTable(getGuestColumnDefs(), this.guestsSource);
    confirmGuestTable = getConfirmGuestTable(getConfirmGuestColumnDefs(), this.guestsSource);
    markMissingGuestFieldsAsRequired(xmlDoc);
    displayNumberOfGuests(xmlDoc.getElementsByTagName('guest').length);
    createHiddenFields();
}

function populateArray(xmlDoc, tagName, array) {
    var elements = xmlDoc.getElementsByTagName(tagName);
    var j = 1;
    for (var i = 0; i < elements.length; i++) {
        var idNodes = elements[i].getElementsByTagName('id');
        if (idNodes.length > 0) {
            var valueStr = elements[i].getElementsByTagName('id')[0].text;
            var textStr = elements[i].getElementsByTagName('name')[0].text;
            array[j++] = {value:valueStr, text:textStr};
        }
    }
}

function displayNumberOfGuests(numGuests) {
    var numGuestsElement = document.getElementById('numGuests');
    if (numGuestsElement != null) {
        numGuestsElement.innerHTML = '(' + numGuests + ')';
    }
}

function markMissingGuestFieldsAsRequired(xmlDoc) {
    var guestElements = xmlDoc.getElementsByTagName('guest');
    for (var k = 0; k < guestElements.length; k++) {
        var firstName = guestElements[k].getElementsByTagName('firstName')[0].text;
        if (firstName == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[1], requiredFieldClass);
        }
        var lastName = guestElements[k].getElementsByTagName('lastName')[0].text;
        if (lastName == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[2], requiredFieldClass);
        }
        var location = guestElements[k].getElementsByTagName('location')[0].text;
        if (location == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[3], requiredFieldClass);
        }
        var state = guestElements[k].getElementsByTagName('guestState')[0].text;
        if (location == "Domestic") {
            if (state == "") {
                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[4], requiredFieldClass);
            }
            guestTable.getRow(k).cells[5].innerHTML = usaCountry;
        }
        var country = guestElements[k].getElementsByTagName('guestCountry')[0].text;
        if (location == "International") {
            if (country == "") {
                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[5], requiredFieldClass);
            }
            guestTable.getRow(k).cells[4].innerHTML = naState;
        }
        var classification = guestElements[k].getElementsByTagName('guestClassification')[0].text;
        if (classification == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[6], requiredFieldClass);
        }
    }
}

function createHiddenFields() {
    var formElement = document.forms[0];
    for (var i = 0; i < guestTable.getRecordSet().getLength(); i++) {
        var firstName = guestTable.getRecordSet().getRecord(i).getData().firstName;
        var lastName = guestTable.getRecordSet().getRecord(i).getData().lastName;
        var location = guestTable.getRecordSet().getRecord(i).getData().location;
        var state = guestTable.getRecordSet().getRecord(i).getData().guestState;
        var country = guestTable.getRecordSet().getRecord(i).getData().guestCountry;
        var classification = guestTable.getRecordSet().getRecord(i).getData().guestClassification;

        if (firstName != "" || lastName != "") {
            formElement.appendChild(document.createElement("<input name='guestFirstName' type='hidden' value='" +
                                                           firstName +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestLastName' type='hidden' value='" +
                                                           lastName +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestLocation' type='hidden' value='" +
                                                           location +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestState' type='hidden' value='" + state +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestCountry' type='hidden' value='" +
                                                           country +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestClassification' type='hidden' value='" +
                                                           classification + "'/>"));
        }
    }
}

function deleteHiddenFields() {
    var formElement = document.forms[0];
    var firstNameElemets = document.getElementsByName('guestFirstName');
    var lastNameElemets = document.getElementsByName('guestLastName');
    var locationElemets = document.getElementsByName('guestLocation');
    var stateElemets = document.getElementsByName('guestState');
    var countryElemets = document.getElementsByName('guestCountry');
    var classficationElemets = document.getElementsByName('guestClassification');
    var firstNameLength = firstNameElemets.length;
    for (var i = firstNameLength - 1; i > -1; i--) {
        formElement.removeChild(firstNameElemets[i]);
        formElement.removeChild(lastNameElemets[i]);
        formElement.removeChild(locationElemets[i]);
        formElement.removeChild(stateElemets[i]);
        formElement.removeChild(countryElemets[i]);
        formElement.removeChild(classficationElemets[i]);
    }
}

function onkeyupEvent(v, newData, oColumn, oRecord) {

    var numColumns = guestTable.getColumnSet().keys.length;
    var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
    var totalRows = guestTable.getRecordSet().getLength();
    if (v.keyCode == 13) {//enter
        if (totalRows - rowIndex == 1) {//if last row add a new row
            addGuest();//create a new row
            guestTable.fireEvent("cellClickEvent",
            {target:guestTable.getLastTrEl().cells[1], event:event}
                    );
        } else {//go to the next row
            guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
        }
    }
    if (v.keyCode == 9) {//tab
        if (oColumn.key == 'location') {
            if (newData == 'Domestic') {//go to state
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
                        );
            } else if (newData == 'International') {//go to country
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
                        );
            } else {//go to classification if location not selected
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
                        );
            }
        } else
            if (oColumn.key == 'guestState') {//go to classfication
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
                        );
            }
            else //go to the next column
                if (numColumns - oColumn.getIndex() == 2) {//if last but one column
                    if (totalRows - rowIndex == 1) {//if last row add a new row
                        addGuest();
                        guestTable.fireEvent("cellClickEvent",
                        {target:guestTable.getLastTrEl().cells[1], event:event}
                                );
                    } else {
                        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
                    }
                } else {
                    //go to the next column
                    guestTable.fireEvent("cellClickEvent",
                    {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
                            );
                }
    }
}

//
//    if (numColumns - oColumn.getIndex() == 2) {//if last but one column
//      var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
//      var totalRows = guestTable.getRecordSet().getLength();
//      if (totalRows - rowIndex == 1) {//if last row add a new row
//        addGuest();
//        guestTable.fireEvent("cellClickEvent",
//        {target:guestTable.getLastTrEl().cells[1], event:event}
//            );
//      } else {
//        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
//      }
//    } else {
//      if (oColumn.key == 'location') {
//        if (newData == 'Domestic') {//go to state
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//              );
//        } else if (newData == 'International') {//go to country
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//              );
//        } else {//go to classification iff location not selected
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
//              );
//        }
//      } else {
//        if (oColumn.key == 'guestState') {//go to classfication
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//              );
//        }
//        else {//go to the next column
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//              );
//        }
//      }
//    }


function onchangeEvent(newData, toSaveOrNot) {
    var oldData = guestTable._oCellEditor.record.getData(guestTable._oCellEditor.column.key);
    guestTable._oRecordSet.updateKey(guestTable._oCellEditor.record, guestTable._oCellEditor.column.key, newData);
    guestTable.formatCell(guestTable._oCellEditor.cell);
    guestTable.fireEvent("editorSaveEvent",
    {editor:guestTable._oCellEditor, oldData:oldData, newData:newData, record:guestTable._oCellEditor.record, toSaveOrNot:toSaveOrNot}
            );
}


function getGuestColumnDefs() {

    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                            oRecord.getData(oColumn.key);
        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                      oColumn.editorOptions.dropdownOptions : null;
        for (var i = 0; i < options.length; i++) {
            if (options[i].value == selectedValue) {
                if (selectedValue.length > 0) {
                    el.innerHTML = options[i].text;
                }
                break;
            }
        }
    }

    this.deleteGuestFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = '<img border="0" alt="Delete Guest" src="' + document.getElementById('contextPath').value +
                       '/images/icon_delete.gif">';
        el.style.cursor = 'pointer';
    }

    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
        var rowId = this.getTrEl(el).sectionRowIndex;
        el.innerHTML = rowId + 1;
    }

    this.editTextBox = function (oEditor, oSelf) {
        var oRecord = oEditor.record;
        var oColumn = oEditor.column;
        var elContainer = oEditor.container;
        var value = oRecord.getData(oColumn.key);

        var elTextbox = elContainer.appendChild(document.createElement("input"));
        elTextbox.type = "text";
        elTextbox.style.width = "100px";
        elTextbox.value = value;

        YAHOO.util.Event.addListener(elTextbox, "keydown", function(v) {
            onkeyupEvent(v, elTextbox.value, oColumn, oRecord);
        });

        YAHOO.util.Event.addListener(elTextbox, "focusout", function() {
            onchangeEvent(elTextbox.value, true);
        });
        elTextbox.focus();
        elTextbox.select();
    };

    this.editDropdown = function (oEditor, oSelf) {

        var oRecord = oEditor.record;
        var oColumn = oEditor.column;
        var elContainer = oEditor.container;

        var value = oRecord.getData(oColumn.key);
        var elDropdown = elContainer.appendChild(document.createElement("select"));
        var dropdownOptions = (oColumn.editorOptions && YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                              oColumn.editorOptions.dropdownOptions : [];
        for (var j = 0; j < dropdownOptions.length; j++) {
            var dropdownOption = dropdownOptions[j];
            var elOption = document.createElement("option");
            elOption.value = (YAHOO.lang.isValue(dropdownOption.value)) ? dropdownOption.value : dropdownOption;
            elOption.innerHTML = (YAHOO.lang.isValue(dropdownOption.text)) ? dropdownOption.text : dropdownOption;
            elOption = elDropdown.appendChild(elOption);
            if (value === elDropdown.options[j].value) {
                elDropdown.options[j].selected = true;
            }
        }
        YAHOO.util.Event.addListener(elDropdown, "keydown", function(v) {
            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, false);

            onkeyupEvent(v, elDropdown[elDropdown.selectedIndex].value, oColumn, oRecord);
        });

        YAHOO.util.Event.addListener(elDropdown, "focusout", function() {
            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, true);
        });
        oSelf._focusEl(elDropdown);
    };

    return [
        {label:"", formatter:this.rowNumberFormatter},
        {key:"firstName", label:"<b>First Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
        {key:"lastName", label:"<b>Last Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
        {key:"location", label:"<b>Location</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:locationsArray}, sortable:true, resizeable:true},
        {key:"guestState", label:"<b>State</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:statesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
        {key:"guestCountry", label:"<b>Country</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:countriesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
        {key:"guestClassification", label:"<b>Classification</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true, width:300},
        {key:"delete", label:"", formatter:this.deleteGuestFormatter}
    ];
}

function getConfirmGuestColumnDefs() {

    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                            oRecord.getData(oColumn.key);
        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                      oColumn.editorOptions.dropdownOptions : null;
        for (var i = 0; i < options.length; i++) {
            if (options[i].value == selectedValue) {
                if (selectedValue.length > 0) {
                    el.innerHTML = options[i].text;
                }
                break;
            }
        }
    }

    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
        var rowId = this.getTrEl(el).sectionRowIndex;
        el.innerHTML = rowId + 1;
    }

    return [
        {label:"", formatter:this.rowNumberFormatter},
        {key:"firstName", label:"<b>First Name</b>"},
        {key:"lastName", label:"<b>Last Name</b>"},
        {key:"location", label:"<b>Location</b>", editor:"dropdown", editorOptions:{dropdownOptions:locationsArray}},
        {key:"guestState", label:"<b>State</b>", editor:"dropdown", editorOptions:{dropdownOptions:statesArray}, formatter:this.dropDownFormatter},
        {key:"guestCountry", label:"<b>Country</b>", editor:"dropdown", editorOptions:{dropdownOptions:countriesArray}, formatter:this.dropDownFormatter},
        {key:"guestClassification", label:"<b>Classification</b>", editor:"dropdown", editorOptions:{dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter}
    ];
}

function getGuestTable(columnDefs, dataSource) {

    this.onCellEditSaveGuestValue = function(oArgs) {
        var toSaveOrNot = oArgs.toSaveOrNot;
        var currentCell = oArgs.editor.cell;
        var newData = oArgs.newData;
        var oRecord = oArgs.editor.record;
        var guestRow = this.getTrEl(oRecord);
        var guestTableRowIndex = guestRow.sectionRowIndex;
        confirmGuestTable.updateRow(confirmGuestTable.getTrEl(guestTableRowIndex), oRecord.getData());
        if (oArgs.editor.column.key == 'location') {
            if (newData == 'Domestic') {
                guestRow.cells[4].innerHTML = "";
                oRecord.getData().guestCountry = "";
                guestRow.cells[5].innerHTML = usaCountry;
                YAHOO.util.Dom.addClass(guestRow.cells[4], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
            } else if (newData == 'International') {
                oRecord.getData().guestState = "";
                guestRow.cells[4].innerHTML = naState;
                guestRow.cells[5].innerHTML = "";
                YAHOO.util.Dom.addClass(guestRow.cells[5], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
            } else {
                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
            }
        }
        if (newData == '') {
            YAHOO.util.Dom.addClass(currentCell, requiredFieldClass);
        } else {
            YAHOO.util.Dom.removeClass(currentCell, requiredFieldClass);
        }

        if (toSaveOrNot) {
            deleteHiddenFields();
            createHiddenFields();
            autosave(document.forms['tourForm']);
        }
    }

    this.onCellClickEvent = function(ev) {
        var target = YAHOO.util.Event.getTarget(ev);
        var column = guestTable.getColumn(target);
        if (column.key == 'delete') {
            var rowId = guestTable.getRow(target).sectionRowIndex;
            deleteGuest(rowId);
        } else {
            guestTable.onEventShowCellEditor(ev);
        }
    }

    guestTable = new YAHOO.widget.DataTable("guestTableDiv", columnDefs, dataSource);
    guestTable.subscribe("cellMouseoverEvent", guestTable.onEventHighlightCell);
    guestTable.subscribe("cellMouseoutEvent", guestTable.onEventUnhighlightCell);
    var addGuestButton = document.getElementById("addRow");
    var disabled = addGuestButton.getAttribute("disabled");
    if (disabled != true) {
        guestTable.subscribe("editorSaveEvent", this.onCellEditSaveGuestValue);
        guestTable.subscribe("cellClickEvent", this.onCellClickEvent);
        guestTable.subscribe("editorBlurEvent", function(oArgs) {
            this.cancelCellEditor();
        });
    }
    return guestTable;
}

function getConfirmGuestTable(columnDefs, dataSource) {
    confirmGuestTable = new YAHOO.widget.DataTable("confirmGuestsDiv", columnDefs, dataSource);
    return confirmGuestTable;
}

function addGuest() {
    var prevRow = guestTable.getLastTrEl();
    var location = '';
    var state = '';
    var country = '';
    var classification = '';

    if (prevRow != null) {//copy previous row's values to the new row
        var lastRecord = guestTable.getRecord(prevRow);
        location = lastRecord.getData().location;
        state = lastRecord.getData().guestState;
        country = lastRecord.getData().guestCountry;
        classification = lastRecord.getData().guestClassification;
    }
    guestTable.addRow({
        firstName:"",
        lastName:"",
        location:location,
        guestState:state,
        guestCountry:country,
        guestClassification:classification
    });

    confirmGuestTable.addRow({
        firstName:"",
        lastName:"",
        location:location,
        guestState:state,
        guestCountry:country,
        guestClassification:classification
    });

    var newRow = guestTable.getLastTrEl();
    if (prevRow != null) {
        if (state == "") {
            state = prevRow.cells[4].innerHTML;//In case previous row had 'Not Applicable' in state column
            newRow.cells[4].innerHTML = state;//In case previous row had 'Not Applicable' in state column
        }

        if (country == "") {
            country = prevRow.cells[5].innerHTML;//In case previous row had 'United States of America' in country column
            newRow.cells[5].innerHTML = country;//In case previous row had 'United States of America' in country column
        }
    }

    var cells = newRow.cells;
    for (var t = 1; t < cells.length - 1; t++) {
        var cell = cells[t];
        YAHOO.util.Dom.addClass(cell, requiredFieldClass);
    }
    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);

    //deleteHiddenFields();
    //createHiddenFields();
    //autosave(document.forms['tourForm']);
}

function deleteGuest(rowId) {
    guestTable.deleteRow(rowId);
    guestTable.refreshView();

    confirmGuestTable.deleteRow(rowId);
    confirmGuestTable.refreshView();

    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);

    deleteHiddenFields();
    createHiddenFields();
    autosave(document.forms['tourForm']);
}


function showModalSaveMyChangesWarning(status) {
    var handleSubmit = function() {
        saveMyChanges();
    };
    var handleCancel = function() {
        this.cancel();
    };

    if (status != null) {
        var tourStatus = document.getElementById('tourStatus');
        tourStatus.value = status;
    }
    var anotherUserElement = document.getElementById('anotherUserHasUncompleteChanges');
    if (anotherUserElement == null) {
        saveMyChanges();
    } else {
        var message = anotherUserElement.value;
        message = "<b>Are you sure?</b><br/>" + message + "<br/>";
        message += "<b>Clicking on Save Changes will override other user's Incomplete Changes for this tour.</b><br/>";
        var areYouSure =
                new YAHOO.widget.Dialog("modalDialogForSaveMyChanges",
                { width:"400px",
                    fixedcenter:true,
                    close:false,
                    draggable:false,
                    zindex:4,
                    visible:false,
                    modal:true,
                    buttons : [ { text:"Save My Changes", handler:handleSubmit },
                        { text:"Cancel", handler:handleCancel } ]
                }
                        );

        //areYouSure.setHeader("Are you sure?");
        areYouSure.setBody(message);
        areYouSure.render();
        areYouSure.show();
    }
}

function saveMyChanges() {
    document.getElementById('method').value = 'addTour';
    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
    document.forms[0].submit();
}

function saveImportGuestInfo() {
    autosave(document.forms['tourForm']);
    document.getElementById('method').value = 'addTour';
    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
    document.forms[0].submit();

}

