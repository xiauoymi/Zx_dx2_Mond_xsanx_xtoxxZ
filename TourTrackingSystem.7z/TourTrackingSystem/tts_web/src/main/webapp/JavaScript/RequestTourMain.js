JSAN.addRepository('../JavaScript');

// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.DHTML.TabNavigator');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');
JSAN.use('Lib.Utils.ValidatorUtils');

JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.RequestTour.FormNavView');
JSAN.use('WST.View.RequestTour.ConfirmView');
JSAN.use('WST.View.RequestTour.TabsView');
JSAN.use('WST.View.RequestTour.AdditionalServicesView');
JSAN.use('WST.View.RequestTour.GeneralView');
//JSAN.use('WST.View.RequestTour.GuestsView');
JSAN.use('WST.View.RequestTour.GuidesView');
JSAN.use('WST.View.ErrorView');
JSAN.use('WST.Controller.RequestTour.ConfirmController');
JSAN.use('WST.Controller.Admin.BlackoutController');
JSAN.use('WST.Controller.RequestTour.CalendarController');

// Load RequestTourMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new RequestTourMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This is the main object for the request a tour page.  It is used to create any needed objects for the page, as well
*   as set up all the views, controllers and events.
*/
RequestTourMain = function() {
    var logger = new TTSLog4javascriptLogger();
    if (document.getElementById('showDetails') == 'true') {
        var confirmController = this._createConfirmController();
        var confirmView = this._createConfirmView(confirmController);
    } else {
        var tabNavigator = this._createTabNavigator();
        var formTopNavView = this._createTopFormNavView(tabNavigator);
        var formBottomNavView = this._createBottomFormNavView(tabNavigator);
        var confirmController = this._createConfirmController();
        var confirmView = this._createConfirmView(confirmController);
        var tabsView = this._createTabsView(tabNavigator);
        var additionalServicesView = this._createAdditionalServicesView();
        var calendar = this._createCalendar();
        var guideCalendar = this._createGuideCalendar();
        var generalView = this._createGeneralView(calendar, confirmController);
        var errorView = this._createErrorView();
        //var guestsView = this._createGuestsView(errorView, confirmController);
        var guidesView = this._createGuidesView(confirmController, errorView, guideCalendar);
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the tab navigator widget.
*/
RequestTourMain.prototype._createTabNavigator = function() {
    return new Lib.DHTML.TabNavigator('.tab', 'activeTab', 'hide', Lib.Utils.DocumentUtils, Lib.Utils.EventUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the FormNavView.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createTopFormNavView = function(tabNavigator) {
    var formNavElement = document.getElementsByName('formNav')[0];
    var formElement = document.getElementById('tourForm');
    return new WST.View.RequestTour.FormNavView(
            tabNavigator,
            'invisible',
            Lib.Utils.DocumentUtils,
            formNavElement,
            Lib.Utils.ObjectUtils,
            formElement,
            Lib.Utils.EventUtils);
}
/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the FormNavView.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createBottomFormNavView = function(tabNavigator) {
    var formNavElement = document.getElementsByName('formNav')[1];
    var formElement = document.getElementById('tourForm');
    return new WST.View.RequestTour.FormNavView(
            tabNavigator,
            'invisible',
            Lib.Utils.DocumentUtils,
            formNavElement,
            Lib.Utils.ObjectUtils,
            formElement,
            Lib.Utils.EventUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the ConfirmView object.
*
* @param confirmController - Controller for the confirm section.
*/
RequestTourMain.prototype._createConfirmView = function(confirmController) {
    var confirmPage = document.getElementById('confirmPage');
    return new WST.View.RequestTour.ConfirmView(Lib.Utils.ObjectUtils, Lib.Utils.EventUtils, Lib.Utils.XML.XMLUtils,
            Lib.Utils.FormUtils, confirmController, confirmPage);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the TabsView object.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createTabsView = function(tabNavigator) {
    var tourTabs = document.getElementById('tourTabs');
    return new WST.View.RequestTour.TabsView(tourTabs, tabNavigator, Lib.Utils.ObjectUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the additional services view object.
*/
RequestTourMain.prototype._createAdditionalServicesView = function() {
    var additionalServicesPage = document.getElementById('additionalServicesPage');
    return new WST.View.RequestTour.AdditionalServicesView(
            additionalServicesPage,
            Lib.Utils.EventUtils,
            Lib.Utils.DocumentUtils,
            'hide');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar template.
*/
RequestTourMain.prototype._createTemplates = function() {
    return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar widget.
*/
RequestTourMain.prototype._createCalendar = function() {
    var scheduledToursController = this._createCalendarController();
    var selectedDate = document.getElementById('tourDate').value;
    var blackoutController = this._createBlackoutController(selectedDate);
    var calendar = new Lib.DHTML.Calendar(
        this._createTemplates().getRootElement('calendar'),
        Lib.Utils.DateUtils,
        Lib.Utils.DocumentUtils,
        Lib.Utils.EventUtils,
        Lib.Utils.XML.XMLUtils,
        Lib.Utils.ObjectUtils,
        new Date());
    if (selectedDate != '') {
        calendar.setDate(new Date(selectedDate));
    }
    blackoutController.updateCalendar(calendar);
    scheduledToursController._getTourList(calendar);
    return calendar;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar widget.
*/
RequestTourMain.prototype._createGuideCalendar = function() {
    var calendarController = this._createCalendarController();
    var selectedDate = document.getElementById('tourDate').value;
    var blackoutController = this._createBlackoutController(selectedDate);
    var calendar = new Lib.DHTML.Calendar(
        this._createTemplates().getRootElement('calendar'),
        Lib.Utils.DateUtils,
        Lib.Utils.DocumentUtils,
        Lib.Utils.EventUtils,
        Lib.Utils.XML.XMLUtils,
        Lib.Utils.ObjectUtils,
        new Date());
    if (selectedDate != '') {
        calendar.setDate(new Date(selectedDate));
    }
    blackoutController.updateCalendar(calendar);
    calendarController._getTourList(calendar);
    return calendar;
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method creates a scheduled Tours controller object.
*/
RequestTourMain.prototype._createCalendarController = function() {
    return new WST.Controller.RequestTour.CalendarController(this._createTemplates());
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the general section view object.
*
* @param calendar - Calendar widget.
* @param confirmController - Controller for the confirm section.
*/
RequestTourMain.prototype._createGeneralView = function(calendar, confirmController) {
    var generalPage = document.getElementById('generalPage');
    return new WST.View.RequestTour.GeneralView(
            calendar,
            generalPage,
            Lib.Utils.XML.XMLUtils,
            Lib.Utils.DocumentUtils,
            Lib.Utils.EventUtils,
            Lib.Utils.ObjectUtils,
            confirmController);
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the guests view object.
*
* @param errorView - Object representing the view to error messages.
* @param confirmController - Object representing the controller for the confirm section.
*/
RequestTourMain.prototype._createGuestsView = function(errorView, confirmController) {
    var guestsPage = document.getElementById('guestsPage');
    var numGuests = document.getElementById('numGuests');
    return new WST.View.RequestTour.GuestsView(guestsPage, Lib.Utils.FormUtils, Lib.Utils.ObjectUtils,
            Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, numGuests, Lib.Utils.ValidatorUtils, errorView,
            confirmController);
}
/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the guides view object.
*
* @param confirmController - Object representing the controller for the confirm section.
*/
RequestTourMain.prototype._createGuidesView = function(confirmController, errorView, calendar) {
    var guidesPage = document.getElementById('guidesPage');
    var numGuides = document.getElementById('numGuides');
    return new WST.View.RequestTour.GuidesView(guidesPage, Lib.Utils.FormUtils, Lib.Utils.ObjectUtils,
            Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, numGuides,
            confirmController, errorView, calendar, Lib.Utils.XML.XMLUtils);
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method creates the error view object.
*/
RequestTourMain.prototype._createErrorView = function() {
    var errorElement = document.getElementById('errorMessages');
    return new WST.View.ErrorView(errorElement, Lib.Utils.DocumentUtils, Lib.Utils.ObjectUtils, Lib.Utils.XML.XMLUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method returns the url of the templates file.
*/
RequestTourMain.prototype._getTemplatesURL = function() {
    return '../JavaScript/templates/templates.html';
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the confirm controller object.
*/
RequestTourMain.prototype._createConfirmController = function() {
    return new WST.Controller.RequestTour.ConfirmController();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates a blackout controller object.
*/
RequestTourMain.prototype._createBlackoutController = function(selectedDate) {
    return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL(), selectedDate);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method returns the URL for the blackout list service.
*/
RequestTourMain.prototype._getBlackoutListURL = function() {
    return 'blackout.htm?method=listBlackoutDates';
}

