
/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method returns the URL for the blackout list service.
 */
function setSelectedDate(){
  var selectedYear = document.getElementById("year");
  var selectedMonth = document.getElementById("month");
//  alert("year selected " + selectedYear.options[selectedYear.selectedIndex].value);
//  alert("month selected " + selectedMonth.options[selectedMonth.selectedIndex].value);
  var currentDate = selectedMonth.options[selectedMonth.selectedIndex].value + "/01/" + selectedYear.options[selectedYear.selectedIndex].value;
//  alert("current date is :"+currentDate);
  document.getElementById("currentDate").value=currentDate;
  var scheduledToursMain = new ScheduledToursMain();
  scheduledToursMain._createScheduledToursView(null);
}