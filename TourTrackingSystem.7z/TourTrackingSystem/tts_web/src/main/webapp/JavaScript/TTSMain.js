JSAN.addRepository('JavaScript');
JSAN.addRepository('JavaScript/shared/wst');
JSAN.addRepository('../JavaScript');
JSAN.addRepository('../JavaScript/shared/wst');

JSAN.use('TTSLog4javascriptLogger');

JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.ObjectUtils');

JSAN.use('WST.View.FooterView');
JSAN.use('WST.Utils.DateUtils');
JSAN.use('WST.View.FormView');

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', createTTSMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method instantiates the TTSMain object.
*/
function createTTSMain() {
  var logger = new TTSLog4javascriptLogger();
  new TTSMain(logger);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method clears the cached context objects.
*/
function clearCtx() {
    Lib.Utils.ObjectUtils.clearContextObjects();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is the main object for the TTS application.  It handles wiring up all global events.
*/
TTSMain = function(logger) {
    var dateUtils = this._createDateUtils();
    var formView = this._createFormView();
    var footerView = this._createFooterView(dateUtils);
//    logger.debug("TTSMain - dateUtils, formView and footerView complete");
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates a date utils object.
*/
TTSMain.prototype._createDateUtils = function() {
    return new WST.Utils.DateUtils();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates the footer view object.
*/
TTSMain.prototype._createFooterView = function(dateUtils) {
    var footerElement = document.getElementById('footer');
    return new WST.View.FooterView(footerElement, dateUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates the form view object.
*/
TTSMain.prototype._createFormView = function() {
    return new WST.View.FormView(Lib.Utils.XML.XMLUtils, Lib.Utils.ObjectUtils);
}