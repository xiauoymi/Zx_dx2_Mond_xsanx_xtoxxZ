// Common Javascript functions.
	// --------------------------------------------------
	// Each page need to have this method customized to get data from People Picker Utility.
	// Do not change anything other than the html element ids.
	//	arrPeopleData
	//		index - 0 : party id
	//		index - 1 : last name
	//		index - 2 : first name
	//		index - 3 : middle name
	//		index - 4 : user id
	//		index - 5 : phone id
	//		index - 6 : email
	//
	// ---------------------------------------------------
	var usernameConrolId="";
	var fullnameConrolId="";
	var emailConrolId="";
	var phoneControlId="";
	function setValuesFromPeoplePicker(arrPeopleData)
	{
		if (!usernameConrolId=="")
			document.getElementById(usernameConrolId).value = arrPeopleData[4];
		if (!fullnameConrolId=="")
			document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
    if (!emailConrolId=="")
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
		if (!phoneControlId=="")
			document.getElementById(phoneControlId).value = arrPeopleData[5];

    //manually call onchange coz it is not triggered automatically when ppsclient sets values
    if(document.getElementById(fullnameConrolId).onchange != null){
         document.getElementById(fullnameConrolId).onchange();
     }

    document.getElementById(fullnameConrolId).focus();
	}

function setValuesFromPeoplePickerFirstNameLastName(arrPeopleData)
	{
		if (!usernameConrolId=="")
			document.getElementById(usernameConrolId).value = arrPeopleData[4];
		if (!fullnameConrolId==""){
            if (arrPeopleData[3] != "") {
                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[3] + " " + arrPeopleData[1];
            }
            else {
                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[1];
            }
        }
        if (!emailConrolId=="")
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
		if (!phoneControlId=="")
			document.getElementById(phoneControlId).value = arrPeopleData[5];

    document.getElementById(fullnameConrolId).focus();
	}
	function setPeoplePickerControlIds(usrname,fullname,email,phone) {
		usernameConrolId=usrname;
		fullnameConrolId=fullname;
		emailConrolId=email;
    phoneControlId=phone;
  }
	
	function strtrim(s) {
	 //Match spaces at beginning and end of text and replace with null strings
		return s.replace(/^\s+/,'').replace(/\s+$/,'');
	}