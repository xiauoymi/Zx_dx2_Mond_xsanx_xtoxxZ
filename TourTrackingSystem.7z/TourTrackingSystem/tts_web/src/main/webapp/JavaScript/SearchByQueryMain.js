// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.DHTML.TabNavigator');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');
JSAN.use('Lib.Utils.ValidatorUtils');

JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.RequestTour.TabsView');
JSAN.use('WST.View.Admin.SearchByQueryView');
JSAN.use('WST.View.Admin.SearchByQueryGuestView');
JSAN.use('WST.View.Admin.SearchByQueryResultsView');
JSAN.use('WST.Controller.Admin.BlackoutController');

// Load SearchByQueryMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new SearchByQueryMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

function clearSearchCriteria(path) {
    document.forms[0].action = path + "/servlet/searchByQuery.htm?method=clearSearchCriteria";
    document.forms[0].submit();
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * @constructor
 * description:
 *   This is the main object for the search by querry page.  It is used to create any needed objects for the page, as well
 *   as set up all the views, controllers and events.
 */
SearchByQueryMain = function() {
  var logger = new TTSLog4javascriptLogger();
//  logger.debug("SearchByQueryMain Enter create method");
  var tabNavigator = this._createTabNavigator();
//  logger.debug("SearchByQueryMain Tab Navigator Created");
  var tabsView = this._createTabsView(tabNavigator);
//  logger.debug("SearchByQueryMain Tab View Created");
  var searchByQueryView = this._createSearchByQueryView();
  var searchByGuestsView = this._createSearchByQueryGuestsView();
//  logger.debug("SearchByQueryMain _createSearchByQueryView Executed");
  var searchByQueryResultsView = this._createSearchByQueryResultsView();
//  logger.debug("SearchByQueryMain Exit create method");
}

/**
 * author: Sonal Pstidar
 * date created: /4/27/2007
 * access level: private
 * description:
 *   This method returns the url of the templates file.
 */
SearchByQueryMain.prototype._getTemplatesURL = function() {
  return '../JavaScript/templates/templates.html';
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the calendar template.
 */
SearchByQueryMain.prototype._createCalendarTemplate = function() {
  return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the TabsView object.
 *
 * @param tabNavigator - Tab navigator widget.
 */
SearchByQueryMain.prototype._createTabsView = function(tabNavigator) {
  var queryTabs = document.getElementById('queryTabs');
    return new WST.View.RequestTour.TabsView(queryTabs, tabNavigator, Lib.Utils.ObjectUtils);
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the tab navigator widget.
 */
SearchByQueryMain.prototype._createTabNavigator = function() {
  return new Lib.DHTML.TabNavigator('.tab', 'activeTab', 'hide', Lib.Utils.DocumentUtils, Lib.Utils.EventUtils);
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the calendar widget.
 */
SearchByQueryMain.prototype._createCalendar = function() {
  var blackoutController = this._createBlackoutController();
  var calendar = new Lib.DHTML.Calendar(
      this._createCalendarTemplate().getRootElement('calendar'),
      Lib.Utils.DateUtils,
      Lib.Utils.DocumentUtils,
      Lib.Utils.EventUtils,
      Lib.Utils.XML.XMLUtils,
      Lib.Utils.ObjectUtils,
      new Date());
  blackoutController.updateCalendar(calendar);
  return calendar;
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the SearchByQuery
 */
SearchByQueryMain.prototype._createSearchByQueryView = function() {
  var allPage = document.getElementById('generalPage');
  var startDateCalendar = this._createCalendar();
  startDateCalendar.getCalendar().id = 'startDateCalendar';
  var endDateCalendar = this._createCalendar();
  endDateCalendar.getCalendar().id = 'endDateCalendar';
  return new WST.View.Admin.SearchByQueryView(startDateCalendar, endDateCalendar, allPage, Lib.Utils.XML.XMLUtils,
      Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, Lib.Utils.ObjectUtils);
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the SearchByQuery
 */
SearchByQueryMain.prototype._createSearchByQueryGuestsView = function() {
  var guestPage = document.getElementById('guestPage');
  return new WST.View.Admin.SearchByQueryGuestView(guestPage, Lib.Utils.EventUtils, Lib.Utils.FormUtils, 
          Lib.Utils.DocumentUtils);
}
/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates the SearchByQuery
 */
SearchByQueryMain.prototype._createSearchByQueryResultsView = function() {
  var resultsPage = document.getElementById('resultsPage');
  return new WST.View.Admin.SearchByQueryResultsView(resultsPage, Lib.Utils.DocumentUtils);
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method creates a blackout controller object.
 */
SearchByQueryMain.prototype._createBlackoutController = function() {
  return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL());
}

/**
 * author: Sonal Pstidar
 * date created: 4/27/2007
 * access level: private
 * description:
 *   This method returns the URL for the blackout list service.
 */
SearchByQueryMain.prototype._getBlackoutListURL = function() {
  return 'blackout.htm?method=listFutureBlackoutDates';
}
