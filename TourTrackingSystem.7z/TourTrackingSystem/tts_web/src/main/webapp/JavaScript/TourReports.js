var reportWindow
var bReportWindowOpen = false;


function openReportWindow(sURL, sName)
{
	reportWindow = window.open(sURL, sName, 'status=0,toolbar=0,location=0,directories=0,menubar=0,resizable=yes,scrollbars=yes,width=800,height=600,top=50,left=50,true');
	bReportWindowOpen = true;
}


function ClosePopUp()
{
	if (bReportWindowOpen)
	{
		reportWindow.close();
		bReportWindowOpen = false;
	}
}

