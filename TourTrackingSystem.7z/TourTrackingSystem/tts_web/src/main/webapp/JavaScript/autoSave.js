var http_request = false;

function sendSyncRequest(url) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, false);
    http_request.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
    http_request.onreadystatechange = function() {
        if (http_request.readyState == 4) {
            callbackMethodAfterSync();
        }
    }

    http_request.send();
}

function callbackMethodAfterSync() {
    var autosaveSessionId = http_request.responseText;
//  autosaveSessionId = autosaveSessionId.replace("\r\n", '');
    document.getElementById('__AUTOSAVE_SESSION_ID').value = autosaveSessionId;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = 0;
    var itemId = this.document.getElementById('__AUTOSAVE_ITEM_ID').value;
    if (itemId == "" || itemId == "null") {
        itemId = "NEW" + autosaveSessionId;
        document.getElementById('__AUTOSAVE_ITEM_ID').value = itemId;
        document.getElementById('incompleteNewTourId').value = itemId;
    }
}

function sendAsyncRequest(url, parameters) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, true);
    http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http_request.setRequestHeader("Content-length", parameters.length);
    http_request.onreadystatechange = callbackMethodAfterAsync;
    http_request.send(parameters);
}

function callbackMethodAfterAsync() {
    // do nothing in the callback method
    if (http_request.readyState == 4) {
        if (http_request.status == 200) {
            var okAfterAutosave = http_request.responseText;
            if (okAfterAutosave.indexOf('OK') >= 0) {
                document.getElementsByName('discardChanges')[0].disabled = false;
                document.getElementsByName('discardChanges')[1].disabled = false;
                var saveChangesButton = document.getElementsByName('saveChanges');
                if (saveChangesButton.length > 0) {
                    document.getElementsByName('saveChanges')[0].disabled = false;
                    document.getElementsByName('saveChanges')[1].disabled = false;
                }
//          var submitChangesButton = document.getElementsByName('submitChanges');
                //          if(submitChangesButton.length > 0){
                //            document.getElementsByName('submitChanges')[0].disabled = false;
                //            document.getElementsByName('submitChanges')[1].disabled = false;
                //          }
                //          this.document.getElementById('currentUserHasIncompleteChanges').innerHTML = "You have incomplete changes from autosave";
                document.getElementById('currentUserHasIncompleteChanges').style.display = "";
            }
        }
    }


}

function getQueryStringForAutosave(obj) {
    var getstr = "";
    for (i = 0; i < obj.childNodes.length; i++) {
        if (obj.childNodes[i].tagName.toLowerCase() == "input") {
            if (obj.childNodes[i].type == "text") {
                getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
            }

            if (obj.childNodes[i].type.toLowerCase() == "checkbox") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                } else {
                    getstr += obj.childNodes[i].name + "=&";
                }
            }
            if (obj.childNodes[i].type.toLowerCase() == "radio") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                }
            }
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "select") {
            var sel = obj.childNodes[i];
            getstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "textarea") {
            getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
        }
    }
    return getstr;
}

function getQueryStringForAutosaveForEntireForm(frm) {
    var getstr = "";
    for (i = 0; i < frm.elements.length; i++) {
        var frmElement = frm.elements[i];
        if (frmElement.tagName.toLowerCase() == "input") {
            if (frmElement.type == "text") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type == "hidden") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type.toLowerCase() == "checkbox") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                } else {
                    getstr += frmElement.name + "=&";
                }
            }
            if (frmElement.type.toLowerCase() == "radio") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                }
            }
        }
        if (frmElement.tagName.toLowerCase() == "select") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.options[frmElement.selectedIndex].value) + "&";
        }
        if (frmElement.tagName.toLowerCase() == "textarea") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
        }
    }
    return getstr;
}

function startSessionIfNotAlreadyStarted() {
    var autosaveSessionId = document.getElementById('__AUTOSAVE_SESSION_ID').value;
    if (autosaveSessionId == null || autosaveSessionId == "") {
        startAutosaveSession();
    }
}

function autosave(formObj) {
    startSessionIfNotAlreadyStarted();
    var autosaveSeqStr = document.getElementById('__AUTOSAVE_SESSION_SEQ').value;
    var autosaveSeq = parseInt(autosaveSeqStr);
    autosaveSeq += 1;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = autosaveSeq;
    var getstr = getQueryStringForAutosaveForEntireForm(formObj);
    sendAsyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=SAVE', getstr);
}

function startAutosaveSession() {
    sendSyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=START');
}
