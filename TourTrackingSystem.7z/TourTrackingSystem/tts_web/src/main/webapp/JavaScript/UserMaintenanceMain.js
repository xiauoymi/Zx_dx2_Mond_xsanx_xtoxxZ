// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.View.Template');
JSAN.use('Lib.DHTML.Calendar');

JSAN.use('WST.View.Admin.UserMaintenanceView');
JSAN.use('WST.Controller.Admin.UserMaintenanceController');

// Load UserMaintenanceMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new UserMaintenanceMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

function cancelAction(path){
    document.forms[0].action=path +"/servlet/userMaintenance.htm?method=listUsersWithRoles";
    document.forms[0].submit();
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* @constructor
* description:
*   This is the main object for the UserMaintenance page.  It is used to create any needed objects for the page, as well
*   as set up all the views, controllers and events.
*/
UserMaintenanceMain = function() {
    var userMaintenanceView = this._createUserMaintenanceView();
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method creates the UserMaintenanceView.
*/
UserMaintenanceMain.prototype._createUserMaintenanceView = function() {
    var userMaintenanceFields = document.getElementById('userMaintenanceFields');
    return new WST.View.Admin.UserMaintenanceView(userMaintenanceFields, Lib.Utils.DocumentUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates a userMaintenance controller object.
*/
UserMaintenanceMain.prototype._createUserMaintenanceController = function() {
    return new WST.Controller.Admin.UserMaintenanceController(Lib.Utils.XML.AjaxUtils, this._getUserMaintenanceListURL());
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method returns the URL for the users service.
*/
UserMaintenanceMain.prototype._getUserMaintenanceListURL = function() {
    return 'userMaintenance.htm?method=listUsersWithRoles';
}
