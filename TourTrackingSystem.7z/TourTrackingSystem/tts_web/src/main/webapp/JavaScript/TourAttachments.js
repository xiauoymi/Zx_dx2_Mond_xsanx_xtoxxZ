var attachmentWindow
var bAttachmentWindowOpen = false;


function openAttachmentWindow(sURL, sName)
{

  attachmentWindow = window.open(sURL, sName, 'status=0,toolbar=yes,location=0,directories=0,menubar=0,resizable=yes,scrollbars=yes,width=900,height=700,top=50,left=50,true');
	bAttachmentWindowOpen = true;
}


function ClosePopUp()
{
	if (bAttachmentWindowOpen)
	{
		attachmentWindow.close();
		bAttachmentWindowOpen = false;
	}
}

