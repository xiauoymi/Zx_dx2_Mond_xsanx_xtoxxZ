// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.View.Template');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');

JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.Guide.ScheduledToursView');
JSAN.use('WST.Controller.Guide.ChangedToursController');

// Load ChangedToursMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new ChangedToursMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
 * author: Uma Kolandai
 * date created: 12/05/2006
 * @constructor
 * description:
 *   This is the main object for the Changed Tours page.  It is used to create any needed objects for the page, as well
 *   as set up all the views, controllers and events.
 */
ChangedToursMain = function() {

  var logger = new TTSLog4javascriptLogger();

//  logger.debug("ChangedToursMain Enter create method");

  var changedToursView = this._createChangedToursView(logger);

//  logger.debug("ChangedToursMain Exit create method");

}

/**
 * author: Uma Kolandai
 * date created: 12/06/2006
 * access level: private
 * description:
 *   This method creates the ChangedToursView.
 */
ChangedToursMain.prototype._createChangedToursView = function(logger) {
//  logger.debug("ChangedToursMain Enter _createChangedToursView");
  var changedToursFields = document.getElementById('changedToursFields');
  return new WST.View.Guide.ScheduledToursView(null, changedToursFields, Lib.Utils.XML.XMLUtils,
      Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, Lib.Utils.ObjectUtils, Lib.Utils.FormUtils, logger);
}
