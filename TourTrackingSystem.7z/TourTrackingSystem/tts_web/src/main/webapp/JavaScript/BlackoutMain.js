// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.DHTML.Calendar');


JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.Admin.BlackoutView');
JSAN.use('WST.Controller.Admin.BlackoutController');

// Load RequestTourMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new BlackoutMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
* author: Nate Minshew
* date created: 07/26/2006
* @constructor
* description:
*   This is the main object for the blackout page.  It is used to create any needed objects for the page, as well
*   as set up all the views, controllers and events.
*/
BlackoutMain = function() {
    

    var logger = new TTSLog4javascriptLogger();

    var blackoutView = this._createBlackoutView(logger);

//    logger.fatal("BlackoutMain - Black out view created");
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method returns the url of the templates file.
*/
BlackoutMain.prototype._getTemplatesURL = function() {
    return '../JavaScript/templates/templates.html';
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method creates the calendar template.
*/
BlackoutMain.prototype._createCalendarTemplate = function() {
    return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method creates the calendar widget.
*/
BlackoutMain.prototype._createCalendar = function() {
    var blackoutController = this._createBlackoutController();
    var calendar = new Lib.DHTML.Calendar(
            this._createCalendarTemplate().getRootElement('calendar'),
            Lib.Utils.DateUtils,
            Lib.Utils.DocumentUtils,
            Lib.Utils.EventUtils,
            Lib.Utils.XML.XMLUtils,
            Lib.Utils.ObjectUtils,
            new Date());
    blackoutController.updateCalendar(calendar);
    return calendar;
}

/**
* author: Nate Minshew
* date created: 07/26/2006
* access level: private
* description:
*   This method creates the BlackoutView.
*/
BlackoutMain.prototype._createBlackoutView = function(logger) {
    var blackoutFields = document.getElementById('blackoutFields');
    return new WST.View.Admin.BlackoutView(this._createCalendar(), blackoutFields, Lib.Utils.XML.XMLUtils,
            Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, Lib.Utils.ObjectUtils, logger);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates a blackout controller object.
*/
BlackoutMain.prototype._createBlackoutController = function() {
    return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL());
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method returns the URL for the blackout list service.
*/
BlackoutMain.prototype._getBlackoutListURL = function() {
    return 'blackout.htm?method=listFutureBlackoutDates';
}
