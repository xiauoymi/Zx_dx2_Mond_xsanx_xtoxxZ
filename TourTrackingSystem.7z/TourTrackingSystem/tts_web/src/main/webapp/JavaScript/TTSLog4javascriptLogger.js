JSAN.use('log4javascript');

TTSLog4javascriptLogger = function (){
  return this._createTTSLog4javascriptLogger();
}

TTSLog4javascriptLogger.prototype._createTTSLog4javascriptLogger = function(){
  var logger = log4javascript.getLogger("TTSLogger");
  logger.removeAllAppenders();
  var ajaxAppender = new log4javascript.AjaxAppender("/tourtrackingsystem/servlet/logs");
  ajaxAppender.setThreshold(log4javascript.Level.DEBUG);
//  ajaxAppender.setThreshold(log4javascript.Level.FATAL);
  ajaxAppender.setWaitForResponse(false);
  logger.addAppender(ajaxAppender);
//  logger.debug("leaving logger");
  return logger;


  /* These are some other appenders that can be used
  var formElement = document.getElementById('footer');
  var inPageAppender = new log4javascript.InPageAppender(formElement);
  inPageAppender.setThreshold(log4javascript.Level.DEBUG);
  log.addAppender(inPageAppender);

  var popUpAppender = new log4javascript.PopUpAppender();
  popUpAppender.setFocusPopUp(true);
  popUpAppender.setNewestMessageAtTop(true);
  popUpAppender.setThreshold(log4javascript.Level.ERROR);
  log.addAppender(popUpAppender);

  var alertAppender = new log4javascript.AlertAppender();
  alertAppender.setThreshold(log4javascript.Level.INFO);
  log.addAppender(alertAppender);
*/
}