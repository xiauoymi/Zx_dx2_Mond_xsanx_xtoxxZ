function exportToExcel(path){
    document.forms[0].action = path + "/servlet/searchByQuery.htm?method=lookupToursByQuery&view=excel";
    document.forms[0].submit();
}