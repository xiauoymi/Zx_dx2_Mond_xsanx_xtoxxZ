function discardIncompleteChanges() {
    document.getElementById('method').value = 'discard';
    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/incompleteTour.htm";
    document.forms[0].submit();
}

function hideAdditionalServicesTab(dropDown) {
    if (dropDown == null) {
        dropDown = document.getElementById("tourPlace");
    }
    var selection = dropDown.options[dropDown.selectedIndex].value;
    var addServicesTab = document.getElementById("addServicesTab");
    var meetingBeforeFalse = document.getElementById("meetingBeforeFalse");
    var meetingBeforeTrue = document.getElementById("meetingBeforeTrue");
    var arrivalTime = document.getElementById("arrivalTime");
    var refreshmentsBefore = document.getElementById("refreshmentsBefore");
    var refreshmentDuring = document.getElementById("refreshmentsDuring");
    var meetingAfterTrue = document.getElementById("meetingAfterTrue");
    var meetingAfterFalse = document.getElementById("meetingAfterFalse");
    var meetingAfterDuration = document.getElementById("meetingAfterDuration");
    var refreshmentsAfter = document.getElementById("refreshmentsAfter");
    /*
     var creditCardNumber = document.getElementById("creditCardNumber");
     var creditCardName = document.getElementById("creditCardName");
     var creditCardMonth = document.getElementById("creditCardMonth");
     var creditCardYear = document.getElementById("creditCardYear");
     */
    var photoReleaseTrue = document.getElementById("photoReleaseTrue");
    var photoReleaseFalse = document.getElementById("photoReleaseTrue");
    if (selection == 'CC' && addServicesTab != null) {
        addServicesTab.style.display = "none";
        meetingBeforeFalse.checked = true;
        meetingBeforeTrue.checked = false;
        meetingAfterFalse.checked = true;
        meetingAfterTrue.checked = false;
        arrivalTime.value = ""
        refreshmentsBefore.value = "";
        refreshmentDuring.value = ""
        refreshmentsAfter.value = ""
        meetingAfterFalse.checked = true;
        meetingAfterTrue.checked = false;
        meetingAfterDuration.value = "";
        refreshmentsAfter.value = "";
        /*
         creditCardNumber.value = "";
         creditCardName.value = "";
         creditCardMonth.value = "";
         creditCardYear.value = "";
         */
        //        tourLocationAfter.value = ""
        photoReleaseTrue.checked = false;
        photoReleaseFalse.checked = false;
    }
    else {
        if (addServicesTab != null) {
            addServicesTab.style.display = "block";
        }
    }
}

function doScroll() {
    window.scrollTo(0, 0);
    document.getElementById("TTS").focus();
    return true;
}