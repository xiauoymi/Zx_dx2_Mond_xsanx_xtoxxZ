function encodeString(text){
  return encodeURIComponent(text);
}

//function trim(stringToTrim) {
//	return stringToTrim.replace(/^\s+|\s+$/g,"");
//}


function getParameters(){
  var id = document.getElementById("meetingNotesId").value;
  var yearEl = document.getElementById("yearId");
  var yearId = yearEl.options[yearEl.selectedIndex].value;
  var jan = encodeString(document.getElementById("januaryNotes").value);
  var feb = encodeString(document.getElementById("februaryNotes").value);
  var mar = encodeString(document.getElementById("marchNotes").value);
  var apr = encodeString(document.getElementById("aprilNotes").value);
  var may = encodeString(document.getElementById("mayNotes").value);
  var jun = encodeString(document.getElementById("juneNotes").value);
  var jul = encodeString(document.getElementById("julyNotes").value);
  var aug = encodeString(document.getElementById("augustNotes").value);
  var sep = encodeString(document.getElementById("septemberNotes").value);
  var oct = encodeString(document.getElementById("octoberNotes").value);
  var nov = encodeString(document.getElementById("novemberNotes").value);
  var dec = encodeString(document.getElementById("decemberNotes").value);
  var parameters = "?id=" + id + "&yearId=" + yearId;
  parameters += "&january=" + jan;
  parameters += "&february=" + feb;
  parameters += "&march=" + mar;
  parameters += "&april=" + apr;
  parameters += "&may=" + may;
  parameters += "&june=" +jun;
  parameters += "&july=" + jul;
  parameters += "&august=" + aug;
  parameters += "&september=" + sep;
  parameters += "&october=" + oct;
  parameters += "&november=" + nov;
  parameters += "&december=" + dec;
  return parameters;

}

function saveMeetingNotes(){
   document.getElementById('method').value = 'insertOrUpdateMonthlyMeetingNotes';
  document.forms[0].action = document.getElementById('contextPath').value + "/servlet/monthlyTeamMeetings.htm" + getParameters();
  document.forms.monthlyTeamMeetingsForm.submit();
}

function getMeetingNotes(){
  document.getElementById("method").value = "displayMonthlyMeetingNotesForYear";
  var yearEl = document.getElementById("yearId");
  var yearId = yearEl.options[yearEl.selectedIndex].value;

  var url = document.getElementById('contextPath').value + "/servlet/monthlyTeamMeetings.htm?yearId=" + yearId;
  document.forms[0].action = url;
  document.forms.monthlyTeamMeetingsForm.submit();
}

function decodeText(){
  document.getElementById("januaryNotes").value = decodeURIComponent(document.getElementById("jan").value);
  document.getElementById("februaryNotes").value = decodeURIComponent(document.getElementById("feb").value);
  document.getElementById("marchNotes").value = decodeURIComponent(document.getElementById("mar").value);
  document.getElementById("aprilNotes").value = decodeURIComponent(document.getElementById("apr").value);
  document.getElementById("mayNotes").value = decodeURIComponent(document.getElementById("may").value);
  document.getElementById("juneNotes").value = decodeURIComponent(document.getElementById("jun").value);
  document.getElementById("julyNotes").value = decodeURIComponent(document.getElementById("jul").value);
  document.getElementById("augustNotes").value = decodeURIComponent(document.getElementById("aug").value);
  document.getElementById("septemberNotes").value = decodeURIComponent(document.getElementById("sep").value);
  document.getElementById("octoberNotes").value = decodeURIComponent(document.getElementById("oct").value);
  document.getElementById("novemberNotes").value = decodeURIComponent(document.getElementById("nov").value);
  document.getElementById("decemberNotes").value = decodeURIComponent(document.getElementById("dec").value);
}