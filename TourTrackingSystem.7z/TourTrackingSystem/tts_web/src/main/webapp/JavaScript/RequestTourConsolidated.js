var guestTable;
var confirmGuestTable;
var statesArray = [{value:"", text:"Select"}];
var countriesArray = [{value:"", text:"Select"}];
var classificationsArray = [{value:"", text:"Select"}];
var locationsArray = [{value:" ", text:"Select"}, {value:"Domestic", text:"Domestic"}, {value:"International", text:"International"}];
var requiredFieldClass = 'requiredField';
var usaCountry = 'United States Of America';
var naState = 'Not applicable';

function loadGuestList() {
    var loader = new YAHOO.util.YUILoader();
    var contextPath = document.getElementById('contextPath').value;
    loader.sandbox({
        require: ["container", "connection", "datatable"],
        base: contextPath + '/JavaScript/yui/',
        loadOptional: false,
        onSuccess: function() {
            loadGuests();
        }
    });
    loader.insert();
}

function loadGuests() {

    this.createGuestTable = {
        success: function(o) {
            populateGuestTable(o);
        },
        failure: function(o) {
        },
        timeout: 30000 //30 seconds
    };

    var tourId = document.getElementById('__AUTOSAVE_ITEM_ID').value;
    if (tourId === "") {
        tourId = document.getElementById('originalTourId').value;
    }
    var url = document.getElementById('contextPath').value + "/servlet/guest.htm?tourId=" + tourId;
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            this.createGuestTable);
}

function populateGuestTable(o) {
    this.cache = null;
    var xmlDoc = o.responseXML;
    populateArray(xmlDoc, 'state', statesArray);
    populateArray(xmlDoc, 'country', countriesArray);
    populateArray(xmlDoc, 'classification', classificationsArray);

    this.guestsSource = new YAHOO.util.DataSource(xmlDoc);
    this.guestsSource.responseType = YAHOO.util.DataSource.TYPE_XML;
    this.guestsSource.responseSchema = {
        resultNode: "guest",
        fields: ["firstName", "lastName", "location", "guestState", "guestCountry", "guestClassification"]
    };


    guestTable = getGuestTable(getGuestColumnDefs(), this.guestsSource);
    confirmGuestTable = getConfirmGuestTable(getConfirmGuestColumnDefs(), this.guestsSource);
    markMissingGuestFieldsAsRequired(xmlDoc);
    displayNumberOfGuests(xmlDoc.getElementsByTagName('guest').length);
    createHiddenFields();
}

function populateArray(xmlDoc, tagName, array) {
    var elements = xmlDoc.getElementsByTagName(tagName);
    var j = 1;
    for (var i = 0; i < elements.length; i++) {
        var idNodes = elements[i].getElementsByTagName('id');
        if (idNodes.length > 0) {
            var valueStr = elements[i].getElementsByTagName('id')[0].text;
            var textStr = elements[i].getElementsByTagName('name')[0].text;
            array[j++] = {value:valueStr, text:textStr};
        }
    }
}

function displayNumberOfGuests(numGuests) {
    var numGuestsElement = document.getElementById('numGuests');
    if (numGuestsElement != null) {
        numGuestsElement.innerHTML = '(' + numGuests + ')';
    }
}

function markMissingGuestFieldsAsRequired(xmlDoc) {
    var guestElements = xmlDoc.getElementsByTagName('guest');
    for (var k = 0; k < guestElements.length; k++) {
        var firstName = guestElements[k].getElementsByTagName('firstName')[0].text;
        if (firstName == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[1], requiredFieldClass);
        }
        var lastName = guestElements[k].getElementsByTagName('lastName')[0].text;
        if (lastName == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[2], requiredFieldClass);
        }
        var location = guestElements[k].getElementsByTagName('location')[0].text;
        if (location == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[3], requiredFieldClass);
        }
        var state = guestElements[k].getElementsByTagName('guestState')[0].text;
        if (location == "Domestic") {
            if (state == "") {
                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[4], requiredFieldClass);
            }
            guestTable.getRow(k).cells[5].innerHTML = usaCountry;
        }
        var country = guestElements[k].getElementsByTagName('guestCountry')[0].text;
        if (location == "International") {
            if (country == "") {
                YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[5], requiredFieldClass);
            }
            guestTable.getRow(k).cells[4].innerHTML = naState;
        }
        var classification = guestElements[k].getElementsByTagName('guestClassification')[0].text;
        if (classification == "") {
            YAHOO.util.Dom.addClass(guestTable.getRow(k).cells[6], requiredFieldClass);
        }
    }
}

function createHiddenFields() {
    var formElement = document.forms[0];
    for (var i = 0; i < guestTable.getRecordSet().getLength(); i++) {
        var firstName = guestTable.getRecordSet().getRecord(i).getData().firstName;
        var lastName = guestTable.getRecordSet().getRecord(i).getData().lastName;
        var location = guestTable.getRecordSet().getRecord(i).getData().location;
        var state = guestTable.getRecordSet().getRecord(i).getData().guestState;
        var country = guestTable.getRecordSet().getRecord(i).getData().guestCountry;
        var classification = guestTable.getRecordSet().getRecord(i).getData().guestClassification;

        if (firstName != "" || lastName != "") {
            formElement.appendChild(document.createElement("<input name='guestFirstName' type='hidden' value='" +
                                                           firstName +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestLastName' type='hidden' value='" +
                                                           lastName +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestLocation' type='hidden' value='" +
                                                           location +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestState' type='hidden' value='" + state +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestCountry' type='hidden' value='" +
                                                           country +
                                                           "'/>"));
            formElement.appendChild(document.createElement("<input name='guestClassification' type='hidden' value='" +
                                                           classification + "'/>"));
        }
    }
}

function deleteHiddenFields() {
    var formElement = document.forms[0];
    var firstNameElemets = document.getElementsByName('guestFirstName');
    var lastNameElemets = document.getElementsByName('guestLastName');
    var locationElemets = document.getElementsByName('guestLocation');
    var stateElemets = document.getElementsByName('guestState');
    var countryElemets = document.getElementsByName('guestCountry');
    var classficationElemets = document.getElementsByName('guestClassification');
    var firstNameLength = firstNameElemets.length;
    for (var i = firstNameLength - 1; i > -1; i--) {
        formElement.removeChild(firstNameElemets[i]);
        formElement.removeChild(lastNameElemets[i]);
        formElement.removeChild(locationElemets[i]);
        formElement.removeChild(stateElemets[i]);
        formElement.removeChild(countryElemets[i]);
        formElement.removeChild(classficationElemets[i]);
    }
}

function onkeyupEvent(v, newData, oColumn, oRecord) {

    var numColumns = guestTable.getColumnSet().keys.length;
    var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
    var totalRows = guestTable.getRecordSet().getLength();
    if (v.keyCode == 13) {//enter
        if (totalRows - rowIndex == 1) {//if last row add a new row
            addGuest();//create a new row
            guestTable.fireEvent("cellClickEvent",
            {target:guestTable.getLastTrEl().cells[1], event:event}
                    );
        } else {//go to the next row
            guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
        }
    }
    if (v.keyCode == 9) {//tab
        if (oColumn.key == 'location') {
            if (newData == 'Domestic') {//go to state
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
                        );
            } else if (newData == 'International') {//go to country
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
                        );
            } else {//go to classification if location not selected
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
                        );
            }
        } else
            if (oColumn.key == 'guestState') {//go to classfication
                guestTable.fireEvent("cellClickEvent",
                {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
                        );
            }
            else //go to the next column
                if (numColumns - oColumn.getIndex() == 2) {//if last but one column
                    if (totalRows - rowIndex == 1) {//if last row add a new row
                        addGuest();
                        guestTable.fireEvent("cellClickEvent",
                        {target:guestTable.getLastTrEl().cells[1], event:event}
                                );
                    } else {
                        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
                    }
                } else {
                    //go to the next column
                    guestTable.fireEvent("cellClickEvent",
                    {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
                            );
                }
    }
}

//
//    if (numColumns - oColumn.getIndex() == 2) {//if last but one column
//      var rowIndex = guestTable.getTrEl(oRecord).sectionRowIndex;
//      var totalRows = guestTable.getRecordSet().getLength();
//      if (totalRows - rowIndex == 1) {//if last row add a new row
//        addGuest();
//        guestTable.fireEvent("cellClickEvent",
//        {target:guestTable.getLastTrEl().cells[1], event:event}
//            );
//      } else {
//        guestTable.fireEvent("cellClickEvent", {target:guestTable.getTrEl(rowIndex + 1).cells[1]});
//      }
//    } else {
//      if (oColumn.key == 'location') {
//        if (newData == 'Domestic') {//go to state
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//              );
//        } else if (newData == 'International') {//go to country
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//              );
//        } else {//go to classification iff location not selected
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 3]}
//              );
//        }
//      } else {
//        if (oColumn.key == 'guestState') {//go to classfication
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 2]}
//              );
//        }
//        else {//go to the next column
//          guestTable.fireEvent("cellClickEvent",
//          {target:guestTable.getTrEl(oRecord).cells[oColumn.getIndex() + 1]}
//              );
//        }
//      }
//    }


function onchangeEvent(newData, toSaveOrNot) {
    var oldData = guestTable._oCellEditor.record.getData(guestTable._oCellEditor.column.key);
    guestTable._oRecordSet.updateKey(guestTable._oCellEditor.record, guestTable._oCellEditor.column.key, newData);
    guestTable.formatCell(guestTable._oCellEditor.cell);
    guestTable.fireEvent("editorSaveEvent",
    {editor:guestTable._oCellEditor, oldData:oldData, newData:newData, record:guestTable._oCellEditor.record, toSaveOrNot:toSaveOrNot}
            );
}


function getGuestColumnDefs() {

    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                            oRecord.getData(oColumn.key);
        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                      oColumn.editorOptions.dropdownOptions : null;
        for (var i = 0; i < options.length; i++) {
            if (options[i].value == selectedValue) {
                if (selectedValue.length > 0) {
                    el.innerHTML = options[i].text;
                }
                break;
            }
        }
    }

    this.deleteGuestFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = '<img border="0" alt="Delete Guest" src="' + document.getElementById('contextPath').value +
                       '/images/icon_delete.gif">';
        el.style.cursor = 'pointer';
    }

    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
        var rowId = this.getTrEl(el).sectionRowIndex;
        el.innerHTML = rowId + 1;
    }

    this.editTextBox = function (oEditor, oSelf) {
        var oRecord = oEditor.record;
        var oColumn = oEditor.column;
        var elContainer = oEditor.container;
        var value = oRecord.getData(oColumn.key);

        var elTextbox = elContainer.appendChild(document.createElement("input"));
        elTextbox.type = "text";
        elTextbox.style.width = "100px";
        elTextbox.value = value;

        YAHOO.util.Event.addListener(elTextbox, "keydown", function(v) {
            onkeyupEvent(v, elTextbox.value, oColumn, oRecord);
        });

        YAHOO.util.Event.addListener(elTextbox, "focusout", function() {
            onchangeEvent(elTextbox.value, true);
        });
        elTextbox.focus();
        elTextbox.select();
    };

    this.editDropdown = function (oEditor, oSelf) {

        var oRecord = oEditor.record;
        var oColumn = oEditor.column;
        var elContainer = oEditor.container;

        var value = oRecord.getData(oColumn.key);
        var elDropdown = elContainer.appendChild(document.createElement("select"));
        var dropdownOptions = (oColumn.editorOptions && YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                              oColumn.editorOptions.dropdownOptions : [];
        for (var j = 0; j < dropdownOptions.length; j++) {
            var dropdownOption = dropdownOptions[j];
            var elOption = document.createElement("option");
            elOption.value = (YAHOO.lang.isValue(dropdownOption.value)) ? dropdownOption.value : dropdownOption;
            elOption.innerHTML = (YAHOO.lang.isValue(dropdownOption.text)) ? dropdownOption.text : dropdownOption;
            elOption = elDropdown.appendChild(elOption);
            if (value === elDropdown.options[j].value) {
                elDropdown.options[j].selected = true;
            }
        }
        YAHOO.util.Event.addListener(elDropdown, "keydown", function(v) {
            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, false);

            onkeyupEvent(v, elDropdown[elDropdown.selectedIndex].value, oColumn, oRecord);
        });

        YAHOO.util.Event.addListener(elDropdown, "focusout", function() {
            onchangeEvent(elDropdown[elDropdown.selectedIndex].value, true);
        });
        oSelf._focusEl(elDropdown);
    };

    return [
        {label:"", formatter:this.rowNumberFormatter},
        {key:"firstName", label:"<b>First Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
        {key:"lastName", label:"<b>Last Name</b>", editor:this.editTextBox, editorOptions:{disableBtns:true}, sortable:true, resizeable:true},
        {key:"location", label:"<b>Location</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:locationsArray}, sortable:true, resizeable:true},
        {key:"guestState", label:"<b>State</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:statesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
        {key:"guestCountry", label:"<b>Country</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:countriesArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true},
        {key:"guestClassification", label:"<b>Classification</b>", editor:editDropdown, editorOptions:{disableBtns:true, dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter, sortable:true, resizeable:true, width:300},
        {key:"delete", label:"", formatter:this.deleteGuestFormatter}
    ];
}

function getConfirmGuestColumnDefs() {

    this.dropDownFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
        var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                            oRecord.getData(oColumn.key);
        var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                      oColumn.editorOptions.dropdownOptions : null;
        for (var i = 0; i < options.length; i++) {
            if (options[i].value == selectedValue) {
                if (selectedValue.length > 0) {
                    el.innerHTML = options[i].text;
                }
                break;
            }
        }
    }

    this.rowNumberFormatter = function(el, oRecord, oColumn, oData) {
        var rowId = this.getTrEl(el).sectionRowIndex;
        el.innerHTML = rowId + 1;
    }

    return [
        {label:"", formatter:this.rowNumberFormatter},
        {key:"firstName", label:"<b>First Name</b>"},
        {key:"lastName", label:"<b>Last Name</b>"},
        {key:"location", label:"<b>Location</b>", editor:"dropdown", editorOptions:{dropdownOptions:locationsArray}},
        {key:"guestState", label:"<b>State</b>", editor:"dropdown", editorOptions:{dropdownOptions:statesArray}, formatter:this.dropDownFormatter},
        {key:"guestCountry", label:"<b>Country</b>", editor:"dropdown", editorOptions:{dropdownOptions:countriesArray}, formatter:this.dropDownFormatter},
        {key:"guestClassification", label:"<b>Classification</b>", editor:"dropdown", editorOptions:{dropdownOptions:classificationsArray}, formatter:this.dropDownFormatter}
    ];
}

function getGuestTable(columnDefs, dataSource) {

    this.onCellEditSaveGuestValue = function(oArgs) {
        var toSaveOrNot = oArgs.toSaveOrNot;
        var currentCell = oArgs.editor.cell;
        var newData = oArgs.newData;
        var oRecord = oArgs.editor.record;
        var guestRow = this.getTrEl(oRecord);
        var guestTableRowIndex = guestRow.sectionRowIndex;
        confirmGuestTable.updateRow(confirmGuestTable.getTrEl(guestTableRowIndex), oRecord.getData());
        if (oArgs.editor.column.key == 'location') {
            if (newData == 'Domestic') {
                guestRow.cells[4].innerHTML = "";
                oRecord.getData().guestCountry = "";
                guestRow.cells[5].innerHTML = usaCountry;
                YAHOO.util.Dom.addClass(guestRow.cells[4], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
            } else if (newData == 'International') {
                oRecord.getData().guestState = "";
                guestRow.cells[4].innerHTML = naState;
                guestRow.cells[5].innerHTML = "";
                YAHOO.util.Dom.addClass(guestRow.cells[5], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
            } else {
                YAHOO.util.Dom.removeClass(guestRow.cells[4], requiredFieldClass);
                YAHOO.util.Dom.removeClass(guestRow.cells[5], requiredFieldClass);
            }
        }
        if (newData == '') {
            YAHOO.util.Dom.addClass(currentCell, requiredFieldClass);
        } else {
            YAHOO.util.Dom.removeClass(currentCell, requiredFieldClass);
        }

        if (toSaveOrNot) {
            deleteHiddenFields();
            createHiddenFields();
            autosave(document.forms['tourForm']);
        }
    }

    this.onCellClickEvent = function(ev) {
        var target = YAHOO.util.Event.getTarget(ev);
        var column = guestTable.getColumn(target);
        if (column.key == 'delete') {
            var rowId = guestTable.getRow(target).sectionRowIndex;
            deleteGuest(rowId);
        } else {
            guestTable.onEventShowCellEditor(ev);
        }
    }

    guestTable = new YAHOO.widget.DataTable("guestTableDiv", columnDefs, dataSource);
    guestTable.subscribe("cellMouseoverEvent", guestTable.onEventHighlightCell);
    guestTable.subscribe("cellMouseoutEvent", guestTable.onEventUnhighlightCell);
    var addGuestButton = document.getElementById("addRow");
    var disabled = addGuestButton.getAttribute("disabled");
    if (disabled != true) {
        guestTable.subscribe("editorSaveEvent", this.onCellEditSaveGuestValue);
        guestTable.subscribe("cellClickEvent", this.onCellClickEvent);
        guestTable.subscribe("editorBlurEvent", function(oArgs) {
            this.cancelCellEditor();
        });
    }
    return guestTable;
}

function getConfirmGuestTable(columnDefs, dataSource) {
    confirmGuestTable = new YAHOO.widget.DataTable("confirmGuestsDiv", columnDefs, dataSource);
    return confirmGuestTable;
}

function addGuest() {
    var prevRow = guestTable.getLastTrEl();
    var location = '';
    var state = '';
    var country = '';
    var classification = '';

    if (prevRow != null) {//copy previous row's values to the new row
        var lastRecord = guestTable.getRecord(prevRow);
        location = lastRecord.getData().location;
        state = lastRecord.getData().guestState;
        country = lastRecord.getData().guestCountry;
        classification = lastRecord.getData().guestClassification;
    }
    guestTable.addRow({
        firstName:"",
        lastName:"",
        location:location,
        guestState:state,
        guestCountry:country,
        guestClassification:classification
    });

    confirmGuestTable.addRow({
        firstName:"",
        lastName:"",
        location:location,
        guestState:state,
        guestCountry:country,
        guestClassification:classification
    });

    var newRow = guestTable.getLastTrEl();
    if (prevRow != null) {
        if (state == "") {
            state = prevRow.cells[4].innerHTML;//In case previous row had 'Not Applicable' in state column
            newRow.cells[4].innerHTML = state;//In case previous row had 'Not Applicable' in state column
        }

        if (country == "") {
            country = prevRow.cells[5].innerHTML;//In case previous row had 'United States of America' in country column
            newRow.cells[5].innerHTML = country;//In case previous row had 'United States of America' in country column
        }
    }

    var cells = newRow.cells;
    for (var t = 1; t < cells.length - 1; t++) {
        var cell = cells[t];
        YAHOO.util.Dom.addClass(cell, requiredFieldClass);
    }
    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);

    //deleteHiddenFields();
    //createHiddenFields();
    //autosave(document.forms['tourForm']);
}

function deleteGuest(rowId) {
    guestTable.deleteRow(rowId);
    guestTable.refreshView();

    confirmGuestTable.deleteRow(rowId);
    confirmGuestTable.refreshView();

    displayNumberOfGuests(guestTable.getRecordSet().getRecords().length);

    deleteHiddenFields();
    createHiddenFields();
    autosave(document.forms['tourForm']);
}


function showModalSaveMyChangesWarning(status) {
    var handleSubmit = function() {
        saveMyChanges();
    };
    var handleCancel = function() {
        this.cancel();
    };

    if (status != null) {
        var tourStatus = document.getElementById('tourStatus');
        tourStatus.value = status;
    }
    var anotherUserElement = document.getElementById('anotherUserHasUncompleteChanges');
    if (anotherUserElement == null) {
        saveMyChanges();
    } else {
        var message = anotherUserElement.value;
        message = "<b>Are you sure?</b><br/>" + message + "<br/>";
        message += "<b>Clicking on Save Changes will override other user's Incomplete Changes for this tour.</b><br/>";
        var areYouSure =
                new YAHOO.widget.Dialog("modalDialogForSaveMyChanges",
                { width:"400px",
                    fixedcenter:true,
                    close:false,
                    draggable:false,
                    zindex:4,
                    visible:false,
                    modal:true,
                    buttons : [ { text:"Save My Changes", handler:handleSubmit },
                        { text:"Cancel", handler:handleCancel } ]
                }
                        );

        //areYouSure.setHeader("Are you sure?");
        areYouSure.setBody(message);
        areYouSure.render();
        areYouSure.show();
    }
}

function saveMyChanges() {
    document.getElementById('method').value = 'addTour';
    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
    document.forms[0].submit();
}

function saveImportGuestInfo() {
    autosave(document.forms['tourForm']);
    document.getElementById('method').value = 'addTour';
    document.forms[0].action = document.getElementById('contextPath').value + "/servlet/requestTour.htm";
    document.forms[0].submit();

}

//ppsclient.js
//=====================================================================================================================
//DIMENSION GLOBAL SCOPE CLIENT SIDE VARIABLES
//=====================================================================================================================
var oPeoplePicker					//USED TO STORE A REFERENCE TO THE PEOPLE PICKER BROWSER WINDOW OBJECT
var bPeoplePickerIsOpen = false;	//USED TO DENOTE WHETHER THE PEOPLE PICKER WINDOW HAS BEEN OPENED


function Search4People()
{
	//=====================================================================================================================
	//Synopsis: OPENS THE PEOPLE PICKER UTILITY IN A NEW WINDOW
	//
	//   NOTE: loadPeople() MUST exist in this page in order for this feature to work properly.
	//
	//=====================================================================================================================
	// var fieldObject = document.all.hdnPartyID.value;
	//OPEN THE PEOPLE PICKER UTILITY IN A NEW WINDOW
	var lwidth = 600, lheight = 450;
	var ltop = (window.screen.availHeight - lheight)/2;
	var lleft = (window.screen.availWidth - lwidth)/2;

	// changed for getting the people picker url from web.config file.
	var sPickerURL = "/ppsclient/PPService.do?selectable=single";
	//var sPickerURL = document.all.hdnPeoplePickerURL.value;
	// If the party ID is present.
	// if(fieldObject != null || fieldObject != "")
	//	sPickerURL = sPickerURL + "?LoadPeople=1";
	oPeoplePicker = window.open(sPickerURL, "PeoplePicker", "status=1,toolbar=0,location=0,directories=0,menubar=0,resizable=0,scrollbars=yes,width=" + lwidth + ",height=" + lheight + ",top=" + ltop + ",left=" + lleft, true);


	bPeoplePickerIsOpen = true;
	//alert(bPeoplePickerIsOpen);
}


function loadPeople()
{//alert("loadPeople = "+bPeoplePickerIsOpen);
//=====================================================================================================================
//Synopsis: PASSES A LIST OF PEOPLE TO BE LOADED IN THE PEOPLE PICKER
//
//			NOTE: The list passed to the PeoplePicker MUST be a comma delimited list of PeopleDirectory PartyIDs!!!
//			NOTE: This function is called by the People Picker Window after it has been loaded and called with
//				  the querystring parameter: "?LoadPeople=1".  Therefore, this function must be named exactly as is!!!
//=====================================================================================================================
	if (bPeoplePickerIsOpen)
	{//alert("in loadPeople , bPeoplePickerIsOpen = "+bPeoplePickerIsOpen);
		oPeoplePicker.loadPeople(document.all.hdnPartyID.value);	//comma delimited list of PartyIDs passed to People Picker
	}
}


function ClosePopUp()
{
//=====================================================================================================================
//Synopsis: ATTEMPTS TO CLOSE THE PEOPLE PICKER IF IT HAS BEEN OPENED, OTHER WISE NOTHING IS DONE
//=====================================================================================================================
	if (bPeoplePickerIsOpen)
	{
		oPeoplePicker.close();
		bPeoplePickerIsOpen = false;
	}
}


function GetSelectedPeople()
{
    //Check to see if any people were selected, If not return
	var iNumSelPeople = oPeoplePicker.GetNumSelectedPeople_Java();
	var lPersonData = 0;
	var lPersonText = 1;
	var arrPeopleDataFrmPP = new Array();
	var arrPartyIDs = new Array();
	var arrLastNameList = new Array();
	var arrFirstNameList = new Array();
	var arrMiddleNameList = new Array();
	var arrPhoneList = new Array();
	var arrUserIDs	= new Array();
	var arrEmailIDs = new Array();
	var aPeople; // 2 diemensional array
	if(iNumSelPeople > 0)
	{
		// alert('inside getselectedpeople');
		aPeople = oPeoplePicker.GetSelectedPeople_Java();
		// alert('after getselectedpeople');
		var tempStrData;
		var tempStrText;
		var tempArray = new Array();
		for (i = 0; i < aPeople.length; i++)
		{
		// alert('inside loop');
		// alert(aPeople.length);
		//	tempStrData = aPeople[i][lPersonData];
		tempStrData = aPeople[i];
		//	tempStrText = aPeople[i][lPersonText];
		// alert(tempStrData);
		// alert(tempStrText);
			// Person text is separated by '<+>', split using this string to separate
			// Text at 0th position is = Party ID
			// Text at 1st positions is = Email Address
			// Text at 2nd positon is = Name in "Last, First Middel" format
			// Text at 3rd position is = User ID(Lan ID)
			tempArray = tempStrData.split("<+>");
			arrPartyIDs[i] = tempArray[0];
			//alert("Party ID = " + arrPartyIDs[i]);
			arrLastNameList[i] = tempArray[2];
			arrFirstNameList[i] = tempArray[3];
			arrMiddleNameList[i] = tempArray[4];
			//alert("Name List = " + arrNameList[i]);
			arrUserIDs[i] = tempArray[5];
			//alert("User Id = " + arrUserIDs[i]);
			// arrPhoneList[i] = tempStrText.substring(tempStrText.indexOf(":")+1,tempStrText.length);
			arrPhoneList[i] = tempArray[6];
			//alert("Phone number = " + arrPhoneList[i]);
			arrEmailIDs[i] = tempArray[1];
		}
		arrPeopleDataFrmPP[0] = arrPartyIDs;
		arrPeopleDataFrmPP[1] = arrLastNameList;
		arrPeopleDataFrmPP[2] = arrFirstNameList;
		arrPeopleDataFrmPP[3] = arrMiddleNameList;
		arrPeopleDataFrmPP[4] = arrUserIDs;
		arrPeopleDataFrmPP[5] = arrPhoneList;
		arrPeopleDataFrmPP[6] = arrEmailIDs;
	}
	// alert(arrPeopleDataFrmPP);
	setValuesFromPeoplePicker(arrPeopleDataFrmPP)
	//setValuesFromPeoplePickerFirstNameLastName(arrPeopleDataFrmPP)
}

// Commented and moved this code on each page.
// --------------------------------------------------
// Each page specific controls need to modify this section according to their needs
//
//	arrPeopleData
//		index - 0 : party id
//		index - 1 : last name
//		index - 2 : first name
//		index - 3 : middle name
//		index - 4 : user id
//		index - 5 : phone id
//		index - 6 : email
//
// ---------------------------------------------------
//function setValuesFromPeoplePicker(arrPeopleData)
//{
//	document.getElementById("username").value = arrPeopleData[4];
//	document.getElementById("reportInitiator").value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
//	document.getElementById("fromAddress").value = arrPeopleData[6] + "@monsanto.com";
//}

//mcas_common.js
// Common Javascript functions.
	// --------------------------------------------------
	// Each page need to have this method customized to get data from People Picker Utility.
	// Do not change anything other than the html element ids.
	//	arrPeopleData
	//		index - 0 : party id
	//		index - 1 : last name
	//		index - 2 : first name
	//		index - 3 : middle name
	//		index - 4 : user id
	//		index - 5 : phone id
	//		index - 6 : email
	//
	// ---------------------------------------------------
	var usernameConrolId="";
	var fullnameConrolId="";
	var emailConrolId="";
	var phoneControlId="";
	function setValuesFromPeoplePicker(arrPeopleData)
	{
		if (!usernameConrolId=="")
			document.getElementById(usernameConrolId).value = arrPeopleData[4];
		if (!fullnameConrolId=="")
			document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
    if (!emailConrolId=="")
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
		if (!phoneControlId=="")
			document.getElementById(phoneControlId).value = arrPeopleData[5];

    //manually call onchange coz it is not triggered automatically when ppsclient sets values
    if(document.getElementById(fullnameConrolId).onchange != null){
         document.getElementById(fullnameConrolId).onchange();
     }

    document.getElementById(fullnameConrolId).focus();
	}

function setValuesFromPeoplePickerFirstNameLastName(arrPeopleData)
	{
		if (!usernameConrolId=="")
			document.getElementById(usernameConrolId).value = arrPeopleData[4];
		if (!fullnameConrolId==""){
            if (arrPeopleData[3] != "") {
                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[3] + " " + arrPeopleData[1];
            }
            else {
                document.getElementById(fullnameConrolId).value = arrPeopleData[2] + " " + arrPeopleData[1];
            }
        }
        if (!emailConrolId=="")
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
		if (!phoneControlId=="")
			document.getElementById(phoneControlId).value = arrPeopleData[5];

    document.getElementById(fullnameConrolId).focus();
	}
	function setPeoplePickerControlIds(usrname,fullname,email,phone) {
		usernameConrolId=usrname;
		fullnameConrolId=fullname;
		emailConrolId=email;
    phoneControlId=phone;
  }

	function strtrim(s) {
	 //Match spaces at beginning and end of text and replace with null strings
		return s.replace(/^\s+/,'').replace(/\s+$/,'');
	}

//Start niftycorners.js
function NiftyCheck(){
if(!document.getElementById || !document.createElement)
    return(false);
isXHTML=/html\:/.test(document.getElementsByTagName('body')[0].nodeName);
if(Array.prototype.push==null){Array.prototype.push=function(){
      this[this.length]=arguments[0]; return(this.length);}}
return(true);
}

function Rounded(selector,wich,bk,color,opt){
var i,prefixt,prefixb,cn="r",ecolor="",edges=false,eclass="",b=false,t=false;

if(color=="transparent"){
    cn=cn+"x";
    ecolor=bk;
    bk="transparent";
    }
else if(opt && opt.indexOf("border")>=0){
    var optar=opt.split(" ");
    for(i=0;i<optar.length;i++)
        if(optar[i].indexOf("#")>=0) ecolor=optar[i];
    if(ecolor=="") ecolor="#666";
    cn+="e";
    edges=true;
    }
else if(opt && opt.indexOf("smooth")>=0){
    cn+="a";
    ecolor=Mix(bk,color);
    }
if(opt && opt.indexOf("small")>=0) cn+="s";
prefixt=cn;
prefixb=cn;
if(wich.indexOf("all")>=0){t=true;b=true}
else if(wich.indexOf("top")>=0) t="true";
else if(wich.indexOf("tl")>=0){
    t="true";
    if(wich.indexOf("tr")<0) prefixt+="l";
    }
else if(wich.indexOf("tr")>=0){
    t="true";
    prefixt+="r";
    }
if(wich.indexOf("bottom")>=0) b=true;
else if(wich.indexOf("bl")>=0){
    b="true";
    if(wich.indexOf("br")<0) prefixb+="l";
    }
else if(wich.indexOf("br")>=0){
    b="true";
    prefixb+="r";
    }
var v=cssQuery(selector, document);
var l=v.length;
for(i=0;i<l;i++){
    if(edges) AddBorder(v[i],ecolor);
    if(t) AddTop(v[i],bk,color,ecolor,prefixt);
    if(b) AddBottom(v[i],bk,color,ecolor,prefixb);
    }
}

function AddBorder(el,bc){
var i;
if(!el.passed){
    if(el.childNodes.length==1 && el.childNodes[0].nodeType==3){
        var t=el.firstChild.nodeValue;
        el.removeChild(el.lastChild);
        var d=CreateEl("span");
        d.style.display="block";
        d.appendChild(document.createTextNode(t));
        el.appendChild(d);
        }
    for(i=0;i<el.childNodes.length;i++){
        if(el.childNodes[i].nodeType==1){
            el.childNodes[i].style.borderLeft="1px solid "+bc;
            el.childNodes[i].style.borderRight="1px solid "+bc;
            }
        }
    }
el.passed=true;
}

function AddTop(el,bk,color,bc,cn){
var i,lim=4,d=CreateEl("b");

if(cn.indexOf("s")>=0) lim=2;
if(bc) d.className="artop";
else d.className="rtop";
d.style.backgroundColor=bk;
for(i=1;i<=lim;i++){
    var x=CreateEl("b");
    x.className=cn + i;
    x.style.backgroundColor=color;
    if(bc) x.style.borderColor=bc;
    d.appendChild(x);
    }
el.style.paddingTop=0;
el.insertBefore(d,el.firstChild);
}

function AddBottom(el,bk,color,bc,cn){
var i,lim=4,d=CreateEl("b");

if(cn.indexOf("s")>=0) lim=2;
if(bc) d.className="artop";
else d.className="rtop";
d.style.backgroundColor=bk;
for(i=lim;i>0;i--){
    var x=CreateEl("b");
    x.className=cn + i;
    x.style.backgroundColor=color;
    if(bc) x.style.borderColor=bc;
    d.appendChild(x);
    }
el.style.paddingBottom=0;
el.appendChild(d);
}

function CreateEl(x){
if(isXHTML) return(document.createElementNS('http://www.w3.org/1999/xhtml',x));
else return(document.createElement(x));
}

function Mix(c1,c2){
var i,step1,step2,x,y,r=new Array(3);
if(c1.length==4)step1=1;
else step1=2;
if(c2.length==4) step2=1;
else step2=2;
for(i=0;i<3;i++){
    x=parseInt(c1.substr(1+step1*i,step1),16);
    if(step1==1) x=16*x+x;
    y=parseInt(c2.substr(1+step2*i,step2),16);
    if(step2==1) y=16*y+y;
    r[i]=Math.floor((x*50+y*50)/100);
    }
return("#"+r[0].toString(16)+r[1].toString(16)+r[2].toString(16));
}
//End niftycorners.js

//Start cssQuery.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

// the following functions allow querying of the DOM using CSS selectors
var cssQuery = function() {
var version = "2.0.2";

// -----------------------------------------------------------------------
// main query function
// -----------------------------------------------------------------------

var $COMMA = /\s*,\s*/;
var cssQuery = function($selector, $$from) {
try {
    var $match = [];
    var $useCache = arguments.callee.caching && !$$from;
    var $base = ($$from) ? ($$from.constructor == Array) ? $$from : [$$from] : [document];
    // process comma separated selectors
    var $$selectors = parseSelector($selector).split($COMMA), i;
    for (i = 0; i < $$selectors.length; i++) {
        // convert the selector to a stream
        $selector = _toStream($$selectors[i]);
        // faster chop if it starts with id (MSIE only)
        if (isMSIE && $selector.slice(0, 3).join("") == " *#") {
            $selector = $selector.slice(2);
            $$from = _msie_selectById([], $base, $selector[1]);
        } else $$from = $base;
        // process the stream
        var j = 0, $token, $filter, $arguments, $cacheSelector = "";
        while (j < $selector.length) {
            $token = $selector[j++];
            $filter = $selector[j++];
            $cacheSelector += $token + $filter;
            // some pseudo-classes allow arguments to be passed
            //  e.g. nth-child(even)
            $arguments = "";
            if ($selector[j] == "(") {
                while ($selector[j++] != ")" && j < $selector.length) {
                    $arguments += $selector[j];
                }
                $arguments = $arguments.slice(0, -1);
                $cacheSelector += "(" + $arguments + ")";
            }
            // process a token/filter pair use cached results if possible
            $$from = ($useCache && cache[$cacheSelector]) ?
                cache[$cacheSelector] : select($$from, $token, $filter, $arguments);
            if ($useCache) cache[$cacheSelector] = $$from;
        }
        $match = $match.concat($$from);
    }
    delete cssQuery.error;
    return $match;
} catch ($error) {
    cssQuery.error = $error;
    return [];
}};

// -----------------------------------------------------------------------
// public interface
// -----------------------------------------------------------------------

cssQuery.toString = function() {
    return "function cssQuery() {\n  [version " + version + "]\n}";
};

// caching
var cache = {};
cssQuery.caching = false;
cssQuery.clearCache = function($selector) {
    if ($selector) {
        $selector = _toStream($selector).join("");
        delete cache[$selector];
    } else cache = {};
};

// allow extensions
var modules = {};
var loaded = false;
cssQuery.addModule = function($name, $script) {
    if (loaded) eval("$script=" + String($script));
    modules[$name] = new $script();;
};

// hackery
cssQuery.valueOf = function($code) {
    return $code ? eval($code) : this;
};

// -----------------------------------------------------------------------
// declarations
// -----------------------------------------------------------------------

var selectors = {};
var pseudoClasses = {};
// a safari bug means that these have to be declared here
var AttributeSelector = {match: /\[([\w-]+(\|[\w-]+)?)\s*(\W?=)?\s*([^\]]*)\]/};
var attributeSelectors = [];

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// descendant selector
selectors[" "] = function($results, $from, $tagName, $namespace) {
    // loop through current selection
    var $element, i, j;
    for (i = 0; i < $from.length; i++) {
        // get descendants
        var $subset = getElementsByTagName($from[i], $tagName, $namespace);
        // loop through descendants and add to results selection
        for (j = 0; ($element = $subset[j]); j++) {
            if (thisElement($element) && compareNamespace($element, $namespace))
                $results.push($element);
        }
    }
};

// ID selector
selectors["#"] = function($results, $from, $id) {
    // loop through current selection and check ID
    var $element, j;
    for (j = 0; ($element = $from[j]); j++) if ($element.id == $id) $results.push($element);
};

// class selector
selectors["."] = function($results, $from, $className) {
    // create a RegExp version of the class
    $className = new RegExp("(^|\\s)" + $className + "(\\s|$)");
    // loop through current selection and check class
    var $element, i;
    for (i = 0; ($element = $from[i]); i++)
        if ($className.test($element.className)) $results.push($element);
};

// pseudo-class selector
selectors[":"] = function($results, $from, $pseudoClass, $arguments) {
    // retrieve the cssQuery pseudo-class function
    var $test = pseudoClasses[$pseudoClass], $element, i;
    // loop through current selection and apply pseudo-class filter
    if ($test) for (i = 0; ($element = $from[i]); i++)
        // if the cssQuery pseudo-class function returns "true" add the element
        if ($test($element, $arguments)) $results.push($element);
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

pseudoClasses["link"] = function($element) {
    var $document = getDocument($element);
    if ($document.links) for (var i = 0; i < $document.links.length; i++) {
        if ($document.links[i] == $element) return true;
    }
};

pseudoClasses["visited"] = function($element) {
    // can't do this without jiggery-pokery
};

// -----------------------------------------------------------------------
// DOM traversal
// -----------------------------------------------------------------------

// IE5/6 includes comments (LOL) in it's elements collections.
// so we have to check for this. the test is tagName != "!". LOL (again).
var thisElement = function($element) {
    return ($element && $element.nodeType == 1 && $element.tagName != "!") ? $element : null;
};

// return the previous element to the supplied element
//  previousSibling is not good enough as it might return a text or comment node
var previousElementSibling = function($element) {
    while ($element && ($element = $element.previousSibling) && !thisElement($element)) continue;
    return $element;
};

// return the next element to the supplied element
var nextElementSibling = function($element) {
    while ($element && ($element = $element.nextSibling) && !thisElement($element)) continue;
    return $element;
};

// return the first child ELEMENT of an element
//  NOT the first child node (though they may be the same thing)
var firstElementChild = function($element) {
    return thisElement($element.firstChild) || nextElementSibling($element.firstChild);
};

var lastElementChild = function($element) {
    return thisElement($element.lastChild) || previousElementSibling($element.lastChild);
};

// return child elements of an element (not child nodes)
var childElements = function($element) {
    var $childElements = [];
    $element = firstElementChild($element);
    while ($element) {
        $childElements.push($element);
        $element = nextElementSibling($element);
    }
    return $childElements;
};

// -----------------------------------------------------------------------
// browser compatibility
// -----------------------------------------------------------------------

// all of the functions in this section can be overwritten. the default
//  configuration is for IE. The functions below reflect this. standard
//  methods are included in a separate module. It would probably be better
//  the other way round of course but this makes it easier to keep IE7 trim.

var isMSIE = true;

var isXML = function($element) {
    var $document = getDocument($element);
    return (typeof $document.mimeType == "unknown") ?
        /\.xml$/i.test($document.URL) :
        Boolean($document.mimeType == "XML Document");
};

// return the element's containing document
var getDocument = function($element) {
    return $element.ownerDocument || $element.document;
};

var getElementsByTagName = function($element, $tagName) {
    return ($tagName == "*" && $element.all) ? $element.all : $element.getElementsByTagName($tagName);
};

var compareTagName = function($element, $tagName, $namespace) {
    if ($tagName == "*") return thisElement($element);
    if (!compareNamespace($element, $namespace)) return false;
    if (!isXML($element)) $tagName = $tagName.toUpperCase();
    return $element.tagName == $tagName;
};

var compareNamespace = function($element, $namespace) {
    return !$namespace || ($namespace == "*") || ($element.scopeName == $namespace);
};

var getTextContent = function($element) {
    return $element.innerText;
};

function _msie_selectById($results, $from, id) {
    var $match, i, j;
    for (i = 0; i < $from.length; i++) {
        if ($match = $from[i].all.item(id)) {
            if ($match.id == id) $results.push($match);
            else if ($match.length != null) {
                for (j = 0; j < $match.length; j++) {
                    if ($match[j].id == id) $results.push($match[j]);
                }
            }
        }
    }
    return $results;
};

// for IE5.0
if (![].push) Array.prototype.push = function() {
    for (var i = 0; i < arguments.length; i++) {
        this[this.length] = arguments[i];
    }
    return this.length;
};

// -----------------------------------------------------------------------
// query support
// -----------------------------------------------------------------------

// select a set of matching elements.
// "from" is an array of elements.
// "token" is a character representing the type of filter
//  e.g. ">" means child selector
// "filter" represents the tag name, id or class name that is being selected
// the function returns an array of matching elements
var $NAMESPACE = /\|/;
function select($$from, $token, $filter, $arguments) {
    if ($NAMESPACE.test($filter)) {
        $filter = $filter.split($NAMESPACE);
        $arguments = $filter[0];
        $filter = $filter[1];
    }
    var $results = [];
    if (selectors[$token]) {
        selectors[$token]($results, $$from, $filter, $arguments);
    }
    return $results;
};

// -----------------------------------------------------------------------
// parsing
// -----------------------------------------------------------------------

// convert css selectors to a stream of tokens and filters
//  it's not a real stream. it's just an array of strings.
var $STANDARD_SELECT = /^[^\s>+~]/;
var $$STREAM = /[\s#.:>+~()@]|[^\s#.:>+~()@]+/g;
function _toStream($selector) {
    if ($STANDARD_SELECT.test($selector)) $selector = " " + $selector;
    return $selector.match($$STREAM) || [];
};

var $WHITESPACE = /\s*([\s>+~(),]|^|$)\s*/g;
var $IMPLIED_ALL = /([\s>+~,]|[^(]\+|^)([#.:@])/g;
var parseSelector = function($selector) {
    return $selector
    // trim whitespace
    .replace($WHITESPACE, "$1")
    // e.g. ".class1" --> "*.class1"
    .replace($IMPLIED_ALL, "$1*$2");
};

var Quote = {
    toString: function() {return "'"},
    match: /^('[^']*')|("[^"]*")$/,
    test: function($string) {
        return this.match.test($string);
    },
    add: function($string) {
        return this.test($string) ? $string : this + $string + this;
    },
    remove: function($string) {
        return this.test($string) ? $string.slice(1, -1) : $string;
    }
};

var getText = function($text) {
    return Quote.remove($text);
};

var $ESCAPE = /([\/()[\]?{}|*+-])/g;
function regEscape($string) {
    return $string.replace($ESCAPE, "\\$1");
};

// -----------------------------------------------------------------------
// modules
// -----------------------------------------------------------------------

// -------- >>      insert modules here for packaging       << -------- \\

loaded = true;

// -----------------------------------------------------------------------
// return the query function
// -----------------------------------------------------------------------

return cssQuery;

}(); // cssQuery

///end cssQuery.js

///start end CSSQueryLevel2.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

cssQuery.addModule("css-level2", function() {

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// child selector
selectors[">"] = function($results, $from, $tagName, $namespace) {
    var $element, i, j;
    for (i = 0; i < $from.length; i++) {
        var $subset = childElements($from[i]);
        for (j = 0; ($element = $subset[j]); j++)
            if (compareTagName($element, $tagName, $namespace))
                $results.push($element);
    }
};

// sibling selector
selectors["+"] = function($results, $from, $tagName, $namespace) {
    for (var i = 0; i < $from.length; i++) {
        var $element = nextElementSibling($from[i]);
        if ($element && compareTagName($element, $tagName, $namespace))
            $results.push($element);
    }
};

// attribute selector
selectors["@"] = function($results, $from, $attributeSelectorID) {
    var $test = attributeSelectors[$attributeSelectorID].test;
    var $element, i;
    for (i = 0; ($element = $from[i]); i++)
        if ($test($element)) $results.push($element);
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

pseudoClasses["first-child"] = function($element) {
    return !previousElementSibling($element);
};

pseudoClasses["lang"] = function($element, $code) {
    $code = new RegExp("^" + $code, "i");
    while ($element && !$element.getAttribute("lang")) $element = $element.parentNode;
    return $element && $code.test($element.getAttribute("lang"));
};

// -----------------------------------------------------------------------
//  attribute selectors
// -----------------------------------------------------------------------

// constants
AttributeSelector.NS_IE = /\\:/g;
AttributeSelector.PREFIX = "@";
// properties
AttributeSelector.tests = {};
// methods
AttributeSelector.replace = function($match, $attribute, $namespace, $compare, $value) {
    var $key = this.PREFIX + $match;
    if (!attributeSelectors[$key]) {
        $attribute = this.create($attribute, $compare || "", $value || "");
        // store the selector
        attributeSelectors[$key] = $attribute;
        attributeSelectors.push($attribute);
    }
    return attributeSelectors[$key].id;
};
AttributeSelector.parse = function($selector) {
    $selector = $selector.replace(this.NS_IE, "|");
    var $match;
    while ($match = $selector.match(this.match)) {
        var $replace = this.replace($match[0], $match[1], $match[2], $match[3], $match[4]);
        $selector = $selector.replace(this.match, $replace);
    }
    return $selector;
};
AttributeSelector.create = function($propertyName, $test, $value) {
    var $attributeSelector = {};
    $attributeSelector.id = this.PREFIX + attributeSelectors.length;
    $attributeSelector.name = $propertyName;
    $test = this.tests[$test];
    $test = $test ? $test(this.getAttribute($propertyName), getText($value)) : false;
    $attributeSelector.test = new Function("e", "return " + $test);
    return $attributeSelector;
};
AttributeSelector.getAttribute = function($name) {
    switch ($name.toLowerCase()) {
        case "id":
            return "e.id";
        case "class":
            return "e.className";
        case "for":
            return "e.htmlFor";
        case "href":
            if (isMSIE) {
                // IE always returns the full path not the fragment in the href attribute
                //  so we RegExp it out of outerHTML. Opera does the same thing but there
                //  is no way to get the original attribute.
                return "String((e.outerHTML.match(/href=\\x22?([^\\s\\x22]*)\\x22?/)||[])[1]||'')";
            }
    }
    return "e.getAttribute('" + $name.replace($NAMESPACE, ":") + "')";
};

// -----------------------------------------------------------------------
//  attribute selector tests
// -----------------------------------------------------------------------

AttributeSelector.tests[""] = function($attribute) {
    return $attribute;
};

AttributeSelector.tests["="] = function($attribute, $value) {
    return $attribute + "==" + Quote.add($value);
};

AttributeSelector.tests["~="] = function($attribute, $value) {
    return "/(^| )" + regEscape($value) + "( |$)/.test(" + $attribute + ")";
};

AttributeSelector.tests["|="] = function($attribute, $value) {
    return "/^" + regEscape($value) + "(-|$)/.test(" + $attribute + ")";
};

// -----------------------------------------------------------------------
//  parsing
// -----------------------------------------------------------------------

// override parseSelector to parse out attribute selectors
var _parseSelector = parseSelector;
parseSelector = function($selector) {
    return _parseSelector(AttributeSelector.parse($selector));
};

}); // addModule
// end CSSQueryLevel2.js

// start CSSQueryLevel3.js
/*
    cssQuery, version 2.0.2 (2005-08-19)
    Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
    License: http://creativecommons.org/licenses/LGPL/2.1/
*/

/* Thanks to Bill Edney */

cssQuery.addModule("css-level3", function() {

// -----------------------------------------------------------------------
// selectors
// -----------------------------------------------------------------------

// indirect sibling selector
selectors["~"] = function($results, $from, $tagName, $namespace) {
    var $element, i;
    for (i = 0; ($element = $from[i]); i++) {
        while ($element = nextElementSibling($element)) {
            if (compareTagName($element, $tagName, $namespace))
                $results.push($element);
        }
    }
};

// -----------------------------------------------------------------------
// pseudo-classes
// -----------------------------------------------------------------------

// I'm hoping these pseudo-classes are pretty readable. Let me know if
//  any need explanation.

pseudoClasses["contains"] = function($element, $text) {
    $text = new RegExp(regEscape(getText($text)));
    return $text.test(getTextContent($element));
};

pseudoClasses["root"] = function($element) {
    return $element == getDocument($element).documentElement;
};

pseudoClasses["empty"] = function($element) {
    var $node, i;
    for (i = 0; ($node = $element.childNodes[i]); i++) {
        if (thisElement($node) || $node.nodeType == 3) return false;
    }
    return true;
};

pseudoClasses["last-child"] = function($element) {
    return !nextElementSibling($element);
};

pseudoClasses["only-child"] = function($element) {
    $element = $element.parentNode;
    return firstElementChild($element) == lastElementChild($element);
};

pseudoClasses["not"] = function($element, $selector) {
    var $negated = cssQuery($selector, getDocument($element));
    for (var i = 0; i < $negated.length; i++) {
        if ($negated[i] == $element) return false;
    }
    return true;
};

pseudoClasses["nth-child"] = function($element, $arguments) {
    return nthChild($element, $arguments, previousElementSibling);
};

pseudoClasses["nth-last-child"] = function($element, $arguments) {
    return nthChild($element, $arguments, nextElementSibling);
};

pseudoClasses["target"] = function($element) {
    return $element.id == location.hash.slice(1);
};

// UI element states

pseudoClasses["checked"] = function($element) {
    return $element.checked;
};

pseudoClasses["enabled"] = function($element) {
    return $element.disabled === false;
};

pseudoClasses["disabled"] = function($element) {
    return $element.disabled;
};

pseudoClasses["indeterminate"] = function($element) {
    return $element.indeterminate;
};

// -----------------------------------------------------------------------
//  attribute selector tests
// -----------------------------------------------------------------------

AttributeSelector.tests["^="] = function($attribute, $value) {
    return "/^" + regEscape($value) + "/.test(" + $attribute + ")";
};

AttributeSelector.tests["$="] = function($attribute, $value) {
    return "/" + regEscape($value) + "$/.test(" + $attribute + ")";
};

AttributeSelector.tests["*="] = function($attribute, $value) {
    return "/" + regEscape($value) + "/.test(" + $attribute + ")";
};

// -----------------------------------------------------------------------
//  nth child support (Bill Edney)
// -----------------------------------------------------------------------

function nthChild($element, $arguments, $traverse) {
    switch ($arguments) {
        case "n": return true;
        case "even": $arguments = "2n"; break;
        case "odd": $arguments = "2n+1";
    }

    var $$children = childElements($element.parentNode);
    function _checkIndex($index) {
        var $index = ($traverse == nextElementSibling) ? $$children.length - $index : $index - 1;
        return $$children[$index] == $element;
    };

    //    it was just a number (no "n")
    if (!isNaN($arguments)) return _checkIndex($arguments);

    $arguments = $arguments.split("n");
    var $multiplier = parseInt($arguments[0]);
    var $step = parseInt($arguments[1]);

    if ((isNaN($multiplier) || $multiplier == 1) && $step == 0) return true;
    if ($multiplier == 0 && !isNaN($step)) return _checkIndex($step);
    if (isNaN($step)) $step = 0;

    var $count = 1;
    while ($element = $traverse($element)) $count++;

    if (isNaN($multiplier) || $multiplier == 1)
        return ($traverse == nextElementSibling) ? ($count <= $step) : ($step >= $count);

    return ($count % $multiplier) == $step;
};

}); // addModule

//end CSSQueryLevel3.js

//start JSAN.js
/*

*/

var JSAN = function () { JSAN.addRepository(arguments) }

JSAN.VERSION = 0.10;

/*

*/

JSAN.globalScope   = self;
JSAN.includePath   = ['.', 'lib'];
JSAN.errorLevel    = "none";
JSAN.errorMessage  = "";
JSAN.loaded        = {};

/*

*/

JSAN.use = function () {
    var classdef = JSAN.require(arguments[0]);
    if (!classdef) return null;

    var importList = JSAN._parseUseArgs.apply(JSAN, arguments).importList;
    JSAN.exporter(classdef, importList);

    return classdef;
}

/*

*/

JSAN.require = function (pkg) {
    var path = JSAN._convertPackageToPath(pkg);
    if (JSAN.loaded[path]) {
        return JSAN.loaded[path];
    }

    try {
        var classdef = eval(pkg);
        if (typeof classdef != 'undefined') return classdef;
    } catch (e) { /* nice try, eh? */ }


    for (var i = 0; i < JSAN.includePath.length; i++) {
        var js;
        try{
            var url = JSAN._convertPathToUrl(path, JSAN.includePath[i]);
                js  = JSAN._loadJSFromUrl(url);
        } catch (e) {
            if (i == JSAN.includePath.length - 1) throw e;
        }
        if (js != null) {
            var classdef = JSAN._createScript(js, pkg);
            if(classdef!=null){
              JSAN.loaded[path] = classdef;
              return classdef;
            }
        }
    }
    return false;

}

/*

*/

JSAN.exporter = function () {
    JSAN._exportItems.apply(JSAN, arguments);
}

/*

*/

JSAN.addRepository = function () {
    var temp = JSAN._flatten( arguments );
    // Need to go in reverse to do something as simple as unshift( @foo, @_ );
    for ( var i = temp.length - 1; i >= 0; i-- )
        JSAN.includePath.unshift(temp[i]);
    return JSAN;
}

JSAN._flatten = function( list1 ) {
    var list2 = new Array();
    for ( var i = 0; i < list1.length; i++ ) {
        if ( typeof list1[i] == 'object' ) {
            list2 = JSAN._flatten( list1[i], list2 );
        }
        else {
            list2.push( list1[i] );
        }
    }
    return list2;
};

JSAN._findMyPath = function () {
    if (document) {
        var scripts = document.getElementsByTagName('script');
        for ( var i = 0; i < scripts.length; i++ ) {
            var src = scripts[i].getAttribute('src');
            if (src) {
                var inc = src.match(/^(.*?)\/?JSAN.js/);
                if (inc && inc[1]) {
                    var repo = inc[1];
                    for (var j = 0; j < JSAN.includePath.length; j++) {
                        if (JSAN.includePath[j] == repo) {
                            return;
                        }
                    }
                    JSAN.addRepository(repo);
                }
            }
        }
    }
}
JSAN._findMyPath();

JSAN._convertPathToUrl = function (path, repository) {
    return repository.concat('/' + path);
};


JSAN._convertPackageToPath = function (pkg) {
    var path = pkg.replace(/\./g, '/');
        path = path.concat('.js');
    return path;
}

JSAN._parseUseArgs = function () {
    var pkg        = arguments[0];
    var importList = [];

    for (var i = 1; i < arguments.length; i++)
        importList.push(arguments[i]);

    return {
        pkg:        pkg,
        importList: importList
    }
}

JSAN._loadJSFromUrl = function (url) {
	return new JSAN.Request().getText(url);
}

JSAN._findExportInList = function (list, request) {
    if (list == null) return false;
    for (var i = 0; i < list.length; i++)
        if (list[i] == request)
            return true;
    return false;
}

JSAN._findExportInTag = function (tags, request) {
    if (tags == null) return [];
    for (var i in tags)
        if (i == request)
            return tags[i];
    return [];
}

JSAN._exportItems = function (classdef, importList) {
    var exportList  = new Array();
    var EXPORT      = classdef.EXPORT;
    var EXPORT_OK   = classdef.EXPORT_OK;
    var EXPORT_TAGS = classdef.EXPORT_TAGS;

    if (importList.length > 0) {
       importList = JSAN._flatten( importList );

       for (var i = 0; i < importList.length; i++) {
            var request = importList[i];
            if (   JSAN._findExportInList(EXPORT,    request)
                || JSAN._findExportInList(EXPORT_OK, request)) {
                exportList.push(request);
                continue;
            }
            var list = JSAN._findExportInTag(EXPORT_TAGS, request);
            for (var i = 0; i < list.length; i++) {
                exportList.push(list[i]);
            }
        }
    } else {
        exportList = EXPORT;
    }
    JSAN._exportList(classdef, exportList);
}

JSAN._exportList = function (classdef, exportList) {
    if (typeof(exportList) != 'object') return null;
    for (var i = 0; i < exportList.length; i++) {
        var name = exportList[i];

        if (JSAN.globalScope[name] == null)
            JSAN.globalScope[name] = classdef[name];
    }
}

JSAN._makeNamespace = function(js, pkg) {
    var spaces = pkg.split('.');
    var parent = JSAN.globalScope;
    eval(js);
    var classdef = eval(pkg);
    for (var i = 0; i < spaces.length; i++) {
        var name = spaces[i];
        if (i == spaces.length - 1) {
            if (typeof parent[name] == 'undefined') {
                parent[name] = classdef;
                if ( typeof classdef['prototype'] != 'undefined' ) {
                    parent[name].prototype = classdef.prototype;
                }
            }
        } else {
            if (parent[name] == undefined) {
                parent[name] = {};
            }
        }

        parent = parent[name];
    }
    return classdef;
}

JSAN._handleError = function (msg, level) {
    if (!level) level = JSAN.errorLevel;
    JSAN.errorMessage = msg;

    switch (level) {
        case "none":
            break;
        case "warn":
            alert(msg);
            break;
        case "die":
        default:
            throw new Error(msg);
            break;
    }
}

JSAN._createScript = function (js, pkg) {
    try {
        return JSAN._makeNamespace(js, pkg);
    } catch (e) {
        JSAN._handleError("Could not create namespace[" + pkg + "]: " + e);
    }
    return null;
}


JSAN.prototype = {
    use: function () { JSAN.use.apply(JSAN, arguments) }
};


// Low-Level HTTP Request
JSAN.Request = function (jsan) {
    if (JSAN.globalScope.XMLHttpRequest) {
        this._req = new XMLHttpRequest();
    } else {
        this._req = new ActiveXObject("Microsoft.XMLHTTP");
    }
}

JSAN.Request.prototype = {
    _req:  null,
    _useIframe: false,
    _tempIFrame: null,
    _loaded: false,

    getText: function (url) {
        if (!this._useIframe) {
          try {
            this._req.open("GET", url, false);
          } catch (e) {
            return this.readFile(url);
          }
          try {
	            this._req.send(null);
	            if (this._req.status == 200 || this._req.status == 0)
	                return this._req.responseText;
	        } catch (e) {
	            JSAN._handleError("File not found: " + url);
	            return null;
	        };

	        JSAN._handleError("File not found: " + url);
	        return null;
	    }

		var _content = "";
	    if (!this._tempIFrame) {
			this._tempIFrame = document.createElement('iframe');
		    this._tempIFrame.src = "http://localhost:8080/summaryreports/" + url;
		    this._tempIFrame.setAttribute('id', 'jsSrc');
			this._tempIFrame.style.border='0px';
			this._tempIFrame.style.width='30px';
			this._tempIFrame.style.height='30px';
			alert(this._tempIFrame.innerHTML);
			var _self = this;
			this._tempIFrame.onload = function() {
				_content = _self.getContent();
			}
			document.getElementById('content').appendChild(this._tempIFrame);
		}
	    if (_content == "") {
	    	if (confirm(document.getElementById('jsSrc').innerHTML + " continue?")) {
		    	this.getText(url);
		    }
	    }
		alert("js returned from iframe = " + this._tempIFrame.contentDocument.childNodes[1].innerTEXT);
	    return this._tempIFrame.contentDocument.childNodes[1].innerTEXT;
    },

    getContent: function() {
    	alert("content loaded.");
    	this._loaded = true;
    	return this._tempIFrame.contentDocument.childNodes[1].innerTEXT;
    },

    readFile: function(url) {
       var oFS = new ActiveXObject("Scripting.FileSystemObject")
       var contents = null;
       var currentLocation = window.location.href;
       var locarray = currentLocation.split("/");
       locarray.splice(locarray.length - 1, locarray.length);
       var arraytext = locarray.join("/");
       arraytext = arraytext.replace(/%20/g, " ").replace(/file:\/\/\//, "") + '/' + url;
       if (oFS.fileExists(arraytext)) {
          var oTextStream = oFS.openTextFile(arraytext,1);
          contents = oTextStream.readAll();
          oTextStream.close();
          oTextStream = null;
       } else {
          JSAN._handleError("File not found: " + url);
       }
       oFS = null;
       return contents;
    }
};

/*

*/
//end JSAN.js

//start autoSave.js
var http_request = false;

function sendSyncRequest(url) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, false);
    http_request.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
    http_request.onreadystatechange = function() {
        if (http_request.readyState == 4) {
            callbackMethodAfterSync();
        }
    }

    http_request.send();
}

function callbackMethodAfterSync() {
    var autosaveSessionId = http_request.responseText;
//  autosaveSessionId = autosaveSessionId.replace("\r\n", '');
    document.getElementById('__AUTOSAVE_SESSION_ID').value = autosaveSessionId;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = 0;
    var itemId = this.document.getElementById('__AUTOSAVE_ITEM_ID').value;
    if (itemId == "" || itemId == "null") {
        itemId = "NEW" + autosaveSessionId;
        document.getElementById('__AUTOSAVE_ITEM_ID').value = itemId;
        document.getElementById('incompleteNewTourId').value = itemId;
    }
}

function sendAsyncRequest(url, parameters, callbackfunction) {
    http_request = false;
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            //http_request.overrideMimeType('text/xml');
            http_request.overrideMimeType('text/html');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
            }
        }
    }
    if (!http_request) {
        alert('Cannot create XMLHTTP instance');
        return false;
    }
    http_request.open('POST', url, true);
    http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http_request.setRequestHeader("Content-length", parameters.length);
//    http_request.onreadystatechange = callbackMethodAfterAsync;
    http_request.onreadystatechange = callbackfunction;
    http_request.send(parameters);
}

function callbackMethodAfterAsync() {
    if (http_request.readyState == 4) {
        if (http_request.status == 200) {
            var okAfterAutosave = http_request.responseText;
            if (okAfterAutosave.indexOf('OK') >= 0) {
                document.getElementsByName('discardChanges')[0].disabled = false;
                document.getElementsByName('discardChanges')[1].disabled = false;
                var saveChangesButton = document.getElementsByName('saveChanges');
                if (saveChangesButton.length > 0) {
                    document.getElementsByName('saveChanges')[0].disabled = false;
                    document.getElementsByName('saveChanges')[1].disabled = false;
                }
//          var submitChangesButton = document.getElementsByName('submitChanges');
                //          if(submitChangesButton.length > 0){
                //            document.getElementsByName('submitChanges')[0].disabled = false;
                //            document.getElementsByName('submitChanges')[1].disabled = false;
                //          }
                //          this.document.getElementById('currentUserHasIncompleteChanges').innerHTML = "You have incomplete changes from autosave";
                document.getElementById('currentUserHasIncompleteChanges').style.display = "";
            }
        }
    }


}

function getQueryStringForAutosave(obj) {
    var getstr = "";
    for (i = 0; i < obj.childNodes.length; i++) {
        if (obj.childNodes[i].tagName.toLowerCase() == "input") {
            if (obj.childNodes[i].type == "text") {
                getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
            }

            if (obj.childNodes[i].type.toLowerCase() == "checkbox") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                } else {
                    getstr += obj.childNodes[i].name + "=&";
                }
            }
            if (obj.childNodes[i].type.toLowerCase() == "radio") {
                if (obj.childNodes[i].checked) {
                    getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
                }
            }
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "select") {
            var sel = obj.childNodes[i];
            getstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
        }
        if (obj.childNodes[i].tagName.toLowerCase() == "textarea") {
            getstr += obj.childNodes[i].name + "=" + obj.childNodes[i].value + "&";
        }
    }
    return getstr;
}

function getQueryStringForAutosaveForEntireForm(frm) {
    var getstr = "";
    for (i = 0; i < frm.elements.length; i++) {
        var frmElement = frm.elements[i];
        if (frmElement.tagName.toLowerCase() == "input") {
            if (frmElement.type == "text") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type == "hidden") {
                getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
            }
            if (frmElement.type.toLowerCase() == "checkbox") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                } else {
                    getstr += frmElement.name + "=&";
                }
            }
            if (frmElement.type.toLowerCase() == "radio") {
                if (frmElement.checked) {
                    getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
                }
            }
        }
        if (frmElement.tagName.toLowerCase() == "select") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.options[frmElement.selectedIndex].value) + "&";
        }
        if (frmElement.tagName.toLowerCase() == "textarea") {
            getstr += frmElement.name + "=" + encodeURIComponent(frmElement.value) + "&";
        }
    }
    return getstr;
}

function startSessionIfNotAlreadyStarted() {
    var autosaveSessionId = document.getElementById('__AUTOSAVE_SESSION_ID').value;
    if (autosaveSessionId == null || autosaveSessionId == "") {
        startAutosaveSession();
    }
}

function autosave(formObj) {
    startSessionIfNotAlreadyStarted();
    var autosaveSeqStr = document.getElementById('__AUTOSAVE_SESSION_SEQ').value;
    var autosaveSeq = parseInt(autosaveSeqStr);
    autosaveSeq += 1;
    document.getElementById('__AUTOSAVE_SESSION_SEQ').value = autosaveSeq;
    var getstr = getQueryStringForAutosaveForEntireForm(formObj);
    sendAsyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=SAVE', getstr, callbackMethodAfterAsync);
}

function startAutosaveSession() {
    sendSyncRequest('/tourtrackingsystem/servlet/ttsAutoSave?__AUTOSAVE_ACTION=START');
}
//end autoSave.js

// start semnEmailToRequestorAndHostCallBack.js
function sendEmailToRequestorAndHostCallBack(){
    if (http_request.readyState == 4) {
        if (http_request.status == 200) {
            var emailSentStatus = http_request.responseText;
            if (emailSentStatus.indexOf('OK') >= 0) {
                //document.getElementById('reminderEmailSent').style.display = "";
                alert('Reminder Email Sent');
            }
            else if (emailSentStatus.indexOf('FAILURE')) {
                alert('Error Sending Email, Ensure Requestor/Host Email Addresses Are Valid');
            }
        }
    }
}
//end sendEmailToRequestorAndHost()

//Start sendEmailToRequestorAndHost()
 function sendEmailToRequestorAndHost(){
     var tourId = document.getElementById('tourId').value;
     var url =   '/tourtrackingsystem/servlet/sendReminderEmail?tourId='+tourId;
     sendAsyncRequest(url, tourId, sendEmailToRequestorAndHostCallBack );
 }
//end sendEmailToRequestor.js

//Start NamespaceUtils.js
// Create each namespace in the path if it doesn't already exists.
if (typeof Lib == 'undefined') {
    Lib = {};
}

if (!Lib.Utils) {
    Lib.Utils = {};
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description:
*   This is a javascript object that performs utility functions on a namespace.
*/
Lib.Utils.NamespaceUtils = {};

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description: This method takes a namespace classpath and creates any levels of the namespace that have not already
*   been created.
*
*   ie: 'Lib.Utils.JSAN'
*
* @param classpath - String representing a namespace path.
*/
Lib.Utils.NamespaceUtils.createIfNecessary = function(classpath) {
    var namespaces = classpath.split('.');
    var currentNamespace = "";
    for (var i = 0; i < namespaces.length; i++) {
        currentNamespace = currentNamespace + namespaces[i];
        var classdef;
        try {
            classdef = eval(currentNamespace);
        } catch (e) {
            this.createNewNamespace(currentNamespace);
        }
        if (typeof classdef == 'undefined') {
            this.createNewNamespace(currentNamespace);
        }
        currentNamespace = currentNamespace + ".";
    }
}

Lib.Utils.NamespaceUtils.createNewNamespace = function(namespace) {
    eval(namespace + " = {}");
}
//End NamespaceUtils.js


//Start Lib.Utils.ObjectUtils.js

JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* description:
*   This object is used to perform utility operations on objects.
*/
Lib.Utils.ObjectUtils = {};

// Array of context objects used for binding.
Lib.Utils.ObjectUtils.CTX_OBJECTS = new Array();

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method returns whether the specified parameter is an object.
*
* @param object - Parameter to check.
*/
Lib.Utils.ObjectUtils.isObject = function(object) {
    if (typeof object == 'object') {
        return true;
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method provides the ability to subclass javascript objects.  You just pass it the would be child and the parent
*   and it grants the child inheritance.
*
* @param child - Child object.
* @param parent - Parent object to extend.
*/
Lib.Utils.ObjectUtils.extend = function(child, parent) {
    for (var property in parent) {
        child[property] = parent[property];
    }
    return child;
}

/**
* author: Nate Minshew
* date created: 03/28/2006
* access level: public
* description:
*   This method binds the specified function to the specified context using a weak bind pattern.  Weak binds reduce
*   memory leaks that occur in IE when having circular dependencies on the DOM.  This creates an indirect reference
*   between the function and it's context.
*
* @param fn - Function to bind.
* @param ctx - Context object to find the function to.
* @return Function representing the original function with a weak binding to the context object.
*/
Lib.Utils.ObjectUtils.weakBind = function(fn, ctx) {
    var index = Lib.Utils.ObjectUtils.CTX_OBJECTS.length;
    Lib.Utils.ObjectUtils.CTX_OBJECTS.push(ctx);
    return Lib.Utils.ObjectUtils._bindIndexAndReturnFunction(fn, index);
}

/**
* author: Nate Minshew
* date created: 03/28/2006
* access level: non-public
* description:
*   This method takes the specified function and weakly binds it to the context object represented by the specified
*   index.
*
* @param fn - Function to bind.
* @param index - Representing the index of the context object.
* @return Function representing the original function with a weak binding to the context object.
*/
Lib.Utils.ObjectUtils._bindIndexAndReturnFunction = function(fn, index) {
    return function() {
        var ctx = Lib.Utils.ObjectUtils.CTX_OBJECTS[index];
        fn.apply(ctx, arguments);
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method clears all cached context objects.  This is important to call on unload events to prevent memory leaks.
*/
Lib.Utils.ObjectUtils.clearContextObjects = function() {
    Lib.Utils.ObjectUtils.CTX_OBJECTS = new Array();
}

/**
* author: Nate Minshew
* date created: 04/11/2006
* access level: public
* description:
*   This method returns whether the specified object/property is defined and not null.
*
* @param obj - object/property to check.
* @param boolean - Representing if the object/property is defined.
*/
Lib.Utils.ObjectUtils.isDefined = function(obj) {
    if (typeof obj != 'undefined' && obj != null) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 03/06/2006
* description:
*   This object contains utility methods for performing tasks on an array.
*/
Lib.Utils.ObjectUtils.ArrayUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method returns whether the specified object is an array.
*
* @param object - The object to check.
*/
Lib.Utils.ObjectUtils.ArrayUtils.isArray = function(object) {
    if (Lib.Utils.ObjectUtils.isObject(object) && typeof object.length != 'undefined') {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 03/06/2006
* access level: public
* description:
*   This method returns a boolean representing if the specified entry is contained within the specified array.
*
* @param array - Array object.
* @param entry - Value to check array for.
* @return boolean - Representing if the array contains the entry.
*/
Lib.Utils.ObjectUtils.ArrayUtils.contains = function(array, entry) {
    for (var i = 0; Lib.Utils.ObjectUtils.ArrayUtils.isArray(array) && i < array.length; i++) {
        if (array[i] == entry) {
            return true;
        }
    }
    return false;
}
//End Lib.Utils.ObjectUtils.js



//Start Lib.Utils.EventUtils.js
/**
* created by: Nate Minshew
* date created: 09/06/2005
* description: This is a javascript class that handles modifying events on javascript objects.  It allows you to add
*   and remove multiple events like 'onclick' and 'onchange' to html elements.  This is provided in replace of changing
*   the function that the event is set to, for example:
*
*   window.onload = function () { ... };
*
*   This is bad because no other object can now set onload events without overridding the current event.  This class
*   solves that problem.
*/
Lib.Utils.EventUtils = {};

// This array represents events in the global context.
Lib.Utils.EventUtils.EVENTS = new Array();

/**
* created by: Nate Minshew
* date created: 09/06/2005
* access level: public
* description: Adds an event to the specified object.
*
* obj - Object the event is to be applied to.
* type - Type of event to add, ei. 'click' for 'onclick'.
* fn - Function to call for the event.
* ctxObj - Object representing the context to weakly bind to the specified event.
*/
Lib.Utils.EventUtils.addEvent = function(obj, type, fn, ctxObj) {
    if (typeof ctxObj != 'undefined' && ctxObj != null) {
        fn = Lib.Utils.ObjectUtils.weakBind(fn, ctxObj);
    }

    if (obj.addEventListener) {
        obj.addEventListener(type, fn, false);
        var id = Lib.Utils.EventUtils.EVENTS.length;
        Lib.Utils.EventUtils.EVENTS.push(fn);
        return id;
    } else if (obj.attachEvent) {
        var r = obj.attachEvent("on" + type, fn);
        var id = Lib.Utils.EventUtils.EVENTS.length;
        Lib.Utils.EventUtils.EVENTS.push(fn);
        return id;
    } else {
        return -1;
    }
}

/**
* created by: Nate Minshew
* date created: 09/06/2005
* access level: public
* description: Removes an event from the specified object.
*
* obj - Object the event is to be removed from.
* type - Type of event to remove, ei. 'click' for 'onclick'.
* id - integer representing the event to remove.
*/
Lib.Utils.EventUtils.removeEvent = function(obj, type, id) {
    var fn = Lib.Utils.EventUtils.EVENTS[id];
    if (obj.removeEventListener) {
        obj.removeEventListener(type, fn, false);
        return true;
    } else if (obj.detachEvent) {
        var r = obj.detachEvent("on" + type, fn);
        return r;
    } else {
        return false;
    }
}

/**
* created by: Nate Minshew
* date created: 03/30/2006
* access level: public
* description:
*   This method cancels the default action taken by the specified event.
*
* @param event - Event containing the action to cancel.
*/
Lib.Utils.EventUtils.cancelDefaultAction = function(event) {
    if (Lib.Utils.ObjectUtils.isDefined(event) && Lib.Utils.ObjectUtils.isDefined(event.preventDefault)) {
        event.preventDefault();
    } else if (Lib.Utils.ObjectUtils.isDefined(event)) {
        event.returnValue = false;
    }
}

/**
* created by: Nate Minshew
* date created: 03/30/2006
* access level: public
* description:
*   This method cancels event bubbling for the specified event.  This means that any other actions tied to the event at
*   a higher level will be canceled.
*
* @param event - Event object to cancel bubbling on.
*/
Lib.Utils.EventUtils.cancelEventBubbling = function(event) {
    if (Lib.Utils.ObjectUtils.isDefined(event) && Lib.Utils.ObjectUtils.isDefined(event.stopPropagation)) {
        event.stopPropagation();
    } else if (Lib.Utils.ObjectUtils.isDefined(event)) {
        event.cancelBubble = true;
    }
}

//end Lib.Utils.EventUtils

//start Lib.Utils.StringUtils.js
/**
* author: Nate Minshew
* date created: 11/22/2006
* description:
*   This object is a utility object for performing actions on strings.
*/
Lib.Utils.StringUtils = {}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method trims the specified string of leading and ending whitespace.
*
* @param value - String representing the value to trim.
* @return String representing the trimmed value.
*/
Lib.Utils.StringUtils.trim = function(value) {
  var leftTrimExp = /\s*((\S+\s*)*)/;
  var rightTrimExp = /((\s*\S+)*)\s*/;
  return value.replace(leftTrimExp, "$1").replace(rightTrimExp, "$1");
}
//end Lib.Utils.StringUtils.js

//start Lib.Utils.XML.XMLUtils.js
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("Lib.Utils.ObjectUtils");
JSAN.use("Lib.Utils.StringUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils.XML");


/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description: This is a static javascript class for defining XML/DOM utility functions.
*/
Lib.Utils.XML.XMLUtils = {};

/**
* author: James Estes
* date created: 10/06/2005
* access level: public
* description:
*   This method inserts the specified element before the referenced element.
*
* element = DOM Element representing the element you wish to insert.
* reference = DOM Element representing the next sibling element in the document.
*/
Lib.Utils.XML.XMLUtils.insertBefore = function(element, reference) {
    if(reference.insertAdjacentElement) {
        reference.insertAdjacentElement('beforeBegin', element);
    } else {
        reference.parentNode.insertBefore(element, reference);
    }
}

/**
* author: James Estes
* date created: 11/05/2005
* access level: public
* description:
*   This method inserts the specified element after the referenced element.
*
* element - DOM Element representing the element to add.
* reference - DOM Element representing the element to insert after.
*/
Lib.Utils.XML.XMLUtils.insertAfter = function(element, reference) {
    if (reference.insertAdjacentElement ) {
        reference.insertAdjacentElement('afterEnd', element);
    } else if (reference.nextSibling) {
        reference.parentNode.insertBefore(element, reference.nextSibling);
    } else {
        reference.parentNode.appendChild(element);
    }
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   This method returns the first child element in the specified element.
*
* element - DOM Element representing the parent element.
*/
Lib.Utils.XML.XMLUtils.getFirstElementNode = function(element) {
    var children = element.childNodes;
    for(var i = 0; i < children.length; i++) {
        if(children[i].nodeType == 1) {
            return children[i];
        }
    }
    return null;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This method returns the next sibling to the specified element.
*
* origin - Origin element.
*/
Lib.Utils.XML.XMLUtils.getNextSibling = function(origin) {
	while (origin.nextSibling.nodeType != 1) {
		origin = origin.nextSibling;
	}

	return origin.nextSibling;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/06/2006
* access level: public
* description:
*   This method retrieves the previous sibling to the specified element.
*
* @param origin - Origin element.
*/
Lib.Utils.XML.XMLUtils.getPrevSibling = function(origin) {
    while (origin.previousSibling.nodeType != 1) {
        origin = origin.previousSibling;
    }

    return origin.previousSibling;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/25/2005
* access level: public
* description:
*   This method removes all child nodes of the given element.
*
* element - Element to clear.
*/
Lib.Utils.XML.XMLUtils.removeAllChildren = function(element) {
    while (element.childNodes.length && element.childNodes.length > 0) {
        element.removeChild(element.lastChild);
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/18/2006
* access level: public
* description:
*   This method returns whether the specified element contains child nodes.
*
* @param element - Element to check.
*/
Lib.Utils.XML.XMLUtils.hasChildren = function(element) {
    if (typeof element != 'undefined'
            && element != null
            && typeof element.childNodes != 'undefined'
            && element.childNodes.length > 0) {
        return true;
    }

    return false;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/18/2006
* access level: public
* description:
*   This method returns the value of the specified element.  It returns an empty string if the element has no value.
*
* @param element - Representing the element to retrieve the value from.
*/
Lib.Utils.XML.XMLUtils.getElementValue = function(element) {
    var value = '';
    if (this.hasChildren(element)) {
        for (var i = 0; i < element.childNodes.length; i++) {
            if (element.childNodes[i].nodeType == 3) {
                value = value + element.childNodes[i].nodeValue;
            }
        }
    }
    return value;
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method is used to convert and xml node into a string representation of the xml.
*
* @param node - Representing the xml node.
* @return String - String representation of the node.
*/
Lib.Utils.XML.XMLUtils.convertXmlToString = function(node) {
  if (Lib.Utils.ObjectUtils.isDefined(node.xml)) {
    return Lib.Utils.StringUtils.trim(node.xml);
  }
  var serializer = new XMLSerializer();
  return serializer.serializeToString(node);
}
//end Lib.Utils.XML.XMLUtils.js

//start WST.View.FooterView.js
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is a view object for the footer.  It handles interacting with the html document and setting up any
*   events.
*
* @param footerElement - Root html element of the footer.
* @param dateUtils - Date utility object.
*/
WST.View.FooterView = function(footerElement, dateUtils) {
    this._footerElement = footerElement;
    this._dateUtils = dateUtils;
    this._setCurrentDate();
    this._setLastModifiedDate();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the current date on the page.
*/
WST.View.FooterView.prototype._setCurrentDate = function() {
    var currentDateElement = cssQuery('#currentDateValue', this._footerElement)[0];
    if (currentDateElement.childNodes.length > 0) {
        currentDateElement.firstChild.nodeValue = this._dateUtils.getFormattedDate(new Date());
    } else {
        currentDateElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDate(new Date())));
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method sets the last modified date on the page.
*/
WST.View.FooterView.prototype._setLastModifiedDate = function() {
    var lastModifiedElement = cssQuery('#lastModifiedDateValue', this._footerElement)[0];
    if (lastModifiedElement.childNodes.length > 0) {
        lastModifiedElement.firstChild.nodeValue = this._dateUtils.getFormattedDateTime(new Date(document.lastModified));
    } else {
        lastModifiedElement.appendChild(document.createTextNode(this._dateUtils.getFormattedDateTime(new Date(document.lastModified))));
    }
}
//end WST.View.FooterView.js

//start WST.Utils.DateUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Utils");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is used to perform date functions.
*/
WST.Utils.DateUtils = function() {
}

// Array of formatted month names.
WST.Utils.DateUtils.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];
// Array of formatted weekday names.
WST.Utils.DateUtils.WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method formats the specified date object as a date string.
*
* @param date - Date object representing the date.
* @return string - Representing the date.
*/
WST.Utils.DateUtils.prototype.getFormattedDate = function(date) {
    var weekday = WST.Utils.DateUtils.WEEK_DAYS[date.getDay()];
    var month = WST.Utils.DateUtils.MONTHS[date.getMonth()];
    var year = date.getFullYear();
    var day = date.getDate();
    return weekday + ", " + month + " " + day + ", " + year;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the specified date object as a date/time string.
*
* @param date - Date object representing the date.
* @return string - Representing the date and time.
*/
WST.Utils.DateUtils.prototype.getFormattedDateTime = function(date) {
    var dateString = this.getFormattedDate(date);
    var hours = this.getFormattedHours(date);
    var minutes = this.getFormattedMinutes(date);
    var ampm = this.getAMPM(date);
    return dateString + ", " + hours + ":" + minutes + " " + ampm;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the minutes of the specified date object formatted as a 2 digit string.
*
* @param date - Date object representing the date.
* @return string - Representing the formatted minutes.
*/
WST.Utils.DateUtils.prototype.getFormattedMinutes = function(date) {
    if (date.getMinutes() < 10) {
        return "0" + date.getMinutes();
    }
    return date.getMinutes();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns am or pm based on the specified date object.
*
* @param date - Date object representing the date and time.
* @return string - Representing whether it is am or pm.
*/
WST.Utils.DateUtils.prototype.getAMPM = function(date) {
    if (date.getHours() >= 12) {
        return "pm";
    }
    return "am";
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the hour for the specified date based on the 12 hour clock.
*
* @param date - Date object representing the date and time.
* @return string - Representing the hour.
*/
WST.Utils.DateUtils.prototype.getFormattedHours = function(date) {
    if (date.getHours() > 12) {
        return date.getHours() - 12;
    }
    return date.getHours();
}

WST.Utils.DateUtils.prototype.getFormattedDateRange = function(startDate, startTime, endDate, endTime) {
    var formattedDate = this.getFormattedSummarizedDate(startDate);
    if (Lib.Utils.ObjectUtils.isDefined(startTime)) {
        formattedDate = formattedDate + " " + startTime;
    }
    formattedDate = formattedDate + " - ";
    if (Lib.Utils.ObjectUtils.isDefined(endDate)) {
        formattedDate = formattedDate + this.getFormattedSummarizedDate(endDate);
        if (Lib.Utils.ObjectUtils.isDefined(endTime)) {
            formattedDate = formattedDate + " " + endTime;
        }
    } else {
        formattedDate = formattedDate + "No End Date";
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedDateAndTime = function(date, time) {
    var formattedDate = this.getFormattedSummarizedDate(date);
    if (Lib.Utils.ObjectUtils.isDefined(time)) {
        formattedDate = formattedDate + " " + time;
    }
    return formattedDate;
}

WST.Utils.DateUtils.prototype.getFormattedSummarizedDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}
//end WST.Utils.DateUtils.js

//start WST.View.FormView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object adds global functionality across all forms on the site.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView = function(xmlUtils, objectUtils) {
    this._appendSpecialTextToRequiredFormLabels(xmlUtils, objectUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method prepends all required field labels with a special character.
*
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
*/
WST.View.FormView.prototype._appendSpecialTextToRequiredFormLabels = function(xmlUtils, objectUtils) {
    var requiredLabels = cssQuery('.required');
    for (var i = 0; i < requiredLabels.length; i++) {
        var spanElement = document.createElement('span');
        spanElement.className = 'requiredIndicator';
        spanElement.appendChild(document.createTextNode('*'));

        var newNode = requiredLabels[i].cloneNode();
        var childNodes = requiredLabels[i].childNodes;
        newNode.appendChild(spanElement);
        for (var j = 0; j < childNodes.length; j++) {
            newNode.appendChild(childNodes[j]);
        }
        var parent = requiredLabels[i].parentNode;
        parent.replaceChild(newNode, requiredLabels[i]);
    }
}
//end WST.View.FormView.js

//start TTSMain().js

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', createTTSMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method instantiates the TTSMain object.
*/
function createTTSMain() {
  //var logger = new TTSLog4javascriptLogger();
  new TTSMain();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method clears the cached context objects.
*/
function clearCtx() {
    Lib.Utils.ObjectUtils.clearContextObjects();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is the main object for the TTS application.  It handles wiring up all global events.
*/
TTSMain = function() {
    var dateUtils = this._createDateUtils();
    var formView = this._createFormView();
    var footerView = this._createFooterView(dateUtils);
//    logger.debug("TTSMain - dateUtils, formView and footerView complete");
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates a date utils object.
*/
TTSMain.prototype._createDateUtils = function() {
    return new WST.Utils.DateUtils();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates the footer view object.
*/
TTSMain.prototype._createFooterView = function(dateUtils) {
    var footerElement = document.getElementById('footer');
    return new WST.View.FooterView(footerElement, dateUtils);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates the form view object.
*/
TTSMain.prototype._createFormView = function() {
    return new WST.View.FormView(Lib.Utils.XML.XMLUtils, Lib.Utils.ObjectUtils);
}

//end TTSMain();

//Begin code for RequestTourMain.js
//start DocumentUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* description:
*   This object is a utility object for performing actions on the document.
*/
Lib.Utils.DocumentUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* access level: public
* description:
*   This method adds the specified class name to the specified element.
*
* element - Element on the page.
* className - Name of the class to add to the element.
*/
Lib.Utils.DocumentUtils.addClass = function(element, className) {
    if (!this.containsClass(element, className)) {
        if (element) {
            if (element.className.length > 0) {
                element.className = element.className + ' ' + className;
            } else {
                element.className = className;
            }
        }
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/04/2005
* access level: public
* description:
*   This method removes the specified class name for the specified element.
*
* element - Element on the page.
* className - Name of the class to remove from the element.
*/
Lib.Utils.DocumentUtils.removeClass = function(element, className) {
    if (this.containsClass(element, className)) {
        if (element && element.className.indexOf(className) > -1) {
            var pre = element.className.substring(0, element.className.indexOf(className) - 1);
            var post = element.className.substring(element.className.indexOf(className) + className.length + 1);
            element.className = pre + ' ' + post;
        }
    }
}

/**
* author: Ken Johnson (KJJOHN2)
* date created: 12/18/2007
* access level: public
* description:
*   This method removes all classes for the specified element.  This is to address a bug where some classes are being
*   left on an element because the name isn't known
*
* element - Element on the page.
*/
Lib.Utils.DocumentUtils.removeClasses = function(element) {
  element.className = '';
}

/**
* author: Nate Minshew
* date created: 03/08/2006
* access level: public
* description:
*   This method returns whether the specified element contains the specified css class.
*
* @param element - Page Element to check.
* @param className - String representing the css class to check for.
* @return boolean - Representing if the element contains the class.
*/
Lib.Utils.DocumentUtils.containsClass = function(element, className) {
    return element.className.indexOf(className) > -1;
}

Lib.Utils.DocumentUtils.copyHTMLElement = function(targetElement) {
    var container = document.createElement('div');
    container.innerHTML = targetElement.outerHTML;
    return container.firstChild;
}
//end DocumentUtils.js

//start Lib.DHTML.Event.TabNavigatorEvent.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

Lib.DHTML.Event.TabNavigatorEvent = function(tabElement, eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
    this._tabElement = tabElement;
}

Lib.DHTML.Event.TabNavigatorEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

Lib.DHTML.Event.TabNavigatorEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.changeTab(this._tabElement);
}

//end Lib.DHTML.Event.TabNavigatorEvent.js


// start  WST.TourCalendar.Model.Tour
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Tour = function(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization,
                                       guides, status) {
    this._id = id;
    this._startDate = new Date(startDate);
    this._endDate = new Date(endDate);
    this._startTime = startTime;
    this._endTime = endTime;
    this._location = location;
    this._numGuests = numGuests;
    this._place = place;
    this._organization = organization;
    this._guides = guides;
    this._status = status;
}

WST.TourCalendar.Model.Tour.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Tour.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.Tour.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.Tour.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.Tour.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.Tour.prototype.getLocation = function() {
    return this._location;
}

WST.TourCalendar.Model.Tour.prototype.getNumGuests = function() {
    return this._numGuests;
}

WST.TourCalendar.Model.Tour.prototype.getPlace = function() {
    return this._place;
}

WST.TourCalendar.Model.Tour.prototype.getOrganization = function() {
    return this._organization;
}

WST.TourCalendar.Model.Tour.prototype.getGuides = function() {
    return this._guides;
}

WST.TourCalendar.Model.Tour.prototype.getStatus = function() {
    return this._status;
}

WST.TourCalendar.Model.Tour.prototype.getFormattedDateRange = function() {
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedStartDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
}

WST.TourCalendar.Model.Tour.prototype.getFormattedEndDateAndTime = function() {
    return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
}
//end      WST.TourCalendar.Model.Tour



//start WST.TourCalendar.Model.Tour
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Guide");

WST.Model.Guide.Tour = function(tourDate, startTime,  orgName, guests, place, guides, location) {
    this._tourDate = tourDate;
    this._startTime = startTime;
    this._orgName = orgName;
    this._guests = guests;
    this._place = place;
    this._guides = guides;
    this._location = location;
}

WST.Model.Guide.Tour.prototype.getTourDate = function() {
    return this._tourDate;
}

WST.Model.Guide.Tour.prototype.getStartTime = function() {
    return this._startTime;
}

WST.Model.Guide.Tour.prototype.getOrgName = function() {
    return this._orgName;
}

WST.Model.Guide.Tour.prototype.getGuests = function() {
    return this._guests;
}

WST.Model.Guide.Tour.prototype.getPlace = function() {
    return this._place;
}

WST.Model.Guide.Tour.prototype.getGuides = function() {
    return this._guides;
}

WST.Model.Guide.Tour.prototype.getLocation = function() {
    return this._location;
}
//end  WST.TourCalendar.Model.Tour

//start WST.TourCalendar.Model.Guide
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.Guide = function(id, name) {
    this._id = id;
    this._name = name;
}

WST.TourCalendar.Model.Guide.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.Guide.prototype.getName = function() {
    return this._name;
}
//end WST.TourCalendar.Model.Guide

//start Lib.Utils.XML.AjaxUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("Lib.Utils.ObjectUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils.XML");

/**
* author: NJMINSH (Nate Minshew)
* date created: 05/26/2005
* last updated: 10/06/2005
* description:
*   This is a javascript object for componentizing AJAX functionality.
*/
Lib.Utils.XML.AjaxUtils = {};

Lib.Utils.XML.AjaxUtils.successStatus = 200;
Lib.Utils.XML.AjaxUtils.errorStatus = 12029;
Lib.Utils.XML.AjaxUtils.sendingState = 1;
Lib.Utils.XML.AjaxUtils.waitingState = 3;
Lib.Utils.XML.AjaxUtils.completeState = 4;

/**
* created by: NJMINSH (Nate Minshew)
* date created: 05/26/2005
* access level: public
* description:
*   This function makes an AJAX request to the specified url and defines the function that will process the
*   response.
*
*   updated: 08/30/2005 - Changed name to requestAsynchronousFeed and added new method for synchronous feeds.
*   updated: 10/06/2005 - Now implementing JSAN and using namespaces.
*
* url - String representing the url of the service.
* functionObject - Object representing the callback method used for processing the result.
*/
Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed = function(url, getGuides, currentDate, calendar, tourListObject, callback, parentClass, functionObject) {
var request;
  if (window.XMLHttpRequest) {
  // This is how we setup XMLHttpRequest for none IE browsers.
  request = new XMLHttpRequest();
  request.onreadystatechange = function() {
          if(request.readyState == 4){
            functionObject(request, getGuides, currentDate, calendar, tourListObject, parentClass, callback);
        }
   }
    request.open("GET", url, true);
    request.send(null);
} else if (window.ActiveXObject) {
    // This is how we setup XMLHttpRequest for IE.
    request = new ActiveXObject("Microsoft.XMLHTTP");
  request.onreadystatechange = function() {
          if(request.readyState == 4){
            functionObject(request, getGuides, currentDate, calendar, tourListObject, parentClass, callback);
        }
   }

  request.open("GET", url, true);
  request.setRequestHeader( "If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT" );
  request.send();
}

return request;
}

/**
* created by: Nate Minshew
* date created: 08/30/2005
* access level: public
* description:
*   This function makes a synchronous request to the specified url and returns the response.
*
* url - String representing the url of the service.
* returnText - Representing whether the response should be returned as text or xml
*/
Lib.Utils.XML.AjaxUtils.requestSynchronousFeed = function(url, returnText) {
var request;
if (window.XMLHttpRequest) {
    // This is how we setup XMLHttpRequest for none IE browsers.
    request = new XMLHttpRequest();
    try {
      request.open("GET", url, false);
      request.send(null);
    } catch(ex) {
    }
} else if (window.ActiveXObject) {
    // This is how we setup XMLHttpRequest for IE.
    request = new ActiveXObject("Microsoft.XMLHTTP");
    request.open("GET", url, false);
    request.setRequestHeader( "If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT" );
    request.send();
}
if (returnText) {
    return this.getResponseText(request);
}
return this.getResponse(request);
}

/**
* created by: Nate Minshew
* date created: 04/11/2006
* access level: public
* description:
*   This function loads and XML file from a URL.  This is typically used for loading XML from a static source like the
*   filesystem.
*
* @param url - String representing the url to the XML file.
* @return Javascript DOM representing the XML.
*/
Lib.Utils.XML.AjaxUtils.loadXML = function(url) {
var xmlDoc;
if (typeof ActiveXObject != 'undefined' &&
        typeof new ActiveXObject("Microsoft.XMLDOM") != 'undefined') {
    xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
    xmlDoc.async = "false";
    xmlDoc.load(url);
} else if (typeof document.implementation.createDocument != 'undefined') {
    var xmlText = this.requestSynchronousFeed(url, true);
    if (Lib.Utils.ObjectUtils.isDefined(xmlText)) {
      var parser = new DOMParser();
      xmlDoc = parser.parseFromString(xmlText, "text/xml");
    }
}
return xmlDoc;
}

/**
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 * access level: public
 * description:
 *   This function returns the xml response from the AJAX request and null if there wasn't a response or
 *   there was an error returned.
 *
 * request - Object representing the request to the service.
 */
Lib.Utils.XML.AjaxUtils.getResponse = function(request) {
if (request) {
    if (request.readyState == 4) {
        if (request.status == 200) {
            if (request.responseXML) {
                return request.responseXML;
            }
        }
    }
}

return null;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/7/2005
* access level: public
* description:
*   This function returns the current status of the AJAX request.
*/
Lib.Utils.XML.AjaxUtils.getStatus = function(request) {
if (request) {
    if (request.readyState == 4) {
        return request.status;
    }
}
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/7/2005
* access level: public
* description:
*   This function returns the current state of the AJAX request.
*/
Lib.Utils.XML.AjaxUtils.getState = function(request) {
if (request) {
    return request.readyState;
}
}

/**
* created by: Nate Minshew
* date created: 08/30/2005
* access level: public
* description:
*   This function returns the full response returned from the server.
*
* request - Object representing the request to the service.
*/
Lib.Utils.XML.AjaxUtils.getResponseText = function(request) {
if (request) {
    if (request.readyState == 4 && (request.status == 200 || request.status == 0)) {
        return request.responseText;
    }
}
}

/**
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 * access level: public
 * description:
 *   This function returns whether AJAX is supported in the current browser.  It returns false if
 *   getElementById is not defined, meaning that DHTML is not supported.
 */
Lib.Utils.XML.AjaxUtils.isAjaxSupported = function() {
// If we can't access elements in the page using document.getElementById
// then the Ajax stuff isn't very useful to us.
if (!document.getElementById) {
    return false;
}

if (window.XMLHttpRequest || (window.ActiveXObject
        && new ActiveXObject("Microsoft.XMLHTTP"))) {
    return true;
}

return false;
}
//end Lib.Utils.XML.AjaxUtils.js

//start Lib.Utils.DateUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a utility object for performing date functions.
*/
Lib.Utils.DateUtils = {};

// Array of formatted month names.
Lib.Utils.DateUtils.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the days in the specified month and year.
*/
Lib.Utils.DateUtils.getDaysInMonth = function(month, year) {
    var date = new Date(year, month + 1, 0);
    return date.getDate();
}

//end Lib.Utils.DateUtils.js

//start WST.Model.RequestTour.Guides.ToursListUnderGuides
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('WST.TourCalendar.Model.Tour');
JSAN.use('WST.TourCalendar.Model.Guide');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.RequestTour.Guides");

WST.Model.RequestTour.Guides.ToursListUnderGuides = function(currentDate, parentClass, callback) {
    if (currentDate != null) {
      this._startDate = currentDate;
      this._tours = new Array();
      this.refreshListAsynchronously(this, parentClass, callback);
    }
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype.refreshListAsynchronously = function(tourListObject,  parentClass, callback) {
    this._tours = this._getToursXmlAsynchronously(tourListObject, parentClass, callback);
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._getToursXmlAsynchronously = function(tourListObject, parentClass, callback) {
    return Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed(this._getTourServiceUrl(), null, null, null, tourListObject, callback, parentClass, this._parseTourXmlAsynchronously);
}


WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._getTourServiceUrl = function() {
    return 'listNewAndScheduledTours.htm?method=lookupNewAndScheduledToursForGuide&view=xml&startDate=' + this._startDate;
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._parseTourXmlAsynchronously = function(request, getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
  var xmlDoc = request.responseXML;
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var status = tourElements[i].getAttribute('status');
        var place = tourElements[i].getAttribute('place');
        var location = tourElements[i].getAttribute('location');
        var organization = tourElements[i].getAttribute('organization');
//        if (getGuidesOrNot) {
          guides = tourListObject._parseGuideXml(tourElements[i]);
//        }
        tours.push(new WST.TourCalendar.Model.Tour(id, null, null, startTime, endTime, location, null, place, organization, guides, status));
    }
    tourListObject._tours = tours;
    callback(tourListObject, parentClass);
}

WST.Model.RequestTour.Guides.ToursListUnderGuides.prototype._parseGuideXml = function(tourElement) {
    var guideElements = tourElement.getElementsByTagName('guide');
    var guides = new Array();
    for (var i = 0; i < guideElements.length; i++) {
        var id = guideElements[i].getAttribute('id');
        var name = guideElements[i].getAttribute('name');
        guides.push(new WST.TourCalendar.Model.Guide(id, name));
    }
    return guides;
}

//end   WST.Model.RequestTour.Guides.ToursListUnderGuides

//start TourControllerUnderGuides
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.RequestTour.Guides.ToursListUnderGuides');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");

WST.Controller.RequestTour.TourControllerUnderGuides = function() {
}

WST.Controller.RequestTour.TourControllerUnderGuides.prototype._getTourList = function(currentDate) {
    return new WST.Model.RequestTour.Guides.ToursListUnderGuides(currentDate, this, this.updateTourTableUnderGuides);
}


WST.Controller.RequestTour.TourControllerUnderGuides.prototype.updateTourTableUnderGuides = function(tourListObject, thisClass) {
    var tableElement = document.getElementById('tourTableUnderGuides');
    var tourId = document.getElementById('tourId').value;
    var tbodyElement = tableElement.getElementsByTagName('tbody')[0];
    Lib.Utils.XML.XMLUtils.removeAllChildren(tbodyElement);
    var tours = tourListObject._tours;
    if (tours.length == 1){
        tour = tours[0];
        if (tour.getId() == tourId) {
            var trElement = document.createElement('tr');
            var tdElement = document.createElement('td');
            trElement.colspan = 6;
            tdElement.innerHTML = "No Tours Found."
            trElement.appendChild(tdElement);
            tbodyElement.appendChild(trElement);
            return;
        }
    }
    for(var i=0; i < tours.length; i++) {
        var tour = tours[i];
        if (tour.getId() == tourId){
            continue;
        }

        var trElement = document.createElement('tr');

        if (i % 2 == 0) {
            Lib.Utils.DocumentUtils.addClass(trElement, 'even');
        } else {
            Lib.Utils.DocumentUtils.addClass(trElement, 'odd');
        }

        var tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getStartTime();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getEndTime();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getId() + "-" + tour.getOrganization();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getPlace();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getLocation();
        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        var guides = tour.getGuides();
        if (guides.length == 0){
           tdElement.innerHTML = "No Guide Assigned";
        }

        for (var j = 0; j < guides.length; j++) {
            var guide = guides[j];
                tdElement.innerHTML += guide.getName() + "<br />";
        }

        trElement.appendChild(tdElement);

        tdElement = document.createElement('td');
        tdElement.innerHTML = tour.getStatus();
        trElement.appendChild(tdElement);

        tbodyElement.appendChild(trElement);
    }
}

//end TourControllerUnderGuides
//start Lib.DHTML.TabNavigator.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.DHTML.Event.TabNavigatorEvent');
JSAN.use('WST.Controller.RequestTour.TourControllerUnderGuides');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* @constructor
* description:
*   This is the constructor for the tab navigator object.  It provides tab navigation functionality.
*/
Lib.DHTML.TabNavigator = function(
		tabSelector,
		activeTabCssClass,
		hiddenTabSectionCssClass,
		documentUtils,
		eventUtils,
        baseElement) {
    this._activeTabCssClass = activeTabCssClass;
	this._hiddenTabSectionCssClass = hiddenTabSectionCssClass;
	this._documentUtils = documentUtils;
	this._eventUtils = eventUtils;
	this._activeTab;
	this._activeTabSection;
	this._callbacks = new Array();
    this._baseElement = baseElement;
    this._tabSelector = tabSelector;
    this._applyEvents(tabSelector);

}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method apply the tab functionality to all the tabs on the page.
*/
Lib.DHTML.TabNavigator.prototype._applyEvents = function(tabSelector) {
	var tabElements = cssQuery(tabSelector, this._baseElement);
    for (var i = 0; i < tabElements.length; i++) {
		var currentTabElement = tabElements[i];
//     var initialActiveTab = cssQuery('#initialActiveTab', this._baseElement)[0];
//      alert('sonal initialActiveTab ' +  initialActiveTab.value);
//
//     if(initialActiveTab.value == "guideTab"){
//       alert("sonal this._getTargetElement(currentTabElement).id " + this._getTargetElement(currentTabElement).id);
//       if(this._getTargetElement(currentTabElement).id == 'guidesPage'){
//          this.changeTab(currentTabElement);
//       }
//     }

    var resetsubmitDivTop = document.getElementById('resetsubmitTop');
    var resetsubmitDivBottom = document.getElementById('resetsubmitBottom');
    var placeholderDiv = document.getElementById('placeholder');
    if (resetsubmitDivTop != null && resetsubmitDivBottom != null && placeholderDiv != null) {
        if (currentTabElement.parentNode.id == 'resultsTab' && this._isActive(currentTabElement)) {
            resetsubmitDivTop.style.display = 'none';
            resetsubmitDivBottom.style.display = 'none';
            this._documentUtils.removeClass(placeholderDiv, 'hide');
        }
    }

    if (this._isActive(currentTabElement)) {
            this._activeTab = currentTabElement;
			this._activeTabSection = this._getTargetElement(currentTabElement);
		}
        var event = new Lib.DHTML.Event.TabNavigatorEvent(currentTabElement, this._eventUtils, this);
        event.attachEvent(currentTabElement, 'click');
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method changes the current active tab.
*/
Lib.DHTML.TabNavigator.prototype.changeTab = function(tabElement) {
    var target = this._getTargetElement(tabElement);
    this._hideActiveTab();
    this._showTab(tabElement, target);
    doScroll();
    this._notify();
}

function doScroll(){
  window.scrollTo(0,0);
  document.getElementById("TTS").focus();
  return true;
}

/**
* author: Nate Minshew
* date created: 06/30/2006
* access level: public
* description:
*   This method returns the index of the active tab.
*/
Lib.DHTML.TabNavigator.prototype.getActiveTabIndex = function() {
    var tabElements = cssQuery(this._tabSelector, this._baseElement);
    for (var i = 0; i < tabElements.length; i++) {
        if (tabElements[i] == this._activeTab) {
            return i;
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns the number of tabs.
*/
Lib.DHTML.TabNavigator.prototype.getTabCount = function() {
    return cssQuery(this._tabSelector, this._baseElement).length;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns whether the current active tab is the last tab in the list.
*/
Lib.DHTML.TabNavigator.prototype.isLastTabActive = function() {
    var activeTabIndex = this.getActiveTabIndex();
    return activeTabIndex + 1 == this.getTabCount();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method returns whether the current active tab is the first tab in the list.
*/
Lib.DHTML.TabNavigator.prototype.isFirstTabActive = function() {
    return this.getActiveTabIndex() == 0;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method activates the next tab in the list.
*/
Lib.DHTML.TabNavigator.prototype.nextTab = function(place) {
    var dropDown = document.getElementById("tourPlace");
    var formLocation = dropDown.options[dropDown.selectedIndex].value
    var tabElements = cssQuery(this._tabSelector, this._baseElement);
    var currentIndex = this.getActiveTabIndex();
    if (currentIndex + 1 < tabElements.length) {
        if (formLocation == 'CC' && currentIndex == 0) {
            this.changeTab(tabElements[currentIndex + 2]);
        } else {
            this.changeTab(tabElements[currentIndex + 1]);
        }
    }
}
/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method activates the skip(confirm) tab in the list.
*/
Lib.DHTML.TabNavigator.prototype.skipTab = function() {
    var tabElements = cssQuery(this._tabSelector, this._baseElement);
        this.changeTab(tabElements[tabElements.length - 1]);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method activates the previous tab in the list.
*/
Lib.DHTML.TabNavigator.prototype.previousTab = function() {
    var tabElements = cssQuery(this._tabSelector, this._baseElement);
    var currentIndex = this.getActiveTabIndex();
    var dropDown = document.getElementById("tourPlace");
    var formLocation = dropDown.options[dropDown.selectedIndex].value
    if (currentIndex != 0) {
        if (formLocation == 'CC' && currentIndex == 2) {
            this.changeTab(tabElements[currentIndex - 2]);
        } else {
            this.changeTab(tabElements[currentIndex - 1]);
        }
//        this.changeTab(tabElements[currentIndex - 1]);
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method hides the active tab.
*/
Lib.DHTML.TabNavigator.prototype._hideActiveTab = function() {
    if (this._activeTab) {
		this._documentUtils.removeClass(this._activeTab, this._activeTabCssClass);
        this._documentUtils.addClass(this._activeTabSection, this._hiddenTabSectionCssClass);
	}
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method retrieves the target element with the specified tab.
*/
Lib.DHTML.TabNavigator.prototype._getTargetElement = function(tabElement) {
	return cssQuery(tabElement.href.substring(tabElement.href.indexOf('#')), this._baseElement)[0];
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method displays the specified tab.
*/
Lib.DHTML.TabNavigator.prototype._showTab = function(tabElement, targetElement) {
  this._documentUtils.removeClass(targetElement, this._hiddenTabSectionCssClass);
	this._documentUtils.addClass(tabElement, this._activeTabCssClass);
    this._activeTab = tabElement;
	this._activeTabSection = targetElement;
    if(tabElement.parentElement.id == 'guideTab'){
        var currentDate = document.getElementById('tourDate').value;
        var tourController = new WST.Controller.RequestTour.TourControllerUnderGuides();
        tourController._getTourList(currentDate);
    }

     var resetsubmitDivTop = document.getElementById('resetsubmitTop');
    var resetsubmitDivBottom = document.getElementById('resetsubmitBottom');
    var placeholderDiv = document.getElementById('placeholder');
    if (resetsubmitDivTop != null && resetsubmitDivBottom != null && placeholderDiv != null) {
        if (targetElement.id == 'resultsPage') {
            resetsubmitDivTop.style.display = 'none';
            resetsubmitDivBottom.style.display = 'none';
            this._documentUtils.removeClass(placeholderDiv, 'hide');
        } else {
            resetsubmitDivTop.style.display = '';
            resetsubmitDivBottom.style.display = '';
            this._documentUtils.addClass(placeholderDiv, 'hide');
        }
    }
    //     var tab = cssQuery('#initialActiveTab', this._baseElement)[0];
    //     tab.value = "guideTab";
    //     var formElement = document.getElementById('tourForm');
    //     formElement.submit();

}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method returns whether the specified tab is active.
*/
Lib.DHTML.TabNavigator.prototype._isActive = function(element) {
    return this._documentUtils.containsClass(element, this._activeTabCssClass);
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: public
* description:
*   This method adds a callback listener to this tab navigator.
*/
Lib.DHTML.TabNavigator.prototype.addListener = function(callback) {
	this._callbacks.push(callback);
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 11/11/2005
* access level: private
* description:
*   This method notifies all listeners that the state of the tab navigator has changed.
*/
Lib.DHTML.TabNavigator.prototype._notify = function() {
    for (var i = 0; i < this._callbacks.length; i++) {
        this._callbacks[i]();
    }
}
//end Lib.DHTML.TabNavigator.js


//start Lib.View.Templates.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.XMLUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.View");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to defined external dhtml templates to be provided to widgets.  You just define an html page
*   with your widget embedded in the templates id with any added classes or ids and then provide the url to this object.
*   It will read in the template and and provide it to your widget as html.
*
* @param ajaxUtils - Ajax utility object.
* @param url - URL of the template.
* @param templateId - Id of the template.
* @param objectUtils - Object utility object.
*/
Lib.View.Templates = function(ajaxUtils, url, objectUtils) {
    this._templatesXML = this._parseTemplateXML(ajaxUtils, url, objectUtils);
    this._templatesElement = this._convertXMLToHTML(this._templatesXML, objectUtils);
    this._objectUtils = objectUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the root element of your template as an HTML element.
*/
Lib.View.Templates.prototype.getRootElement = function(templateId) {
    var template = cssQuery('#' + templateId, this._templatesElement);
    if (template.length > 0) {
        for(var i = 0; i < template[0].childNodes.length; i++) {
            if (template[0].childNodes[i].nodeType == 1) {
                return template[0].childNodes[i];
            }
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method will append this template to the specified HTML element.
*
* @param element - HTML element to append template to.
*/
Lib.View.Templates.prototype.attachTemplateToPage = function(element, templateId) {
    if (!this._objectUtils.isDefined(element)) {
        element = document.getElementsByTagName('body')[0];
    }
    element.appendChild(this.getRootElement(templateId));
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method retrieves the template from the specified url and returns it as XML.
*
* @param ajaxUtils - Ajax utility object.
* @param url - URL of the template.
* @param templateId - Id of the template.
* @param objectUtils - Object utility object.
*/
Lib.View.Templates.prototype._parseTemplateXML = function(ajaxUtils, url, objectUtils) {
    var resultXML;
    try {
        resultXML = ajaxUtils.loadXML(url);
    } catch(ex) {
        throw new Error("The template at '" + url + "' was not found or is invalid.");
    }
    if (resultXML == null
            || resultXML.getElementsByTagName('div').length == 0
            || resultXML.getElementsByTagName('div')[0].getAttribute('id') != 'templates') {
        throw new Error("The template at '" + url + "' was not found or is invalid.");
    }

    return resultXML.getElementsByTagName('div')[0];
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method converts the XML returned from the url into HTML.
*
* @param xmlDoc - XML document.
* @param objectUtils - Object utility object.
* @param templateId - Id of the template.
*/
Lib.View.Templates.prototype._convertXMLToHTML = function(xmlDoc, objectUtils) {
    var container = document.createElement('div');
    container.innerHTML = Lib.Utils.XML.XMLUtils.convertXmlToString(xmlDoc);
    return cssQuery('#templates', container)[0];
}

//end Lib.View.Templates.js


//start   Lib.DHTML.Event.CalendarIncrementMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that increment the month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, incrementing the month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarIncrementMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.incrementMonth();
}
//end Lib.DHTML.Event.CalendarIncrementMonthEvent

//start   Lib.DHTML.Event.CalendarCurrentMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Sonal Patidar
* date created: 10/1/2007
* @constructor
* description:
*   This object is used to handle events that refreshes the calendar with the curernt month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method executes this event, refreshing the calendar with current month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarCurrentMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.currentMonth();
}
//end Lib.DHTML.Event.CalendarCurrentMonthEvent

//start   Lib.DHTML.Event.CalendarDecrementMonthEvent
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that decrement the month in the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent = function(calendar, eventUtils) {
    this._calendar = calendar;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, decrementing the month on the calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarDecrementMonthEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._calendar.decrementMonth();
}
//end Lib.DHTML.Event.CalendarDecrementMonthEvent

//start   Lib.DHTML.Event.CalendarSelectDateEvent.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to handle events that select a date on the calendar object.
*
* @param calendar - Object representing the calendar.
* @param eventUtils - Utility object for events.
*/
Lib.DHTML.Event.CalendarSelectDateEvent = function(dateLinkElement, calendar, eventUtils, documentUtils) {
    this._dateLinkElement = dateLinkElement;
    this._calendar = calendar;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
Lib.DHTML.Event.CalendarSelectDateEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, selected the date representing by the dateLinkElement field and notifying the
*   calendar object.
*
* @param evt - Event object provided by the browser.
*/
Lib.DHTML.Event.CalendarSelectDateEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    var date = this._dateLinkElement.firstChild.nodeValue;
    if (!this._calendar.isDateDisabled(date)) {
        this._calendar.notifyDateSelected(date, this._dateLinkElement);
    }
}
//end Lib.DHTML.Event.CalendarSelectDateEvent.js

//start Lib.DHTML.Calendar.js
// Create the namespace if it doesn't already exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.DHTML.Event.CalendarIncrementMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarCurrentMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarDecrementMonthEvent');
JSAN.use('Lib.DHTML.Event.CalendarSelectDateEvent');
JSAN.use('Lib.Utils.DateUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.DHTML");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a dhtml calendar object for creating a functional calendar on an html page.  It provides all
*   functionality typically associated with a dhtml calendar.  The ability to change months and select dates.
*
* @param template - Object representing the template to use for the html and css.
* @param dateUtils - Object representing a date utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param xmlUtils - XML utility object.
* @param objectUtils - Object utility object.
* @param blackoutDates - Array of days that should be blacked out.
* @param otherDates - Array of DateStyleConfiguration that should be shaded out.
* @param selectedDate - selected date to be shaded.
*/
Lib.DHTML.Calendar = function(template, dateUtils, documentUtils, eventUtils, xmlUtils, objectUtils, currentDate, currentMonthIsALink) {
    this._template = template;
    this._templateElement = template;
    this._date = currentDate;
    this._currentMonthIsALink = currentMonthIsALink;
    var todaysDate = new Date();
    this._currentDate = todaysDate.getDate();
    this._currentMonth = todaysDate.getMonth();
    this._currentYear = todaysDate.getFullYear();
    this._selectedDate;
    this._selectedYear;
    this._selectedMonth;
    this._dateUtils = dateUtils;
    this._documentUtils = documentUtils;
    this._xmlUtils = xmlUtils;
    this._eventUtils = eventUtils;
    this._objectUtils = objectUtils;
    this._dateListeners = new Array();
    this._dateInitListeners = new Array();
    this._disabledDates = new Array();
    this._monthChangeListeners = new Array();
    this._initialize();
    this._attachHeaderEvents();
}

// Array of formatted month names.
Lib.DHTML.Calendar.MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'];
// Array of formatted weekday names.
Lib.DHTML.Calendar.WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'];

Lib.DHTML.Calendar.prototype.refresh = function() {
    this._initialize();
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method sets the location href use for decrementing or incrementing month
*/
Lib.DHTML.Calendar.prototype.setLocationHref = function(locationHref) {
  this._locationHref = locationHref;
}

/**
* author: Sonal Patidar
* date created: 10/1/2007
* access level: public
* description:
*   This method increments the month on this calendar object.  If the last month, the year will be incremented and the
*   month will start over from the beginning.
*/
Lib.DHTML.Calendar.prototype.currentMonth = function() {
  if (this._locationHref != null){
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method increments the month on this calendar object.  If the last month, the year will be incremented and the
*   month will start over from the beginning.
*/
Lib.DHTML.Calendar.prototype.incrementMonth = function() {
  if (this._locationHref == null) {
      this._date.setMonth(this._date.getMonth() + 1);
      this._notifyMonthChangeListeners(this._date.getMonth(), this._date.getYear());
      this._initialize();
  } else {
      this._date.setMonth(this._date.getMonth() + 1);
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method decrements the month on this calendar object.  If the first month, the year will be decremented and the
*   month will go to december.
*/
Lib.DHTML.Calendar.prototype.decrementMonth = function() {
    if (this._locationHref == null) {
      this._date.setMonth(this._date.getMonth() - 1);
      this._notifyMonthChangeListeners(this._date.getMonth(), this._date.getYear());
      this._initialize();
  } else {
      this._date.setMonth(this._date.getMonth() - 1);
      var numOfDaysInThismonth = Lib.Utils.DateUtils.getDaysInMonth(this._date.getMonth(), this._date.getYear());
      this._date.setDate(numOfDaysInThismonth);
      var endDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      this._date.setDate(1);
      var startDate = (this._date.getMonth() + 1) + "/" + this._date.getDate() + "/" + this._date.getYear();

      location.href = this._locationHref + '&startDate=' + startDate + '&endDate=' + endDate;
  }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method returns the root element of the HTML calendar.
*/
Lib.DHTML.Calendar.prototype.getCalendar = function() {
    return this._templateElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method registers the specified date listener for notification when a date is selected.
*
* @param listener - Object/function to call when a date is selected.
*/
Lib.DHTML.Calendar.prototype.registerDateEventListener = function(listener) {
    this._dateListeners.push(listener);
}

Lib.DHTML.Calendar.prototype.registerDateInitListener = function(listener) {
    this._dateInitListeners.push(listener);
    this._initialize();
}

Lib.DHTML.Calendar.prototype.registerMonthChangeListener = function(listener) {
    this._monthChangeListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method notifies all date listeners that a new date has been selected.
*
* @param date - Date object representing the new date.
* @param dateLinkElement - Element representing the date.
*/
Lib.DHTML.Calendar.prototype.notifyDateSelected = function(date, dateLinkElement) {
    this._date.setDate(date);
    this._selectDate(dateLinkElement);
    for (var i = 0; i < this._dateListeners.length; i++) {
        this._dateListeners[i](this._date);
    }
}

/**
* author: Nate Minshew
* date created: 08/01/2006
* access level: public
* description:
*   This method changes the calendar to the specified date.
*
* @param date - Date object representing the new date.
*/
Lib.DHTML.Calendar.prototype.setDate = function(date) {
    this._date = date;
    this._selectedDate = date.getDate();
    this._selectedMonth = date.getMonth();
    this._selectedYear = date.getFullYear();
    this._clearSelectedDate();
    this._initialize();
}

Lib.DHTML.Calendar.prototype.disableDate = function(date) {
    this._disabledDates.push(date);
}

Lib.DHTML.Calendar.prototype.isDateDisabled = function(dateNumber) {
    for (var i = 0; i < this._disabledDates.length; i++) {
        if (dateNumber == this._disabledDates[i].getDate()
                && this._date.getFullYear() == this._disabledDates[i].getFullYear()
                && this._date.getMonth() == this._disabledDates[i].getMonth()) {
            return true;
        }
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method initializes the calendar, creating the html relative to the current selected date.
*/
Lib.DHTML.Calendar.prototype._initialize = function() {
    this._setMonth(this._date.getMonth(), this._templateElement);
    this._setYear(this._date.getFullYear(), this._templateElement);
    this._updateCalendarDays(this._templateElement);
    this._attachDateEvents();
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the month header to the specified month.
*
* @param month - Index of the new month.
*/
Lib.DHTML.Calendar.prototype._setMonth = function(month) {
    var monthNameElement = cssQuery('span#monthName', this._templateElement)[0];
    if (this._objectUtils.isDefined(monthNameElement)) {
        if(this._currentMonthIsALink != null){
          this._documentUtils.addClass(monthNameElement, 'underline');
      }
    }
    monthNameElement.firstChild.nodeValue = Lib.Utils.DateUtils.MONTHS[month];
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the year header to the specified year.
*
* @param year - Representing the new year.
*/
Lib.DHTML.Calendar.prototype._setYear = function(year) {
    var yearElement = cssQuery('span#year', this._templateElement)[0];
    yearElement.firstChild.nodeValue = year;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method updates the days on the calendar.
*/
Lib.DHTML.Calendar.prototype._updateCalendarDays = function() {
    this._date.setDate(1);
    var firstDayOfMonth = Lib.DHTML.Calendar.WEEK_DAYS[this._date.getDay()];
    var dayHeaderElement = cssQuery('th#' + firstDayOfMonth, this._templateElement)[0];
    var dateIndex = this._findElementIndex(dayHeaderElement);
    this._clearAllDates();
    this._setDates(dateIndex);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method finds the index of the specified element according to it's parent.
*
* @param element - HTML element's index to retrieve.
*/
Lib.DHTML.Calendar.prototype._findElementIndex = function(element) {
    var parent = element.parentNode;
    var index = -1;
    for (var i = 0; i < parent.childNodes.length; i++) {
        if (parent.childNodes[i].nodeType == 1) {
            index++;
            if (parent.childNodes[i] == element) {
                return index;
            }
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method clears all current calendar dates.
*/
Lib.DHTML.Calendar.prototype._clearAllDates = function() {
    var dateElements = this._templateElement.getElementsByTagName('td');
    this._clearSelectedDate();
    for (var i = 0; i < dateElements.length; i++) {
        this._xmlUtils.removeAllChildren(dateElements[i]);
        dateElements[i].innerHTML = '&nbsp;';
        this._documentUtils.removeClass(dateElements[i], 'currentDate');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method clears the selected date.
*/
Lib.DHTML.Calendar.prototype._clearSelectedDate = function() {
    var dateElement = cssQuery('.selectedDate', this._templateElement)[0];
    if (this._objectUtils.isDefined(dateElement)) {
        this._documentUtils.removeClass(dateElement, 'selectedDate');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets all the dates on the calendar based on the specified starting index.
*
* @param startingIndex - Index of the first calendar date field.
*/
Lib.DHTML.Calendar.prototype._setDates = function(startingIndex) {
    var dateElements = this._templateElement.getElementsByTagName('td');
    var dateNumber = 1;
    var daysInMonth = this._dateUtils.getDaysInMonth(this._date.getMonth(), this._date.getFullYear());
    for (var i = startingIndex; i < daysInMonth + startingIndex; i++) {
    	this._xmlUtils.removeAllChildren(dateElements[i]);
        this._createDate(dateElements[i], dateNumber);
        this._notifyDateInitListeners(new Date(this._date.getFullYear(), this._date.getMonth(), dateNumber), dateElements[i])
        if (this._isCurrentDate(dateNumber)) {
            this._documentUtils.addClass(dateElements[i], 'currentDate');
        }
        if (this._isSelectedDate(dateNumber)) {
            this._documentUtils.addClass(dateElements[i], 'selectedDate');
        }
        dateNumber++;
    }
}

Lib.DHTML.Calendar.prototype._notifyDateInitListeners = function(date, dateElement) {
    for (var i = 0; i < this._dateInitListeners.length; i++) {
        this._dateInitListeners[i](date, dateElement);
    }
}

Lib.DHTML.Calendar.prototype._notifyMonthChangeListeners = function(month, year) {
    for (var i = 0; i < this._monthChangeListeners.length; i++) {
        this._monthChangeListeners[i](month, year);
    }
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns whether the specified date (number) is today's date.
*
* @param dateNumber - Representing the date.
*/
Lib.DHTML.Calendar.prototype._isCurrentDate = function(dateNumber) {
    if (dateNumber == this._currentDate
            && this._date.getMonth() == this._currentMonth
            && this._date.getFullYear() == this._currentYear) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns whether the specified date (number) is the selected date.
*
* @param dateNumber - Representing the date.
*/
Lib.DHTML.Calendar.prototype._isSelectedDate = function(dateNumber) {
    if (dateNumber == this._selectedDate
            && this._date.getMonth() == this._selectedMonth
            && this._date.getFullYear() == this._selectedYear) {
        return true;
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates a date field in the specified date element with the specified date value.
*
* @param dateElement - HTML element to create the date in.
* @param dateValue - Value to set the date to.
*/
Lib.DHTML.Calendar.prototype._createDate = function(dateElement, dateValue) {
    var linkElement = document.createElement('a');
    linkElement.href = '#';
    linkElement.className = 'dateLink';
    linkElement.appendChild(document.createTextNode(dateValue));
    dateElement.appendChild(linkElement);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method attaches the navigation events to the header.
*/
Lib.DHTML.Calendar.prototype._attachHeaderEvents = function() {
    var nextMonthLink = cssQuery('a#nextMonthLink', this._templateElement)[0];
    var event = new Lib.DHTML.Event.CalendarIncrementMonthEvent(this, this._eventUtils);
    event.attachEvent(nextMonthLink, 'click');

    var monthYearLink = cssQuery('a#monthYearLink', this._templateElement)[0];
    event = new Lib.DHTML.Event.CalendarCurrentMonthEvent(this, this._eventUtils);
    event.attachEvent(monthYearLink, 'click');

    var prevMonthLink = cssQuery('a#prevMonthLink', this._templateElement)[0];
    event = new Lib.DHTML.Event.CalendarDecrementMonthEvent(this, this._eventUtils);
    event.attachEvent(prevMonthLink, 'click');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches the date events.
*/
Lib.DHTML.Calendar.prototype._attachDateEvents = function() {
    var dateLinks = cssQuery('a.dateLink', this._templateElement);
    for (var i = 0; i < dateLinks.length; i++) {
        var event = new Lib.DHTML.Event.CalendarSelectDateEvent(dateLinks[i], this, this._eventUtils, this._documentUtils);
        event.attachEvent(dateLinks[i], 'click');
    }
}

  /**
  * author: Nate Minshew
  * date created: 07/12/2006            
  * access level: private
  * description:
  *   This method selects the specified date link element.
  *
  * @param dateLinkElement - HTML element representing the selected date.
  */
  Lib.DHTML.Calendar.prototype._selectDate = function(dateLinkElement) {
      this._selectedDate = this._date.getDate();
      this._selectedMonth = this._date.getMonth();
      this._selectedYear = this._date.getFullYear();
      this._clearSelectedDate();
      this._documentUtils.addClass(dateLinkElement.parentNode, 'selectedDate');
}
//end Lib.DHTML.Calendar.js

//start Lib.Utils.FormUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* description:
*   This is a javascript class for defining common static utility functions that will be used throughout the
*   application.
*/
Lib.Utils.FormUtils = {};

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   Clears the specified select element by creating a single option with an empty value and '-'s for text.
*
* element - DOM Select Element that will be modified.
* defaultValue - Default value of the select element.
* defaultText - Default text of the select element.
*/
Lib.Utils.FormUtils.clearSelectElement = function(element, defaultValue, defaultText) {
    element.innerHTML = "";
    var optionElement = document.createElement('option');
    optionElement.setAttribute('value', defaultValue);
    var textNode = document.createTextNode(defaultText);
    optionElement.appendChild(textNode);
    element.appendChild(optionElement);
}

/**
* author: njminsh (Nate Minshew)
* date created: 10/06/2005
* access level: public
* description:
*   This method clears the specified text box element.
*
* element - DOM Input Element representing the text box.
* defaultValue - Default value of the field.
*/
Lib.Utils.FormUtils.clearTextBox = function(element, defaultValue) {
    element.value = defaultValue;
}

/**
* author: Nate Minshew
* date created: 03/08/2006
* access level: public
* description:
*   This method creates a new input field with the specified name.
*
* @return Element - Representing the new input field.
*/
Lib.Utils.FormUtils.createInputField = function(name) {
    if (document.all) {
        return document.createElement('<input name="' + name + '">');
    }
    var field = document.createElement('input');
    field.name = name;
    return field;
}

/**
* author: njminsh (Nate Minshew)
* date created: 11/02/2005
* access level: public
* description:
*   This method validates that the value of the specified element is numeric.
*
* element - Element representing the form field to validate.
*/
Lib.Utils.FormUtils.isNumeric = function(element) {
    if (isNaN(element.value)) {
        return false;
    }

    return true;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method returns the current selected value of the specified select box element.
*
* @param element - HTML select box element to retrieve value from.
*/
Lib.Utils.FormUtils.getSelectedValue = function(element) {
    return element.options[element.selectedIndex].value;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method returns the current selected text of the specified select box element.
*
* @param element - HTML select box element to retrieve text from.
*/
Lib.Utils.FormUtils.getSelectedText = function(element) {
    return element.options[element.selectedIndex].text;
}

/**
* author: Nate Minshew
* date created: 07/18/2006
* access level: public
* description:
*   This method returns the index of the specified value of the specified select element.
*
* @param element - HTML select element.
* @param value - Text value of requested option index.
*/
Lib.Utils.FormUtils.getIndexOfValue = function(element, value) {
    for (var i = 0; i < element.options.length; i++) {
        if (element.options[i].value == value) {
            return i;
        }
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* description:
*   This object contains utility functions for checkbox elements.
*/
Lib.Utils.FormUtils.CheckboxUtils = {};

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function clears all selected checkboxes.
*
* element - Checkbox element to clear.
*/
Lib.Utils.FormUtils.CheckboxUtils.clearAllCheckboxes = function(element) {
    if (element.length) {
        for (var i = 0; i < element.length; i++) {
            element[i].checked = false;
        }
    } else {
        element.checked = false;
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: private
* description:
*   This function returns the number of checked checkboxes.
*
* element - Checkbox element to query.
*/
Lib.Utils.FormUtils.CheckboxUtils._getNumChecked = function(element) {
	var counter = 0;
	if (element.length) {
		for (var i = 0; i < element.length; i++) {
			if (element[i].checked) {
				counter++;
			}
		}
	} else if (element && element.checked) {
		counter ++;
	}

	return counter;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function returns whether the number of checkboxes checked is less than or equal to the max.
*
* element - The checkbox element.
* max - The maximum number of checks.
*/
Lib.Utils.FormUtils.CheckboxUtils.isNumCheckedLTEQMax = function(element, max) {
    var counter = this._getNumChecked(element);

    if (counter > max) {
        return false;
    }

    return true;
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 10/13/2005
* access level: public
* description:
*   This function returns whether the number of checkboxes checked is greater than or equal to the minimum.
*
* element - The checkbox element.
* min - The minimum number of checks.
*/
Lib.Utils.FormUtils.CheckboxUtils.isNumCheckedGTEQMin = function(element, min) {
	var counter = this._getNumChecked(element);

	if (counter < min) {
		return false;
	}

	return true;
}

//end Lib.Utils.FormUtils.js

//start Lib.Utils.ValidatorUtils.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("Lib.Utils");

/**
* author: Nate Minshew
* date created: 07/14/2006
* description:
*   This object provides common validation methods.
*/
Lib.Utils.ValidatorUtils = {};

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: public
* description:
*   This method validates that the value specified is defined and has content.  An empty string is not valid.
*
* @param value - The value to validate.
*/
Lib.Utils.ValidatorUtils.validateRequired = function(value) {
    if (Lib.Utils.ObjectUtils.isDefined(value) && value != '') {
        return true;
    }
    return false;
}
//end Lib.Utils.ValidatorUtils.js


//start  WST.View.RequestTour.Event.SaveTourEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a save tour event for submitting the tour form to the server.
*
* @param formElement - HTML element representing the form.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.Event.SaveTourEvent = function(formElement, eventUtils) {
    this._formElement = formElement;
    this._eventUtils = eventUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.SaveTourEvent.prototype.attachEvent = function(element, type) {
    this._element = element;
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This methd executes the event, submitting the form.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.SaveTourEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    var linkName = this._element.id;
    var status = cssQuery('#tourStatus', this._baseElement)[0];
    if(linkName == "finishedNav"){
      if(status.value == ""){
        status.value = "NEW";
        }
    }
    if(linkName == "saveAsNav"){
      document.getElementById("method").value = "makeACopyOfTour";
    }
    if(linkName == "approveNav"){
      status.value = "SCHEDULED";
    }
    if(linkName == "addonNav"){
      status.value = "ADDON";
    }
    if(linkName == "pendingNav"){
      status.value = "PENDING";
    }
    if(linkName == "declineNav"){
      status.value = "CANCELLED";
    }
    if(linkName == "resetToNewNav"){
      status.value = "NEW";
    }
    this._formElement.submit();
}
//end  WST.View.RequestTour.Event.SaveTourEvent.js

//start  WST.View.RequestTour.Event.NextTabEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for change to the next tab on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param tabNavigator - Object used for switching and maintaining tabs.
*/
WST.View.RequestTour.Event.NextTabEvent = function(eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches this event to the specified element using the specified type.
*
* @param element - Page element to attach event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.NextTabEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes this event.  It uses the tab navigator to switch to the next tab.
*
* @param evt - System event object.
*/
WST.View.RequestTour.Event.NextTabEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.nextTab();
}
//end    WST.View.RequestTour.Event.NextTabEvent.js

//start  WST.View.RequestTour.Event.SkipTabEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for change to the skip tab on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param tabNavigator - Object used for switching and maintaining tabs.
*/
WST.View.RequestTour.Event.SkipTabEvent = function(eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches this event to the specified element using the specified type.
*
* @param element - Page element to attach event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.SkipTabEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes this event.  It uses the tab navigator to switch to the confirm tab.
*
* @param evt - System event object.
*/
WST.View.RequestTour.Event.SkipTabEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.skipTab();
}
//end  WST.View.RequestTour.Event.SkipTabEvent.js

//start WST.View.RequestTour.Event.PreviousTabEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This is an event object for switching to a previous tab on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param tabNavigator - DHTML tab navigator widget.
*/
WST.View.RequestTour.Event.PreviousTabEvent = function(eventUtils, tabNavigator) {
    this._eventUtils = eventUtils;
    this._tabNavigator = tabNavigator;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.PreviousTabEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event, switching to the previous tab.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.PreviousTabEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._tabNavigator.previousTab();
}
//end  WST.View.RequestTour.Event.PreviousTabEvent.js


//start WST.View.RequestTour.FormNavView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.SaveTourEvent');
JSAN.use('WST.View.RequestTour.Event.NextTabEvent');
JSAN.use('WST.View.RequestTour.Event.SkipTabEvent');
JSAN.use('WST.View.RequestTour.Event.PreviousTabEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the form navigation section of the request a tour page.  It is responsible for
*   updating the html and adding events related to form navigation.
*
* @param tabNavigator - Tab Navigation widget.
* @param disableCssClass - CSS class used for hidding html.
* @param documentUtils - Document utility object.
* @param baseElement - Root html element for the section.
* @param objectUtils - Object utility object.
* @param formElement - HTML element representing the form.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView = function(
        tabNavigator,
        disableCssClass,
        documentUtils,
        baseElement,
        objectUtils,
        formElement,
        eventUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._disableCssClass = disableCssClass;
    this._tabNavigator = tabNavigator;
    this.updateVisibleNavigation();
    this._attachFinishedEvent(formElement, eventUtils);
    this._attachNextEvent(eventUtils);
    this._attachSkipEvent(eventUtils);
    this._attachBackEvent(eventUtils);
    var reference = objectUtils.weakBind(this.updateVisibleNavigation, this);
    tabNavigator.addListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method updates the visible navigation, hiding the back link if on the first tab, etc.
*/
WST.View.RequestTour.FormNavView.prototype.updateVisibleNavigation = function() {
    if (this._tabNavigator.isFirstTabActive()) {
        this._hideBackLink();
        this._showNextLink();
        this._hideSubmitLink();
        this._showSkipLink();
    } else if (this._tabNavigator.isLastTabActive()) {
        this._hideNextLink();
        this._showBackLink();
        this._showSubmitLink();
        this._hideSkipLink();
    } else {
        this._showNextLink();
        this._showBackLink();
        this._hideSubmitLink();
        this._showSkipLink();
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the back link.
*/
WST.View.RequestTour.FormNavView.prototype._hideBackLink = function() {
    var backElement = cssQuery('#backNav', this._baseElement);
    for(var i = 0; i < backElement.length; i++){
      this._documentUtils.addClass(backElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the submit link only if skipNav exists on the page
*/
WST.View.RequestTour.FormNavView.prototype._hideSubmitLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    if(skipElement.length > 0){
    var submitElement = cssQuery('#finishedNav', this._baseElement);
    for(var i = 0; i < submitElement.length; i++){
      this._documentUtils.addClass(submitElement[i], this._disableCssClass);
    }
   }
}


/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the submit link only if skipNav exists on the page
*/
WST.View.RequestTour.FormNavView.prototype._showSubmitLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    if(skipElement.length > 0){
    var submitElement = cssQuery('#finishedNav', this._baseElement);
      for(var i = 0; i < submitElement.length; i++){
         this._documentUtils.removeClass(submitElement[i], this._disableCssClass);
     }
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the skip link.
*/
WST.View.RequestTour.FormNavView.prototype._hideSkipLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
    for(var i = 0; i < skipElement.length; i++){
      this._documentUtils.addClass(skipElement[i], this._disableCssClass);
   }

}


/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the skip link.
*/
WST.View.RequestTour.FormNavView.prototype._showSkipLink = function() {
    var skipElement = cssQuery('#skipNav', this._baseElement);
      for(var i = 0; i < skipElement.length; i++){
         this._documentUtils.removeClass(skipElement[i], this._disableCssClass);
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the back link.
*/
WST.View.RequestTour.FormNavView.prototype._showBackLink = function() {
    var backElement = cssQuery('#backNav', this._baseElement);
      for(var i = 0; i < backElement.length; i++){
         this._documentUtils.removeClass(backElement[i], this._disableCssClass);
   }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method hides the next link.
*/
WST.View.RequestTour.FormNavView.prototype._hideNextLink = function() {
    var nextElement = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextElement.length; i++){
         this._documentUtils.addClass(nextElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method displays the next link.
*/
WST.View.RequestTour.FormNavView.prototype._showNextLink = function() {
    var nextElement = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextElement.length; i++){
         this._documentUtils.removeClass(nextElement[i], this._disableCssClass);
   }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the form submit events to the submit link.
*
* @param formElement - Form html element.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachFinishedEvent = function(formElement, eventUtils) {
    var saveAsLink = cssQuery('#saveAsNav', this._baseElement);
  if(saveAsLink != null){
    for(var i = 0; i < saveAsLink.length; i++){
      var event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
      event.attachEvent(saveAsLink[i], 'click');
    }
  }
      //    var finishedLink = cssQuery('#finishedNav', this._baseElement);
  //    if(finishedLink != null){
  //        for(var i = 0; i < finishedLink.length; i++){
  //          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
  //          event.attachEvent(finishedLink[i], 'click');
  //         }
  //    }
  //    var approveLink = cssQuery('#approveNav', this._baseElement);
  //    if(approveLink != null){
  //      for(var i = 0; i < approveLink.length; i++){
  //        event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
  //        event.attachEvent(approveLink[i], 'click');
//        }
//    }
//    var pendingLink = cssQuery('#pendingNav', this._baseElement);
//    if(pendingLink != null){
//      for(var i = 0; i < pendingLink.length; i++){
//          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//          event.attachEvent(pendingLink[i], 'click');
//       }
//    }
//    var resetToNewLink = cssQuery('#resetToNewNav', this._baseElement);
//    if(resetToNewLink != null){
//      for(var i = 0; i < resetToNewLink.length; i++){
//          event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//          event.attachEvent(resetToNewLink[i], 'click');
//       }
//    }
//   var declineLink = cssQuery('#declineNav', this._baseElement);
//    if(declineLink != null){
//      for(var i = 0; i < declineLink.length; i++){
//        event = new WST.View.RequestTour.Event.SaveTourEvent(formElement, eventUtils);
//        event.attachEvent(declineLink[i], 'click');
//       }
//    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the next tab event to the next link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachNextEvent = function(eventUtils) {
    var nextLink = cssQuery('#nextNav', this._baseElement);
    for(var i = 0; i < nextLink.length; i++){
        var event = new WST.View.RequestTour.Event.NextTabEvent(eventUtils, this._tabNavigator);
        event.attachEvent(nextLink[i], 'click');
    }
}
/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the skip(confirm) tab event to the skip link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachSkipEvent = function(eventUtils) {
    var skipLink = cssQuery('#skipNav', this._baseElement);
    if(skipLink != null){
      for(var i = 0; i < skipLink.length; i++){
         var event = new WST.View.RequestTour.Event.SkipTabEvent(eventUtils, this._tabNavigator);
         event.attachEvent(skipLink[i], 'click');
      }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the previous tab event to the back link.
*
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.FormNavView.prototype._attachBackEvent = function(eventUtils) {
    var backLink = cssQuery('#backNav', this._baseElement);
    for(var i = 0; i < backLink.length; i++){
        var event = new WST.View.RequestTour.Event.PreviousTabEvent(eventUtils, this._tabNavigator);
        event.attachEvent(backLink[i], 'click');
   }

}

//end WST.View.RequestTour.FormNavView.js

//start WST.View.RequestTour.Event.ConfirmEvent
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for defining confirmation events on the request a tour page.
*
* @param eventUtils - Event utility object.
* @param element - Input element containing the value.
* @param confirmView - Object representing the confirm view.
*/
WST.View.RequestTour.Event.ConfirmEvent = function(eventUtils, element, confirmView) {
    this._eventUtils = eventUtils;
    this._element = element;
    this._confirmView = confirmView;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.ConfirmEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event for this object.  It sets the confirm view value based on the current input element.
*/
WST.View.RequestTour.Event.ConfirmEvent.prototype.executeEvent = function(evt) {
    this._confirmView.setConfirmValue(this._element);
}
//end WST.View.RequestTour.Event.ConfirmEvent

//start WST.View.RequestTour.ConfirmView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ConfirmEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view for the confirmation section of the request a tour page.  It handles updating the html on the
*   confirmation page and attaching events.
*
* @param objectUtils - Object utility object.
* @param eventUtil - Event utility object
* @param xmlUtils - XML utility object.
* @param formUtils - Form utility object.
* @param confirmController - Controller object for the confirm section.
*/
WST.View.RequestTour.ConfirmView = function(objectUtils, eventUtils, xmlUtils, formUtils, confirmController, baseElement) {
    this._baseElement = baseElement;
    this._objectUtils = objectUtils;
    this._xmlUtils = xmlUtils;
    this._formUtils = formUtils;
    var inputElements = this._getInputElements();
    var reference = objectUtils.weakBind(this.setConfirmValue, this);
    confirmController.registerConfirmValueListener(reference);
    reference = objectUtils.weakBind(this.addGuide, this);
    confirmController.registerAddGuideListener(reference);
    reference = objectUtils.weakBind(this.deleteGuide, this);
    confirmController.registerDeleteGuideListener(reference);

    //reference = objectUtils.weakBind(this.addGuest, this);
    //confirmController.registerAddGuestListener(reference);
    //reference = objectUtils.weakBind(this.editGuest, this);
    //confirmController.registerEditGuestListener(reference);
    //reference = objectUtils.weakBind(this.deleteGuest, this);
    //confirmController.registerDeleteGuestListener(reference);
    for (var i = 0; i < inputElements.length; i++) {
        var event = new WST.View.RequestTour.Event.ConfirmEvent(eventUtils, inputElements[i], this);
        event.attachEvent(inputElements[i], 'change');
        this.setConfirmValue(inputElements[i]);
    }
  var disabledElements = cssQuery('.disabled');
    for (var i = 0; i < disabledElements.length; i++) {
      disabledElements[i].disabled = true;
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the entered/selected value of the specified input element in it's corresponding location on the
*   confirmation page.
*
* @param inputElement - HTML input element.
*/
WST.View.RequestTour.ConfirmView.prototype.setConfirmValue = function(inputElement) {

    var confirmElement = cssQuery('#' + inputElement.id + "-value")[0];
    if (inputElement.nodeName == 'INPUT') {
        if (inputElement.type == 'radio' && inputElement.checked) {
            confirmElement = cssQuery('#' + inputElement.name + '-value')[0];
            if (inputElement.value == 'true') {
                this._setValue(confirmElement, 'Yes');
            } else {
                this._setValue(confirmElement, 'No');
            }
        } else if (inputElement.type != 'radio') {
            var value = inputElement.value;
            if(inputElement.id == 'creditCardNumber'){
                value = this._maskCreditCardNumber(value);
            }
            this._setValue(confirmElement, value);
        }
    } else if (inputElement.nodeName == 'SELECT') {
        if (this._formUtils.getSelectedValue(inputElement) != '') {
            var value = this._formUtils.getSelectedText(inputElement);
            this._setValue(confirmElement, value);
        } else {
            this._setValue(confirmElement, '');
        }
    }
     else if (inputElement.nodeName == 'TEXTAREA') {
         this._setValue(confirmElement, inputElement.value);
    } else {
        throw new Error("The html element '" + inputElement.nodeName + "' is not supported");
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method adds the specified guest to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.addGuest = function(name, classification, location) {
    this._removeNoConfirmGuestsRow();
    this._addGuestRow(name, classification, location);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method adds the specified guide to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.addGuide = function(guideName) {
    this._removeNoConfirmGuidesRow();
    this._addGuideRow(guideName);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method updates the specified guest in the confirm section.
*
* @param index - Index of Guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype.editGuest = function(index, name, classification, location) {
    this._editGuestRow(index, name, classification, location);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method deletes the specified guest in the confirm section.
*
* @param index - Index of Guest.
*/
WST.View.RequestTour.ConfirmView.prototype.deleteGuest = function(index) {
    this._deleteGuestRow(index);
    if (this._getNumGuests() == 0) {
        this._addNoConfirmGuestsRow();
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method deletes the specified guide in the confirm section.
*
* @param index - Index of Guest.
*/
WST.View.RequestTour.ConfirmView.prototype.deleteGuide = function(index) {
    this._deleteGuideRow(index);
    if (this._getNumGuides() == 0) {
        this._addNoConfirmGuidesRow();
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method removes the no confirm guests row from the guest table.
*/
WST.View.RequestTour.ConfirmView.prototype._removeNoConfirmGuestsRow = function() {
    var row = cssQuery('#noConfirmGuests', this._baseElement)[0];
    if (this._objectUtils.isDefined(row)) {
        row.parentNode.removeChild(row);
    }
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method removes the no confirm guests row from the guide table.
*/
WST.View.RequestTour.ConfirmView.prototype._removeNoConfirmGuidesRow = function() {
    var row = cssQuery('#noConfirmGuides', this._baseElement)[0];
    if (this._objectUtils.isDefined(row)) {
        row.parentNode.removeChild(row);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds the no confirm guests row to the guests table.
*/
WST.View.RequestTour.ConfirmView.prototype._addNoConfirmGuestsRow = function() {
    var guestsTable = cssQuery('#confirmGuestsTable', this._baseElement)[0];
    var tbodyElement = guestsTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.id = 'noConfirmGuests';
    var column = document.createElement('td');
    column.colspan = 4;
    column.appendChild(document.createTextNode('No Guests Entered'));
    row.appendChild(column);
    tbodyElement.appendChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds the no confirm gudies row to the guests table.
*/
WST.View.RequestTour.ConfirmView.prototype._addNoConfirmGuidesRow = function() {
    var guidesTable = cssQuery('#confirmGuidesTable', this._baseElement)[0];
    var tbodyElement = guidesTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.id = 'noConfirmGuides';
    var column = document.createElement('td');
    column.colspan = 2;
    column.appendChild(document.createTextNode('No Gudies Entered'));
    row.appendChild(column);
    tbodyElement.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds a guest row to the guest table.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype._addGuestRow = function(name, classification, location) {
    var guestTable = cssQuery('#confirmGuestsTable', this._baseElement)[0];
    var tbodyElement = guestTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.className = 'guestRow';
    row.id = 'guestRow-' + this._getNumGuests();
    row.appendChild(this._createGuestHeader());
    row.appendChild(this._createGuestColumn(name));
    row.appendChild(this._createGuestColumn(classification));
    var lastCol = this._createGuestColumn(location);
    lastCol.className = 'lastGuestColumn';
    row.appendChild(lastCol);
    tbodyElement.appendChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method adds a guest row to the gudie table.
*
* @param name - Guides's name.
*/
WST.View.RequestTour.ConfirmView.prototype._addGuideRow = function(guideName) {
    var guideTable = cssQuery('#confirmGuidesTable', this._baseElement)[0];
    var tbodyElement = guideTable.getElementsByTagName('tbody')[0];
    var row = document.createElement('tr');
    row.className = 'guideRow';
    row.id = 'guideRow-' + this._getNumGuides();
    row.appendChild(this._createGuideHeader());
    var lastCol = this._createGuideColumn(guideName);
    lastCol.className = 'lastGuideColumn';
    row.appendChild(lastCol);
    tbodyElement.appendChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method edits the guest at the specified index.
*
* @param index - Index of Guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location.
*/
WST.View.RequestTour.ConfirmView.prototype._editGuestRow = function(index, name, classification, location) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    var tdElements = row.getElementsByTagName('td');
    tdElements[0].innerHTML = name;
    tdElements[1].innerHTML = classification;
    tdElements[2].innerHTML = location;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method deletes the guest row at the specified index.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.ConfirmView.prototype._deleteGuestRow = function(index) {
    var row = cssQuery('#guestRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method deletes the guide row at the specified index.
*
* @param index - Index of guest.
*/
WST.View.RequestTour.ConfirmView.prototype._deleteGuideRow = function(index) {
    var row = cssQuery('#guideRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the guest header.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuestHeader = function() {
    var thElement = document.createElement('th');
    thElement.appendChild(document.createTextNode('Guest ' + (this._getNumGuests() + 1) + ':'));
    return thElement;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the guide header.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuideHeader = function() {
    var thElement = document.createElement('th');
    thElement.appendChild(document.createTextNode('Guide ' + (this._getNumGuides() + 1) + ':'));
    return thElement;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates a guest column with the specified value.
*
* @param value - Representing the text of the column.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuestColumn = function(value) {
    var tdElement = document.createElement('td');
    tdElement.appendChild(document.createTextNode(value));
    return tdElement;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates a guest column with the specified value.
*
* @param value - Representing the text of the column.
*/
WST.View.RequestTour.ConfirmView.prototype._createGuideColumn = function(value) {
    var tdElement = document.createElement('td');
    tdElement.appendChild(document.createTextNode(value));
    return tdElement;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method returns the number of guests in the confirm guest section.
*/
WST.View.RequestTour.ConfirmView.prototype._getNumGuests = function() {
    return cssQuery('.guestRow', this._baseElement).length;
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method returns the number of guides in the confirm gudie section.
*/
WST.View.RequestTour.ConfirmView.prototype._getNumGuides = function() {
    return cssQuery('.guideRow', this._baseElement).length;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method returns all input elements on the current page with the "confirm-value" class.
*/
WST.View.RequestTour.ConfirmView.prototype._getInputElements = function() {
    return cssQuery('.confirm-value');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method sets the specified value in the specified confirmation element.
*
* @param confirmElement - HTML element which to insert value.
* @param value - Value to insert.
*/
WST.View.RequestTour.ConfirmView.prototype._setValue = function(confirmElement, value) {
    if (this._objectUtils.isDefined(confirmElement)
            && this._objectUtils.isDefined(confirmElement.firstChild)
            && this._objectUtils.isDefined(confirmElement.firstChild.nodeValue)) {
        confirmElement.firstChild.nodeValue = value;
    } else if (this._objectUtils.isDefined(confirmElement)) {
        this._xmlUtils.removeAllChildren(confirmElement);
        confirmElement.appendChild(document.createTextNode(value));
    }
}

WST.View.RequestTour.ConfirmView.prototype._maskCreditCardNumber = function(creditCardNumber) {
    var lastFourDigits = creditCardNumber.substring(creditCardNumber.length - 4, creditCardNumber.length);
    var xStr = '';
    for(var j = 0; j < creditCardNumber.length - 4; j++){
      xStr += 'X';
    }
    creditCardNumber = xStr + lastFourDigits;
    return creditCardNumber;
}

//end   WST.View.RequestTour.ConfirmView.js

//start  WST.View.RequestTour.TabsView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the tabs on the request a tour page.  It handles manipulating the tabs on the page
*   as well as adding events.
*
* @param baseElement - Root html element of the tabs.
* @param tabNavigator - Tab navigator widget.
* @param objectUtils - Object utility object.
*/
WST.View.RequestTour.TabsView = function(baseElement, tabNavigator, objectUtils) {
    this._baseElement = baseElement;
    this.roundTabs();
    var reference = objectUtils.weakBind(this.roundTabs, this);
    tabNavigator.addListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method rounds the tabs using niftycorners.
*/
WST.View.RequestTour.TabsView.prototype.roundTabs = function() {
    if (typeof NiftyCheck != 'undefined' && NiftyCheck()) {
        this.removeAllRoundedCorners();
        // TODO: Would like to eventually rewrite niftycorners to use css classes instead.
        Rounded('a.tab', "top", "#FFF", "#336633", "smooth");
        this._roundActiveTab();
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method removes the rounded corners from the specified element.
*
* @param element - HTML element to be squared off.
*/
WST.View.RequestTour.TabsView.prototype._removeRoundedCorners = function(element) {
    if (element != null) {
        var roundedElements = element.getElementsByTagName('b');
        for (var i = 0; i < roundedElements.length; i++) {
            roundedElements[i].parentNode.removeChild(roundedElements[i]);
        }
    }

}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method removes all rounded corners.
*/
WST.View.RequestTour.TabsView.prototype.removeAllRoundedCorners = function() {
    var tabs = cssQuery('a.tab', this._baseElement);
    for (var i = 0; i < tabs.length; i++) {
        this._removeRoundedCorners(tabs[i]);
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method rounds the active tab.
*/
WST.View.RequestTour.TabsView.prototype._roundActiveTab = function() {
    var activeTab = cssQuery('a.activeTab', this._baseElement)[0];
    this._removeRoundedCorners(activeTab);
    Rounded('a.activeTab', "top", "#FFF", "#C3DDAD", "smooth");
}

//end WST.View.RequestTour.TabsView.js


//start   ToggleMeetingOptionsEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object represents the toggle meeting options event.  This causes the meeting options section to be displayed
*   based on whether a meeting room is selected.
*
* @param inputElement - HTML meeting room input element.
* @param eventUtils - Event utility object.
* @param disableCssClass - CSS class used to hide the meeting options sections.
* @param documentUtils - Document utility object.
* @param baseElement - Root html element for the meeting room section.
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent = function(inputElement, eventUtils, disableCssClass, documentUtils, baseElement) {
    this._inputElement = inputElement;
    this._eventUtils = eventUtils;
    this._disableCssClass = disableCssClass;
    this._documentUtils = documentUtils;
    this._baseElement = baseElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes this event, causing the meeting options to be displayed if a meeting room is selected.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.ToggleMeetingOptionsEvent.prototype.executeEvent = function(evt) {
    var extension = cssQuery('#' + this._inputElement.name + '-extension', this._baseElement)[0];
    if (this._inputElement.value == 'true') {
        this._documentUtils.removeClass(extension, this._disableCssClass);
    } else if (this._inputElement.value == 'false') {
        this._documentUtils.addClass(extension, this._disableCssClass);
    }
}
//end      ToggleMeetingOptionsEvent.js

//start   WST.View.RequestTour.Event.ToggleCreditCardEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a toggle credit card event.  It either displays or hides the credit card section on the page.
*
* @param elements - Array of html elements representing the refreshment fields.
* @param creditCardInfoElement - HTML element representing the credit card section.
* @param disableCssClass - CSS class that causes the credit card section to be hidden.
* @param eventUtils - Event utililty object.
* @param documentUtils - Document utility object.
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent = function(elements, creditCardInfoElement, disableCssClass, eventUtils, documentUtils) {
    this._elements = elements;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
    this._creditCardInfoElement = creditCardInfoElement;
    this._disableCssClass = disableCssClass;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the event, causing the credit card section to toggle if any refreshments are selected.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.ToggleCreditCardEvent.prototype.executeEvent = function(evt) {
    var display = false;
    for (var i = 0; i < this._elements.length; i++) {
        if (this._elements[i].options[this._elements[i].selectedIndex].value.length > 0) {
            display = true;
        }
    }
    if (display) {
        this._documentUtils.removeClass(this._creditCardInfoElement, this._disableCssClass);
    } else {
        this._documentUtils.addClass(this._creditCardInfoElement, this._disableCssClass);
    }
}
//end      WST.View.RequestTour.Event.ToggleCreditCardEvent.js

//start WST.View.RequestTour.AdditionalServicesView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.ToggleMeetingOptionsEvent');
//JSAN.use('WST.View.RequestTour.Event.ToggleCreditCardEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is a view object for the additional services section of the request a tour page.  It is responsible
*   for interacting with the html in the additional services section.  It is also responsible for creating any
*   necessary events.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    this._attachMeetingEvents(baseElement, eventUtils, documentUtils, disableCssClass);
    //this._attachCreditCardEvents(baseElement, eventUtils, documentUtils, disableCssClass);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the events related to the meeting sections.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView.prototype._attachMeetingEvents = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    var meetings = cssQuery('.meeting', baseElement);
    for (var i = 0; i < meetings.length; i++) {
        var event = new WST.View.RequestTour.Event.ToggleMeetingOptionsEvent(meetings[i], eventUtils, disableCssClass, documentUtils, baseElement);
        event.attachEvent(meetings[i], 'click');
        if (meetings[i].id == 'meetingBeforeTrue' && meetings[i].checked) {
            event.executeEvent();
        }
        if (meetings[i].id == 'meetingAfterTrue' && meetings[i].checked) {
            event.executeEvent();
        }
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates and attaches the events related to the credit card section.
*
* @param baseElement - Base html element for the section.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
* @param disableCssClass - CSS class used to hide information on the page.
*/
WST.View.RequestTour.AdditionalServicesView.prototype._attachCreditCardEvents = function(baseElement, eventUtils, documentUtils, disableCssClass) {
    var refreshments = cssQuery('.refreshment', baseElement);
    var creditCardInfo = cssQuery('#creditCardInfo', baseElement)[0];
    var event = new WST.View.RequestTour.Event.ToggleCreditCardEvent(refreshments, creditCardInfo, disableCssClass, eventUtils, documentUtils);
    for (var i = 0; i < refreshments.length; i++) {
        event.attachEvent(refreshments[i], 'change');
        if (refreshments[i].selectedIndex > 0) {
            event.executeEvent();
        }
    }
}

//end WST.View.RequestTour.AdditionalServicesView.js


//start WST.View.Event.ToggleCalendarEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to define events that will cause the calendar to display and hide.
*
* @param calendarElement - HTML element representing the calendar.
* @param eventUtils - Event utility object.
* @param documentUtils - Document utility object.
*/
WST.View.Event.ToggleCalendarEvent = function(calendarElement, eventUtils, documentUtils) {
    this._calendarElement = calendarElement;
    this._eventUtils = eventUtils;
    this._documentUtils = documentUtils;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.View.Event.ToggleCalendarEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the toggle calendar event, causing the calendar to either be displayed or hidden.
*
* @param evt - Event object provided by the browser.
*/
WST.View.Event.ToggleCalendarEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    if (this._documentUtils.containsClass(this._calendarElement, 'hide')) {
//        var selectElements = document.getElementsByTagName('select');
//        for (var i = 0; i < selectElements.length; i++) {
//            Lib.Utils.DocumentUtils.addClass(selectElements[i], 'invisible');
//        }
        this._documentUtils.removeClass(this._calendarElement, 'hide');
    } else {
//        var selectElements = document.getElementsByTagName('select');
//        for (var i = 0; i < selectElements.length; i++) {
//            Lib.Utils.DocumentUtils.removeClass(selectElements[i], 'invisible');
//        }
        this._documentUtils.addClass(this._calendarElement, 'hide');
    }
}
//end     WST.View.Event.ToggleCalendarEvent.js

//start   WST.View.RequestTour.GeneralView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.Event.ToggleCalendarEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is the view for the general section of the request a tour page.  It handles all events and html on the
*   general section.
*
* @param calendar - Calendar widget.
* @param baseElement - Root html element of the general section.
* @param xmlUtils - XML utility object.
* @param documentUtils - Document utility object.
* @param eventUtils - Event utility object.
* @param objectUtils - Object utility object.
*/
WST.View.RequestTour.GeneralView = function(calendar, baseElement, xmlUtils, documentUtils, eventUtils, objectUtils,
                                            confirmController) {
    this._confirmController = confirmController;
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._attachCalendarEvent(calendar, eventUtils, xmlUtils);
    var reference = objectUtils.weakBind(this.updateDate, this);
    calendar.registerDateEventListener(reference);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method attaches the calendar event to the calendar icon.
*
* @param calendarElement - HTML element of the calendar.
* @param eventUtils - Event utility object.
*/
WST.View.RequestTour.GeneralView.prototype._attachCalendarEvent = function(calendar, eventUtils, xmlUtils) {
//    var calendarElement = cssQuery('#calendarContainer')[0];
//    var calendarLinks = cssQuery('.calendarLink');
//  for(var i = 0; i < calendarLinks.length; i++) {
//    var calendarLink = calendarLinks[i];
//    var event = new WST.View.Event.ToggleCalendarEvent(calendarElement, eventUtils, this._documentUtils);
//    event.attachEvent(calendarLink, 'click');
//  }

    var element = calendar.getCalendar();
    this._documentUtils.addClass(element, 'hide');
    var tourDateLabel = cssQuery('#tourDate', this._baseElement)[0].parentNode;
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    xmlUtils.insertAfter(brElement, tourDateLabel);
    xmlUtils.insertAfter(element, tourDateLabel);
    this._documentUtils.removeClass(brElement, 'mozclear');
    xmlUtils.insertAfter(brElement, element);

    var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
    if(calendarLink != null){
      var event = new WST.View.Event.ToggleCalendarEvent(element, eventUtils, this._documentUtils);
      event.attachEvent(calendarLink, 'click');
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method updates the date in the tour date field based on the value of the date object specified.
*
* @param date - Date object representing the new date.
*/
WST.View.RequestTour.GeneralView.prototype.updateDate = function(date) {
  var tourDate = cssQuery('#tourDate', this._baseElement)[0];
  tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
  tourDate.onchange();//have to call this manually coz date change from calendar does not trigger onchange automatically
  var calendarElement = cssQuery('.calendar', this._baseElement)[0];
  this._documentUtils.addClass(calendarElement, 'hide');
  this._confirmController.setConfirmValue(tourDate);
 }
//end WST.View.RequestTour.GeneralView.js

//start WST.View.RequestTour.Event.AddGuideEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for adding guides to the request a tour page.
*
* @param eventUtils - Event utility object.
* @param guidesView - Object representing the guides view.
*/
WST.View.RequestTour.Event.AddGuideEvent = function(eventUtils, guidesView) {
    this._eventUtils = eventUtils;
    this._guidesView = guidesView;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.AddGuideEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event for this object, adding the entered guide.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.AddGuideEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._eventUtils.cancelEventBubbling(evt);
    this._guidesView.addGuide();
}
//end WST.View.RequestTour.Event.AddGuideEvent.js

//start WST.View.RequestTour.Event.DeleteGuideEvent.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour.Event");

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is an event object for deleting guides from the request a tour page.
*
* @param eventUtils - Event utility object.
* @param guestsView - Object representing the guides view.
*/
WST.View.RequestTour.Event.DeleteGuideEvent = function(eventUtils, guidesView, index) {
    this._eventUtils = eventUtils;
    this._guidesView = guidesView;
    this._index = index;
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method attaches an event of the specified type to the specified element, binding it to this object.
*
* @param element - Page element to bind event to.
* @param type - String representing the type of event, ie. "click"
*/
WST.View.RequestTour.Event.DeleteGuideEvent.prototype.attachEvent = function(element, type) {
    this._eventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: public
* description:
*   This method executes the event for this object, deleting the entered guide.
*
* @param evt - Event object provided by the browser.
*/
WST.View.RequestTour.Event.DeleteGuideEvent.prototype.executeEvent = function(evt) {
    this._eventUtils.cancelDefaultAction(evt);
    this._guidesView.deleteGuide(this._index);
}

//end WST.View.RequestTour.Event.DeleteGuideEvent.js

//start  WST.View.RequestTour.GuidesView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.View.RequestTour.Event.AddGuideEvent');
JSAN.use('WST.View.RequestTour.Event.DeleteGuideEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.RequestTour");

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * @constructor
 * description:
 *   This object is a view object for the guests section of the request a tour page.  It is responsible for interacting
 *   with the html on the page providing events and any necessary dhtml.
 *
 * @param baseElement - Root html element for the guests section.
 * @param formUtils - Form utility object.
 * @param objectUtils - Object utility object.
 * @param documentUtils - Document utility object.
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView = function(baseElement, formUtils, objectUtils, documentUtils, eventUtils,
                                           numGuidesElement, confirmController, errorView, calendar, xmlUtils) {
    this._baseElement = baseElement;
    this._formUtils = formUtils;
    this._objectUtils = objectUtils;
    this._documentUtils = documentUtils;
    this._eventUtils = eventUtils;
    this._numGuidesElement = numGuidesElement;
    this._confirmController = confirmController;
    this._createAddGuideEvent(eventUtils);
    this._attachEventsToExistingGuides();
    this._errorView = errorView;
    this._calendar = calendar;
    this._xmlUtils = xmlUtils;
    this._attachCalendarEvent(calendar, eventUtils, xmlUtils);
    var reference = objectUtils.weakBind(this.updateTourTable, this);
    calendar.registerDateEventListener(reference);
}

/**
 * author: Nate Minshew
 * date created: 07/12/2006
 * access level: private
 * description:
 *   This method attaches the calendar event to the calendar icon.
 *
 * @param calendarElement - HTML element of the calendar.
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView.prototype._attachCalendarEvent = function(calendar, eventUtils, xmlUtils) {
    //    var calendarElement = cssQuery('#calendarContainer')[0];
    //    var calendarLinks = cssQuery('.calendarLink');
    //  for(var i = 0; i < calendarLinks.length; i++) {
    //    var calendarLink = calendarLinks[i];
    //    var event = new WST.View.Event.ToggleCalendarEvent(calendarElement, eventUtils, this._documentUtils);
    //    event.attachEvent(calendarLink, 'click');
    //  }
    var element = calendar.getCalendar();
    var guidesTable = cssQuery('#guideTable', this._baseElement)[0];
    var brElement = document.createElement('br');
    brElement.className = 'mozclear';
    if (guidesTable != null){
    xmlUtils.insertAfter(brElement, guidesTable);
    xmlUtils.insertAfter(element, guidesTable);
    this._documentUtils.removeClass(brElement, 'mozclear');
    xmlUtils.insertAfter(brElement, element);
    }

//    var calendarLink = cssQuery('#calendarLink', this._baseElement)[0];
    //    if(calendarLink != null){
    //      var event = new WST.View.Event.ToggleCalendarEvent(element, eventUtils, this._documentUtils);
    //      event.attachEvent(calendarLink, 'click');
    //    }

}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: public
 * description:
 *   This method adds a guide depending on the current mode and updates the guides table.
 */
WST.View.RequestTour.GuidesView.prototype.addGuide = function() {
    var button = cssQuery('#addGuideButton', this._baseElement)[0];
    this._addGuide();
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method adds the entered guide to the request a tour form and the gudies table.
 */
WST.View.RequestTour.GuidesView.prototype._addGuide = function() {
    this._errorView.clearAllErrors();
    var idElement = cssQuery('#guideName-dhtml', this._baseElement)[0];

    var fieldset = document.getElementById('guidesPage');
    var index = this._getNumGuides();

    var guideId = idElement.options[idElement.selectedIndex].value;

    if (guideId != null && guideId != '') {
        if (!this._isGuideAlreadyAdded(guideId)) {
          this._createHiddenInput('guideId', guideId, fieldset, index);
          this._removeNoGuidesRow();
          this._addGuideToTable(this._formUtils.getSelectedText(idElement));
          //this._updateNumGuides();
          this._confirmController.addGuide(idElement.value);
          autosave(document.forms['tourForm']);
        } else {
            this._errorView.displayErrorMessage('Guide already added');
        }
    }
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: public
 * description:
 *   This method removes the guide at the specified index from the form and table.
 *
 * @param index - Index of guest.
 */
WST.View.RequestTour.GuidesView.prototype.deleteGuide = function(index) {
    this._errorView.clearAllErrors();
    var idHiddenElement = cssQuery('#guideId-' + index, this._baseElement)[0];
    idHiddenElement.parentNode.removeChild(idHiddenElement);
    this._removeGuideFromTable(index);
    //this._updateNumGuides();
    this._confirmController.deleteGuide(index);
    autosave(document.forms['tourForm']);

}

WST.View.RequestTour.GuidesView.prototype._isGuideAlreadyAdded = function(guideId) {
    var guideIds = cssQuery('.guideIds', this._baseElement);
    for (var i = 0; i < guideIds.length; i++) {
        var currentId = guideIds[i].value;
        if (currentId == guideId) {
            return true;
        }
    }
    return false;
}

/**
 * author: Nate Minshew
 * date created: 07/25/2006
 * access level: private
 * description:
 *   This method attaches the edit and delete events to any existing guides.
 */
WST.View.RequestTour.GuidesView.prototype._attachEventsToExistingGuides = function() {
    var deleteGuideLinks = cssQuery('.deleteGuideLink');
    for (var i = 0; i < deleteGuideLinks.length; i++) {
        this._attachDeleteEvent(deleteGuideLinks[i], i);
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates a hidden input field for one of the guide fields.
 *
 * @param name - Name of the input field.
 * @param value - Value of the input field.
 */
WST.View.RequestTour.GuidesView.prototype._createHiddenInput = function(name, value, parent, index) {
    var element = this._formUtils.createInputField(name);
    element.type = 'hidden';
    element.id = name + '-' + index;
    element.className = "guideIds";
    element.value = value;
    parent.appendChild(element);
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method adds a guest to the guide table.
 *
 * @param name - Text representing the guide name
 */
WST.View.RequestTour.GuidesView.prototype._addGuideToTable = function(name) {
    var tableBody = cssQuery('#guideTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    row.className = 'guideRow';
    row.id = 'guideRow-' + this._getNumGuides();
    row.appendChild(this._createGuideColumn(name));
    row.appendChild(this._createActionsColumn());
    tableBody.appendChild(row);
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method deletes the guide at the specified index from the guides table
 *
 * @param index - Index of guest.
 */
WST.View.RequestTour.GuidesView.prototype._removeGuideFromTable = function(index) {
    var row = cssQuery('#guideRow-' + index, this._baseElement)[0];
    row.parentNode.removeChild(row);
    if (this._getNumGuides() == 0) {
        this._addNoGuidesRow();
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates the actions column with edit and delete links.
 */
WST.View.RequestTour.GuidesView.prototype._createActionsColumn = function() {
    var columnElement = this._createGuideColumn();
    columnElement.className = 'guideActions';
    var deleteLink = document.createElement('a');
    deleteLink.className = 'deleteGuideLink';
    deleteLink.href = '#';
    this._attachDeleteEvent(deleteLink, this._getNumGuides());
    deleteLink.appendChild(document.createTextNode('delete'));

    columnElement.appendChild(deleteLink);

    return columnElement;
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method attaches the delete guide event to the specified delete link.
 *
 * @param deleteLink - HTML link element.
 */
WST.View.RequestTour.GuidesView.prototype._attachDeleteEvent = function(deleteLink, index) {
    var event = new WST.View.RequestTour.Event.DeleteGuideEvent(this._eventUtils, this, index);
    event.attachEvent(deleteLink, 'click');
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This methood creates a guide column with the value specified.
 *
 * @param value - The text to be added to the column.
 */
WST.View.RequestTour.GuidesView.prototype._createGuideColumn = function(value) {
    var column = document.createElement('td');
    if (this._objectUtils.isDefined(value)) {
        column.appendChild(document.createTextNode(value));
    }
    return column;
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method removes the no guests row.
 */
WST.View.RequestTour.GuidesView.prototype._removeNoGuidesRow = function() {
    var noGuidesCol = cssQuery('#noGuides', this._baseElement)[0];
    if (this._objectUtils.isDefined(noGuidesCol)) {
        noGuidesRow = noGuidesCol.parentNode;
        noGuidesRow.parentNode.removeChild(noGuidesRow);
    }
}

/**
 * author: Nate Minshew
 * date created: 07/19/2006
 * access level: private
 * description:
 *   This method adds the no guides column to the guides table.
 */
WST.View.RequestTour.GuidesView.prototype._addNoGuidesRow = function() {
    var tableBody = cssQuery('#guideTableBody', this._baseElement)[0];
    var row = document.createElement('tr');
    var noGuidesCol = document.createElement('td');
    noGuidesCol.id = 'noGuides';
    noGuidesCol.colSpan = 4;
    noGuidesCol.appendChild(document.createTextNode('No Guides Entered'));
    row.appendChild(noGuidesCol);
    tableBody.appendChild(row);
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method creates the add guest event for adding guests to the form and table.
 *
 * @param eventUtils - Event utility object.
 */
WST.View.RequestTour.GuidesView.prototype._createAddGuideEvent = function(eventUtils) {
    var addGuideButton = cssQuery('#addGuideButton', this._baseElement)[0];
    if (addGuideButton != null) {
        var event = new WST.View.RequestTour.Event.AddGuideEvent(eventUtils, this);
        event.attachEvent(addGuideButton, 'click');
    }
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method updates the number guides info in the tab.
 */
WST.View.RequestTour.GuidesView.prototype._updateNumGuides = function() {
    var numGuides = this._getNumGuides();
    this._numGuidesElement.firstChild.nodeValue = '(' + numGuides + ')';
}

/**
 * author: Nate Minshew
 * date created: 07/13/2006
 * access level: private
 * description:
 *   This method returns the number of guides that have been created.
 */
WST.View.RequestTour.GuidesView.prototype._getNumGuides = function() {
    return cssQuery('.guideRow', this._baseElement).length;
}

/**
 * author: Nate Minshew
 * date created: 07/12/2006
 * access level: private
 * description:
 *   This method updates the tour table in the guides tab based on the value of the date object specified.
 *
 * @param date - Date object representing the new date.
 */
WST.View.RequestTour.GuidesView.prototype.updateTourTable = function(date) {
    var tourDate = cssQuery('#tourTableUnderGuides', this._baseElement)[0];
    var tourController = new WST.Controller.RequestTour.TourControllerUnderGuides();
    var currentDate = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
    tourController._getTourList(currentDate);
//    tourDate.value = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getYear();
//    var calendarElement = cssQuery('.calendar', this._baseElement)[0];
  //  var calendarElement = cssQuery('#calendar', this._baseElement)[0];
//    this._documentUtils.addClass(calendarElement, 'hide');
//    this._confirmController.setConfirmValue(tourDate);
}
//end WST.View.RequestTour.GuidesView.js

//start  WST.View.ErrorView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 07/13/2006
* @constructor
* description:
*   This object is used to display error messages to the user.
*
* @param baseElement - Root html element for error messages.
* @param documentUtils - Document utility object
* @param objectUtils - Object utility object.
* @param xmlUtils - XML utility object.
*/
WST.View.ErrorView = function(baseElement, documentUtils, objectUtils, xmlUtils) {
    this._baseElement = baseElement;
    this._documentUtils = documentUtils;
    this._objectUtils = objectUtils;
    this._xmlUtils = xmlUtils;
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method displays the specified error message and decorates the specified field's label.
*
* @param message - Text error message.
* @param field - HTML element for the field that has the error.
*/
WST.View.ErrorView.prototype.displayErrorMessage = function(message, field) {
    var brElement = document.createElement('br');
    this._baseElement.appendChild(document.createTextNode(message));
    this._baseElement.appendChild(brElement);
    if (this._objectUtils.isDefined(field)) {
        this._decorateErrorFieldLabel(field);
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: public
* description:
*   This method clears all error messages currently being displayed.
*/
WST.View.ErrorView.prototype.clearAllErrors = function() {
    this._xmlUtils.removeAllChildren(this._baseElement);
    this._clearErrorLabels();
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method clears all error labels.
*/
WST.View.ErrorView.prototype._clearErrorLabels = function() {
    var errorFields = cssQuery('.fieldError');
    for (var i = 0; i < errorFields.length; i++) {
        Lib.Utils.DocumentUtils.removeClass(errorFields[i], 'fieldError');
    }
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method decorates the label of the specified field.
*
* @param field - HTML input element with the error.
*/
WST.View.ErrorView.prototype._decorateErrorFieldLabel = function(field) {
    var fieldLabel = document.getElementById(field.id + '-label');
    if (this._objectUtils.isDefined(fieldLabel)) {
        this._documentUtils.addClass(fieldLabel, 'fieldError');
    }
}
//end  WST.View.ErrorView.js

//start WST.Controller.RequestTour.ConfirmController.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");

/**
* author: Nate Minshew
* date created: 07/25/2006
* @constructor
* description:
*   This object is a controller for the confirm section of the request a tour page.  It acts as an interface for
*   performing actions on the confirm section.
*/
WST.Controller.RequestTour.ConfirmController = function() {
    this._confirmValueListeners = new Array();
    this._addGuestListeners = new Array();
    this._editGuestListeners = new Array();
    this._deleteGuestListeners = new Array();
    this._addGuideListeners = new Array();
    this._editGuideListeners = new Array();
    this._deleteGuideListeners = new Array();
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to setConfirmValue.  When another object calls the
*   setConfirmValue method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the setConfirmValue method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerConfirmValueListener = function(listener) {
    this._confirmValueListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to addGuest.  When another object calls the
*   addGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerAddGuestListener = function(listener) {
    this._addGuestListeners.push(listener);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to addGuide.  When another object calls the
*   addGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerAddGuideListener = function(listener) {
    this._addGuideListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to editGuest.  When another object calls the
*   editGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the editGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerEditGuestListener = function(listener) {
    this._editGuestListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to deleteGuest.  When another object calls the
*   deleteGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerDeleteGuestListener = function(listener) {
    this._deleteGuestListeners.push(listener);
}


/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method registers the specified listener for calls to deleteGuide.  When another object calls the
*   deleteGuest method, all listeners will be notified.
*
* @param listener - Object/Function that will be listening to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype.registerDeleteGuideListener = function(listener) {
    this._deleteGuideListeners.push(listener);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to set the confirm value of the specified
*   input element.
*
* @param inputElement - HTML element with the confirm value.
*/
WST.Controller.RequestTour.ConfirmController.prototype.setConfirmValue = function(inputElement) {
    this._notifyConfirmValueListeners(inputElement);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to add the guest to the confirm section.
*
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location
*/
WST.Controller.RequestTour.ConfirmController.prototype.addGuest = function(name, classification, location) {
    this._notifyAddGuestListeners(name, classification, location);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to add the guide to the confirm section.
*
* @param name - Guide's name.
*/
WST.Controller.RequestTour.ConfirmController.prototype.addGuide = function(guideName) {
    this._notifyAddGuideListeners(guideName);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to edit the guest in the confirm section.
*
* @param index - Index of guest.
* @param name - Guest's name.
* @param classification - Guest's classification.
* @param location - Guest's location
*/
WST.Controller.RequestTour.ConfirmController.prototype.editGuest = function(index, name, classification, location) {
    this._notifyEditGuestListeners(index, name, classification, location);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to delete the guest in the confirm section.
*
* @param index - Index of guest.
*/
WST.Controller.RequestTour.ConfirmController.prototype.deleteGuest = function(index) {
    this._notifyDeleteGuestListeners(index);
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method calls all listeners listening to this method.  It's purpose is to delete the guide in the confirm section.
*
* @param index - Index of guest.
*/
WST.Controller.RequestTour.ConfirmController.prototype.deleteGuide = function(index) {
    this._notifyDeleteGuideListeners(index);
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the setConfirmValue method was called.
*
* @param inputElement - HTML element passed to the setConfirmValue method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyConfirmValueListeners = function(inputElement) {
    for (var i = 0; i < this._confirmValueListeners.length; i++) {
        this._confirmValueListeners[i](inputElement);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the addGuest method was called.
*
* @param inputElement - HTML element passed to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyAddGuestListeners = function(name, classification, location) {
    for (var i = 0; i < this._addGuestListeners.length; i++) {
        this._addGuestListeners[i](name, classification, location);
    }
}
/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the addGuide method was called.
*
* @param inputElement - HTML element passed to the addGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyAddGuideListeners = function(name) {
    for (var i = 0; i < this._addGuideListeners.length; i++) {
        this._addGuideListeners[i](name);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the editGuest method was called.
*
* @param inputElement - HTML element passed to the editGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyEditGuestListeners = function(index, name, classification, location) {
    for (var i = 0; i < this._editGuestListeners.length; i++) {
        this._editGuestListeners[i](index, name, classification, location);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the deleteGuest method was called.
*
* @param inputElement - HTML element passed to the deleteGuest method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyDeleteGuestListeners = function(index) {
    for (var i = 0; i < this._deleteGuestListeners.length; i++) {
        this._deleteGuestListeners[i](index);
    }
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method notifies all listeners that the deleteGuest method was called.
*
* @param inputElement - HTML element passed to the deleteGuide method.
*/
WST.Controller.RequestTour.ConfirmController.prototype._notifyDeleteGuideListeners = function(index) {
    for (var i = 0; i < this._deleteGuideListeners.length; i++) {
        this._deleteGuideListeners[i](index);
    }
}

//end  WST.Controller.RequestTour.ConfirmController.js

//start WST.Model.Admin.Blackout.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

WST.Model.Admin.Blackout = function(date, reason) {
    this._date = date;
    this._reason = reason;
}

WST.Model.Admin.Blackout.prototype.getDate = function() {
    return this._date;
}

WST.Model.Admin.Blackout.prototype.getReason = function() {
    return this._reason;
}
//end WST.Model.Admin.Blackout.js

//start WST.View.Admin.BlackoutDateView.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View.Admin");

WST.View.Admin.BlackoutDateView = function() {
}

WST.View.Admin.BlackoutDateView.prototype.updateDateElement = function(dateElement, isBlackedOut) {
    if (isBlackedOut) {
        Lib.Utils.DocumentUtils.addClass(dateElement, 'blackoutDate');
    } else {
        Lib.Utils.DocumentUtils.removeClass(dateElement, 'blackoutDate');
    }
}
//end WST.View.Admin.BlackoutDateView.js

//start  WST.Model.Admin.BlackoutList.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Model.Admin.Blackout");
JSAN.use('WST.View.Admin.BlackoutDateView');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model.Admin");

/**
* author: Nate Minshew
* date created: 07/27/2006
* @constructor
* description:
*   This object represents a list of blackout dates.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList = function(blackoutListXML) {
    this._blackouts = new Array();
    this._parseList(blackoutListXML);
    this._blackoutDateView = new WST.View.Admin.BlackoutDateView();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of Blackout objects.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackouts = function() {
    return this._blackouts;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: public
* description:
*   This method returns an array of blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype.getBlackoutDates = function() {
    var dates = new Array();
    for (var i = 0; i < this._blackouts.length; i++) {
        dates.push(new Date(this._blackouts[i].getDate()));
    }
    return dates;
}

WST.Model.Admin.BlackoutList.prototype.processDateElement = function(date, dateElement) {
    this._blackoutDateView.updateDateElement(dateElement, this._isBlackedOut(date));
}

WST.Model.Admin.BlackoutList.prototype._isBlackedOut = function(date) {
    var blackoutDates = this.getBlackoutDates();
    for (var i = 0; i < blackoutDates.length; i++) {
        if (blackoutDates[i].getYear() == date.getYear()
                && blackoutDates[i].getMonth() == date.getMonth()
                && blackoutDates[i].getDate() == date.getDate()) {
            return true;
        }
    }
    return false;
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method parses the xml document of blackout dates into Blackout objects.
*
* @param blackoutListXML - XML document representing the blackout dates.
*/
WST.Model.Admin.BlackoutList.prototype._parseList = function(blackoutListXML) {
    var blackoutElements = blackoutListXML.getElementsByTagName('blackout');
    for (var i = 0; i < blackoutElements.length; i++) {
        var date = blackoutElements[i].getAttribute('date');
        var reason = null; //blackoutElements[i].getAttribute('reason');
        this._blackouts.push(new WST.Model.Admin.Blackout(date, reason));
    }
}

//end WST.Model.Admin.BlackoutList.js

//start  WST.Controller.Admin.BlackoutController.js
 // Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Model.Admin.BlackoutList');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.Admin");

/**
* author: Nate Minshew
* date created: 07/25/2006
* @constructor
* description:
*   This object is a controller for blackout dates.  It acts as a transportation layer.
*
* @param ajaxUtils - Ajax utility object.
* @param blackoutListUrl - Url of the blackout list service.
*/
WST.Controller.Admin.BlackoutController = function(ajaxUtils, blackoutListUrl, selectedDate) {
    this._selectedDate = selectedDate;
    this._ajaxUtils = ajaxUtils;
    this._blackoutListUrl = blackoutListUrl;
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: public
* description:
*   This method retrieves a list of blackout dates from the server.
*/
WST.Controller.Admin.BlackoutController.prototype.getBlackoutList = function() {
    if (Lib.Utils.ObjectUtils.isDefined(this._selectedDate)
       && Lib.Utils.ObjectUtils.isDefined(this._blackoutListUrl)){
       this._blackoutListUrl = this._blackoutListUrl + '&selectedDate=' + this._selectedDate;
    }
    var xml = this._ajaxUtils.requestSynchronousFeed(this._blackoutListUrl);
    return new WST.Model.Admin.BlackoutList(xml);
}

WST.Controller.Admin.BlackoutController.prototype.updateCalendar = function(calendar) {
    var blackoutList = this.getBlackoutList();
    var reference = Lib.Utils.ObjectUtils.weakBind(blackoutList.processDateElement, blackoutList);
    calendar.registerDateInitListener(reference);
    for (var i = 0; i < blackoutList.getBlackoutDates().length; i++) {
        calendar.disableDate(blackoutList.getBlackoutDates()[i]);
    }
}
//end  WST.Controller.Admin.BlackoutController.js



//start WST.TourCalendar.Model.TourList
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.Tour');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('WST.TourCalendar.Model.Guide');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.TourList = function(status, getGuidesOrNot, guideId, calendar, currentDate, parentClass, callback) {
    var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._status = status;
    this._guideId = guideId;
    this._tours = new Array();
    this.refreshListAsynchronously(getGuidesOrNot, currentDate, calendar, this, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.TourList.prototype.refreshList = function() {
    this._tours = this._parseTourXml(this._getToursXml());
}

WST.TourCalendar.Model.TourList.prototype.refreshListAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject,  parentClass, callback) {
    this._tours = this._getToursXmlAsynchronously(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback);
}

WST.TourCalendar.Model.TourList.prototype._getToursXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getTourServiceUrl());
}

WST.TourCalendar.Model.TourList.prototype._getToursXmlAsynchronously = function(getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
    return Lib.Utils.XML.AjaxUtils.requestAsynchronousFeed(this._getTourServiceUrl(), getGuidesOrNot, currentDate, calendar, tourListObject, callback, parentClass, this._parseTourXmlAsynchronously);
}

WST.TourCalendar.Model.TourList.prototype.setStatus = function(status) {
    this._status = status;
}

WST.TourCalendar.Model.TourList.prototype.getToursByDate = function(date) {
    var tours = new Array();
    for (var i = 0; i < this._tours.length; i++) {
        if (this._tours[i].getStartDate().getFullYear() == date.getFullYear()
                && this._tours[i].getStartDate().getMonth() == date.getMonth()
                && this._tours[i].getStartDate().getDate() == date.getDate()) {
            tours.push(this._tours[i]);
        }
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseTourXmlAsynchronously = function(request, getGuidesOrNot, currentDate, calendar, tourListObject, parentClass, callback) {
  var xmlDoc = request.responseXML;
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
        if (getGuidesOrNot) {
          guides = tourListObject._parseGuideXml(tourElements[i]);
        }
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    tourListObject._tours = tours;
    callback(tourListObject, calendar, currentDate, parentClass);
}

WST.TourCalendar.Model.TourList.prototype._parseTourXml = function(xmlDoc) {
    var tourElements = xmlDoc.getElementsByTagName('tour');
    var tours = new Array();
    var guides = new Array();
    for (var i = 0; i < tourElements.length; i++) {
        var id = tourElements[i].getAttribute('id');
        var startDate = tourElements[i].getAttribute('startDate');
        var endDate = tourElements[i].getAttribute('endDate');
        var startTime = tourElements[i].getAttribute('startTime');
        var endTime = tourElements[i].getAttribute('endTime');
        var location = tourElements[i].getAttribute('location');
        var numGuests = tourElements[i].getAttribute('numGuests');
        var place = tourElements[i].getAttribute('place');
        var organization = tourElements[i].getAttribute('visitorOrganization');
//        var guides = this._parseGuideXml(tourElements[i]);
        tours.push(new WST.TourCalendar.Model.Tour(id, startDate, endDate, startTime, endTime, location, numGuests, place, organization, guides));
    }
    return tours;
}

WST.TourCalendar.Model.TourList.prototype._parseGuideXml = function(tourElement) {
    var guideElements = tourElement.getElementsByTagName('guide');
    var guides = new Array();
    for (var i = 0; i < guideElements.length; i++) {
        var id = guideElements[i].getAttribute('id');
        var name = guideElements[i].getAttribute('name');
        guides.push(new WST.TourCalendar.Model.Guide(id, name));
    }
    return guides;
}


WST.TourCalendar.Model.TourList.prototype._getTourServiceUrl = function() {
    var tourServiceUrl = 'listTours.htm?method=listToursByCriteria&view=xml&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&status=' + this._status;
    if (Lib.Utils.ObjectUtils.isDefined(this._guideId) && this._guideId != 'All') {
        tourServiceUrl = tourServiceUrl + '&guide=' + this._guideId;
    }
    return tourServiceUrl;
}

WST.TourCalendar.Model.TourList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.TourList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}

//end   WST.TourCalendar.Model.TourList

//start  WST.TourCalendar.Model.OutOfOffice.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Utils.DateUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOffice = function(id, guideId, guideName, startDate, startTime, endDate, endTime, allDay,
                                              noEndDate, days) {
    this._id = id;
    this._guideId = guideId;
    this._guideName = guideName;
    this._startDate = new Date(startDate);
    if (endDate != '' && endDate != null) {
        this._endDate = new Date(endDate);
    }
    this._startTime = startTime;
    if (endTime != '' && endTime != null) {
        this._endTime = endTime;
    }
    this._allDay = allDay;
    this._noEndDate = noEndDate;
    this._days = days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getId = function() {
    return this._id;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideId = function() {
    return this._guideId;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getGuideName = function() {
    return this._guideName;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartDate = function() {
    return this._startDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getStartTime = function() {
    return this._startTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndDate = function() {
    return this._endDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getEndTime = function() {
    return this._endTime;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getAllDay = function() {
    return this._allDay;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getNoEndDate = function() {
    return this._noEndDate;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getDays = function() {
    return this._days;
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedDateRange = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, null, null);
    }
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, null, this._endDate, null);
    }
    if (this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, null, null);
    }
    return new WST.Utils.DateUtils().getFormattedDateRange(this._startDate, this._startTime, this._endDate, this._endTime);
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedStartDateAndTime = function() {
    if (this._allDay == 'Yes' && this._noEndDate == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, null);
    }else{
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._startDate, this._startTime);
    }
}

WST.TourCalendar.Model.OutOfOffice.prototype.getFormattedEndDateAndTime = function() {
    if (this._allDay == 'Yes') {
        return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, null);
    }else {
      return new WST.Utils.DateUtils().getFormattedDateAndTime(this._endDate, this._endTime);
    }
}

//end  WST.TourCalendar.Model.OutOfOffice.js

//start WST.TourCalendar.Model.OutOfOfficeList
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.TourCalendar.Model.OutOfOffice');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Model");

WST.TourCalendar.Model.OutOfOfficeList = function(guideId, currentDate) {
     var date;
    if (currentDate == null) {
      date = new Date();
    } else {
      date = currentDate;
    }
    date.setDate(1);
    this._startDate = this._formatDate(date);
    date.setDate(Lib.Utils.DateUtils.getDaysInMonth(date.getMonth(), date.getFullYear()));
    this._endDate = this._formatDate(date);
    this._guideId = guideId;
    this._outOfOfficeList = new Array();
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.updateList = function(month, year) {
    var startDate = new Date(year, month, 1);
    this._setStartDate(startDate);
    var endDate = new Date(year, month, Lib.Utils.DateUtils.getDaysInMonth(month, year));
    this._setEndDate(endDate);
    this.refreshList();
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.refreshList = function() {
    this._outOfOfficeList = this._parseOutOfOfficeXml(this._getOutOfOfficeXml());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype.getOutOfOfficeByDate = function(date) {
    var outOfOfficeList = new Array();
    for (var i = 0; i < this._outOfOfficeList.length; i++) {
        if (this._outOfOfficeList[i].getStartDate().getFullYear() == date.getFullYear()
                && this._outOfOfficeList[i].getStartDate().getMonth() == date.getMonth()
                && this._outOfOfficeList[i].getStartDate().getDate() == date.getDate()) {
            outOfOfficeList.push(this._outOfOfficeList[i]);
        }
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseOutOfOfficeXml = function(xmlDoc) {
    var outOfOfficeElements = xmlDoc.getElementsByTagName('outOfOffice');
    var outOfOfficeList = new Array();
    for (var i = 0; i < outOfOfficeElements.length; i++) {
        var id = null; //outOfOfficeElements[i].getAttribute('id');
        var guideId = outOfOfficeElements[i].getAttribute('guideId');
        var guideName = null; //outOfOfficeElements[i].getAttribute('guideName');
        var startDate = outOfOfficeElements[i].getAttribute('startDate');
        var startTime = outOfOfficeElements[i].getAttribute('startTime');
        var endDate = outOfOfficeElements[i].getAttribute('endDate');
        var endTime = outOfOfficeElements[i].getAttribute('endTime');
        var allDay = outOfOfficeElements[i].getAttribute('allDay');
        var noEndDate = outOfOfficeElements[i].getAttribute('noEndDate');
        var days = this._parseDaysXml(outOfOfficeElements[i]);
        outOfOfficeList.push(new WST.TourCalendar.Model.OutOfOffice(id, guideId, guideName, startDate, startTime, endDate,
                endTime, allDay, noEndDate, days));
    }
    return outOfOfficeList;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._parseDaysXml = function(outOfOfficeElement) {
    var dayElements = outOfOfficeElement.getElementsByTagName('day');
    var days = new Array();
    for (var i = 0; i < dayElements.length; i++) {
        days.push(dayElements[i].firstChild.nodeValue);
    }
    return days;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeXml = function() {
    return Lib.Utils.XML.AjaxUtils.requestSynchronousFeed(this._getOutOfOfficeServiceUrl());
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._getOutOfOfficeServiceUrl = function() {
    return 'lookupOutOfOffice.htm?method=lookupOutOfOfficeByCriteria&startDate=' + this._startDate + '&endDate=' + this._endDate
            + '&guideId=' + this._guideId;
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setStartDate = function(date) {
    this._startDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._setEndDate = function(date) {
    this._endDate = this._formatDate(date);
}

WST.TourCalendar.Model.OutOfOfficeList.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}

//end  WST.TourCalendar.Model.OutOfOfficeList

//start  WST.Event.WindowCloseEvent
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event");

WST.Event.WindowCloseEvent = function(targetElement) {
    this._targetElement = targetElement;
}

WST.Event.WindowCloseEvent.prototype.attachEvent = function(element, type) {
    Lib.Utils.EventUtils.addEvent(element, "mouseout", this.executeEvent, this);
}

WST.Event.WindowCloseEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
//    var selectElements = document.getElementsByTagName('select');
//    for (var i = 0; i < selectElements.length; i++) {
//        Lib.Utils.DocumentUtils.removeClass(selectElements[i], 'invisible');
//    }
    Lib.Utils.DocumentUtils.addClass(this._targetElement, 'hide');
}
//end  WST.Event.WindowCloseEvent

//start  WST.TourCalendar.View.CalendarEntryView
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('WST.Event.WindowCloseEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.View");

WST.TourCalendar.View.CalendarEntryView = function(template, tourList, outOfOfficeList, viewDataType) {
    this._template = template;
    this._tourList = tourList;
    this._outOfOfficeList = outOfOfficeList;
    this._viewDataType = viewDataType;
    this._entryEvents = new Array();
}

WST.TourCalendar.View.CalendarEntryView.prototype.updateDateElement = function(date, dateElement) {
    if (Lib.Utils.ObjectUtils.isDefined(this._tourList)) {
        this._addTours(date, dateElement);
    }
    if (Lib.Utils.ObjectUtils.isDefined(this._outOfOfficeList)) {
        this._addOutOfOffice(date, dateElement);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype.registerCalendarEntryEvent = function(event) {
    this._entryEvents.push(event);
}

WST.TourCalendar.View.CalendarEntryView.prototype._attachCalendarEntryEvents = function(calendarEntryLink, entryDetailElement) {
    for (var i = 0; i < this._entryEvents.length; i++) {
        var event = new this._entryEvents[i](entryDetailElement);
        event.attachEvent(calendarEntryLink);
    }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTours = function(date, dateElement) {
  var tours = this._tourList.getToursByDate(date);
  if (tours != null && tours.length > 0){
     if (Lib.Utils.ObjectUtils.isDefined(this._viewDataType)
         && this._viewDataType == 'RequestTour'){
                 this._addToursForRequestTours(dateElement, tours);
     }else{
       this._addToursForScheduledTours(dateElement, tours);
     }
  }
}

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForRequestTours = function(dateElement, tours) {
      if (tours != null && tours.length > 0){
      var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarRequestedTourEntry'));
      var dateLink = cssQuery('.dateLink', dateElement)[0];
      var entryDetail = cssQuery('.entryRequestedTourDetail', calendarEntry)[0];

        var popupHTML = '<ul class="calStartTimePlace">';
        for (var i = 0; i < tours.length; i++) {
          popupHTML  +=  '   <li>' +
                               tours[i].getStartTime() +
                               '  ' +
                               tours[i].getPlace() +
                          '   </li>';
        }
        popupHTML += '</ul>';
        entryDetail.innerHTML = popupHTML;
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

//      var calStartTimePlace = cssQuery('.calStartTimePlace', entryDetail)[0];
//      Lib.Utils.XML.XMLUtils.removeAllChildren(calStartTimePlace);
//      for (var i = 0; i < tours.length; i++) {
//          var listElement = document.createElement('li');
//          listElement.innerHTML = tours[i].getStartTime() + " " + tours[i].getPlace() ;
//          calStartTimePlace.appendChild(listElement);
//      }
//      Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');

      this._attachCalendarEntryEvents(dateLink, entryDetail);
      dateElement.appendChild(calendarEntry);
    }
  }

WST.TourCalendar.View.CalendarEntryView.prototype._addToursForScheduledTours = function(dateElement, tours) {
           var dateEntry = document.createElement('div');
           dateEntry.className = 'dateEntry';
           for (var i = 0; i < tours.length; i++) {
              var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarTourEntry'));
              var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
                //calendarEntryLink.title = tours[i].getOrganization(); // in anticipation of client req
                calendarEntryLink.title = tours[i].getPlace();
              var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];
              timeElement.innerHTML = tours[i].getStartTime();
              var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
                 // descElement.innerHTML = tours[i].getOrganization();// in anticipation of client req
                  descElement.innerHTML = tours[i].getPlace();
              var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
              this._addTourDetails(entryDetail, tours[i], calendarEntryLink);
              Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
              this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
              dateEntry.appendChild(calendarEntry);
            }
       dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOffice = function(date, dateElement) {
    var outOfOfficeList = this._outOfOfficeList.getOutOfOfficeByDate(date);
    var dateEntry = document.createElement('div');
    dateEntry.className = 'dateEntry';
    for (var i = 0; i < outOfOfficeList.length; i++) {
        var calendarEntry = Lib.Utils.DocumentUtils.copyHTMLElement(this._template.getRootElement('calendarOutOfOfficeEntry'));
        var calendarEntryLink = cssQuery('.calendarEntryLink', calendarEntry)[0];
        var timeElement = calendarEntryLink.getElementsByTagName('dt')[0];
        timeElement.innerHTML = outOfOfficeList[i].getStartTime();
        var descElement = calendarEntryLink.getElementsByTagName('dd')[0];
        descElement.innerHTML = 'OOO';
        var entryDetail = cssQuery('.entryDetail', calendarEntry)[0];
        this._addOutOfOfficeDetails(entryDetail, outOfOfficeList[i], calendarEntryLink);
        Lib.Utils.DocumentUtils.addClass(entryDetail, 'hide');
        this._attachCalendarEntryEvents(calendarEntryLink, entryDetail);
        dateEntry.appendChild(calendarEntry);
    }
    dateElement.appendChild(dateEntry);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addTourDetails = function(entryDetails, tour, calendarEntryLink) {
  var guideElements = "";
  for (var i = 0; i < tour.getGuides().length; i++) {
      guideElements = guideElements + "<li>" + tour.getGuides()[i].getName() + "</li>";
  }

  var detailPopupHtml = '<h3 class="tourDetailsHeader">Tour</h3>' +
                        '<dl class="detailedDefinitions">' +
                        '    <dt>Location:</dt>' +
                        '    <dd class="calDetailPlace">' + tour.getPlace() + '</dd>' +
                        '    <dt>Start:</dt>' +
                        '    <dd class="entryDetailStartDateAndTime">' + tour.getFormattedStartDateAndTime() + '</dd>' +
                        '    <dt>End:</dt>' +
                        '    <dd class="entryDetailEndDateAndTime">' + tour.getFormattedEndDateAndTime() + '</dd>' +
                        '    <dt>Organization:</dt>' +
                        '    <dd class="calDetailOrganization">' + tour.getOrganization() + '</dd>' +
                        '    <dt>Guests:</dt>' +
                        '    <dd class="calDetailNumGuests">' + tour.getNumGuests() + '</dd>' +
                        '    <dt>Room Number:</dt>' +
                        '    <dd class="calDetailLocation">' + tour.getLocation() + '</dd>' +
                        '</dl>' +
                        '<br class="mozclear"/>' +
                        '<span class="calDetailGuidesLabel">Guides:</span>' +
                        '<ul class="calDetailGuideList">' +
                        guideElements +
                        '</ul>';

  entryDetails.innerHTML = detailPopupHtml;

  calendarEntryLink.href = 'tourDetails.htm?method=tourDetail&tourId=' + tour.getId();

//    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
//    entryDetailStartDateAndTime.innerHTML = tour.getFormattedStartDateAndTime();
//    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
//    entryDetailEndDateAndTime.innerHTML = tour.getFormattedEndDateAndTime();
//    var calDetailOrganization = cssQuery('.calDetailOrganization', entryDetails)[0];
//    calDetailOrganization.innerHTML = tour.getOrganization();
//    var calDetailNumGuests = cssQuery('.calDetailNumGuests', entryDetails)[0];
//    calDetailNumGuests.innerHTML = tour.getNumGuests();
//    var calDetailPlace = cssQuery('.calDetailPlace', entryDetails)[0];
//    calDetailPlace.innerHTML = tour.getPlace();
//    var calDetailLocation = cssQuery('.calDetailLocation', entryDetails)[0];
//    calDetailLocation.innerHTML = tour.getLocation();
    //var tourDetailsLink = cssQuery('.tourDetailsLink', entryDetails)[0];
//    var calDetailGuideList = cssQuery('.calDetailGuideList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailGuideList);
//    for (var i = 0; i < tour.getGuides().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = tour.getGuides()[i].getName();
//        calDetailGuideList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

WST.TourCalendar.View.CalendarEntryView.prototype._addOutOfOfficeDetails = function(entryDetails, outOfOffice, calendarEntryLink) {
    var entryDetailStartDateAndTime = cssQuery('.entryDetailStartDateAndTime', entryDetails)[0];
    entryDetailStartDateAndTime.innerHTML = outOfOffice.getStartTime();
    var entryDetailEndDateAndTime = cssQuery('.entryDetailEndDateAndTime', entryDetails)[0];
    entryDetailEndDateAndTime.innerHTML = outOfOffice.getEndTime();
    calendarEntryLink.href = 'outofoffice.htm?guide=' + outOfOffice.getGuideId();
//    var calDetailDayList = cssQuery('.calDetailDayList', entryDetails)[0];
//    Lib.Utils.XML.XMLUtils.removeAllChildren(calDetailDayList);
//    for (var i = 0; i < outOfOffice.getDays().length; i++) {
//        var listElement = document.createElement('li');
//        listElement.innerHTML = outOfOffice.getDays()[i];
//        calDetailDayList.appendChild(listElement);
//    }
    //this._attachWindowCloseEvent(entryDetails);
}

//WST.TourCalendar.View.CalendarEntryView.prototype._attachWindowCloseEvent = function(entryDetails) {
//    var closeLink = cssQuery('.xClose', entryDetails)[0];
//    var event = new WST.Event.WindowCloseEvent(entryDetails);
//    event.attachEvent(closeLink, 'click');
//}

WST.TourCalendar.View.CalendarEntryView.prototype._formatDate = function(date) {
    return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
}

//end  WST.TourCalendar.View.CalendarEntryView

//start WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.TourCalendar.Event");

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This object is used to define events that will cause the calendar to display and hide.
*
* @param calendarElement - HTML element representing the calendar.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent = function(calendarElement) {
    this._calendarElement = calendarElement;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method attaches this event to the specified element as the specified type.
*
* @param element - HTML element to attach event to.
* @param type - Type of event to attach, ie. 'click'
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.attachEvent = function(element) {
    Lib.Utils.EventUtils.addEvent(element, 'mouseover', this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: public
* description:
*   This method executes the toggle calendar event, causing the calendar to either be displayed or hidden.
*
* @param evt - Event object provided by the browser.
*/
WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
    Lib.Utils.DocumentUtils.removeClass(this._calendarElement, 'hide');
}
//end  WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent.js



//start WST.Event.CancelEvent
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.EventUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event");

WST.Event.CancelEvent = function() {
}

WST.Event.CancelEvent.prototype.attachEvent = function(element, type) {
    Lib.Utils.EventUtils.addEvent(element, type, this.executeEvent, this);
}

WST.Event.CancelEvent.prototype.executeEvent = function(evt) {
    Lib.Utils.EventUtils.cancelDefaultAction(evt);
}
//end WST.Event.CancelEvent

//start WST.Controller.RequestTour.CalendarController.js
// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.TourCalendar.Model.TourList');
JSAN.use('WST.TourCalendar.Model.OutOfOfficeList');
JSAN.use('WST.TourCalendar.View.CalendarEntryView');
JSAN.use('WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent');
JSAN.use('WST.Event.WindowCloseEvent');
JSAN.use('WST.Event.CancelEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Controller.RequestTour");


WST.Controller.RequestTour.CalendarController = function(template) {
    this._template = template;
}

WST.Controller.RequestTour.CalendarController.prototype._getTourList = function(calendar) {
//    return new WST.TourCalendar.Model.TourList('SCHEDULED');
  return new WST.TourCalendar.Model.TourList('SCHEDULED', false, null, calendar, null, this, this.updateCalendar);

}

WST.Controller.RequestTour.CalendarController.prototype._getCalendarEntryView = function(tourList) {
    var viewDataType = 'RequestTour';
    var view = new WST.TourCalendar.View.CalendarEntryView(this._template, tourList, null, viewDataType);
    view.registerCalendarEntryEvent(WST.Event.CancelEvent);
  view.registerCalendarEntryEvent(WST.TourCalendar.Event.DisplayCalendarEntryDetailsEvent);
  view.registerCalendarEntryEvent(WST.Event.WindowCloseEvent);
    return view;
}

WST.Controller.RequestTour.CalendarController.prototype.updateCalendar = function(tourList, calendar, currentDate, thisClass) {
//    var tourList = this._getTourList();
    thisClass._registerCalendarEntryViewWithCalendar(tourList, calendar, thisClass);
    thisClass._registerTourListWithCalendar(tourList, calendar);
}

WST.Controller.RequestTour.CalendarController.prototype._registerCalendarEntryViewWithCalendar = function(tourList, calendar, thisClass) {
    var calendarEntryView = thisClass._getCalendarEntryView(tourList);
    var reference = Lib.Utils.ObjectUtils.weakBind(calendarEntryView.updateDateElement, calendarEntryView);
    calendar.registerDateInitListener(reference);
}

WST.Controller.RequestTour.CalendarController.prototype._registerTourListWithCalendar = function(tourList, calendar) {
    reference = Lib.Utils.ObjectUtils.weakBind(tourList.updateList, tourList);
    calendar.registerMonthChangeListener(reference);
}

//end  WST.Controller.RequestTour.CalendarController.js


// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.DHTML.TabNavigator');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');
JSAN.use('Lib.Utils.ValidatorUtils');

//JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.RequestTour.FormNavView');
JSAN.use('WST.View.RequestTour.ConfirmView');
JSAN.use('WST.View.RequestTour.TabsView');
JSAN.use('WST.View.RequestTour.AdditionalServicesView');
JSAN.use('WST.View.RequestTour.GeneralView');
//JSAN.use('WST.View.RequestTour.GuestsView');
JSAN.use('WST.View.RequestTour.GuidesView');
JSAN.use('WST.View.ErrorView');
JSAN.use('WST.Controller.RequestTour.ConfirmController');
JSAN.use('WST.Controller.Admin.BlackoutController');
JSAN.use('WST.Controller.RequestTour.CalendarController');

// Load RequestTourMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new RequestTourMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
* author: Nate Minshew
* date created: 07/12/2006
* @constructor
* description:
*   This is the main object for the request a tour page.  It is used to create any needed objects for the page, as well
*   as set up all the views, controllers and events.
*/
RequestTourMain = function() {
//    var logger = new TTSLog4javascriptLogger();
    if (document.getElementById('showDetails') == 'true') {
        var confirmController = this._createConfirmController();
        var confirmView = this._createConfirmView(confirmController);
    } else {
        var tabNavigator = this._createTabNavigator();
        var formTopNavView = this._createTopFormNavView(tabNavigator);
        var formBottomNavView = this._createBottomFormNavView(tabNavigator);
        var confirmController = this._createConfirmController();
        var confirmView = this._createConfirmView(confirmController);
        var tabsView = this._createTabsView(tabNavigator);
        var additionalServicesView = this._createAdditionalServicesView();
        var calendar = this._createCalendar();
        var guideCalendar = this._createGuideCalendar();
        var generalView = this._createGeneralView(calendar, confirmController);
        var errorView = this._createErrorView();
        //var guestsView = this._createGuestsView(errorView, confirmController);
        var guidesView = this._createGuidesView(confirmController, errorView, guideCalendar);
    }
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the tab navigator widget.
*/
RequestTourMain.prototype._createTabNavigator = function() {
    return new Lib.DHTML.TabNavigator('.tab', 'activeTab', 'hide', Lib.Utils.DocumentUtils, Lib.Utils.EventUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the FormNavView.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createTopFormNavView = function(tabNavigator) {
    var formNavElement = document.getElementsByName('formNav')[0];
    var formElement = document.getElementById('tourForm');
    return new WST.View.RequestTour.FormNavView(
            tabNavigator,
            'invisible',
            Lib.Utils.DocumentUtils,
            formNavElement,
            Lib.Utils.ObjectUtils,
            formElement,
            Lib.Utils.EventUtils);
}
/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the FormNavView.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createBottomFormNavView = function(tabNavigator) {
    var formNavElement = document.getElementsByName('formNav')[1];
    var formElement = document.getElementById('tourForm');
    return new WST.View.RequestTour.FormNavView(
            tabNavigator,
            'invisible',
            Lib.Utils.DocumentUtils,
            formNavElement,
            Lib.Utils.ObjectUtils,
            formElement,
            Lib.Utils.EventUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the ConfirmView object.
*
* @param confirmController - Controller for the confirm section.
*/
RequestTourMain.prototype._createConfirmView = function(confirmController) {
    var confirmPage = document.getElementById('confirmPage');
    return new WST.View.RequestTour.ConfirmView(Lib.Utils.ObjectUtils, Lib.Utils.EventUtils, Lib.Utils.XML.XMLUtils,
            Lib.Utils.FormUtils, confirmController, confirmPage);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the TabsView object.
*
* @param tabNavigator - Tab navigator widget.
*/
RequestTourMain.prototype._createTabsView = function(tabNavigator) {
    var tourTabs = document.getElementById('tourTabs');
    return new WST.View.RequestTour.TabsView(tourTabs, tabNavigator, Lib.Utils.ObjectUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the additional services view object.
*/
RequestTourMain.prototype._createAdditionalServicesView = function() {
    var additionalServicesPage = document.getElementById('additionalServicesPage');
    return new WST.View.RequestTour.AdditionalServicesView(
            additionalServicesPage,
            Lib.Utils.EventUtils,
            Lib.Utils.DocumentUtils,
            'hide');
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar template.
*/
RequestTourMain.prototype._createTemplates = function() {
    return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar widget.
*/
RequestTourMain.prototype._createCalendar = function() {
    var scheduledToursController = this._createCalendarController();
    var selectedDate = document.getElementById('tourDate').value;
    var blackoutController = this._createBlackoutController(selectedDate);
    var calendar = new Lib.DHTML.Calendar(
        this._createTemplates().getRootElement('calendar'),
        Lib.Utils.DateUtils,
        Lib.Utils.DocumentUtils,
        Lib.Utils.EventUtils,
        Lib.Utils.XML.XMLUtils,
        Lib.Utils.ObjectUtils,
        new Date());
    if (selectedDate != '') {
        calendar.setDate(new Date(selectedDate));
    }
    blackoutController.updateCalendar(calendar);
    scheduledToursController._getTourList(calendar);
    return calendar;
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the calendar widget.
*/
RequestTourMain.prototype._createGuideCalendar = function() {
    var calendarController = this._createCalendarController();
    var selectedDate = document.getElementById('tourDate').value;
    var blackoutController = this._createBlackoutController(selectedDate);
    var calendar = new Lib.DHTML.Calendar(
        this._createTemplates().getRootElement('calendar'),
        Lib.Utils.DateUtils,
        Lib.Utils.DocumentUtils,
        Lib.Utils.EventUtils,
        Lib.Utils.XML.XMLUtils,
        Lib.Utils.ObjectUtils,
        new Date());
    if (selectedDate != '') {
        calendar.setDate(new Date(selectedDate));
    }
    blackoutController.updateCalendar(calendar);
    calendarController._getTourList(calendar);
    return calendar;
}

/**
* author: Sonal Patidar
* date created: 08/28/2006
* access level: private
* description:
*   This method creates a scheduled Tours controller object.
*/
RequestTourMain.prototype._createCalendarController = function() {
    return new WST.Controller.RequestTour.CalendarController(this._createTemplates());
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method creates the general section view object.
*
* @param calendar - Calendar widget.
* @param confirmController - Controller for the confirm section.
*/
RequestTourMain.prototype._createGeneralView = function(calendar, confirmController) {
    var generalPage = document.getElementById('generalPage');
    return new WST.View.RequestTour.GeneralView(
            calendar,
            generalPage,
            Lib.Utils.XML.XMLUtils,
            Lib.Utils.DocumentUtils,
            Lib.Utils.EventUtils,
            Lib.Utils.ObjectUtils,
            confirmController);
}

/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the guests view object.
*
* @param errorView - Object representing the view to error messages.
* @param confirmController - Object representing the controller for the confirm section.
*/
RequestTourMain.prototype._createGuestsView = function(errorView, confirmController) {
    var guestsPage = document.getElementById('guestsPage');
    var numGuests = document.getElementById('numGuests');
    return new WST.View.RequestTour.GuestsView(guestsPage, Lib.Utils.FormUtils, Lib.Utils.ObjectUtils,
            Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, numGuests, Lib.Utils.ValidatorUtils, errorView,
            confirmController);
}
/**
* author: Nate Minshew
* date created: 07/13/2006
* access level: private
* description:
*   This method creates the guides view object.
*
* @param confirmController - Object representing the controller for the confirm section.
*/
RequestTourMain.prototype._createGuidesView = function(confirmController, errorView, calendar) {
    var guidesPage = document.getElementById('guidesPage');
    var numGuides = document.getElementById('numGuides');
    return new WST.View.RequestTour.GuidesView(guidesPage, Lib.Utils.FormUtils, Lib.Utils.ObjectUtils,
            Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, numGuides,
            confirmController, errorView, calendar, Lib.Utils.XML.XMLUtils);
}

/**
* author: Nate Minshew
* date created: 07/14/2006
* access level: private
* description:
*   This method creates the error view object.
*/
RequestTourMain.prototype._createErrorView = function() {
    var errorElement = document.getElementById('errorMessages');
    return new WST.View.ErrorView(errorElement, Lib.Utils.DocumentUtils, Lib.Utils.ObjectUtils, Lib.Utils.XML.XMLUtils);
}

/**
* author: Nate Minshew
* date created: 07/12/2006
* access level: private
* description:
*   This method returns the url of the templates file.
*/
RequestTourMain.prototype._getTemplatesURL = function() {
    return '../JavaScript/templates/templates.html';
}

/**
* author: Nate Minshew
* date created: 07/25/2006
* access level: private
* description:
*   This method creates the confirm controller object.
*/
RequestTourMain.prototype._createConfirmController = function() {
    return new WST.Controller.RequestTour.ConfirmController();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates a blackout controller object.
*/
RequestTourMain.prototype._createBlackoutController = function(selectedDate) {
    return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL(), selectedDate);
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method returns the URL for the blackout list service.
*/
RequestTourMain.prototype._getBlackoutListURL = function() {
    return 'blackout.htm?method=listBlackoutDates';
}

//attachments.js
var attachmentWindow
var bAttachmentWindowOpen = false;


function openAttachmentWindow(sURL, sName)
{

  attachmentWindow = window.open(sURL, sName, 'status=0,toolbar=yes,location=0,directories=0,menubar=0,resizable=yes,scrollbars=yes,width=900,height=700,top=50,left=50,true');
	bAttachmentWindowOpen = true;
}


function ClosePopUp()
{
	if (bAttachmentWindowOpen)
	{
		attachmentWindow.close();
		bAttachmentWindowOpen = false;
	}
}

//
var reportWindow
var bReportWindowOpen = false;


function openReportWindow(sURL, sName)
{
	reportWindow = window.open(sURL, sName, 'status=0,toolbar=0,location=0,directories=0,menubar=0,resizable=yes,scrollbars=yes,width=800,height=600,top=50,left=50,true');
	bReportWindowOpen = true;
}


function ClosePopUp()
{
	if (bReportWindowOpen)
	{
		reportWindow.close();
		bReportWindowOpen = false;
	}
}


//
function discardIncompleteChanges() {
  document.getElementById('method').value = 'discard';
  document.forms[0].action = document.getElementById('contextPath').value + "/servlet/incompleteTour.htm";
  document.forms[0].submit();
}

function hideAdditionalServicesTab(dropDown) {
  if (dropDown == null)
  {
    dropDown = document.getElementById("tourPlace");
  }
  var selection = dropDown.options[dropDown.selectedIndex].value;
  var addServicesTab = document.getElementById("addServicesTab");
  var meetingBeforeFalse = document.getElementById("meetingBeforeFalse");
  var meetingBeforeTrue = document.getElementById("meetingBeforeTrue");
  var arrivalTime = document.getElementById("arrivalTime");
  var refreshmentsBefore = document.getElementById("refreshmentsBefore");
  var refreshmentDuring = document.getElementById("refreshmentsDuring");
  var meetingAfterTrue = document.getElementById("meetingAfterTrue");
  var meetingAfterFalse = document.getElementById("meetingAfterFalse");
  var meetingAfterDuration = document.getElementById("meetingAfterDuration");
  var refreshmentsAfter = document.getElementById("refreshmentsAfter");
  var creditCardNumber = document.getElementById("creditCardNumber");
  var creditCardName = document.getElementById("creditCardName");
  var creditCardMonth = document.getElementById("creditCardMonth");
  var creditCardYear = document.getElementById("creditCardYear");
  var photoReleaseTrue = document.getElementById("photoReleaseTrue");
  var photoReleaseFalse = document.getElementById("photoReleaseTrue");
  if (selection == 'CC' && addServicesTab != null) {
    addServicesTab.style.display = "none";
    meetingBeforeFalse.checked = true;
    meetingBeforeTrue.checked = false;
    meetingAfterFalse.checked = true;
    meetingAfterTrue.checked = false;
    arrivalTime.value = ""
    refreshmentsBefore.value = "";
    refreshmentDuring.value = ""
    refreshmentsAfter.value = ""
    meetingAfterFalse.checked = true;
    meetingAfterTrue.checked = false;
    meetingAfterDuration.value = "";
    refreshmentsAfter.value = "";
    creditCardNumber.value = "";
    creditCardName.value = "";
    creditCardMonth.value = "";
    creditCardYear.value = "";
            //        tourLocationAfter.value = ""
    photoReleaseTrue.checked = false;
    photoReleaseFalse.checked = false;
  }
  else {
    if (addServicesTab != null) {
      addServicesTab.style.display = "block";
    }
  }
}

function doScroll(){
  window.scrollTo(0,0);
  document.getElementById("TTS").focus();
  return true;
}













