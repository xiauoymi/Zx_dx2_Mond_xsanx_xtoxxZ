JSAN.addRepository('../JavaScript');

// Import JS objects needed by request a tour page.
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.DateUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.View.Templates');
JSAN.use('Lib.DHTML.Calendar');
JSAN.use('Lib.Utils.FormUtils');

JSAN.use('TTSLog4javascriptLogger');

JSAN.use('WST.View.Guide.ScheduledToursView');
JSAN.use('WST.Controller.Guide.ScheduledToursController');
JSAN.use('WST.Controller.Admin.BlackoutController');
JSAN.use('WST.Event.WindowCloseEvent');

// Load ScheduledToursMain when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', function() { new ScheduledToursMain(); });
// Clear all cached JS objects.
Lib.Utils.EventUtils.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects(); });

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * @constructor
 * description:
 *   This is the main object for the blackout page.  It is used to create any needed objects for the page, as well
 *   as set up all the views, controllers and events.
 */
ScheduledToursMain = function() {

  var logger = new TTSLog4javascriptLogger();

//  logger.debug("ScheduledToursMain Enter create method");

  var scheduledToursView = this._createScheduledToursView(logger);

//  logger.debug("ScheduledToursMain Exit create method");
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method returns the url of the templates file.
 */
ScheduledToursMain.prototype._getTemplatesURL = function() {
  return '../JavaScript/templates/templates.html';
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the calendar template.
 */
ScheduledToursMain.prototype._createTemplates = function() {
  return new Lib.View.Templates(Lib.Utils.XML.AjaxUtils, this._getTemplatesURL(), Lib.Utils.ObjectUtils);
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the calendar widget.
 */
ScheduledToursMain.prototype._createCalendar = function(logger) {
//  logger.debug("ScheduledToursMain - Enter _createCalendar");
  var scheduledToursController = this._createScheduledToursController();
//  logger.debug("ScheduledToursMain - done creating scheduledTourController");
  var blackoutController = this._createBlackoutController();
//  logger.debug("ScheduledToursMain - done creating BlackOutController");
//  var selectedDate = document.getElementById('tourDate').value;
  var currentDate = document.getElementById('currentDate').value;
    if (currentDate == null) {
       currentDate = new Date();
    }else{
      currentDate = new Date(currentDate);
    }
   var calendar = new Lib.DHTML.Calendar(
      this._createTemplates().getRootElement('calendar'),
      Lib.Utils.DateUtils,
      Lib.Utils.DocumentUtils,
      Lib.Utils.EventUtils,
      Lib.Utils.XML.XMLUtils,
      Lib.Utils.ObjectUtils,
      currentDate,
      true);
//  if (currentDate != '') {
//    calendar.setDate(new Date(currentDate));
//  }
//  logger.debug("ScheduledToursMain - Before updating blackout calendar");
  blackoutController.updateCalendar(calendar);
//  logger.debug("ScheduledToursMain - Updated blackout calendar before updating tour calendar");
//  scheduledToursController.updateCalendar(calendar, currentDate);
  scheduledToursController._getTourList(calendar, currentDate);
//  logger.debug("ScheduledToursMain - Exit _createCalendar");
  return calendar;
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates the ScheduledToursView.
 */
ScheduledToursMain.prototype._createScheduledToursView = function(logger) {
//  logger.debug("ScheduledToursMain - Enter _createScheduledToursView ");
  var scheduledToursFields = document.getElementById('scheduledToursFields');
  var calendar = this._createCalendar(logger);
//  logger.debug("ScheduledToursMain - Calendar created");
  return new WST.View.Guide.ScheduledToursView(calendar, scheduledToursFields,Lib.Utils.XML.XMLUtils,
      Lib.Utils.DocumentUtils, Lib.Utils.EventUtils, Lib.Utils.ObjectUtils, Lib.Utils.FormUtils, logger);
}

/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates a scheduled Tours controller object.
 */
ScheduledToursMain.prototype._createScheduledToursController = function() {
  var guideId = document.getElementById('guide')[document.getElementById('guide').selectedIndex].value;
  return new WST.Controller.Guide.ScheduledToursController(this._createTemplates(), guideId);
}
/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method creates a blackout controller object.
 */
ScheduledToursMain.prototype._createBlackoutController = function() {
  return new WST.Controller.Admin.BlackoutController(Lib.Utils.XML.AjaxUtils, this._getBlackoutListURL());
}


/**
 * author: Sonal Patidar
 * date created: 08/28/2006
 * access level: private
 * description:
 *   This method returns the URL for the blackout list service.
 */
ScheduledToursMain.prototype._getBlackoutListURL = function() {
  return 'blackout.htm?method=listBlackoutDates';
}
