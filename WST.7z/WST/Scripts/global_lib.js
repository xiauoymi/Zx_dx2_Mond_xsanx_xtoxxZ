// Start Print Function
	function printWindow(){
	   bV = parseInt(navigator.appVersion)
	   if (bV >= 4) window.print()
	}
// End Print Function

// Start Popup Funtion 
var spawnWin = null
var winCount = 0
var winName = "spawnWin"

function openSpawn(winURL, winWidth, winHeight, winFeatures, winLeft, winTop){
	var d_winLeft = 20
	var d_winTop = 20 
	winName = "spawnWin" + winCount++ 
	closePopWin()
	if (openSpawn.arguments.length >= 4)
		winFeatures = "," + winFeatures
	else
		winFeatures = ""
	if (openSpawn.arguments.length == 6)
		winFeatures += getLocation(winWidth, winHeight, winLeft, winTop)
	else
		winFeatures += getLocation(winWidth, winHeight, d_winLeft, d_winTop)
		spawnWin = window.open(winURL, winName, "width=" + winWidth + ",height=" + winHeight + winFeatures)
	self.name = "detail"
}

/* Win Features
toolbar,scrollbars,location,statusbar,menubar,resizable
*/

function closePopWin(){
	if (navigator.appName != "Microsoft Internet Explorer" || parseInt(navigator.appVersion) >=4) 
	if (spawnWin != null) if(!spawnWin.closed) spawnWin.close()
}

function getLocation(winWidth, winHeight, winLeft, winTop){
	return ""
}

function getLocation(winWidth, winHeight, winLeft, winTop){
	var winLocation = ""
	if (winLeft < 0) winLeft = screen.width - winWidth + winLeft
	if (winTop < 0) winTop = screen.height - winHeight + winTop
	if (winTop == "cen") winTop = (screen.height - winHeight)/2
	if (winLeft == "cen") winLeft = (screen.width - winWidth)/2
	if (winLeft>0 & winTop>0) winLocation =  ",screenX=" + winLeft + ",left=" + winLeft + ",screenY=" + winTop + ",top=" + winTop
	else winLocation = ""
	return winLocation
}
/* End Popup Funtion */

/* Clear Field */

function clearText(thefield){
if (thefield.defaultValue==thefield.value)
thefield.value = ""
} 

/* End Clear Field */
