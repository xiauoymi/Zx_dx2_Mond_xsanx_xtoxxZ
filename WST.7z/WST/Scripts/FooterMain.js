JSAN.addRepository('../scripts');
JSAN.use('WST.Cookie.FooterCookie');
JSAN.use('Lib.Utils.CookieUtils');
JSAN.use('Lib.Adapters.EventHandler');
JSAN.use('WST.Event.MyProfileEvent');
JSAN.use('WST.Event.NavigatorSettingsEvent');
JSAN.use('WST.Event.ChangePortalEvent');

Lib.Adapters.EventHandler.addEvent(window, 'load', function() { new FooterMain() });

FooterMain = function() {
	var cookie = new WST.Cookie.FooterCookie(Lib.Utils.CookieUtils);
	var defaultPortal = cookie.getDefaultPortal();
	var fullName = cookie.getFullName();
	this._selectDefaultPortal(defaultPortal);
	this._setFullName(fullName);
	this._initMyProfileEvent();
	this._initNavSettingsEvent();
	this._initChangePortalEvent();
	this._setLastModified();
}

FooterMain.prototype._selectDefaultPortal = function(defaultPortal) {
	var defaultPortalElement = document.getElementById('DashboardPicked');
	var options = defaultPortalElement.getElementsByTagName('option');
	for (var i = 0; i < options.length; i++) {
		if (options[i].text == defaultPortal) {
			options[i].selected = 'selected';
		}
	}
}

FooterMain.prototype._setFullName = function(fullName) {
	var myProfileLink = document.getElementById('myProfileLink');
	myProfileLink.innerHTML = fullName.toLowerCase();
}

FooterMain.prototype._initMyProfileEvent = function() {
	var myProfileLink = document.getElementById('myProfileLink');
	var event = new WST.Event.MyProfileEvent(myProfileLink, Lib.Adapters.EventHandler);
	event.attachEvent(myProfileLink, 'click');
}

FooterMain.prototype._initNavSettingsEvent = function() {
	var navSettingsLink = document.getElementById('navSettingsLink');
	var event = new WST.Event.NavigatorSettingsEvent(navSettingsLink, Lib.Adapters.EventHandler);
	event.attachEvent(navSettingsLink, 'click');
}

FooterMain.prototype._setLastModified = function() {
	var lastUpdateElement = document.getElementById('lastUpdate');
	lastUpdateElement.appendChild(document.createTextNode('Last Updated: ' + document.lastModified));
}

FooterMain.prototype._initChangePortalEvent = function() {
	var portalElement = document.getElementById('DashboardPicked');
	var event = new WST.Event.ChangePortalEvent(portalElement, Lib.Adapters.EventHandler);
	event.attachEvent(portalElement, 'change');
}
