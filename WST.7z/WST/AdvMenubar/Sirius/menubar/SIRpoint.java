package Sirius.menubar;

import java.io.*;

public class SIRpoint implements Serializable {

  private int     x;
  private int     y;

  public SIRpoint  (int     x,
                    int     y) {
         this.x            = x;
         this.y            = y;
  }

  public  int     getX() {return  x;}
  public  int     getY() {return  y;}

  public void setX(int x)  {this.x = x;}
  public void setY(int x)  {this.y = y;}

}