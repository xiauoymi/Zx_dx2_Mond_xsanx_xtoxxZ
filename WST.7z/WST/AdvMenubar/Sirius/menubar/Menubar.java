package Sirius.menubar;

import java.awt.*;
import java.io.*;

public class Menubar implements Serializable {

   private String   mid;              // menu id  (root is top level)
   private int      bw;               // button width
   private int      bh;               // button height
   private int      gap;              // gap between buttons
   private int      mw;               // Menu Width
   private Color    bg;               // bg color
   private Image    bgimg;            // bg image

   public Menubar (String   mid,        // menu id  (root is top level)
                   int      bw,         // button width
                   int      bh,         // button height
                   int      gap,        // gap between buttons
                   int      mw,         // Menu Width
                   Color    bg,         // bg color
                   Image    bgimg       // bg image
                   ) {
                   this.mid    = mid;              // menu id  (root is top level)
                   this.bw     = bw;               // button width
                   this.bh     = bh;               // button height
                   this.gap    = gap;              // gap between buttons
                   this.mw     = mw;               // menu width
                   this.bg     = bg;               // bg color
                   this.bgimg  = bgimg;            // bg image
   }

   public String   getMid()      {return mid;}              // menu id  (root is top level)
   public int      getBw()       {return bw;}               // button width
   public int      getBh()       {return bh;}               // button height
   public int      getGap()      {return gap;}              // gap between buttons
   public int      getMw()       {return mw;}               // Menu width
   public Color    getBg()       {return bg;}               // bg color
   public Image    getBgimg()    {return bgimg;}            // bg image

   public void setMid(String mid)         {this.mid    = mid;}              // menu id  (root is top level)
   public void setBw(int bw)              {this.bw     = bw;}               // button width
   public void setBh(int bh)              {this.bh     = bh;}               // button height
   public void setGap(int gap)            {this.gap    = gap;}              // gap between buttons
   public void setMw(int mw)              {this.mw     = mw;}               // menu width
   public void setBg(Color bg)            {this.bg     = bg;}               // bg color
   public void setBgimg(Image bgimg)      {this.bgimg  = bgimg;}            // bg image


}