package Sirius.menubar;

import java.awt.*;
import java.io.*;
import java.applet.AudioClip;
import Sirius.menubar.SIRpoint;

public class Item implements Serializable {


   private String   mid;              // menu id
   private String   id;               // item id
   private int      index;            // item index
   private String   sid;              // submenu
   private int      sinx;             // sub window index
   private Color    bgc;              // background color
   private Color    arc;              // arrow color
   private boolean  div;              // divide line
   private Color    mobgc;            // mouseover bg color
   private Color    motxtc;           // mouseover txt color
   private int      moeff;            // mouseover effect (none, raised, sunken)
   private Color    mcbgc;            // mouseclick color
   private Color    mctxtc;           // mouseclick txt color
   private int      mceff;            // mouseclick effect (none, raised, sunken)
   private int      beff;             // border effect
   private Image    img;              // button image
   private Image    moimg;            // mouse over image
   private Image    mcimg;            // mouse click image
   private SIRpoint ipos;             // image relative position
   private String   txt;              // text
   private SIRpoint txtp;             // text x inset
   private Color    txtc;             // text color
   private Font     txtf;             // text font
   private String   url;              // url
   private String   target;           // target
   private int      state;            // state 0 - normal, 1 - highlight, 2 - clicked
   private AudioClip aopen;            // Sub Menu open
   private AudioClip aclose;           // Sub Menu close
   private AudioClip aclick;           // button click
   private String    statusmsg;        // Status Bar Message


   public Item  (String   mid,              // menu id
                 String   id,               // item id
                 int      index,            // item index
                 String   sid,              // submenu
                 int      sinx,             // sub window index
                 Color    bgc,              // background color
                 Color    arc,              // arrow color
                 boolean  div,              // divide line
                 Color    mobgc,            // mouseover bg color
                 Color    motxtc,           // mouseover txt color
                 int      moeff,            // mouseover effect (none, raised, sunken)
                 Color    mcbgc,            // mouseclick color
                 Color    mctxtc,           // mouseover txt color
                 int      mceff,            // mouseclick effect (none, raised, sunken)
                 int      beff,             // border effect
                 Image    img,              // image
                 Image    moimg,            // Mouseover image
                 Image    mcimg,            // Mouseclick image
                 SIRpoint ipos,             // image relative position
                 String   txt,              // text
                 SIRpoint txtp,             // text inset
                 Color    txtc,             // text color
                 Font     txtf,             // text font
                 String   url,              // url
                 String   target,           // target
                 int       state,            // state 0 - normal, 1 - highlight, 2 - clicked
                 AudioClip aopen,            // sub menu open
                 AudioClip aclose,           // sub menu close
                 AudioClip aclick,           // button click
                 String    statusmsg         // Status Bar Message
                ) {
                   this.mid    = mid;              // menu id
                   this.id     = id;               // item id
                   this.index  = index;            // item index
                   this.sinx   = sinx;             // sub window index
                   this.sid    = sid;              // submenu
                   this.bgc    = bgc;              // background color
                   this.arc    = arc;              // arrow color
                   this.div    = div;              // divide line
                   this.mobgc  = mobgc;            // mouseover bg color
                   this.motxtc = motxtc;           // mouseover txt color
                   this.moeff  = moeff;            // mouseover effect (none, raised, sunken)
                   this.mcbgc  = mcbgc;            // mouseclick color
                   this.mctxtc = mctxtc;           // mouseover txt color
                   this.mceff  = mceff;            // mouseclick effect (none, raised, sunken)
                   this.beff   = beff;             // border effect
                   this.img    = img;              // image
                   this.moimg  = moimg;            // mouseover image
                   this.mcimg  = mcimg;            // mouseclick image
                   this.ipos   = ipos;             // image relative position
                   this.txt    = txt;              // text
                   this.txtp   = txtp;             // text inset
                   this.txtc   = txtc;             // text color
                   this.txtf   = txtf;             // text font
                   this.url    = url;              // url
                   this.target = target;           // target
                   this.state  = state;            // state 0 - normal, 1 - highlight, 2 - clicked
                   this.aopen  = aopen;            // submenu open
                   this.aclose = aclose;           // submenu close
                   this.aclick = aclick;           // button click
                   this.statusmsg = statusmsg;     // Status Bar Message
   }

   public String   getMid()      {return mid;}              // menu id
   public String   getId()       {return id;}               // item id
   public int      getIndex()    {return index;}            // item index
   public int      getSinx()     {return sinx;}             // sub window index
   public String   getSid()      {return sid;}              // submenu
   public Color    getBgc()      {return bgc;}              // background color
   public Color    getArc()      {return arc;}              // arrow color
   public boolean  getDiv()      {return div;}              // divide line
   public Color    getMobgc()    {return mobgc;}            // mouseover bg color
   public Color    getMotxtc()   {return motxtc;}           // mouseover txt color
   public int      getMoeff()    {return moeff;}            // mouseover effect (none, raised, sunken)
   public Color    getMcbgc()    {return mcbgc;}            // mouseclick color
   public Color    getMctxtc()   {return mctxtc;}           // mouseover txt color
   public int      getMceff()    {return mceff;}            // mouseclick effect (none, raised, sunken)
   public int      getBeff()     {return beff;}             // border effect (none(0), raised(1), sunken(2))
   public Image    getImg()      {return img;}              // image
   public Image    getMoimg()    {return moimg;}            // mouseover image
   public Image    getMcimg()    {return mcimg;}            // mouseclick image
   public SIRpoint getIpos()     {return ipos;}             // image relative position
   public String   getTxt()      {return txt;}              // text
   public SIRpoint getTxtp()     {return txtp;}             // text inset
   public Color    getTxtc()     {return txtc;}             // text color
   public Font     getTxtf()     {return txtf;}             // text font
   public String   getUrl()      {return url;}              // url
   public String   getTarget()   {return target;}           // target
   public int      getState()    {return state;}            // state 0 - normal, 1 - highlight, 2 - clicked
   public AudioClip getAopen()     {return aopen;}            // submenu open
   public AudioClip getAclose()    {return aclose;}           // submenu close
   public AudioClip getAclick()    {return aclick;}           // submenu click
   public String    getStatusmsg() {return statusmsg;}        // Status Bar Message

   public void setMid(String mid)         {this.mid      = mid;}              // menu id
   public void setId(String id)           {this.id       = id;}               // item id
   public void setIndex(int index)        {this.index    = index;}            // item index
   public void setSinx(int sinx)          {this.sinx   = sinx;}               // sub window index
   public void setSid(String sid)         {this.sid      = sid;}              // submenu
   public void setBgc(Color bgc)          {this.bgc      = bgc;}              // background color
   public void setArc(Color arc)          {this.arc      = arc;}              // arrow color
   public void setDiv(boolean div)        {this.div      = div;}              // divide line
   public void setMobgc(Color mobgc)      {this.mobgc    = mobgc;}            // mouseover bg color
   public void setMotxtc(Color motxtc)    {this.motxtc   = motxtc;}           // mouseover txt color
   public void setMoeff(int moeff)        {this.moeff    = moeff;}            // mouseover effect (none, raised, sunken)
   public void setMcbgc(Color mcbgc)      {this.mcbgc    = mcbgc;}            // mouseclick color
   public void setMctxtc(Color mctxtc)    {this.mctxtc   = mctxtc;}           // mouseover txt color
   public void setMceff(int mceff)        {this.mceff    = mceff;}            // mouseclick effect (none, raised, sunken)
   public void setBeff(int beff)          {this.beff     = beff;}             // border effect
   public void setImg(Image img)          {this.img      = img;}              // image
   public void setMoimg(Image moimg)      {this.moimg    = moimg;}            // mouseover image
   public void setMcimg(Image mcimg)      {this.mcimg    = mcimg;}            // mouseclick image
   public void setIpos(SIRpoint ipos)     {this.ipos     = ipos;}             // image relative position
   public void setTxt(String txt)         {this.txt      = txt;}              // text
   public void setTxtp(SIRpoint txtp)     {this.txtp     = txtp;}             // text inset
   public void setTxtc(Color txtc)        {this.txtc     = txtc;}             // text color
   public void setTxtf(Font txtf)         {this.txtf     = txtf;}             // text font
   public void setUrl(String url)         {this.url      = url;}              // url
   public void setTarget(String target)   {this.target   = target;}           // target
   public void setState(int state)        {this.state    = state;}            // state 0 - normal, 1 - highlight, 2 - clicked
   public void setAopen(AudioClip aopen)   {this.aopen    = aopen;}            // submenu open
   public void setAclose(AudioClip aclose) {this.aclose   = aclose;}           // submenu close
   public void setAclick(AudioClip aclick) {this.aclick   = aclick;}           // button click
   public void setStatusmsg(String statusmsg) {this.statusmsg = statusmsg;}    // Status Bar Message

}