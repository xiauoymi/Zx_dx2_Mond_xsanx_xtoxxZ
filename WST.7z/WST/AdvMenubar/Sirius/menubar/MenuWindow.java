package Sirius.menubar;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.applet.AppletContext;
import java.util.*;
import java.net.*;
import java.lang.*;
import Sirius.menubar.*;
import netscape.javascript.*;

//---------------------------------------------------------------------
// Common Window.
public class MenuWindow extends Window implements MouseMotionListener, MouseListener {

	private Image  buffer;
	private static Graphics pad;
	private int y;
    private Item item;
    private Frame frame;
    private Point pt;
    private boolean created = false;
    private MenuWindow mw = null;


    // Data Objects
    private Vector areadata;      // Clickable area data
    private Vector mwins;         // Menu Windows

    // Item data varaibles
    private int      i_index;            // item index
    private String   i_url;              // url
    private String   i_target;           // target

    // Area Object variables
    private String  a_iid;               // Item id
    private int     a_ty;                // top y
    private int     a_lx;                // left x
    private int     a_by;                // bottom y
    private int     a_rx;                // right x
    private int     a_act;               // action

    // This Menu data variables
    private String   id;               // Id
    private Vector   mitems;           // Items
    private int      bw;               // button width
    private int      bh;               // button height
    private int      gap;              // gap between buttons
    private Color    bg;               // Background Color
    private Image    bgimg;            // background image
    private int      winh;             // Window Height
    private Thread killMenus;
    private Menubarbean menubarbean;

    // General Options
    private boolean closeonclick;       // Close Submenu's upon mouse click

    // Parent applet
    private static Applet parentapplet;


//-----------------------------------------------------------------------------------
// Set and get methods
//
   public String   getId()       {return id;}               // Id
   public Vector   getMitems()   {return mitems;}           // Items
   public int      getBw()       {return bw;}               // button width
   public int      getBh()       {return bh;}               // button height
   public int      getGap()      {return gap;}              // gap between buttons
   public Color    getBg()       {return bg;}               // Background Color
   public Image    getBgimg()    {return bgimg;}            // Background image
   public int      getWinh()     {return winh;}             // Window Height

   public void setId(String id)           {this.id     = id;}               // Id
   public void setMitems(Vector mitems)   {this.mitems = mitems;}           // Items
   public void setBw(int bw)              {this.bw     = bw;}               // button width
   public void setBh(int bh)              {this.bh     = bh;}               // button height
   public void setGap(int gap)            {this.gap    = gap;}              // gap between buttons
   public void setBg(Color bg)            {this.bg     = bg;}               // Background Color
   public void setBgimg(Image bgimg)      {this.bgimg  = bgimg;}            // Background Image
   public void setWinh(int winh)          {this.winh   = winh;
                                           initwindow();}                   // Window height
   public void setKillMenus(Thread killMenus)    {this.killMenus   = killMenus;

        // Set killmenus in all sub windows
        int widx = -1;
        MenuWindow mw = null;

        Enumeration ie = mitems.elements();
        while (ie.hasMoreElements()) {
               Item  item = (Item)ie.nextElement();
               widx = item.getSinx();
               if (widx>-1) {mw = (MenuWindow)mwins.elementAt(widx);
                             mw.setKillMenus(killMenus);
			   }
	    }




   }


   public void setMenubarbean(Menubarbean menubarbean) {this.menubarbean = menubarbean;}

   // Windows Get and Set methods
   public Vector getMwins() {return mwins;}
   public void setMwins(Vector mwins) {this.mwins  = mwins;
                                       SIRdata.setwindowindex(mitems, mwins);
								      }

    // Parent Applet
    public Applet getParentapplet() {return parentapplet;}
    public void   setParentapplet(Applet parentapplet) {this.parentapplet = parentapplet;}

    // General options
    public void setCloseonclick(boolean closeonclick) {this.closeonclick = closeonclick;}


//-----------------------------------------------------------------------------------
// Zero Argument Constructor
//-----------------------------------------------------------------------------------
    public MenuWindow(Frame frame) {
		super(frame);

  		// Add mouse listeners
   		addMouseMotionListener(this);
   		addMouseListener(this);
    }

//-----------------------------------------------------------------------------------
// Turn Window and sub windows off
//
    public void setOff(boolean thisoff, AudioClip close) {
		 int widx = -1;

         if (thisoff) {if (close!=null&&this.isShowing()) {close.play();}
                       this.setVisible(false);
         }
         Enumeration ie = mitems.elements();
 	     while (ie.hasMoreElements()) {
	          Item  item = (Item)ie.nextElement();
              item.setState(0); // reset button state to normal
	          widx = item.getSinx();
              if (widx>-1) {mw = (MenuWindow)mwins.elementAt(widx);
                            // System.out.println("SetOff Index:"+widx);
                            mw.setOff(true, item.getAclose());
			  }
	     }
	}

//-----------------------------------------------------------------------------------
// Initialise Window
    private void initwindow() {
		   this.setBounds(100,100,bw,winh);
		   this.setBackground(bg);
	}
//------------------------------------------------------------------------------------
// Update Method
//
    public void update(Graphics g) {
	   paint(g);
    }
//-----------------------------------------------------------------------------------
    public void paint(Graphics g) {

       if (!created) {

          // Create graphics Pad
          buffer = createImage(bw, winh);
          pad = buffer.getGraphics();

          // Draw the Background
          pad.setColor(bg);
	      pad.fillRect(0,0,bw,winh);
	      if (bgimg!=null) {pad.drawImage(bgimg, 0, 0, this);}

	      // Draw the Menu
  	      areadata = new Vector();
          Enumeration ie = mitems.elements();
          y = 0;

          while (ie.hasMoreElements()) {
               Item  item = (Item)ie.nextElement();
               SIRmenugraphics.drawButton(buffer,
                                          item,
                                          bw,
                                          bh,
                                          0,
                                          y
				                         );
	   		   i_index = item.getIndex();
               areadata.addElement(new Areadata(i_index,   // Item index
                                                y,         // top y
                                                0,         // left x
                                                y+bh,      // bottom y
                                                bw,        // right x
                                                1)         // Mouse Over Highlight
                                  );

               areadata.addElement(new Areadata(i_index,   // Item index
                                                y,         // top y
                                                0,         // left x
                                                y+bh,      // bottom y
                                                bw,        // right x
                                                2)         // Mouse Over Show sub menu
                                     );
               i_url = item.getUrl();
               i_target = item.getTarget();
               if (i_url!=null&&!i_url.equals("")&&!i_url.equals(" ")) {
                  if (i_target.equals("javascript")) {
  		             areadata.addElement(new Areadata(i_index,   // Item index
				                                      y,         // top y
				                                      0,         // left x
				                                      y+bh,      // bottom y
				                                      bw,        // right x
				                                      4)         // action, Execute javascript
				                        );
				  }
  		          else {

                     areadata.addElement(new Areadata(i_index,   // Item index
                                                      y,         // top y
                                                      0,         // left x
                                                      y+bh,      // bottom y
                                                      bw,        // right x
                                                      3)         // action, Execute url
                                        );
				  }
               }

               y = y + bh + gap;
		   }
       created = true;
       }  // if !created
       else {
          y = 0;
          Enumeration ie = mitems.elements();
          while (ie.hasMoreElements()) {
               Item  item = (Item)ie.nextElement();
               SIRmenugraphics.drawButton(buffer,
                                          item,
                                          bw,
                                          bh,
                                          0,
                                          y
				                         );
               y = y + bh + gap;
    	   }
       }

       // Draw completed buffer to g
       g.drawImage(buffer, 0, 0, this);

    } // End paint


//------------------------------------------------------------------------------------
    public void mousePressed (MouseEvent evt) {
         int mx = evt.getX();
         int my = evt.getY();
         String itemurl;
         String itemtarget;
         int idx;

         Enumeration ae = areadata.elements();

		 while (ae.hasMoreElements()) {
			Areadata ad = (Areadata)ae.nextElement();

			if (mx>ad.getLx()&&mx<ad.getRx()&&my>ad.getTy()&&my<ad.getBy()) {

				idx = ad.getIndex();
                item = (Item)mitems.elementAt(idx);
                itemurl         = item.getUrl();          // URL
                itemtarget      = item.getTarget();       // Target Frame
                item.setState(2);
                if (!(item.getAopen()==null)) {item.getAclick().play();}


				switch(ad.getActn()) {
				                   case 3: // mouseclicked execute url

                                          try {URL url = new URL (parentapplet.getDocumentBase(),itemurl);
										       parentapplet.getAppletContext().showDocument(url,itemtarget);}
										  catch (MalformedURLException e) {e.printStackTrace();}



				                          break;
				                   case 4: // Execute a javascript function

                                          try {JSObject.getWindow(parentapplet).eval(itemurl);}
                                          catch(Throwable _ex)  {
							                   try {URL url = new URL (parentapplet.getDocumentBase(),"javascript:"+itemurl);
										            parentapplet.getAppletContext().showDocument(url);}
										       catch (MalformedURLException e) {e.printStackTrace();}
										  }


				                          break;
				                   default:
                 }

			}

		 }

         if (closeonclick) {menubarbean.mouseExited(evt);}

         paint(getGraphics());


                                              }
//------------------------------------------------------------------------------------
    public void mouseReleased (MouseEvent evt) {
                                               }
//------------------------------------------------------------------------------------
    public void mouseMoved (MouseEvent evt)   {
         int mx = evt.getX();
         int my = evt.getY();
         int idx  = 0;
         int widx = -1;
         int widx2 = -1;
         int warn;
         mw = null;

         // reset all highlights
         Enumeration ie = mitems.elements();
         int i = 0;
         while (ie.hasMoreElements()) {
			   Item  item = (Item)ie.nextElement();
			   if (item.getState()>0) {
			      item.setState(0);
			   }
			   i++;
		 }

        Enumeration ae = areadata.elements();

		Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle bounds = new Rectangle( d.width, d.height );

		 while (ae.hasMoreElements()) {
			Areadata ad = (Areadata)ae.nextElement();

			if (mx>ad.getLx()&&mx<ad.getRx()&&my>ad.getTy()&&my<ad.getBy()) {

				switch(ad.getActn()) {
				                   case 1: // mouseover highlight
				                          idx = ad.getIndex();
                                          item = (Item)mitems.elementAt(idx);
                                          item.setState(1);
                                          parentapplet.showStatus(item.getStatusmsg());
				                          break;

				                   case 2: // mouseover show sub menu
				                          pt = this.getLocationOnScreen();
				                          idx = ad.getIndex();
                                          item = (Item)mitems.elementAt(idx);
                                          widx = item.getSinx();
                                          if (widx>-1) {mw = (MenuWindow)mwins.elementAt(widx);
                                                        if (!mw.isShowing()&&!(item.getAopen()==null)) {item.getAopen().play();}
                                                        warn = 0;
                                                        warn = mw.getInsets().bottom;
											int right_rightedge = pt.x+ad.getRx()+mw.getBw();
				int left_leftedge = pt.x - mw.getBw();
                                                        
											int right_hidden = right_rightedge - bounds.width;
											int left_hidden = 0 - left_leftedge;
                                                        
											int left;
                                                        
											if (right_hidden < 0 || right_hidden < left_hidden)
											{
												// draw to right of current menu.
												left = pt.x+ad.getRx();
											}
											else
											{
												// draw to left of current menu.
												left = pt.x-mw.getBw();
											}
                                                        
											int top = pt.y+ad.getTy();
											int bottom_edge = pt.y+ad.getTy()+mw.getWinh()+warn;
											int hidden_pixels = bottom_edge - bounds.height;
											if (hidden_pixels > 0)
											{
												// part of the menu would be hidden below the screen.
												// draw it a little higher.
												if (hidden_pixels < top)
													top -= hidden_pixels;
												else
													top = 0; // can't win.  put it at the top, draw as much as possible.
											}
											mw.setBounds(left,top,mw.getBw(),mw.getWinh()+warn);
                                                        mw.setVisible(true);
										  }
				                          break;
				                   default:
                 }

			}

		 }

         // Switch off all sub windows, except the one just turned on
  	     ie = mitems.elements();
 	     while (ie.hasMoreElements()) {
	          Item  item = (Item)ie.nextElement();
	          widx2 = item.getSinx();
	          // System.out.println("widx2:"+widx2);
              if (widx2>-1&&widx2!=widx) {mw = (MenuWindow)mwins.elementAt(widx2);
                                          mw.setOff(true, item.getAclose());
			  }
	     }


         paint(getGraphics());
                                              }
//------------------------------------------------------------------------------------
    public void mouseDragged (MouseEvent evt) {}
//------------------------------------------------------------------------------------
    public void mouseClicked (MouseEvent evt) {}
//------------------------------------------------------------------------------------
    public void mouseEntered (MouseEvent evt) {
            if(killMenus != null && killMenus.isAlive())
                killMenus.stop();
	}
//------------------------------------------------------------------------------------
    public void mouseExited (MouseEvent evt)  {
        menubarbean.mouseExited(evt);
	}
//------------------------------------------------------------------------------------

}

