package Sirius.menubar;

import java.awt.*;
import java.io.*;
import java.util.Vector;

public class Areadata implements Serializable {

  private int  index;
  private int  ty;
  private int  lx;
  private int  by;
  private int  rx;
  private int  act;     // Action values
                        // 0 - No Action
                        // 1 - Mouseover highlight    mouseover
                        // 2 - Mouseover show submenu mouseover
                        // 3 - Execute url            on click
                        // 4 - Execute script         on click

//--------------------------------------------------------------------------------
  public Areadata  (int    index,
                    int    ty,
                    int    lx,
                    int    by,
                    int    rx,
                    int    act)
  {
	this.index = index;
    this.ty    = ty;
    this.lx    = lx;
    this.by    = by;
    this.rx    = rx;
    this.act   = act;
  }
//--------------------------------------------------------------------------------
  public  int    getIndex()  {return index;}
  public  int    getTy()       {return ty;}
  public  int    getLx()      {return lx;}
  public  int    getBy()    {return by;}
  public  int    getRx()     {return rx;}
  public  int    getActn()     {return act;}
//--------------------------------------------------------------------------------
  public void setIndex(int index) {this.index = index;}
  public void setTy(int ty)       {this.ty    = ty;}
  public void setLx(int lx)       {this.lx   = lx;}
  public void setBy(int by)       {this.by = by;}
  public void setRx(int rx)       {this.rx  = rx;}
  public void setAct(int act)     {this.act  = act;}
//--------------------------------------------------------------------------------
}