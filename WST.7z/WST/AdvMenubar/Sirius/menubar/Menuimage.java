package Sirius.menubar;

import java.awt.*;
import java.io.*;
import java.util.Vector;

public class Menuimage implements Serializable {

  private String  imagename;        // image name
  private Image   image;            // image

  public Menuimage (String  imagename,        // Image name
                    Image   image
	               ) {

         this.imagename  = imagename;  //  image id
         this.image      = image;      //  image

  }

  public  String  getImagename() {return  imagename;}        // Image name
  public  Image   getImage()     {return  image;}            // Image

  public void setImagename(String imagename)   {this.imagename  = imagename;}  // image name
  public void setImage(Image image)            {this.image      = image;}      // image

}