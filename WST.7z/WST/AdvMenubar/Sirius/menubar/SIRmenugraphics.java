//----------------------------------------------------------
// SIRmenugraphics.
//
// Functions
//
//    Draw Menu
//    Draw Label
//    Draw Text Box
//    Draw Border
//
//---------------------------------------------------------
package Sirius.menubar;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.net.*;
import java.lang.*;
import Sirius.menubar.*;

public class SIRmenugraphics {

       // General variables
       private static int i;
       private static int j;
       private static ImageObserver Iobs;

//------------------------------------------------------------------------------------
//    Draw a Button
//
       public static void drawButton (Image    SIRbuffer,
                       	              Item     item,
                       	              int      bw,
                       	              int      bh,
                       	              int      x,
                       	              int      y
								     ) {

          Graphics pad = SIRbuffer.getGraphics();

          Color    i_bgc    = item.getBgc();              // background color
          Color    i_arc    = item.getArc();              // arrow color
          boolean  i_div    = item.getDiv();              // divide line
          Color    i_mobgc  = item.getMobgc();            // mouseover bg color
          Color    i_motxtc = item.getMotxtc();           // mouseover txt color
          int      i_moeff  = item.getMoeff();            // mouseover effect (none, raised, sunken)
          Color    i_mcbgc  = item.getMcbgc();            // mouseclick color
          Color    i_mctxtc = item.getMctxtc();           // mouseclick txt color
          int      i_mceff  = item.getMceff();            // mouseclick effect (none, raised, sunken)
          int      i_beff   = item.getBeff();             // border effect (none(0), raised(1), sunken(2))
          Image    i_img    = item.getImg();              // image
          Image    i_moimg  = item.getMoimg();            // mouseover image
          Image    i_mcimg  = item.getMcimg();            // mouseclick image
          SIRpoint i_ipos   = item.getIpos();             // image relative position
          String   i_txt    = item.getTxt();              // text
          SIRpoint i_txtp   = item.getTxtp();             // text inset
          Color    i_txtc   = item.getTxtc();             // text color
          Font     i_txtf   = item.getTxtf();             // text font
          int      i_state  = item.getState();            // state 0 - normal, 1 - highlight, 2 - clicked

          // draw the background
          switch(i_state) {
	            case 1: // highlight
	                   pad.setColor(i_mobgc);
	                   break;
	            case 2: // clicked
	                   pad.setColor(i_mcbgc);
		               break;
			    default: // normal
			            pad.setColor(i_bgc);
          }
          pad.fillRect(x,y,bw,bh);

          // draw the border
          int border = 0;
          switch(i_state) {
	            case 1: // highlight
	                   border = i_moeff;
	                   break;
	            case 2: // clicked
	                   border = i_mceff;
		               break;
			    default: // normal
			            border = i_beff;
          }

          switch(border) {
				                   case 1: // raised border
                                           pad.setColor(new Color(50,50,50));
                                           pad.drawLine(x,y+bh-1,x+bw-1,y+bh-1);
		                                   pad.drawLine(x+bw-1,y,x+bw-1,y+bh-1);

                                           pad.setColor(new Color(200,200,200));
                                           pad.drawLine(x,y,x+bw-1,y);
                                           pad.drawLine(x,y,x,y+bh-2);
                                           break;

				                   case 2: // sunken
                                           pad.setColor(new Color(200,200,200));
                                           pad.drawLine(x,y+bh-1,x+bw-1,y+bh-1);
		                                   pad.drawLine(x+bw-1,y,x+bw-1,y+bh-1);

                                           pad.setColor(new Color(50,50,50));
                                           pad.drawLine(x,y,x+bw-1,y);
                                           pad.drawLine(x,y,x,y+bh-2);
                                           break;
				                   default:
          }


          // draw the image
          switch(i_state) {
	            case 1: // highlight
	                   if (i_moimg!=null) {pad.drawImage(i_moimg, x+i_ipos.getX(), y+i_ipos.getY(), Iobs);}
	                   break;
	            case 2: // clicked
	                   if (i_mcimg!=null) {pad.drawImage(i_mcimg, x+i_ipos.getX(), y+i_ipos.getY(), Iobs);}
		               break;
			    default: // normal
			            if (i_img!=null) {pad.drawImage(i_img, x+i_ipos.getX(), y+i_ipos.getY(), Iobs);}
          }


          // draw the text
          switch(i_state) {
	            case 1: // highlight
	                   pad.setColor(i_motxtc);
	                   break;
	            case 2: // clicked
	                   pad.setColor(i_mctxtc);
		               break;
			    default: // normal
			            pad.setColor(i_txtc);
          }

          pad.setFont(i_txtf);
          pad.drawString(i_txt,x+i_txtp.getX(),y+i_txtp.getY());

          // Draw the arrow if submenu exists
          if (!item.getMid().equals("root")&&item.getSinx()>-1) {
             pad.setColor(i_arc);
             pad.drawLine(x+bw-8,y+bh/2-3,x+bw-8,y+bh/2+3);
             pad.drawLine(x+bw-7,y+bh/2-2,x+bw-7,y+bh/2+2);
             pad.drawLine(x+bw-6,y+bh/2-1,x+bw-6,y+bh/2+1);
             pad.drawLine(x+bw-5,y+bh/2,x+bw-6,y+bh/2);
	      }


          if (item.getMid().equals("root")&&item.getSinx()>-1) {
             pad.setColor(i_arc);


             pad.drawLine(x+bw-12,y+bh-8,x+bw-5,y+bh-8);
             pad.drawLine(x+bw-11,y+bh-7,x+bw-6,y+bh-7);
             pad.drawLine(x+bw-10,y+bh-6,x+bw-7,y+bh-6);
             pad.drawLine(x+bw-9,y+bh-5,x+bw-8,y+bh-5);
	      }


          // Draw divide line
          if (i_div) {
			pad.setColor(new Color(0,0,0));
			pad.drawLine(x+3,y+bh-2,x+bw-3,y+bh-2);
			pad.setColor(new Color(255,255,255));
			pad.drawLine(x+3,y+bh-1,x+bw-3,y+bh-1);


		  }


          return;

       }

//------------------------------------------------------------------------------------


                   } // End Tree Graphics Class
//========================================THE=END============================================