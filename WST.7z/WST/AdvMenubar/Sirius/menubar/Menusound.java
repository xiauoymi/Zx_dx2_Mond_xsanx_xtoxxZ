package Sirius.menubar;

import java.awt.*;
import java.applet.AudioClip;
import java.io.*;
import java.util.Vector;

public class Menusound implements Serializable {

  private String    soundname;            // Sound name
  private AudioClip sound;                // Sound

  public Menusound (String    soundname,  // Sound name
                    AudioClip sound       // Sound
	               ) {

         this.soundname  = soundname;  //  sound name
         this.sound      = sound;      //  sound

  }

  public  String    getSoundname() {return  soundname;}        // sound name
  public  AudioClip getSound()     {return  sound;}            // sound

  public void setSoundname(String soundname)   {this.soundname  = soundname;}  // sound name
  public void setSound(AudioClip sound)        {this.sound      = sound;}      // sound

}