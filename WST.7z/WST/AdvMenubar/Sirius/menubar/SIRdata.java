package Sirius.menubar;

//----------------------------------------------------------
// SIRdata.
//
// Functions
//
//   Convert int to Text String
//   Convert Double to Text String
//   Format String
//   Verify String
//   Verify Font
//   Verify Color
//   Verify Boolean
//   Verify int
//   Verify double
//
//---------------------------------------------------------

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.net.*;
import java.lang.*;
import Sirius.menubar.SIRpoint;
import Sirius.menubar.Menuimage;
import Sirius.menubar.Item;
import Sirius.menubar.MenuWindow;
import java.io.*;

public class SIRdata {

       // General variables
       private static int i;
       private static StringTokenizer st;

//------------------------------------------------------------------------------------
//    Verify String
//      Input String                  String
//      Default Value                 String
//

    public static String verifystr(String instr, String strdefault) {

             String sresult = " ";

             if (instr == null||instr.equals("")) sresult=strdefault;
             else {sresult=instr;}
             return sresult;
                                                                      }

//------------------------------------------------------------------------------------
//   * Verify Font
//      Input Font String             String
//      Default Font Value            String
//      String Tokeniser              String
//

    public static Font verifyfnt(String infnt, String fntdflt, String strtkn) {

           Font   fresult;
           String Fonttype;
		   String Fontstyle;
           int    Fontsize;
           int    i;
           String infnt2;

           try {infnt2 = infnt.trim();}
            catch(Exception e) {infnt2 = "Courier|N|10";}


           String FT = SIRdata.verifystr(infnt2,fntdflt);
           st = new StringTokenizer(FT, strtkn);

         try {
           if (st.hasMoreTokens()) {Fonttype = st.nextToken();}
                              else {Fonttype = "Courier";}
           if (st.hasMoreTokens()) {Fontstyle = st.nextToken().toUpperCase();}
                              else {Fontstyle = "N";}
           if (st.hasMoreTokens()) {Fontsize = Integer.parseInt(st.nextToken());}
                              else {Fontsize = 12;}

           if (Fontstyle.equals("B"))
                              {fresult =new Font(Fonttype,Font.BOLD,Fontsize);}
           else if (Fontstyle.equals("I"))
                              {fresult = new Font(Fonttype,Font.ITALIC,Fontsize);}
           else if (Fontstyle.equals("BI") || Fontstyle.equals("IB"))
                              {fresult = new Font(Fonttype,Font.ITALIC + Font.BOLD,Fontsize);}
           else
                              {fresult = new Font(Fonttype,Font.PLAIN,Fontsize);}
		     }
		 catch (Exception e) {fresult = new Font("Courier",Font.PLAIN,12);}
           return fresult;

                                                                             }

//------------------------------------------------------------------------------------
//*    Verify Color
//      Input Font String             String
//      Default Font Value            String
//      String Tokeniser              String
//

    public static Color verifyclr(String inclr, String clrdflt, String strtkn) {

         int RED,GREEN,BLUE,i;
         Color clrresult;
         String inclr2;


         if (inclr == null||inclr.equals("")) inclr=clrdflt;

         try {inclr2 = inclr.trim();}
            catch(Exception e) {inclr2 = "0|0|0";}

         String CLR = SIRdata.verifystr(inclr2,clrdflt);
         st = new StringTokenizer(CLR, strtkn);

         try {
			 if (st.hasMoreTokens()) {RED = Math.abs(Integer.parseInt(st.nextToken()));} else {RED = 0;}
			 if (st.hasMoreTokens()) {GREEN = Math.abs(Integer.parseInt(st.nextToken()));} else {GREEN = 0;}
			 if (st.hasMoreTokens()) {BLUE = Math.abs(Integer.parseInt(st.nextToken()));} else {BLUE = 0;}
			 clrresult = new Color(RED,GREEN,BLUE);
		     }
		 catch (Exception e) {clrresult = new Color(0,0,0);}
         return clrresult;

                                                                             }

//------------------------------------------------------------------------------------
//*    Verify boolean
//      Input String                  String
//      Default Value                 String
//

    public static boolean verifybool(String instr, String strdefault) {

             boolean bresult = false;

             if (instr == null || (instr.length()<1)) instr=strdefault;
             instr = (instr.toLowerCase()).substring(0,1);
             if (instr.equals("t")) {bresult = true;}

             return bresult;
                                                                      }

//-----------------------------------------------------------------------------------

    public static int verifyint(String instr) {

            int iresult;
            String instr2 = "0";

            try {instr2 = instr.trim();}
            catch(Exception e) {instr2 = "0";}

            try {iresult = Integer.parseInt(instr2);}
            catch(Exception e) {iresult = 0;}

            return iresult;
                                              }

//-----------------------------------------------------------------------------------------
    public static SIRpoint verifypnt(String instr) {

            SIRpoint pnt = new SIRpoint(0,0);
            int x = 0;
            int y = 0;

            if (!instr.equals(" ")&&!instr.equals(null)) {
			    st = new StringTokenizer(instr, ",");
				if (st.hasMoreTokens()) {x = verifyint(st.nextToken());}
				if (st.hasMoreTokens()) {y = verifyint(st.nextToken());}
                if (x<0) {x=0;}
                if (y<0) {y=0;}
				pnt = new SIRpoint(x,y);
			}


            return pnt;
    }



//-----------------------------------------------------------------------------------
// *
    public static Image getimage(String name,
                                 Vector imagedata) {

            Enumeration imagee = imagedata.elements();
            Image imageresult = null;
            boolean found = false;

            while (imagee.hasMoreElements()&&!found) {

              Menuimage imaged = (Menuimage)imagee.nextElement();

              if (name.equals(imaged.getImagename())) {imageresult = imaged.getImage();found=true;}


            } // End while

            return imageresult;
    }

//-----------------------------------------------------------------------------------
// *
    public static AudioClip getsound(String name,
                                     Vector sounddata) {

            Enumeration sounde = sounddata.elements();
            AudioClip soundresult = null;
            boolean found = false;

            while (sounde.hasMoreElements()&&!found) {

              Menusound soundd = (Menusound)sounde.nextElement();

              if (name.equals(soundd.getSoundname())) {soundresult = soundd.getSound();found=true;}


            } // End while

            return soundresult;
    }


//-----------------------------------------------------------------------------------
// Set window index on all items
//
    public static void setwindowindex(Vector idata,
                                      Vector mwins
                                     ) {

            Enumeration ie = idata.elements();
            String i_sid;

            while (ie.hasMoreElements()) {
              Item id = (Item)ie.nextElement();
              id.setSinx(getsubindex(id.getSid(),mwins));
            } // End while

            return;
    }

//-----------------------------------------------------------------------------------
//*
    public static Vector getmenuitems(String mid,
                                      Vector idata
                                      ) {

            Vector mi = new Vector();
            Enumeration ie = idata.elements();
            String i_mid;
            int index = 0;

            while (ie.hasMoreElements()) {
              Item id = (Item)ie.nextElement();
              i_mid   = id.getMid();
              if (mid.equals(i_mid)) {id.setIndex(index);
                                      mi.addElement(id);
                                      index++;}
            } // End while

            return mi;
    }
//-----------------------------------------------------------------------------------
//*
    public static Vector getitems(String mid,
                                  Vector idata) {

            Vector mi = new Vector();
            Enumeration ie = idata.elements();
            String i_mid;
            int index = 0;

            while (ie.hasMoreElements()) {
              Item id = (Item)ie.nextElement();
              i_mid   = id.getMid();
              if (mid.equals(i_mid)) {id.setIndex(index);
                                      mi.addElement(id);
                                      index++;}
            } // End while

            return mi;
    }
//-----------------------------------------------------------------------------------
    public static int getsubindex(String id, Vector mwins) {

		int index = -1;
		String mw_id = " ";
		Enumeration mwe = mwins.elements();
        int i = 0;

        if (id!=null) {
 		   while (mwe.hasMoreElements()) {
		         MenuWindow mw = (MenuWindow)mwe.nextElement();
		         mw_id   = mw.getId();
		         if (mw_id.equals(id)) {index = i;}
		         i++;

           } // End while
	    }

		return index;
	}
//-----------------------------------------------------------------------------------
//*
    public static int getnitems(String mid,
                                Vector idata
                                ) {

            int nit = 0;
            Vector mi = new Vector();
            Enumeration ie = idata.elements();
            String i_mid;
            int index = 0;

            while (ie.hasMoreElements()) {
              Item id = (Item)ie.nextElement();
              i_mid   = id.getMid();
              if (mid.equals(i_mid)) {nit++;}
            } // End while

            return nit;
    }
//-----------------------------------------------------------------------------------
//*
    public static Menubar getMenubar(String id,
                                     Vector menu
                                      ) {

            Enumeration me = menu.elements();
            Menubar mb = null;
            String  mid;

            while (me.hasMoreElements()) {
              Menubar m = (Menubar)me.nextElement();
              mid   = m.getMid();
              if (id.equals(mid)) {mb = m;}
            } // End while

            return mb;
    }
//-----------------------------------------------------------------------------------
//*
    public static Vector createwindows(Vector menu,
                                       Vector itemdata,
                                       Frame  frame,
                                       Applet parentapplet,
                                       Menubarbean menubarbean,
                                       boolean closeonclick
                                        ) {

            Vector mwin = new Vector();
            MenuWindow mw;
            Enumeration me = menu.elements();
            String  mid;
            int warn;

            while (me.hasMoreElements()) {
              Menubar m = (Menubar)me.nextElement();
              mid   = m.getMid();
              if (!mid.equals("root")) {
                 mw = new MenuWindow(frame);

                 warn = mw.getInsets().bottom+1;

                 mw.setId(m.getMid());
                 mw.setMitems(getitems(m.getMid(),itemdata));
				 mw.setBw(m.getBw());
				 mw.setBh(m.getBh());
				 mw.setGap(m.getGap());
				 mw.setBg(m.getBg());
				 mw.setBgimg(m.getBgimg());
				 mw.setWinh( ((m.getBh()+m.getGap()) * (getnitems(m.getMid(),itemdata)))-m.getGap());
				 mw.setParentapplet(parentapplet);
				 mw.setMenubarbean(menubarbean);
				 mw.setCloseonclick(closeonclick);

                 mw.setVisible(false);
                 mwin.addElement(mw);

                 // System.out.println("Createwindows Gap:"+m.getGap());
		      }
            } // End while

            return mwin;
    }
//----------------------------------------------------------------------------------

                 } // End SIRdata class
//========================================THE=END============================================