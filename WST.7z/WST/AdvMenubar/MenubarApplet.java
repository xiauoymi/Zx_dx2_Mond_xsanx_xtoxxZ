/*
    MenubarApplet
    Copyright (c) 2001 by Sirius Computer Consultants Ltd. All rights reserved.
    Author: Patrick O'Brien  15/04/2002
    Version: 2.5

Sirius Computer Consultants Ltd herby grants you a non-exclusive
license to use its accompanying software product provided that,
  1) Licensee does not redistribute the software.
  2) Utilize the software in a manner which is disparaging to Sirius.
  3) No attempt is made to  modify, translate,reverse engineer,
     decompile, disassemble or create derivative works based on the Software.
  4) Rent, lease, transfer or otherwise transfer rights to the
     Software; or remove any proprietary  notices or labels on the Software.

This license does not grant you any right to any enhancement or update.

Title, ownership rights, and intellectual property
rights in and to the Software shall remain in Sirius Computer Consultants Ltd.
The Software is protected by the international copyright
laws.  Title, ownership rights, and intellectual property
rights in and to the content accessed through the Software is
the property of the applicable content owner and may be
protected by applicable copyright or other law. This License
gives you no rights to such content.

This software is provided "AS IS," without a warranty of any kind. ALL
EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SIRIUS AND ITS LICENSORS SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SIRIUS OR ITS
LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
OR INABILITY TO USE SOFTWARE, EVEN IF SIRIUS HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

This software is not designed or intended for use in on-line control of
aircraft, air traffic, aircraft navigation or aircraft communications; or in
the design, construction, operation or maintenance of any nuclear
facility. Licensee represents and warrants that it will not use or
redistribute the Software for such purposes.

*/

import Sirius.menubar.*;
import Sirius.menubar.Menubarbean;
import Sirius.menubar.Menuimage;
import Sirius.menubar.Menusound;
import Sirius.menubar.SIRdata;
import Sirius.menubar.SIRpoint;
import Sirius.menubar.Item;
import Sirius.menubar.Menubar;
import java.applet.Applet;
import java.awt.*;
import java.util.*;
import java.awt.image.*;
import java.net.*;
import java.lang.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;

import java.applet.AppletContext;

public class MenubarApplet extends Applet
{

    // Bean Object
    private Menubarbean menubarbean;

    // Data Objects
    private Vector itemdata;      // item data Object
    private Vector menu;          // Menu Objects
    private Vector imagedata;     // Image data Object
    private Vector sounddata;     // Sound data Object

    // Item data varaibles
    private String   i_mid;              // menu id
    private String   i_id;               // item id
    private String   i_sid;              // submenu window index
    private Color    i_bgc;              // background color
    private Color    i_arc;              // arrow color
    private boolean  i_div;              // divide line
    private Color    i_mobgc;            // mouseover bg color
    private Color    i_motxtc;           // mouseover txt color
    private int      i_moeff;            // mouseover effect (none, raised, sunken)
    private Color    i_mcbgc;            // mouseclick color
    private Color    i_mctxtc;           // mouseover txt color
    private int      i_mceff;            // mouseclick effect (none, raised, sunken)
    private int      i_beff;             // border effect
    private Image    i_img;              // image
    private Image    i_moimg;            // mouseover image
    private Image    i_mcimg;            // mouseclick image
    private SIRpoint i_ipos;             // image relative position
    private String   i_txt;              // text
    private SIRpoint i_txtp;             // text inset
    private Color    i_txtc;             // text color
    private Font     i_txtf;             // text font
    private String   i_url;              // url
    private String   i_target;           // target
    private AudioClip i_aopen;            // submenu open
    private AudioClip i_aclose;           // submenu close
    private AudioClip i_aclick;           // button click
    private String    i_statusmsg;        // status bar message

    // Menu data variables
    private String   m_mid;              // menu id  (root is top level)
    private int      m_bw;               // button width
    private int      m_bh;               // button height
    private int      m_gap;              // gap between buttons
    private int      m_mw;               // Menu Width
    private Color    m_bg;               // bg color
    private Image    m_img;              // menu background image

    // General Applet properties
    private boolean closeonclick;        // Close all Sub-menu's upon a mouse click

    // General Applet working variables
    // private String debugmsg;
    private int     i;
    private String  sTemp;
    private String  sTemp2;
    private StringTokenizer st;

//-------------------------------------------------------------------------------------
    public MenubarApplet()
    {
    }
//------------------------------------------------------------------------------------
   public void init() {

      String copyright = "Copyright (c) 2001 by Sirius Computer Consultants Ltd - "+
                         "Unauthorized distribution is forbidden.";
      // if(!getDocumentBase().toString().startsWith("http://www.jpowered.com"))
      //       System.exit(0);

                      }
//------------------------------------------------------------------------------------
// Start Method
//
   public void start() {

		// Initialise Menu bar Bean
        menubarbean = new Menubarbean();


        // Gather and set bean data
        get_images();
        get_audio();     // get sounds

        // Get background sound parameter and start playing sound.
		AudioClip bgsound = null;
		boolean   loop    = false;

		sTemp = getParameter("BackgroundSound");
		if (sTemp!="" & sTemp!=null) {st = new StringTokenizer(sTemp, "|");
		                              if (st.hasMoreTokens()) {bgsound     = SIRdata.getsound(st.nextToken(),sounddata);}
		                              if (st.hasMoreTokens()) {loop        = SIRdata.verifybool(st.nextToken(), "false");}
								     }

		if (bgsound!=null) {
		   if (loop) {bgsound.loop();}
			    else {bgsound.play();}
	    }


        // Get the General Applet properties
        closeonclick = false;
        sTemp = getParameter("CloseOnClick");
        if (sTemp!="" & sTemp!=null) {closeonclick = SIRdata.verifybool(sTemp, "false");}     // Close Submenu's upon mouse click


        // Get Item data
        itemdata = new Vector();
        sTemp = null;
        sTemp = getParameter("Itemdata");
        if (sTemp!="" & sTemp!=null) {get_itemdatafromfile(sTemp);}
                                else {get_itemdata();}

        menu  = new Vector();
        sTemp = null;
        sTemp = getParameter("Menudata");
        if (sTemp!="" & sTemp!=null) {get_menudatafromfile(sTemp);}
                                else {get_menudata();}

        // Add the bean to the applet canvas
        setLayout(null);
        add(menubarbean);
        menubarbean.setCloseonclick(closeonclick);
        menubarbean.setParentapplet(this);
        menubarbean.setItemdata(itemdata);
        menubarbean.setMenudata(menu);


        // Start the bean.
        menubarbean.start();


 } // End start


//-----------------------------------------------------------------------------
//
    private void get_itemdatafromfile(String fn) {

		 URL	fileURL = null;

    	 try {fileURL = new URL(getCodeBase(), fn);}
	     catch ( MalformedURLException e) {
	     System.out.println("Bad URL for File Location : " + fn);}

		 URLConnection conn = null;
		 DataInputStream data = null;

 		 try {
			   conn = fileURL.openConnection();
			   conn.connect();
			   data = new DataInputStream(new BufferedInputStream(
			   conn.getInputStream()));
			   i = 1;
			   while (( sTemp = data.readLine()) != null) {if (!sTemp.startsWith("<!-")) {add_item(sTemp,i); i++;}}
		 }
		 catch (IOException e) {
			System.out.println("IO Error:" + e.getMessage());}

	}
//-----------------------------------------------------------------------------
//
    private void get_itemdata() {
		i = 1;
		sTemp = getParameter("item"+i);
		while (sTemp!=null) {
			   add_item(sTemp, i);
		       i++;
			   sTemp = getParameter("item" + i);
		}
	}
//-----------------------------------------------------------------------------
//  Create Item
//
    private void add_item(String str, int cnt) {

            i_mid     = "";                                   // menu id
            i_id      = "item" + String.valueOf(cnt);         // item id
            i_sid     = "";                                   // submenu id
            i_bgc     = new Color(255,255,255);               // background color
            i_arc     = new Color(100,100,100);               // arrow color
            i_div     = false;                                // divide line
            i_mobgc   = new Color(0,0,0);                     // mouseover bg color
            i_motxtc  = new Color(255,255,255);               // mouseover txt color
            i_moeff   = 0;                                    // mouseover effect (none, raised, sunken)
            i_mcbgc   = new Color(0,0,0);                     // mouseclick color
            i_mctxtc  = new Color(255,255,255);               // mouseover txt color
            i_mceff   = 0;                                    // mouseclick effect (none, raised, sunken)
            i_beff    = 0;                                    // border effect
            i_img     = null;                                 // image
            i_moimg   = null;                                 // mouseover image
            i_mcimg   = null;                                 // mouseclick image
            i_ipos    = new SIRpoint(0,0);                    // image relative position
            i_txt     = "";                                   // text
            i_txtp    = new SIRpoint(5,15);                   // text inset
            i_txtc    = new Color(0,0,0);                     // text color
            i_txtf    = new Font("Helvetica",Font.PLAIN,10);  // text font
            i_url     = "";                                   // url
            i_target  = "";                                   // target
            i_aopen   = null;
            i_aclose  = null;
            i_aclick  = null;
            i_statusmsg = null;                               // Status Bar message

	        st = new StringTokenizer(str, "|");

            if (st.hasMoreTokens()) {i_mid     = st.nextToken();}                                         // menu id
            // if (st.hasMoreTokens()) {i_id      = st.nextToken();}                                         // item id
            if (st.hasMoreTokens()) {i_sid     = st.nextToken();}                                         // sub menu id
            if (st.hasMoreTokens()) {i_bgc     = SIRdata.verifyclr(st.nextToken(),"255,255,255",",");}    // background color
            if (st.hasMoreTokens()) {i_arc     = SIRdata.verifyclr(st.nextToken(),"100,100,100",",");}    // arrowcolor
            if (st.hasMoreTokens()) {i_div     = SIRdata.verifybool(st.nextToken(), "false");}            // divide line
            if (st.hasMoreTokens()) {i_mobgc   = SIRdata.verifyclr(st.nextToken(),"0,0,0",",");}          // mouseover bg color
            if (st.hasMoreTokens()) {i_motxtc  = SIRdata.verifyclr(st.nextToken(),"255,255,255",",");}    // mouseover text color
            if (st.hasMoreTokens()) {i_moeff   = SIRdata.verifyint(st.nextToken());}                      // mouseover effect
            if (st.hasMoreTokens()) {i_mcbgc   = SIRdata.verifyclr(st.nextToken(),"0,0,0",",");}          // mouseclick bg color
            if (st.hasMoreTokens()) {i_mctxtc  = SIRdata.verifyclr(st.nextToken(),"255,255,255",",");}    // mouseclick text color
            if (st.hasMoreTokens()) {i_mceff   = SIRdata.verifyint(st.nextToken());}                      // mouseclick effect
            if (st.hasMoreTokens()) {i_beff    = SIRdata.verifyint(st.nextToken());}                      // border effect
            if (st.hasMoreTokens()) {i_img     = SIRdata.getimage(st.nextToken(),imagedata);}             // normal image
            if (st.hasMoreTokens()) {i_moimg   = SIRdata.getimage(st.nextToken(),imagedata);}             // mouseover image
            if (st.hasMoreTokens()) {i_mcimg   = SIRdata.getimage(st.nextToken(),imagedata);}             // mouseclick image
            if (st.hasMoreTokens()) {i_ipos    = SIRdata.verifypnt(st.nextToken());}                      // image position
            if (st.hasMoreTokens()) {i_txt     = st.nextToken();}                                         // item text
            if (st.hasMoreTokens()) {i_txtp    = SIRdata.verifypnt(st.nextToken());}                      // text position
            if (st.hasMoreTokens()) {i_txtc    = SIRdata.verifyclr(st.nextToken(),"0,0,0",",");}          // text color
            if (st.hasMoreTokens()) {i_txtf    = SIRdata.verifyfnt(st.nextToken(),"Helvetica,N,10",",");} // text font
            if (st.hasMoreTokens()) {i_url     = st.nextToken();}                                         // url
            if (st.hasMoreTokens()) {i_target  = st.nextToken();}                                         // target frame
            if (st.hasMoreTokens()) {i_aopen   = SIRdata.getsound(st.nextToken(),sounddata);}             // submenu open
            if (st.hasMoreTokens()) {i_aclose  = SIRdata.getsound(st.nextToken(),sounddata);}             // submenu close
            if (st.hasMoreTokens()) {i_aclick  = SIRdata.getsound(st.nextToken(),sounddata);}             // button click
            if (st.hasMoreTokens()) {i_statusmsg = st.nextToken();}                                       // status bar message

            if (i_moimg==null) {i_moimg = i_img;}
            if (i_mcimg==null) {i_mcimg = i_moimg;}

		    itemdata.addElement(new Item(i_mid,              // menu id
		                                 i_id,               // item id
		                                 0,                  // item index
                                         i_sid,              // submenu id
                                         -1,                 // sub menu window index
                                         i_bgc,              // background color
                                         i_arc,              // arrow color
                                         i_div,              // divide line
                                         i_mobgc,            // mouseover bg color
                                         i_motxtc,           // mouseover txt color
                                         i_moeff,            // mouseover effect (none, raised, sunken)
                                         i_mcbgc,            // mouseclick color
                                         i_mctxtc,           // mouseover txt color
                                         i_mceff,            // mouseclick effect (none, raised, sunken)
                                         i_beff,             // border effect
                                         i_img,              // image
                                         i_moimg,            // mouseover image
                                         i_mcimg,            // mouseclick image
                                         i_ipos,             // image relative position
                                         i_txt,              // text
                                         i_txtp,             // text inset
                                         i_txtc,             // text color
                                         i_txtf,             // text font
                                         i_url,              // url
                                         i_target,           // target
                                         0,                  // state 0 - normal, 1 - highlight, 2 - clicked
                                         i_aopen,            // submenu open
                                         i_aclose,           // submenu close
                                         i_aclick,           // button click
                                         i_statusmsg         // Satus Bar message
                                        ));

    }

//-----------------------------------------------------------------------------
//
    private void get_menudatafromfile(String fn) {

			URL	fileURL = null;

		  	try {fileURL = new URL(getCodeBase(), fn);}
			catch ( MalformedURLException e) {System.out.println("Bad URL for File Location : " + fn);}

			URLConnection conn = null;
			DataInputStream data = null;

		 	try {
				 conn = fileURL.openConnection();
				 conn.connect();
				 data = new DataInputStream(new BufferedInputStream(
				 conn.getInputStream()));
				 while (( sTemp = data.readLine()) != null) {if (!sTemp.startsWith("<!-")) {add_menu(sTemp);}}
				 }
			catch (IOException e) {System.out.println("IO Error:" + e.getMessage());}



	}
//-----------------------------------------------------------------------------
//
    private void get_menudata() {
		i = 1;
		sTemp = getParameter("menu"+i);
		while (sTemp!=null) {
			   add_menu(sTemp);
		       i++;
			   sTemp = getParameter("menu" + i);
		}


	}
//-----------------------------------------------------------------------------
//  Create Menu
//
    private void add_menu(String str) {

            m_mid    = "";                      // menu id  (root is top level)
            m_bw     = 0;                       // button width
            m_bh     = 0;                       // button height
            m_gap    = 0;                       // gap between buttons
            m_mw     = 0;                       // Menu Width
            m_bg     = new Color(255,255,255);  // Bg Color
            m_img    = null;                    // menu background image

	        st = new StringTokenizer(str, "|");

            if (st.hasMoreTokens()) {m_mid    = st.nextToken();}                                 // menu id  (root is top level)
            if (st.hasMoreTokens()) {m_bw     = SIRdata.verifyint(st.nextToken());}              // button width
            if (st.hasMoreTokens()) {m_bh     = SIRdata.verifyint(st.nextToken());}              // button height
            if (st.hasMoreTokens()) {m_gap    = SIRdata.verifyint(st.nextToken());}              // gap between buttons
            if (st.hasMoreTokens()) {m_bg     = SIRdata.verifyclr(st.nextToken(),"0,0,0",",");}  // bg color
            if (st.hasMoreTokens()) {m_img    = SIRdata.getimage(st.nextToken(),imagedata);}     // menu background image

            if (m_mid.equals("root")) {m_mw = m_bw*(SIRdata.getnitems("root",itemdata)+m_gap)-m_gap;}
            else                      {m_mw = m_bw;}

		    menu.addElement(new Menubar(m_mid,        // item id
                                        m_bw,         // button width
                                        m_bh,         // button height
                                        m_gap,        // gap between buttons
                                        m_mw,         // Menu Width
                                        m_bg,         // bg color
                                        m_img         // menu background image
                                       ));

    }
//-----------------------------------------------------------------------------
// Create the images
//
    private void get_images() {
         imagedata = new Vector();
         String iname;
         Image  im;
         i = 1;
         sTemp = getParameter("image"+i);
         while (sTemp!="" & sTemp!=null) {
               st = new StringTokenizer(sTemp, "|");
               if (st.hasMoreTokens()) {iname = st.nextToken();}   else {iname = "";}
               if (st.hasMoreTokens()) {im = downloadImage(st.nextToken());} else {im=null;}
               imagedata.addElement(new Menuimage(iname,im));
               i++;
	           sTemp = getParameter("image" + i);
		 }
    }

//-----------------------------------------------------------------------------
// Create the Audio Files
//
    private void get_audio() {
         sounddata = new Vector();
         String sname;
         AudioClip  audio;
         i = 1;
         sTemp = getParameter("sound"+i);
         while (sTemp!="" & sTemp!=null) {
               st = new StringTokenizer(sTemp, "|");
               if (st.hasMoreTokens()) {sname = st.nextToken();}   else {sname = "";}
               if (st.hasMoreTokens()) {audio = this.getAudioClip(getDocumentBase(), st.nextToken());} else {audio=null;}
               sounddata.addElement(new Menusound(sname,audio));
               i++;
	           sTemp = getParameter("sound" + i);
		 }
    }

//DownloadImage--------------------------------------------------------------------------------

    public Image downloadImage(String img) {
		int pixs[];
        MediaTracker tracker;
        tracker = new MediaTracker(this);
        Image di = getImage(getCodeBase(), img);
        tracker.addImage(di, 0);
        try {
            showStatus("Loading Image...");
            tracker.waitForID(0);
            showStatus("");
        }
        catch(InterruptedException e) {
             return createImage(size().width, size().height);
        }
    //MakeVMThinkTheImageSourceIsMemory______________________________________
        int w = di.getWidth(this);
        int h = di.getHeight(this);
        pixs = new int[w * h];
        PixelGrabber pg = new PixelGrabber(di, 0, 0, w, h, pixs, 0, w);
        try {
            pg.grabPixels();
        }
        catch (InterruptedException e) {
            System.err.println("interrupted waiting for pixels!");
            showStatus("Image loading error");
            return createImage(size().width, size().height);
        }
        if((pg.status() & ImageObserver.ABORT) != 0) {
            System.err.println("image fetch aborted or errored");
            showStatus("Image loading error");
            return createImage(size().width, size().height);
        }
        di = createImage(new MemoryImageSource(w, h, pixs, 0, w));
        int index = 0;
        return di;
    } // End download image method

//------------------------------------------------------------------------------------

} // End Applet class