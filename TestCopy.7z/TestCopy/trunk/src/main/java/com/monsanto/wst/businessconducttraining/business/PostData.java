package com.monsanto.wst.businessconducttraining.business;

import java.io.*;
import java.net.*;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:24:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class PostData {
  public PostData()
  {
  }

  public String postDataGetResponse()
  {
      try
      {
          String s = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode("monsantoadmin", "UTF-8");
          s = s + "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode("admin", "UTF-8");
          System.out.println("Data :" + s);
          URL url = new URL("http://library.midicorp.com/monsanto/default.asp");
          HttpURLConnection httpurlconnection = (HttpURLConnection)url.openConnection();
          httpurlconnection.setRequestMethod("POST");
          httpurlconnection.setDoOutput(true);
          OutputStreamWriter outputstreamwriter = new OutputStreamWriter(httpurlconnection.getOutputStream());
          outputstreamwriter.write(s);
          outputstreamwriter.flush();
          BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
          String s1;
          while((s1 = bufferedreader.readLine()) != null)
              System.out.println(s1);
          outputstreamwriter.close();
          bufferedreader.close();
      }
      catch(Exception exception) { }
      return "SUCCESS";
  }

  public void prepareMultiPartFormWithParameters(String s, String s1, DataOutputStream dataoutputstream)
      throws IOException
  {
      dataoutputstream.writeBytes("Content-Disposition: form-data; name=\"" + s + "\"" + "\r\n");
      dataoutputstream.writeBytes("\r\n");
      dataoutputstream.writeBytes(s1);
      dataoutputstream.writeBytes("\r\n");
  }

  public void appendDelimiter(DataOutputStream dataoutputstream)
      throws IOException
  {
      dataoutputstream.writeBytes("-----------------------------7d626e13d0a4c\r\n");
  }

  public void appendEndOfFormDelimiter(DataOutputStream dataoutputstream)
      throws IOException
  {
      dataoutputstream.writeBytes("-----------------------------7d626e13d0a4c--\r\n");
  }

  public void prepareMultiPartFormWithParametersString(String s, String s1, DataOutputStream dataoutputstream)
      throws IOException
  {
      dataoutputstream.writeBytes("Content-Disposition: form-data; name=\"" + s + "\"" + "\r\n");
      dataoutputstream.writeBytes("\r\n");
      dataoutputstream.writeBytes(s1);
      dataoutputstream.writeBytes("\r\n");
  }

  public void appendDelimiterString(DataOutputStream dataoutputstream)
      throws IOException
  {
      dataoutputstream.writeBytes("-----------------------------7d626e13d0a4c\r\n");
  }

  public static final String TWO_HYPHENS = "--";
  public static final String LINE_END = "\r\n";
  public static final String BOUNDARY = "---------------------------7d626e13d0a4c";
  public static final String DELIMETER = "-----------------------------7d626e13d0a4c\r\n";
  public static final String END_OF_FILE_DELIMETER = "-----------------------------7d626e13d0a4c--\r\n";

}
