package com.monsanto.wst.businessconducttraining.controllers;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.ParserException;
import java.io.IOException;
import java.io.PrintStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:36:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class LogonController implements UseCaseController{
  public LogonController()
  {
  }

  public void run(UCCHelper ucchelper)
      throws IOException
  {
      Logger.traceEntry();
      try
      {
          ucchelper.clearSession();
          String s = getSignOnURL(ucchelper);
          System.out.println("Sign On URL :" + s);
          redirectToTarget(ucchelper, s);
          Logger.traceExit();
      }
      catch(Exception exception)
      {
          System.out.println("Exception is :" + exception.getMessage());
      }
  }

  protected void redirectToTarget(UCCHelper ucchelper, String s)
      throws IOException
  {
      ucchelper.redirect(s);
  }

  protected String getSignOnURL(UCCHelper ucchelper)
      throws POSException, POSCommunicationException, ParserException, IOException, TransformerException, PeopleInfoException, NoSuchAlgorithmException, InvalidKeyException, EncryptorException, IllegalAccessException, InstantiationException, ClassNotFoundException
  {
      URLGenerator urlgenerator = createURLGenerator(ucchelper);
      return urlgenerator.computeTargetURL();
  }

  protected URLGenerator createURLGenerator(UCCHelper ucchelper)
      throws ClassNotFoundException, IllegalAccessException, InstantiationException
  {
      String s = "";
      HashMap hashmap = ucchelper.getInitParameters();
      if(hashmap.containsKey("urlGenerator"))
          s = (String)hashmap.get("urlGenerator");
      else
          throw new ClassNotFoundException("Parameter not found");
      Class class1 = Class.forName(s);
      URLGenerator urlgenerator = (URLGenerator)class1.newInstance();
      urlgenerator.init(ucchelper);
      return urlgenerator;
  }

}
