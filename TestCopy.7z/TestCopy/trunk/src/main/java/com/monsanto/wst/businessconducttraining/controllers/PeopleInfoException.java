package com.monsanto.wst.businessconducttraining.controllers;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:35:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeopleInfoException extends Exception{
  public PeopleInfoException(String s)
  {
      super(s);
  }

  public PeopleInfoException(String s, Throwable throwable)
  {
      super(s, throwable);
  }

}
