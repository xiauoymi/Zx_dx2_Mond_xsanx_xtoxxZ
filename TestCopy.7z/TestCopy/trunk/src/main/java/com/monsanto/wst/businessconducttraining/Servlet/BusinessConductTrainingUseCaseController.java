/*
 ExampleServletUseCaseController was created on May 21, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.businessconducttraining.Servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.security.SecureUser;

import java.io.IOException;

/**
 * <p>Title: BusinessConductTrainingUseCaseController</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: BusinessConductTrainingUseCaseController.java,v 1.1 2006-03-08 17:56:29 ardharn Exp $
 */
public abstract class BusinessConductTrainingUseCaseController implements UseCaseController
{
   protected boolean checkForTimeout(UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      boolean boolRetVal = false;

      SecureUser loggedOnUser = (SecureUser)helper.getSessionParameter(I_SessionParams.sf_cstrCURRENT_USER);
      if (loggedOnUser == null) {
         boolRetVal = true;

         DisplaySessionTimeout.displayTimeoutMessage(helper.getPrintWriter());
      }

      return Logger.traceExit(boolRetVal);
   }
}
