package com.monsanto.wst.businessconducttraining.Security;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.AbstractLogging.Logger;

import java.io.IOException;

/**
 *
 * <p>Title: BusinessConductTrainingLogoutController.java</p>
 * <p>Description: Closes the session and calls the logon controller.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: BusinessConductTrainingLogoutController.java,v 1.1 2006-03-08 17:56:29 ardharn Exp $
 */
public class BusinessConductTrainingLogoutController implements UseCaseController
{
   /**
    * Closes the session and calls the logon controller to re-logon the user.
    * @param helper A Use Case Controller helper class.
    * @throws java.io.IOException
    */
   public void run(UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      helper.closeSession();
      helper.displayHTML_File("html/BusinessConductTrainingLogon.html");

      Logger.traceExit();
   }
}
