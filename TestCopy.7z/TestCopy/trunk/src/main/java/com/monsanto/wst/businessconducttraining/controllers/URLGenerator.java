package com.monsanto.wst.businessconducttraining.controllers;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:28:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class URLGenerator {
  public URLGenerator()
  {
  }

  public void init(UCCHelper ucchelper)
  {
      helper = ucchelper;
  }

  protected ClientSecurityProxy createClientSecurityProxy()
  {
      return new KerberosSPNEGOClient(new OSBasedGSSManagerFactory());
  }

  protected SecureXMLPOSConnection createPOSCommunication(ClientSecurityProxy clientsecurityproxy, UCCHelper ucchelper)
  {
      return new SecureXMLPOSConnection(clientsecurityproxy, ucchelper.getSystemSecurityProxy());
  }

  public Document makeInputDocument(UCCHelper ucchelper)
  {
      UserRequest userrequest = new UserRequest(ucchelper.getAuthenticatedUserID().toUpperCase());
      Document document = userrequest.toXML();
      return document;
  }

  public String computeTargetURL()
      throws ParserException, IOException, TransformerException, POSException, POSCommunicationException, PeopleInfoException, NoSuchAlgorithmException, InvalidKeyException, EncryptorException, ClassNotFoundException
  {
      String s = getSkeletonURL();
      String s1 = getSiteSpecificMods(s);
      return s1;
  }

  public String getSkeletonURL()
      throws ParserException, TransformerException, IOException, PeopleInfoException, POSCommunicationException, POSException, ClassNotFoundException
  {
      StringBuffer stringbuffer = new StringBuffer();
      String s = getTargetURL();
      stringbuffer.append(s);
      return stringbuffer.toString();
  }

  protected String getSiteSpecificMods(String s)
      throws ParserException, IOException, TransformerException, POSException, POSCommunicationException, PeopleInfoException
  {
      return s;
  }

  protected String getTargetURL()
      throws ClassNotFoundException
  {
      String s = "";
      HashMap hashmap = helper.getInitParameters();
      if(hashmap.containsKey("targetURL"))
          s = (String)hashmap.get("targetURL");
      return s;
  }

  protected String addParametersFromHelperToSkeletonURL()
      throws IOException
  {
      StringBuffer stringbuffer = new StringBuffer();
      Enumeration enumeration = helper.getParameterNames();
      if(enumeration.hasMoreElements())
      {
          String s;
          String s1;
          for(; enumeration.hasMoreElements(); stringbuffer.append("&").append(s).append("=").append(s1))
          {
              s = (String)enumeration.nextElement();
              s1 = helper.getRequestParameterValue(s);
          }

      }
      return stringbuffer.toString();
  }

  protected String getURLEncodedCurrentTimestamp()
      throws UnsupportedEncodingException
  {
      String s = "yyyy-MM-dd HH:mm:ss";
      String s1 = null;
      TimeZone timezone = TimeZone.getTimeZone("UTC");
      Calendar calendar = Calendar.getInstance(timezone);
      SimpleDateFormat simpledateformat = new SimpleDateFormat(s);
      simpledateformat.setTimeZone(timezone);
      s1 = simpledateformat.format(calendar.getTime());
      return URLEncoder.encode(s1, "UTF-8");
  }

  protected UCCHelper helper;
  protected static final String SITE = "NA1000";
  protected static final String defaultURL = "https://app2.outtask.com/verify_login.asp";
  
}
