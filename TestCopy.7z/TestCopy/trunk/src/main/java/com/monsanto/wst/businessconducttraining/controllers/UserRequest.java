package com.monsanto.wst.businessconducttraining.controllers;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:30:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserRequest {
  public UserRequest(String s)
  {
      authenticatedUserID = s;
  }

  public Document toXML()
  {
      Document document = DOMUtil.newDocumentNS();
      Element element = DOMUtil.addChildElementWithNS("http://www.monsanto.com/PeopleInfo", document, "PeopleInfoRequest");
      addNameSpace(element, "http://www.monsanto.com/PeopleInfo", ":PI");
      DOMUtil.addChildElementWithNS("http://www.monsanto.com/PeopleInfo", element, "Userid", authenticatedUserID);
      return document;
  }

  private void addNameSpace(Element element, String s, String s1)
  {
      DOMUtil.setAttribute(element, "xmlns", s);
      DOMUtil.setAttribute(element, "xmlns" + s1, s);
      DOMUtil.setAttribute(element, "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
  }

  private String authenticatedUserID;
  private final String PEOPLE_INFO_NAMESPACE = "http://www.monsanto.com/PeopleInfo";

}
